<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-03-09 00:58:52 --> Upload Class Initialized
INFO - 2020-03-09 00:58:52 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2020-03-09 00:58:52 --> You did not select a file to upload.
INFO - 2020-03-09 01:07:49 --> Final output sent to browser
DEBUG - 2020-03-09 01:07:49 --> Total execution time: 0.1543
INFO - 2020-03-09 01:09:02 --> Upload Class Initialized
INFO - 2020-03-09 01:09:02 --> Language file loaded: language/english/upload_lang.php
INFO - 2020-03-09 01:09:02 --> The image you are attempting to upload doesn't fit into the allowed dimensions.
INFO - 2020-03-09 01:15:32 --> Upload Class Initialized
INFO - 2020-03-09 01:15:32 --> Language file loaded: language/english/upload_lang.php
ERROR - 2020-03-09 01:15:32 --> The upload path does not appear to be valid.
INFO - 2020-03-09 01:19:31 --> Upload Class Initialized
INFO - 2020-03-09 01:19:31 --> Language file loaded: language/english/upload_lang.php
ERROR - 2020-03-09 01:19:31 --> The upload path does not appear to be valid.
INFO - 2020-03-09 01:21:24 --> Upload Class Initialized
INFO - 2020-03-09 01:21:24 --> Language file loaded: language/english/upload_lang.php
ERROR - 2020-03-09 01:21:24 --> The upload path does not appear to be valid.
INFO - 2020-03-09 01:23:12 --> Upload Class Initialized
INFO - 2020-03-09 01:23:12 --> Language file loaded: language/english/upload_lang.php
ERROR - 2020-03-09 01:23:12 --> The upload path does not appear to be valid.
INFO - 2020-03-09 01:24:37 --> Upload Class Initialized
INFO - 2020-03-09 01:24:37 --> Language file loaded: language/english/upload_lang.php
ERROR - 2020-03-09 01:24:37 --> The upload path does not appear to be valid.
INFO - 2020-03-09 01:28:40 --> Upload Class Initialized
INFO - 2020-03-09 01:31:01 --> Upload Class Initialized
INFO - 2020-03-09 01:32:01 --> Final output sent to browser
DEBUG - 2020-03-09 01:32:01 --> Total execution time: 0.1712
INFO - 2020-03-09 01:32:37 --> Upload Class Initialized
INFO - 2020-03-09 01:34:20 --> Upload Class Initialized
INFO - 2020-03-09 01:55:41 --> Final output sent to browser
DEBUG - 2020-03-09 01:55:41 --> Total execution time: 0.1286
INFO - 2020-03-09 01:56:28 --> Upload Class Initialized
INFO - 2020-03-09 00:58:37 --> Config Class Initialized
INFO - 2020-03-09 00:58:37 --> Hooks Class Initialized
DEBUG - 2020-03-09 00:58:37 --> UTF-8 Support Enabled
INFO - 2020-03-09 00:58:37 --> Utf8 Class Initialized
INFO - 2020-03-09 00:58:37 --> URI Class Initialized
DEBUG - 2020-03-09 00:58:37 --> No URI present. Default controller set.
INFO - 2020-03-09 00:58:37 --> Router Class Initialized
INFO - 2020-03-09 00:58:37 --> Output Class Initialized
INFO - 2020-03-09 00:58:37 --> Security Class Initialized
DEBUG - 2020-03-09 00:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 00:58:37 --> Input Class Initialized
INFO - 2020-03-09 00:58:37 --> Language Class Initialized
INFO - 2020-03-09 00:58:37 --> Loader Class Initialized
INFO - 2020-03-09 00:58:37 --> Helper loaded: url_helper
INFO - 2020-03-09 00:58:37 --> Helper loaded: string_helper
INFO - 2020-03-09 00:58:37 --> Database Driver Class Initialized
DEBUG - 2020-03-09 00:58:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 00:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 00:58:37 --> Controller Class Initialized
INFO - 2020-03-09 00:58:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 00:58:37 --> Pagination Class Initialized
INFO - 2020-03-09 00:58:37 --> Model "M_show" initialized
INFO - 2020-03-09 00:58:37 --> Helper loaded: form_helper
INFO - 2020-03-09 00:58:37 --> Form Validation Class Initialized
INFO - 2020-03-09 00:58:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 00:58:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 00:58:37 --> Final output sent to browser
DEBUG - 2020-03-09 00:58:37 --> Total execution time: 0.0823
INFO - 2020-03-09 00:58:49 --> Config Class Initialized
INFO - 2020-03-09 00:58:49 --> Hooks Class Initialized
DEBUG - 2020-03-09 00:58:49 --> UTF-8 Support Enabled
INFO - 2020-03-09 00:58:49 --> Utf8 Class Initialized
INFO - 2020-03-09 00:58:49 --> URI Class Initialized
INFO - 2020-03-09 00:58:49 --> Router Class Initialized
INFO - 2020-03-09 00:58:49 --> Output Class Initialized
INFO - 2020-03-09 00:58:49 --> Security Class Initialized
DEBUG - 2020-03-09 00:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 00:58:49 --> Input Class Initialized
INFO - 2020-03-09 00:58:49 --> Language Class Initialized
INFO - 2020-03-09 00:58:49 --> Loader Class Initialized
INFO - 2020-03-09 00:58:49 --> Helper loaded: url_helper
INFO - 2020-03-09 00:58:49 --> Helper loaded: string_helper
INFO - 2020-03-09 00:58:49 --> Database Driver Class Initialized
DEBUG - 2020-03-09 00:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 00:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 00:58:49 --> Controller Class Initialized
INFO - 2020-03-09 00:58:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 00:58:49 --> Pagination Class Initialized
INFO - 2020-03-09 00:58:49 --> Model "M_show" initialized
INFO - 2020-03-09 00:58:49 --> Helper loaded: form_helper
INFO - 2020-03-09 00:58:49 --> Form Validation Class Initialized
INFO - 2020-03-09 00:58:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 00:58:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 00:58:49 --> Final output sent to browser
DEBUG - 2020-03-09 00:58:49 --> Total execution time: 0.0083
INFO - 2020-03-09 00:58:50 --> Config Class Initialized
INFO - 2020-03-09 00:58:50 --> Hooks Class Initialized
DEBUG - 2020-03-09 00:58:50 --> UTF-8 Support Enabled
INFO - 2020-03-09 00:58:50 --> Utf8 Class Initialized
INFO - 2020-03-09 00:58:50 --> URI Class Initialized
INFO - 2020-03-09 00:58:50 --> Router Class Initialized
INFO - 2020-03-09 00:58:50 --> Output Class Initialized
INFO - 2020-03-09 00:58:50 --> Security Class Initialized
DEBUG - 2020-03-09 00:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 00:58:50 --> Input Class Initialized
INFO - 2020-03-09 00:58:50 --> Language Class Initialized
INFO - 2020-03-09 00:58:50 --> Loader Class Initialized
INFO - 2020-03-09 00:58:50 --> Helper loaded: url_helper
INFO - 2020-03-09 00:58:50 --> Helper loaded: string_helper
INFO - 2020-03-09 00:58:50 --> Database Driver Class Initialized
DEBUG - 2020-03-09 00:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 00:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 00:58:50 --> Controller Class Initialized
INFO - 2020-03-09 00:58:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 00:58:50 --> Pagination Class Initialized
INFO - 2020-03-09 00:58:50 --> Model "M_show" initialized
INFO - 2020-03-09 00:58:50 --> Helper loaded: form_helper
INFO - 2020-03-09 00:58:50 --> Form Validation Class Initialized
INFO - 2020-03-09 00:58:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 00:58:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 00:58:50 --> Final output sent to browser
DEBUG - 2020-03-09 00:58:50 --> Total execution time: 0.0064
INFO - 2020-03-09 00:58:51 --> Config Class Initialized
INFO - 2020-03-09 00:58:51 --> Hooks Class Initialized
DEBUG - 2020-03-09 00:58:51 --> UTF-8 Support Enabled
INFO - 2020-03-09 00:58:51 --> Utf8 Class Initialized
INFO - 2020-03-09 00:58:51 --> URI Class Initialized
INFO - 2020-03-09 00:58:51 --> Router Class Initialized
INFO - 2020-03-09 00:58:51 --> Output Class Initialized
INFO - 2020-03-09 00:58:51 --> Security Class Initialized
DEBUG - 2020-03-09 00:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 00:58:51 --> Input Class Initialized
INFO - 2020-03-09 00:58:51 --> Language Class Initialized
ERROR - 2020-03-09 00:58:51 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-09 00:59:00 --> Config Class Initialized
INFO - 2020-03-09 00:59:00 --> Hooks Class Initialized
DEBUG - 2020-03-09 00:59:00 --> UTF-8 Support Enabled
INFO - 2020-03-09 00:59:00 --> Utf8 Class Initialized
INFO - 2020-03-09 00:59:00 --> URI Class Initialized
DEBUG - 2020-03-09 00:59:00 --> No URI present. Default controller set.
INFO - 2020-03-09 00:59:00 --> Router Class Initialized
INFO - 2020-03-09 00:59:00 --> Output Class Initialized
INFO - 2020-03-09 00:59:00 --> Security Class Initialized
DEBUG - 2020-03-09 00:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 00:59:00 --> Input Class Initialized
INFO - 2020-03-09 00:59:00 --> Language Class Initialized
INFO - 2020-03-09 00:59:00 --> Loader Class Initialized
INFO - 2020-03-09 00:59:00 --> Helper loaded: url_helper
INFO - 2020-03-09 00:59:00 --> Helper loaded: string_helper
INFO - 2020-03-09 00:59:00 --> Database Driver Class Initialized
DEBUG - 2020-03-09 00:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 00:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 00:59:00 --> Controller Class Initialized
INFO - 2020-03-09 00:59:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 00:59:00 --> Pagination Class Initialized
INFO - 2020-03-09 00:59:00 --> Model "M_show" initialized
INFO - 2020-03-09 00:59:00 --> Helper loaded: form_helper
INFO - 2020-03-09 00:59:00 --> Form Validation Class Initialized
INFO - 2020-03-09 00:59:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 00:59:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 00:59:00 --> Final output sent to browser
DEBUG - 2020-03-09 00:59:00 --> Total execution time: 0.0054
INFO - 2020-03-09 00:59:01 --> Config Class Initialized
INFO - 2020-03-09 00:59:01 --> Hooks Class Initialized
DEBUG - 2020-03-09 00:59:01 --> UTF-8 Support Enabled
INFO - 2020-03-09 00:59:01 --> Utf8 Class Initialized
INFO - 2020-03-09 00:59:01 --> URI Class Initialized
INFO - 2020-03-09 00:59:01 --> Router Class Initialized
INFO - 2020-03-09 00:59:01 --> Output Class Initialized
INFO - 2020-03-09 00:59:01 --> Security Class Initialized
DEBUG - 2020-03-09 00:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 00:59:01 --> Input Class Initialized
INFO - 2020-03-09 00:59:01 --> Language Class Initialized
INFO - 2020-03-09 00:59:01 --> Loader Class Initialized
INFO - 2020-03-09 00:59:01 --> Helper loaded: url_helper
INFO - 2020-03-09 00:59:01 --> Helper loaded: string_helper
INFO - 2020-03-09 00:59:01 --> Database Driver Class Initialized
DEBUG - 2020-03-09 00:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 00:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 00:59:01 --> Controller Class Initialized
INFO - 2020-03-09 00:59:01 --> Model "M_tiket" initialized
INFO - 2020-03-09 00:59:01 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 00:59:01 --> Model "M_pesan" initialized
INFO - 2020-03-09 00:59:01 --> Helper loaded: form_helper
INFO - 2020-03-09 00:59:01 --> Form Validation Class Initialized
INFO - 2020-03-09 00:59:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-09 00:59:01 --> Final output sent to browser
DEBUG - 2020-03-09 00:59:01 --> Total execution time: 0.0292
INFO - 2020-03-09 00:59:22 --> Config Class Initialized
INFO - 2020-03-09 00:59:22 --> Hooks Class Initialized
DEBUG - 2020-03-09 00:59:22 --> UTF-8 Support Enabled
INFO - 2020-03-09 00:59:22 --> Utf8 Class Initialized
INFO - 2020-03-09 00:59:22 --> URI Class Initialized
INFO - 2020-03-09 00:59:22 --> Router Class Initialized
INFO - 2020-03-09 00:59:22 --> Output Class Initialized
INFO - 2020-03-09 00:59:22 --> Security Class Initialized
DEBUG - 2020-03-09 00:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 00:59:22 --> Input Class Initialized
INFO - 2020-03-09 00:59:22 --> Language Class Initialized
INFO - 2020-03-09 00:59:22 --> Loader Class Initialized
INFO - 2020-03-09 00:59:22 --> Helper loaded: url_helper
INFO - 2020-03-09 00:59:22 --> Helper loaded: string_helper
INFO - 2020-03-09 00:59:22 --> Database Driver Class Initialized
DEBUG - 2020-03-09 00:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 00:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 00:59:22 --> Controller Class Initialized
INFO - 2020-03-09 00:59:22 --> Model "M_tiket" initialized
INFO - 2020-03-09 00:59:22 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 00:59:22 --> Model "M_pesan" initialized
INFO - 2020-03-09 00:59:22 --> Helper loaded: form_helper
INFO - 2020-03-09 00:59:22 --> Form Validation Class Initialized
INFO - 2020-03-09 00:59:22 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-09 00:59:22 --> Final output sent to browser
DEBUG - 2020-03-09 00:59:22 --> Total execution time: 0.0456
INFO - 2020-03-09 00:59:44 --> Config Class Initialized
INFO - 2020-03-09 00:59:44 --> Hooks Class Initialized
DEBUG - 2020-03-09 00:59:44 --> UTF-8 Support Enabled
INFO - 2020-03-09 00:59:44 --> Utf8 Class Initialized
INFO - 2020-03-09 00:59:44 --> URI Class Initialized
DEBUG - 2020-03-09 00:59:44 --> No URI present. Default controller set.
INFO - 2020-03-09 00:59:44 --> Router Class Initialized
INFO - 2020-03-09 00:59:44 --> Output Class Initialized
INFO - 2020-03-09 00:59:44 --> Security Class Initialized
DEBUG - 2020-03-09 00:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 00:59:44 --> Input Class Initialized
INFO - 2020-03-09 00:59:44 --> Language Class Initialized
INFO - 2020-03-09 00:59:44 --> Loader Class Initialized
INFO - 2020-03-09 00:59:44 --> Helper loaded: url_helper
INFO - 2020-03-09 00:59:44 --> Helper loaded: string_helper
INFO - 2020-03-09 00:59:44 --> Database Driver Class Initialized
DEBUG - 2020-03-09 00:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 00:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 00:59:44 --> Controller Class Initialized
INFO - 2020-03-09 00:59:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 00:59:44 --> Pagination Class Initialized
INFO - 2020-03-09 00:59:44 --> Model "M_show" initialized
INFO - 2020-03-09 00:59:44 --> Helper loaded: form_helper
INFO - 2020-03-09 00:59:44 --> Form Validation Class Initialized
INFO - 2020-03-09 00:59:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 00:59:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 00:59:44 --> Final output sent to browser
DEBUG - 2020-03-09 00:59:44 --> Total execution time: 0.0051
INFO - 2020-03-09 00:59:57 --> Config Class Initialized
INFO - 2020-03-09 00:59:57 --> Hooks Class Initialized
DEBUG - 2020-03-09 00:59:57 --> UTF-8 Support Enabled
INFO - 2020-03-09 00:59:57 --> Utf8 Class Initialized
INFO - 2020-03-09 00:59:57 --> URI Class Initialized
INFO - 2020-03-09 00:59:57 --> Router Class Initialized
INFO - 2020-03-09 00:59:57 --> Output Class Initialized
INFO - 2020-03-09 00:59:57 --> Security Class Initialized
DEBUG - 2020-03-09 00:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 00:59:57 --> Input Class Initialized
INFO - 2020-03-09 00:59:57 --> Language Class Initialized
INFO - 2020-03-09 00:59:57 --> Loader Class Initialized
INFO - 2020-03-09 00:59:57 --> Helper loaded: url_helper
INFO - 2020-03-09 00:59:57 --> Helper loaded: string_helper
INFO - 2020-03-09 00:59:57 --> Database Driver Class Initialized
DEBUG - 2020-03-09 00:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 00:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 00:59:57 --> Controller Class Initialized
INFO - 2020-03-09 00:59:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 00:59:57 --> Pagination Class Initialized
INFO - 2020-03-09 00:59:57 --> Model "M_show" initialized
INFO - 2020-03-09 00:59:57 --> Helper loaded: form_helper
INFO - 2020-03-09 00:59:57 --> Form Validation Class Initialized
INFO - 2020-03-09 00:59:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 00:59:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 00:59:57 --> Final output sent to browser
DEBUG - 2020-03-09 00:59:57 --> Total execution time: 0.0074
INFO - 2020-03-09 00:59:59 --> Config Class Initialized
INFO - 2020-03-09 00:59:59 --> Hooks Class Initialized
DEBUG - 2020-03-09 00:59:59 --> UTF-8 Support Enabled
INFO - 2020-03-09 00:59:59 --> Utf8 Class Initialized
INFO - 2020-03-09 00:59:59 --> URI Class Initialized
INFO - 2020-03-09 00:59:59 --> Router Class Initialized
INFO - 2020-03-09 00:59:59 --> Output Class Initialized
INFO - 2020-03-09 00:59:59 --> Security Class Initialized
DEBUG - 2020-03-09 00:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 00:59:59 --> Input Class Initialized
INFO - 2020-03-09 00:59:59 --> Language Class Initialized
INFO - 2020-03-09 00:59:59 --> Loader Class Initialized
INFO - 2020-03-09 00:59:59 --> Helper loaded: url_helper
INFO - 2020-03-09 00:59:59 --> Helper loaded: string_helper
INFO - 2020-03-09 00:59:59 --> Database Driver Class Initialized
DEBUG - 2020-03-09 00:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 00:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 00:59:59 --> Controller Class Initialized
INFO - 2020-03-09 00:59:59 --> Model "M_tiket" initialized
INFO - 2020-03-09 00:59:59 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 00:59:59 --> Model "M_pesan" initialized
INFO - 2020-03-09 00:59:59 --> Helper loaded: form_helper
INFO - 2020-03-09 00:59:59 --> Form Validation Class Initialized
INFO - 2020-03-09 00:59:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-09 00:59:59 --> Final output sent to browser
DEBUG - 2020-03-09 00:59:59 --> Total execution time: 0.0068
INFO - 2020-03-09 01:00:09 --> Config Class Initialized
INFO - 2020-03-09 01:00:09 --> Hooks Class Initialized
DEBUG - 2020-03-09 01:00:09 --> UTF-8 Support Enabled
INFO - 2020-03-09 01:00:09 --> Utf8 Class Initialized
INFO - 2020-03-09 01:00:09 --> URI Class Initialized
INFO - 2020-03-09 01:00:09 --> Router Class Initialized
INFO - 2020-03-09 01:00:09 --> Output Class Initialized
INFO - 2020-03-09 01:00:09 --> Security Class Initialized
DEBUG - 2020-03-09 01:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 01:00:09 --> Input Class Initialized
INFO - 2020-03-09 01:00:09 --> Language Class Initialized
INFO - 2020-03-09 01:00:09 --> Loader Class Initialized
INFO - 2020-03-09 01:00:09 --> Helper loaded: url_helper
INFO - 2020-03-09 01:00:09 --> Helper loaded: string_helper
INFO - 2020-03-09 01:00:09 --> Database Driver Class Initialized
DEBUG - 2020-03-09 01:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 01:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 01:00:09 --> Controller Class Initialized
INFO - 2020-03-09 01:00:09 --> Model "M_tiket" initialized
INFO - 2020-03-09 01:00:09 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 01:00:09 --> Model "M_pesan" initialized
INFO - 2020-03-09 01:00:09 --> Helper loaded: form_helper
INFO - 2020-03-09 01:00:09 --> Form Validation Class Initialized
INFO - 2020-03-09 01:00:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-09 01:00:09 --> Final output sent to browser
DEBUG - 2020-03-09 01:00:09 --> Total execution time: 0.0064
INFO - 2020-03-09 01:01:07 --> Config Class Initialized
INFO - 2020-03-09 01:01:07 --> Hooks Class Initialized
DEBUG - 2020-03-09 01:01:07 --> UTF-8 Support Enabled
INFO - 2020-03-09 01:01:07 --> Utf8 Class Initialized
INFO - 2020-03-09 01:01:07 --> URI Class Initialized
DEBUG - 2020-03-09 01:01:07 --> No URI present. Default controller set.
INFO - 2020-03-09 01:01:07 --> Router Class Initialized
INFO - 2020-03-09 01:01:07 --> Output Class Initialized
INFO - 2020-03-09 01:01:07 --> Security Class Initialized
DEBUG - 2020-03-09 01:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 01:01:07 --> Input Class Initialized
INFO - 2020-03-09 01:01:07 --> Language Class Initialized
INFO - 2020-03-09 01:01:07 --> Loader Class Initialized
INFO - 2020-03-09 01:01:07 --> Helper loaded: url_helper
INFO - 2020-03-09 01:01:07 --> Helper loaded: string_helper
INFO - 2020-03-09 01:01:07 --> Database Driver Class Initialized
DEBUG - 2020-03-09 01:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 01:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 01:01:07 --> Controller Class Initialized
INFO - 2020-03-09 01:01:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 01:01:07 --> Pagination Class Initialized
INFO - 2020-03-09 01:01:07 --> Model "M_show" initialized
INFO - 2020-03-09 01:01:07 --> Helper loaded: form_helper
INFO - 2020-03-09 01:01:07 --> Form Validation Class Initialized
INFO - 2020-03-09 01:01:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 01:01:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 01:01:07 --> Final output sent to browser
DEBUG - 2020-03-09 01:01:07 --> Total execution time: 0.0062
INFO - 2020-03-09 01:01:08 --> Config Class Initialized
INFO - 2020-03-09 01:01:08 --> Hooks Class Initialized
DEBUG - 2020-03-09 01:01:08 --> UTF-8 Support Enabled
INFO - 2020-03-09 01:01:08 --> Utf8 Class Initialized
INFO - 2020-03-09 01:01:08 --> URI Class Initialized
DEBUG - 2020-03-09 01:01:08 --> No URI present. Default controller set.
INFO - 2020-03-09 01:01:08 --> Router Class Initialized
INFO - 2020-03-09 01:01:08 --> Output Class Initialized
INFO - 2020-03-09 01:01:08 --> Security Class Initialized
DEBUG - 2020-03-09 01:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 01:01:08 --> Input Class Initialized
INFO - 2020-03-09 01:01:08 --> Language Class Initialized
INFO - 2020-03-09 01:01:08 --> Loader Class Initialized
INFO - 2020-03-09 01:01:08 --> Helper loaded: url_helper
INFO - 2020-03-09 01:01:08 --> Helper loaded: string_helper
INFO - 2020-03-09 01:01:08 --> Database Driver Class Initialized
DEBUG - 2020-03-09 01:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 01:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 01:01:08 --> Controller Class Initialized
INFO - 2020-03-09 01:01:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 01:01:08 --> Pagination Class Initialized
INFO - 2020-03-09 01:01:08 --> Model "M_show" initialized
INFO - 2020-03-09 01:01:08 --> Helper loaded: form_helper
INFO - 2020-03-09 01:01:08 --> Form Validation Class Initialized
INFO - 2020-03-09 01:01:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 01:01:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 01:01:08 --> Final output sent to browser
DEBUG - 2020-03-09 01:01:08 --> Total execution time: 0.0058
INFO - 2020-03-09 01:01:52 --> Config Class Initialized
INFO - 2020-03-09 01:01:52 --> Hooks Class Initialized
DEBUG - 2020-03-09 01:01:52 --> UTF-8 Support Enabled
INFO - 2020-03-09 01:01:52 --> Utf8 Class Initialized
INFO - 2020-03-09 01:01:52 --> URI Class Initialized
INFO - 2020-03-09 01:01:52 --> Router Class Initialized
INFO - 2020-03-09 01:01:52 --> Output Class Initialized
INFO - 2020-03-09 01:01:52 --> Security Class Initialized
DEBUG - 2020-03-09 01:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 01:01:52 --> Input Class Initialized
INFO - 2020-03-09 01:01:52 --> Language Class Initialized
INFO - 2020-03-09 01:01:52 --> Loader Class Initialized
INFO - 2020-03-09 01:01:52 --> Helper loaded: url_helper
INFO - 2020-03-09 01:01:52 --> Helper loaded: string_helper
INFO - 2020-03-09 01:01:52 --> Database Driver Class Initialized
DEBUG - 2020-03-09 01:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 01:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 01:01:52 --> Controller Class Initialized
INFO - 2020-03-09 01:01:52 --> Model "M_tiket" initialized
INFO - 2020-03-09 01:01:52 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 01:01:52 --> Model "M_pesan" initialized
INFO - 2020-03-09 01:01:52 --> Helper loaded: form_helper
INFO - 2020-03-09 01:01:52 --> Form Validation Class Initialized
DEBUG - 2020-03-09 01:01:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-09 01:01:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-09 08:01:52 --> Final output sent to browser
DEBUG - 2020-03-09 08:01:52 --> Total execution time: 0.1534
INFO - 2020-03-09 01:01:54 --> Config Class Initialized
INFO - 2020-03-09 01:01:54 --> Hooks Class Initialized
DEBUG - 2020-03-09 01:01:54 --> UTF-8 Support Enabled
INFO - 2020-03-09 01:01:54 --> Utf8 Class Initialized
INFO - 2020-03-09 01:01:54 --> URI Class Initialized
INFO - 2020-03-09 01:01:54 --> Router Class Initialized
INFO - 2020-03-09 01:01:54 --> Output Class Initialized
INFO - 2020-03-09 01:01:54 --> Security Class Initialized
DEBUG - 2020-03-09 01:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 01:01:54 --> Input Class Initialized
INFO - 2020-03-09 01:01:54 --> Language Class Initialized
INFO - 2020-03-09 01:01:54 --> Loader Class Initialized
INFO - 2020-03-09 01:01:54 --> Helper loaded: url_helper
INFO - 2020-03-09 01:01:54 --> Helper loaded: string_helper
INFO - 2020-03-09 01:01:54 --> Database Driver Class Initialized
DEBUG - 2020-03-09 01:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 01:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 01:01:54 --> Controller Class Initialized
INFO - 2020-03-09 01:01:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 01:01:54 --> Pagination Class Initialized
INFO - 2020-03-09 01:01:54 --> Model "M_show" initialized
INFO - 2020-03-09 01:01:54 --> Helper loaded: form_helper
INFO - 2020-03-09 01:01:54 --> Form Validation Class Initialized
INFO - 2020-03-09 01:01:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 01:01:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 01:01:54 --> Final output sent to browser
DEBUG - 2020-03-09 01:01:54 --> Total execution time: 0.0072
INFO - 2020-03-09 01:04:42 --> Config Class Initialized
INFO - 2020-03-09 01:04:42 --> Hooks Class Initialized
DEBUG - 2020-03-09 01:04:42 --> UTF-8 Support Enabled
INFO - 2020-03-09 01:04:42 --> Utf8 Class Initialized
INFO - 2020-03-09 01:04:42 --> URI Class Initialized
INFO - 2020-03-09 01:04:42 --> Router Class Initialized
INFO - 2020-03-09 01:04:42 --> Output Class Initialized
INFO - 2020-03-09 01:04:42 --> Security Class Initialized
DEBUG - 2020-03-09 01:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 01:04:42 --> Input Class Initialized
INFO - 2020-03-09 01:04:42 --> Language Class Initialized
INFO - 2020-03-09 01:04:42 --> Loader Class Initialized
INFO - 2020-03-09 01:04:42 --> Helper loaded: url_helper
INFO - 2020-03-09 01:04:42 --> Helper loaded: string_helper
INFO - 2020-03-09 01:04:42 --> Database Driver Class Initialized
DEBUG - 2020-03-09 01:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 01:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 01:04:42 --> Controller Class Initialized
INFO - 2020-03-09 01:04:42 --> Model "M_tiket" initialized
INFO - 2020-03-09 01:04:42 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 01:04:42 --> Model "M_pesan" initialized
INFO - 2020-03-09 01:04:42 --> Helper loaded: form_helper
INFO - 2020-03-09 01:04:42 --> Form Validation Class Initialized
INFO - 2020-03-09 01:04:42 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-09 01:04:42 --> Final output sent to browser
DEBUG - 2020-03-09 01:04:42 --> Total execution time: 0.0579
INFO - 2020-03-09 01:10:00 --> Config Class Initialized
INFO - 2020-03-09 01:10:00 --> Hooks Class Initialized
DEBUG - 2020-03-09 01:10:00 --> UTF-8 Support Enabled
INFO - 2020-03-09 01:10:00 --> Utf8 Class Initialized
INFO - 2020-03-09 01:10:00 --> URI Class Initialized
INFO - 2020-03-09 01:10:00 --> Router Class Initialized
INFO - 2020-03-09 01:10:00 --> Output Class Initialized
INFO - 2020-03-09 01:10:00 --> Security Class Initialized
DEBUG - 2020-03-09 01:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 01:10:00 --> Input Class Initialized
INFO - 2020-03-09 01:10:00 --> Language Class Initialized
INFO - 2020-03-09 01:10:00 --> Loader Class Initialized
INFO - 2020-03-09 01:10:00 --> Helper loaded: url_helper
INFO - 2020-03-09 01:10:00 --> Helper loaded: string_helper
INFO - 2020-03-09 01:10:00 --> Database Driver Class Initialized
DEBUG - 2020-03-09 01:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 01:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 01:10:00 --> Controller Class Initialized
INFO - 2020-03-09 01:10:00 --> Model "M_tiket" initialized
INFO - 2020-03-09 01:10:00 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 01:10:00 --> Model "M_pesan" initialized
INFO - 2020-03-09 01:10:00 --> Helper loaded: form_helper
INFO - 2020-03-09 01:10:00 --> Form Validation Class Initialized
INFO - 2020-03-09 01:10:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-09 01:10:00 --> Final output sent to browser
DEBUG - 2020-03-09 01:10:00 --> Total execution time: 0.0446
INFO - 2020-03-09 01:10:27 --> Config Class Initialized
INFO - 2020-03-09 01:10:27 --> Hooks Class Initialized
DEBUG - 2020-03-09 01:10:27 --> UTF-8 Support Enabled
INFO - 2020-03-09 01:10:27 --> Utf8 Class Initialized
INFO - 2020-03-09 01:10:27 --> URI Class Initialized
INFO - 2020-03-09 01:10:27 --> Router Class Initialized
INFO - 2020-03-09 01:10:27 --> Output Class Initialized
INFO - 2020-03-09 01:10:27 --> Security Class Initialized
DEBUG - 2020-03-09 01:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 01:10:27 --> Input Class Initialized
INFO - 2020-03-09 01:10:27 --> Language Class Initialized
INFO - 2020-03-09 01:10:27 --> Loader Class Initialized
INFO - 2020-03-09 01:10:27 --> Helper loaded: url_helper
INFO - 2020-03-09 01:10:27 --> Helper loaded: string_helper
INFO - 2020-03-09 01:10:27 --> Database Driver Class Initialized
DEBUG - 2020-03-09 01:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 01:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 01:10:27 --> Controller Class Initialized
INFO - 2020-03-09 01:10:27 --> Model "M_tiket" initialized
INFO - 2020-03-09 01:10:27 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 01:10:27 --> Model "M_pesan" initialized
INFO - 2020-03-09 01:10:27 --> Helper loaded: form_helper
INFO - 2020-03-09 01:10:27 --> Form Validation Class Initialized
INFO - 2020-03-09 08:10:27 --> Upload Class Initialized
INFO - 2020-03-09 01:10:28 --> Config Class Initialized
INFO - 2020-03-09 01:10:28 --> Hooks Class Initialized
DEBUG - 2020-03-09 01:10:28 --> UTF-8 Support Enabled
INFO - 2020-03-09 01:10:28 --> Utf8 Class Initialized
INFO - 2020-03-09 01:10:28 --> URI Class Initialized
INFO - 2020-03-09 01:10:28 --> Router Class Initialized
INFO - 2020-03-09 01:10:28 --> Output Class Initialized
INFO - 2020-03-09 01:10:28 --> Security Class Initialized
DEBUG - 2020-03-09 01:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 01:10:28 --> Input Class Initialized
INFO - 2020-03-09 01:10:28 --> Language Class Initialized
INFO - 2020-03-09 01:10:28 --> Loader Class Initialized
INFO - 2020-03-09 01:10:28 --> Helper loaded: url_helper
INFO - 2020-03-09 01:10:28 --> Helper loaded: string_helper
INFO - 2020-03-09 01:10:28 --> Database Driver Class Initialized
DEBUG - 2020-03-09 01:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 01:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 01:10:28 --> Controller Class Initialized
INFO - 2020-03-09 01:10:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 01:10:28 --> Pagination Class Initialized
INFO - 2020-03-09 01:10:28 --> Model "M_show" initialized
INFO - 2020-03-09 01:10:28 --> Helper loaded: form_helper
INFO - 2020-03-09 01:10:28 --> Form Validation Class Initialized
INFO - 2020-03-09 01:10:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 01:10:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 01:10:28 --> Final output sent to browser
DEBUG - 2020-03-09 01:10:28 --> Total execution time: 0.0110
INFO - 2020-03-09 01:13:55 --> Config Class Initialized
INFO - 2020-03-09 01:13:55 --> Hooks Class Initialized
DEBUG - 2020-03-09 01:13:55 --> UTF-8 Support Enabled
INFO - 2020-03-09 01:13:55 --> Utf8 Class Initialized
INFO - 2020-03-09 01:13:55 --> URI Class Initialized
INFO - 2020-03-09 01:13:55 --> Router Class Initialized
INFO - 2020-03-09 01:13:55 --> Output Class Initialized
INFO - 2020-03-09 01:13:55 --> Security Class Initialized
DEBUG - 2020-03-09 01:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 01:13:55 --> Input Class Initialized
INFO - 2020-03-09 01:13:55 --> Language Class Initialized
INFO - 2020-03-09 01:13:55 --> Loader Class Initialized
INFO - 2020-03-09 01:13:55 --> Helper loaded: url_helper
INFO - 2020-03-09 01:13:55 --> Helper loaded: string_helper
INFO - 2020-03-09 01:13:55 --> Database Driver Class Initialized
DEBUG - 2020-03-09 01:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 01:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 01:13:55 --> Controller Class Initialized
INFO - 2020-03-09 01:13:55 --> Model "M_tiket" initialized
INFO - 2020-03-09 01:13:55 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 01:13:55 --> Model "M_pesan" initialized
INFO - 2020-03-09 01:13:55 --> Helper loaded: form_helper
INFO - 2020-03-09 01:13:55 --> Form Validation Class Initialized
INFO - 2020-03-09 08:13:55 --> Upload Class Initialized
INFO - 2020-03-09 01:13:56 --> Config Class Initialized
INFO - 2020-03-09 01:13:56 --> Hooks Class Initialized
DEBUG - 2020-03-09 01:13:56 --> UTF-8 Support Enabled
INFO - 2020-03-09 01:13:56 --> Utf8 Class Initialized
INFO - 2020-03-09 01:13:56 --> URI Class Initialized
INFO - 2020-03-09 01:13:56 --> Router Class Initialized
INFO - 2020-03-09 01:13:56 --> Output Class Initialized
INFO - 2020-03-09 01:13:56 --> Security Class Initialized
DEBUG - 2020-03-09 01:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 01:13:56 --> Input Class Initialized
INFO - 2020-03-09 01:13:56 --> Language Class Initialized
INFO - 2020-03-09 01:13:56 --> Loader Class Initialized
INFO - 2020-03-09 01:13:56 --> Helper loaded: url_helper
INFO - 2020-03-09 01:13:56 --> Helper loaded: string_helper
INFO - 2020-03-09 01:13:56 --> Database Driver Class Initialized
DEBUG - 2020-03-09 01:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 01:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 01:13:56 --> Controller Class Initialized
INFO - 2020-03-09 01:13:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 01:13:56 --> Pagination Class Initialized
INFO - 2020-03-09 01:13:56 --> Model "M_show" initialized
INFO - 2020-03-09 01:13:56 --> Helper loaded: form_helper
INFO - 2020-03-09 01:13:56 --> Form Validation Class Initialized
INFO - 2020-03-09 01:13:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 01:13:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 01:13:56 --> Final output sent to browser
DEBUG - 2020-03-09 01:13:56 --> Total execution time: 0.0091
INFO - 2020-03-09 01:14:28 --> Config Class Initialized
INFO - 2020-03-09 01:14:28 --> Hooks Class Initialized
DEBUG - 2020-03-09 01:14:28 --> UTF-8 Support Enabled
INFO - 2020-03-09 01:14:28 --> Utf8 Class Initialized
INFO - 2020-03-09 01:14:28 --> URI Class Initialized
INFO - 2020-03-09 01:14:28 --> Router Class Initialized
INFO - 2020-03-09 01:14:28 --> Output Class Initialized
INFO - 2020-03-09 01:14:28 --> Security Class Initialized
DEBUG - 2020-03-09 01:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 01:14:28 --> Input Class Initialized
INFO - 2020-03-09 01:14:28 --> Language Class Initialized
INFO - 2020-03-09 01:14:28 --> Loader Class Initialized
INFO - 2020-03-09 01:14:28 --> Helper loaded: url_helper
INFO - 2020-03-09 01:14:28 --> Helper loaded: string_helper
INFO - 2020-03-09 01:14:28 --> Database Driver Class Initialized
DEBUG - 2020-03-09 01:14:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 01:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 01:14:28 --> Controller Class Initialized
INFO - 2020-03-09 01:14:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 01:14:28 --> Pagination Class Initialized
INFO - 2020-03-09 01:14:28 --> Model "M_show" initialized
INFO - 2020-03-09 01:14:28 --> Helper loaded: form_helper
INFO - 2020-03-09 01:14:28 --> Form Validation Class Initialized
INFO - 2020-03-09 01:14:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 01:14:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 01:14:28 --> Final output sent to browser
DEBUG - 2020-03-09 01:14:28 --> Total execution time: 0.0059
INFO - 2020-03-09 01:14:32 --> Config Class Initialized
INFO - 2020-03-09 01:14:32 --> Hooks Class Initialized
DEBUG - 2020-03-09 01:14:32 --> UTF-8 Support Enabled
INFO - 2020-03-09 01:14:32 --> Utf8 Class Initialized
INFO - 2020-03-09 01:14:32 --> URI Class Initialized
INFO - 2020-03-09 01:14:32 --> Router Class Initialized
INFO - 2020-03-09 01:14:32 --> Output Class Initialized
INFO - 2020-03-09 01:14:32 --> Security Class Initialized
DEBUG - 2020-03-09 01:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 01:14:32 --> Input Class Initialized
INFO - 2020-03-09 01:14:32 --> Language Class Initialized
INFO - 2020-03-09 01:14:32 --> Loader Class Initialized
INFO - 2020-03-09 01:14:32 --> Helper loaded: url_helper
INFO - 2020-03-09 01:14:32 --> Helper loaded: string_helper
INFO - 2020-03-09 01:14:32 --> Database Driver Class Initialized
DEBUG - 2020-03-09 01:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 01:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 01:14:32 --> Controller Class Initialized
INFO - 2020-03-09 01:14:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 01:14:32 --> Pagination Class Initialized
INFO - 2020-03-09 01:14:32 --> Model "M_show" initialized
INFO - 2020-03-09 01:14:32 --> Helper loaded: form_helper
INFO - 2020-03-09 01:14:32 --> Form Validation Class Initialized
INFO - 2020-03-09 01:14:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 01:14:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-09 01:14:32 --> Final output sent to browser
DEBUG - 2020-03-09 01:14:32 --> Total execution time: 0.0201
INFO - 2020-03-09 01:14:46 --> Config Class Initialized
INFO - 2020-03-09 01:14:46 --> Hooks Class Initialized
DEBUG - 2020-03-09 01:14:46 --> UTF-8 Support Enabled
INFO - 2020-03-09 01:14:46 --> Utf8 Class Initialized
INFO - 2020-03-09 01:14:46 --> URI Class Initialized
INFO - 2020-03-09 01:14:46 --> Router Class Initialized
INFO - 2020-03-09 01:14:46 --> Output Class Initialized
INFO - 2020-03-09 01:14:46 --> Security Class Initialized
DEBUG - 2020-03-09 01:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 01:14:46 --> Input Class Initialized
INFO - 2020-03-09 01:14:46 --> Language Class Initialized
INFO - 2020-03-09 01:14:46 --> Loader Class Initialized
INFO - 2020-03-09 01:14:46 --> Helper loaded: url_helper
INFO - 2020-03-09 01:14:46 --> Helper loaded: string_helper
INFO - 2020-03-09 01:14:46 --> Database Driver Class Initialized
DEBUG - 2020-03-09 01:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 01:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 01:14:46 --> Controller Class Initialized
INFO - 2020-03-09 01:14:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 01:14:46 --> Pagination Class Initialized
INFO - 2020-03-09 01:14:46 --> Model "M_show" initialized
INFO - 2020-03-09 01:14:46 --> Helper loaded: form_helper
INFO - 2020-03-09 01:14:46 --> Form Validation Class Initialized
INFO - 2020-03-09 01:14:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 01:14:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/hub.php
INFO - 2020-03-09 01:14:46 --> Final output sent to browser
DEBUG - 2020-03-09 01:14:46 --> Total execution time: 0.0167
INFO - 2020-03-09 01:17:33 --> Config Class Initialized
INFO - 2020-03-09 01:17:33 --> Hooks Class Initialized
DEBUG - 2020-03-09 01:17:33 --> UTF-8 Support Enabled
INFO - 2020-03-09 01:17:33 --> Utf8 Class Initialized
INFO - 2020-03-09 01:17:33 --> URI Class Initialized
INFO - 2020-03-09 01:17:33 --> Router Class Initialized
INFO - 2020-03-09 01:17:33 --> Output Class Initialized
INFO - 2020-03-09 01:17:33 --> Security Class Initialized
DEBUG - 2020-03-09 01:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 01:17:33 --> Input Class Initialized
INFO - 2020-03-09 01:17:33 --> Language Class Initialized
INFO - 2020-03-09 01:17:33 --> Loader Class Initialized
INFO - 2020-03-09 01:17:33 --> Helper loaded: url_helper
INFO - 2020-03-09 01:17:33 --> Helper loaded: string_helper
INFO - 2020-03-09 01:17:33 --> Database Driver Class Initialized
DEBUG - 2020-03-09 01:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 01:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 01:17:33 --> Controller Class Initialized
INFO - 2020-03-09 01:17:33 --> Model "M_tiket" initialized
INFO - 2020-03-09 01:17:33 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 01:17:33 --> Model "M_pesan" initialized
INFO - 2020-03-09 01:17:33 --> Helper loaded: form_helper
INFO - 2020-03-09 01:17:33 --> Form Validation Class Initialized
INFO - 2020-03-09 01:17:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-09 01:17:33 --> Final output sent to browser
DEBUG - 2020-03-09 01:17:33 --> Total execution time: 0.0578
INFO - 2020-03-09 01:17:42 --> Config Class Initialized
INFO - 2020-03-09 01:17:42 --> Hooks Class Initialized
DEBUG - 2020-03-09 01:17:42 --> UTF-8 Support Enabled
INFO - 2020-03-09 01:17:42 --> Utf8 Class Initialized
INFO - 2020-03-09 01:17:42 --> URI Class Initialized
INFO - 2020-03-09 01:17:42 --> Router Class Initialized
INFO - 2020-03-09 01:17:42 --> Output Class Initialized
INFO - 2020-03-09 01:17:42 --> Security Class Initialized
DEBUG - 2020-03-09 01:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 01:17:42 --> Input Class Initialized
INFO - 2020-03-09 01:17:42 --> Language Class Initialized
INFO - 2020-03-09 01:17:42 --> Loader Class Initialized
INFO - 2020-03-09 01:17:42 --> Helper loaded: url_helper
INFO - 2020-03-09 01:17:42 --> Helper loaded: string_helper
INFO - 2020-03-09 01:17:42 --> Database Driver Class Initialized
DEBUG - 2020-03-09 01:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 01:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 01:17:42 --> Controller Class Initialized
INFO - 2020-03-09 01:17:42 --> Model "M_tiket" initialized
INFO - 2020-03-09 01:17:42 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 01:17:42 --> Model "M_pesan" initialized
INFO - 2020-03-09 01:17:42 --> Helper loaded: form_helper
INFO - 2020-03-09 01:17:42 --> Form Validation Class Initialized
INFO - 2020-03-09 01:17:42 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-09 01:17:42 --> Final output sent to browser
DEBUG - 2020-03-09 01:17:42 --> Total execution time: 0.0071
INFO - 2020-03-09 01:17:48 --> Config Class Initialized
INFO - 2020-03-09 01:17:48 --> Hooks Class Initialized
DEBUG - 2020-03-09 01:17:48 --> UTF-8 Support Enabled
INFO - 2020-03-09 01:17:48 --> Utf8 Class Initialized
INFO - 2020-03-09 01:17:48 --> URI Class Initialized
INFO - 2020-03-09 01:17:48 --> Router Class Initialized
INFO - 2020-03-09 01:17:48 --> Output Class Initialized
INFO - 2020-03-09 01:17:48 --> Security Class Initialized
DEBUG - 2020-03-09 01:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 01:17:48 --> Input Class Initialized
INFO - 2020-03-09 01:17:48 --> Language Class Initialized
INFO - 2020-03-09 01:17:48 --> Loader Class Initialized
INFO - 2020-03-09 01:17:48 --> Helper loaded: url_helper
INFO - 2020-03-09 01:17:48 --> Helper loaded: string_helper
INFO - 2020-03-09 01:17:48 --> Database Driver Class Initialized
DEBUG - 2020-03-09 01:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 01:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 01:17:48 --> Controller Class Initialized
INFO - 2020-03-09 01:17:48 --> Model "M_tiket" initialized
INFO - 2020-03-09 01:17:48 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 01:17:48 --> Model "M_pesan" initialized
INFO - 2020-03-09 01:17:48 --> Helper loaded: form_helper
INFO - 2020-03-09 01:17:48 --> Form Validation Class Initialized
INFO - 2020-03-09 01:17:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-09 01:17:48 --> Final output sent to browser
DEBUG - 2020-03-09 01:17:48 --> Total execution time: 0.0078
INFO - 2020-03-09 01:24:03 --> Config Class Initialized
INFO - 2020-03-09 01:24:03 --> Hooks Class Initialized
DEBUG - 2020-03-09 01:24:03 --> UTF-8 Support Enabled
INFO - 2020-03-09 01:24:03 --> Utf8 Class Initialized
INFO - 2020-03-09 01:24:03 --> URI Class Initialized
INFO - 2020-03-09 01:24:03 --> Router Class Initialized
INFO - 2020-03-09 01:24:03 --> Output Class Initialized
INFO - 2020-03-09 01:24:03 --> Security Class Initialized
DEBUG - 2020-03-09 01:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 01:24:03 --> Input Class Initialized
INFO - 2020-03-09 01:24:03 --> Language Class Initialized
INFO - 2020-03-09 01:24:03 --> Loader Class Initialized
INFO - 2020-03-09 01:24:03 --> Helper loaded: url_helper
INFO - 2020-03-09 01:24:03 --> Helper loaded: string_helper
INFO - 2020-03-09 01:24:03 --> Database Driver Class Initialized
DEBUG - 2020-03-09 01:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 01:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 01:24:03 --> Controller Class Initialized
INFO - 2020-03-09 01:24:03 --> Model "M_tiket" initialized
INFO - 2020-03-09 01:24:03 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 01:24:03 --> Model "M_pesan" initialized
INFO - 2020-03-09 01:24:03 --> Helper loaded: form_helper
INFO - 2020-03-09 01:24:03 --> Form Validation Class Initialized
INFO - 2020-03-09 01:24:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-09 01:24:03 --> Final output sent to browser
DEBUG - 2020-03-09 01:24:03 --> Total execution time: 0.0577
INFO - 2020-03-09 01:24:52 --> Config Class Initialized
INFO - 2020-03-09 01:24:52 --> Hooks Class Initialized
DEBUG - 2020-03-09 01:24:52 --> UTF-8 Support Enabled
INFO - 2020-03-09 01:24:52 --> Utf8 Class Initialized
INFO - 2020-03-09 01:24:52 --> URI Class Initialized
INFO - 2020-03-09 01:24:52 --> Router Class Initialized
INFO - 2020-03-09 01:24:52 --> Output Class Initialized
INFO - 2020-03-09 01:24:52 --> Security Class Initialized
DEBUG - 2020-03-09 01:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 01:24:52 --> Input Class Initialized
INFO - 2020-03-09 01:24:52 --> Language Class Initialized
INFO - 2020-03-09 01:24:52 --> Loader Class Initialized
INFO - 2020-03-09 01:24:52 --> Helper loaded: url_helper
INFO - 2020-03-09 01:24:52 --> Helper loaded: string_helper
INFO - 2020-03-09 01:24:52 --> Database Driver Class Initialized
DEBUG - 2020-03-09 01:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 01:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 01:24:52 --> Controller Class Initialized
INFO - 2020-03-09 01:24:52 --> Model "M_tiket" initialized
INFO - 2020-03-09 01:24:52 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 01:24:52 --> Model "M_pesan" initialized
INFO - 2020-03-09 01:24:52 --> Helper loaded: form_helper
INFO - 2020-03-09 01:24:52 --> Form Validation Class Initialized
INFO - 2020-03-09 01:24:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-09 01:24:52 --> Final output sent to browser
DEBUG - 2020-03-09 01:24:52 --> Total execution time: 0.0075
INFO - 2020-03-09 01:25:11 --> Config Class Initialized
INFO - 2020-03-09 01:25:11 --> Hooks Class Initialized
DEBUG - 2020-03-09 01:25:11 --> UTF-8 Support Enabled
INFO - 2020-03-09 01:25:11 --> Utf8 Class Initialized
INFO - 2020-03-09 01:25:11 --> URI Class Initialized
INFO - 2020-03-09 01:25:11 --> Router Class Initialized
INFO - 2020-03-09 01:25:11 --> Output Class Initialized
INFO - 2020-03-09 01:25:11 --> Security Class Initialized
DEBUG - 2020-03-09 01:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 01:25:11 --> Input Class Initialized
INFO - 2020-03-09 01:25:11 --> Language Class Initialized
INFO - 2020-03-09 01:25:11 --> Loader Class Initialized
INFO - 2020-03-09 01:25:11 --> Helper loaded: url_helper
INFO - 2020-03-09 01:25:11 --> Helper loaded: string_helper
INFO - 2020-03-09 01:25:11 --> Database Driver Class Initialized
DEBUG - 2020-03-09 01:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 01:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 01:25:11 --> Controller Class Initialized
INFO - 2020-03-09 01:25:11 --> Model "M_tiket" initialized
INFO - 2020-03-09 01:25:11 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 01:25:11 --> Model "M_pesan" initialized
INFO - 2020-03-09 01:25:11 --> Helper loaded: form_helper
INFO - 2020-03-09 01:25:11 --> Form Validation Class Initialized
INFO - 2020-03-09 08:25:11 --> Upload Class Initialized
INFO - 2020-03-09 01:25:12 --> Config Class Initialized
INFO - 2020-03-09 01:25:12 --> Hooks Class Initialized
DEBUG - 2020-03-09 01:25:12 --> UTF-8 Support Enabled
INFO - 2020-03-09 01:25:12 --> Utf8 Class Initialized
INFO - 2020-03-09 01:25:12 --> URI Class Initialized
INFO - 2020-03-09 01:25:12 --> Router Class Initialized
INFO - 2020-03-09 01:25:12 --> Output Class Initialized
INFO - 2020-03-09 01:25:12 --> Security Class Initialized
DEBUG - 2020-03-09 01:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 01:25:12 --> Input Class Initialized
INFO - 2020-03-09 01:25:12 --> Language Class Initialized
INFO - 2020-03-09 01:25:12 --> Loader Class Initialized
INFO - 2020-03-09 01:25:12 --> Helper loaded: url_helper
INFO - 2020-03-09 01:25:12 --> Helper loaded: string_helper
INFO - 2020-03-09 01:25:12 --> Database Driver Class Initialized
DEBUG - 2020-03-09 01:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 01:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 01:25:12 --> Controller Class Initialized
INFO - 2020-03-09 01:25:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 01:25:12 --> Pagination Class Initialized
INFO - 2020-03-09 01:25:12 --> Model "M_show" initialized
INFO - 2020-03-09 01:25:12 --> Helper loaded: form_helper
INFO - 2020-03-09 01:25:12 --> Form Validation Class Initialized
INFO - 2020-03-09 01:25:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 01:25:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 01:25:12 --> Final output sent to browser
DEBUG - 2020-03-09 01:25:12 --> Total execution time: 0.0092
INFO - 2020-03-09 01:25:13 --> Config Class Initialized
INFO - 2020-03-09 01:25:13 --> Hooks Class Initialized
DEBUG - 2020-03-09 01:25:13 --> UTF-8 Support Enabled
INFO - 2020-03-09 01:25:13 --> Utf8 Class Initialized
INFO - 2020-03-09 01:25:13 --> URI Class Initialized
INFO - 2020-03-09 01:25:13 --> Router Class Initialized
INFO - 2020-03-09 01:25:13 --> Output Class Initialized
INFO - 2020-03-09 01:25:13 --> Security Class Initialized
DEBUG - 2020-03-09 01:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 01:25:13 --> Input Class Initialized
INFO - 2020-03-09 01:25:13 --> Language Class Initialized
ERROR - 2020-03-09 01:25:13 --> 404 Page Not Found: Engine0/jquery.js
INFO - 2020-03-09 01:25:32 --> Config Class Initialized
INFO - 2020-03-09 01:25:32 --> Hooks Class Initialized
DEBUG - 2020-03-09 01:25:32 --> UTF-8 Support Enabled
INFO - 2020-03-09 01:25:32 --> Utf8 Class Initialized
INFO - 2020-03-09 01:25:32 --> URI Class Initialized
INFO - 2020-03-09 01:25:32 --> Router Class Initialized
INFO - 2020-03-09 01:25:32 --> Output Class Initialized
INFO - 2020-03-09 01:25:32 --> Security Class Initialized
DEBUG - 2020-03-09 01:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 01:25:32 --> Input Class Initialized
INFO - 2020-03-09 01:25:32 --> Language Class Initialized
INFO - 2020-03-09 01:25:32 --> Loader Class Initialized
INFO - 2020-03-09 01:25:32 --> Helper loaded: url_helper
INFO - 2020-03-09 01:25:32 --> Helper loaded: string_helper
INFO - 2020-03-09 01:25:32 --> Database Driver Class Initialized
DEBUG - 2020-03-09 01:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 01:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 01:25:32 --> Controller Class Initialized
INFO - 2020-03-09 01:25:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 01:25:32 --> Pagination Class Initialized
INFO - 2020-03-09 01:25:32 --> Model "M_show" initialized
INFO - 2020-03-09 01:25:32 --> Helper loaded: form_helper
INFO - 2020-03-09 01:25:32 --> Form Validation Class Initialized
INFO - 2020-03-09 01:25:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 01:25:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/gal.php
INFO - 2020-03-09 01:25:32 --> Final output sent to browser
DEBUG - 2020-03-09 01:25:32 --> Total execution time: 0.0149
INFO - 2020-03-09 01:25:33 --> Config Class Initialized
INFO - 2020-03-09 01:25:33 --> Hooks Class Initialized
DEBUG - 2020-03-09 01:25:33 --> UTF-8 Support Enabled
INFO - 2020-03-09 01:25:33 --> Utf8 Class Initialized
INFO - 2020-03-09 01:25:33 --> URI Class Initialized
INFO - 2020-03-09 01:25:33 --> Router Class Initialized
INFO - 2020-03-09 01:25:33 --> Output Class Initialized
INFO - 2020-03-09 01:25:33 --> Security Class Initialized
DEBUG - 2020-03-09 01:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 01:25:33 --> Input Class Initialized
INFO - 2020-03-09 01:25:33 --> Language Class Initialized
ERROR - 2020-03-09 01:25:33 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-09 01:44:30 --> Config Class Initialized
INFO - 2020-03-09 01:44:30 --> Hooks Class Initialized
DEBUG - 2020-03-09 01:44:30 --> UTF-8 Support Enabled
INFO - 2020-03-09 01:44:30 --> Utf8 Class Initialized
INFO - 2020-03-09 01:44:30 --> URI Class Initialized
DEBUG - 2020-03-09 01:44:30 --> No URI present. Default controller set.
INFO - 2020-03-09 01:44:30 --> Router Class Initialized
INFO - 2020-03-09 01:44:30 --> Output Class Initialized
INFO - 2020-03-09 01:44:30 --> Security Class Initialized
DEBUG - 2020-03-09 01:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 01:44:30 --> Input Class Initialized
INFO - 2020-03-09 01:44:30 --> Language Class Initialized
INFO - 2020-03-09 01:44:30 --> Loader Class Initialized
INFO - 2020-03-09 01:44:30 --> Helper loaded: url_helper
INFO - 2020-03-09 01:44:30 --> Helper loaded: string_helper
INFO - 2020-03-09 01:44:30 --> Database Driver Class Initialized
DEBUG - 2020-03-09 01:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 01:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 01:44:30 --> Controller Class Initialized
INFO - 2020-03-09 01:44:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 01:44:30 --> Pagination Class Initialized
INFO - 2020-03-09 01:44:30 --> Model "M_show" initialized
INFO - 2020-03-09 01:44:30 --> Helper loaded: form_helper
INFO - 2020-03-09 01:44:30 --> Form Validation Class Initialized
INFO - 2020-03-09 01:44:30 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 01:44:30 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 01:44:30 --> Final output sent to browser
DEBUG - 2020-03-09 01:44:30 --> Total execution time: 0.0403
INFO - 2020-03-09 01:59:06 --> Config Class Initialized
INFO - 2020-03-09 01:59:06 --> Hooks Class Initialized
DEBUG - 2020-03-09 01:59:06 --> UTF-8 Support Enabled
INFO - 2020-03-09 01:59:06 --> Utf8 Class Initialized
INFO - 2020-03-09 01:59:06 --> URI Class Initialized
DEBUG - 2020-03-09 01:59:06 --> No URI present. Default controller set.
INFO - 2020-03-09 01:59:06 --> Router Class Initialized
INFO - 2020-03-09 01:59:06 --> Output Class Initialized
INFO - 2020-03-09 01:59:06 --> Security Class Initialized
DEBUG - 2020-03-09 01:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 01:59:06 --> Input Class Initialized
INFO - 2020-03-09 01:59:06 --> Language Class Initialized
INFO - 2020-03-09 01:59:06 --> Loader Class Initialized
INFO - 2020-03-09 01:59:06 --> Helper loaded: url_helper
INFO - 2020-03-09 01:59:06 --> Helper loaded: string_helper
INFO - 2020-03-09 01:59:06 --> Database Driver Class Initialized
DEBUG - 2020-03-09 01:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 01:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 01:59:06 --> Controller Class Initialized
INFO - 2020-03-09 01:59:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 01:59:06 --> Pagination Class Initialized
INFO - 2020-03-09 01:59:06 --> Model "M_show" initialized
INFO - 2020-03-09 01:59:06 --> Helper loaded: form_helper
INFO - 2020-03-09 01:59:06 --> Form Validation Class Initialized
INFO - 2020-03-09 01:59:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 01:59:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 01:59:06 --> Final output sent to browser
DEBUG - 2020-03-09 01:59:06 --> Total execution time: 0.0456
INFO - 2020-03-09 02:05:56 --> Config Class Initialized
INFO - 2020-03-09 02:05:56 --> Hooks Class Initialized
DEBUG - 2020-03-09 02:05:56 --> UTF-8 Support Enabled
INFO - 2020-03-09 02:05:56 --> Utf8 Class Initialized
INFO - 2020-03-09 02:05:56 --> URI Class Initialized
DEBUG - 2020-03-09 02:05:56 --> No URI present. Default controller set.
INFO - 2020-03-09 02:05:56 --> Router Class Initialized
INFO - 2020-03-09 02:05:56 --> Output Class Initialized
INFO - 2020-03-09 02:05:56 --> Security Class Initialized
DEBUG - 2020-03-09 02:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 02:05:56 --> Input Class Initialized
INFO - 2020-03-09 02:05:56 --> Language Class Initialized
INFO - 2020-03-09 02:05:56 --> Loader Class Initialized
INFO - 2020-03-09 02:05:56 --> Helper loaded: url_helper
INFO - 2020-03-09 02:05:56 --> Helper loaded: string_helper
INFO - 2020-03-09 02:05:56 --> Database Driver Class Initialized
DEBUG - 2020-03-09 02:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 02:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 02:05:56 --> Controller Class Initialized
INFO - 2020-03-09 02:05:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 02:05:56 --> Pagination Class Initialized
INFO - 2020-03-09 02:05:56 --> Model "M_show" initialized
INFO - 2020-03-09 02:05:56 --> Helper loaded: form_helper
INFO - 2020-03-09 02:05:56 --> Form Validation Class Initialized
INFO - 2020-03-09 02:05:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 02:05:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 02:05:56 --> Final output sent to browser
DEBUG - 2020-03-09 02:05:56 --> Total execution time: 0.0421
INFO - 2020-03-09 02:06:26 --> Config Class Initialized
INFO - 2020-03-09 02:06:26 --> Hooks Class Initialized
DEBUG - 2020-03-09 02:06:26 --> UTF-8 Support Enabled
INFO - 2020-03-09 02:06:26 --> Utf8 Class Initialized
INFO - 2020-03-09 02:06:26 --> URI Class Initialized
INFO - 2020-03-09 02:06:26 --> Router Class Initialized
INFO - 2020-03-09 02:06:26 --> Output Class Initialized
INFO - 2020-03-09 02:06:26 --> Security Class Initialized
DEBUG - 2020-03-09 02:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 02:06:26 --> Input Class Initialized
INFO - 2020-03-09 02:06:26 --> Language Class Initialized
INFO - 2020-03-09 02:06:26 --> Loader Class Initialized
INFO - 2020-03-09 02:06:26 --> Helper loaded: url_helper
INFO - 2020-03-09 02:06:26 --> Helper loaded: string_helper
INFO - 2020-03-09 02:06:26 --> Database Driver Class Initialized
DEBUG - 2020-03-09 02:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 02:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 02:06:26 --> Controller Class Initialized
INFO - 2020-03-09 02:06:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 02:06:26 --> Pagination Class Initialized
INFO - 2020-03-09 02:06:26 --> Model "M_show" initialized
INFO - 2020-03-09 02:06:26 --> Helper loaded: form_helper
INFO - 2020-03-09 02:06:26 --> Form Validation Class Initialized
INFO - 2020-03-09 02:06:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 02:06:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 02:06:26 --> Final output sent to browser
DEBUG - 2020-03-09 02:06:26 --> Total execution time: 0.0090
INFO - 2020-03-09 02:06:31 --> Config Class Initialized
INFO - 2020-03-09 02:06:31 --> Hooks Class Initialized
DEBUG - 2020-03-09 02:06:31 --> UTF-8 Support Enabled
INFO - 2020-03-09 02:06:31 --> Utf8 Class Initialized
INFO - 2020-03-09 02:06:31 --> URI Class Initialized
INFO - 2020-03-09 02:06:31 --> Router Class Initialized
INFO - 2020-03-09 02:06:31 --> Output Class Initialized
INFO - 2020-03-09 02:06:31 --> Security Class Initialized
DEBUG - 2020-03-09 02:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 02:06:31 --> Input Class Initialized
INFO - 2020-03-09 02:06:31 --> Language Class Initialized
INFO - 2020-03-09 02:06:31 --> Loader Class Initialized
INFO - 2020-03-09 02:06:31 --> Helper loaded: url_helper
INFO - 2020-03-09 02:06:31 --> Helper loaded: string_helper
INFO - 2020-03-09 02:06:31 --> Database Driver Class Initialized
DEBUG - 2020-03-09 02:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 02:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 02:06:31 --> Controller Class Initialized
INFO - 2020-03-09 02:06:31 --> Model "M_tiket" initialized
INFO - 2020-03-09 02:06:31 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 02:06:31 --> Model "M_pesan" initialized
INFO - 2020-03-09 02:06:31 --> Helper loaded: form_helper
INFO - 2020-03-09 02:06:31 --> Form Validation Class Initialized
INFO - 2020-03-09 02:06:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-09 02:06:31 --> Final output sent to browser
DEBUG - 2020-03-09 02:06:31 --> Total execution time: 0.0123
INFO - 2020-03-09 02:07:00 --> Config Class Initialized
INFO - 2020-03-09 02:07:00 --> Hooks Class Initialized
DEBUG - 2020-03-09 02:07:00 --> UTF-8 Support Enabled
INFO - 2020-03-09 02:07:00 --> Utf8 Class Initialized
INFO - 2020-03-09 02:07:00 --> URI Class Initialized
INFO - 2020-03-09 02:07:00 --> Router Class Initialized
INFO - 2020-03-09 02:07:00 --> Output Class Initialized
INFO - 2020-03-09 02:07:00 --> Security Class Initialized
DEBUG - 2020-03-09 02:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 02:07:00 --> Input Class Initialized
INFO - 2020-03-09 02:07:00 --> Language Class Initialized
INFO - 2020-03-09 02:07:00 --> Loader Class Initialized
INFO - 2020-03-09 02:07:00 --> Helper loaded: url_helper
INFO - 2020-03-09 02:07:00 --> Helper loaded: string_helper
INFO - 2020-03-09 02:07:00 --> Database Driver Class Initialized
DEBUG - 2020-03-09 02:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 02:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 02:07:00 --> Controller Class Initialized
INFO - 2020-03-09 02:07:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 02:07:00 --> Pagination Class Initialized
INFO - 2020-03-09 02:07:00 --> Model "M_show" initialized
INFO - 2020-03-09 02:07:00 --> Helper loaded: form_helper
INFO - 2020-03-09 02:07:00 --> Form Validation Class Initialized
INFO - 2020-03-09 02:07:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 02:07:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 02:07:00 --> Final output sent to browser
DEBUG - 2020-03-09 02:07:00 --> Total execution time: 0.0066
INFO - 2020-03-09 02:07:03 --> Config Class Initialized
INFO - 2020-03-09 02:07:03 --> Hooks Class Initialized
DEBUG - 2020-03-09 02:07:03 --> UTF-8 Support Enabled
INFO - 2020-03-09 02:07:03 --> Utf8 Class Initialized
INFO - 2020-03-09 02:07:03 --> URI Class Initialized
INFO - 2020-03-09 02:07:03 --> Router Class Initialized
INFO - 2020-03-09 02:07:03 --> Output Class Initialized
INFO - 2020-03-09 02:07:03 --> Security Class Initialized
DEBUG - 2020-03-09 02:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 02:07:03 --> Input Class Initialized
INFO - 2020-03-09 02:07:03 --> Language Class Initialized
INFO - 2020-03-09 02:07:03 --> Loader Class Initialized
INFO - 2020-03-09 02:07:03 --> Helper loaded: url_helper
INFO - 2020-03-09 02:07:03 --> Helper loaded: string_helper
INFO - 2020-03-09 02:07:03 --> Database Driver Class Initialized
DEBUG - 2020-03-09 02:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 02:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 02:07:03 --> Controller Class Initialized
INFO - 2020-03-09 02:07:03 --> Model "M_tiket" initialized
INFO - 2020-03-09 02:07:03 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 02:07:03 --> Model "M_pesan" initialized
INFO - 2020-03-09 02:07:03 --> Helper loaded: form_helper
INFO - 2020-03-09 02:07:03 --> Form Validation Class Initialized
INFO - 2020-03-09 02:07:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-09 02:07:03 --> Final output sent to browser
DEBUG - 2020-03-09 02:07:03 --> Total execution time: 0.0075
INFO - 2020-03-09 02:15:24 --> Config Class Initialized
INFO - 2020-03-09 02:15:24 --> Hooks Class Initialized
DEBUG - 2020-03-09 02:15:24 --> UTF-8 Support Enabled
INFO - 2020-03-09 02:15:24 --> Utf8 Class Initialized
INFO - 2020-03-09 02:15:24 --> URI Class Initialized
DEBUG - 2020-03-09 02:15:24 --> No URI present. Default controller set.
INFO - 2020-03-09 02:15:24 --> Router Class Initialized
INFO - 2020-03-09 02:15:24 --> Output Class Initialized
INFO - 2020-03-09 02:15:24 --> Security Class Initialized
DEBUG - 2020-03-09 02:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 02:15:24 --> Input Class Initialized
INFO - 2020-03-09 02:15:24 --> Language Class Initialized
INFO - 2020-03-09 02:15:24 --> Loader Class Initialized
INFO - 2020-03-09 02:15:24 --> Helper loaded: url_helper
INFO - 2020-03-09 02:15:24 --> Helper loaded: string_helper
INFO - 2020-03-09 02:15:24 --> Database Driver Class Initialized
DEBUG - 2020-03-09 02:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 02:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 02:15:24 --> Controller Class Initialized
INFO - 2020-03-09 02:15:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 02:15:24 --> Pagination Class Initialized
INFO - 2020-03-09 02:15:24 --> Model "M_show" initialized
INFO - 2020-03-09 02:15:24 --> Helper loaded: form_helper
INFO - 2020-03-09 02:15:24 --> Form Validation Class Initialized
INFO - 2020-03-09 02:15:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 02:15:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 02:15:24 --> Final output sent to browser
DEBUG - 2020-03-09 02:15:24 --> Total execution time: 0.0488
INFO - 2020-03-09 02:15:33 --> Config Class Initialized
INFO - 2020-03-09 02:15:33 --> Hooks Class Initialized
DEBUG - 2020-03-09 02:15:33 --> UTF-8 Support Enabled
INFO - 2020-03-09 02:15:33 --> Utf8 Class Initialized
INFO - 2020-03-09 02:15:33 --> URI Class Initialized
DEBUG - 2020-03-09 02:15:33 --> No URI present. Default controller set.
INFO - 2020-03-09 02:15:33 --> Router Class Initialized
INFO - 2020-03-09 02:15:33 --> Output Class Initialized
INFO - 2020-03-09 02:15:33 --> Security Class Initialized
DEBUG - 2020-03-09 02:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 02:15:33 --> Input Class Initialized
INFO - 2020-03-09 02:15:33 --> Language Class Initialized
INFO - 2020-03-09 02:15:33 --> Loader Class Initialized
INFO - 2020-03-09 02:15:33 --> Helper loaded: url_helper
INFO - 2020-03-09 02:15:33 --> Helper loaded: string_helper
INFO - 2020-03-09 02:15:33 --> Database Driver Class Initialized
DEBUG - 2020-03-09 02:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 02:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 02:15:33 --> Controller Class Initialized
INFO - 2020-03-09 02:15:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 02:15:33 --> Pagination Class Initialized
INFO - 2020-03-09 02:15:33 --> Model "M_show" initialized
INFO - 2020-03-09 02:15:33 --> Helper loaded: form_helper
INFO - 2020-03-09 02:15:33 --> Form Validation Class Initialized
INFO - 2020-03-09 02:15:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 02:15:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 02:15:33 --> Final output sent to browser
DEBUG - 2020-03-09 02:15:33 --> Total execution time: 0.0056
INFO - 2020-03-09 02:16:01 --> Config Class Initialized
INFO - 2020-03-09 02:16:01 --> Hooks Class Initialized
DEBUG - 2020-03-09 02:16:01 --> UTF-8 Support Enabled
INFO - 2020-03-09 02:16:01 --> Utf8 Class Initialized
INFO - 2020-03-09 02:16:01 --> URI Class Initialized
INFO - 2020-03-09 02:16:01 --> Router Class Initialized
INFO - 2020-03-09 02:16:01 --> Output Class Initialized
INFO - 2020-03-09 02:16:01 --> Security Class Initialized
DEBUG - 2020-03-09 02:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 02:16:01 --> Input Class Initialized
INFO - 2020-03-09 02:16:01 --> Language Class Initialized
INFO - 2020-03-09 02:16:01 --> Loader Class Initialized
INFO - 2020-03-09 02:16:01 --> Helper loaded: url_helper
INFO - 2020-03-09 02:16:01 --> Helper loaded: string_helper
INFO - 2020-03-09 02:16:01 --> Database Driver Class Initialized
DEBUG - 2020-03-09 02:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 02:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 02:16:01 --> Controller Class Initialized
INFO - 2020-03-09 02:16:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 02:16:01 --> Pagination Class Initialized
INFO - 2020-03-09 02:16:01 --> Model "M_show" initialized
INFO - 2020-03-09 02:16:01 --> Helper loaded: form_helper
INFO - 2020-03-09 02:16:01 --> Form Validation Class Initialized
INFO - 2020-03-09 02:16:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 02:16:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tentang.php
INFO - 2020-03-09 02:16:01 --> Final output sent to browser
DEBUG - 2020-03-09 02:16:01 --> Total execution time: 0.0178
INFO - 2020-03-09 02:16:41 --> Config Class Initialized
INFO - 2020-03-09 02:16:41 --> Hooks Class Initialized
DEBUG - 2020-03-09 02:16:41 --> UTF-8 Support Enabled
INFO - 2020-03-09 02:16:41 --> Utf8 Class Initialized
INFO - 2020-03-09 02:16:41 --> URI Class Initialized
DEBUG - 2020-03-09 02:16:41 --> No URI present. Default controller set.
INFO - 2020-03-09 02:16:41 --> Router Class Initialized
INFO - 2020-03-09 02:16:41 --> Output Class Initialized
INFO - 2020-03-09 02:16:41 --> Security Class Initialized
DEBUG - 2020-03-09 02:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 02:16:41 --> Input Class Initialized
INFO - 2020-03-09 02:16:41 --> Language Class Initialized
INFO - 2020-03-09 02:16:41 --> Loader Class Initialized
INFO - 2020-03-09 02:16:41 --> Helper loaded: url_helper
INFO - 2020-03-09 02:16:41 --> Helper loaded: string_helper
INFO - 2020-03-09 02:16:41 --> Database Driver Class Initialized
DEBUG - 2020-03-09 02:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 02:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 02:16:41 --> Controller Class Initialized
INFO - 2020-03-09 02:16:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 02:16:41 --> Pagination Class Initialized
INFO - 2020-03-09 02:16:41 --> Model "M_show" initialized
INFO - 2020-03-09 02:16:41 --> Helper loaded: form_helper
INFO - 2020-03-09 02:16:41 --> Form Validation Class Initialized
INFO - 2020-03-09 02:16:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 02:16:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 02:16:41 --> Final output sent to browser
DEBUG - 2020-03-09 02:16:41 --> Total execution time: 0.0093
INFO - 2020-03-09 02:16:44 --> Config Class Initialized
INFO - 2020-03-09 02:16:44 --> Hooks Class Initialized
DEBUG - 2020-03-09 02:16:44 --> UTF-8 Support Enabled
INFO - 2020-03-09 02:16:44 --> Utf8 Class Initialized
INFO - 2020-03-09 02:16:44 --> URI Class Initialized
INFO - 2020-03-09 02:16:44 --> Router Class Initialized
INFO - 2020-03-09 02:16:44 --> Output Class Initialized
INFO - 2020-03-09 02:16:44 --> Security Class Initialized
DEBUG - 2020-03-09 02:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 02:16:44 --> Input Class Initialized
INFO - 2020-03-09 02:16:44 --> Language Class Initialized
INFO - 2020-03-09 02:16:44 --> Loader Class Initialized
INFO - 2020-03-09 02:16:44 --> Helper loaded: url_helper
INFO - 2020-03-09 02:16:44 --> Helper loaded: string_helper
INFO - 2020-03-09 02:16:44 --> Database Driver Class Initialized
DEBUG - 2020-03-09 02:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 02:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 02:16:44 --> Controller Class Initialized
INFO - 2020-03-09 02:16:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 02:16:44 --> Pagination Class Initialized
INFO - 2020-03-09 02:16:44 --> Model "M_show" initialized
INFO - 2020-03-09 02:16:44 --> Helper loaded: form_helper
INFO - 2020-03-09 02:16:44 --> Form Validation Class Initialized
INFO - 2020-03-09 02:16:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 02:16:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-09 02:16:44 --> Final output sent to browser
DEBUG - 2020-03-09 02:16:44 --> Total execution time: 0.0061
INFO - 2020-03-09 02:17:03 --> Config Class Initialized
INFO - 2020-03-09 02:17:03 --> Hooks Class Initialized
DEBUG - 2020-03-09 02:17:03 --> UTF-8 Support Enabled
INFO - 2020-03-09 02:17:03 --> Utf8 Class Initialized
INFO - 2020-03-09 02:17:03 --> URI Class Initialized
INFO - 2020-03-09 02:17:03 --> Router Class Initialized
INFO - 2020-03-09 02:17:03 --> Output Class Initialized
INFO - 2020-03-09 02:17:03 --> Security Class Initialized
DEBUG - 2020-03-09 02:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 02:17:03 --> Input Class Initialized
INFO - 2020-03-09 02:17:03 --> Language Class Initialized
INFO - 2020-03-09 02:17:03 --> Loader Class Initialized
INFO - 2020-03-09 02:17:03 --> Helper loaded: url_helper
INFO - 2020-03-09 02:17:03 --> Helper loaded: string_helper
INFO - 2020-03-09 02:17:03 --> Database Driver Class Initialized
DEBUG - 2020-03-09 02:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 02:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 02:17:03 --> Controller Class Initialized
INFO - 2020-03-09 02:17:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 02:17:03 --> Pagination Class Initialized
INFO - 2020-03-09 02:17:03 --> Model "M_show" initialized
INFO - 2020-03-09 02:17:03 --> Helper loaded: form_helper
INFO - 2020-03-09 02:17:03 --> Form Validation Class Initialized
INFO - 2020-03-09 02:17:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 02:17:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tentang.php
INFO - 2020-03-09 02:17:03 --> Final output sent to browser
DEBUG - 2020-03-09 02:17:03 --> Total execution time: 0.0059
INFO - 2020-03-09 02:17:04 --> Config Class Initialized
INFO - 2020-03-09 02:17:04 --> Hooks Class Initialized
DEBUG - 2020-03-09 02:17:04 --> UTF-8 Support Enabled
INFO - 2020-03-09 02:17:04 --> Utf8 Class Initialized
INFO - 2020-03-09 02:17:04 --> URI Class Initialized
INFO - 2020-03-09 02:17:04 --> Router Class Initialized
INFO - 2020-03-09 02:17:04 --> Output Class Initialized
INFO - 2020-03-09 02:17:04 --> Security Class Initialized
DEBUG - 2020-03-09 02:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 02:17:04 --> Input Class Initialized
INFO - 2020-03-09 02:17:04 --> Language Class Initialized
INFO - 2020-03-09 02:17:04 --> Loader Class Initialized
INFO - 2020-03-09 02:17:04 --> Helper loaded: url_helper
INFO - 2020-03-09 02:17:04 --> Helper loaded: string_helper
INFO - 2020-03-09 02:17:04 --> Database Driver Class Initialized
DEBUG - 2020-03-09 02:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 02:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 02:17:04 --> Controller Class Initialized
INFO - 2020-03-09 02:17:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 02:17:04 --> Pagination Class Initialized
INFO - 2020-03-09 02:17:04 --> Model "M_show" initialized
INFO - 2020-03-09 02:17:04 --> Helper loaded: form_helper
INFO - 2020-03-09 02:17:04 --> Form Validation Class Initialized
INFO - 2020-03-09 02:17:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 02:17:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 02:17:04 --> Final output sent to browser
DEBUG - 2020-03-09 02:17:04 --> Total execution time: 0.0082
INFO - 2020-03-09 02:17:04 --> Config Class Initialized
INFO - 2020-03-09 02:17:04 --> Hooks Class Initialized
DEBUG - 2020-03-09 02:17:04 --> UTF-8 Support Enabled
INFO - 2020-03-09 02:17:04 --> Utf8 Class Initialized
INFO - 2020-03-09 02:17:04 --> URI Class Initialized
INFO - 2020-03-09 02:17:04 --> Router Class Initialized
INFO - 2020-03-09 02:17:04 --> Output Class Initialized
INFO - 2020-03-09 02:17:04 --> Security Class Initialized
DEBUG - 2020-03-09 02:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 02:17:04 --> Input Class Initialized
INFO - 2020-03-09 02:17:04 --> Language Class Initialized
ERROR - 2020-03-09 02:17:04 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-09 02:17:07 --> Config Class Initialized
INFO - 2020-03-09 02:17:07 --> Hooks Class Initialized
DEBUG - 2020-03-09 02:17:07 --> UTF-8 Support Enabled
INFO - 2020-03-09 02:17:07 --> Utf8 Class Initialized
INFO - 2020-03-09 02:17:07 --> URI Class Initialized
INFO - 2020-03-09 02:17:07 --> Router Class Initialized
INFO - 2020-03-09 02:17:07 --> Output Class Initialized
INFO - 2020-03-09 02:17:07 --> Security Class Initialized
DEBUG - 2020-03-09 02:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 02:17:07 --> Input Class Initialized
INFO - 2020-03-09 02:17:07 --> Language Class Initialized
INFO - 2020-03-09 02:17:07 --> Loader Class Initialized
INFO - 2020-03-09 02:17:07 --> Helper loaded: url_helper
INFO - 2020-03-09 02:17:07 --> Helper loaded: string_helper
INFO - 2020-03-09 02:17:07 --> Database Driver Class Initialized
DEBUG - 2020-03-09 02:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 02:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 02:17:07 --> Controller Class Initialized
INFO - 2020-03-09 02:17:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 02:17:07 --> Pagination Class Initialized
INFO - 2020-03-09 02:17:07 --> Model "M_show" initialized
INFO - 2020-03-09 02:17:07 --> Helper loaded: form_helper
INFO - 2020-03-09 02:17:07 --> Form Validation Class Initialized
INFO - 2020-03-09 02:17:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 02:17:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/hub.php
INFO - 2020-03-09 02:17:07 --> Final output sent to browser
DEBUG - 2020-03-09 02:17:07 --> Total execution time: 0.0056
INFO - 2020-03-09 02:17:13 --> Config Class Initialized
INFO - 2020-03-09 02:17:13 --> Hooks Class Initialized
DEBUG - 2020-03-09 02:17:13 --> UTF-8 Support Enabled
INFO - 2020-03-09 02:17:13 --> Utf8 Class Initialized
INFO - 2020-03-09 02:17:13 --> URI Class Initialized
DEBUG - 2020-03-09 02:17:13 --> No URI present. Default controller set.
INFO - 2020-03-09 02:17:13 --> Router Class Initialized
INFO - 2020-03-09 02:17:13 --> Output Class Initialized
INFO - 2020-03-09 02:17:13 --> Security Class Initialized
DEBUG - 2020-03-09 02:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 02:17:13 --> Input Class Initialized
INFO - 2020-03-09 02:17:13 --> Language Class Initialized
INFO - 2020-03-09 02:17:13 --> Loader Class Initialized
INFO - 2020-03-09 02:17:13 --> Helper loaded: url_helper
INFO - 2020-03-09 02:17:13 --> Helper loaded: string_helper
INFO - 2020-03-09 02:17:13 --> Database Driver Class Initialized
DEBUG - 2020-03-09 02:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 02:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 02:17:13 --> Controller Class Initialized
INFO - 2020-03-09 02:17:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 02:17:13 --> Pagination Class Initialized
INFO - 2020-03-09 02:17:13 --> Model "M_show" initialized
INFO - 2020-03-09 02:17:13 --> Helper loaded: form_helper
INFO - 2020-03-09 02:17:13 --> Form Validation Class Initialized
INFO - 2020-03-09 02:17:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 02:17:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 02:17:13 --> Final output sent to browser
DEBUG - 2020-03-09 02:17:13 --> Total execution time: 0.0051
INFO - 2020-03-09 02:18:02 --> Config Class Initialized
INFO - 2020-03-09 02:18:02 --> Hooks Class Initialized
DEBUG - 2020-03-09 02:18:02 --> UTF-8 Support Enabled
INFO - 2020-03-09 02:18:02 --> Utf8 Class Initialized
INFO - 2020-03-09 02:18:02 --> URI Class Initialized
INFO - 2020-03-09 02:18:02 --> Router Class Initialized
INFO - 2020-03-09 02:18:02 --> Output Class Initialized
INFO - 2020-03-09 02:18:02 --> Security Class Initialized
DEBUG - 2020-03-09 02:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 02:18:02 --> Input Class Initialized
INFO - 2020-03-09 02:18:02 --> Language Class Initialized
INFO - 2020-03-09 02:18:02 --> Loader Class Initialized
INFO - 2020-03-09 02:18:02 --> Helper loaded: url_helper
INFO - 2020-03-09 02:18:02 --> Helper loaded: string_helper
INFO - 2020-03-09 02:18:02 --> Database Driver Class Initialized
DEBUG - 2020-03-09 02:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 02:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 02:18:02 --> Controller Class Initialized
INFO - 2020-03-09 02:18:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 02:18:02 --> Pagination Class Initialized
INFO - 2020-03-09 02:18:02 --> Model "M_show" initialized
INFO - 2020-03-09 02:18:02 --> Helper loaded: form_helper
INFO - 2020-03-09 02:18:02 --> Form Validation Class Initialized
INFO - 2020-03-09 02:18:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 02:18:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/gal.php
INFO - 2020-03-09 02:18:02 --> Final output sent to browser
DEBUG - 2020-03-09 02:18:02 --> Total execution time: 0.0066
INFO - 2020-03-09 02:18:27 --> Config Class Initialized
INFO - 2020-03-09 02:18:27 --> Hooks Class Initialized
DEBUG - 2020-03-09 02:18:27 --> UTF-8 Support Enabled
INFO - 2020-03-09 02:18:27 --> Utf8 Class Initialized
INFO - 2020-03-09 02:18:27 --> URI Class Initialized
INFO - 2020-03-09 02:18:27 --> Router Class Initialized
INFO - 2020-03-09 02:18:27 --> Output Class Initialized
INFO - 2020-03-09 02:18:27 --> Security Class Initialized
DEBUG - 2020-03-09 02:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 02:18:27 --> Input Class Initialized
INFO - 2020-03-09 02:18:27 --> Language Class Initialized
INFO - 2020-03-09 02:18:27 --> Loader Class Initialized
INFO - 2020-03-09 02:18:27 --> Helper loaded: url_helper
INFO - 2020-03-09 02:18:27 --> Helper loaded: string_helper
INFO - 2020-03-09 02:18:27 --> Database Driver Class Initialized
DEBUG - 2020-03-09 02:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 02:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 02:18:27 --> Controller Class Initialized
INFO - 2020-03-09 02:18:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 02:18:27 --> Pagination Class Initialized
INFO - 2020-03-09 02:18:27 --> Model "M_show" initialized
INFO - 2020-03-09 02:18:27 --> Helper loaded: form_helper
INFO - 2020-03-09 02:18:27 --> Form Validation Class Initialized
INFO - 2020-03-09 02:18:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 02:18:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/hub.php
INFO - 2020-03-09 02:18:27 --> Final output sent to browser
DEBUG - 2020-03-09 02:18:27 --> Total execution time: 0.0057
INFO - 2020-03-09 02:43:27 --> Config Class Initialized
INFO - 2020-03-09 02:43:27 --> Hooks Class Initialized
DEBUG - 2020-03-09 02:43:27 --> UTF-8 Support Enabled
INFO - 2020-03-09 02:43:27 --> Utf8 Class Initialized
INFO - 2020-03-09 02:43:27 --> URI Class Initialized
DEBUG - 2020-03-09 02:43:27 --> No URI present. Default controller set.
INFO - 2020-03-09 02:43:27 --> Router Class Initialized
INFO - 2020-03-09 02:43:27 --> Output Class Initialized
INFO - 2020-03-09 02:43:27 --> Security Class Initialized
DEBUG - 2020-03-09 02:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 02:43:27 --> Input Class Initialized
INFO - 2020-03-09 02:43:27 --> Language Class Initialized
INFO - 2020-03-09 02:43:27 --> Loader Class Initialized
INFO - 2020-03-09 02:43:27 --> Helper loaded: url_helper
INFO - 2020-03-09 02:43:27 --> Helper loaded: string_helper
INFO - 2020-03-09 02:43:27 --> Database Driver Class Initialized
DEBUG - 2020-03-09 02:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 02:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 02:43:27 --> Controller Class Initialized
INFO - 2020-03-09 02:43:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 02:43:27 --> Pagination Class Initialized
INFO - 2020-03-09 02:43:27 --> Model "M_show" initialized
INFO - 2020-03-09 02:43:27 --> Helper loaded: form_helper
INFO - 2020-03-09 02:43:27 --> Form Validation Class Initialized
INFO - 2020-03-09 02:43:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 02:43:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 02:43:27 --> Final output sent to browser
DEBUG - 2020-03-09 02:43:27 --> Total execution time: 0.0413
INFO - 2020-03-09 02:43:37 --> Config Class Initialized
INFO - 2020-03-09 02:43:37 --> Hooks Class Initialized
DEBUG - 2020-03-09 02:43:37 --> UTF-8 Support Enabled
INFO - 2020-03-09 02:43:37 --> Utf8 Class Initialized
INFO - 2020-03-09 02:43:37 --> URI Class Initialized
DEBUG - 2020-03-09 02:43:37 --> No URI present. Default controller set.
INFO - 2020-03-09 02:43:37 --> Router Class Initialized
INFO - 2020-03-09 02:43:37 --> Output Class Initialized
INFO - 2020-03-09 02:43:37 --> Security Class Initialized
DEBUG - 2020-03-09 02:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 02:43:37 --> Input Class Initialized
INFO - 2020-03-09 02:43:37 --> Language Class Initialized
INFO - 2020-03-09 02:43:37 --> Loader Class Initialized
INFO - 2020-03-09 02:43:37 --> Helper loaded: url_helper
INFO - 2020-03-09 02:43:37 --> Helper loaded: string_helper
INFO - 2020-03-09 02:43:37 --> Database Driver Class Initialized
DEBUG - 2020-03-09 02:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 02:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 02:43:37 --> Controller Class Initialized
INFO - 2020-03-09 02:43:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 02:43:37 --> Pagination Class Initialized
INFO - 2020-03-09 02:43:37 --> Model "M_show" initialized
INFO - 2020-03-09 02:43:37 --> Helper loaded: form_helper
INFO - 2020-03-09 02:43:37 --> Form Validation Class Initialized
INFO - 2020-03-09 02:43:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 02:43:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 02:43:37 --> Final output sent to browser
DEBUG - 2020-03-09 02:43:37 --> Total execution time: 0.0092
INFO - 2020-03-09 02:43:37 --> Config Class Initialized
INFO - 2020-03-09 02:43:37 --> Hooks Class Initialized
DEBUG - 2020-03-09 02:43:37 --> UTF-8 Support Enabled
INFO - 2020-03-09 02:43:37 --> Utf8 Class Initialized
INFO - 2020-03-09 02:43:37 --> URI Class Initialized
DEBUG - 2020-03-09 02:43:37 --> No URI present. Default controller set.
INFO - 2020-03-09 02:43:37 --> Router Class Initialized
INFO - 2020-03-09 02:43:37 --> Output Class Initialized
INFO - 2020-03-09 02:43:37 --> Security Class Initialized
DEBUG - 2020-03-09 02:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 02:43:37 --> Input Class Initialized
INFO - 2020-03-09 02:43:37 --> Language Class Initialized
INFO - 2020-03-09 02:43:37 --> Loader Class Initialized
INFO - 2020-03-09 02:43:37 --> Helper loaded: url_helper
INFO - 2020-03-09 02:43:37 --> Helper loaded: string_helper
INFO - 2020-03-09 02:43:37 --> Database Driver Class Initialized
DEBUG - 2020-03-09 02:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 02:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 02:43:37 --> Controller Class Initialized
INFO - 2020-03-09 02:43:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 02:43:37 --> Pagination Class Initialized
INFO - 2020-03-09 02:43:37 --> Model "M_show" initialized
INFO - 2020-03-09 02:43:37 --> Helper loaded: form_helper
INFO - 2020-03-09 02:43:37 --> Form Validation Class Initialized
INFO - 2020-03-09 02:43:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 02:43:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 02:43:37 --> Final output sent to browser
DEBUG - 2020-03-09 02:43:37 --> Total execution time: 0.0095
INFO - 2020-03-09 02:43:40 --> Config Class Initialized
INFO - 2020-03-09 02:43:40 --> Hooks Class Initialized
DEBUG - 2020-03-09 02:43:40 --> UTF-8 Support Enabled
INFO - 2020-03-09 02:43:40 --> Utf8 Class Initialized
INFO - 2020-03-09 02:43:40 --> URI Class Initialized
DEBUG - 2020-03-09 02:43:40 --> No URI present. Default controller set.
INFO - 2020-03-09 02:43:40 --> Router Class Initialized
INFO - 2020-03-09 02:43:40 --> Output Class Initialized
INFO - 2020-03-09 02:43:40 --> Security Class Initialized
DEBUG - 2020-03-09 02:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 02:43:40 --> Input Class Initialized
INFO - 2020-03-09 02:43:40 --> Language Class Initialized
INFO - 2020-03-09 02:43:40 --> Loader Class Initialized
INFO - 2020-03-09 02:43:40 --> Helper loaded: url_helper
INFO - 2020-03-09 02:43:40 --> Helper loaded: string_helper
INFO - 2020-03-09 02:43:40 --> Database Driver Class Initialized
DEBUG - 2020-03-09 02:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 02:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 02:43:40 --> Controller Class Initialized
INFO - 2020-03-09 02:43:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 02:43:40 --> Pagination Class Initialized
INFO - 2020-03-09 02:43:40 --> Model "M_show" initialized
INFO - 2020-03-09 02:43:40 --> Helper loaded: form_helper
INFO - 2020-03-09 02:43:40 --> Form Validation Class Initialized
INFO - 2020-03-09 02:43:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 02:43:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 02:43:40 --> Final output sent to browser
DEBUG - 2020-03-09 02:43:40 --> Total execution time: 0.0051
INFO - 2020-03-09 02:43:47 --> Config Class Initialized
INFO - 2020-03-09 02:43:47 --> Hooks Class Initialized
DEBUG - 2020-03-09 02:43:47 --> UTF-8 Support Enabled
INFO - 2020-03-09 02:43:47 --> Utf8 Class Initialized
INFO - 2020-03-09 02:43:47 --> URI Class Initialized
INFO - 2020-03-09 02:43:47 --> Router Class Initialized
INFO - 2020-03-09 02:43:47 --> Output Class Initialized
INFO - 2020-03-09 02:43:47 --> Security Class Initialized
DEBUG - 2020-03-09 02:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 02:43:47 --> Input Class Initialized
INFO - 2020-03-09 02:43:47 --> Language Class Initialized
INFO - 2020-03-09 02:43:47 --> Loader Class Initialized
INFO - 2020-03-09 02:43:47 --> Helper loaded: url_helper
INFO - 2020-03-09 02:43:47 --> Helper loaded: string_helper
INFO - 2020-03-09 02:43:47 --> Database Driver Class Initialized
DEBUG - 2020-03-09 02:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 02:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 02:43:47 --> Controller Class Initialized
INFO - 2020-03-09 02:43:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 02:43:47 --> Pagination Class Initialized
INFO - 2020-03-09 02:43:47 --> Model "M_show" initialized
INFO - 2020-03-09 02:43:47 --> Helper loaded: form_helper
INFO - 2020-03-09 02:43:47 --> Form Validation Class Initialized
INFO - 2020-03-09 02:43:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 02:43:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 02:43:47 --> Final output sent to browser
DEBUG - 2020-03-09 02:43:47 --> Total execution time: 0.0079
INFO - 2020-03-09 02:43:48 --> Config Class Initialized
INFO - 2020-03-09 02:43:48 --> Hooks Class Initialized
DEBUG - 2020-03-09 02:43:48 --> UTF-8 Support Enabled
INFO - 2020-03-09 02:43:48 --> Utf8 Class Initialized
INFO - 2020-03-09 02:43:48 --> URI Class Initialized
INFO - 2020-03-09 02:43:48 --> Router Class Initialized
INFO - 2020-03-09 02:43:48 --> Output Class Initialized
INFO - 2020-03-09 02:43:48 --> Security Class Initialized
DEBUG - 2020-03-09 02:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 02:43:48 --> Input Class Initialized
INFO - 2020-03-09 02:43:48 --> Language Class Initialized
ERROR - 2020-03-09 02:43:48 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-09 02:43:51 --> Config Class Initialized
INFO - 2020-03-09 02:43:51 --> Hooks Class Initialized
DEBUG - 2020-03-09 02:43:51 --> UTF-8 Support Enabled
INFO - 2020-03-09 02:43:51 --> Utf8 Class Initialized
INFO - 2020-03-09 02:43:51 --> URI Class Initialized
INFO - 2020-03-09 02:43:51 --> Router Class Initialized
INFO - 2020-03-09 02:43:51 --> Output Class Initialized
INFO - 2020-03-09 02:43:51 --> Security Class Initialized
DEBUG - 2020-03-09 02:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 02:43:51 --> Input Class Initialized
INFO - 2020-03-09 02:43:51 --> Language Class Initialized
INFO - 2020-03-09 02:43:51 --> Loader Class Initialized
INFO - 2020-03-09 02:43:51 --> Helper loaded: url_helper
INFO - 2020-03-09 02:43:51 --> Helper loaded: string_helper
INFO - 2020-03-09 02:43:51 --> Database Driver Class Initialized
DEBUG - 2020-03-09 02:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 02:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 02:43:51 --> Controller Class Initialized
INFO - 2020-03-09 02:43:51 --> Model "M_tiket" initialized
INFO - 2020-03-09 02:43:51 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 02:43:51 --> Model "M_pesan" initialized
INFO - 2020-03-09 02:43:51 --> Helper loaded: form_helper
INFO - 2020-03-09 02:43:51 --> Form Validation Class Initialized
INFO - 2020-03-09 02:43:51 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-09 02:43:51 --> Final output sent to browser
DEBUG - 2020-03-09 02:43:51 --> Total execution time: 0.0109
INFO - 2020-03-09 03:55:35 --> Config Class Initialized
INFO - 2020-03-09 03:55:35 --> Hooks Class Initialized
DEBUG - 2020-03-09 03:55:35 --> UTF-8 Support Enabled
INFO - 2020-03-09 03:55:35 --> Utf8 Class Initialized
INFO - 2020-03-09 03:55:35 --> URI Class Initialized
DEBUG - 2020-03-09 03:55:35 --> No URI present. Default controller set.
INFO - 2020-03-09 03:55:35 --> Router Class Initialized
INFO - 2020-03-09 03:55:35 --> Output Class Initialized
INFO - 2020-03-09 03:55:35 --> Security Class Initialized
DEBUG - 2020-03-09 03:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 03:55:35 --> Input Class Initialized
INFO - 2020-03-09 03:55:35 --> Language Class Initialized
INFO - 2020-03-09 03:55:35 --> Loader Class Initialized
INFO - 2020-03-09 03:55:35 --> Helper loaded: url_helper
INFO - 2020-03-09 03:55:35 --> Helper loaded: string_helper
INFO - 2020-03-09 03:55:35 --> Database Driver Class Initialized
DEBUG - 2020-03-09 03:55:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 03:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 03:55:35 --> Controller Class Initialized
INFO - 2020-03-09 03:55:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 03:55:35 --> Pagination Class Initialized
INFO - 2020-03-09 03:55:35 --> Model "M_show" initialized
INFO - 2020-03-09 03:55:35 --> Helper loaded: form_helper
INFO - 2020-03-09 03:55:35 --> Form Validation Class Initialized
INFO - 2020-03-09 03:55:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 03:55:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 03:55:35 --> Final output sent to browser
DEBUG - 2020-03-09 03:55:35 --> Total execution time: 0.1516
INFO - 2020-03-09 04:23:01 --> Config Class Initialized
INFO - 2020-03-09 04:23:01 --> Hooks Class Initialized
DEBUG - 2020-03-09 04:23:01 --> UTF-8 Support Enabled
INFO - 2020-03-09 04:23:01 --> Utf8 Class Initialized
INFO - 2020-03-09 04:23:01 --> URI Class Initialized
DEBUG - 2020-03-09 04:23:01 --> No URI present. Default controller set.
INFO - 2020-03-09 04:23:01 --> Router Class Initialized
INFO - 2020-03-09 04:23:01 --> Output Class Initialized
INFO - 2020-03-09 04:23:01 --> Security Class Initialized
DEBUG - 2020-03-09 04:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 04:23:01 --> Input Class Initialized
INFO - 2020-03-09 04:23:01 --> Language Class Initialized
INFO - 2020-03-09 04:23:01 --> Loader Class Initialized
INFO - 2020-03-09 04:23:01 --> Helper loaded: url_helper
INFO - 2020-03-09 04:23:01 --> Helper loaded: string_helper
INFO - 2020-03-09 04:23:01 --> Database Driver Class Initialized
DEBUG - 2020-03-09 04:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 04:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 04:23:01 --> Controller Class Initialized
INFO - 2020-03-09 04:23:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 04:23:01 --> Pagination Class Initialized
INFO - 2020-03-09 04:23:01 --> Model "M_show" initialized
INFO - 2020-03-09 04:23:01 --> Helper loaded: form_helper
INFO - 2020-03-09 04:23:01 --> Form Validation Class Initialized
INFO - 2020-03-09 04:23:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 04:23:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 04:23:01 --> Final output sent to browser
DEBUG - 2020-03-09 04:23:01 --> Total execution time: 0.1386
INFO - 2020-03-09 04:58:31 --> Config Class Initialized
INFO - 2020-03-09 04:58:31 --> Hooks Class Initialized
DEBUG - 2020-03-09 04:58:31 --> UTF-8 Support Enabled
INFO - 2020-03-09 04:58:31 --> Utf8 Class Initialized
INFO - 2020-03-09 04:58:31 --> URI Class Initialized
DEBUG - 2020-03-09 04:58:31 --> No URI present. Default controller set.
INFO - 2020-03-09 04:58:31 --> Router Class Initialized
INFO - 2020-03-09 04:58:31 --> Output Class Initialized
INFO - 2020-03-09 04:58:31 --> Security Class Initialized
DEBUG - 2020-03-09 04:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 04:58:31 --> Input Class Initialized
INFO - 2020-03-09 04:58:31 --> Language Class Initialized
INFO - 2020-03-09 04:58:31 --> Loader Class Initialized
INFO - 2020-03-09 04:58:31 --> Helper loaded: url_helper
INFO - 2020-03-09 04:58:31 --> Helper loaded: string_helper
INFO - 2020-03-09 04:58:31 --> Database Driver Class Initialized
DEBUG - 2020-03-09 04:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 04:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 04:58:32 --> Controller Class Initialized
INFO - 2020-03-09 04:58:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 04:58:32 --> Pagination Class Initialized
INFO - 2020-03-09 04:58:32 --> Model "M_show" initialized
INFO - 2020-03-09 04:58:32 --> Helper loaded: form_helper
INFO - 2020-03-09 04:58:32 --> Form Validation Class Initialized
INFO - 2020-03-09 04:58:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 04:58:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 04:58:32 --> Final output sent to browser
DEBUG - 2020-03-09 04:58:32 --> Total execution time: 0.3493
INFO - 2020-03-09 04:58:32 --> Config Class Initialized
INFO - 2020-03-09 04:58:32 --> Hooks Class Initialized
DEBUG - 2020-03-09 04:58:32 --> UTF-8 Support Enabled
INFO - 2020-03-09 04:58:32 --> Utf8 Class Initialized
INFO - 2020-03-09 04:58:32 --> URI Class Initialized
DEBUG - 2020-03-09 04:58:32 --> No URI present. Default controller set.
INFO - 2020-03-09 04:58:32 --> Router Class Initialized
INFO - 2020-03-09 04:58:32 --> Output Class Initialized
INFO - 2020-03-09 04:58:32 --> Security Class Initialized
DEBUG - 2020-03-09 04:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 04:58:32 --> Input Class Initialized
INFO - 2020-03-09 04:58:32 --> Language Class Initialized
INFO - 2020-03-09 04:58:32 --> Loader Class Initialized
INFO - 2020-03-09 04:58:32 --> Helper loaded: url_helper
INFO - 2020-03-09 04:58:32 --> Helper loaded: string_helper
INFO - 2020-03-09 04:58:32 --> Database Driver Class Initialized
DEBUG - 2020-03-09 04:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 04:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 04:58:32 --> Controller Class Initialized
INFO - 2020-03-09 04:58:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 04:58:32 --> Pagination Class Initialized
INFO - 2020-03-09 04:58:32 --> Model "M_show" initialized
INFO - 2020-03-09 04:58:32 --> Helper loaded: form_helper
INFO - 2020-03-09 04:58:32 --> Form Validation Class Initialized
INFO - 2020-03-09 04:58:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 04:58:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 04:58:32 --> Final output sent to browser
DEBUG - 2020-03-09 04:58:32 --> Total execution time: 0.0421
INFO - 2020-03-09 05:00:10 --> Config Class Initialized
INFO - 2020-03-09 05:00:10 --> Hooks Class Initialized
DEBUG - 2020-03-09 05:00:10 --> UTF-8 Support Enabled
INFO - 2020-03-09 05:00:10 --> Utf8 Class Initialized
INFO - 2020-03-09 05:00:10 --> URI Class Initialized
DEBUG - 2020-03-09 05:00:10 --> No URI present. Default controller set.
INFO - 2020-03-09 05:00:10 --> Router Class Initialized
INFO - 2020-03-09 05:00:10 --> Output Class Initialized
INFO - 2020-03-09 05:00:10 --> Security Class Initialized
DEBUG - 2020-03-09 05:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 05:00:10 --> Input Class Initialized
INFO - 2020-03-09 05:00:10 --> Language Class Initialized
INFO - 2020-03-09 05:00:10 --> Loader Class Initialized
INFO - 2020-03-09 05:00:10 --> Helper loaded: url_helper
INFO - 2020-03-09 05:00:10 --> Helper loaded: string_helper
INFO - 2020-03-09 05:00:10 --> Database Driver Class Initialized
DEBUG - 2020-03-09 05:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 05:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 05:00:10 --> Controller Class Initialized
INFO - 2020-03-09 05:00:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 05:00:10 --> Pagination Class Initialized
INFO - 2020-03-09 05:00:10 --> Model "M_show" initialized
INFO - 2020-03-09 05:00:10 --> Helper loaded: form_helper
INFO - 2020-03-09 05:00:10 --> Form Validation Class Initialized
INFO - 2020-03-09 05:00:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 05:00:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 05:00:10 --> Final output sent to browser
DEBUG - 2020-03-09 05:00:10 --> Total execution time: 0.1223
INFO - 2020-03-09 05:00:23 --> Config Class Initialized
INFO - 2020-03-09 05:00:23 --> Hooks Class Initialized
DEBUG - 2020-03-09 05:00:23 --> UTF-8 Support Enabled
INFO - 2020-03-09 05:00:23 --> Utf8 Class Initialized
INFO - 2020-03-09 05:00:23 --> URI Class Initialized
INFO - 2020-03-09 05:00:23 --> Router Class Initialized
INFO - 2020-03-09 05:00:23 --> Output Class Initialized
INFO - 2020-03-09 05:00:23 --> Security Class Initialized
DEBUG - 2020-03-09 05:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 05:00:23 --> Input Class Initialized
INFO - 2020-03-09 05:00:23 --> Language Class Initialized
INFO - 2020-03-09 05:00:23 --> Loader Class Initialized
INFO - 2020-03-09 05:00:23 --> Helper loaded: url_helper
INFO - 2020-03-09 05:00:23 --> Helper loaded: string_helper
INFO - 2020-03-09 05:00:23 --> Database Driver Class Initialized
DEBUG - 2020-03-09 05:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 05:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 05:00:23 --> Controller Class Initialized
INFO - 2020-03-09 05:00:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 05:00:23 --> Pagination Class Initialized
INFO - 2020-03-09 05:00:23 --> Model "M_show" initialized
INFO - 2020-03-09 05:00:23 --> Helper loaded: form_helper
INFO - 2020-03-09 05:00:23 --> Form Validation Class Initialized
INFO - 2020-03-09 05:00:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 05:00:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 05:00:24 --> Final output sent to browser
DEBUG - 2020-03-09 05:00:24 --> Total execution time: 0.1835
INFO - 2020-03-09 05:00:27 --> Config Class Initialized
INFO - 2020-03-09 05:00:27 --> Hooks Class Initialized
DEBUG - 2020-03-09 05:00:27 --> UTF-8 Support Enabled
INFO - 2020-03-09 05:00:27 --> Utf8 Class Initialized
INFO - 2020-03-09 05:00:27 --> URI Class Initialized
INFO - 2020-03-09 05:00:27 --> Router Class Initialized
INFO - 2020-03-09 05:00:27 --> Output Class Initialized
INFO - 2020-03-09 05:00:27 --> Security Class Initialized
DEBUG - 2020-03-09 05:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 05:00:27 --> Input Class Initialized
INFO - 2020-03-09 05:00:27 --> Language Class Initialized
INFO - 2020-03-09 05:00:27 --> Loader Class Initialized
INFO - 2020-03-09 05:00:27 --> Helper loaded: url_helper
INFO - 2020-03-09 05:00:27 --> Helper loaded: string_helper
INFO - 2020-03-09 05:00:27 --> Database Driver Class Initialized
DEBUG - 2020-03-09 05:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 05:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 05:00:27 --> Controller Class Initialized
INFO - 2020-03-09 05:00:27 --> Model "M_tiket" initialized
INFO - 2020-03-09 05:00:28 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 05:00:28 --> Model "M_pesan" initialized
INFO - 2020-03-09 05:00:28 --> Helper loaded: form_helper
INFO - 2020-03-09 05:00:28 --> Form Validation Class Initialized
INFO - 2020-03-09 05:00:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-09 05:00:28 --> Final output sent to browser
DEBUG - 2020-03-09 05:00:28 --> Total execution time: 1.0566
INFO - 2020-03-09 05:00:29 --> Config Class Initialized
INFO - 2020-03-09 05:00:29 --> Hooks Class Initialized
DEBUG - 2020-03-09 05:00:29 --> UTF-8 Support Enabled
INFO - 2020-03-09 05:00:29 --> Utf8 Class Initialized
INFO - 2020-03-09 05:00:29 --> URI Class Initialized
INFO - 2020-03-09 05:00:29 --> Router Class Initialized
INFO - 2020-03-09 05:00:29 --> Output Class Initialized
INFO - 2020-03-09 05:00:29 --> Security Class Initialized
DEBUG - 2020-03-09 05:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 05:00:29 --> Input Class Initialized
INFO - 2020-03-09 05:00:29 --> Language Class Initialized
INFO - 2020-03-09 05:00:29 --> Loader Class Initialized
INFO - 2020-03-09 05:00:29 --> Helper loaded: url_helper
INFO - 2020-03-09 05:00:29 --> Helper loaded: string_helper
INFO - 2020-03-09 05:00:29 --> Database Driver Class Initialized
DEBUG - 2020-03-09 05:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 05:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 05:00:29 --> Controller Class Initialized
INFO - 2020-03-09 05:00:29 --> Model "M_tiket" initialized
INFO - 2020-03-09 05:00:29 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 05:00:29 --> Model "M_pesan" initialized
INFO - 2020-03-09 05:00:29 --> Helper loaded: form_helper
INFO - 2020-03-09 05:00:29 --> Form Validation Class Initialized
INFO - 2020-03-09 05:00:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-09 05:00:29 --> Final output sent to browser
DEBUG - 2020-03-09 05:00:29 --> Total execution time: 0.0108
INFO - 2020-03-09 05:00:42 --> Config Class Initialized
INFO - 2020-03-09 05:00:42 --> Hooks Class Initialized
DEBUG - 2020-03-09 05:00:42 --> UTF-8 Support Enabled
INFO - 2020-03-09 05:00:42 --> Utf8 Class Initialized
INFO - 2020-03-09 05:00:42 --> URI Class Initialized
INFO - 2020-03-09 05:00:42 --> Router Class Initialized
INFO - 2020-03-09 05:00:42 --> Output Class Initialized
INFO - 2020-03-09 05:00:42 --> Security Class Initialized
DEBUG - 2020-03-09 05:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 05:00:42 --> Input Class Initialized
INFO - 2020-03-09 05:00:42 --> Language Class Initialized
INFO - 2020-03-09 05:00:42 --> Loader Class Initialized
INFO - 2020-03-09 05:00:42 --> Helper loaded: url_helper
INFO - 2020-03-09 05:00:42 --> Helper loaded: string_helper
INFO - 2020-03-09 05:00:42 --> Database Driver Class Initialized
DEBUG - 2020-03-09 05:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 05:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 05:00:42 --> Controller Class Initialized
INFO - 2020-03-09 05:00:42 --> Model "M_tiket" initialized
INFO - 2020-03-09 05:00:42 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 05:00:42 --> Model "M_pesan" initialized
INFO - 2020-03-09 05:00:42 --> Helper loaded: form_helper
INFO - 2020-03-09 05:00:42 --> Form Validation Class Initialized
INFO - 2020-03-09 05:00:42 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-09 05:00:42 --> Final output sent to browser
DEBUG - 2020-03-09 05:00:42 --> Total execution time: 0.1845
INFO - 2020-03-09 05:00:53 --> Config Class Initialized
INFO - 2020-03-09 05:00:53 --> Hooks Class Initialized
DEBUG - 2020-03-09 05:00:53 --> UTF-8 Support Enabled
INFO - 2020-03-09 05:00:53 --> Utf8 Class Initialized
INFO - 2020-03-09 05:00:53 --> URI Class Initialized
DEBUG - 2020-03-09 05:00:53 --> No URI present. Default controller set.
INFO - 2020-03-09 05:00:53 --> Router Class Initialized
INFO - 2020-03-09 05:00:53 --> Output Class Initialized
INFO - 2020-03-09 05:00:53 --> Security Class Initialized
DEBUG - 2020-03-09 05:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 05:00:53 --> Input Class Initialized
INFO - 2020-03-09 05:00:53 --> Language Class Initialized
INFO - 2020-03-09 05:00:53 --> Loader Class Initialized
INFO - 2020-03-09 05:00:53 --> Helper loaded: url_helper
INFO - 2020-03-09 05:00:53 --> Helper loaded: string_helper
INFO - 2020-03-09 05:00:53 --> Database Driver Class Initialized
DEBUG - 2020-03-09 05:00:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 05:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 05:00:53 --> Controller Class Initialized
INFO - 2020-03-09 05:00:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 05:00:53 --> Pagination Class Initialized
INFO - 2020-03-09 05:00:53 --> Model "M_show" initialized
INFO - 2020-03-09 05:00:53 --> Helper loaded: form_helper
INFO - 2020-03-09 05:00:53 --> Form Validation Class Initialized
INFO - 2020-03-09 05:00:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 05:00:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 05:00:53 --> Final output sent to browser
DEBUG - 2020-03-09 05:00:53 --> Total execution time: 0.0122
INFO - 2020-03-09 05:00:55 --> Config Class Initialized
INFO - 2020-03-09 05:00:55 --> Hooks Class Initialized
DEBUG - 2020-03-09 05:00:55 --> UTF-8 Support Enabled
INFO - 2020-03-09 05:00:55 --> Utf8 Class Initialized
INFO - 2020-03-09 05:00:55 --> URI Class Initialized
DEBUG - 2020-03-09 05:00:55 --> No URI present. Default controller set.
INFO - 2020-03-09 05:00:55 --> Router Class Initialized
INFO - 2020-03-09 05:00:55 --> Output Class Initialized
INFO - 2020-03-09 05:00:55 --> Security Class Initialized
DEBUG - 2020-03-09 05:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 05:00:55 --> Input Class Initialized
INFO - 2020-03-09 05:00:55 --> Language Class Initialized
INFO - 2020-03-09 05:00:55 --> Loader Class Initialized
INFO - 2020-03-09 05:00:55 --> Helper loaded: url_helper
INFO - 2020-03-09 05:00:55 --> Helper loaded: string_helper
INFO - 2020-03-09 05:00:55 --> Database Driver Class Initialized
DEBUG - 2020-03-09 05:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 05:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 05:00:55 --> Controller Class Initialized
INFO - 2020-03-09 05:00:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 05:00:55 --> Pagination Class Initialized
INFO - 2020-03-09 05:00:55 --> Model "M_show" initialized
INFO - 2020-03-09 05:00:55 --> Helper loaded: form_helper
INFO - 2020-03-09 05:00:55 --> Form Validation Class Initialized
INFO - 2020-03-09 05:00:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 05:00:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 05:00:55 --> Final output sent to browser
DEBUG - 2020-03-09 05:00:55 --> Total execution time: 0.0051
INFO - 2020-03-09 05:01:50 --> Config Class Initialized
INFO - 2020-03-09 05:01:50 --> Hooks Class Initialized
DEBUG - 2020-03-09 05:01:50 --> UTF-8 Support Enabled
INFO - 2020-03-09 05:01:50 --> Utf8 Class Initialized
INFO - 2020-03-09 05:01:50 --> URI Class Initialized
INFO - 2020-03-09 05:01:50 --> Router Class Initialized
INFO - 2020-03-09 05:01:50 --> Output Class Initialized
INFO - 2020-03-09 05:01:50 --> Security Class Initialized
DEBUG - 2020-03-09 05:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 05:01:50 --> Input Class Initialized
INFO - 2020-03-09 05:01:50 --> Language Class Initialized
INFO - 2020-03-09 05:01:50 --> Loader Class Initialized
INFO - 2020-03-09 05:01:50 --> Helper loaded: url_helper
INFO - 2020-03-09 05:01:50 --> Helper loaded: string_helper
INFO - 2020-03-09 05:01:50 --> Database Driver Class Initialized
DEBUG - 2020-03-09 05:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 05:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 05:01:50 --> Controller Class Initialized
INFO - 2020-03-09 05:01:50 --> Model "M_tiket" initialized
INFO - 2020-03-09 05:01:50 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 05:01:50 --> Model "M_pesan" initialized
INFO - 2020-03-09 05:01:50 --> Helper loaded: form_helper
INFO - 2020-03-09 05:01:50 --> Form Validation Class Initialized
INFO - 2020-03-09 05:01:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-09 05:01:50 --> Final output sent to browser
DEBUG - 2020-03-09 05:01:50 --> Total execution time: 0.0093
INFO - 2020-03-09 05:02:31 --> Config Class Initialized
INFO - 2020-03-09 05:02:31 --> Hooks Class Initialized
DEBUG - 2020-03-09 05:02:31 --> UTF-8 Support Enabled
INFO - 2020-03-09 05:02:31 --> Utf8 Class Initialized
INFO - 2020-03-09 05:02:31 --> URI Class Initialized
INFO - 2020-03-09 05:02:31 --> Router Class Initialized
INFO - 2020-03-09 05:02:31 --> Output Class Initialized
INFO - 2020-03-09 05:02:31 --> Security Class Initialized
DEBUG - 2020-03-09 05:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 05:02:31 --> Input Class Initialized
INFO - 2020-03-09 05:02:31 --> Language Class Initialized
INFO - 2020-03-09 05:02:31 --> Loader Class Initialized
INFO - 2020-03-09 05:02:31 --> Helper loaded: url_helper
INFO - 2020-03-09 05:02:31 --> Helper loaded: string_helper
INFO - 2020-03-09 05:02:31 --> Database Driver Class Initialized
DEBUG - 2020-03-09 05:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 05:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 05:02:31 --> Controller Class Initialized
INFO - 2020-03-09 05:02:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 05:02:31 --> Pagination Class Initialized
INFO - 2020-03-09 05:02:31 --> Model "M_show" initialized
INFO - 2020-03-09 05:02:31 --> Helper loaded: form_helper
INFO - 2020-03-09 05:02:31 --> Form Validation Class Initialized
INFO - 2020-03-09 05:02:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 05:02:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 05:02:31 --> Final output sent to browser
DEBUG - 2020-03-09 05:02:31 --> Total execution time: 0.0061
INFO - 2020-03-09 05:02:33 --> Config Class Initialized
INFO - 2020-03-09 05:02:33 --> Hooks Class Initialized
DEBUG - 2020-03-09 05:02:33 --> UTF-8 Support Enabled
INFO - 2020-03-09 05:02:33 --> Utf8 Class Initialized
INFO - 2020-03-09 05:02:33 --> URI Class Initialized
DEBUG - 2020-03-09 05:02:33 --> No URI present. Default controller set.
INFO - 2020-03-09 05:02:33 --> Router Class Initialized
INFO - 2020-03-09 05:02:33 --> Output Class Initialized
INFO - 2020-03-09 05:02:33 --> Security Class Initialized
DEBUG - 2020-03-09 05:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 05:02:33 --> Input Class Initialized
INFO - 2020-03-09 05:02:33 --> Language Class Initialized
INFO - 2020-03-09 05:02:33 --> Loader Class Initialized
INFO - 2020-03-09 05:02:33 --> Helper loaded: url_helper
INFO - 2020-03-09 05:02:33 --> Helper loaded: string_helper
INFO - 2020-03-09 05:02:33 --> Database Driver Class Initialized
DEBUG - 2020-03-09 05:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 05:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 05:02:33 --> Controller Class Initialized
INFO - 2020-03-09 05:02:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 05:02:33 --> Pagination Class Initialized
INFO - 2020-03-09 05:02:33 --> Model "M_show" initialized
INFO - 2020-03-09 05:02:33 --> Helper loaded: form_helper
INFO - 2020-03-09 05:02:33 --> Form Validation Class Initialized
INFO - 2020-03-09 05:02:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 05:02:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 05:02:33 --> Final output sent to browser
DEBUG - 2020-03-09 05:02:33 --> Total execution time: 0.0053
INFO - 2020-03-09 05:35:56 --> Config Class Initialized
INFO - 2020-03-09 05:35:56 --> Hooks Class Initialized
DEBUG - 2020-03-09 05:35:56 --> UTF-8 Support Enabled
INFO - 2020-03-09 05:35:56 --> Utf8 Class Initialized
INFO - 2020-03-09 05:35:56 --> URI Class Initialized
DEBUG - 2020-03-09 05:35:56 --> No URI present. Default controller set.
INFO - 2020-03-09 05:35:56 --> Router Class Initialized
INFO - 2020-03-09 05:35:56 --> Output Class Initialized
INFO - 2020-03-09 05:35:56 --> Security Class Initialized
DEBUG - 2020-03-09 05:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 05:35:56 --> Input Class Initialized
INFO - 2020-03-09 05:35:56 --> Language Class Initialized
INFO - 2020-03-09 05:35:56 --> Loader Class Initialized
INFO - 2020-03-09 05:35:56 --> Helper loaded: url_helper
INFO - 2020-03-09 05:35:56 --> Helper loaded: string_helper
INFO - 2020-03-09 05:35:56 --> Database Driver Class Initialized
DEBUG - 2020-03-09 05:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 05:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 05:35:56 --> Controller Class Initialized
INFO - 2020-03-09 05:35:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 05:35:56 --> Pagination Class Initialized
INFO - 2020-03-09 05:35:56 --> Model "M_show" initialized
INFO - 2020-03-09 05:35:56 --> Helper loaded: form_helper
INFO - 2020-03-09 05:35:56 --> Form Validation Class Initialized
INFO - 2020-03-09 05:35:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 05:35:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 05:35:56 --> Final output sent to browser
DEBUG - 2020-03-09 05:35:56 --> Total execution time: 0.1425
INFO - 2020-03-09 05:36:17 --> Config Class Initialized
INFO - 2020-03-09 05:36:17 --> Hooks Class Initialized
DEBUG - 2020-03-09 05:36:17 --> UTF-8 Support Enabled
INFO - 2020-03-09 05:36:17 --> Utf8 Class Initialized
INFO - 2020-03-09 05:36:17 --> URI Class Initialized
INFO - 2020-03-09 05:36:17 --> Router Class Initialized
INFO - 2020-03-09 05:36:17 --> Output Class Initialized
INFO - 2020-03-09 05:36:17 --> Security Class Initialized
DEBUG - 2020-03-09 05:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 05:36:17 --> Input Class Initialized
INFO - 2020-03-09 05:36:17 --> Language Class Initialized
INFO - 2020-03-09 05:36:17 --> Loader Class Initialized
INFO - 2020-03-09 05:36:17 --> Helper loaded: url_helper
INFO - 2020-03-09 05:36:17 --> Helper loaded: string_helper
INFO - 2020-03-09 05:36:17 --> Database Driver Class Initialized
DEBUG - 2020-03-09 05:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 05:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 05:36:17 --> Controller Class Initialized
INFO - 2020-03-09 05:36:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 05:36:17 --> Pagination Class Initialized
INFO - 2020-03-09 05:36:17 --> Model "M_show" initialized
INFO - 2020-03-09 05:36:17 --> Helper loaded: form_helper
INFO - 2020-03-09 05:36:17 --> Form Validation Class Initialized
INFO - 2020-03-09 05:36:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 05:36:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 05:36:17 --> Final output sent to browser
DEBUG - 2020-03-09 05:36:17 --> Total execution time: 0.0489
INFO - 2020-03-09 05:36:17 --> Config Class Initialized
INFO - 2020-03-09 05:36:17 --> Hooks Class Initialized
DEBUG - 2020-03-09 05:36:17 --> UTF-8 Support Enabled
INFO - 2020-03-09 05:36:17 --> Utf8 Class Initialized
INFO - 2020-03-09 05:36:17 --> URI Class Initialized
INFO - 2020-03-09 05:36:17 --> Router Class Initialized
INFO - 2020-03-09 05:36:17 --> Output Class Initialized
INFO - 2020-03-09 05:36:17 --> Security Class Initialized
DEBUG - 2020-03-09 05:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 05:36:17 --> Input Class Initialized
INFO - 2020-03-09 05:36:17 --> Language Class Initialized
ERROR - 2020-03-09 05:36:17 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-09 05:36:21 --> Config Class Initialized
INFO - 2020-03-09 05:36:21 --> Hooks Class Initialized
DEBUG - 2020-03-09 05:36:21 --> UTF-8 Support Enabled
INFO - 2020-03-09 05:36:21 --> Utf8 Class Initialized
INFO - 2020-03-09 05:36:21 --> URI Class Initialized
INFO - 2020-03-09 05:36:21 --> Router Class Initialized
INFO - 2020-03-09 05:36:21 --> Output Class Initialized
INFO - 2020-03-09 05:36:21 --> Security Class Initialized
DEBUG - 2020-03-09 05:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 05:36:21 --> Input Class Initialized
INFO - 2020-03-09 05:36:21 --> Language Class Initialized
INFO - 2020-03-09 05:36:21 --> Loader Class Initialized
INFO - 2020-03-09 05:36:21 --> Helper loaded: url_helper
INFO - 2020-03-09 05:36:21 --> Helper loaded: string_helper
INFO - 2020-03-09 05:36:21 --> Database Driver Class Initialized
DEBUG - 2020-03-09 05:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 05:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 05:36:21 --> Controller Class Initialized
INFO - 2020-03-09 05:36:21 --> Model "M_tiket" initialized
INFO - 2020-03-09 05:36:21 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 05:36:21 --> Model "M_pesan" initialized
INFO - 2020-03-09 05:36:21 --> Helper loaded: form_helper
INFO - 2020-03-09 05:36:21 --> Form Validation Class Initialized
INFO - 2020-03-09 05:36:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-09 05:36:21 --> Final output sent to browser
DEBUG - 2020-03-09 05:36:21 --> Total execution time: 0.0756
INFO - 2020-03-09 05:39:53 --> Config Class Initialized
INFO - 2020-03-09 05:39:53 --> Hooks Class Initialized
INFO - 2020-03-09 05:39:53 --> Config Class Initialized
INFO - 2020-03-09 05:39:53 --> Hooks Class Initialized
DEBUG - 2020-03-09 05:39:53 --> UTF-8 Support Enabled
INFO - 2020-03-09 05:39:53 --> Utf8 Class Initialized
DEBUG - 2020-03-09 05:39:53 --> UTF-8 Support Enabled
INFO - 2020-03-09 05:39:53 --> Utf8 Class Initialized
INFO - 2020-03-09 05:39:53 --> URI Class Initialized
INFO - 2020-03-09 05:39:53 --> URI Class Initialized
INFO - 2020-03-09 05:39:53 --> Router Class Initialized
INFO - 2020-03-09 05:39:53 --> Router Class Initialized
INFO - 2020-03-09 05:39:53 --> Output Class Initialized
INFO - 2020-03-09 05:39:53 --> Output Class Initialized
INFO - 2020-03-09 05:39:53 --> Security Class Initialized
INFO - 2020-03-09 05:39:53 --> Security Class Initialized
DEBUG - 2020-03-09 05:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 05:39:53 --> Input Class Initialized
INFO - 2020-03-09 05:39:53 --> Language Class Initialized
DEBUG - 2020-03-09 05:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 05:39:53 --> Input Class Initialized
INFO - 2020-03-09 05:39:53 --> Language Class Initialized
INFO - 2020-03-09 05:39:53 --> Loader Class Initialized
INFO - 2020-03-09 05:39:53 --> Loader Class Initialized
INFO - 2020-03-09 05:39:53 --> Helper loaded: url_helper
INFO - 2020-03-09 05:39:53 --> Helper loaded: string_helper
INFO - 2020-03-09 05:39:53 --> Helper loaded: url_helper
INFO - 2020-03-09 05:39:53 --> Helper loaded: string_helper
INFO - 2020-03-09 05:39:53 --> Database Driver Class Initialized
INFO - 2020-03-09 05:39:53 --> Database Driver Class Initialized
DEBUG - 2020-03-09 05:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-03-09 05:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 05:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 05:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 05:39:53 --> Controller Class Initialized
INFO - 2020-03-09 05:39:53 --> Controller Class Initialized
INFO - 2020-03-09 05:39:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 05:39:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 05:39:53 --> Pagination Class Initialized
INFO - 2020-03-09 05:39:53 --> Pagination Class Initialized
INFO - 2020-03-09 05:39:53 --> Model "M_show" initialized
INFO - 2020-03-09 05:39:53 --> Model "M_show" initialized
INFO - 2020-03-09 05:39:53 --> Helper loaded: form_helper
INFO - 2020-03-09 05:39:53 --> Form Validation Class Initialized
INFO - 2020-03-09 05:39:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 05:39:53 --> Helper loaded: form_helper
INFO - 2020-03-09 05:39:53 --> Form Validation Class Initialized
INFO - 2020-03-09 05:39:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 05:39:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/hub.php
INFO - 2020-03-09 05:39:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/hub.php
INFO - 2020-03-09 05:39:54 --> Final output sent to browser
INFO - 2020-03-09 05:39:54 --> Final output sent to browser
DEBUG - 2020-03-09 05:39:54 --> Total execution time: 0.2992
DEBUG - 2020-03-09 05:39:54 --> Total execution time: 0.2991
INFO - 2020-03-09 05:40:12 --> Config Class Initialized
INFO - 2020-03-09 05:40:12 --> Hooks Class Initialized
DEBUG - 2020-03-09 05:40:12 --> UTF-8 Support Enabled
INFO - 2020-03-09 05:40:12 --> Utf8 Class Initialized
INFO - 2020-03-09 05:40:12 --> URI Class Initialized
INFO - 2020-03-09 05:40:12 --> Router Class Initialized
INFO - 2020-03-09 05:40:12 --> Output Class Initialized
INFO - 2020-03-09 05:40:12 --> Security Class Initialized
DEBUG - 2020-03-09 05:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 05:40:12 --> Input Class Initialized
INFO - 2020-03-09 05:40:12 --> Language Class Initialized
INFO - 2020-03-09 05:40:12 --> Loader Class Initialized
INFO - 2020-03-09 05:40:12 --> Helper loaded: url_helper
INFO - 2020-03-09 05:40:12 --> Helper loaded: string_helper
INFO - 2020-03-09 05:40:12 --> Database Driver Class Initialized
DEBUG - 2020-03-09 05:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 05:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 05:40:12 --> Controller Class Initialized
INFO - 2020-03-09 05:40:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 05:40:12 --> Pagination Class Initialized
INFO - 2020-03-09 05:40:12 --> Model "M_show" initialized
INFO - 2020-03-09 05:40:12 --> Helper loaded: form_helper
INFO - 2020-03-09 05:40:12 --> Form Validation Class Initialized
INFO - 2020-03-09 05:40:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 05:40:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tentang.php
INFO - 2020-03-09 05:40:12 --> Final output sent to browser
DEBUG - 2020-03-09 05:40:12 --> Total execution time: 0.0231
INFO - 2020-03-09 05:40:12 --> Config Class Initialized
INFO - 2020-03-09 05:40:12 --> Hooks Class Initialized
DEBUG - 2020-03-09 05:40:12 --> UTF-8 Support Enabled
INFO - 2020-03-09 05:40:12 --> Utf8 Class Initialized
INFO - 2020-03-09 05:40:12 --> URI Class Initialized
INFO - 2020-03-09 05:40:12 --> Router Class Initialized
INFO - 2020-03-09 05:40:12 --> Output Class Initialized
INFO - 2020-03-09 05:40:12 --> Security Class Initialized
DEBUG - 2020-03-09 05:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 05:40:12 --> Input Class Initialized
INFO - 2020-03-09 05:40:12 --> Language Class Initialized
INFO - 2020-03-09 05:40:12 --> Loader Class Initialized
INFO - 2020-03-09 05:40:12 --> Helper loaded: url_helper
INFO - 2020-03-09 05:40:12 --> Helper loaded: string_helper
INFO - 2020-03-09 05:40:12 --> Database Driver Class Initialized
DEBUG - 2020-03-09 05:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 05:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 05:40:12 --> Controller Class Initialized
INFO - 2020-03-09 05:40:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 05:40:12 --> Pagination Class Initialized
INFO - 2020-03-09 05:40:12 --> Model "M_show" initialized
INFO - 2020-03-09 05:40:12 --> Helper loaded: form_helper
INFO - 2020-03-09 05:40:12 --> Form Validation Class Initialized
INFO - 2020-03-09 05:40:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 05:40:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tentang.php
INFO - 2020-03-09 05:40:12 --> Final output sent to browser
DEBUG - 2020-03-09 05:40:12 --> Total execution time: 0.0071
INFO - 2020-03-09 05:40:19 --> Config Class Initialized
INFO - 2020-03-09 05:40:19 --> Hooks Class Initialized
DEBUG - 2020-03-09 05:40:19 --> UTF-8 Support Enabled
INFO - 2020-03-09 05:40:19 --> Utf8 Class Initialized
INFO - 2020-03-09 05:40:19 --> URI Class Initialized
INFO - 2020-03-09 05:40:19 --> Router Class Initialized
INFO - 2020-03-09 05:40:19 --> Output Class Initialized
INFO - 2020-03-09 05:40:19 --> Security Class Initialized
DEBUG - 2020-03-09 05:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 05:40:19 --> Input Class Initialized
INFO - 2020-03-09 05:40:19 --> Language Class Initialized
INFO - 2020-03-09 05:40:19 --> Loader Class Initialized
INFO - 2020-03-09 05:40:19 --> Helper loaded: url_helper
INFO - 2020-03-09 05:40:19 --> Helper loaded: string_helper
INFO - 2020-03-09 05:40:19 --> Database Driver Class Initialized
DEBUG - 2020-03-09 05:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 05:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 05:40:19 --> Controller Class Initialized
INFO - 2020-03-09 05:40:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 05:40:19 --> Pagination Class Initialized
INFO - 2020-03-09 05:40:19 --> Model "M_show" initialized
INFO - 2020-03-09 05:40:19 --> Helper loaded: form_helper
INFO - 2020-03-09 05:40:19 --> Form Validation Class Initialized
INFO - 2020-03-09 05:40:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 05:40:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/hub.php
INFO - 2020-03-09 05:40:19 --> Final output sent to browser
DEBUG - 2020-03-09 05:40:19 --> Total execution time: 0.0100
INFO - 2020-03-09 05:50:45 --> Config Class Initialized
INFO - 2020-03-09 05:50:45 --> Hooks Class Initialized
DEBUG - 2020-03-09 05:50:45 --> UTF-8 Support Enabled
INFO - 2020-03-09 05:50:45 --> Utf8 Class Initialized
INFO - 2020-03-09 05:50:45 --> URI Class Initialized
DEBUG - 2020-03-09 05:50:45 --> No URI present. Default controller set.
INFO - 2020-03-09 05:50:45 --> Router Class Initialized
INFO - 2020-03-09 05:50:45 --> Output Class Initialized
INFO - 2020-03-09 05:50:45 --> Security Class Initialized
DEBUG - 2020-03-09 05:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 05:50:45 --> Input Class Initialized
INFO - 2020-03-09 05:50:45 --> Language Class Initialized
INFO - 2020-03-09 05:50:45 --> Loader Class Initialized
INFO - 2020-03-09 05:50:45 --> Helper loaded: url_helper
INFO - 2020-03-09 05:50:45 --> Helper loaded: string_helper
INFO - 2020-03-09 05:50:45 --> Database Driver Class Initialized
DEBUG - 2020-03-09 05:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 05:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 05:50:46 --> Controller Class Initialized
INFO - 2020-03-09 05:50:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 05:50:46 --> Pagination Class Initialized
INFO - 2020-03-09 05:50:46 --> Model "M_show" initialized
INFO - 2020-03-09 05:50:46 --> Helper loaded: form_helper
INFO - 2020-03-09 05:50:46 --> Form Validation Class Initialized
INFO - 2020-03-09 05:50:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 05:50:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 05:50:46 --> Final output sent to browser
DEBUG - 2020-03-09 05:50:46 --> Total execution time: 0.1760
INFO - 2020-03-09 06:22:28 --> Config Class Initialized
INFO - 2020-03-09 06:22:28 --> Hooks Class Initialized
DEBUG - 2020-03-09 06:22:28 --> UTF-8 Support Enabled
INFO - 2020-03-09 06:22:28 --> Utf8 Class Initialized
INFO - 2020-03-09 06:22:28 --> URI Class Initialized
DEBUG - 2020-03-09 06:22:28 --> No URI present. Default controller set.
INFO - 2020-03-09 06:22:28 --> Router Class Initialized
INFO - 2020-03-09 06:22:28 --> Output Class Initialized
INFO - 2020-03-09 06:22:28 --> Security Class Initialized
DEBUG - 2020-03-09 06:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 06:22:28 --> Input Class Initialized
INFO - 2020-03-09 06:22:28 --> Language Class Initialized
INFO - 2020-03-09 06:22:28 --> Loader Class Initialized
INFO - 2020-03-09 06:22:28 --> Helper loaded: url_helper
INFO - 2020-03-09 06:22:28 --> Helper loaded: string_helper
INFO - 2020-03-09 06:22:28 --> Database Driver Class Initialized
DEBUG - 2020-03-09 06:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 06:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 06:22:28 --> Controller Class Initialized
INFO - 2020-03-09 06:22:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 06:22:28 --> Pagination Class Initialized
INFO - 2020-03-09 06:22:28 --> Model "M_show" initialized
INFO - 2020-03-09 06:22:28 --> Helper loaded: form_helper
INFO - 2020-03-09 06:22:28 --> Form Validation Class Initialized
INFO - 2020-03-09 06:22:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 06:22:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 06:22:28 --> Final output sent to browser
DEBUG - 2020-03-09 06:22:28 --> Total execution time: 0.0442
INFO - 2020-03-09 06:22:46 --> Config Class Initialized
INFO - 2020-03-09 06:22:46 --> Hooks Class Initialized
DEBUG - 2020-03-09 06:22:46 --> UTF-8 Support Enabled
INFO - 2020-03-09 06:22:46 --> Utf8 Class Initialized
INFO - 2020-03-09 06:22:46 --> URI Class Initialized
INFO - 2020-03-09 06:22:46 --> Router Class Initialized
INFO - 2020-03-09 06:22:46 --> Output Class Initialized
INFO - 2020-03-09 06:22:46 --> Security Class Initialized
DEBUG - 2020-03-09 06:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 06:22:46 --> Input Class Initialized
INFO - 2020-03-09 06:22:46 --> Language Class Initialized
INFO - 2020-03-09 06:22:46 --> Loader Class Initialized
INFO - 2020-03-09 06:22:46 --> Helper loaded: url_helper
INFO - 2020-03-09 06:22:46 --> Helper loaded: string_helper
INFO - 2020-03-09 06:22:46 --> Database Driver Class Initialized
DEBUG - 2020-03-09 06:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 06:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 06:22:46 --> Controller Class Initialized
INFO - 2020-03-09 06:22:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 06:22:46 --> Pagination Class Initialized
INFO - 2020-03-09 06:22:46 --> Model "M_show" initialized
INFO - 2020-03-09 06:22:46 --> Helper loaded: form_helper
INFO - 2020-03-09 06:22:46 --> Form Validation Class Initialized
INFO - 2020-03-09 06:22:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 06:22:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 06:22:46 --> Final output sent to browser
DEBUG - 2020-03-09 06:22:46 --> Total execution time: 0.0247
INFO - 2020-03-09 06:22:53 --> Config Class Initialized
INFO - 2020-03-09 06:22:53 --> Hooks Class Initialized
DEBUG - 2020-03-09 06:22:53 --> UTF-8 Support Enabled
INFO - 2020-03-09 06:22:53 --> Utf8 Class Initialized
INFO - 2020-03-09 06:22:53 --> URI Class Initialized
INFO - 2020-03-09 06:22:53 --> Router Class Initialized
INFO - 2020-03-09 06:22:53 --> Output Class Initialized
INFO - 2020-03-09 06:22:53 --> Security Class Initialized
DEBUG - 2020-03-09 06:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 06:22:53 --> Input Class Initialized
INFO - 2020-03-09 06:22:53 --> Language Class Initialized
INFO - 2020-03-09 06:22:53 --> Loader Class Initialized
INFO - 2020-03-09 06:22:53 --> Helper loaded: url_helper
INFO - 2020-03-09 06:22:53 --> Helper loaded: string_helper
INFO - 2020-03-09 06:22:53 --> Database Driver Class Initialized
DEBUG - 2020-03-09 06:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 06:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 06:22:53 --> Controller Class Initialized
INFO - 2020-03-09 06:22:53 --> Model "M_tiket" initialized
INFO - 2020-03-09 06:22:53 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 06:22:53 --> Model "M_pesan" initialized
INFO - 2020-03-09 06:22:53 --> Helper loaded: form_helper
INFO - 2020-03-09 06:22:53 --> Form Validation Class Initialized
INFO - 2020-03-09 06:22:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-09 06:22:53 --> Final output sent to browser
DEBUG - 2020-03-09 06:22:53 --> Total execution time: 0.0405
INFO - 2020-03-09 06:23:10 --> Config Class Initialized
INFO - 2020-03-09 06:23:10 --> Hooks Class Initialized
DEBUG - 2020-03-09 06:23:10 --> UTF-8 Support Enabled
INFO - 2020-03-09 06:23:10 --> Utf8 Class Initialized
INFO - 2020-03-09 06:23:10 --> URI Class Initialized
INFO - 2020-03-09 06:23:10 --> Router Class Initialized
INFO - 2020-03-09 06:23:10 --> Output Class Initialized
INFO - 2020-03-09 06:23:10 --> Security Class Initialized
DEBUG - 2020-03-09 06:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 06:23:10 --> Input Class Initialized
INFO - 2020-03-09 06:23:10 --> Language Class Initialized
INFO - 2020-03-09 06:23:10 --> Loader Class Initialized
INFO - 2020-03-09 06:23:10 --> Helper loaded: url_helper
INFO - 2020-03-09 06:23:10 --> Helper loaded: string_helper
INFO - 2020-03-09 06:23:10 --> Database Driver Class Initialized
DEBUG - 2020-03-09 06:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 06:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 06:23:10 --> Controller Class Initialized
INFO - 2020-03-09 06:23:10 --> Model "M_tiket" initialized
INFO - 2020-03-09 06:23:10 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 06:23:10 --> Model "M_pesan" initialized
INFO - 2020-03-09 06:23:10 --> Helper loaded: form_helper
INFO - 2020-03-09 06:23:10 --> Form Validation Class Initialized
INFO - 2020-03-09 06:23:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-09 06:23:10 --> Final output sent to browser
DEBUG - 2020-03-09 06:23:10 --> Total execution time: 0.0110
INFO - 2020-03-09 06:27:02 --> Config Class Initialized
INFO - 2020-03-09 06:27:02 --> Hooks Class Initialized
DEBUG - 2020-03-09 06:27:02 --> UTF-8 Support Enabled
INFO - 2020-03-09 06:27:02 --> Utf8 Class Initialized
INFO - 2020-03-09 06:27:02 --> URI Class Initialized
INFO - 2020-03-09 06:27:02 --> Router Class Initialized
INFO - 2020-03-09 06:27:02 --> Output Class Initialized
INFO - 2020-03-09 06:27:02 --> Security Class Initialized
DEBUG - 2020-03-09 06:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 06:27:02 --> Input Class Initialized
INFO - 2020-03-09 06:27:02 --> Language Class Initialized
INFO - 2020-03-09 06:27:02 --> Loader Class Initialized
INFO - 2020-03-09 06:27:02 --> Helper loaded: url_helper
INFO - 2020-03-09 06:27:02 --> Helper loaded: string_helper
INFO - 2020-03-09 06:27:02 --> Database Driver Class Initialized
DEBUG - 2020-03-09 06:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 06:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 06:27:02 --> Controller Class Initialized
INFO - 2020-03-09 06:27:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 06:27:02 --> Pagination Class Initialized
INFO - 2020-03-09 06:27:02 --> Model "M_show" initialized
INFO - 2020-03-09 06:27:02 --> Helper loaded: form_helper
INFO - 2020-03-09 06:27:02 --> Form Validation Class Initialized
INFO - 2020-03-09 06:27:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 06:27:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 06:27:02 --> Final output sent to browser
DEBUG - 2020-03-09 06:27:02 --> Total execution time: 0.0636
INFO - 2020-03-09 07:18:57 --> Config Class Initialized
INFO - 2020-03-09 07:18:57 --> Hooks Class Initialized
DEBUG - 2020-03-09 07:18:57 --> UTF-8 Support Enabled
INFO - 2020-03-09 07:18:57 --> Utf8 Class Initialized
INFO - 2020-03-09 07:18:57 --> URI Class Initialized
DEBUG - 2020-03-09 07:18:57 --> No URI present. Default controller set.
INFO - 2020-03-09 07:18:57 --> Router Class Initialized
INFO - 2020-03-09 07:18:57 --> Output Class Initialized
INFO - 2020-03-09 07:18:57 --> Security Class Initialized
DEBUG - 2020-03-09 07:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 07:18:57 --> Input Class Initialized
INFO - 2020-03-09 07:18:57 --> Language Class Initialized
INFO - 2020-03-09 07:18:57 --> Loader Class Initialized
INFO - 2020-03-09 07:18:57 --> Helper loaded: url_helper
INFO - 2020-03-09 07:18:57 --> Helper loaded: string_helper
INFO - 2020-03-09 07:18:57 --> Database Driver Class Initialized
DEBUG - 2020-03-09 07:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 07:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 07:18:57 --> Controller Class Initialized
INFO - 2020-03-09 07:18:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 07:18:57 --> Pagination Class Initialized
INFO - 2020-03-09 07:18:57 --> Model "M_show" initialized
INFO - 2020-03-09 07:18:57 --> Helper loaded: form_helper
INFO - 2020-03-09 07:18:57 --> Form Validation Class Initialized
INFO - 2020-03-09 07:18:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 07:18:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 07:18:57 --> Final output sent to browser
DEBUG - 2020-03-09 07:18:57 --> Total execution time: 0.2067
INFO - 2020-03-09 07:19:05 --> Config Class Initialized
INFO - 2020-03-09 07:19:05 --> Hooks Class Initialized
DEBUG - 2020-03-09 07:19:05 --> UTF-8 Support Enabled
INFO - 2020-03-09 07:19:05 --> Utf8 Class Initialized
INFO - 2020-03-09 07:19:05 --> URI Class Initialized
INFO - 2020-03-09 07:19:05 --> Router Class Initialized
INFO - 2020-03-09 07:19:05 --> Output Class Initialized
INFO - 2020-03-09 07:19:05 --> Security Class Initialized
DEBUG - 2020-03-09 07:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 07:19:05 --> Input Class Initialized
INFO - 2020-03-09 07:19:05 --> Language Class Initialized
INFO - 2020-03-09 07:19:05 --> Loader Class Initialized
INFO - 2020-03-09 07:19:05 --> Helper loaded: url_helper
INFO - 2020-03-09 07:19:05 --> Helper loaded: string_helper
INFO - 2020-03-09 07:19:05 --> Database Driver Class Initialized
DEBUG - 2020-03-09 07:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 07:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 07:19:05 --> Controller Class Initialized
INFO - 2020-03-09 07:19:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 07:19:05 --> Pagination Class Initialized
INFO - 2020-03-09 07:19:05 --> Model "M_show" initialized
INFO - 2020-03-09 07:19:05 --> Helper loaded: form_helper
INFO - 2020-03-09 07:19:05 --> Form Validation Class Initialized
INFO - 2020-03-09 07:19:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 07:19:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 07:19:05 --> Final output sent to browser
DEBUG - 2020-03-09 07:19:05 --> Total execution time: 0.0280
INFO - 2020-03-09 07:19:06 --> Config Class Initialized
INFO - 2020-03-09 07:19:06 --> Hooks Class Initialized
DEBUG - 2020-03-09 07:19:06 --> UTF-8 Support Enabled
INFO - 2020-03-09 07:19:06 --> Utf8 Class Initialized
INFO - 2020-03-09 07:19:06 --> URI Class Initialized
INFO - 2020-03-09 07:19:06 --> Router Class Initialized
INFO - 2020-03-09 07:19:06 --> Output Class Initialized
INFO - 2020-03-09 07:19:06 --> Security Class Initialized
DEBUG - 2020-03-09 07:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 07:19:06 --> Input Class Initialized
INFO - 2020-03-09 07:19:06 --> Language Class Initialized
ERROR - 2020-03-09 07:19:06 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-09 07:19:08 --> Config Class Initialized
INFO - 2020-03-09 07:19:08 --> Hooks Class Initialized
DEBUG - 2020-03-09 07:19:08 --> UTF-8 Support Enabled
INFO - 2020-03-09 07:19:08 --> Utf8 Class Initialized
INFO - 2020-03-09 07:19:08 --> URI Class Initialized
INFO - 2020-03-09 07:19:08 --> Router Class Initialized
INFO - 2020-03-09 07:19:08 --> Output Class Initialized
INFO - 2020-03-09 07:19:08 --> Security Class Initialized
DEBUG - 2020-03-09 07:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 07:19:08 --> Input Class Initialized
INFO - 2020-03-09 07:19:08 --> Language Class Initialized
INFO - 2020-03-09 07:19:08 --> Loader Class Initialized
INFO - 2020-03-09 07:19:08 --> Helper loaded: url_helper
INFO - 2020-03-09 07:19:08 --> Helper loaded: string_helper
INFO - 2020-03-09 07:19:08 --> Database Driver Class Initialized
DEBUG - 2020-03-09 07:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 07:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 07:19:08 --> Controller Class Initialized
INFO - 2020-03-09 07:19:08 --> Model "M_tiket" initialized
INFO - 2020-03-09 07:19:08 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 07:19:08 --> Model "M_pesan" initialized
INFO - 2020-03-09 07:19:08 --> Helper loaded: form_helper
INFO - 2020-03-09 07:19:08 --> Form Validation Class Initialized
INFO - 2020-03-09 07:19:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-09 07:19:08 --> Final output sent to browser
DEBUG - 2020-03-09 07:19:08 --> Total execution time: 0.1628
INFO - 2020-03-09 07:19:13 --> Config Class Initialized
INFO - 2020-03-09 07:19:13 --> Hooks Class Initialized
DEBUG - 2020-03-09 07:19:13 --> UTF-8 Support Enabled
INFO - 2020-03-09 07:19:13 --> Utf8 Class Initialized
INFO - 2020-03-09 07:19:13 --> URI Class Initialized
INFO - 2020-03-09 07:19:13 --> Router Class Initialized
INFO - 2020-03-09 07:19:13 --> Output Class Initialized
INFO - 2020-03-09 07:19:13 --> Security Class Initialized
DEBUG - 2020-03-09 07:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 07:19:13 --> Input Class Initialized
INFO - 2020-03-09 07:19:13 --> Language Class Initialized
INFO - 2020-03-09 07:19:13 --> Loader Class Initialized
INFO - 2020-03-09 07:19:13 --> Helper loaded: url_helper
INFO - 2020-03-09 07:19:13 --> Helper loaded: string_helper
INFO - 2020-03-09 07:19:13 --> Database Driver Class Initialized
DEBUG - 2020-03-09 07:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 07:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 07:19:13 --> Controller Class Initialized
INFO - 2020-03-09 07:19:13 --> Model "M_tiket" initialized
INFO - 2020-03-09 07:19:13 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 07:19:13 --> Model "M_pesan" initialized
INFO - 2020-03-09 07:19:13 --> Helper loaded: form_helper
INFO - 2020-03-09 07:19:13 --> Form Validation Class Initialized
INFO - 2020-03-09 07:19:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-09 07:19:13 --> Final output sent to browser
DEBUG - 2020-03-09 07:19:13 --> Total execution time: 0.0183
INFO - 2020-03-09 07:20:31 --> Config Class Initialized
INFO - 2020-03-09 07:20:31 --> Hooks Class Initialized
DEBUG - 2020-03-09 07:20:31 --> UTF-8 Support Enabled
INFO - 2020-03-09 07:20:31 --> Utf8 Class Initialized
INFO - 2020-03-09 07:20:31 --> URI Class Initialized
DEBUG - 2020-03-09 07:20:31 --> No URI present. Default controller set.
INFO - 2020-03-09 07:20:31 --> Router Class Initialized
INFO - 2020-03-09 07:20:31 --> Output Class Initialized
INFO - 2020-03-09 07:20:31 --> Security Class Initialized
DEBUG - 2020-03-09 07:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 07:20:31 --> Input Class Initialized
INFO - 2020-03-09 07:20:31 --> Language Class Initialized
INFO - 2020-03-09 07:20:31 --> Loader Class Initialized
INFO - 2020-03-09 07:20:31 --> Helper loaded: url_helper
INFO - 2020-03-09 07:20:31 --> Helper loaded: string_helper
INFO - 2020-03-09 07:20:31 --> Database Driver Class Initialized
DEBUG - 2020-03-09 07:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 07:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 07:20:31 --> Controller Class Initialized
INFO - 2020-03-09 07:20:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 07:20:31 --> Pagination Class Initialized
INFO - 2020-03-09 07:20:31 --> Model "M_show" initialized
INFO - 2020-03-09 07:20:31 --> Helper loaded: form_helper
INFO - 2020-03-09 07:20:31 --> Form Validation Class Initialized
INFO - 2020-03-09 07:20:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 07:20:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 07:20:31 --> Final output sent to browser
DEBUG - 2020-03-09 07:20:31 --> Total execution time: 0.0446
INFO - 2020-03-09 07:20:33 --> Config Class Initialized
INFO - 2020-03-09 07:20:33 --> Hooks Class Initialized
DEBUG - 2020-03-09 07:20:33 --> UTF-8 Support Enabled
INFO - 2020-03-09 07:20:33 --> Utf8 Class Initialized
INFO - 2020-03-09 07:20:33 --> URI Class Initialized
DEBUG - 2020-03-09 07:20:33 --> No URI present. Default controller set.
INFO - 2020-03-09 07:20:33 --> Router Class Initialized
INFO - 2020-03-09 07:20:33 --> Output Class Initialized
INFO - 2020-03-09 07:20:33 --> Security Class Initialized
DEBUG - 2020-03-09 07:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 07:20:33 --> Input Class Initialized
INFO - 2020-03-09 07:20:33 --> Language Class Initialized
INFO - 2020-03-09 07:20:33 --> Loader Class Initialized
INFO - 2020-03-09 07:20:33 --> Helper loaded: url_helper
INFO - 2020-03-09 07:20:33 --> Helper loaded: string_helper
INFO - 2020-03-09 07:20:33 --> Database Driver Class Initialized
DEBUG - 2020-03-09 07:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 07:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 07:20:33 --> Controller Class Initialized
INFO - 2020-03-09 07:20:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 07:20:33 --> Pagination Class Initialized
INFO - 2020-03-09 07:20:33 --> Model "M_show" initialized
INFO - 2020-03-09 07:20:33 --> Helper loaded: form_helper
INFO - 2020-03-09 07:20:33 --> Form Validation Class Initialized
INFO - 2020-03-09 07:20:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 07:20:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 07:20:33 --> Final output sent to browser
DEBUG - 2020-03-09 07:20:33 --> Total execution time: 0.0057
INFO - 2020-03-09 07:24:00 --> Config Class Initialized
INFO - 2020-03-09 07:24:00 --> Hooks Class Initialized
DEBUG - 2020-03-09 07:24:00 --> UTF-8 Support Enabled
INFO - 2020-03-09 07:24:00 --> Utf8 Class Initialized
INFO - 2020-03-09 07:24:00 --> URI Class Initialized
DEBUG - 2020-03-09 07:24:00 --> No URI present. Default controller set.
INFO - 2020-03-09 07:24:00 --> Router Class Initialized
INFO - 2020-03-09 07:24:00 --> Output Class Initialized
INFO - 2020-03-09 07:24:00 --> Security Class Initialized
DEBUG - 2020-03-09 07:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 07:24:00 --> Input Class Initialized
INFO - 2020-03-09 07:24:00 --> Language Class Initialized
INFO - 2020-03-09 07:24:00 --> Loader Class Initialized
INFO - 2020-03-09 07:24:00 --> Helper loaded: url_helper
INFO - 2020-03-09 07:24:00 --> Helper loaded: string_helper
INFO - 2020-03-09 07:24:00 --> Database Driver Class Initialized
DEBUG - 2020-03-09 07:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 07:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 07:24:00 --> Controller Class Initialized
INFO - 2020-03-09 07:24:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 07:24:00 --> Pagination Class Initialized
INFO - 2020-03-09 07:24:00 --> Model "M_show" initialized
INFO - 2020-03-09 07:24:00 --> Helper loaded: form_helper
INFO - 2020-03-09 07:24:00 --> Form Validation Class Initialized
INFO - 2020-03-09 07:24:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 07:24:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 07:24:00 --> Final output sent to browser
DEBUG - 2020-03-09 07:24:00 --> Total execution time: 0.0448
INFO - 2020-03-09 07:24:05 --> Config Class Initialized
INFO - 2020-03-09 07:24:05 --> Hooks Class Initialized
DEBUG - 2020-03-09 07:24:05 --> UTF-8 Support Enabled
INFO - 2020-03-09 07:24:05 --> Utf8 Class Initialized
INFO - 2020-03-09 07:24:05 --> URI Class Initialized
INFO - 2020-03-09 07:24:05 --> Router Class Initialized
INFO - 2020-03-09 07:24:05 --> Output Class Initialized
INFO - 2020-03-09 07:24:05 --> Security Class Initialized
DEBUG - 2020-03-09 07:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 07:24:05 --> Input Class Initialized
INFO - 2020-03-09 07:24:05 --> Language Class Initialized
INFO - 2020-03-09 07:24:05 --> Loader Class Initialized
INFO - 2020-03-09 07:24:05 --> Helper loaded: url_helper
INFO - 2020-03-09 07:24:05 --> Helper loaded: string_helper
INFO - 2020-03-09 07:24:05 --> Database Driver Class Initialized
DEBUG - 2020-03-09 07:24:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 07:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 07:24:05 --> Controller Class Initialized
INFO - 2020-03-09 07:24:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 07:24:05 --> Pagination Class Initialized
INFO - 2020-03-09 07:24:05 --> Model "M_show" initialized
INFO - 2020-03-09 07:24:05 --> Helper loaded: form_helper
INFO - 2020-03-09 07:24:05 --> Form Validation Class Initialized
INFO - 2020-03-09 07:24:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 07:24:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 07:24:05 --> Final output sent to browser
DEBUG - 2020-03-09 07:24:05 --> Total execution time: 0.0130
INFO - 2020-03-09 07:24:08 --> Config Class Initialized
INFO - 2020-03-09 07:24:08 --> Hooks Class Initialized
DEBUG - 2020-03-09 07:24:08 --> UTF-8 Support Enabled
INFO - 2020-03-09 07:24:08 --> Utf8 Class Initialized
INFO - 2020-03-09 07:24:08 --> URI Class Initialized
INFO - 2020-03-09 07:24:08 --> Router Class Initialized
INFO - 2020-03-09 07:24:08 --> Output Class Initialized
INFO - 2020-03-09 07:24:08 --> Security Class Initialized
DEBUG - 2020-03-09 07:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 07:24:08 --> Input Class Initialized
INFO - 2020-03-09 07:24:08 --> Language Class Initialized
INFO - 2020-03-09 07:24:08 --> Loader Class Initialized
INFO - 2020-03-09 07:24:08 --> Helper loaded: url_helper
INFO - 2020-03-09 07:24:08 --> Helper loaded: string_helper
INFO - 2020-03-09 07:24:08 --> Database Driver Class Initialized
DEBUG - 2020-03-09 07:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 07:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 07:24:08 --> Controller Class Initialized
INFO - 2020-03-09 07:24:08 --> Model "M_tiket" initialized
INFO - 2020-03-09 07:24:08 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 07:24:08 --> Model "M_pesan" initialized
INFO - 2020-03-09 07:24:08 --> Helper loaded: form_helper
INFO - 2020-03-09 07:24:08 --> Form Validation Class Initialized
INFO - 2020-03-09 07:24:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-09 07:24:08 --> Final output sent to browser
DEBUG - 2020-03-09 07:24:08 --> Total execution time: 0.0154
INFO - 2020-03-09 07:24:26 --> Config Class Initialized
INFO - 2020-03-09 07:24:26 --> Hooks Class Initialized
DEBUG - 2020-03-09 07:24:26 --> UTF-8 Support Enabled
INFO - 2020-03-09 07:24:26 --> Utf8 Class Initialized
INFO - 2020-03-09 07:24:26 --> URI Class Initialized
INFO - 2020-03-09 07:24:26 --> Router Class Initialized
INFO - 2020-03-09 07:24:26 --> Output Class Initialized
INFO - 2020-03-09 07:24:26 --> Security Class Initialized
DEBUG - 2020-03-09 07:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 07:24:26 --> Input Class Initialized
INFO - 2020-03-09 07:24:26 --> Language Class Initialized
INFO - 2020-03-09 07:24:26 --> Loader Class Initialized
INFO - 2020-03-09 07:24:26 --> Helper loaded: url_helper
INFO - 2020-03-09 07:24:26 --> Helper loaded: string_helper
INFO - 2020-03-09 07:24:26 --> Database Driver Class Initialized
DEBUG - 2020-03-09 07:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 07:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 07:24:26 --> Controller Class Initialized
INFO - 2020-03-09 07:24:26 --> Model "M_tiket" initialized
INFO - 2020-03-09 07:24:26 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 07:24:26 --> Model "M_pesan" initialized
INFO - 2020-03-09 07:24:26 --> Helper loaded: form_helper
INFO - 2020-03-09 07:24:26 --> Form Validation Class Initialized
INFO - 2020-03-09 07:24:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-09 07:24:26 --> Final output sent to browser
DEBUG - 2020-03-09 07:24:26 --> Total execution time: 0.0234
INFO - 2020-03-09 07:25:58 --> Config Class Initialized
INFO - 2020-03-09 07:25:58 --> Hooks Class Initialized
DEBUG - 2020-03-09 07:25:58 --> UTF-8 Support Enabled
INFO - 2020-03-09 07:25:58 --> Utf8 Class Initialized
INFO - 2020-03-09 07:25:58 --> URI Class Initialized
INFO - 2020-03-09 07:25:58 --> Router Class Initialized
INFO - 2020-03-09 07:25:58 --> Output Class Initialized
INFO - 2020-03-09 07:25:58 --> Security Class Initialized
DEBUG - 2020-03-09 07:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 07:25:58 --> Input Class Initialized
INFO - 2020-03-09 07:25:58 --> Language Class Initialized
INFO - 2020-03-09 07:25:58 --> Loader Class Initialized
INFO - 2020-03-09 07:25:58 --> Helper loaded: url_helper
INFO - 2020-03-09 07:25:58 --> Helper loaded: string_helper
INFO - 2020-03-09 07:25:58 --> Database Driver Class Initialized
DEBUG - 2020-03-09 07:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 07:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 07:26:00 --> Controller Class Initialized
INFO - 2020-03-09 07:26:00 --> Model "M_tiket" initialized
INFO - 2020-03-09 07:26:00 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 07:26:00 --> Model "M_pesan" initialized
INFO - 2020-03-09 07:26:00 --> Helper loaded: form_helper
INFO - 2020-03-09 07:26:00 --> Form Validation Class Initialized
DEBUG - 2020-03-09 07:26:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-09 07:26:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-09 07:26:00 --> Final output sent to browser
DEBUG - 2020-03-09 07:26:00 --> Total execution time: 1.2229
INFO - 2020-03-09 07:26:07 --> Config Class Initialized
INFO - 2020-03-09 07:26:07 --> Hooks Class Initialized
DEBUG - 2020-03-09 07:26:07 --> UTF-8 Support Enabled
INFO - 2020-03-09 07:26:07 --> Utf8 Class Initialized
INFO - 2020-03-09 07:26:07 --> URI Class Initialized
INFO - 2020-03-09 07:26:07 --> Router Class Initialized
INFO - 2020-03-09 07:26:07 --> Output Class Initialized
INFO - 2020-03-09 07:26:07 --> Security Class Initialized
DEBUG - 2020-03-09 07:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 07:26:07 --> Input Class Initialized
INFO - 2020-03-09 07:26:07 --> Language Class Initialized
INFO - 2020-03-09 07:26:07 --> Loader Class Initialized
INFO - 2020-03-09 07:26:07 --> Helper loaded: url_helper
INFO - 2020-03-09 07:26:07 --> Helper loaded: string_helper
INFO - 2020-03-09 07:26:07 --> Database Driver Class Initialized
DEBUG - 2020-03-09 07:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 07:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 07:26:07 --> Controller Class Initialized
INFO - 2020-03-09 07:26:07 --> Model "M_tiket" initialized
INFO - 2020-03-09 07:26:07 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 07:26:07 --> Model "M_pesan" initialized
INFO - 2020-03-09 07:26:07 --> Helper loaded: form_helper
INFO - 2020-03-09 07:26:07 --> Form Validation Class Initialized
INFO - 2020-03-09 07:26:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-09 07:26:07 --> Final output sent to browser
DEBUG - 2020-03-09 07:26:07 --> Total execution time: 0.0261
INFO - 2020-03-09 07:26:10 --> Config Class Initialized
INFO - 2020-03-09 07:26:10 --> Hooks Class Initialized
DEBUG - 2020-03-09 07:26:10 --> UTF-8 Support Enabled
INFO - 2020-03-09 07:26:10 --> Utf8 Class Initialized
INFO - 2020-03-09 07:26:10 --> URI Class Initialized
INFO - 2020-03-09 07:26:10 --> Router Class Initialized
INFO - 2020-03-09 07:26:10 --> Output Class Initialized
INFO - 2020-03-09 07:26:10 --> Security Class Initialized
DEBUG - 2020-03-09 07:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 07:26:10 --> Input Class Initialized
INFO - 2020-03-09 07:26:10 --> Language Class Initialized
INFO - 2020-03-09 07:26:10 --> Loader Class Initialized
INFO - 2020-03-09 07:26:10 --> Helper loaded: url_helper
INFO - 2020-03-09 07:26:10 --> Helper loaded: string_helper
INFO - 2020-03-09 07:26:10 --> Database Driver Class Initialized
DEBUG - 2020-03-09 07:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 07:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 07:26:11 --> Controller Class Initialized
INFO - 2020-03-09 07:26:11 --> Model "M_tiket" initialized
INFO - 2020-03-09 07:26:11 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 07:26:11 --> Model "M_pesan" initialized
INFO - 2020-03-09 07:26:11 --> Helper loaded: form_helper
INFO - 2020-03-09 07:26:11 --> Form Validation Class Initialized
DEBUG - 2020-03-09 07:26:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-09 07:26:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-09 07:26:11 --> Final output sent to browser
DEBUG - 2020-03-09 07:26:11 --> Total execution time: 0.0578
INFO - 2020-03-09 07:26:14 --> Config Class Initialized
INFO - 2020-03-09 07:26:14 --> Hooks Class Initialized
DEBUG - 2020-03-09 07:26:14 --> UTF-8 Support Enabled
INFO - 2020-03-09 07:26:14 --> Utf8 Class Initialized
INFO - 2020-03-09 07:26:14 --> URI Class Initialized
INFO - 2020-03-09 07:26:14 --> Router Class Initialized
INFO - 2020-03-09 07:26:14 --> Output Class Initialized
INFO - 2020-03-09 07:26:14 --> Security Class Initialized
DEBUG - 2020-03-09 07:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 07:26:14 --> Input Class Initialized
INFO - 2020-03-09 07:26:14 --> Language Class Initialized
INFO - 2020-03-09 07:26:14 --> Loader Class Initialized
INFO - 2020-03-09 07:26:14 --> Helper loaded: url_helper
INFO - 2020-03-09 07:26:14 --> Helper loaded: string_helper
INFO - 2020-03-09 07:26:14 --> Database Driver Class Initialized
DEBUG - 2020-03-09 07:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 07:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 07:26:14 --> Controller Class Initialized
INFO - 2020-03-09 07:26:14 --> Model "M_tiket" initialized
INFO - 2020-03-09 07:26:14 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 07:26:14 --> Model "M_pesan" initialized
INFO - 2020-03-09 07:26:14 --> Helper loaded: form_helper
INFO - 2020-03-09 07:26:14 --> Form Validation Class Initialized
INFO - 2020-03-09 07:26:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-09 07:26:14 --> Final output sent to browser
DEBUG - 2020-03-09 07:26:14 --> Total execution time: 0.1187
INFO - 2020-03-09 07:29:49 --> Config Class Initialized
INFO - 2020-03-09 07:29:49 --> Hooks Class Initialized
DEBUG - 2020-03-09 07:29:49 --> UTF-8 Support Enabled
INFO - 2020-03-09 07:29:49 --> Utf8 Class Initialized
INFO - 2020-03-09 07:29:49 --> URI Class Initialized
DEBUG - 2020-03-09 07:29:49 --> No URI present. Default controller set.
INFO - 2020-03-09 07:29:49 --> Router Class Initialized
INFO - 2020-03-09 07:29:49 --> Output Class Initialized
INFO - 2020-03-09 07:29:49 --> Security Class Initialized
DEBUG - 2020-03-09 07:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 07:29:49 --> Input Class Initialized
INFO - 2020-03-09 07:29:49 --> Language Class Initialized
INFO - 2020-03-09 07:29:49 --> Loader Class Initialized
INFO - 2020-03-09 07:29:49 --> Helper loaded: url_helper
INFO - 2020-03-09 07:29:49 --> Helper loaded: string_helper
INFO - 2020-03-09 07:29:49 --> Database Driver Class Initialized
DEBUG - 2020-03-09 07:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 07:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 07:29:49 --> Controller Class Initialized
INFO - 2020-03-09 07:29:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 07:29:49 --> Pagination Class Initialized
INFO - 2020-03-09 07:29:49 --> Model "M_show" initialized
INFO - 2020-03-09 07:29:49 --> Helper loaded: form_helper
INFO - 2020-03-09 07:29:49 --> Form Validation Class Initialized
INFO - 2020-03-09 07:29:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 07:29:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 07:29:49 --> Final output sent to browser
DEBUG - 2020-03-09 07:29:49 --> Total execution time: 0.0430
INFO - 2020-03-09 07:31:25 --> Config Class Initialized
INFO - 2020-03-09 07:31:25 --> Hooks Class Initialized
DEBUG - 2020-03-09 07:31:25 --> UTF-8 Support Enabled
INFO - 2020-03-09 07:31:25 --> Utf8 Class Initialized
INFO - 2020-03-09 07:31:25 --> URI Class Initialized
DEBUG - 2020-03-09 07:31:25 --> No URI present. Default controller set.
INFO - 2020-03-09 07:31:25 --> Router Class Initialized
INFO - 2020-03-09 07:31:25 --> Output Class Initialized
INFO - 2020-03-09 07:31:25 --> Security Class Initialized
DEBUG - 2020-03-09 07:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 07:31:25 --> Input Class Initialized
INFO - 2020-03-09 07:31:25 --> Language Class Initialized
INFO - 2020-03-09 07:31:25 --> Loader Class Initialized
INFO - 2020-03-09 07:31:25 --> Helper loaded: url_helper
INFO - 2020-03-09 07:31:25 --> Helper loaded: string_helper
INFO - 2020-03-09 07:31:25 --> Database Driver Class Initialized
DEBUG - 2020-03-09 07:31:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 07:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 07:31:25 --> Controller Class Initialized
INFO - 2020-03-09 07:31:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 07:31:25 --> Pagination Class Initialized
INFO - 2020-03-09 07:31:25 --> Model "M_show" initialized
INFO - 2020-03-09 07:31:25 --> Helper loaded: form_helper
INFO - 2020-03-09 07:31:25 --> Form Validation Class Initialized
INFO - 2020-03-09 07:31:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 07:31:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 07:31:25 --> Final output sent to browser
DEBUG - 2020-03-09 07:31:25 --> Total execution time: 0.0657
INFO - 2020-03-09 07:32:19 --> Config Class Initialized
INFO - 2020-03-09 07:32:19 --> Hooks Class Initialized
DEBUG - 2020-03-09 07:32:19 --> UTF-8 Support Enabled
INFO - 2020-03-09 07:32:19 --> Utf8 Class Initialized
INFO - 2020-03-09 07:32:19 --> URI Class Initialized
DEBUG - 2020-03-09 07:32:19 --> No URI present. Default controller set.
INFO - 2020-03-09 07:32:19 --> Router Class Initialized
INFO - 2020-03-09 07:32:19 --> Output Class Initialized
INFO - 2020-03-09 07:32:19 --> Security Class Initialized
DEBUG - 2020-03-09 07:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 07:32:19 --> Input Class Initialized
INFO - 2020-03-09 07:32:19 --> Language Class Initialized
INFO - 2020-03-09 07:32:19 --> Loader Class Initialized
INFO - 2020-03-09 07:32:19 --> Helper loaded: url_helper
INFO - 2020-03-09 07:32:19 --> Helper loaded: string_helper
INFO - 2020-03-09 07:32:19 --> Database Driver Class Initialized
DEBUG - 2020-03-09 07:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 07:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 07:32:19 --> Controller Class Initialized
INFO - 2020-03-09 07:32:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 07:32:19 --> Pagination Class Initialized
INFO - 2020-03-09 07:32:19 --> Model "M_show" initialized
INFO - 2020-03-09 07:32:19 --> Helper loaded: form_helper
INFO - 2020-03-09 07:32:19 --> Form Validation Class Initialized
INFO - 2020-03-09 07:32:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 07:32:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 07:32:19 --> Final output sent to browser
DEBUG - 2020-03-09 07:32:19 --> Total execution time: 0.0053
INFO - 2020-03-09 07:46:13 --> Config Class Initialized
INFO - 2020-03-09 07:46:13 --> Hooks Class Initialized
DEBUG - 2020-03-09 07:46:13 --> UTF-8 Support Enabled
INFO - 2020-03-09 07:46:13 --> Utf8 Class Initialized
INFO - 2020-03-09 07:46:13 --> URI Class Initialized
DEBUG - 2020-03-09 07:46:13 --> No URI present. Default controller set.
INFO - 2020-03-09 07:46:13 --> Router Class Initialized
INFO - 2020-03-09 07:46:13 --> Output Class Initialized
INFO - 2020-03-09 07:46:13 --> Security Class Initialized
DEBUG - 2020-03-09 07:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 07:46:13 --> Input Class Initialized
INFO - 2020-03-09 07:46:13 --> Language Class Initialized
INFO - 2020-03-09 07:46:13 --> Loader Class Initialized
INFO - 2020-03-09 07:46:13 --> Helper loaded: url_helper
INFO - 2020-03-09 07:46:13 --> Helper loaded: string_helper
INFO - 2020-03-09 07:46:13 --> Database Driver Class Initialized
DEBUG - 2020-03-09 07:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 07:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 07:46:13 --> Controller Class Initialized
INFO - 2020-03-09 07:46:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 07:46:13 --> Pagination Class Initialized
INFO - 2020-03-09 07:46:13 --> Model "M_show" initialized
INFO - 2020-03-09 07:46:13 --> Helper loaded: form_helper
INFO - 2020-03-09 07:46:13 --> Form Validation Class Initialized
INFO - 2020-03-09 07:46:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 07:46:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 07:46:13 --> Final output sent to browser
DEBUG - 2020-03-09 07:46:13 --> Total execution time: 0.0492
INFO - 2020-03-09 07:46:18 --> Config Class Initialized
INFO - 2020-03-09 07:46:18 --> Hooks Class Initialized
DEBUG - 2020-03-09 07:46:18 --> UTF-8 Support Enabled
INFO - 2020-03-09 07:46:18 --> Utf8 Class Initialized
INFO - 2020-03-09 07:46:18 --> URI Class Initialized
INFO - 2020-03-09 07:46:18 --> Router Class Initialized
INFO - 2020-03-09 07:46:18 --> Output Class Initialized
INFO - 2020-03-09 07:46:18 --> Security Class Initialized
DEBUG - 2020-03-09 07:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 07:46:18 --> Input Class Initialized
INFO - 2020-03-09 07:46:18 --> Language Class Initialized
INFO - 2020-03-09 07:46:18 --> Loader Class Initialized
INFO - 2020-03-09 07:46:18 --> Helper loaded: url_helper
INFO - 2020-03-09 07:46:18 --> Helper loaded: string_helper
INFO - 2020-03-09 07:46:18 --> Database Driver Class Initialized
DEBUG - 2020-03-09 07:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 07:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 07:46:18 --> Controller Class Initialized
INFO - 2020-03-09 07:46:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 07:46:18 --> Pagination Class Initialized
INFO - 2020-03-09 07:46:18 --> Model "M_show" initialized
INFO - 2020-03-09 07:46:18 --> Helper loaded: form_helper
INFO - 2020-03-09 07:46:18 --> Form Validation Class Initialized
INFO - 2020-03-09 07:46:18 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 07:46:18 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 07:46:18 --> Final output sent to browser
DEBUG - 2020-03-09 07:46:18 --> Total execution time: 0.0114
INFO - 2020-03-09 07:46:21 --> Config Class Initialized
INFO - 2020-03-09 07:46:21 --> Hooks Class Initialized
DEBUG - 2020-03-09 07:46:21 --> UTF-8 Support Enabled
INFO - 2020-03-09 07:46:21 --> Utf8 Class Initialized
INFO - 2020-03-09 07:46:21 --> URI Class Initialized
INFO - 2020-03-09 07:46:21 --> Router Class Initialized
INFO - 2020-03-09 07:46:21 --> Output Class Initialized
INFO - 2020-03-09 07:46:21 --> Security Class Initialized
DEBUG - 2020-03-09 07:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 07:46:21 --> Input Class Initialized
INFO - 2020-03-09 07:46:21 --> Language Class Initialized
INFO - 2020-03-09 07:46:21 --> Loader Class Initialized
INFO - 2020-03-09 07:46:21 --> Helper loaded: url_helper
INFO - 2020-03-09 07:46:21 --> Helper loaded: string_helper
INFO - 2020-03-09 07:46:21 --> Database Driver Class Initialized
DEBUG - 2020-03-09 07:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 07:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 07:46:21 --> Controller Class Initialized
INFO - 2020-03-09 07:46:21 --> Model "M_tiket" initialized
INFO - 2020-03-09 07:46:21 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 07:46:21 --> Model "M_pesan" initialized
INFO - 2020-03-09 07:46:21 --> Helper loaded: form_helper
INFO - 2020-03-09 07:46:21 --> Form Validation Class Initialized
INFO - 2020-03-09 07:46:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-09 07:46:21 --> Final output sent to browser
DEBUG - 2020-03-09 07:46:21 --> Total execution time: 0.0124
INFO - 2020-03-09 07:46:25 --> Config Class Initialized
INFO - 2020-03-09 07:46:25 --> Hooks Class Initialized
DEBUG - 2020-03-09 07:46:25 --> UTF-8 Support Enabled
INFO - 2020-03-09 07:46:25 --> Utf8 Class Initialized
INFO - 2020-03-09 07:46:25 --> URI Class Initialized
INFO - 2020-03-09 07:46:25 --> Router Class Initialized
INFO - 2020-03-09 07:46:25 --> Output Class Initialized
INFO - 2020-03-09 07:46:25 --> Security Class Initialized
DEBUG - 2020-03-09 07:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 07:46:25 --> Input Class Initialized
INFO - 2020-03-09 07:46:25 --> Language Class Initialized
INFO - 2020-03-09 07:46:25 --> Loader Class Initialized
INFO - 2020-03-09 07:46:25 --> Helper loaded: url_helper
INFO - 2020-03-09 07:46:25 --> Helper loaded: string_helper
INFO - 2020-03-09 07:46:25 --> Database Driver Class Initialized
DEBUG - 2020-03-09 07:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 07:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 07:46:25 --> Controller Class Initialized
INFO - 2020-03-09 07:46:25 --> Model "M_tiket" initialized
INFO - 2020-03-09 07:46:25 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 07:46:25 --> Model "M_pesan" initialized
INFO - 2020-03-09 07:46:25 --> Helper loaded: form_helper
INFO - 2020-03-09 07:46:25 --> Form Validation Class Initialized
INFO - 2020-03-09 07:46:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-09 07:46:25 --> Final output sent to browser
DEBUG - 2020-03-09 07:46:25 --> Total execution time: 0.0074
INFO - 2020-03-09 07:50:50 --> Config Class Initialized
INFO - 2020-03-09 07:50:50 --> Hooks Class Initialized
DEBUG - 2020-03-09 07:50:50 --> UTF-8 Support Enabled
INFO - 2020-03-09 07:50:50 --> Utf8 Class Initialized
INFO - 2020-03-09 07:50:50 --> URI Class Initialized
DEBUG - 2020-03-09 07:50:50 --> No URI present. Default controller set.
INFO - 2020-03-09 07:50:50 --> Router Class Initialized
INFO - 2020-03-09 07:50:50 --> Output Class Initialized
INFO - 2020-03-09 07:50:50 --> Security Class Initialized
DEBUG - 2020-03-09 07:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 07:50:50 --> Input Class Initialized
INFO - 2020-03-09 07:50:50 --> Language Class Initialized
INFO - 2020-03-09 07:50:50 --> Loader Class Initialized
INFO - 2020-03-09 07:50:50 --> Helper loaded: url_helper
INFO - 2020-03-09 07:50:50 --> Helper loaded: string_helper
INFO - 2020-03-09 07:50:50 --> Database Driver Class Initialized
DEBUG - 2020-03-09 07:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 07:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 07:50:50 --> Controller Class Initialized
INFO - 2020-03-09 07:50:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 07:50:50 --> Pagination Class Initialized
INFO - 2020-03-09 07:50:50 --> Model "M_show" initialized
INFO - 2020-03-09 07:50:50 --> Helper loaded: form_helper
INFO - 2020-03-09 07:50:50 --> Form Validation Class Initialized
INFO - 2020-03-09 07:50:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 07:50:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 07:50:50 --> Final output sent to browser
DEBUG - 2020-03-09 07:50:50 --> Total execution time: 0.0614
INFO - 2020-03-09 07:54:01 --> Config Class Initialized
INFO - 2020-03-09 07:54:01 --> Hooks Class Initialized
DEBUG - 2020-03-09 07:54:02 --> UTF-8 Support Enabled
INFO - 2020-03-09 07:54:02 --> Utf8 Class Initialized
INFO - 2020-03-09 07:54:02 --> URI Class Initialized
INFO - 2020-03-09 07:54:02 --> Config Class Initialized
INFO - 2020-03-09 07:54:02 --> Hooks Class Initialized
DEBUG - 2020-03-09 07:54:02 --> UTF-8 Support Enabled
INFO - 2020-03-09 07:54:02 --> Utf8 Class Initialized
INFO - 2020-03-09 07:54:02 --> URI Class Initialized
INFO - 2020-03-09 07:54:02 --> Router Class Initialized
INFO - 2020-03-09 07:54:02 --> Output Class Initialized
INFO - 2020-03-09 07:54:02 --> Security Class Initialized
INFO - 2020-03-09 07:54:02 --> Router Class Initialized
INFO - 2020-03-09 07:54:02 --> Output Class Initialized
INFO - 2020-03-09 07:54:02 --> Security Class Initialized
DEBUG - 2020-03-09 07:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 07:54:02 --> Input Class Initialized
INFO - 2020-03-09 07:54:02 --> Language Class Initialized
INFO - 2020-03-09 07:54:02 --> Loader Class Initialized
DEBUG - 2020-03-09 07:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 07:54:02 --> Input Class Initialized
INFO - 2020-03-09 07:54:02 --> Language Class Initialized
INFO - 2020-03-09 07:54:02 --> Loader Class Initialized
INFO - 2020-03-09 07:54:02 --> Helper loaded: url_helper
INFO - 2020-03-09 07:54:02 --> Helper loaded: string_helper
INFO - 2020-03-09 07:54:02 --> Helper loaded: url_helper
INFO - 2020-03-09 07:54:02 --> Helper loaded: string_helper
INFO - 2020-03-09 07:54:02 --> Database Driver Class Initialized
INFO - 2020-03-09 07:54:02 --> Database Driver Class Initialized
DEBUG - 2020-03-09 07:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 07:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 07:54:02 --> Controller Class Initialized
DEBUG - 2020-03-09 07:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 07:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 07:54:02 --> Controller Class Initialized
INFO - 2020-03-09 07:54:02 --> Model "M_tiket" initialized
INFO - 2020-03-09 07:54:02 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 07:54:02 --> Model "M_tiket" initialized
INFO - 2020-03-09 07:54:02 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 07:54:02 --> Model "M_pesan" initialized
INFO - 2020-03-09 07:54:02 --> Model "M_pesan" initialized
INFO - 2020-03-09 07:54:02 --> Helper loaded: form_helper
INFO - 2020-03-09 07:54:02 --> Form Validation Class Initialized
INFO - 2020-03-09 07:54:02 --> Helper loaded: form_helper
INFO - 2020-03-09 07:54:02 --> Form Validation Class Initialized
INFO - 2020-03-09 07:54:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-09 07:54:02 --> Final output sent to browser
DEBUG - 2020-03-09 07:54:02 --> Total execution time: 0.2217
INFO - 2020-03-09 07:54:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-09 07:54:02 --> Final output sent to browser
DEBUG - 2020-03-09 07:54:02 --> Total execution time: 0.2266
INFO - 2020-03-09 08:04:58 --> Config Class Initialized
INFO - 2020-03-09 08:04:58 --> Hooks Class Initialized
DEBUG - 2020-03-09 08:04:58 --> UTF-8 Support Enabled
INFO - 2020-03-09 08:04:58 --> Utf8 Class Initialized
INFO - 2020-03-09 08:04:58 --> URI Class Initialized
DEBUG - 2020-03-09 08:04:58 --> No URI present. Default controller set.
INFO - 2020-03-09 08:04:58 --> Router Class Initialized
INFO - 2020-03-09 08:04:58 --> Output Class Initialized
INFO - 2020-03-09 08:04:58 --> Security Class Initialized
DEBUG - 2020-03-09 08:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 08:04:58 --> Input Class Initialized
INFO - 2020-03-09 08:04:58 --> Language Class Initialized
INFO - 2020-03-09 08:04:58 --> Loader Class Initialized
INFO - 2020-03-09 08:04:58 --> Helper loaded: url_helper
INFO - 2020-03-09 08:04:58 --> Helper loaded: string_helper
INFO - 2020-03-09 08:04:58 --> Database Driver Class Initialized
DEBUG - 2020-03-09 08:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 08:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 08:04:58 --> Controller Class Initialized
INFO - 2020-03-09 08:04:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 08:04:58 --> Pagination Class Initialized
INFO - 2020-03-09 08:04:58 --> Model "M_show" initialized
INFO - 2020-03-09 08:04:58 --> Helper loaded: form_helper
INFO - 2020-03-09 08:04:58 --> Form Validation Class Initialized
INFO - 2020-03-09 08:04:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 08:04:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 08:04:58 --> Final output sent to browser
DEBUG - 2020-03-09 08:04:58 --> Total execution time: 0.0537
INFO - 2020-03-09 08:05:15 --> Config Class Initialized
INFO - 2020-03-09 08:05:15 --> Hooks Class Initialized
DEBUG - 2020-03-09 08:05:15 --> UTF-8 Support Enabled
INFO - 2020-03-09 08:05:15 --> Utf8 Class Initialized
INFO - 2020-03-09 08:05:15 --> URI Class Initialized
DEBUG - 2020-03-09 08:05:15 --> No URI present. Default controller set.
INFO - 2020-03-09 08:05:15 --> Router Class Initialized
INFO - 2020-03-09 08:05:15 --> Output Class Initialized
INFO - 2020-03-09 08:05:15 --> Security Class Initialized
DEBUG - 2020-03-09 08:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 08:05:15 --> Input Class Initialized
INFO - 2020-03-09 08:05:15 --> Language Class Initialized
INFO - 2020-03-09 08:05:15 --> Loader Class Initialized
INFO - 2020-03-09 08:05:15 --> Helper loaded: url_helper
INFO - 2020-03-09 08:05:15 --> Helper loaded: string_helper
INFO - 2020-03-09 08:05:15 --> Database Driver Class Initialized
DEBUG - 2020-03-09 08:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 08:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 08:05:15 --> Controller Class Initialized
INFO - 2020-03-09 08:05:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 08:05:15 --> Pagination Class Initialized
INFO - 2020-03-09 08:05:15 --> Model "M_show" initialized
INFO - 2020-03-09 08:05:15 --> Helper loaded: form_helper
INFO - 2020-03-09 08:05:15 --> Form Validation Class Initialized
INFO - 2020-03-09 08:05:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 08:05:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 08:05:15 --> Final output sent to browser
DEBUG - 2020-03-09 08:05:15 --> Total execution time: 0.0082
INFO - 2020-03-09 08:14:26 --> Config Class Initialized
INFO - 2020-03-09 08:14:26 --> Hooks Class Initialized
DEBUG - 2020-03-09 08:14:26 --> UTF-8 Support Enabled
INFO - 2020-03-09 08:14:26 --> Utf8 Class Initialized
INFO - 2020-03-09 08:14:26 --> URI Class Initialized
DEBUG - 2020-03-09 08:14:26 --> No URI present. Default controller set.
INFO - 2020-03-09 08:14:26 --> Router Class Initialized
INFO - 2020-03-09 08:14:26 --> Output Class Initialized
INFO - 2020-03-09 08:14:26 --> Security Class Initialized
DEBUG - 2020-03-09 08:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 08:14:26 --> Input Class Initialized
INFO - 2020-03-09 08:14:26 --> Language Class Initialized
INFO - 2020-03-09 08:14:26 --> Loader Class Initialized
INFO - 2020-03-09 08:14:26 --> Helper loaded: url_helper
INFO - 2020-03-09 08:14:26 --> Helper loaded: string_helper
INFO - 2020-03-09 08:14:26 --> Database Driver Class Initialized
DEBUG - 2020-03-09 08:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 08:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 08:14:26 --> Controller Class Initialized
INFO - 2020-03-09 08:14:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 08:14:26 --> Pagination Class Initialized
INFO - 2020-03-09 08:14:26 --> Model "M_show" initialized
INFO - 2020-03-09 08:14:26 --> Helper loaded: form_helper
INFO - 2020-03-09 08:14:26 --> Form Validation Class Initialized
INFO - 2020-03-09 08:14:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 08:14:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 08:14:26 --> Final output sent to browser
DEBUG - 2020-03-09 08:14:26 --> Total execution time: 0.0522
INFO - 2020-03-09 08:14:35 --> Config Class Initialized
INFO - 2020-03-09 08:14:35 --> Hooks Class Initialized
DEBUG - 2020-03-09 08:14:35 --> UTF-8 Support Enabled
INFO - 2020-03-09 08:14:35 --> Utf8 Class Initialized
INFO - 2020-03-09 08:14:35 --> URI Class Initialized
INFO - 2020-03-09 08:14:35 --> Router Class Initialized
INFO - 2020-03-09 08:14:35 --> Output Class Initialized
INFO - 2020-03-09 08:14:35 --> Security Class Initialized
DEBUG - 2020-03-09 08:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 08:14:35 --> Input Class Initialized
INFO - 2020-03-09 08:14:35 --> Language Class Initialized
INFO - 2020-03-09 08:14:35 --> Loader Class Initialized
INFO - 2020-03-09 08:14:35 --> Helper loaded: url_helper
INFO - 2020-03-09 08:14:35 --> Helper loaded: string_helper
INFO - 2020-03-09 08:14:35 --> Database Driver Class Initialized
DEBUG - 2020-03-09 08:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 08:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 08:14:35 --> Controller Class Initialized
INFO - 2020-03-09 08:14:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 08:14:35 --> Pagination Class Initialized
INFO - 2020-03-09 08:14:35 --> Model "M_show" initialized
INFO - 2020-03-09 08:14:35 --> Helper loaded: form_helper
INFO - 2020-03-09 08:14:35 --> Form Validation Class Initialized
INFO - 2020-03-09 08:14:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 08:14:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 08:14:35 --> Final output sent to browser
DEBUG - 2020-03-09 08:14:35 --> Total execution time: 0.0096
INFO - 2020-03-09 08:14:39 --> Config Class Initialized
INFO - 2020-03-09 08:14:39 --> Hooks Class Initialized
DEBUG - 2020-03-09 08:14:39 --> UTF-8 Support Enabled
INFO - 2020-03-09 08:14:39 --> Utf8 Class Initialized
INFO - 2020-03-09 08:14:39 --> URI Class Initialized
INFO - 2020-03-09 08:14:39 --> Router Class Initialized
INFO - 2020-03-09 08:14:39 --> Output Class Initialized
INFO - 2020-03-09 08:14:39 --> Security Class Initialized
DEBUG - 2020-03-09 08:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 08:14:39 --> Input Class Initialized
INFO - 2020-03-09 08:14:39 --> Language Class Initialized
INFO - 2020-03-09 08:14:39 --> Loader Class Initialized
INFO - 2020-03-09 08:14:39 --> Helper loaded: url_helper
INFO - 2020-03-09 08:14:39 --> Helper loaded: string_helper
INFO - 2020-03-09 08:14:39 --> Database Driver Class Initialized
DEBUG - 2020-03-09 08:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 08:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 08:14:39 --> Controller Class Initialized
INFO - 2020-03-09 08:14:39 --> Model "M_tiket" initialized
INFO - 2020-03-09 08:14:39 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 08:14:39 --> Model "M_pesan" initialized
INFO - 2020-03-09 08:14:39 --> Helper loaded: form_helper
INFO - 2020-03-09 08:14:39 --> Form Validation Class Initialized
INFO - 2020-03-09 08:14:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-09 08:14:39 --> Final output sent to browser
DEBUG - 2020-03-09 08:14:39 --> Total execution time: 0.0144
INFO - 2020-03-09 08:14:47 --> Config Class Initialized
INFO - 2020-03-09 08:14:47 --> Hooks Class Initialized
DEBUG - 2020-03-09 08:14:47 --> UTF-8 Support Enabled
INFO - 2020-03-09 08:14:47 --> Utf8 Class Initialized
INFO - 2020-03-09 08:14:47 --> URI Class Initialized
INFO - 2020-03-09 08:14:47 --> Router Class Initialized
INFO - 2020-03-09 08:14:47 --> Output Class Initialized
INFO - 2020-03-09 08:14:47 --> Security Class Initialized
DEBUG - 2020-03-09 08:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 08:14:48 --> Input Class Initialized
INFO - 2020-03-09 08:14:48 --> Language Class Initialized
INFO - 2020-03-09 08:14:48 --> Loader Class Initialized
INFO - 2020-03-09 08:14:48 --> Helper loaded: url_helper
INFO - 2020-03-09 08:14:48 --> Helper loaded: string_helper
INFO - 2020-03-09 08:14:48 --> Database Driver Class Initialized
DEBUG - 2020-03-09 08:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 08:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 08:14:48 --> Controller Class Initialized
INFO - 2020-03-09 08:14:48 --> Model "M_tiket" initialized
INFO - 2020-03-09 08:14:48 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 08:14:48 --> Model "M_pesan" initialized
INFO - 2020-03-09 08:14:48 --> Helper loaded: form_helper
INFO - 2020-03-09 08:14:48 --> Form Validation Class Initialized
INFO - 2020-03-09 08:14:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-09 08:14:48 --> Final output sent to browser
DEBUG - 2020-03-09 08:14:48 --> Total execution time: 0.0159
INFO - 2020-03-09 08:15:26 --> Config Class Initialized
INFO - 2020-03-09 08:15:26 --> Hooks Class Initialized
DEBUG - 2020-03-09 08:15:26 --> UTF-8 Support Enabled
INFO - 2020-03-09 08:15:26 --> Utf8 Class Initialized
INFO - 2020-03-09 08:15:26 --> URI Class Initialized
DEBUG - 2020-03-09 08:15:26 --> No URI present. Default controller set.
INFO - 2020-03-09 08:15:26 --> Router Class Initialized
INFO - 2020-03-09 08:15:26 --> Output Class Initialized
INFO - 2020-03-09 08:15:26 --> Security Class Initialized
DEBUG - 2020-03-09 08:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 08:15:26 --> Input Class Initialized
INFO - 2020-03-09 08:15:26 --> Language Class Initialized
INFO - 2020-03-09 08:15:26 --> Loader Class Initialized
INFO - 2020-03-09 08:15:26 --> Helper loaded: url_helper
INFO - 2020-03-09 08:15:26 --> Helper loaded: string_helper
INFO - 2020-03-09 08:15:26 --> Database Driver Class Initialized
DEBUG - 2020-03-09 08:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 08:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 08:15:26 --> Controller Class Initialized
INFO - 2020-03-09 08:15:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 08:15:26 --> Pagination Class Initialized
INFO - 2020-03-09 08:15:26 --> Model "M_show" initialized
INFO - 2020-03-09 08:15:26 --> Helper loaded: form_helper
INFO - 2020-03-09 08:15:26 --> Form Validation Class Initialized
INFO - 2020-03-09 08:15:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 08:15:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 08:15:26 --> Final output sent to browser
DEBUG - 2020-03-09 08:15:26 --> Total execution time: 0.0065
INFO - 2020-03-09 08:15:40 --> Config Class Initialized
INFO - 2020-03-09 08:15:40 --> Hooks Class Initialized
DEBUG - 2020-03-09 08:15:40 --> UTF-8 Support Enabled
INFO - 2020-03-09 08:15:40 --> Utf8 Class Initialized
INFO - 2020-03-09 08:15:40 --> URI Class Initialized
INFO - 2020-03-09 08:15:40 --> Router Class Initialized
INFO - 2020-03-09 08:15:40 --> Output Class Initialized
INFO - 2020-03-09 08:15:40 --> Security Class Initialized
DEBUG - 2020-03-09 08:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 08:15:40 --> Input Class Initialized
INFO - 2020-03-09 08:15:40 --> Language Class Initialized
INFO - 2020-03-09 08:15:40 --> Loader Class Initialized
INFO - 2020-03-09 08:15:40 --> Helper loaded: url_helper
INFO - 2020-03-09 08:15:40 --> Helper loaded: string_helper
INFO - 2020-03-09 08:15:40 --> Database Driver Class Initialized
DEBUG - 2020-03-09 08:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 08:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 08:15:40 --> Controller Class Initialized
INFO - 2020-03-09 08:15:40 --> Model "M_tiket" initialized
INFO - 2020-03-09 08:15:40 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 08:15:40 --> Model "M_pesan" initialized
INFO - 2020-03-09 08:15:40 --> Helper loaded: form_helper
INFO - 2020-03-09 08:15:40 --> Form Validation Class Initialized
DEBUG - 2020-03-09 08:15:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-09 08:15:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-09 15:15:40 --> Final output sent to browser
DEBUG - 2020-03-09 15:15:40 --> Total execution time: 0.1893
INFO - 2020-03-09 08:15:43 --> Config Class Initialized
INFO - 2020-03-09 08:15:43 --> Hooks Class Initialized
DEBUG - 2020-03-09 08:15:43 --> UTF-8 Support Enabled
INFO - 2020-03-09 08:15:43 --> Utf8 Class Initialized
INFO - 2020-03-09 08:15:43 --> URI Class Initialized
INFO - 2020-03-09 08:15:43 --> Router Class Initialized
INFO - 2020-03-09 08:15:43 --> Output Class Initialized
INFO - 2020-03-09 08:15:43 --> Security Class Initialized
DEBUG - 2020-03-09 08:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 08:15:43 --> Input Class Initialized
INFO - 2020-03-09 08:15:43 --> Language Class Initialized
INFO - 2020-03-09 08:15:43 --> Loader Class Initialized
INFO - 2020-03-09 08:15:43 --> Helper loaded: url_helper
INFO - 2020-03-09 08:15:43 --> Helper loaded: string_helper
INFO - 2020-03-09 08:15:43 --> Database Driver Class Initialized
DEBUG - 2020-03-09 08:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 08:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 08:15:43 --> Controller Class Initialized
INFO - 2020-03-09 08:15:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 08:15:43 --> Pagination Class Initialized
INFO - 2020-03-09 08:15:43 --> Model "M_show" initialized
INFO - 2020-03-09 08:15:43 --> Helper loaded: form_helper
INFO - 2020-03-09 08:15:43 --> Form Validation Class Initialized
INFO - 2020-03-09 08:15:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 08:15:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 08:15:43 --> Final output sent to browser
DEBUG - 2020-03-09 08:15:43 --> Total execution time: 0.0060
INFO - 2020-03-09 08:19:07 --> Config Class Initialized
INFO - 2020-03-09 08:19:07 --> Hooks Class Initialized
DEBUG - 2020-03-09 08:19:07 --> UTF-8 Support Enabled
INFO - 2020-03-09 08:19:07 --> Utf8 Class Initialized
INFO - 2020-03-09 08:19:07 --> URI Class Initialized
DEBUG - 2020-03-09 08:19:07 --> No URI present. Default controller set.
INFO - 2020-03-09 08:19:07 --> Router Class Initialized
INFO - 2020-03-09 08:19:07 --> Output Class Initialized
INFO - 2020-03-09 08:19:07 --> Security Class Initialized
DEBUG - 2020-03-09 08:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 08:19:07 --> Input Class Initialized
INFO - 2020-03-09 08:19:07 --> Language Class Initialized
INFO - 2020-03-09 08:19:07 --> Loader Class Initialized
INFO - 2020-03-09 08:19:07 --> Helper loaded: url_helper
INFO - 2020-03-09 08:19:07 --> Helper loaded: string_helper
INFO - 2020-03-09 08:19:07 --> Database Driver Class Initialized
DEBUG - 2020-03-09 08:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 08:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 08:19:07 --> Controller Class Initialized
INFO - 2020-03-09 08:19:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 08:19:07 --> Pagination Class Initialized
INFO - 2020-03-09 08:19:07 --> Model "M_show" initialized
INFO - 2020-03-09 08:19:07 --> Helper loaded: form_helper
INFO - 2020-03-09 08:19:07 --> Form Validation Class Initialized
INFO - 2020-03-09 08:19:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 08:19:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 08:19:07 --> Final output sent to browser
DEBUG - 2020-03-09 08:19:07 --> Total execution time: 0.0614
INFO - 2020-03-09 08:19:24 --> Config Class Initialized
INFO - 2020-03-09 08:19:24 --> Hooks Class Initialized
DEBUG - 2020-03-09 08:19:24 --> UTF-8 Support Enabled
INFO - 2020-03-09 08:19:24 --> Utf8 Class Initialized
INFO - 2020-03-09 08:19:24 --> URI Class Initialized
INFO - 2020-03-09 08:19:24 --> Router Class Initialized
INFO - 2020-03-09 08:19:24 --> Output Class Initialized
INFO - 2020-03-09 08:19:24 --> Security Class Initialized
DEBUG - 2020-03-09 08:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 08:19:24 --> Input Class Initialized
INFO - 2020-03-09 08:19:24 --> Language Class Initialized
INFO - 2020-03-09 08:19:24 --> Loader Class Initialized
INFO - 2020-03-09 08:19:24 --> Helper loaded: url_helper
INFO - 2020-03-09 08:19:24 --> Helper loaded: string_helper
INFO - 2020-03-09 08:19:24 --> Database Driver Class Initialized
DEBUG - 2020-03-09 08:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 08:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 08:19:24 --> Controller Class Initialized
INFO - 2020-03-09 08:19:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 08:19:24 --> Pagination Class Initialized
INFO - 2020-03-09 08:19:24 --> Model "M_show" initialized
INFO - 2020-03-09 08:19:24 --> Helper loaded: form_helper
INFO - 2020-03-09 08:19:24 --> Form Validation Class Initialized
INFO - 2020-03-09 08:19:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 08:19:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 08:19:24 --> Final output sent to browser
DEBUG - 2020-03-09 08:19:24 --> Total execution time: 0.0091
INFO - 2020-03-09 08:19:34 --> Config Class Initialized
INFO - 2020-03-09 08:19:34 --> Hooks Class Initialized
DEBUG - 2020-03-09 08:19:34 --> UTF-8 Support Enabled
INFO - 2020-03-09 08:19:34 --> Utf8 Class Initialized
INFO - 2020-03-09 08:19:34 --> URI Class Initialized
INFO - 2020-03-09 08:19:34 --> Router Class Initialized
INFO - 2020-03-09 08:19:34 --> Output Class Initialized
INFO - 2020-03-09 08:19:34 --> Security Class Initialized
DEBUG - 2020-03-09 08:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 08:19:34 --> Input Class Initialized
INFO - 2020-03-09 08:19:34 --> Language Class Initialized
INFO - 2020-03-09 08:19:34 --> Loader Class Initialized
INFO - 2020-03-09 08:19:34 --> Helper loaded: url_helper
INFO - 2020-03-09 08:19:34 --> Helper loaded: string_helper
INFO - 2020-03-09 08:19:34 --> Database Driver Class Initialized
DEBUG - 2020-03-09 08:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 08:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 08:19:34 --> Controller Class Initialized
INFO - 2020-03-09 08:19:34 --> Model "M_tiket" initialized
INFO - 2020-03-09 08:19:34 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 08:19:34 --> Model "M_pesan" initialized
INFO - 2020-03-09 08:19:34 --> Helper loaded: form_helper
INFO - 2020-03-09 08:19:34 --> Form Validation Class Initialized
INFO - 2020-03-09 08:19:34 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-09 08:19:34 --> Final output sent to browser
DEBUG - 2020-03-09 08:19:34 --> Total execution time: 0.0113
INFO - 2020-03-09 08:19:46 --> Config Class Initialized
INFO - 2020-03-09 08:19:46 --> Hooks Class Initialized
DEBUG - 2020-03-09 08:19:46 --> UTF-8 Support Enabled
INFO - 2020-03-09 08:19:46 --> Utf8 Class Initialized
INFO - 2020-03-09 08:19:46 --> URI Class Initialized
INFO - 2020-03-09 08:19:46 --> Router Class Initialized
INFO - 2020-03-09 08:19:46 --> Output Class Initialized
INFO - 2020-03-09 08:19:46 --> Security Class Initialized
DEBUG - 2020-03-09 08:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 08:19:46 --> Input Class Initialized
INFO - 2020-03-09 08:19:46 --> Language Class Initialized
INFO - 2020-03-09 08:19:46 --> Loader Class Initialized
INFO - 2020-03-09 08:19:46 --> Helper loaded: url_helper
INFO - 2020-03-09 08:19:46 --> Helper loaded: string_helper
INFO - 2020-03-09 08:19:46 --> Database Driver Class Initialized
DEBUG - 2020-03-09 08:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 08:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 08:19:46 --> Controller Class Initialized
INFO - 2020-03-09 08:19:46 --> Model "M_tiket" initialized
INFO - 2020-03-09 08:19:46 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 08:19:46 --> Model "M_pesan" initialized
INFO - 2020-03-09 08:19:46 --> Helper loaded: form_helper
INFO - 2020-03-09 08:19:46 --> Form Validation Class Initialized
INFO - 2020-03-09 08:19:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-09 08:19:46 --> Final output sent to browser
DEBUG - 2020-03-09 08:19:46 --> Total execution time: 0.0080
INFO - 2020-03-09 08:21:15 --> Config Class Initialized
INFO - 2020-03-09 08:21:15 --> Hooks Class Initialized
DEBUG - 2020-03-09 08:21:15 --> UTF-8 Support Enabled
INFO - 2020-03-09 08:21:15 --> Utf8 Class Initialized
INFO - 2020-03-09 08:21:15 --> URI Class Initialized
INFO - 2020-03-09 08:21:15 --> Router Class Initialized
INFO - 2020-03-09 08:21:15 --> Output Class Initialized
INFO - 2020-03-09 08:21:15 --> Security Class Initialized
DEBUG - 2020-03-09 08:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 08:21:15 --> Input Class Initialized
INFO - 2020-03-09 08:21:15 --> Language Class Initialized
INFO - 2020-03-09 08:21:15 --> Loader Class Initialized
INFO - 2020-03-09 08:21:15 --> Helper loaded: url_helper
INFO - 2020-03-09 08:21:15 --> Helper loaded: string_helper
INFO - 2020-03-09 08:21:15 --> Database Driver Class Initialized
DEBUG - 2020-03-09 08:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 08:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 08:21:15 --> Controller Class Initialized
INFO - 2020-03-09 08:21:15 --> Model "M_tiket" initialized
INFO - 2020-03-09 08:21:15 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 08:21:15 --> Model "M_pesan" initialized
INFO - 2020-03-09 08:21:15 --> Helper loaded: form_helper
INFO - 2020-03-09 08:21:15 --> Form Validation Class Initialized
INFO - 2020-03-09 08:21:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-09 08:21:15 --> Final output sent to browser
DEBUG - 2020-03-09 08:21:15 --> Total execution time: 0.0588
INFO - 2020-03-09 08:21:17 --> Config Class Initialized
INFO - 2020-03-09 08:21:17 --> Hooks Class Initialized
DEBUG - 2020-03-09 08:21:17 --> UTF-8 Support Enabled
INFO - 2020-03-09 08:21:17 --> Utf8 Class Initialized
INFO - 2020-03-09 08:21:17 --> URI Class Initialized
INFO - 2020-03-09 08:21:17 --> Router Class Initialized
INFO - 2020-03-09 08:21:17 --> Output Class Initialized
INFO - 2020-03-09 08:21:17 --> Security Class Initialized
DEBUG - 2020-03-09 08:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 08:21:17 --> Input Class Initialized
INFO - 2020-03-09 08:21:17 --> Language Class Initialized
INFO - 2020-03-09 08:21:17 --> Loader Class Initialized
INFO - 2020-03-09 08:21:17 --> Helper loaded: url_helper
INFO - 2020-03-09 08:21:17 --> Helper loaded: string_helper
INFO - 2020-03-09 08:21:17 --> Database Driver Class Initialized
DEBUG - 2020-03-09 08:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 08:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 08:21:17 --> Controller Class Initialized
INFO - 2020-03-09 08:21:17 --> Model "M_tiket" initialized
INFO - 2020-03-09 08:21:17 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 08:21:17 --> Model "M_pesan" initialized
INFO - 2020-03-09 08:21:17 --> Helper loaded: form_helper
INFO - 2020-03-09 08:21:17 --> Form Validation Class Initialized
INFO - 2020-03-09 08:21:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-09 08:21:17 --> Final output sent to browser
DEBUG - 2020-03-09 08:21:17 --> Total execution time: 0.0083
INFO - 2020-03-09 08:21:17 --> Config Class Initialized
INFO - 2020-03-09 08:21:17 --> Hooks Class Initialized
DEBUG - 2020-03-09 08:21:17 --> UTF-8 Support Enabled
INFO - 2020-03-09 08:21:17 --> Utf8 Class Initialized
INFO - 2020-03-09 08:21:17 --> URI Class Initialized
INFO - 2020-03-09 08:21:17 --> Router Class Initialized
INFO - 2020-03-09 08:21:17 --> Output Class Initialized
INFO - 2020-03-09 08:21:17 --> Security Class Initialized
DEBUG - 2020-03-09 08:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 08:21:17 --> Input Class Initialized
INFO - 2020-03-09 08:21:17 --> Language Class Initialized
INFO - 2020-03-09 08:21:17 --> Loader Class Initialized
INFO - 2020-03-09 08:21:17 --> Helper loaded: url_helper
INFO - 2020-03-09 08:21:17 --> Helper loaded: string_helper
INFO - 2020-03-09 08:21:17 --> Database Driver Class Initialized
DEBUG - 2020-03-09 08:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 08:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 08:21:17 --> Controller Class Initialized
INFO - 2020-03-09 08:21:17 --> Model "M_tiket" initialized
INFO - 2020-03-09 08:21:17 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 08:21:17 --> Model "M_pesan" initialized
INFO - 2020-03-09 08:21:17 --> Helper loaded: form_helper
INFO - 2020-03-09 08:21:17 --> Form Validation Class Initialized
INFO - 2020-03-09 08:21:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-09 08:21:17 --> Final output sent to browser
DEBUG - 2020-03-09 08:21:17 --> Total execution time: 0.0065
INFO - 2020-03-09 08:22:20 --> Config Class Initialized
INFO - 2020-03-09 08:22:20 --> Hooks Class Initialized
DEBUG - 2020-03-09 08:22:20 --> UTF-8 Support Enabled
INFO - 2020-03-09 08:22:20 --> Utf8 Class Initialized
INFO - 2020-03-09 08:22:20 --> URI Class Initialized
INFO - 2020-03-09 08:22:20 --> Router Class Initialized
INFO - 2020-03-09 08:22:20 --> Output Class Initialized
INFO - 2020-03-09 08:22:20 --> Security Class Initialized
DEBUG - 2020-03-09 08:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 08:22:20 --> Input Class Initialized
INFO - 2020-03-09 08:22:20 --> Language Class Initialized
INFO - 2020-03-09 08:22:20 --> Loader Class Initialized
INFO - 2020-03-09 08:22:20 --> Helper loaded: url_helper
INFO - 2020-03-09 08:22:20 --> Helper loaded: string_helper
INFO - 2020-03-09 08:22:20 --> Database Driver Class Initialized
DEBUG - 2020-03-09 08:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 08:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 08:22:20 --> Controller Class Initialized
INFO - 2020-03-09 08:22:20 --> Model "M_tiket" initialized
INFO - 2020-03-09 08:22:20 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 08:22:20 --> Model "M_pesan" initialized
INFO - 2020-03-09 08:22:20 --> Helper loaded: form_helper
INFO - 2020-03-09 08:22:20 --> Form Validation Class Initialized
INFO - 2020-03-09 15:22:20 --> Upload Class Initialized
INFO - 2020-03-09 08:22:23 --> Config Class Initialized
INFO - 2020-03-09 08:22:23 --> Hooks Class Initialized
DEBUG - 2020-03-09 08:22:23 --> UTF-8 Support Enabled
INFO - 2020-03-09 08:22:23 --> Utf8 Class Initialized
INFO - 2020-03-09 08:22:23 --> URI Class Initialized
INFO - 2020-03-09 08:22:23 --> Router Class Initialized
INFO - 2020-03-09 08:22:23 --> Output Class Initialized
INFO - 2020-03-09 08:22:23 --> Security Class Initialized
DEBUG - 2020-03-09 08:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 08:22:23 --> Input Class Initialized
INFO - 2020-03-09 08:22:23 --> Language Class Initialized
INFO - 2020-03-09 08:22:23 --> Loader Class Initialized
INFO - 2020-03-09 08:22:23 --> Helper loaded: url_helper
INFO - 2020-03-09 08:22:23 --> Helper loaded: string_helper
INFO - 2020-03-09 08:22:23 --> Database Driver Class Initialized
DEBUG - 2020-03-09 08:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 08:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 08:22:23 --> Controller Class Initialized
INFO - 2020-03-09 08:22:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 08:22:23 --> Pagination Class Initialized
INFO - 2020-03-09 08:22:23 --> Model "M_show" initialized
INFO - 2020-03-09 08:22:23 --> Helper loaded: form_helper
INFO - 2020-03-09 08:22:23 --> Form Validation Class Initialized
INFO - 2020-03-09 08:22:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 08:22:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 08:22:23 --> Final output sent to browser
DEBUG - 2020-03-09 08:22:23 --> Total execution time: 0.0097
INFO - 2020-03-09 08:22:23 --> Config Class Initialized
INFO - 2020-03-09 08:22:23 --> Hooks Class Initialized
DEBUG - 2020-03-09 08:22:23 --> UTF-8 Support Enabled
INFO - 2020-03-09 08:22:23 --> Utf8 Class Initialized
INFO - 2020-03-09 08:22:23 --> URI Class Initialized
INFO - 2020-03-09 08:22:23 --> Router Class Initialized
INFO - 2020-03-09 08:22:23 --> Output Class Initialized
INFO - 2020-03-09 08:22:23 --> Security Class Initialized
DEBUG - 2020-03-09 08:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 08:22:23 --> Input Class Initialized
INFO - 2020-03-09 08:22:23 --> Language Class Initialized
ERROR - 2020-03-09 08:22:23 --> 404 Page Not Found: Engine0/jquery.js
INFO - 2020-03-09 08:22:39 --> Config Class Initialized
INFO - 2020-03-09 08:22:39 --> Hooks Class Initialized
DEBUG - 2020-03-09 08:22:39 --> UTF-8 Support Enabled
INFO - 2020-03-09 08:22:39 --> Utf8 Class Initialized
INFO - 2020-03-09 08:22:39 --> URI Class Initialized
INFO - 2020-03-09 08:22:39 --> Router Class Initialized
INFO - 2020-03-09 08:22:39 --> Output Class Initialized
INFO - 2020-03-09 08:22:39 --> Security Class Initialized
DEBUG - 2020-03-09 08:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 08:22:39 --> Input Class Initialized
INFO - 2020-03-09 08:22:39 --> Language Class Initialized
INFO - 2020-03-09 08:22:39 --> Loader Class Initialized
INFO - 2020-03-09 08:22:39 --> Helper loaded: url_helper
INFO - 2020-03-09 08:22:39 --> Helper loaded: string_helper
INFO - 2020-03-09 08:22:39 --> Database Driver Class Initialized
DEBUG - 2020-03-09 08:22:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 08:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 08:22:39 --> Controller Class Initialized
INFO - 2020-03-09 08:22:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 08:22:39 --> Pagination Class Initialized
INFO - 2020-03-09 08:22:39 --> Model "M_show" initialized
INFO - 2020-03-09 08:22:39 --> Helper loaded: form_helper
INFO - 2020-03-09 08:22:39 --> Form Validation Class Initialized
INFO - 2020-03-09 08:22:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 08:22:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 08:22:39 --> Final output sent to browser
DEBUG - 2020-03-09 08:22:39 --> Total execution time: 0.0058
INFO - 2020-03-09 08:22:39 --> Config Class Initialized
INFO - 2020-03-09 08:22:39 --> Hooks Class Initialized
DEBUG - 2020-03-09 08:22:39 --> UTF-8 Support Enabled
INFO - 2020-03-09 08:22:39 --> Utf8 Class Initialized
INFO - 2020-03-09 08:22:39 --> URI Class Initialized
INFO - 2020-03-09 08:22:39 --> Router Class Initialized
INFO - 2020-03-09 08:22:39 --> Output Class Initialized
INFO - 2020-03-09 08:22:39 --> Security Class Initialized
DEBUG - 2020-03-09 08:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 08:22:39 --> Input Class Initialized
INFO - 2020-03-09 08:22:39 --> Language Class Initialized
ERROR - 2020-03-09 08:22:39 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-09 08:27:12 --> Config Class Initialized
INFO - 2020-03-09 08:27:12 --> Hooks Class Initialized
DEBUG - 2020-03-09 08:27:12 --> UTF-8 Support Enabled
INFO - 2020-03-09 08:27:12 --> Utf8 Class Initialized
INFO - 2020-03-09 08:27:12 --> URI Class Initialized
INFO - 2020-03-09 08:27:12 --> Router Class Initialized
INFO - 2020-03-09 08:27:12 --> Output Class Initialized
INFO - 2020-03-09 08:27:12 --> Security Class Initialized
DEBUG - 2020-03-09 08:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 08:27:12 --> Input Class Initialized
INFO - 2020-03-09 08:27:12 --> Language Class Initialized
INFO - 2020-03-09 08:27:12 --> Loader Class Initialized
INFO - 2020-03-09 08:27:12 --> Helper loaded: url_helper
INFO - 2020-03-09 08:27:12 --> Helper loaded: string_helper
INFO - 2020-03-09 08:27:12 --> Database Driver Class Initialized
DEBUG - 2020-03-09 08:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 08:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 08:27:12 --> Controller Class Initialized
INFO - 2020-03-09 08:27:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 08:27:12 --> Pagination Class Initialized
INFO - 2020-03-09 08:27:12 --> Model "M_show" initialized
INFO - 2020-03-09 08:27:12 --> Helper loaded: form_helper
INFO - 2020-03-09 08:27:12 --> Form Validation Class Initialized
INFO - 2020-03-09 08:27:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 08:27:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 08:27:12 --> Final output sent to browser
DEBUG - 2020-03-09 08:27:12 --> Total execution time: 0.0623
INFO - 2020-03-09 08:27:12 --> Config Class Initialized
INFO - 2020-03-09 08:27:12 --> Hooks Class Initialized
DEBUG - 2020-03-09 08:27:12 --> UTF-8 Support Enabled
INFO - 2020-03-09 08:27:12 --> Utf8 Class Initialized
INFO - 2020-03-09 08:27:12 --> URI Class Initialized
INFO - 2020-03-09 08:27:12 --> Router Class Initialized
INFO - 2020-03-09 08:27:12 --> Output Class Initialized
INFO - 2020-03-09 08:27:12 --> Security Class Initialized
DEBUG - 2020-03-09 08:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 08:27:12 --> Input Class Initialized
INFO - 2020-03-09 08:27:12 --> Language Class Initialized
ERROR - 2020-03-09 08:27:12 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-09 08:33:48 --> Config Class Initialized
INFO - 2020-03-09 08:33:48 --> Hooks Class Initialized
DEBUG - 2020-03-09 08:33:48 --> UTF-8 Support Enabled
INFO - 2020-03-09 08:33:48 --> Utf8 Class Initialized
INFO - 2020-03-09 08:33:48 --> URI Class Initialized
INFO - 2020-03-09 08:33:48 --> Router Class Initialized
INFO - 2020-03-09 08:33:48 --> Output Class Initialized
INFO - 2020-03-09 08:33:48 --> Security Class Initialized
DEBUG - 2020-03-09 08:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 08:33:48 --> Input Class Initialized
INFO - 2020-03-09 08:33:48 --> Language Class Initialized
INFO - 2020-03-09 08:33:48 --> Loader Class Initialized
INFO - 2020-03-09 08:33:48 --> Helper loaded: url_helper
INFO - 2020-03-09 08:33:48 --> Helper loaded: string_helper
INFO - 2020-03-09 08:33:48 --> Database Driver Class Initialized
DEBUG - 2020-03-09 08:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 08:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 08:33:48 --> Controller Class Initialized
INFO - 2020-03-09 08:33:48 --> Model "M_tiket" initialized
INFO - 2020-03-09 08:33:48 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 08:33:48 --> Model "M_pesan" initialized
INFO - 2020-03-09 08:33:48 --> Helper loaded: form_helper
INFO - 2020-03-09 08:33:48 --> Form Validation Class Initialized
DEBUG - 2020-03-09 08:33:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-09 08:33:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-09 15:33:48 --> Final output sent to browser
DEBUG - 2020-03-09 15:33:48 --> Total execution time: 0.1904
INFO - 2020-03-09 08:34:20 --> Config Class Initialized
INFO - 2020-03-09 08:34:20 --> Hooks Class Initialized
DEBUG - 2020-03-09 08:34:20 --> UTF-8 Support Enabled
INFO - 2020-03-09 08:34:20 --> Utf8 Class Initialized
INFO - 2020-03-09 08:34:20 --> URI Class Initialized
INFO - 2020-03-09 08:34:20 --> Router Class Initialized
INFO - 2020-03-09 08:34:20 --> Output Class Initialized
INFO - 2020-03-09 08:34:20 --> Security Class Initialized
DEBUG - 2020-03-09 08:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 08:34:20 --> Input Class Initialized
INFO - 2020-03-09 08:34:20 --> Language Class Initialized
INFO - 2020-03-09 08:34:20 --> Loader Class Initialized
INFO - 2020-03-09 08:34:20 --> Helper loaded: url_helper
INFO - 2020-03-09 08:34:20 --> Helper loaded: string_helper
INFO - 2020-03-09 08:34:20 --> Database Driver Class Initialized
DEBUG - 2020-03-09 08:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 08:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 08:34:20 --> Controller Class Initialized
INFO - 2020-03-09 08:34:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 08:34:20 --> Pagination Class Initialized
INFO - 2020-03-09 08:34:20 --> Model "M_show" initialized
INFO - 2020-03-09 08:34:20 --> Helper loaded: form_helper
INFO - 2020-03-09 08:34:20 --> Form Validation Class Initialized
INFO - 2020-03-09 08:34:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 08:34:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 08:34:20 --> Final output sent to browser
DEBUG - 2020-03-09 08:34:20 --> Total execution time: 0.0084
INFO - 2020-03-09 08:42:05 --> Config Class Initialized
INFO - 2020-03-09 08:42:05 --> Hooks Class Initialized
DEBUG - 2020-03-09 08:42:05 --> UTF-8 Support Enabled
INFO - 2020-03-09 08:42:05 --> Utf8 Class Initialized
INFO - 2020-03-09 08:42:05 --> URI Class Initialized
DEBUG - 2020-03-09 08:42:05 --> No URI present. Default controller set.
INFO - 2020-03-09 08:42:05 --> Router Class Initialized
INFO - 2020-03-09 08:42:05 --> Output Class Initialized
INFO - 2020-03-09 08:42:05 --> Security Class Initialized
DEBUG - 2020-03-09 08:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 08:42:05 --> Input Class Initialized
INFO - 2020-03-09 08:42:05 --> Language Class Initialized
INFO - 2020-03-09 08:42:05 --> Loader Class Initialized
INFO - 2020-03-09 08:42:05 --> Helper loaded: url_helper
INFO - 2020-03-09 08:42:05 --> Helper loaded: string_helper
INFO - 2020-03-09 08:42:05 --> Database Driver Class Initialized
DEBUG - 2020-03-09 08:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 08:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 08:42:05 --> Controller Class Initialized
INFO - 2020-03-09 08:42:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 08:42:05 --> Pagination Class Initialized
INFO - 2020-03-09 08:42:05 --> Model "M_show" initialized
INFO - 2020-03-09 08:42:06 --> Helper loaded: form_helper
INFO - 2020-03-09 08:42:06 --> Form Validation Class Initialized
INFO - 2020-03-09 08:42:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 08:42:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 08:42:06 --> Final output sent to browser
DEBUG - 2020-03-09 08:42:06 --> Total execution time: 0.0498
INFO - 2020-03-09 08:42:06 --> Config Class Initialized
INFO - 2020-03-09 08:42:06 --> Hooks Class Initialized
DEBUG - 2020-03-09 08:42:06 --> UTF-8 Support Enabled
INFO - 2020-03-09 08:42:06 --> Utf8 Class Initialized
INFO - 2020-03-09 08:42:06 --> URI Class Initialized
DEBUG - 2020-03-09 08:42:06 --> No URI present. Default controller set.
INFO - 2020-03-09 08:42:06 --> Router Class Initialized
INFO - 2020-03-09 08:42:06 --> Output Class Initialized
INFO - 2020-03-09 08:42:06 --> Security Class Initialized
DEBUG - 2020-03-09 08:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 08:42:06 --> Input Class Initialized
INFO - 2020-03-09 08:42:06 --> Language Class Initialized
INFO - 2020-03-09 08:42:06 --> Loader Class Initialized
INFO - 2020-03-09 08:42:06 --> Helper loaded: url_helper
INFO - 2020-03-09 08:42:06 --> Helper loaded: string_helper
INFO - 2020-03-09 08:42:06 --> Database Driver Class Initialized
DEBUG - 2020-03-09 08:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 08:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 08:42:06 --> Controller Class Initialized
INFO - 2020-03-09 08:42:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 08:42:06 --> Pagination Class Initialized
INFO - 2020-03-09 08:42:06 --> Model "M_show" initialized
INFO - 2020-03-09 08:42:06 --> Helper loaded: form_helper
INFO - 2020-03-09 08:42:06 --> Form Validation Class Initialized
INFO - 2020-03-09 08:42:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 08:42:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 08:42:06 --> Final output sent to browser
DEBUG - 2020-03-09 08:42:06 --> Total execution time: 0.0076
INFO - 2020-03-09 08:42:14 --> Config Class Initialized
INFO - 2020-03-09 08:42:14 --> Hooks Class Initialized
DEBUG - 2020-03-09 08:42:14 --> UTF-8 Support Enabled
INFO - 2020-03-09 08:42:14 --> Utf8 Class Initialized
INFO - 2020-03-09 08:42:14 --> URI Class Initialized
INFO - 2020-03-09 08:42:14 --> Router Class Initialized
INFO - 2020-03-09 08:42:14 --> Output Class Initialized
INFO - 2020-03-09 08:42:14 --> Security Class Initialized
DEBUG - 2020-03-09 08:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 08:42:14 --> Input Class Initialized
INFO - 2020-03-09 08:42:14 --> Language Class Initialized
INFO - 2020-03-09 08:42:14 --> Loader Class Initialized
INFO - 2020-03-09 08:42:14 --> Helper loaded: url_helper
INFO - 2020-03-09 08:42:14 --> Helper loaded: string_helper
INFO - 2020-03-09 08:42:14 --> Database Driver Class Initialized
DEBUG - 2020-03-09 08:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 08:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 08:42:14 --> Controller Class Initialized
INFO - 2020-03-09 08:42:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 08:42:14 --> Pagination Class Initialized
INFO - 2020-03-09 08:42:14 --> Model "M_show" initialized
INFO - 2020-03-09 08:42:14 --> Helper loaded: form_helper
INFO - 2020-03-09 08:42:14 --> Form Validation Class Initialized
INFO - 2020-03-09 08:42:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 08:42:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 08:42:14 --> Final output sent to browser
DEBUG - 2020-03-09 08:42:14 --> Total execution time: 0.0090
INFO - 2020-03-09 08:42:18 --> Config Class Initialized
INFO - 2020-03-09 08:42:18 --> Hooks Class Initialized
DEBUG - 2020-03-09 08:42:18 --> UTF-8 Support Enabled
INFO - 2020-03-09 08:42:18 --> Utf8 Class Initialized
INFO - 2020-03-09 08:42:18 --> URI Class Initialized
INFO - 2020-03-09 08:42:18 --> Router Class Initialized
INFO - 2020-03-09 08:42:18 --> Output Class Initialized
INFO - 2020-03-09 08:42:18 --> Security Class Initialized
DEBUG - 2020-03-09 08:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 08:42:18 --> Input Class Initialized
INFO - 2020-03-09 08:42:18 --> Language Class Initialized
INFO - 2020-03-09 08:42:18 --> Loader Class Initialized
INFO - 2020-03-09 08:42:18 --> Helper loaded: url_helper
INFO - 2020-03-09 08:42:18 --> Helper loaded: string_helper
INFO - 2020-03-09 08:42:18 --> Database Driver Class Initialized
DEBUG - 2020-03-09 08:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 08:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 08:42:19 --> Controller Class Initialized
INFO - 2020-03-09 08:42:19 --> Model "M_tiket" initialized
INFO - 2020-03-09 08:42:19 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 08:42:19 --> Model "M_pesan" initialized
INFO - 2020-03-09 08:42:19 --> Helper loaded: form_helper
INFO - 2020-03-09 08:42:19 --> Form Validation Class Initialized
INFO - 2020-03-09 08:42:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-09 08:42:19 --> Final output sent to browser
DEBUG - 2020-03-09 08:42:19 --> Total execution time: 0.5443
INFO - 2020-03-09 08:42:58 --> Config Class Initialized
INFO - 2020-03-09 08:42:58 --> Hooks Class Initialized
DEBUG - 2020-03-09 08:42:58 --> UTF-8 Support Enabled
INFO - 2020-03-09 08:42:58 --> Utf8 Class Initialized
INFO - 2020-03-09 08:42:58 --> URI Class Initialized
INFO - 2020-03-09 08:42:58 --> Router Class Initialized
INFO - 2020-03-09 08:42:58 --> Output Class Initialized
INFO - 2020-03-09 08:42:58 --> Security Class Initialized
DEBUG - 2020-03-09 08:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 08:42:58 --> Input Class Initialized
INFO - 2020-03-09 08:42:58 --> Language Class Initialized
INFO - 2020-03-09 08:42:58 --> Loader Class Initialized
INFO - 2020-03-09 08:42:58 --> Helper loaded: url_helper
INFO - 2020-03-09 08:42:58 --> Helper loaded: string_helper
INFO - 2020-03-09 08:42:58 --> Database Driver Class Initialized
DEBUG - 2020-03-09 08:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 08:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 08:42:58 --> Controller Class Initialized
INFO - 2020-03-09 08:42:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 08:42:58 --> Pagination Class Initialized
INFO - 2020-03-09 08:42:58 --> Model "M_show" initialized
INFO - 2020-03-09 08:42:58 --> Helper loaded: form_helper
INFO - 2020-03-09 08:42:58 --> Form Validation Class Initialized
INFO - 2020-03-09 08:42:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 08:42:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 08:42:58 --> Final output sent to browser
DEBUG - 2020-03-09 08:42:58 --> Total execution time: 0.0078
INFO - 2020-03-09 08:43:00 --> Config Class Initialized
INFO - 2020-03-09 08:43:00 --> Hooks Class Initialized
DEBUG - 2020-03-09 08:43:00 --> UTF-8 Support Enabled
INFO - 2020-03-09 08:43:00 --> Utf8 Class Initialized
INFO - 2020-03-09 08:43:00 --> URI Class Initialized
DEBUG - 2020-03-09 08:43:00 --> No URI present. Default controller set.
INFO - 2020-03-09 08:43:00 --> Router Class Initialized
INFO - 2020-03-09 08:43:00 --> Output Class Initialized
INFO - 2020-03-09 08:43:00 --> Security Class Initialized
DEBUG - 2020-03-09 08:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 08:43:00 --> Input Class Initialized
INFO - 2020-03-09 08:43:00 --> Language Class Initialized
INFO - 2020-03-09 08:43:00 --> Loader Class Initialized
INFO - 2020-03-09 08:43:00 --> Helper loaded: url_helper
INFO - 2020-03-09 08:43:00 --> Helper loaded: string_helper
INFO - 2020-03-09 08:43:00 --> Database Driver Class Initialized
DEBUG - 2020-03-09 08:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 08:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 08:43:00 --> Controller Class Initialized
INFO - 2020-03-09 08:43:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 08:43:00 --> Pagination Class Initialized
INFO - 2020-03-09 08:43:00 --> Model "M_show" initialized
INFO - 2020-03-09 08:43:00 --> Helper loaded: form_helper
INFO - 2020-03-09 08:43:00 --> Form Validation Class Initialized
INFO - 2020-03-09 08:43:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 08:43:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 08:43:00 --> Final output sent to browser
DEBUG - 2020-03-09 08:43:00 --> Total execution time: 0.0057
INFO - 2020-03-09 08:43:06 --> Config Class Initialized
INFO - 2020-03-09 08:43:06 --> Hooks Class Initialized
DEBUG - 2020-03-09 08:43:06 --> UTF-8 Support Enabled
INFO - 2020-03-09 08:43:06 --> Utf8 Class Initialized
INFO - 2020-03-09 08:43:06 --> URI Class Initialized
INFO - 2020-03-09 08:43:06 --> Router Class Initialized
INFO - 2020-03-09 08:43:06 --> Output Class Initialized
INFO - 2020-03-09 08:43:06 --> Security Class Initialized
DEBUG - 2020-03-09 08:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 08:43:06 --> Input Class Initialized
INFO - 2020-03-09 08:43:06 --> Language Class Initialized
INFO - 2020-03-09 08:43:06 --> Loader Class Initialized
INFO - 2020-03-09 08:43:06 --> Helper loaded: url_helper
INFO - 2020-03-09 08:43:06 --> Helper loaded: string_helper
INFO - 2020-03-09 08:43:06 --> Database Driver Class Initialized
DEBUG - 2020-03-09 08:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 08:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 08:43:06 --> Controller Class Initialized
INFO - 2020-03-09 08:43:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 08:43:06 --> Pagination Class Initialized
INFO - 2020-03-09 08:43:06 --> Model "M_show" initialized
INFO - 2020-03-09 08:43:06 --> Helper loaded: form_helper
INFO - 2020-03-09 08:43:06 --> Form Validation Class Initialized
INFO - 2020-03-09 08:43:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 08:43:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-09 08:43:06 --> Final output sent to browser
DEBUG - 2020-03-09 08:43:06 --> Total execution time: 0.0932
INFO - 2020-03-09 08:43:24 --> Config Class Initialized
INFO - 2020-03-09 08:43:24 --> Hooks Class Initialized
DEBUG - 2020-03-09 08:43:24 --> UTF-8 Support Enabled
INFO - 2020-03-09 08:43:24 --> Utf8 Class Initialized
INFO - 2020-03-09 08:43:24 --> URI Class Initialized
INFO - 2020-03-09 08:43:24 --> Router Class Initialized
INFO - 2020-03-09 08:43:24 --> Output Class Initialized
INFO - 2020-03-09 08:43:24 --> Security Class Initialized
DEBUG - 2020-03-09 08:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 08:43:24 --> Input Class Initialized
INFO - 2020-03-09 08:43:24 --> Language Class Initialized
INFO - 2020-03-09 08:43:24 --> Loader Class Initialized
INFO - 2020-03-09 08:43:24 --> Helper loaded: url_helper
INFO - 2020-03-09 08:43:24 --> Helper loaded: string_helper
INFO - 2020-03-09 08:43:24 --> Database Driver Class Initialized
DEBUG - 2020-03-09 08:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 08:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 08:43:24 --> Controller Class Initialized
INFO - 2020-03-09 08:43:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 08:43:24 --> Pagination Class Initialized
INFO - 2020-03-09 08:43:24 --> Model "M_show" initialized
INFO - 2020-03-09 08:43:24 --> Helper loaded: form_helper
INFO - 2020-03-09 08:43:24 --> Form Validation Class Initialized
INFO - 2020-03-09 08:43:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 08:43:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-09 08:43:24 --> Final output sent to browser
DEBUG - 2020-03-09 08:43:24 --> Total execution time: 0.0155
INFO - 2020-03-09 08:44:07 --> Config Class Initialized
INFO - 2020-03-09 08:44:07 --> Hooks Class Initialized
DEBUG - 2020-03-09 08:44:07 --> UTF-8 Support Enabled
INFO - 2020-03-09 08:44:07 --> Utf8 Class Initialized
INFO - 2020-03-09 08:44:07 --> URI Class Initialized
INFO - 2020-03-09 08:44:07 --> Router Class Initialized
INFO - 2020-03-09 08:44:07 --> Output Class Initialized
INFO - 2020-03-09 08:44:07 --> Security Class Initialized
DEBUG - 2020-03-09 08:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 08:44:07 --> Input Class Initialized
INFO - 2020-03-09 08:44:07 --> Language Class Initialized
INFO - 2020-03-09 08:44:07 --> Loader Class Initialized
INFO - 2020-03-09 08:44:07 --> Helper loaded: url_helper
INFO - 2020-03-09 08:44:07 --> Helper loaded: string_helper
INFO - 2020-03-09 08:44:07 --> Database Driver Class Initialized
DEBUG - 2020-03-09 08:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 08:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 08:44:07 --> Controller Class Initialized
INFO - 2020-03-09 08:44:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 08:44:07 --> Pagination Class Initialized
INFO - 2020-03-09 08:44:07 --> Model "M_show" initialized
INFO - 2020-03-09 08:44:07 --> Helper loaded: form_helper
INFO - 2020-03-09 08:44:07 --> Form Validation Class Initialized
INFO - 2020-03-09 08:44:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 08:44:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 08:44:07 --> Final output sent to browser
DEBUG - 2020-03-09 08:44:07 --> Total execution time: 0.0055
INFO - 2020-03-09 08:46:28 --> Config Class Initialized
INFO - 2020-03-09 08:46:28 --> Hooks Class Initialized
DEBUG - 2020-03-09 08:46:28 --> UTF-8 Support Enabled
INFO - 2020-03-09 08:46:28 --> Utf8 Class Initialized
INFO - 2020-03-09 08:46:28 --> URI Class Initialized
INFO - 2020-03-09 08:46:28 --> Router Class Initialized
INFO - 2020-03-09 08:46:28 --> Output Class Initialized
INFO - 2020-03-09 08:46:28 --> Security Class Initialized
DEBUG - 2020-03-09 08:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 08:46:28 --> Input Class Initialized
INFO - 2020-03-09 08:46:28 --> Language Class Initialized
INFO - 2020-03-09 08:46:28 --> Loader Class Initialized
INFO - 2020-03-09 08:46:28 --> Helper loaded: url_helper
INFO - 2020-03-09 08:46:28 --> Helper loaded: string_helper
INFO - 2020-03-09 08:46:28 --> Database Driver Class Initialized
DEBUG - 2020-03-09 08:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 08:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 08:46:28 --> Controller Class Initialized
INFO - 2020-03-09 08:46:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 08:46:28 --> Pagination Class Initialized
INFO - 2020-03-09 08:46:28 --> Model "M_show" initialized
INFO - 2020-03-09 08:46:28 --> Helper loaded: form_helper
INFO - 2020-03-09 08:46:28 --> Form Validation Class Initialized
INFO - 2020-03-09 08:46:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 08:46:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 08:46:28 --> Final output sent to browser
DEBUG - 2020-03-09 08:46:28 --> Total execution time: 0.0419
INFO - 2020-03-09 08:50:11 --> Config Class Initialized
INFO - 2020-03-09 08:50:11 --> Hooks Class Initialized
DEBUG - 2020-03-09 08:50:11 --> UTF-8 Support Enabled
INFO - 2020-03-09 08:50:11 --> Utf8 Class Initialized
INFO - 2020-03-09 08:50:11 --> URI Class Initialized
INFO - 2020-03-09 08:50:11 --> Router Class Initialized
INFO - 2020-03-09 08:50:11 --> Output Class Initialized
INFO - 2020-03-09 08:50:11 --> Security Class Initialized
DEBUG - 2020-03-09 08:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 08:50:11 --> Input Class Initialized
INFO - 2020-03-09 08:50:11 --> Language Class Initialized
INFO - 2020-03-09 08:50:11 --> Loader Class Initialized
INFO - 2020-03-09 08:50:11 --> Helper loaded: url_helper
INFO - 2020-03-09 08:50:11 --> Helper loaded: string_helper
INFO - 2020-03-09 08:50:11 --> Database Driver Class Initialized
DEBUG - 2020-03-09 08:50:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 08:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 08:50:11 --> Controller Class Initialized
INFO - 2020-03-09 08:50:11 --> Model "M_tiket" initialized
INFO - 2020-03-09 08:50:11 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 08:50:11 --> Model "M_pesan" initialized
INFO - 2020-03-09 08:50:11 --> Helper loaded: form_helper
INFO - 2020-03-09 08:50:11 --> Form Validation Class Initialized
INFO - 2020-03-09 08:50:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-09 08:50:11 --> Final output sent to browser
DEBUG - 2020-03-09 08:50:11 --> Total execution time: 0.0577
INFO - 2020-03-09 08:50:24 --> Config Class Initialized
INFO - 2020-03-09 08:50:24 --> Hooks Class Initialized
DEBUG - 2020-03-09 08:50:24 --> UTF-8 Support Enabled
INFO - 2020-03-09 08:50:24 --> Utf8 Class Initialized
INFO - 2020-03-09 08:50:24 --> URI Class Initialized
INFO - 2020-03-09 08:50:24 --> Router Class Initialized
INFO - 2020-03-09 08:50:24 --> Output Class Initialized
INFO - 2020-03-09 08:50:24 --> Security Class Initialized
DEBUG - 2020-03-09 08:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 08:50:24 --> Input Class Initialized
INFO - 2020-03-09 08:50:24 --> Language Class Initialized
INFO - 2020-03-09 08:50:24 --> Loader Class Initialized
INFO - 2020-03-09 08:50:24 --> Helper loaded: url_helper
INFO - 2020-03-09 08:50:24 --> Helper loaded: string_helper
INFO - 2020-03-09 08:50:24 --> Database Driver Class Initialized
DEBUG - 2020-03-09 08:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 08:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 08:50:24 --> Controller Class Initialized
INFO - 2020-03-09 08:50:24 --> Model "M_tiket" initialized
INFO - 2020-03-09 08:50:24 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 08:50:24 --> Model "M_pesan" initialized
INFO - 2020-03-09 08:50:24 --> Helper loaded: form_helper
INFO - 2020-03-09 08:50:24 --> Form Validation Class Initialized
INFO - 2020-03-09 08:50:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-09 08:50:24 --> Final output sent to browser
DEBUG - 2020-03-09 08:50:24 --> Total execution time: 0.0082
INFO - 2020-03-09 09:41:17 --> Config Class Initialized
INFO - 2020-03-09 09:41:18 --> Hooks Class Initialized
DEBUG - 2020-03-09 09:41:18 --> UTF-8 Support Enabled
INFO - 2020-03-09 09:41:18 --> Utf8 Class Initialized
INFO - 2020-03-09 09:41:18 --> URI Class Initialized
DEBUG - 2020-03-09 09:41:18 --> No URI present. Default controller set.
INFO - 2020-03-09 09:41:18 --> Router Class Initialized
INFO - 2020-03-09 09:41:18 --> Output Class Initialized
INFO - 2020-03-09 09:41:18 --> Security Class Initialized
DEBUG - 2020-03-09 09:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 09:41:18 --> Input Class Initialized
INFO - 2020-03-09 09:41:18 --> Language Class Initialized
INFO - 2020-03-09 09:41:18 --> Loader Class Initialized
INFO - 2020-03-09 09:41:18 --> Helper loaded: url_helper
INFO - 2020-03-09 09:41:19 --> Helper loaded: string_helper
INFO - 2020-03-09 09:41:19 --> Database Driver Class Initialized
DEBUG - 2020-03-09 09:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 09:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 09:41:19 --> Controller Class Initialized
INFO - 2020-03-09 09:41:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 09:41:19 --> Pagination Class Initialized
INFO - 2020-03-09 09:41:19 --> Model "M_show" initialized
INFO - 2020-03-09 09:41:19 --> Helper loaded: form_helper
INFO - 2020-03-09 09:41:19 --> Form Validation Class Initialized
INFO - 2020-03-09 09:41:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 09:41:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 09:41:19 --> Final output sent to browser
DEBUG - 2020-03-09 09:41:19 --> Total execution time: 1.4341
INFO - 2020-03-09 09:41:39 --> Config Class Initialized
INFO - 2020-03-09 09:41:39 --> Hooks Class Initialized
DEBUG - 2020-03-09 09:41:39 --> UTF-8 Support Enabled
INFO - 2020-03-09 09:41:39 --> Utf8 Class Initialized
INFO - 2020-03-09 09:41:39 --> URI Class Initialized
INFO - 2020-03-09 09:41:39 --> Router Class Initialized
INFO - 2020-03-09 09:41:39 --> Output Class Initialized
INFO - 2020-03-09 09:41:39 --> Security Class Initialized
DEBUG - 2020-03-09 09:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 09:41:39 --> Input Class Initialized
INFO - 2020-03-09 09:41:39 --> Language Class Initialized
INFO - 2020-03-09 09:41:39 --> Loader Class Initialized
INFO - 2020-03-09 09:41:39 --> Helper loaded: url_helper
INFO - 2020-03-09 09:41:39 --> Helper loaded: string_helper
INFO - 2020-03-09 09:41:39 --> Database Driver Class Initialized
DEBUG - 2020-03-09 09:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 09:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 09:41:39 --> Controller Class Initialized
INFO - 2020-03-09 09:41:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 09:41:39 --> Pagination Class Initialized
INFO - 2020-03-09 09:41:39 --> Model "M_show" initialized
INFO - 2020-03-09 09:41:39 --> Helper loaded: form_helper
INFO - 2020-03-09 09:41:39 --> Form Validation Class Initialized
INFO - 2020-03-09 09:41:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 09:41:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-09 09:41:39 --> Final output sent to browser
DEBUG - 2020-03-09 09:41:39 --> Total execution time: 0.0412
INFO - 2020-03-09 09:41:57 --> Config Class Initialized
INFO - 2020-03-09 09:41:57 --> Hooks Class Initialized
DEBUG - 2020-03-09 09:41:57 --> UTF-8 Support Enabled
INFO - 2020-03-09 09:41:57 --> Utf8 Class Initialized
INFO - 2020-03-09 09:41:57 --> URI Class Initialized
INFO - 2020-03-09 09:41:57 --> Router Class Initialized
INFO - 2020-03-09 09:41:57 --> Output Class Initialized
INFO - 2020-03-09 09:41:57 --> Security Class Initialized
DEBUG - 2020-03-09 09:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 09:41:57 --> Input Class Initialized
INFO - 2020-03-09 09:41:57 --> Language Class Initialized
INFO - 2020-03-09 09:41:57 --> Loader Class Initialized
INFO - 2020-03-09 09:41:57 --> Helper loaded: url_helper
INFO - 2020-03-09 09:41:57 --> Helper loaded: string_helper
INFO - 2020-03-09 09:41:57 --> Database Driver Class Initialized
DEBUG - 2020-03-09 09:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 09:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 09:41:57 --> Controller Class Initialized
INFO - 2020-03-09 09:41:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 09:41:57 --> Pagination Class Initialized
INFO - 2020-03-09 09:41:57 --> Model "M_show" initialized
INFO - 2020-03-09 09:41:57 --> Helper loaded: form_helper
INFO - 2020-03-09 09:41:57 --> Form Validation Class Initialized
INFO - 2020-03-09 09:41:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 09:41:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 09:41:57 --> Final output sent to browser
DEBUG - 2020-03-09 09:41:57 --> Total execution time: 0.0089
INFO - 2020-03-09 09:42:01 --> Config Class Initialized
INFO - 2020-03-09 09:42:01 --> Hooks Class Initialized
DEBUG - 2020-03-09 09:42:01 --> UTF-8 Support Enabled
INFO - 2020-03-09 09:42:01 --> Utf8 Class Initialized
INFO - 2020-03-09 09:42:01 --> URI Class Initialized
INFO - 2020-03-09 09:42:01 --> Router Class Initialized
INFO - 2020-03-09 09:42:01 --> Output Class Initialized
INFO - 2020-03-09 09:42:01 --> Security Class Initialized
DEBUG - 2020-03-09 09:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 09:42:01 --> Input Class Initialized
INFO - 2020-03-09 09:42:01 --> Language Class Initialized
INFO - 2020-03-09 09:42:01 --> Loader Class Initialized
INFO - 2020-03-09 09:42:01 --> Helper loaded: url_helper
INFO - 2020-03-09 09:42:01 --> Helper loaded: string_helper
INFO - 2020-03-09 09:42:01 --> Database Driver Class Initialized
DEBUG - 2020-03-09 09:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 09:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 09:42:01 --> Controller Class Initialized
INFO - 2020-03-09 09:42:01 --> Model "M_tiket" initialized
INFO - 2020-03-09 09:42:01 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 09:42:01 --> Model "M_pesan" initialized
INFO - 2020-03-09 09:42:01 --> Helper loaded: form_helper
INFO - 2020-03-09 09:42:01 --> Form Validation Class Initialized
INFO - 2020-03-09 09:42:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-09 09:42:01 --> Final output sent to browser
DEBUG - 2020-03-09 09:42:01 --> Total execution time: 0.0229
INFO - 2020-03-09 09:42:31 --> Config Class Initialized
INFO - 2020-03-09 09:42:31 --> Hooks Class Initialized
DEBUG - 2020-03-09 09:42:31 --> UTF-8 Support Enabled
INFO - 2020-03-09 09:42:31 --> Utf8 Class Initialized
INFO - 2020-03-09 09:42:31 --> URI Class Initialized
INFO - 2020-03-09 09:42:31 --> Router Class Initialized
INFO - 2020-03-09 09:42:31 --> Output Class Initialized
INFO - 2020-03-09 09:42:31 --> Security Class Initialized
DEBUG - 2020-03-09 09:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 09:42:31 --> Input Class Initialized
INFO - 2020-03-09 09:42:31 --> Language Class Initialized
INFO - 2020-03-09 09:42:31 --> Loader Class Initialized
INFO - 2020-03-09 09:42:31 --> Helper loaded: url_helper
INFO - 2020-03-09 09:42:31 --> Helper loaded: string_helper
INFO - 2020-03-09 09:42:31 --> Database Driver Class Initialized
DEBUG - 2020-03-09 09:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 09:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 09:42:31 --> Controller Class Initialized
INFO - 2020-03-09 09:42:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 09:42:31 --> Pagination Class Initialized
INFO - 2020-03-09 09:42:31 --> Model "M_show" initialized
INFO - 2020-03-09 09:42:31 --> Helper loaded: form_helper
INFO - 2020-03-09 09:42:31 --> Form Validation Class Initialized
INFO - 2020-03-09 09:42:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 09:42:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 09:42:31 --> Final output sent to browser
DEBUG - 2020-03-09 09:42:31 --> Total execution time: 0.0072
INFO - 2020-03-09 09:42:34 --> Config Class Initialized
INFO - 2020-03-09 09:42:34 --> Hooks Class Initialized
DEBUG - 2020-03-09 09:42:34 --> UTF-8 Support Enabled
INFO - 2020-03-09 09:42:34 --> Utf8 Class Initialized
INFO - 2020-03-09 09:42:34 --> URI Class Initialized
INFO - 2020-03-09 09:42:34 --> Router Class Initialized
INFO - 2020-03-09 09:42:34 --> Output Class Initialized
INFO - 2020-03-09 09:42:34 --> Security Class Initialized
DEBUG - 2020-03-09 09:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 09:42:34 --> Input Class Initialized
INFO - 2020-03-09 09:42:34 --> Language Class Initialized
INFO - 2020-03-09 09:42:34 --> Loader Class Initialized
INFO - 2020-03-09 09:42:34 --> Helper loaded: url_helper
INFO - 2020-03-09 09:42:34 --> Helper loaded: string_helper
INFO - 2020-03-09 09:42:34 --> Database Driver Class Initialized
DEBUG - 2020-03-09 09:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 09:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 09:42:34 --> Controller Class Initialized
INFO - 2020-03-09 09:42:34 --> Model "M_tiket" initialized
INFO - 2020-03-09 09:42:34 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 09:42:34 --> Model "M_pesan" initialized
INFO - 2020-03-09 09:42:34 --> Helper loaded: form_helper
INFO - 2020-03-09 09:42:34 --> Form Validation Class Initialized
INFO - 2020-03-09 09:42:34 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-09 09:42:34 --> Final output sent to browser
DEBUG - 2020-03-09 09:42:34 --> Total execution time: 0.0075
INFO - 2020-03-09 09:42:35 --> Config Class Initialized
INFO - 2020-03-09 09:42:35 --> Hooks Class Initialized
DEBUG - 2020-03-09 09:42:35 --> UTF-8 Support Enabled
INFO - 2020-03-09 09:42:35 --> Utf8 Class Initialized
INFO - 2020-03-09 09:42:35 --> URI Class Initialized
INFO - 2020-03-09 09:42:35 --> Router Class Initialized
INFO - 2020-03-09 09:42:35 --> Output Class Initialized
INFO - 2020-03-09 09:42:35 --> Security Class Initialized
DEBUG - 2020-03-09 09:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 09:42:35 --> Input Class Initialized
INFO - 2020-03-09 09:42:35 --> Language Class Initialized
INFO - 2020-03-09 09:42:35 --> Loader Class Initialized
INFO - 2020-03-09 09:42:35 --> Helper loaded: url_helper
INFO - 2020-03-09 09:42:35 --> Helper loaded: string_helper
INFO - 2020-03-09 09:42:35 --> Database Driver Class Initialized
DEBUG - 2020-03-09 09:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 09:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 09:42:35 --> Controller Class Initialized
INFO - 2020-03-09 09:42:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 09:42:35 --> Pagination Class Initialized
INFO - 2020-03-09 09:42:35 --> Model "M_show" initialized
INFO - 2020-03-09 09:42:35 --> Helper loaded: form_helper
INFO - 2020-03-09 09:42:35 --> Form Validation Class Initialized
INFO - 2020-03-09 09:42:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 09:42:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 09:42:35 --> Final output sent to browser
DEBUG - 2020-03-09 09:42:35 --> Total execution time: 0.0088
INFO - 2020-03-09 09:42:36 --> Config Class Initialized
INFO - 2020-03-09 09:42:36 --> Hooks Class Initialized
DEBUG - 2020-03-09 09:42:36 --> UTF-8 Support Enabled
INFO - 2020-03-09 09:42:36 --> Utf8 Class Initialized
INFO - 2020-03-09 09:42:36 --> URI Class Initialized
INFO - 2020-03-09 09:42:36 --> Router Class Initialized
INFO - 2020-03-09 09:42:36 --> Output Class Initialized
INFO - 2020-03-09 09:42:36 --> Security Class Initialized
DEBUG - 2020-03-09 09:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 09:42:36 --> Input Class Initialized
INFO - 2020-03-09 09:42:36 --> Language Class Initialized
INFO - 2020-03-09 09:42:36 --> Loader Class Initialized
INFO - 2020-03-09 09:42:36 --> Helper loaded: url_helper
INFO - 2020-03-09 09:42:36 --> Helper loaded: string_helper
INFO - 2020-03-09 09:42:36 --> Database Driver Class Initialized
DEBUG - 2020-03-09 09:42:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 09:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 09:42:36 --> Controller Class Initialized
INFO - 2020-03-09 09:42:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 09:42:36 --> Pagination Class Initialized
INFO - 2020-03-09 09:42:36 --> Model "M_show" initialized
INFO - 2020-03-09 09:42:36 --> Helper loaded: form_helper
INFO - 2020-03-09 09:42:36 --> Form Validation Class Initialized
INFO - 2020-03-09 09:42:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 09:42:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-09 09:42:36 --> Final output sent to browser
DEBUG - 2020-03-09 09:42:36 --> Total execution time: 0.0056
INFO - 2020-03-09 09:42:37 --> Config Class Initialized
INFO - 2020-03-09 09:42:37 --> Hooks Class Initialized
DEBUG - 2020-03-09 09:42:37 --> UTF-8 Support Enabled
INFO - 2020-03-09 09:42:37 --> Utf8 Class Initialized
INFO - 2020-03-09 09:42:37 --> URI Class Initialized
DEBUG - 2020-03-09 09:42:37 --> No URI present. Default controller set.
INFO - 2020-03-09 09:42:37 --> Router Class Initialized
INFO - 2020-03-09 09:42:37 --> Output Class Initialized
INFO - 2020-03-09 09:42:37 --> Security Class Initialized
DEBUG - 2020-03-09 09:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 09:42:37 --> Input Class Initialized
INFO - 2020-03-09 09:42:37 --> Language Class Initialized
INFO - 2020-03-09 09:42:37 --> Loader Class Initialized
INFO - 2020-03-09 09:42:37 --> Helper loaded: url_helper
INFO - 2020-03-09 09:42:37 --> Helper loaded: string_helper
INFO - 2020-03-09 09:42:37 --> Database Driver Class Initialized
DEBUG - 2020-03-09 09:42:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 09:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 09:42:37 --> Controller Class Initialized
INFO - 2020-03-09 09:42:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 09:42:37 --> Pagination Class Initialized
INFO - 2020-03-09 09:42:37 --> Model "M_show" initialized
INFO - 2020-03-09 09:42:37 --> Helper loaded: form_helper
INFO - 2020-03-09 09:42:37 --> Form Validation Class Initialized
INFO - 2020-03-09 09:42:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 09:42:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 09:42:37 --> Final output sent to browser
DEBUG - 2020-03-09 09:42:37 --> Total execution time: 0.0054
INFO - 2020-03-09 09:54:16 --> Config Class Initialized
INFO - 2020-03-09 09:54:16 --> Hooks Class Initialized
DEBUG - 2020-03-09 09:54:16 --> UTF-8 Support Enabled
INFO - 2020-03-09 09:54:16 --> Utf8 Class Initialized
INFO - 2020-03-09 09:54:16 --> URI Class Initialized
DEBUG - 2020-03-09 09:54:16 --> No URI present. Default controller set.
INFO - 2020-03-09 09:54:16 --> Router Class Initialized
INFO - 2020-03-09 09:54:16 --> Output Class Initialized
INFO - 2020-03-09 09:54:16 --> Security Class Initialized
DEBUG - 2020-03-09 09:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 09:54:16 --> Input Class Initialized
INFO - 2020-03-09 09:54:16 --> Language Class Initialized
INFO - 2020-03-09 09:54:16 --> Loader Class Initialized
INFO - 2020-03-09 09:54:16 --> Helper loaded: url_helper
INFO - 2020-03-09 09:54:16 --> Helper loaded: string_helper
INFO - 2020-03-09 09:54:16 --> Database Driver Class Initialized
DEBUG - 2020-03-09 09:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 09:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 09:54:16 --> Controller Class Initialized
INFO - 2020-03-09 09:54:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 09:54:16 --> Pagination Class Initialized
INFO - 2020-03-09 09:54:16 --> Model "M_show" initialized
INFO - 2020-03-09 09:54:16 --> Helper loaded: form_helper
INFO - 2020-03-09 09:54:16 --> Form Validation Class Initialized
INFO - 2020-03-09 09:54:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 09:54:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 09:54:16 --> Final output sent to browser
DEBUG - 2020-03-09 09:54:16 --> Total execution time: 0.2491
INFO - 2020-03-09 09:54:36 --> Config Class Initialized
INFO - 2020-03-09 09:54:36 --> Hooks Class Initialized
DEBUG - 2020-03-09 09:54:36 --> UTF-8 Support Enabled
INFO - 2020-03-09 09:54:36 --> Utf8 Class Initialized
INFO - 2020-03-09 09:54:36 --> URI Class Initialized
INFO - 2020-03-09 09:54:36 --> Router Class Initialized
INFO - 2020-03-09 09:54:36 --> Output Class Initialized
INFO - 2020-03-09 09:54:36 --> Security Class Initialized
DEBUG - 2020-03-09 09:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 09:54:36 --> Input Class Initialized
INFO - 2020-03-09 09:54:36 --> Language Class Initialized
INFO - 2020-03-09 09:54:36 --> Loader Class Initialized
INFO - 2020-03-09 09:54:36 --> Helper loaded: url_helper
INFO - 2020-03-09 09:54:36 --> Helper loaded: string_helper
INFO - 2020-03-09 09:54:36 --> Database Driver Class Initialized
DEBUG - 2020-03-09 09:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 09:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 09:54:36 --> Controller Class Initialized
INFO - 2020-03-09 09:54:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 09:54:36 --> Pagination Class Initialized
INFO - 2020-03-09 09:54:36 --> Model "M_show" initialized
INFO - 2020-03-09 09:54:36 --> Helper loaded: form_helper
INFO - 2020-03-09 09:54:36 --> Form Validation Class Initialized
INFO - 2020-03-09 09:54:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 09:54:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 09:54:36 --> Final output sent to browser
DEBUG - 2020-03-09 09:54:36 --> Total execution time: 0.1937
INFO - 2020-03-09 09:54:40 --> Config Class Initialized
INFO - 2020-03-09 09:54:40 --> Hooks Class Initialized
DEBUG - 2020-03-09 09:54:40 --> UTF-8 Support Enabled
INFO - 2020-03-09 09:54:40 --> Utf8 Class Initialized
INFO - 2020-03-09 09:54:40 --> URI Class Initialized
INFO - 2020-03-09 09:54:40 --> Router Class Initialized
INFO - 2020-03-09 09:54:40 --> Output Class Initialized
INFO - 2020-03-09 09:54:40 --> Security Class Initialized
DEBUG - 2020-03-09 09:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 09:54:40 --> Input Class Initialized
INFO - 2020-03-09 09:54:40 --> Language Class Initialized
INFO - 2020-03-09 09:54:40 --> Loader Class Initialized
INFO - 2020-03-09 09:54:40 --> Helper loaded: url_helper
INFO - 2020-03-09 09:54:40 --> Helper loaded: string_helper
INFO - 2020-03-09 09:54:40 --> Database Driver Class Initialized
DEBUG - 2020-03-09 09:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 09:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 09:54:40 --> Controller Class Initialized
INFO - 2020-03-09 09:54:40 --> Model "M_tiket" initialized
INFO - 2020-03-09 09:54:40 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 09:54:40 --> Model "M_pesan" initialized
INFO - 2020-03-09 09:54:40 --> Helper loaded: form_helper
INFO - 2020-03-09 09:54:40 --> Form Validation Class Initialized
INFO - 2020-03-09 09:54:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-09 09:54:40 --> Final output sent to browser
DEBUG - 2020-03-09 09:54:40 --> Total execution time: 0.0260
INFO - 2020-03-09 09:54:41 --> Config Class Initialized
INFO - 2020-03-09 09:54:41 --> Hooks Class Initialized
DEBUG - 2020-03-09 09:54:41 --> UTF-8 Support Enabled
INFO - 2020-03-09 09:54:41 --> Utf8 Class Initialized
INFO - 2020-03-09 09:54:41 --> URI Class Initialized
DEBUG - 2020-03-09 09:54:41 --> No URI present. Default controller set.
INFO - 2020-03-09 09:54:41 --> Router Class Initialized
INFO - 2020-03-09 09:54:41 --> Output Class Initialized
INFO - 2020-03-09 09:54:41 --> Security Class Initialized
DEBUG - 2020-03-09 09:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 09:54:41 --> Input Class Initialized
INFO - 2020-03-09 09:54:41 --> Language Class Initialized
INFO - 2020-03-09 09:54:41 --> Loader Class Initialized
INFO - 2020-03-09 09:54:41 --> Helper loaded: url_helper
INFO - 2020-03-09 09:54:41 --> Helper loaded: string_helper
INFO - 2020-03-09 09:54:41 --> Database Driver Class Initialized
DEBUG - 2020-03-09 09:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 09:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 09:54:41 --> Controller Class Initialized
INFO - 2020-03-09 09:54:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 09:54:41 --> Pagination Class Initialized
INFO - 2020-03-09 09:54:41 --> Model "M_show" initialized
INFO - 2020-03-09 09:54:41 --> Helper loaded: form_helper
INFO - 2020-03-09 09:54:41 --> Form Validation Class Initialized
INFO - 2020-03-09 09:54:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 09:54:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 09:54:41 --> Final output sent to browser
DEBUG - 2020-03-09 09:54:41 --> Total execution time: 0.0924
INFO - 2020-03-09 09:54:55 --> Config Class Initialized
INFO - 2020-03-09 09:54:55 --> Hooks Class Initialized
DEBUG - 2020-03-09 09:54:55 --> UTF-8 Support Enabled
INFO - 2020-03-09 09:54:55 --> Utf8 Class Initialized
INFO - 2020-03-09 09:54:55 --> URI Class Initialized
INFO - 2020-03-09 09:54:55 --> Router Class Initialized
INFO - 2020-03-09 09:54:55 --> Output Class Initialized
INFO - 2020-03-09 09:54:55 --> Security Class Initialized
DEBUG - 2020-03-09 09:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 09:54:55 --> Input Class Initialized
INFO - 2020-03-09 09:54:55 --> Language Class Initialized
INFO - 2020-03-09 09:54:55 --> Loader Class Initialized
INFO - 2020-03-09 09:54:55 --> Helper loaded: url_helper
INFO - 2020-03-09 09:54:55 --> Helper loaded: string_helper
INFO - 2020-03-09 09:54:55 --> Database Driver Class Initialized
DEBUG - 2020-03-09 09:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 09:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 09:54:55 --> Controller Class Initialized
INFO - 2020-03-09 09:54:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 09:54:55 --> Pagination Class Initialized
INFO - 2020-03-09 09:54:55 --> Model "M_show" initialized
INFO - 2020-03-09 09:54:55 --> Helper loaded: form_helper
INFO - 2020-03-09 09:54:55 --> Form Validation Class Initialized
INFO - 2020-03-09 09:54:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 09:54:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 09:54:55 --> Final output sent to browser
DEBUG - 2020-03-09 09:54:55 --> Total execution time: 0.0069
INFO - 2020-03-09 09:55:00 --> Config Class Initialized
INFO - 2020-03-09 09:55:00 --> Hooks Class Initialized
DEBUG - 2020-03-09 09:55:00 --> UTF-8 Support Enabled
INFO - 2020-03-09 09:55:00 --> Utf8 Class Initialized
INFO - 2020-03-09 09:55:00 --> URI Class Initialized
INFO - 2020-03-09 09:55:00 --> Router Class Initialized
INFO - 2020-03-09 09:55:00 --> Output Class Initialized
INFO - 2020-03-09 09:55:00 --> Security Class Initialized
DEBUG - 2020-03-09 09:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 09:55:00 --> Input Class Initialized
INFO - 2020-03-09 09:55:00 --> Language Class Initialized
INFO - 2020-03-09 09:55:00 --> Loader Class Initialized
INFO - 2020-03-09 09:55:00 --> Helper loaded: url_helper
INFO - 2020-03-09 09:55:00 --> Helper loaded: string_helper
INFO - 2020-03-09 09:55:00 --> Database Driver Class Initialized
DEBUG - 2020-03-09 09:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 09:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 09:55:00 --> Controller Class Initialized
INFO - 2020-03-09 09:55:00 --> Model "M_tiket" initialized
INFO - 2020-03-09 09:55:00 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 09:55:00 --> Model "M_pesan" initialized
INFO - 2020-03-09 09:55:00 --> Helper loaded: form_helper
INFO - 2020-03-09 09:55:00 --> Form Validation Class Initialized
INFO - 2020-03-09 09:55:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-09 09:55:00 --> Final output sent to browser
DEBUG - 2020-03-09 09:55:00 --> Total execution time: 0.0128
INFO - 2020-03-09 09:55:08 --> Config Class Initialized
INFO - 2020-03-09 09:55:08 --> Hooks Class Initialized
DEBUG - 2020-03-09 09:55:08 --> UTF-8 Support Enabled
INFO - 2020-03-09 09:55:08 --> Utf8 Class Initialized
INFO - 2020-03-09 09:55:08 --> URI Class Initialized
INFO - 2020-03-09 09:55:08 --> Router Class Initialized
INFO - 2020-03-09 09:55:08 --> Output Class Initialized
INFO - 2020-03-09 09:55:08 --> Security Class Initialized
DEBUG - 2020-03-09 09:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 09:55:08 --> Input Class Initialized
INFO - 2020-03-09 09:55:08 --> Language Class Initialized
INFO - 2020-03-09 09:55:08 --> Loader Class Initialized
INFO - 2020-03-09 09:55:08 --> Helper loaded: url_helper
INFO - 2020-03-09 09:55:08 --> Helper loaded: string_helper
INFO - 2020-03-09 09:55:08 --> Database Driver Class Initialized
DEBUG - 2020-03-09 09:55:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 09:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 09:55:08 --> Controller Class Initialized
INFO - 2020-03-09 09:55:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 09:55:08 --> Pagination Class Initialized
INFO - 2020-03-09 09:55:08 --> Model "M_show" initialized
INFO - 2020-03-09 09:55:08 --> Helper loaded: form_helper
INFO - 2020-03-09 09:55:08 --> Form Validation Class Initialized
INFO - 2020-03-09 09:55:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 09:55:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 09:55:08 --> Final output sent to browser
DEBUG - 2020-03-09 09:55:08 --> Total execution time: 0.0160
INFO - 2020-03-09 09:55:11 --> Config Class Initialized
INFO - 2020-03-09 09:55:11 --> Hooks Class Initialized
DEBUG - 2020-03-09 09:55:11 --> UTF-8 Support Enabled
INFO - 2020-03-09 09:55:11 --> Utf8 Class Initialized
INFO - 2020-03-09 09:55:11 --> URI Class Initialized
DEBUG - 2020-03-09 09:55:11 --> No URI present. Default controller set.
INFO - 2020-03-09 09:55:11 --> Router Class Initialized
INFO - 2020-03-09 09:55:11 --> Output Class Initialized
INFO - 2020-03-09 09:55:11 --> Security Class Initialized
DEBUG - 2020-03-09 09:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 09:55:11 --> Input Class Initialized
INFO - 2020-03-09 09:55:11 --> Language Class Initialized
INFO - 2020-03-09 09:55:11 --> Loader Class Initialized
INFO - 2020-03-09 09:55:11 --> Helper loaded: url_helper
INFO - 2020-03-09 09:55:11 --> Helper loaded: string_helper
INFO - 2020-03-09 09:55:11 --> Database Driver Class Initialized
DEBUG - 2020-03-09 09:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 09:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 09:55:11 --> Controller Class Initialized
INFO - 2020-03-09 09:55:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 09:55:11 --> Pagination Class Initialized
INFO - 2020-03-09 09:55:11 --> Model "M_show" initialized
INFO - 2020-03-09 09:55:11 --> Helper loaded: form_helper
INFO - 2020-03-09 09:55:11 --> Form Validation Class Initialized
INFO - 2020-03-09 09:55:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 09:55:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 09:55:11 --> Final output sent to browser
DEBUG - 2020-03-09 09:55:11 --> Total execution time: 0.0115
INFO - 2020-03-09 10:06:41 --> Config Class Initialized
INFO - 2020-03-09 10:06:41 --> Hooks Class Initialized
DEBUG - 2020-03-09 10:06:41 --> UTF-8 Support Enabled
INFO - 2020-03-09 10:06:41 --> Utf8 Class Initialized
INFO - 2020-03-09 10:06:41 --> URI Class Initialized
INFO - 2020-03-09 10:06:41 --> Router Class Initialized
INFO - 2020-03-09 10:06:41 --> Output Class Initialized
INFO - 2020-03-09 10:06:41 --> Security Class Initialized
DEBUG - 2020-03-09 10:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 10:06:41 --> Input Class Initialized
INFO - 2020-03-09 10:06:41 --> Language Class Initialized
INFO - 2020-03-09 10:06:41 --> Loader Class Initialized
INFO - 2020-03-09 10:06:41 --> Helper loaded: url_helper
INFO - 2020-03-09 10:06:41 --> Helper loaded: string_helper
INFO - 2020-03-09 10:06:41 --> Database Driver Class Initialized
DEBUG - 2020-03-09 10:06:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 10:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 10:06:41 --> Controller Class Initialized
INFO - 2020-03-09 10:06:41 --> Model "M_tiket" initialized
INFO - 2020-03-09 10:06:41 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 10:06:41 --> Model "M_pesan" initialized
INFO - 2020-03-09 10:06:41 --> Helper loaded: form_helper
INFO - 2020-03-09 10:06:41 --> Form Validation Class Initialized
INFO - 2020-03-09 10:06:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-09 10:06:41 --> Final output sent to browser
DEBUG - 2020-03-09 10:06:41 --> Total execution time: 0.0611
INFO - 2020-03-09 10:06:43 --> Config Class Initialized
INFO - 2020-03-09 10:06:43 --> Hooks Class Initialized
DEBUG - 2020-03-09 10:06:43 --> UTF-8 Support Enabled
INFO - 2020-03-09 10:06:43 --> Utf8 Class Initialized
INFO - 2020-03-09 10:06:43 --> URI Class Initialized
INFO - 2020-03-09 10:06:43 --> Router Class Initialized
INFO - 2020-03-09 10:06:43 --> Output Class Initialized
INFO - 2020-03-09 10:06:43 --> Security Class Initialized
DEBUG - 2020-03-09 10:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 10:06:43 --> Input Class Initialized
INFO - 2020-03-09 10:06:43 --> Language Class Initialized
INFO - 2020-03-09 10:06:43 --> Loader Class Initialized
INFO - 2020-03-09 10:06:43 --> Helper loaded: url_helper
INFO - 2020-03-09 10:06:43 --> Helper loaded: string_helper
INFO - 2020-03-09 10:06:43 --> Database Driver Class Initialized
DEBUG - 2020-03-09 10:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 10:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 10:06:43 --> Controller Class Initialized
INFO - 2020-03-09 10:06:43 --> Model "M_tiket" initialized
INFO - 2020-03-09 10:06:43 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 10:06:43 --> Model "M_pesan" initialized
INFO - 2020-03-09 10:06:43 --> Helper loaded: form_helper
INFO - 2020-03-09 10:06:43 --> Form Validation Class Initialized
INFO - 2020-03-09 10:06:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-09 10:06:43 --> Final output sent to browser
DEBUG - 2020-03-09 10:06:43 --> Total execution time: 0.0082
INFO - 2020-03-09 10:07:56 --> Config Class Initialized
INFO - 2020-03-09 10:07:56 --> Hooks Class Initialized
DEBUG - 2020-03-09 10:07:56 --> UTF-8 Support Enabled
INFO - 2020-03-09 10:07:56 --> Utf8 Class Initialized
INFO - 2020-03-09 10:07:56 --> URI Class Initialized
INFO - 2020-03-09 10:07:56 --> Router Class Initialized
INFO - 2020-03-09 10:07:56 --> Output Class Initialized
INFO - 2020-03-09 10:07:56 --> Security Class Initialized
DEBUG - 2020-03-09 10:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 10:07:56 --> Input Class Initialized
INFO - 2020-03-09 10:07:56 --> Language Class Initialized
INFO - 2020-03-09 10:07:56 --> Loader Class Initialized
INFO - 2020-03-09 10:07:56 --> Helper loaded: url_helper
INFO - 2020-03-09 10:07:56 --> Helper loaded: string_helper
INFO - 2020-03-09 10:07:56 --> Database Driver Class Initialized
DEBUG - 2020-03-09 10:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 10:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 10:07:56 --> Controller Class Initialized
INFO - 2020-03-09 10:07:56 --> Model "M_tiket" initialized
INFO - 2020-03-09 10:07:56 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 10:07:56 --> Model "M_pesan" initialized
INFO - 2020-03-09 10:07:56 --> Helper loaded: form_helper
INFO - 2020-03-09 10:07:56 --> Form Validation Class Initialized
INFO - 2020-03-09 17:07:56 --> Upload Class Initialized
INFO - 2020-03-09 17:07:56 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2020-03-09 17:07:56 --> The filetype you are attempting to upload is not allowed.
INFO - 2020-03-09 10:07:59 --> Config Class Initialized
INFO - 2020-03-09 10:07:59 --> Hooks Class Initialized
DEBUG - 2020-03-09 10:07:59 --> UTF-8 Support Enabled
INFO - 2020-03-09 10:07:59 --> Utf8 Class Initialized
INFO - 2020-03-09 10:07:59 --> URI Class Initialized
INFO - 2020-03-09 10:07:59 --> Router Class Initialized
INFO - 2020-03-09 10:07:59 --> Output Class Initialized
INFO - 2020-03-09 10:07:59 --> Security Class Initialized
DEBUG - 2020-03-09 10:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 10:07:59 --> Input Class Initialized
INFO - 2020-03-09 10:07:59 --> Language Class Initialized
INFO - 2020-03-09 10:07:59 --> Loader Class Initialized
INFO - 2020-03-09 10:07:59 --> Helper loaded: url_helper
INFO - 2020-03-09 10:07:59 --> Helper loaded: string_helper
INFO - 2020-03-09 10:07:59 --> Database Driver Class Initialized
DEBUG - 2020-03-09 10:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 10:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 10:07:59 --> Controller Class Initialized
INFO - 2020-03-09 10:07:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 10:07:59 --> Pagination Class Initialized
INFO - 2020-03-09 10:07:59 --> Model "M_show" initialized
INFO - 2020-03-09 10:07:59 --> Helper loaded: form_helper
INFO - 2020-03-09 10:07:59 --> Form Validation Class Initialized
INFO - 2020-03-09 10:07:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 10:07:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 10:07:59 --> Final output sent to browser
DEBUG - 2020-03-09 10:07:59 --> Total execution time: 0.0097
INFO - 2020-03-09 10:08:00 --> Config Class Initialized
INFO - 2020-03-09 10:08:00 --> Hooks Class Initialized
DEBUG - 2020-03-09 10:08:00 --> UTF-8 Support Enabled
INFO - 2020-03-09 10:08:00 --> Utf8 Class Initialized
INFO - 2020-03-09 10:08:00 --> URI Class Initialized
INFO - 2020-03-09 10:08:00 --> Router Class Initialized
INFO - 2020-03-09 10:08:00 --> Output Class Initialized
INFO - 2020-03-09 10:08:00 --> Security Class Initialized
DEBUG - 2020-03-09 10:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 10:08:00 --> Input Class Initialized
INFO - 2020-03-09 10:08:00 --> Language Class Initialized
ERROR - 2020-03-09 10:08:00 --> 404 Page Not Found: Engine0/jquery.js
INFO - 2020-03-09 10:55:09 --> Config Class Initialized
INFO - 2020-03-09 10:55:09 --> Hooks Class Initialized
DEBUG - 2020-03-09 10:55:09 --> UTF-8 Support Enabled
INFO - 2020-03-09 10:55:09 --> Utf8 Class Initialized
INFO - 2020-03-09 10:55:09 --> URI Class Initialized
DEBUG - 2020-03-09 10:55:09 --> No URI present. Default controller set.
INFO - 2020-03-09 10:55:09 --> Router Class Initialized
INFO - 2020-03-09 10:55:09 --> Output Class Initialized
INFO - 2020-03-09 10:55:09 --> Security Class Initialized
DEBUG - 2020-03-09 10:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 10:55:09 --> Input Class Initialized
INFO - 2020-03-09 10:55:09 --> Language Class Initialized
INFO - 2020-03-09 10:55:09 --> Loader Class Initialized
INFO - 2020-03-09 10:55:09 --> Helper loaded: url_helper
INFO - 2020-03-09 10:55:09 --> Helper loaded: string_helper
INFO - 2020-03-09 10:55:09 --> Database Driver Class Initialized
DEBUG - 2020-03-09 10:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 10:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 10:55:09 --> Controller Class Initialized
INFO - 2020-03-09 10:55:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 10:55:09 --> Pagination Class Initialized
INFO - 2020-03-09 10:55:09 --> Model "M_show" initialized
INFO - 2020-03-09 10:55:09 --> Helper loaded: form_helper
INFO - 2020-03-09 10:55:09 --> Form Validation Class Initialized
INFO - 2020-03-09 10:55:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 10:55:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 10:55:09 --> Final output sent to browser
DEBUG - 2020-03-09 10:55:09 --> Total execution time: 0.1029
INFO - 2020-03-09 10:55:11 --> Config Class Initialized
INFO - 2020-03-09 10:55:11 --> Hooks Class Initialized
DEBUG - 2020-03-09 10:55:11 --> UTF-8 Support Enabled
INFO - 2020-03-09 10:55:11 --> Utf8 Class Initialized
INFO - 2020-03-09 10:55:11 --> URI Class Initialized
DEBUG - 2020-03-09 10:55:11 --> No URI present. Default controller set.
INFO - 2020-03-09 10:55:11 --> Router Class Initialized
INFO - 2020-03-09 10:55:11 --> Output Class Initialized
INFO - 2020-03-09 10:55:11 --> Security Class Initialized
DEBUG - 2020-03-09 10:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 10:55:11 --> Input Class Initialized
INFO - 2020-03-09 10:55:11 --> Language Class Initialized
INFO - 2020-03-09 10:55:11 --> Loader Class Initialized
INFO - 2020-03-09 10:55:11 --> Helper loaded: url_helper
INFO - 2020-03-09 10:55:11 --> Helper loaded: string_helper
INFO - 2020-03-09 10:55:11 --> Database Driver Class Initialized
DEBUG - 2020-03-09 10:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 10:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 10:55:11 --> Controller Class Initialized
INFO - 2020-03-09 10:55:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 10:55:11 --> Pagination Class Initialized
INFO - 2020-03-09 10:55:11 --> Model "M_show" initialized
INFO - 2020-03-09 10:55:11 --> Helper loaded: form_helper
INFO - 2020-03-09 10:55:11 --> Form Validation Class Initialized
INFO - 2020-03-09 10:55:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 10:55:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 10:55:11 --> Final output sent to browser
DEBUG - 2020-03-09 10:55:11 --> Total execution time: 0.0058
INFO - 2020-03-09 11:04:47 --> Config Class Initialized
INFO - 2020-03-09 11:04:47 --> Hooks Class Initialized
DEBUG - 2020-03-09 11:04:47 --> UTF-8 Support Enabled
INFO - 2020-03-09 11:04:47 --> Utf8 Class Initialized
INFO - 2020-03-09 11:04:47 --> URI Class Initialized
DEBUG - 2020-03-09 11:04:47 --> No URI present. Default controller set.
INFO - 2020-03-09 11:04:47 --> Router Class Initialized
INFO - 2020-03-09 11:04:47 --> Output Class Initialized
INFO - 2020-03-09 11:04:47 --> Security Class Initialized
DEBUG - 2020-03-09 11:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 11:04:47 --> Input Class Initialized
INFO - 2020-03-09 11:04:47 --> Language Class Initialized
INFO - 2020-03-09 11:04:47 --> Loader Class Initialized
INFO - 2020-03-09 11:04:47 --> Helper loaded: url_helper
INFO - 2020-03-09 11:04:47 --> Helper loaded: string_helper
INFO - 2020-03-09 11:04:47 --> Database Driver Class Initialized
DEBUG - 2020-03-09 11:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 11:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 11:04:47 --> Controller Class Initialized
INFO - 2020-03-09 11:04:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 11:04:47 --> Pagination Class Initialized
INFO - 2020-03-09 11:04:47 --> Model "M_show" initialized
INFO - 2020-03-09 11:04:47 --> Helper loaded: form_helper
INFO - 2020-03-09 11:04:47 --> Form Validation Class Initialized
INFO - 2020-03-09 11:04:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 11:04:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 11:04:47 --> Final output sent to browser
DEBUG - 2020-03-09 11:04:47 --> Total execution time: 0.1236
INFO - 2020-03-09 11:43:02 --> Config Class Initialized
INFO - 2020-03-09 11:43:02 --> Hooks Class Initialized
DEBUG - 2020-03-09 11:43:02 --> UTF-8 Support Enabled
INFO - 2020-03-09 11:43:02 --> Utf8 Class Initialized
INFO - 2020-03-09 11:43:02 --> URI Class Initialized
INFO - 2020-03-09 11:43:02 --> Router Class Initialized
INFO - 2020-03-09 11:43:02 --> Output Class Initialized
INFO - 2020-03-09 11:43:02 --> Security Class Initialized
DEBUG - 2020-03-09 11:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 11:43:02 --> Input Class Initialized
INFO - 2020-03-09 11:43:02 --> Language Class Initialized
INFO - 2020-03-09 11:43:02 --> Loader Class Initialized
INFO - 2020-03-09 11:43:02 --> Helper loaded: url_helper
INFO - 2020-03-09 11:43:02 --> Helper loaded: string_helper
INFO - 2020-03-09 11:43:02 --> Database Driver Class Initialized
DEBUG - 2020-03-09 11:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 11:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 11:43:02 --> Controller Class Initialized
INFO - 2020-03-09 11:43:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 11:43:02 --> Pagination Class Initialized
INFO - 2020-03-09 11:43:02 --> Model "M_show" initialized
INFO - 2020-03-09 11:43:02 --> Helper loaded: form_helper
INFO - 2020-03-09 11:43:02 --> Form Validation Class Initialized
INFO - 2020-03-09 11:43:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 11:43:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 11:43:02 --> Final output sent to browser
DEBUG - 2020-03-09 11:43:02 --> Total execution time: 0.1836
INFO - 2020-03-09 12:22:04 --> Config Class Initialized
INFO - 2020-03-09 12:22:04 --> Hooks Class Initialized
DEBUG - 2020-03-09 12:22:04 --> UTF-8 Support Enabled
INFO - 2020-03-09 12:22:04 --> Utf8 Class Initialized
INFO - 2020-03-09 12:22:04 --> URI Class Initialized
DEBUG - 2020-03-09 12:22:04 --> No URI present. Default controller set.
INFO - 2020-03-09 12:22:04 --> Router Class Initialized
INFO - 2020-03-09 12:22:04 --> Output Class Initialized
INFO - 2020-03-09 12:22:04 --> Security Class Initialized
DEBUG - 2020-03-09 12:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 12:22:04 --> Input Class Initialized
INFO - 2020-03-09 12:22:04 --> Language Class Initialized
INFO - 2020-03-09 12:22:04 --> Loader Class Initialized
INFO - 2020-03-09 12:22:04 --> Helper loaded: url_helper
INFO - 2020-03-09 12:22:04 --> Helper loaded: string_helper
INFO - 2020-03-09 12:22:04 --> Database Driver Class Initialized
DEBUG - 2020-03-09 12:22:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 12:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 12:22:04 --> Controller Class Initialized
INFO - 2020-03-09 12:22:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 12:22:04 --> Pagination Class Initialized
INFO - 2020-03-09 12:22:04 --> Model "M_show" initialized
INFO - 2020-03-09 12:22:04 --> Helper loaded: form_helper
INFO - 2020-03-09 12:22:04 --> Form Validation Class Initialized
INFO - 2020-03-09 12:22:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 12:22:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 12:22:04 --> Final output sent to browser
DEBUG - 2020-03-09 12:22:04 --> Total execution time: 0.0659
INFO - 2020-03-09 12:24:15 --> Config Class Initialized
INFO - 2020-03-09 12:24:15 --> Hooks Class Initialized
DEBUG - 2020-03-09 12:24:15 --> UTF-8 Support Enabled
INFO - 2020-03-09 12:24:15 --> Utf8 Class Initialized
INFO - 2020-03-09 12:24:15 --> URI Class Initialized
DEBUG - 2020-03-09 12:24:15 --> No URI present. Default controller set.
INFO - 2020-03-09 12:24:15 --> Router Class Initialized
INFO - 2020-03-09 12:24:15 --> Output Class Initialized
INFO - 2020-03-09 12:24:15 --> Security Class Initialized
DEBUG - 2020-03-09 12:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 12:24:15 --> Input Class Initialized
INFO - 2020-03-09 12:24:15 --> Language Class Initialized
INFO - 2020-03-09 12:24:15 --> Loader Class Initialized
INFO - 2020-03-09 12:24:15 --> Helper loaded: url_helper
INFO - 2020-03-09 12:24:15 --> Helper loaded: string_helper
INFO - 2020-03-09 12:24:15 --> Database Driver Class Initialized
DEBUG - 2020-03-09 12:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 12:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 12:24:15 --> Controller Class Initialized
INFO - 2020-03-09 12:24:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 12:24:15 --> Pagination Class Initialized
INFO - 2020-03-09 12:24:15 --> Model "M_show" initialized
INFO - 2020-03-09 12:24:15 --> Helper loaded: form_helper
INFO - 2020-03-09 12:24:15 --> Form Validation Class Initialized
INFO - 2020-03-09 12:24:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 12:24:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 12:24:15 --> Final output sent to browser
DEBUG - 2020-03-09 12:24:15 --> Total execution time: 0.0495
INFO - 2020-03-09 12:28:24 --> Config Class Initialized
INFO - 2020-03-09 12:28:24 --> Hooks Class Initialized
DEBUG - 2020-03-09 12:28:24 --> UTF-8 Support Enabled
INFO - 2020-03-09 12:28:24 --> Utf8 Class Initialized
INFO - 2020-03-09 12:28:24 --> URI Class Initialized
DEBUG - 2020-03-09 12:28:24 --> No URI present. Default controller set.
INFO - 2020-03-09 12:28:24 --> Router Class Initialized
INFO - 2020-03-09 12:28:24 --> Output Class Initialized
INFO - 2020-03-09 12:28:24 --> Security Class Initialized
DEBUG - 2020-03-09 12:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 12:28:24 --> Input Class Initialized
INFO - 2020-03-09 12:28:24 --> Language Class Initialized
INFO - 2020-03-09 12:28:24 --> Loader Class Initialized
INFO - 2020-03-09 12:28:24 --> Helper loaded: url_helper
INFO - 2020-03-09 12:28:24 --> Helper loaded: string_helper
INFO - 2020-03-09 12:28:24 --> Database Driver Class Initialized
DEBUG - 2020-03-09 12:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 12:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 12:28:24 --> Controller Class Initialized
INFO - 2020-03-09 12:28:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 12:28:24 --> Pagination Class Initialized
INFO - 2020-03-09 12:28:24 --> Model "M_show" initialized
INFO - 2020-03-09 12:28:24 --> Helper loaded: form_helper
INFO - 2020-03-09 12:28:24 --> Form Validation Class Initialized
INFO - 2020-03-09 12:28:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 12:28:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 12:28:24 --> Final output sent to browser
DEBUG - 2020-03-09 12:28:24 --> Total execution time: 0.0508
INFO - 2020-03-09 13:10:24 --> Config Class Initialized
INFO - 2020-03-09 13:10:24 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:10:24 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:10:24 --> Utf8 Class Initialized
INFO - 2020-03-09 13:10:24 --> URI Class Initialized
INFO - 2020-03-09 13:10:24 --> Router Class Initialized
INFO - 2020-03-09 13:10:24 --> Output Class Initialized
INFO - 2020-03-09 13:10:24 --> Security Class Initialized
DEBUG - 2020-03-09 13:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:10:24 --> Input Class Initialized
INFO - 2020-03-09 13:10:24 --> Language Class Initialized
INFO - 2020-03-09 13:10:24 --> Loader Class Initialized
INFO - 2020-03-09 13:10:24 --> Helper loaded: url_helper
INFO - 2020-03-09 13:10:24 --> Helper loaded: string_helper
INFO - 2020-03-09 13:10:24 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:10:25 --> Controller Class Initialized
INFO - 2020-03-09 13:10:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 13:10:25 --> Pagination Class Initialized
INFO - 2020-03-09 13:10:25 --> Model "M_show" initialized
INFO - 2020-03-09 13:10:25 --> Helper loaded: form_helper
INFO - 2020-03-09 13:10:25 --> Form Validation Class Initialized
INFO - 2020-03-09 13:10:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 13:10:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 13:10:25 --> Final output sent to browser
DEBUG - 2020-03-09 13:10:25 --> Total execution time: 0.2240
INFO - 2020-03-09 13:10:47 --> Config Class Initialized
INFO - 2020-03-09 13:10:47 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:10:47 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:10:47 --> Utf8 Class Initialized
INFO - 2020-03-09 13:10:47 --> URI Class Initialized
INFO - 2020-03-09 13:10:47 --> Router Class Initialized
INFO - 2020-03-09 13:10:47 --> Output Class Initialized
INFO - 2020-03-09 13:10:47 --> Security Class Initialized
DEBUG - 2020-03-09 13:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:10:47 --> Input Class Initialized
INFO - 2020-03-09 13:10:47 --> Language Class Initialized
INFO - 2020-03-09 13:10:47 --> Loader Class Initialized
INFO - 2020-03-09 13:10:47 --> Helper loaded: url_helper
INFO - 2020-03-09 13:10:47 --> Helper loaded: string_helper
INFO - 2020-03-09 13:10:47 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:10:47 --> Controller Class Initialized
INFO - 2020-03-09 13:10:47 --> Model "M_tiket" initialized
INFO - 2020-03-09 13:10:47 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 13:10:47 --> Model "M_pesan" initialized
INFO - 2020-03-09 13:10:47 --> Helper loaded: form_helper
INFO - 2020-03-09 13:10:47 --> Form Validation Class Initialized
INFO - 2020-03-09 13:10:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-09 13:10:47 --> Final output sent to browser
DEBUG - 2020-03-09 13:10:47 --> Total execution time: 0.0199
INFO - 2020-03-09 13:11:02 --> Config Class Initialized
INFO - 2020-03-09 13:11:02 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:11:02 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:11:02 --> Utf8 Class Initialized
INFO - 2020-03-09 13:11:02 --> URI Class Initialized
INFO - 2020-03-09 13:11:02 --> Router Class Initialized
INFO - 2020-03-09 13:11:02 --> Output Class Initialized
INFO - 2020-03-09 13:11:02 --> Security Class Initialized
DEBUG - 2020-03-09 13:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:11:02 --> Input Class Initialized
INFO - 2020-03-09 13:11:02 --> Language Class Initialized
INFO - 2020-03-09 13:11:02 --> Loader Class Initialized
INFO - 2020-03-09 13:11:02 --> Helper loaded: url_helper
INFO - 2020-03-09 13:11:02 --> Helper loaded: string_helper
INFO - 2020-03-09 13:11:02 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:11:02 --> Controller Class Initialized
INFO - 2020-03-09 13:11:02 --> Model "M_tiket" initialized
INFO - 2020-03-09 13:11:02 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 13:11:02 --> Model "M_pesan" initialized
INFO - 2020-03-09 13:11:02 --> Helper loaded: form_helper
INFO - 2020-03-09 13:11:02 --> Form Validation Class Initialized
INFO - 2020-03-09 13:11:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-09 13:11:02 --> Final output sent to browser
DEBUG - 2020-03-09 13:11:02 --> Total execution time: 0.0679
INFO - 2020-03-09 13:13:01 --> Config Class Initialized
INFO - 2020-03-09 13:13:01 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:13:01 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:13:01 --> Utf8 Class Initialized
INFO - 2020-03-09 13:13:01 --> URI Class Initialized
INFO - 2020-03-09 13:13:01 --> Router Class Initialized
INFO - 2020-03-09 13:13:01 --> Output Class Initialized
INFO - 2020-03-09 13:13:01 --> Security Class Initialized
DEBUG - 2020-03-09 13:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:13:01 --> Input Class Initialized
INFO - 2020-03-09 13:13:01 --> Language Class Initialized
INFO - 2020-03-09 13:13:01 --> Loader Class Initialized
INFO - 2020-03-09 13:13:01 --> Helper loaded: url_helper
INFO - 2020-03-09 13:13:01 --> Helper loaded: string_helper
INFO - 2020-03-09 13:13:01 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:13:01 --> Controller Class Initialized
INFO - 2020-03-09 13:13:01 --> Model "M_tiket" initialized
INFO - 2020-03-09 13:13:01 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 13:13:01 --> Model "M_pesan" initialized
INFO - 2020-03-09 13:13:01 --> Helper loaded: form_helper
INFO - 2020-03-09 13:13:01 --> Form Validation Class Initialized
DEBUG - 2020-03-09 13:13:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-09 13:13:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-09 13:13:01 --> Final output sent to browser
DEBUG - 2020-03-09 13:13:01 --> Total execution time: 0.0890
INFO - 2020-03-09 13:13:08 --> Config Class Initialized
INFO - 2020-03-09 13:13:08 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:13:08 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:13:08 --> Utf8 Class Initialized
INFO - 2020-03-09 13:13:08 --> URI Class Initialized
INFO - 2020-03-09 13:13:08 --> Router Class Initialized
INFO - 2020-03-09 13:13:08 --> Output Class Initialized
INFO - 2020-03-09 13:13:08 --> Security Class Initialized
DEBUG - 2020-03-09 13:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:13:08 --> Input Class Initialized
INFO - 2020-03-09 13:13:08 --> Language Class Initialized
INFO - 2020-03-09 13:13:08 --> Loader Class Initialized
INFO - 2020-03-09 13:13:08 --> Helper loaded: url_helper
INFO - 2020-03-09 13:13:08 --> Helper loaded: string_helper
INFO - 2020-03-09 13:13:08 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:13:08 --> Controller Class Initialized
INFO - 2020-03-09 13:13:08 --> Model "M_tiket" initialized
INFO - 2020-03-09 13:13:08 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 13:13:08 --> Model "M_pesan" initialized
INFO - 2020-03-09 13:13:08 --> Helper loaded: form_helper
INFO - 2020-03-09 13:13:08 --> Form Validation Class Initialized
INFO - 2020-03-09 13:13:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-09 13:13:08 --> Final output sent to browser
DEBUG - 2020-03-09 13:13:08 --> Total execution time: 0.0089
INFO - 2020-03-09 13:13:12 --> Config Class Initialized
INFO - 2020-03-09 13:13:12 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:13:12 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:13:12 --> Utf8 Class Initialized
INFO - 2020-03-09 13:13:12 --> URI Class Initialized
INFO - 2020-03-09 13:13:12 --> Router Class Initialized
INFO - 2020-03-09 13:13:12 --> Output Class Initialized
INFO - 2020-03-09 13:13:12 --> Security Class Initialized
DEBUG - 2020-03-09 13:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:13:12 --> Input Class Initialized
INFO - 2020-03-09 13:13:12 --> Language Class Initialized
INFO - 2020-03-09 13:13:12 --> Loader Class Initialized
INFO - 2020-03-09 13:13:12 --> Helper loaded: url_helper
INFO - 2020-03-09 13:13:12 --> Helper loaded: string_helper
INFO - 2020-03-09 13:13:12 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:13:12 --> Controller Class Initialized
INFO - 2020-03-09 13:13:12 --> Model "M_tiket" initialized
INFO - 2020-03-09 13:13:12 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 13:13:12 --> Model "M_pesan" initialized
INFO - 2020-03-09 13:13:12 --> Helper loaded: form_helper
INFO - 2020-03-09 13:13:12 --> Form Validation Class Initialized
DEBUG - 2020-03-09 13:13:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-09 13:13:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-09 13:13:12 --> Final output sent to browser
DEBUG - 2020-03-09 13:13:12 --> Total execution time: 0.0098
INFO - 2020-03-09 13:13:20 --> Config Class Initialized
INFO - 2020-03-09 13:13:20 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:13:20 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:13:20 --> Utf8 Class Initialized
INFO - 2020-03-09 13:13:20 --> URI Class Initialized
INFO - 2020-03-09 13:13:20 --> Router Class Initialized
INFO - 2020-03-09 13:13:20 --> Output Class Initialized
INFO - 2020-03-09 13:13:20 --> Security Class Initialized
DEBUG - 2020-03-09 13:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:13:20 --> Input Class Initialized
INFO - 2020-03-09 13:13:20 --> Language Class Initialized
INFO - 2020-03-09 13:13:20 --> Loader Class Initialized
INFO - 2020-03-09 13:13:20 --> Helper loaded: url_helper
INFO - 2020-03-09 13:13:20 --> Helper loaded: string_helper
INFO - 2020-03-09 13:13:20 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:13:20 --> Controller Class Initialized
INFO - 2020-03-09 13:13:20 --> Model "M_tiket" initialized
INFO - 2020-03-09 13:13:20 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 13:13:20 --> Model "M_pesan" initialized
INFO - 2020-03-09 13:13:20 --> Helper loaded: form_helper
INFO - 2020-03-09 13:13:20 --> Form Validation Class Initialized
INFO - 2020-03-09 13:13:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-09 13:13:20 --> Final output sent to browser
DEBUG - 2020-03-09 13:13:20 --> Total execution time: 0.0076
INFO - 2020-03-09 13:13:37 --> Config Class Initialized
INFO - 2020-03-09 13:13:37 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:13:37 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:13:37 --> Utf8 Class Initialized
INFO - 2020-03-09 13:13:37 --> URI Class Initialized
INFO - 2020-03-09 13:13:37 --> Router Class Initialized
INFO - 2020-03-09 13:13:37 --> Output Class Initialized
INFO - 2020-03-09 13:13:37 --> Security Class Initialized
DEBUG - 2020-03-09 13:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:13:37 --> Input Class Initialized
INFO - 2020-03-09 13:13:37 --> Language Class Initialized
INFO - 2020-03-09 13:13:37 --> Loader Class Initialized
INFO - 2020-03-09 13:13:37 --> Helper loaded: url_helper
INFO - 2020-03-09 13:13:37 --> Helper loaded: string_helper
INFO - 2020-03-09 13:13:37 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:13:37 --> Controller Class Initialized
INFO - 2020-03-09 13:13:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 13:13:37 --> Pagination Class Initialized
INFO - 2020-03-09 13:13:37 --> Model "M_show" initialized
INFO - 2020-03-09 13:13:37 --> Helper loaded: form_helper
INFO - 2020-03-09 13:13:37 --> Form Validation Class Initialized
INFO - 2020-03-09 13:13:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 13:13:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 13:13:37 --> Final output sent to browser
DEBUG - 2020-03-09 13:13:37 --> Total execution time: 0.0917
INFO - 2020-03-09 13:19:22 --> Config Class Initialized
INFO - 2020-03-09 13:19:22 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:19:22 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:19:22 --> Utf8 Class Initialized
INFO - 2020-03-09 13:19:22 --> URI Class Initialized
INFO - 2020-03-09 13:19:22 --> Router Class Initialized
INFO - 2020-03-09 13:19:22 --> Output Class Initialized
INFO - 2020-03-09 13:19:22 --> Security Class Initialized
DEBUG - 2020-03-09 13:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:19:22 --> Input Class Initialized
INFO - 2020-03-09 13:19:22 --> Language Class Initialized
INFO - 2020-03-09 13:19:22 --> Loader Class Initialized
INFO - 2020-03-09 13:19:22 --> Helper loaded: url_helper
INFO - 2020-03-09 13:19:22 --> Helper loaded: string_helper
INFO - 2020-03-09 13:19:22 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:19:22 --> Controller Class Initialized
INFO - 2020-03-09 13:19:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 13:19:22 --> Pagination Class Initialized
INFO - 2020-03-09 13:19:22 --> Model "M_show" initialized
INFO - 2020-03-09 13:19:22 --> Helper loaded: form_helper
INFO - 2020-03-09 13:19:22 --> Form Validation Class Initialized
INFO - 2020-03-09 13:19:22 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 13:19:22 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 13:19:22 --> Final output sent to browser
DEBUG - 2020-03-09 13:19:22 --> Total execution time: 0.0470
INFO - 2020-03-09 13:22:33 --> Config Class Initialized
INFO - 2020-03-09 13:22:33 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:22:33 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:22:33 --> Utf8 Class Initialized
INFO - 2020-03-09 13:22:33 --> URI Class Initialized
INFO - 2020-03-09 13:22:33 --> Router Class Initialized
INFO - 2020-03-09 13:22:33 --> Output Class Initialized
INFO - 2020-03-09 13:22:33 --> Security Class Initialized
DEBUG - 2020-03-09 13:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:22:33 --> Input Class Initialized
INFO - 2020-03-09 13:22:33 --> Language Class Initialized
INFO - 2020-03-09 13:22:33 --> Loader Class Initialized
INFO - 2020-03-09 13:22:33 --> Helper loaded: url_helper
INFO - 2020-03-09 13:22:33 --> Helper loaded: string_helper
INFO - 2020-03-09 13:22:33 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:22:33 --> Controller Class Initialized
INFO - 2020-03-09 13:22:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 13:22:33 --> Pagination Class Initialized
INFO - 2020-03-09 13:22:33 --> Model "M_show" initialized
INFO - 2020-03-09 13:22:33 --> Helper loaded: form_helper
INFO - 2020-03-09 13:22:33 --> Form Validation Class Initialized
INFO - 2020-03-09 13:22:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 13:22:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 13:22:33 --> Final output sent to browser
DEBUG - 2020-03-09 13:22:33 --> Total execution time: 0.0563
INFO - 2020-03-09 13:22:34 --> Config Class Initialized
INFO - 2020-03-09 13:22:34 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:22:34 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:22:34 --> Utf8 Class Initialized
INFO - 2020-03-09 13:22:34 --> URI Class Initialized
INFO - 2020-03-09 13:22:34 --> Router Class Initialized
INFO - 2020-03-09 13:22:34 --> Output Class Initialized
INFO - 2020-03-09 13:22:34 --> Security Class Initialized
DEBUG - 2020-03-09 13:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:22:34 --> Input Class Initialized
INFO - 2020-03-09 13:22:34 --> Language Class Initialized
ERROR - 2020-03-09 13:22:34 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-09 13:24:03 --> Config Class Initialized
INFO - 2020-03-09 13:24:03 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:24:03 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:24:03 --> Utf8 Class Initialized
INFO - 2020-03-09 13:24:03 --> URI Class Initialized
INFO - 2020-03-09 13:24:03 --> Router Class Initialized
INFO - 2020-03-09 13:24:03 --> Output Class Initialized
INFO - 2020-03-09 13:24:03 --> Security Class Initialized
DEBUG - 2020-03-09 13:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:24:03 --> Input Class Initialized
INFO - 2020-03-09 13:24:03 --> Language Class Initialized
INFO - 2020-03-09 13:24:03 --> Loader Class Initialized
INFO - 2020-03-09 13:24:03 --> Helper loaded: url_helper
INFO - 2020-03-09 13:24:03 --> Helper loaded: string_helper
INFO - 2020-03-09 13:24:03 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:24:03 --> Controller Class Initialized
INFO - 2020-03-09 13:24:03 --> Model "M_tiket" initialized
INFO - 2020-03-09 13:24:03 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 13:24:03 --> Model "M_pesan" initialized
INFO - 2020-03-09 13:24:03 --> Helper loaded: form_helper
INFO - 2020-03-09 13:24:03 --> Form Validation Class Initialized
INFO - 2020-03-09 13:24:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-09 13:24:03 --> Final output sent to browser
DEBUG - 2020-03-09 13:24:03 --> Total execution time: 0.0521
INFO - 2020-03-09 13:25:46 --> Config Class Initialized
INFO - 2020-03-09 13:25:46 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:25:46 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:25:46 --> Utf8 Class Initialized
INFO - 2020-03-09 13:25:46 --> URI Class Initialized
INFO - 2020-03-09 13:25:46 --> Router Class Initialized
INFO - 2020-03-09 13:25:46 --> Output Class Initialized
INFO - 2020-03-09 13:25:46 --> Security Class Initialized
DEBUG - 2020-03-09 13:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:25:46 --> Input Class Initialized
INFO - 2020-03-09 13:25:46 --> Language Class Initialized
INFO - 2020-03-09 13:25:46 --> Loader Class Initialized
INFO - 2020-03-09 13:25:46 --> Helper loaded: url_helper
INFO - 2020-03-09 13:25:46 --> Helper loaded: string_helper
INFO - 2020-03-09 13:25:46 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:25:46 --> Controller Class Initialized
INFO - 2020-03-09 13:25:46 --> Model "M_tiket" initialized
INFO - 2020-03-09 13:25:46 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 13:25:46 --> Model "M_pesan" initialized
INFO - 2020-03-09 13:25:46 --> Helper loaded: form_helper
INFO - 2020-03-09 13:25:46 --> Form Validation Class Initialized
INFO - 2020-03-09 20:25:46 --> Upload Class Initialized
INFO - 2020-03-09 13:26:44 --> Config Class Initialized
INFO - 2020-03-09 13:26:44 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:26:44 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:26:44 --> Utf8 Class Initialized
INFO - 2020-03-09 13:26:44 --> URI Class Initialized
INFO - 2020-03-09 13:26:44 --> Router Class Initialized
INFO - 2020-03-09 13:26:44 --> Output Class Initialized
INFO - 2020-03-09 13:26:44 --> Security Class Initialized
DEBUG - 2020-03-09 13:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:26:44 --> Input Class Initialized
INFO - 2020-03-09 13:26:44 --> Language Class Initialized
INFO - 2020-03-09 13:26:44 --> Loader Class Initialized
INFO - 2020-03-09 13:26:44 --> Helper loaded: url_helper
INFO - 2020-03-09 13:26:44 --> Helper loaded: string_helper
INFO - 2020-03-09 13:26:44 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:26:44 --> Controller Class Initialized
INFO - 2020-03-09 13:26:44 --> Model "M_tiket" initialized
INFO - 2020-03-09 13:26:44 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 13:26:44 --> Model "M_pesan" initialized
INFO - 2020-03-09 13:26:44 --> Helper loaded: form_helper
INFO - 2020-03-09 13:26:44 --> Form Validation Class Initialized
INFO - 2020-03-09 13:26:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-09 13:26:44 --> Final output sent to browser
DEBUG - 2020-03-09 13:26:44 --> Total execution time: 0.0111
INFO - 2020-03-09 13:27:04 --> Config Class Initialized
INFO - 2020-03-09 13:27:04 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:27:04 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:27:04 --> Utf8 Class Initialized
INFO - 2020-03-09 13:27:04 --> URI Class Initialized
INFO - 2020-03-09 13:27:04 --> Router Class Initialized
INFO - 2020-03-09 13:27:04 --> Output Class Initialized
INFO - 2020-03-09 13:27:04 --> Security Class Initialized
DEBUG - 2020-03-09 13:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:27:04 --> Input Class Initialized
INFO - 2020-03-09 13:27:04 --> Language Class Initialized
INFO - 2020-03-09 13:27:04 --> Loader Class Initialized
INFO - 2020-03-09 13:27:04 --> Helper loaded: url_helper
INFO - 2020-03-09 13:27:04 --> Helper loaded: string_helper
INFO - 2020-03-09 13:27:04 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:27:04 --> Controller Class Initialized
INFO - 2020-03-09 13:27:04 --> Model "M_tiket" initialized
INFO - 2020-03-09 13:27:04 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 13:27:04 --> Model "M_pesan" initialized
INFO - 2020-03-09 13:27:04 --> Helper loaded: form_helper
INFO - 2020-03-09 13:27:04 --> Form Validation Class Initialized
INFO - 2020-03-09 13:27:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-09 13:27:04 --> Final output sent to browser
DEBUG - 2020-03-09 13:27:04 --> Total execution time: 0.0105
INFO - 2020-03-09 13:28:07 --> Config Class Initialized
INFO - 2020-03-09 13:28:07 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:28:07 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:28:07 --> Utf8 Class Initialized
INFO - 2020-03-09 13:28:07 --> URI Class Initialized
INFO - 2020-03-09 13:28:07 --> Router Class Initialized
INFO - 2020-03-09 13:28:07 --> Output Class Initialized
INFO - 2020-03-09 13:28:07 --> Security Class Initialized
DEBUG - 2020-03-09 13:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:28:07 --> Input Class Initialized
INFO - 2020-03-09 13:28:07 --> Language Class Initialized
INFO - 2020-03-09 13:28:07 --> Loader Class Initialized
INFO - 2020-03-09 13:28:07 --> Helper loaded: url_helper
INFO - 2020-03-09 13:28:07 --> Helper loaded: string_helper
INFO - 2020-03-09 13:28:07 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:28:07 --> Controller Class Initialized
INFO - 2020-03-09 13:28:07 --> Model "M_tiket" initialized
INFO - 2020-03-09 13:28:07 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 13:28:07 --> Model "M_pesan" initialized
INFO - 2020-03-09 13:28:07 --> Helper loaded: form_helper
INFO - 2020-03-09 13:28:07 --> Form Validation Class Initialized
INFO - 2020-03-09 20:28:07 --> Upload Class Initialized
INFO - 2020-03-09 13:28:22 --> Config Class Initialized
INFO - 2020-03-09 13:28:22 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:28:22 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:28:22 --> Utf8 Class Initialized
INFO - 2020-03-09 13:28:22 --> URI Class Initialized
INFO - 2020-03-09 13:28:22 --> Router Class Initialized
INFO - 2020-03-09 13:28:22 --> Output Class Initialized
INFO - 2020-03-09 13:28:22 --> Security Class Initialized
DEBUG - 2020-03-09 13:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:28:22 --> Input Class Initialized
INFO - 2020-03-09 13:28:22 --> Language Class Initialized
INFO - 2020-03-09 13:28:22 --> Loader Class Initialized
INFO - 2020-03-09 13:28:22 --> Helper loaded: url_helper
INFO - 2020-03-09 13:28:22 --> Helper loaded: string_helper
INFO - 2020-03-09 13:28:22 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:28:22 --> Controller Class Initialized
INFO - 2020-03-09 13:28:22 --> Model "M_tiket" initialized
INFO - 2020-03-09 13:28:22 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 13:28:22 --> Model "M_pesan" initialized
INFO - 2020-03-09 13:28:22 --> Helper loaded: form_helper
INFO - 2020-03-09 13:28:22 --> Form Validation Class Initialized
INFO - 2020-03-09 20:28:22 --> Upload Class Initialized
INFO - 2020-03-09 13:28:23 --> Config Class Initialized
INFO - 2020-03-09 13:28:23 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:28:23 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:28:23 --> Utf8 Class Initialized
INFO - 2020-03-09 13:28:23 --> URI Class Initialized
INFO - 2020-03-09 13:28:23 --> Router Class Initialized
INFO - 2020-03-09 13:28:23 --> Output Class Initialized
INFO - 2020-03-09 13:28:23 --> Security Class Initialized
DEBUG - 2020-03-09 13:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:28:23 --> Input Class Initialized
INFO - 2020-03-09 13:28:23 --> Language Class Initialized
INFO - 2020-03-09 13:28:23 --> Loader Class Initialized
INFO - 2020-03-09 13:28:23 --> Helper loaded: url_helper
INFO - 2020-03-09 13:28:23 --> Helper loaded: string_helper
INFO - 2020-03-09 13:28:23 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:28:23 --> Controller Class Initialized
INFO - 2020-03-09 13:28:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 13:28:23 --> Pagination Class Initialized
INFO - 2020-03-09 13:28:23 --> Model "M_show" initialized
INFO - 2020-03-09 13:28:23 --> Helper loaded: form_helper
INFO - 2020-03-09 13:28:23 --> Form Validation Class Initialized
INFO - 2020-03-09 13:28:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 13:28:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 13:28:23 --> Final output sent to browser
DEBUG - 2020-03-09 13:28:23 --> Total execution time: 0.0131
INFO - 2020-03-09 13:29:33 --> Config Class Initialized
INFO - 2020-03-09 13:29:33 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:29:33 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:29:33 --> Utf8 Class Initialized
INFO - 2020-03-09 13:29:33 --> URI Class Initialized
INFO - 2020-03-09 13:29:33 --> Router Class Initialized
INFO - 2020-03-09 13:29:33 --> Output Class Initialized
INFO - 2020-03-09 13:29:33 --> Security Class Initialized
DEBUG - 2020-03-09 13:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:29:33 --> Input Class Initialized
INFO - 2020-03-09 13:29:33 --> Language Class Initialized
INFO - 2020-03-09 13:29:33 --> Loader Class Initialized
INFO - 2020-03-09 13:29:33 --> Helper loaded: url_helper
INFO - 2020-03-09 13:29:33 --> Helper loaded: string_helper
INFO - 2020-03-09 13:29:33 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:29:33 --> Controller Class Initialized
INFO - 2020-03-09 13:29:33 --> Model "M_tiket" initialized
INFO - 2020-03-09 13:29:33 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 13:29:33 --> Model "M_pesan" initialized
INFO - 2020-03-09 13:29:33 --> Helper loaded: form_helper
INFO - 2020-03-09 13:29:33 --> Form Validation Class Initialized
INFO - 2020-03-09 13:29:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-09 13:29:33 --> Final output sent to browser
DEBUG - 2020-03-09 13:29:33 --> Total execution time: 0.0107
INFO - 2020-03-09 13:29:33 --> Config Class Initialized
INFO - 2020-03-09 13:29:33 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:29:33 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:29:33 --> Utf8 Class Initialized
INFO - 2020-03-09 13:29:33 --> URI Class Initialized
INFO - 2020-03-09 13:29:33 --> Router Class Initialized
INFO - 2020-03-09 13:29:33 --> Output Class Initialized
INFO - 2020-03-09 13:29:33 --> Security Class Initialized
DEBUG - 2020-03-09 13:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:29:33 --> Input Class Initialized
INFO - 2020-03-09 13:29:33 --> Language Class Initialized
INFO - 2020-03-09 13:29:33 --> Loader Class Initialized
INFO - 2020-03-09 13:29:33 --> Helper loaded: url_helper
INFO - 2020-03-09 13:29:33 --> Helper loaded: string_helper
INFO - 2020-03-09 13:29:33 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:29:33 --> Controller Class Initialized
INFO - 2020-03-09 13:29:33 --> Model "M_tiket" initialized
INFO - 2020-03-09 13:29:33 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 13:29:33 --> Model "M_pesan" initialized
INFO - 2020-03-09 13:29:33 --> Helper loaded: form_helper
INFO - 2020-03-09 13:29:33 --> Form Validation Class Initialized
INFO - 2020-03-09 13:29:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-09 13:29:33 --> Final output sent to browser
DEBUG - 2020-03-09 13:29:33 --> Total execution time: 0.0066
INFO - 2020-03-09 13:29:43 --> Config Class Initialized
INFO - 2020-03-09 13:29:43 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:29:43 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:29:43 --> Utf8 Class Initialized
INFO - 2020-03-09 13:29:43 --> URI Class Initialized
DEBUG - 2020-03-09 13:29:43 --> No URI present. Default controller set.
INFO - 2020-03-09 13:29:43 --> Router Class Initialized
INFO - 2020-03-09 13:29:43 --> Output Class Initialized
INFO - 2020-03-09 13:29:43 --> Security Class Initialized
DEBUG - 2020-03-09 13:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:29:43 --> Input Class Initialized
INFO - 2020-03-09 13:29:43 --> Language Class Initialized
INFO - 2020-03-09 13:29:43 --> Loader Class Initialized
INFO - 2020-03-09 13:29:43 --> Helper loaded: url_helper
INFO - 2020-03-09 13:29:43 --> Helper loaded: string_helper
INFO - 2020-03-09 13:29:43 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:29:43 --> Controller Class Initialized
INFO - 2020-03-09 13:29:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 13:29:43 --> Pagination Class Initialized
INFO - 2020-03-09 13:29:43 --> Model "M_show" initialized
INFO - 2020-03-09 13:29:43 --> Helper loaded: form_helper
INFO - 2020-03-09 13:29:43 --> Form Validation Class Initialized
INFO - 2020-03-09 13:29:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 13:29:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 13:29:43 --> Final output sent to browser
DEBUG - 2020-03-09 13:29:43 --> Total execution time: 0.0061
INFO - 2020-03-09 13:30:21 --> Config Class Initialized
INFO - 2020-03-09 13:30:21 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:30:21 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:30:21 --> Utf8 Class Initialized
INFO - 2020-03-09 13:30:21 --> URI Class Initialized
DEBUG - 2020-03-09 13:30:21 --> No URI present. Default controller set.
INFO - 2020-03-09 13:30:21 --> Router Class Initialized
INFO - 2020-03-09 13:30:21 --> Output Class Initialized
INFO - 2020-03-09 13:30:21 --> Security Class Initialized
DEBUG - 2020-03-09 13:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:30:21 --> Input Class Initialized
INFO - 2020-03-09 13:30:21 --> Language Class Initialized
INFO - 2020-03-09 13:30:21 --> Loader Class Initialized
INFO - 2020-03-09 13:30:21 --> Helper loaded: url_helper
INFO - 2020-03-09 13:30:21 --> Helper loaded: string_helper
INFO - 2020-03-09 13:30:21 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:30:21 --> Controller Class Initialized
INFO - 2020-03-09 13:30:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 13:30:21 --> Pagination Class Initialized
INFO - 2020-03-09 13:30:21 --> Model "M_show" initialized
INFO - 2020-03-09 13:30:21 --> Helper loaded: form_helper
INFO - 2020-03-09 13:30:21 --> Form Validation Class Initialized
INFO - 2020-03-09 13:30:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 13:30:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 13:30:21 --> Final output sent to browser
DEBUG - 2020-03-09 13:30:21 --> Total execution time: 0.0251
INFO - 2020-03-09 13:30:53 --> Config Class Initialized
INFO - 2020-03-09 13:30:53 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:30:53 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:30:53 --> Utf8 Class Initialized
INFO - 2020-03-09 13:30:53 --> URI Class Initialized
INFO - 2020-03-09 13:30:53 --> Router Class Initialized
INFO - 2020-03-09 13:30:53 --> Output Class Initialized
INFO - 2020-03-09 13:30:53 --> Security Class Initialized
DEBUG - 2020-03-09 13:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:30:53 --> Input Class Initialized
INFO - 2020-03-09 13:30:53 --> Language Class Initialized
INFO - 2020-03-09 13:30:53 --> Loader Class Initialized
INFO - 2020-03-09 13:30:53 --> Helper loaded: url_helper
INFO - 2020-03-09 13:30:53 --> Helper loaded: string_helper
INFO - 2020-03-09 13:30:53 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:30:53 --> Controller Class Initialized
INFO - 2020-03-09 13:30:53 --> Model "M_tiket" initialized
INFO - 2020-03-09 13:30:53 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 13:30:53 --> Model "M_pesan" initialized
INFO - 2020-03-09 13:30:53 --> Helper loaded: form_helper
INFO - 2020-03-09 13:30:53 --> Form Validation Class Initialized
INFO - 2020-03-09 13:30:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-09 13:30:53 --> Final output sent to browser
DEBUG - 2020-03-09 13:30:53 --> Total execution time: 0.0634
INFO - 2020-03-09 13:31:08 --> Config Class Initialized
INFO - 2020-03-09 13:31:08 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:31:08 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:31:08 --> Utf8 Class Initialized
INFO - 2020-03-09 13:31:08 --> URI Class Initialized
INFO - 2020-03-09 13:31:08 --> Router Class Initialized
INFO - 2020-03-09 13:31:08 --> Output Class Initialized
INFO - 2020-03-09 13:31:08 --> Security Class Initialized
DEBUG - 2020-03-09 13:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:31:08 --> Input Class Initialized
INFO - 2020-03-09 13:31:08 --> Language Class Initialized
INFO - 2020-03-09 13:31:08 --> Loader Class Initialized
INFO - 2020-03-09 13:31:08 --> Helper loaded: url_helper
INFO - 2020-03-09 13:31:08 --> Helper loaded: string_helper
INFO - 2020-03-09 13:31:08 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:31:08 --> Controller Class Initialized
INFO - 2020-03-09 13:31:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 13:31:08 --> Pagination Class Initialized
INFO - 2020-03-09 13:31:08 --> Model "M_show" initialized
INFO - 2020-03-09 13:31:08 --> Helper loaded: form_helper
INFO - 2020-03-09 13:31:08 --> Form Validation Class Initialized
INFO - 2020-03-09 13:31:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 13:31:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 13:31:08 --> Final output sent to browser
DEBUG - 2020-03-09 13:31:08 --> Total execution time: 0.2414
INFO - 2020-03-09 13:31:24 --> Config Class Initialized
INFO - 2020-03-09 13:31:24 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:31:24 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:31:24 --> Utf8 Class Initialized
INFO - 2020-03-09 13:31:24 --> URI Class Initialized
INFO - 2020-03-09 13:31:24 --> Router Class Initialized
INFO - 2020-03-09 13:31:24 --> Output Class Initialized
INFO - 2020-03-09 13:31:24 --> Security Class Initialized
DEBUG - 2020-03-09 13:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:31:24 --> Input Class Initialized
INFO - 2020-03-09 13:31:24 --> Language Class Initialized
INFO - 2020-03-09 13:31:24 --> Loader Class Initialized
INFO - 2020-03-09 13:31:24 --> Helper loaded: url_helper
INFO - 2020-03-09 13:31:24 --> Helper loaded: string_helper
INFO - 2020-03-09 13:31:24 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:31:24 --> Controller Class Initialized
INFO - 2020-03-09 13:31:24 --> Model "M_tiket" initialized
INFO - 2020-03-09 13:31:24 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 13:31:24 --> Model "M_pesan" initialized
INFO - 2020-03-09 13:31:24 --> Helper loaded: form_helper
INFO - 2020-03-09 13:31:24 --> Form Validation Class Initialized
INFO - 2020-03-09 13:31:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-09 13:31:24 --> Final output sent to browser
DEBUG - 2020-03-09 13:31:24 --> Total execution time: 0.0815
INFO - 2020-03-09 13:32:20 --> Config Class Initialized
INFO - 2020-03-09 13:32:20 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:32:20 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:32:20 --> Utf8 Class Initialized
INFO - 2020-03-09 13:32:20 --> URI Class Initialized
INFO - 2020-03-09 13:32:20 --> Router Class Initialized
INFO - 2020-03-09 13:32:20 --> Output Class Initialized
INFO - 2020-03-09 13:32:20 --> Security Class Initialized
DEBUG - 2020-03-09 13:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:32:20 --> Input Class Initialized
INFO - 2020-03-09 13:32:20 --> Language Class Initialized
INFO - 2020-03-09 13:32:20 --> Loader Class Initialized
INFO - 2020-03-09 13:32:20 --> Helper loaded: url_helper
INFO - 2020-03-09 13:32:20 --> Helper loaded: string_helper
INFO - 2020-03-09 13:32:20 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:32:20 --> Controller Class Initialized
INFO - 2020-03-09 13:32:20 --> Model "M_tiket" initialized
INFO - 2020-03-09 13:32:20 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 13:32:20 --> Model "M_pesan" initialized
INFO - 2020-03-09 13:32:20 --> Helper loaded: form_helper
INFO - 2020-03-09 13:32:20 --> Form Validation Class Initialized
INFO - 2020-03-09 20:32:20 --> Upload Class Initialized
INFO - 2020-03-09 13:32:21 --> Config Class Initialized
INFO - 2020-03-09 13:32:21 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:32:21 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:32:21 --> Utf8 Class Initialized
INFO - 2020-03-09 13:32:21 --> URI Class Initialized
INFO - 2020-03-09 13:32:21 --> Router Class Initialized
INFO - 2020-03-09 13:32:21 --> Output Class Initialized
INFO - 2020-03-09 13:32:21 --> Security Class Initialized
DEBUG - 2020-03-09 13:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:32:21 --> Input Class Initialized
INFO - 2020-03-09 13:32:21 --> Language Class Initialized
INFO - 2020-03-09 13:32:21 --> Loader Class Initialized
INFO - 2020-03-09 13:32:21 --> Helper loaded: url_helper
INFO - 2020-03-09 13:32:21 --> Helper loaded: string_helper
INFO - 2020-03-09 13:32:21 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:32:21 --> Controller Class Initialized
INFO - 2020-03-09 13:32:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 13:32:21 --> Pagination Class Initialized
INFO - 2020-03-09 13:32:21 --> Model "M_show" initialized
INFO - 2020-03-09 13:32:21 --> Helper loaded: form_helper
INFO - 2020-03-09 13:32:21 --> Form Validation Class Initialized
INFO - 2020-03-09 13:32:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 13:32:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 13:32:21 --> Final output sent to browser
DEBUG - 2020-03-09 13:32:21 --> Total execution time: 0.0072
INFO - 2020-03-09 13:32:23 --> Config Class Initialized
INFO - 2020-03-09 13:32:23 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:32:23 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:32:23 --> Utf8 Class Initialized
INFO - 2020-03-09 13:32:23 --> URI Class Initialized
INFO - 2020-03-09 13:32:23 --> Router Class Initialized
INFO - 2020-03-09 13:32:23 --> Output Class Initialized
INFO - 2020-03-09 13:32:23 --> Security Class Initialized
DEBUG - 2020-03-09 13:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:32:23 --> Input Class Initialized
INFO - 2020-03-09 13:32:23 --> Language Class Initialized
INFO - 2020-03-09 13:32:23 --> Loader Class Initialized
INFO - 2020-03-09 13:32:23 --> Helper loaded: url_helper
INFO - 2020-03-09 13:32:23 --> Helper loaded: string_helper
INFO - 2020-03-09 13:32:23 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:32:23 --> Controller Class Initialized
INFO - 2020-03-09 13:32:23 --> Model "M_tiket" initialized
INFO - 2020-03-09 13:32:23 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 13:32:23 --> Model "M_pesan" initialized
INFO - 2020-03-09 13:32:23 --> Helper loaded: form_helper
INFO - 2020-03-09 13:32:23 --> Form Validation Class Initialized
INFO - 2020-03-09 13:32:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-09 13:32:23 --> Final output sent to browser
DEBUG - 2020-03-09 13:32:23 --> Total execution time: 0.1023
INFO - 2020-03-09 13:33:05 --> Config Class Initialized
INFO - 2020-03-09 13:33:05 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:33:05 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:33:05 --> Utf8 Class Initialized
INFO - 2020-03-09 13:33:05 --> URI Class Initialized
INFO - 2020-03-09 13:33:05 --> Router Class Initialized
INFO - 2020-03-09 13:33:05 --> Output Class Initialized
INFO - 2020-03-09 13:33:05 --> Security Class Initialized
DEBUG - 2020-03-09 13:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:33:05 --> Input Class Initialized
INFO - 2020-03-09 13:33:05 --> Language Class Initialized
INFO - 2020-03-09 13:33:05 --> Loader Class Initialized
INFO - 2020-03-09 13:33:05 --> Helper loaded: url_helper
INFO - 2020-03-09 13:33:05 --> Helper loaded: string_helper
INFO - 2020-03-09 13:33:05 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:33:05 --> Controller Class Initialized
INFO - 2020-03-09 13:33:05 --> Model "M_tiket" initialized
INFO - 2020-03-09 13:33:05 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 13:33:05 --> Model "M_pesan" initialized
INFO - 2020-03-09 13:33:05 --> Helper loaded: form_helper
INFO - 2020-03-09 13:33:05 --> Form Validation Class Initialized
INFO - 2020-03-09 13:33:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-09 13:33:05 --> Final output sent to browser
DEBUG - 2020-03-09 13:33:05 --> Total execution time: 0.0085
INFO - 2020-03-09 13:34:05 --> Config Class Initialized
INFO - 2020-03-09 13:34:05 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:34:05 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:34:05 --> Utf8 Class Initialized
INFO - 2020-03-09 13:34:05 --> URI Class Initialized
DEBUG - 2020-03-09 13:34:05 --> No URI present. Default controller set.
INFO - 2020-03-09 13:34:05 --> Router Class Initialized
INFO - 2020-03-09 13:34:05 --> Output Class Initialized
INFO - 2020-03-09 13:34:05 --> Security Class Initialized
DEBUG - 2020-03-09 13:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:34:05 --> Input Class Initialized
INFO - 2020-03-09 13:34:05 --> Language Class Initialized
INFO - 2020-03-09 13:34:05 --> Loader Class Initialized
INFO - 2020-03-09 13:34:05 --> Helper loaded: url_helper
INFO - 2020-03-09 13:34:05 --> Helper loaded: string_helper
INFO - 2020-03-09 13:34:05 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:34:05 --> Controller Class Initialized
INFO - 2020-03-09 13:34:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 13:34:05 --> Pagination Class Initialized
INFO - 2020-03-09 13:34:05 --> Model "M_show" initialized
INFO - 2020-03-09 13:34:05 --> Helper loaded: form_helper
INFO - 2020-03-09 13:34:05 --> Form Validation Class Initialized
INFO - 2020-03-09 13:34:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 13:34:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 13:34:05 --> Final output sent to browser
DEBUG - 2020-03-09 13:34:05 --> Total execution time: 0.0061
INFO - 2020-03-09 13:34:17 --> Config Class Initialized
INFO - 2020-03-09 13:34:17 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:34:17 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:34:17 --> Utf8 Class Initialized
INFO - 2020-03-09 13:34:17 --> URI Class Initialized
INFO - 2020-03-09 13:34:17 --> Router Class Initialized
INFO - 2020-03-09 13:34:17 --> Output Class Initialized
INFO - 2020-03-09 13:34:17 --> Security Class Initialized
DEBUG - 2020-03-09 13:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:34:17 --> Input Class Initialized
INFO - 2020-03-09 13:34:17 --> Language Class Initialized
INFO - 2020-03-09 13:34:17 --> Loader Class Initialized
INFO - 2020-03-09 13:34:17 --> Helper loaded: url_helper
INFO - 2020-03-09 13:34:17 --> Helper loaded: string_helper
INFO - 2020-03-09 13:34:17 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:34:17 --> Controller Class Initialized
INFO - 2020-03-09 13:34:17 --> Model "M_tiket" initialized
INFO - 2020-03-09 13:34:17 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 13:34:17 --> Model "M_pesan" initialized
INFO - 2020-03-09 13:34:17 --> Helper loaded: form_helper
INFO - 2020-03-09 13:34:17 --> Form Validation Class Initialized
INFO - 2020-03-09 13:34:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-09 13:34:17 --> Final output sent to browser
DEBUG - 2020-03-09 13:34:17 --> Total execution time: 0.0079
INFO - 2020-03-09 13:34:28 --> Config Class Initialized
INFO - 2020-03-09 13:34:28 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:34:28 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:34:28 --> Utf8 Class Initialized
INFO - 2020-03-09 13:34:28 --> URI Class Initialized
INFO - 2020-03-09 13:34:28 --> Router Class Initialized
INFO - 2020-03-09 13:34:28 --> Output Class Initialized
INFO - 2020-03-09 13:34:28 --> Security Class Initialized
DEBUG - 2020-03-09 13:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:34:28 --> Input Class Initialized
INFO - 2020-03-09 13:34:28 --> Language Class Initialized
INFO - 2020-03-09 13:34:28 --> Loader Class Initialized
INFO - 2020-03-09 13:34:28 --> Helper loaded: url_helper
INFO - 2020-03-09 13:34:28 --> Helper loaded: string_helper
INFO - 2020-03-09 13:34:28 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:34:28 --> Controller Class Initialized
INFO - 2020-03-09 13:34:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 13:34:28 --> Pagination Class Initialized
INFO - 2020-03-09 13:34:28 --> Model "M_show" initialized
INFO - 2020-03-09 13:34:28 --> Helper loaded: form_helper
INFO - 2020-03-09 13:34:28 --> Form Validation Class Initialized
INFO - 2020-03-09 13:34:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 13:34:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 13:34:28 --> Final output sent to browser
DEBUG - 2020-03-09 13:34:28 --> Total execution time: 0.0175
INFO - 2020-03-09 13:34:34 --> Config Class Initialized
INFO - 2020-03-09 13:34:34 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:34:34 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:34:34 --> Utf8 Class Initialized
INFO - 2020-03-09 13:34:34 --> URI Class Initialized
INFO - 2020-03-09 13:34:34 --> Router Class Initialized
INFO - 2020-03-09 13:34:34 --> Output Class Initialized
INFO - 2020-03-09 13:34:34 --> Security Class Initialized
DEBUG - 2020-03-09 13:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:34:34 --> Input Class Initialized
INFO - 2020-03-09 13:34:34 --> Language Class Initialized
INFO - 2020-03-09 13:34:34 --> Loader Class Initialized
INFO - 2020-03-09 13:34:34 --> Helper loaded: url_helper
INFO - 2020-03-09 13:34:34 --> Helper loaded: string_helper
INFO - 2020-03-09 13:34:34 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:34:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:34:34 --> Controller Class Initialized
INFO - 2020-03-09 13:34:34 --> Model "M_tiket" initialized
INFO - 2020-03-09 13:34:34 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 13:34:34 --> Model "M_pesan" initialized
INFO - 2020-03-09 13:34:34 --> Helper loaded: form_helper
INFO - 2020-03-09 13:34:34 --> Form Validation Class Initialized
INFO - 2020-03-09 13:34:34 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-09 13:34:34 --> Final output sent to browser
DEBUG - 2020-03-09 13:34:34 --> Total execution time: 0.0110
INFO - 2020-03-09 13:34:53 --> Config Class Initialized
INFO - 2020-03-09 13:34:53 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:34:53 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:34:53 --> Utf8 Class Initialized
INFO - 2020-03-09 13:34:53 --> URI Class Initialized
DEBUG - 2020-03-09 13:34:53 --> No URI present. Default controller set.
INFO - 2020-03-09 13:34:53 --> Router Class Initialized
INFO - 2020-03-09 13:34:53 --> Output Class Initialized
INFO - 2020-03-09 13:34:53 --> Security Class Initialized
DEBUG - 2020-03-09 13:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:34:53 --> Input Class Initialized
INFO - 2020-03-09 13:34:53 --> Language Class Initialized
INFO - 2020-03-09 13:34:53 --> Loader Class Initialized
INFO - 2020-03-09 13:34:53 --> Helper loaded: url_helper
INFO - 2020-03-09 13:34:53 --> Helper loaded: string_helper
INFO - 2020-03-09 13:34:53 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:34:53 --> Controller Class Initialized
INFO - 2020-03-09 13:34:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 13:34:53 --> Pagination Class Initialized
INFO - 2020-03-09 13:34:53 --> Model "M_show" initialized
INFO - 2020-03-09 13:34:53 --> Helper loaded: form_helper
INFO - 2020-03-09 13:34:53 --> Form Validation Class Initialized
INFO - 2020-03-09 13:34:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 13:34:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 13:34:53 --> Final output sent to browser
DEBUG - 2020-03-09 13:34:53 --> Total execution time: 0.0091
INFO - 2020-03-09 13:34:54 --> Config Class Initialized
INFO - 2020-03-09 13:34:54 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:34:54 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:34:54 --> Utf8 Class Initialized
INFO - 2020-03-09 13:34:54 --> URI Class Initialized
DEBUG - 2020-03-09 13:34:54 --> No URI present. Default controller set.
INFO - 2020-03-09 13:34:54 --> Router Class Initialized
INFO - 2020-03-09 13:34:54 --> Output Class Initialized
INFO - 2020-03-09 13:34:54 --> Security Class Initialized
DEBUG - 2020-03-09 13:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:34:54 --> Input Class Initialized
INFO - 2020-03-09 13:34:54 --> Language Class Initialized
INFO - 2020-03-09 13:34:54 --> Loader Class Initialized
INFO - 2020-03-09 13:34:54 --> Helper loaded: url_helper
INFO - 2020-03-09 13:34:54 --> Helper loaded: string_helper
INFO - 2020-03-09 13:34:54 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:34:54 --> Controller Class Initialized
INFO - 2020-03-09 13:34:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 13:34:54 --> Pagination Class Initialized
INFO - 2020-03-09 13:34:54 --> Model "M_show" initialized
INFO - 2020-03-09 13:34:54 --> Helper loaded: form_helper
INFO - 2020-03-09 13:34:54 --> Form Validation Class Initialized
INFO - 2020-03-09 13:34:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 13:34:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 13:34:54 --> Final output sent to browser
DEBUG - 2020-03-09 13:34:54 --> Total execution time: 0.0059
INFO - 2020-03-09 13:34:58 --> Config Class Initialized
INFO - 2020-03-09 13:34:58 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:34:58 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:34:58 --> Utf8 Class Initialized
INFO - 2020-03-09 13:34:58 --> URI Class Initialized
INFO - 2020-03-09 13:34:58 --> Router Class Initialized
INFO - 2020-03-09 13:34:58 --> Output Class Initialized
INFO - 2020-03-09 13:34:58 --> Security Class Initialized
DEBUG - 2020-03-09 13:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:34:58 --> Input Class Initialized
INFO - 2020-03-09 13:34:58 --> Language Class Initialized
INFO - 2020-03-09 13:34:58 --> Loader Class Initialized
INFO - 2020-03-09 13:34:58 --> Helper loaded: url_helper
INFO - 2020-03-09 13:34:58 --> Helper loaded: string_helper
INFO - 2020-03-09 13:34:58 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:34:58 --> Controller Class Initialized
INFO - 2020-03-09 13:34:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 13:34:58 --> Pagination Class Initialized
INFO - 2020-03-09 13:34:58 --> Model "M_show" initialized
INFO - 2020-03-09 13:34:58 --> Helper loaded: form_helper
INFO - 2020-03-09 13:34:58 --> Form Validation Class Initialized
INFO - 2020-03-09 13:34:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 13:34:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 13:34:58 --> Final output sent to browser
DEBUG - 2020-03-09 13:34:58 --> Total execution time: 0.0065
INFO - 2020-03-09 13:34:59 --> Config Class Initialized
INFO - 2020-03-09 13:34:59 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:34:59 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:34:59 --> Utf8 Class Initialized
INFO - 2020-03-09 13:34:59 --> URI Class Initialized
DEBUG - 2020-03-09 13:34:59 --> No URI present. Default controller set.
INFO - 2020-03-09 13:34:59 --> Router Class Initialized
INFO - 2020-03-09 13:34:59 --> Output Class Initialized
INFO - 2020-03-09 13:34:59 --> Security Class Initialized
DEBUG - 2020-03-09 13:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:34:59 --> Input Class Initialized
INFO - 2020-03-09 13:34:59 --> Language Class Initialized
INFO - 2020-03-09 13:34:59 --> Loader Class Initialized
INFO - 2020-03-09 13:34:59 --> Helper loaded: url_helper
INFO - 2020-03-09 13:34:59 --> Helper loaded: string_helper
INFO - 2020-03-09 13:34:59 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:34:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:34:59 --> Controller Class Initialized
INFO - 2020-03-09 13:34:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 13:34:59 --> Pagination Class Initialized
INFO - 2020-03-09 13:34:59 --> Model "M_show" initialized
INFO - 2020-03-09 13:34:59 --> Helper loaded: form_helper
INFO - 2020-03-09 13:34:59 --> Form Validation Class Initialized
INFO - 2020-03-09 13:34:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 13:34:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 13:34:59 --> Final output sent to browser
DEBUG - 2020-03-09 13:34:59 --> Total execution time: 0.0059
INFO - 2020-03-09 13:52:28 --> Config Class Initialized
INFO - 2020-03-09 13:52:28 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:52:28 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:52:28 --> Utf8 Class Initialized
INFO - 2020-03-09 13:52:28 --> URI Class Initialized
DEBUG - 2020-03-09 13:52:28 --> No URI present. Default controller set.
INFO - 2020-03-09 13:52:28 --> Router Class Initialized
INFO - 2020-03-09 13:52:28 --> Output Class Initialized
INFO - 2020-03-09 13:52:28 --> Security Class Initialized
DEBUG - 2020-03-09 13:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:52:28 --> Input Class Initialized
INFO - 2020-03-09 13:52:28 --> Language Class Initialized
INFO - 2020-03-09 13:52:28 --> Loader Class Initialized
INFO - 2020-03-09 13:52:28 --> Helper loaded: url_helper
INFO - 2020-03-09 13:52:28 --> Helper loaded: string_helper
INFO - 2020-03-09 13:52:28 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:52:28 --> Controller Class Initialized
INFO - 2020-03-09 13:52:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 13:52:28 --> Pagination Class Initialized
INFO - 2020-03-09 13:52:28 --> Model "M_show" initialized
INFO - 2020-03-09 13:52:28 --> Helper loaded: form_helper
INFO - 2020-03-09 13:52:28 --> Form Validation Class Initialized
INFO - 2020-03-09 13:52:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 13:52:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 13:52:28 --> Final output sent to browser
DEBUG - 2020-03-09 13:52:28 --> Total execution time: 0.0861
INFO - 2020-03-09 13:52:43 --> Config Class Initialized
INFO - 2020-03-09 13:52:43 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:52:43 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:52:43 --> Utf8 Class Initialized
INFO - 2020-03-09 13:52:43 --> URI Class Initialized
INFO - 2020-03-09 13:52:43 --> Router Class Initialized
INFO - 2020-03-09 13:52:43 --> Output Class Initialized
INFO - 2020-03-09 13:52:43 --> Security Class Initialized
DEBUG - 2020-03-09 13:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:52:43 --> Input Class Initialized
INFO - 2020-03-09 13:52:43 --> Language Class Initialized
INFO - 2020-03-09 13:52:43 --> Loader Class Initialized
INFO - 2020-03-09 13:52:43 --> Helper loaded: url_helper
INFO - 2020-03-09 13:52:43 --> Helper loaded: string_helper
INFO - 2020-03-09 13:52:43 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:52:43 --> Controller Class Initialized
INFO - 2020-03-09 13:52:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 13:52:43 --> Pagination Class Initialized
INFO - 2020-03-09 13:52:43 --> Model "M_show" initialized
INFO - 2020-03-09 13:52:43 --> Helper loaded: form_helper
INFO - 2020-03-09 13:52:43 --> Form Validation Class Initialized
INFO - 2020-03-09 13:52:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 13:52:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 13:52:43 --> Final output sent to browser
DEBUG - 2020-03-09 13:52:43 --> Total execution time: 0.0112
INFO - 2020-03-09 13:53:34 --> Config Class Initialized
INFO - 2020-03-09 13:53:34 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:53:34 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:53:34 --> Utf8 Class Initialized
INFO - 2020-03-09 13:53:34 --> URI Class Initialized
INFO - 2020-03-09 13:53:34 --> Router Class Initialized
INFO - 2020-03-09 13:53:34 --> Output Class Initialized
INFO - 2020-03-09 13:53:34 --> Security Class Initialized
DEBUG - 2020-03-09 13:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:53:34 --> Input Class Initialized
INFO - 2020-03-09 13:53:34 --> Language Class Initialized
INFO - 2020-03-09 13:53:34 --> Loader Class Initialized
INFO - 2020-03-09 13:53:34 --> Helper loaded: url_helper
INFO - 2020-03-09 13:53:34 --> Helper loaded: string_helper
INFO - 2020-03-09 13:53:34 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:53:34 --> Controller Class Initialized
INFO - 2020-03-09 13:53:34 --> Model "M_tiket" initialized
INFO - 2020-03-09 13:53:34 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 13:53:34 --> Model "M_pesan" initialized
INFO - 2020-03-09 13:53:34 --> Helper loaded: form_helper
INFO - 2020-03-09 13:53:34 --> Form Validation Class Initialized
INFO - 2020-03-09 13:53:34 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-09 13:53:34 --> Final output sent to browser
DEBUG - 2020-03-09 13:53:34 --> Total execution time: 0.0444
INFO - 2020-03-09 13:53:34 --> Config Class Initialized
INFO - 2020-03-09 13:53:34 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:53:34 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:53:34 --> Utf8 Class Initialized
INFO - 2020-03-09 13:53:34 --> URI Class Initialized
INFO - 2020-03-09 13:53:34 --> Router Class Initialized
INFO - 2020-03-09 13:53:34 --> Output Class Initialized
INFO - 2020-03-09 13:53:34 --> Security Class Initialized
DEBUG - 2020-03-09 13:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:53:34 --> Input Class Initialized
INFO - 2020-03-09 13:53:34 --> Language Class Initialized
INFO - 2020-03-09 13:53:34 --> Loader Class Initialized
INFO - 2020-03-09 13:53:34 --> Helper loaded: url_helper
INFO - 2020-03-09 13:53:34 --> Helper loaded: string_helper
INFO - 2020-03-09 13:53:34 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:53:34 --> Controller Class Initialized
INFO - 2020-03-09 13:53:34 --> Model "M_tiket" initialized
INFO - 2020-03-09 13:53:34 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 13:53:34 --> Model "M_pesan" initialized
INFO - 2020-03-09 13:53:34 --> Helper loaded: form_helper
INFO - 2020-03-09 13:53:34 --> Form Validation Class Initialized
INFO - 2020-03-09 13:53:34 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-09 13:53:34 --> Final output sent to browser
DEBUG - 2020-03-09 13:53:34 --> Total execution time: 0.0089
INFO - 2020-03-09 13:53:49 --> Config Class Initialized
INFO - 2020-03-09 13:53:49 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:53:49 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:53:49 --> Utf8 Class Initialized
INFO - 2020-03-09 13:53:49 --> URI Class Initialized
INFO - 2020-03-09 13:53:49 --> Router Class Initialized
INFO - 2020-03-09 13:53:49 --> Output Class Initialized
INFO - 2020-03-09 13:53:49 --> Security Class Initialized
DEBUG - 2020-03-09 13:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:53:49 --> Input Class Initialized
INFO - 2020-03-09 13:53:49 --> Language Class Initialized
INFO - 2020-03-09 13:53:49 --> Loader Class Initialized
INFO - 2020-03-09 13:53:49 --> Helper loaded: url_helper
INFO - 2020-03-09 13:53:49 --> Helper loaded: string_helper
INFO - 2020-03-09 13:53:49 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:53:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:53:49 --> Controller Class Initialized
INFO - 2020-03-09 13:53:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 13:53:49 --> Pagination Class Initialized
INFO - 2020-03-09 13:53:49 --> Model "M_show" initialized
INFO - 2020-03-09 13:53:49 --> Helper loaded: form_helper
INFO - 2020-03-09 13:53:49 --> Form Validation Class Initialized
INFO - 2020-03-09 13:53:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 13:53:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 13:53:49 --> Final output sent to browser
DEBUG - 2020-03-09 13:53:49 --> Total execution time: 0.0092
INFO - 2020-03-09 13:53:50 --> Config Class Initialized
INFO - 2020-03-09 13:53:50 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:53:50 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:53:50 --> Utf8 Class Initialized
INFO - 2020-03-09 13:53:50 --> URI Class Initialized
INFO - 2020-03-09 13:53:50 --> Router Class Initialized
INFO - 2020-03-09 13:53:50 --> Output Class Initialized
INFO - 2020-03-09 13:53:50 --> Security Class Initialized
DEBUG - 2020-03-09 13:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:53:50 --> Input Class Initialized
INFO - 2020-03-09 13:53:50 --> Language Class Initialized
ERROR - 2020-03-09 13:53:50 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-09 13:55:02 --> Config Class Initialized
INFO - 2020-03-09 13:55:02 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:55:02 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:55:02 --> Utf8 Class Initialized
INFO - 2020-03-09 13:55:02 --> URI Class Initialized
DEBUG - 2020-03-09 13:55:02 --> No URI present. Default controller set.
INFO - 2020-03-09 13:55:02 --> Router Class Initialized
INFO - 2020-03-09 13:55:02 --> Output Class Initialized
INFO - 2020-03-09 13:55:02 --> Security Class Initialized
DEBUG - 2020-03-09 13:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:55:02 --> Input Class Initialized
INFO - 2020-03-09 13:55:02 --> Language Class Initialized
INFO - 2020-03-09 13:55:02 --> Loader Class Initialized
INFO - 2020-03-09 13:55:02 --> Helper loaded: url_helper
INFO - 2020-03-09 13:55:02 --> Helper loaded: string_helper
INFO - 2020-03-09 13:55:02 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:55:02 --> Controller Class Initialized
INFO - 2020-03-09 13:55:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 13:55:02 --> Pagination Class Initialized
INFO - 2020-03-09 13:55:02 --> Model "M_show" initialized
INFO - 2020-03-09 13:55:02 --> Helper loaded: form_helper
INFO - 2020-03-09 13:55:02 --> Form Validation Class Initialized
INFO - 2020-03-09 13:55:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 13:55:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 13:55:02 --> Final output sent to browser
DEBUG - 2020-03-09 13:55:02 --> Total execution time: 0.0891
INFO - 2020-03-09 13:56:52 --> Config Class Initialized
INFO - 2020-03-09 13:56:52 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:56:52 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:56:52 --> Utf8 Class Initialized
INFO - 2020-03-09 13:56:52 --> URI Class Initialized
INFO - 2020-03-09 13:56:52 --> Router Class Initialized
INFO - 2020-03-09 13:56:52 --> Output Class Initialized
INFO - 2020-03-09 13:56:52 --> Security Class Initialized
DEBUG - 2020-03-09 13:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:56:52 --> Input Class Initialized
INFO - 2020-03-09 13:56:52 --> Language Class Initialized
INFO - 2020-03-09 13:56:52 --> Loader Class Initialized
INFO - 2020-03-09 13:56:52 --> Helper loaded: url_helper
INFO - 2020-03-09 13:56:52 --> Helper loaded: string_helper
INFO - 2020-03-09 13:56:52 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:56:52 --> Controller Class Initialized
INFO - 2020-03-09 13:56:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 13:56:52 --> Pagination Class Initialized
INFO - 2020-03-09 13:56:52 --> Model "M_show" initialized
INFO - 2020-03-09 13:56:52 --> Helper loaded: form_helper
INFO - 2020-03-09 13:56:52 --> Form Validation Class Initialized
INFO - 2020-03-09 13:56:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 13:56:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 13:56:52 --> Final output sent to browser
DEBUG - 2020-03-09 13:56:52 --> Total execution time: 0.0579
INFO - 2020-03-09 13:56:58 --> Config Class Initialized
INFO - 2020-03-09 13:56:58 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:56:58 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:56:58 --> Utf8 Class Initialized
INFO - 2020-03-09 13:56:58 --> URI Class Initialized
INFO - 2020-03-09 13:56:58 --> Router Class Initialized
INFO - 2020-03-09 13:56:58 --> Output Class Initialized
INFO - 2020-03-09 13:56:58 --> Security Class Initialized
DEBUG - 2020-03-09 13:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:56:58 --> Input Class Initialized
INFO - 2020-03-09 13:56:58 --> Language Class Initialized
INFO - 2020-03-09 13:56:58 --> Loader Class Initialized
INFO - 2020-03-09 13:56:58 --> Helper loaded: url_helper
INFO - 2020-03-09 13:56:58 --> Helper loaded: string_helper
INFO - 2020-03-09 13:56:58 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:56:58 --> Controller Class Initialized
INFO - 2020-03-09 13:56:58 --> Model "M_tiket" initialized
INFO - 2020-03-09 13:56:58 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 13:56:58 --> Model "M_pesan" initialized
INFO - 2020-03-09 13:56:58 --> Helper loaded: form_helper
INFO - 2020-03-09 13:56:58 --> Form Validation Class Initialized
INFO - 2020-03-09 13:56:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-09 13:56:58 --> Final output sent to browser
DEBUG - 2020-03-09 13:56:58 --> Total execution time: 0.0122
INFO - 2020-03-09 13:57:17 --> Config Class Initialized
INFO - 2020-03-09 13:57:17 --> Hooks Class Initialized
DEBUG - 2020-03-09 13:57:17 --> UTF-8 Support Enabled
INFO - 2020-03-09 13:57:17 --> Utf8 Class Initialized
INFO - 2020-03-09 13:57:17 --> URI Class Initialized
INFO - 2020-03-09 13:57:17 --> Router Class Initialized
INFO - 2020-03-09 13:57:17 --> Output Class Initialized
INFO - 2020-03-09 13:57:17 --> Security Class Initialized
DEBUG - 2020-03-09 13:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 13:57:17 --> Input Class Initialized
INFO - 2020-03-09 13:57:17 --> Language Class Initialized
INFO - 2020-03-09 13:57:17 --> Loader Class Initialized
INFO - 2020-03-09 13:57:17 --> Helper loaded: url_helper
INFO - 2020-03-09 13:57:17 --> Helper loaded: string_helper
INFO - 2020-03-09 13:57:17 --> Database Driver Class Initialized
DEBUG - 2020-03-09 13:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 13:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 13:57:17 --> Controller Class Initialized
INFO - 2020-03-09 13:57:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 13:57:17 --> Pagination Class Initialized
INFO - 2020-03-09 13:57:17 --> Model "M_show" initialized
INFO - 2020-03-09 13:57:17 --> Helper loaded: form_helper
INFO - 2020-03-09 13:57:17 --> Form Validation Class Initialized
INFO - 2020-03-09 13:57:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 13:57:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/hub.php
INFO - 2020-03-09 13:57:17 --> Final output sent to browser
DEBUG - 2020-03-09 13:57:17 --> Total execution time: 0.0294
INFO - 2020-03-09 14:02:50 --> Config Class Initialized
INFO - 2020-03-09 14:02:50 --> Hooks Class Initialized
DEBUG - 2020-03-09 14:02:50 --> UTF-8 Support Enabled
INFO - 2020-03-09 14:02:50 --> Utf8 Class Initialized
INFO - 2020-03-09 14:02:50 --> URI Class Initialized
DEBUG - 2020-03-09 14:02:50 --> No URI present. Default controller set.
INFO - 2020-03-09 14:02:50 --> Router Class Initialized
INFO - 2020-03-09 14:02:50 --> Output Class Initialized
INFO - 2020-03-09 14:02:50 --> Security Class Initialized
DEBUG - 2020-03-09 14:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 14:02:50 --> Input Class Initialized
INFO - 2020-03-09 14:02:50 --> Language Class Initialized
INFO - 2020-03-09 14:02:50 --> Loader Class Initialized
INFO - 2020-03-09 14:02:50 --> Helper loaded: url_helper
INFO - 2020-03-09 14:02:50 --> Helper loaded: string_helper
INFO - 2020-03-09 14:02:50 --> Database Driver Class Initialized
DEBUG - 2020-03-09 14:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 14:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 14:02:50 --> Controller Class Initialized
INFO - 2020-03-09 14:02:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 14:02:50 --> Pagination Class Initialized
INFO - 2020-03-09 14:02:50 --> Model "M_show" initialized
INFO - 2020-03-09 14:02:50 --> Helper loaded: form_helper
INFO - 2020-03-09 14:02:50 --> Form Validation Class Initialized
INFO - 2020-03-09 14:02:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 14:02:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 14:02:50 --> Final output sent to browser
DEBUG - 2020-03-09 14:02:50 --> Total execution time: 0.0625
INFO - 2020-03-09 14:03:00 --> Config Class Initialized
INFO - 2020-03-09 14:03:00 --> Hooks Class Initialized
DEBUG - 2020-03-09 14:03:00 --> UTF-8 Support Enabled
INFO - 2020-03-09 14:03:00 --> Utf8 Class Initialized
INFO - 2020-03-09 14:03:00 --> URI Class Initialized
INFO - 2020-03-09 14:03:00 --> Router Class Initialized
INFO - 2020-03-09 14:03:00 --> Output Class Initialized
INFO - 2020-03-09 14:03:00 --> Security Class Initialized
DEBUG - 2020-03-09 14:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 14:03:00 --> Input Class Initialized
INFO - 2020-03-09 14:03:00 --> Language Class Initialized
INFO - 2020-03-09 14:03:00 --> Loader Class Initialized
INFO - 2020-03-09 14:03:00 --> Helper loaded: url_helper
INFO - 2020-03-09 14:03:00 --> Helper loaded: string_helper
INFO - 2020-03-09 14:03:00 --> Database Driver Class Initialized
DEBUG - 2020-03-09 14:03:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 14:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 14:03:00 --> Controller Class Initialized
INFO - 2020-03-09 14:03:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 14:03:00 --> Pagination Class Initialized
INFO - 2020-03-09 14:03:00 --> Model "M_show" initialized
INFO - 2020-03-09 14:03:00 --> Helper loaded: form_helper
INFO - 2020-03-09 14:03:00 --> Form Validation Class Initialized
INFO - 2020-03-09 14:03:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 14:03:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 14:03:00 --> Final output sent to browser
DEBUG - 2020-03-09 14:03:00 --> Total execution time: 0.0091
INFO - 2020-03-09 14:03:00 --> Config Class Initialized
INFO - 2020-03-09 14:03:00 --> Hooks Class Initialized
DEBUG - 2020-03-09 14:03:00 --> UTF-8 Support Enabled
INFO - 2020-03-09 14:03:00 --> Utf8 Class Initialized
INFO - 2020-03-09 14:03:00 --> URI Class Initialized
INFO - 2020-03-09 14:03:00 --> Router Class Initialized
INFO - 2020-03-09 14:03:00 --> Output Class Initialized
INFO - 2020-03-09 14:03:00 --> Security Class Initialized
DEBUG - 2020-03-09 14:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 14:03:00 --> Input Class Initialized
INFO - 2020-03-09 14:03:00 --> Language Class Initialized
ERROR - 2020-03-09 14:03:00 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-09 14:03:04 --> Config Class Initialized
INFO - 2020-03-09 14:03:04 --> Hooks Class Initialized
DEBUG - 2020-03-09 14:03:04 --> UTF-8 Support Enabled
INFO - 2020-03-09 14:03:04 --> Utf8 Class Initialized
INFO - 2020-03-09 14:03:04 --> URI Class Initialized
INFO - 2020-03-09 14:03:04 --> Router Class Initialized
INFO - 2020-03-09 14:03:04 --> Output Class Initialized
INFO - 2020-03-09 14:03:04 --> Security Class Initialized
DEBUG - 2020-03-09 14:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 14:03:04 --> Input Class Initialized
INFO - 2020-03-09 14:03:04 --> Language Class Initialized
INFO - 2020-03-09 14:03:04 --> Loader Class Initialized
INFO - 2020-03-09 14:03:04 --> Helper loaded: url_helper
INFO - 2020-03-09 14:03:04 --> Helper loaded: string_helper
INFO - 2020-03-09 14:03:04 --> Database Driver Class Initialized
DEBUG - 2020-03-09 14:03:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 14:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 14:03:04 --> Controller Class Initialized
INFO - 2020-03-09 14:03:04 --> Model "M_tiket" initialized
INFO - 2020-03-09 14:03:04 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 14:03:04 --> Model "M_pesan" initialized
INFO - 2020-03-09 14:03:04 --> Helper loaded: form_helper
INFO - 2020-03-09 14:03:04 --> Form Validation Class Initialized
INFO - 2020-03-09 14:03:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-09 14:03:04 --> Final output sent to browser
DEBUG - 2020-03-09 14:03:04 --> Total execution time: 0.1537
INFO - 2020-03-09 14:03:20 --> Config Class Initialized
INFO - 2020-03-09 14:03:20 --> Hooks Class Initialized
DEBUG - 2020-03-09 14:03:20 --> UTF-8 Support Enabled
INFO - 2020-03-09 14:03:20 --> Utf8 Class Initialized
INFO - 2020-03-09 14:03:20 --> URI Class Initialized
INFO - 2020-03-09 14:03:20 --> Router Class Initialized
INFO - 2020-03-09 14:03:20 --> Output Class Initialized
INFO - 2020-03-09 14:03:20 --> Security Class Initialized
DEBUG - 2020-03-09 14:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 14:03:20 --> Input Class Initialized
INFO - 2020-03-09 14:03:20 --> Language Class Initialized
INFO - 2020-03-09 14:03:20 --> Loader Class Initialized
INFO - 2020-03-09 14:03:20 --> Helper loaded: url_helper
INFO - 2020-03-09 14:03:20 --> Helper loaded: string_helper
INFO - 2020-03-09 14:03:20 --> Database Driver Class Initialized
DEBUG - 2020-03-09 14:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 14:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 14:03:20 --> Controller Class Initialized
INFO - 2020-03-09 14:03:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 14:03:20 --> Pagination Class Initialized
INFO - 2020-03-09 14:03:20 --> Model "M_show" initialized
INFO - 2020-03-09 14:03:20 --> Helper loaded: form_helper
INFO - 2020-03-09 14:03:20 --> Form Validation Class Initialized
INFO - 2020-03-09 14:03:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 14:03:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 14:03:20 --> Final output sent to browser
DEBUG - 2020-03-09 14:03:20 --> Total execution time: 0.0073
INFO - 2020-03-09 14:03:23 --> Config Class Initialized
INFO - 2020-03-09 14:03:23 --> Hooks Class Initialized
DEBUG - 2020-03-09 14:03:23 --> UTF-8 Support Enabled
INFO - 2020-03-09 14:03:23 --> Utf8 Class Initialized
INFO - 2020-03-09 14:03:23 --> URI Class Initialized
DEBUG - 2020-03-09 14:03:23 --> No URI present. Default controller set.
INFO - 2020-03-09 14:03:23 --> Router Class Initialized
INFO - 2020-03-09 14:03:23 --> Output Class Initialized
INFO - 2020-03-09 14:03:23 --> Security Class Initialized
DEBUG - 2020-03-09 14:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 14:03:23 --> Input Class Initialized
INFO - 2020-03-09 14:03:23 --> Language Class Initialized
INFO - 2020-03-09 14:03:23 --> Loader Class Initialized
INFO - 2020-03-09 14:03:23 --> Helper loaded: url_helper
INFO - 2020-03-09 14:03:23 --> Helper loaded: string_helper
INFO - 2020-03-09 14:03:23 --> Database Driver Class Initialized
DEBUG - 2020-03-09 14:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 14:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 14:03:23 --> Controller Class Initialized
INFO - 2020-03-09 14:03:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 14:03:23 --> Pagination Class Initialized
INFO - 2020-03-09 14:03:23 --> Model "M_show" initialized
INFO - 2020-03-09 14:03:23 --> Helper loaded: form_helper
INFO - 2020-03-09 14:03:23 --> Form Validation Class Initialized
INFO - 2020-03-09 14:03:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 14:03:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 14:03:23 --> Final output sent to browser
DEBUG - 2020-03-09 14:03:23 --> Total execution time: 0.0077
INFO - 2020-03-09 14:07:39 --> Config Class Initialized
INFO - 2020-03-09 14:07:39 --> Hooks Class Initialized
DEBUG - 2020-03-09 14:07:39 --> UTF-8 Support Enabled
INFO - 2020-03-09 14:07:39 --> Utf8 Class Initialized
INFO - 2020-03-09 14:07:39 --> URI Class Initialized
INFO - 2020-03-09 14:07:39 --> Router Class Initialized
INFO - 2020-03-09 14:07:39 --> Output Class Initialized
INFO - 2020-03-09 14:07:39 --> Security Class Initialized
DEBUG - 2020-03-09 14:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 14:07:39 --> Input Class Initialized
INFO - 2020-03-09 14:07:39 --> Language Class Initialized
INFO - 2020-03-09 14:07:39 --> Loader Class Initialized
INFO - 2020-03-09 14:07:39 --> Helper loaded: url_helper
INFO - 2020-03-09 14:07:39 --> Helper loaded: string_helper
INFO - 2020-03-09 14:07:39 --> Database Driver Class Initialized
DEBUG - 2020-03-09 14:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 14:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 14:07:39 --> Controller Class Initialized
INFO - 2020-03-09 14:07:39 --> Model "M_tiket" initialized
INFO - 2020-03-09 14:07:39 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 14:07:39 --> Model "M_pesan" initialized
INFO - 2020-03-09 14:07:39 --> Helper loaded: form_helper
INFO - 2020-03-09 14:07:39 --> Form Validation Class Initialized
INFO - 2020-03-09 14:07:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-09 14:07:39 --> Final output sent to browser
DEBUG - 2020-03-09 14:07:39 --> Total execution time: 0.0642
INFO - 2020-03-09 14:28:10 --> Config Class Initialized
INFO - 2020-03-09 14:28:10 --> Hooks Class Initialized
DEBUG - 2020-03-09 14:28:10 --> UTF-8 Support Enabled
INFO - 2020-03-09 14:28:10 --> Utf8 Class Initialized
INFO - 2020-03-09 14:28:10 --> URI Class Initialized
DEBUG - 2020-03-09 14:28:10 --> No URI present. Default controller set.
INFO - 2020-03-09 14:28:10 --> Router Class Initialized
INFO - 2020-03-09 14:28:10 --> Output Class Initialized
INFO - 2020-03-09 14:28:10 --> Security Class Initialized
DEBUG - 2020-03-09 14:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 14:28:10 --> Input Class Initialized
INFO - 2020-03-09 14:28:10 --> Language Class Initialized
INFO - 2020-03-09 14:28:10 --> Loader Class Initialized
INFO - 2020-03-09 14:28:10 --> Helper loaded: url_helper
INFO - 2020-03-09 14:28:10 --> Helper loaded: string_helper
INFO - 2020-03-09 14:28:10 --> Database Driver Class Initialized
DEBUG - 2020-03-09 14:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 14:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 14:28:10 --> Controller Class Initialized
INFO - 2020-03-09 14:28:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 14:28:10 --> Pagination Class Initialized
INFO - 2020-03-09 14:28:10 --> Model "M_show" initialized
INFO - 2020-03-09 14:28:10 --> Helper loaded: form_helper
INFO - 2020-03-09 14:28:10 --> Form Validation Class Initialized
INFO - 2020-03-09 14:28:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 14:28:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 14:28:10 --> Final output sent to browser
DEBUG - 2020-03-09 14:28:10 --> Total execution time: 0.0570
INFO - 2020-03-09 14:30:11 --> Config Class Initialized
INFO - 2020-03-09 14:30:11 --> Hooks Class Initialized
DEBUG - 2020-03-09 14:30:11 --> UTF-8 Support Enabled
INFO - 2020-03-09 14:30:11 --> Utf8 Class Initialized
INFO - 2020-03-09 14:30:11 --> URI Class Initialized
DEBUG - 2020-03-09 14:30:11 --> No URI present. Default controller set.
INFO - 2020-03-09 14:30:11 --> Router Class Initialized
INFO - 2020-03-09 14:30:11 --> Output Class Initialized
INFO - 2020-03-09 14:30:11 --> Security Class Initialized
DEBUG - 2020-03-09 14:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 14:30:11 --> Input Class Initialized
INFO - 2020-03-09 14:30:11 --> Language Class Initialized
INFO - 2020-03-09 14:30:11 --> Loader Class Initialized
INFO - 2020-03-09 14:30:11 --> Helper loaded: url_helper
INFO - 2020-03-09 14:30:11 --> Helper loaded: string_helper
INFO - 2020-03-09 14:30:11 --> Database Driver Class Initialized
DEBUG - 2020-03-09 14:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 14:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 14:30:11 --> Controller Class Initialized
INFO - 2020-03-09 14:30:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 14:30:11 --> Pagination Class Initialized
INFO - 2020-03-09 14:30:11 --> Model "M_show" initialized
INFO - 2020-03-09 14:30:11 --> Helper loaded: form_helper
INFO - 2020-03-09 14:30:11 --> Form Validation Class Initialized
INFO - 2020-03-09 14:30:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 14:30:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 14:30:11 --> Final output sent to browser
DEBUG - 2020-03-09 14:30:11 --> Total execution time: 0.0581
INFO - 2020-03-09 14:33:58 --> Config Class Initialized
INFO - 2020-03-09 14:33:58 --> Hooks Class Initialized
DEBUG - 2020-03-09 14:33:58 --> UTF-8 Support Enabled
INFO - 2020-03-09 14:33:58 --> Utf8 Class Initialized
INFO - 2020-03-09 14:33:58 --> URI Class Initialized
INFO - 2020-03-09 14:33:58 --> Router Class Initialized
INFO - 2020-03-09 14:33:58 --> Output Class Initialized
INFO - 2020-03-09 14:33:58 --> Security Class Initialized
DEBUG - 2020-03-09 14:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 14:33:58 --> Input Class Initialized
INFO - 2020-03-09 14:33:58 --> Language Class Initialized
INFO - 2020-03-09 14:33:58 --> Loader Class Initialized
INFO - 2020-03-09 14:33:58 --> Helper loaded: url_helper
INFO - 2020-03-09 14:33:58 --> Helper loaded: string_helper
INFO - 2020-03-09 14:33:58 --> Database Driver Class Initialized
DEBUG - 2020-03-09 14:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 14:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 14:33:58 --> Controller Class Initialized
INFO - 2020-03-09 14:33:58 --> Model "M_tiket" initialized
INFO - 2020-03-09 14:33:58 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 14:33:58 --> Model "M_pesan" initialized
INFO - 2020-03-09 14:33:58 --> Helper loaded: form_helper
INFO - 2020-03-09 14:33:58 --> Form Validation Class Initialized
INFO - 2020-03-09 14:36:30 --> Config Class Initialized
INFO - 2020-03-09 14:36:30 --> Hooks Class Initialized
DEBUG - 2020-03-09 14:36:30 --> UTF-8 Support Enabled
INFO - 2020-03-09 14:36:30 --> Utf8 Class Initialized
INFO - 2020-03-09 14:36:30 --> URI Class Initialized
INFO - 2020-03-09 14:36:30 --> Router Class Initialized
INFO - 2020-03-09 14:36:30 --> Output Class Initialized
INFO - 2020-03-09 14:36:30 --> Security Class Initialized
DEBUG - 2020-03-09 14:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 14:36:30 --> Input Class Initialized
INFO - 2020-03-09 14:36:30 --> Language Class Initialized
INFO - 2020-03-09 14:36:30 --> Loader Class Initialized
INFO - 2020-03-09 14:36:30 --> Helper loaded: url_helper
INFO - 2020-03-09 14:36:30 --> Helper loaded: string_helper
INFO - 2020-03-09 14:36:30 --> Database Driver Class Initialized
DEBUG - 2020-03-09 14:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 14:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 14:36:30 --> Controller Class Initialized
INFO - 2020-03-09 14:36:30 --> Model "M_tiket" initialized
INFO - 2020-03-09 14:36:30 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 14:36:30 --> Model "M_pesan" initialized
INFO - 2020-03-09 14:36:30 --> Helper loaded: form_helper
INFO - 2020-03-09 14:36:30 --> Form Validation Class Initialized
INFO - 2020-03-09 14:36:42 --> Config Class Initialized
INFO - 2020-03-09 14:36:42 --> Hooks Class Initialized
DEBUG - 2020-03-09 14:36:42 --> UTF-8 Support Enabled
INFO - 2020-03-09 14:36:42 --> Utf8 Class Initialized
INFO - 2020-03-09 14:36:42 --> URI Class Initialized
INFO - 2020-03-09 14:36:42 --> Router Class Initialized
INFO - 2020-03-09 14:36:42 --> Output Class Initialized
INFO - 2020-03-09 14:36:42 --> Security Class Initialized
DEBUG - 2020-03-09 14:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 14:36:42 --> Input Class Initialized
INFO - 2020-03-09 14:36:42 --> Language Class Initialized
INFO - 2020-03-09 14:36:42 --> Loader Class Initialized
INFO - 2020-03-09 14:36:42 --> Helper loaded: url_helper
INFO - 2020-03-09 14:36:42 --> Helper loaded: string_helper
INFO - 2020-03-09 14:36:42 --> Database Driver Class Initialized
DEBUG - 2020-03-09 14:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 14:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 14:36:42 --> Controller Class Initialized
INFO - 2020-03-09 14:36:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 14:36:42 --> Pagination Class Initialized
INFO - 2020-03-09 14:36:42 --> Model "M_show" initialized
INFO - 2020-03-09 14:36:42 --> Helper loaded: form_helper
INFO - 2020-03-09 14:36:42 --> Form Validation Class Initialized
INFO - 2020-03-09 14:36:42 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 14:36:42 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 14:36:42 --> Final output sent to browser
DEBUG - 2020-03-09 14:36:42 --> Total execution time: 0.0115
INFO - 2020-03-09 14:40:36 --> Config Class Initialized
INFO - 2020-03-09 14:40:36 --> Hooks Class Initialized
DEBUG - 2020-03-09 14:40:36 --> UTF-8 Support Enabled
INFO - 2020-03-09 14:40:36 --> Utf8 Class Initialized
INFO - 2020-03-09 14:40:36 --> URI Class Initialized
INFO - 2020-03-09 14:40:36 --> Router Class Initialized
INFO - 2020-03-09 14:40:36 --> Output Class Initialized
INFO - 2020-03-09 14:40:36 --> Security Class Initialized
DEBUG - 2020-03-09 14:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 14:40:36 --> Input Class Initialized
INFO - 2020-03-09 14:40:36 --> Language Class Initialized
INFO - 2020-03-09 14:40:36 --> Loader Class Initialized
INFO - 2020-03-09 14:40:36 --> Helper loaded: url_helper
INFO - 2020-03-09 14:40:36 --> Helper loaded: string_helper
INFO - 2020-03-09 14:40:36 --> Database Driver Class Initialized
DEBUG - 2020-03-09 14:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 14:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 14:40:36 --> Controller Class Initialized
INFO - 2020-03-09 14:40:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 14:40:36 --> Pagination Class Initialized
INFO - 2020-03-09 14:40:36 --> Model "M_show" initialized
INFO - 2020-03-09 14:40:36 --> Helper loaded: form_helper
INFO - 2020-03-09 14:40:36 --> Form Validation Class Initialized
INFO - 2020-03-09 14:40:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 14:40:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-09 14:40:36 --> Final output sent to browser
DEBUG - 2020-03-09 14:40:36 --> Total execution time: 0.0921
INFO - 2020-03-09 14:40:40 --> Config Class Initialized
INFO - 2020-03-09 14:40:40 --> Hooks Class Initialized
DEBUG - 2020-03-09 14:40:40 --> UTF-8 Support Enabled
INFO - 2020-03-09 14:40:40 --> Utf8 Class Initialized
INFO - 2020-03-09 14:40:40 --> URI Class Initialized
INFO - 2020-03-09 14:40:40 --> Router Class Initialized
INFO - 2020-03-09 14:40:40 --> Output Class Initialized
INFO - 2020-03-09 14:40:40 --> Security Class Initialized
DEBUG - 2020-03-09 14:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 14:40:40 --> Input Class Initialized
INFO - 2020-03-09 14:40:40 --> Language Class Initialized
INFO - 2020-03-09 14:40:40 --> Loader Class Initialized
INFO - 2020-03-09 14:40:40 --> Helper loaded: url_helper
INFO - 2020-03-09 14:40:40 --> Helper loaded: string_helper
INFO - 2020-03-09 14:40:40 --> Database Driver Class Initialized
DEBUG - 2020-03-09 14:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 14:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 14:40:40 --> Controller Class Initialized
INFO - 2020-03-09 14:40:40 --> Model "M_tiket" initialized
INFO - 2020-03-09 14:40:40 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 14:40:40 --> Model "M_pesan" initialized
INFO - 2020-03-09 14:40:40 --> Helper loaded: form_helper
INFO - 2020-03-09 14:40:40 --> Form Validation Class Initialized
INFO - 2020-03-09 14:40:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-09 14:40:40 --> Final output sent to browser
DEBUG - 2020-03-09 14:40:40 --> Total execution time: 0.1997
INFO - 2020-03-09 14:40:49 --> Config Class Initialized
INFO - 2020-03-09 14:40:49 --> Hooks Class Initialized
DEBUG - 2020-03-09 14:40:49 --> UTF-8 Support Enabled
INFO - 2020-03-09 14:40:49 --> Utf8 Class Initialized
INFO - 2020-03-09 14:40:49 --> URI Class Initialized
INFO - 2020-03-09 14:40:49 --> Router Class Initialized
INFO - 2020-03-09 14:40:49 --> Output Class Initialized
INFO - 2020-03-09 14:40:49 --> Security Class Initialized
DEBUG - 2020-03-09 14:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 14:40:49 --> Input Class Initialized
INFO - 2020-03-09 14:40:49 --> Language Class Initialized
INFO - 2020-03-09 14:40:49 --> Loader Class Initialized
INFO - 2020-03-09 14:40:49 --> Helper loaded: url_helper
INFO - 2020-03-09 14:40:49 --> Helper loaded: string_helper
INFO - 2020-03-09 14:40:49 --> Database Driver Class Initialized
DEBUG - 2020-03-09 14:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 14:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 14:40:49 --> Controller Class Initialized
INFO - 2020-03-09 14:40:49 --> Model "M_tiket" initialized
INFO - 2020-03-09 14:40:49 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 14:40:49 --> Model "M_pesan" initialized
INFO - 2020-03-09 14:40:49 --> Helper loaded: form_helper
INFO - 2020-03-09 14:40:49 --> Form Validation Class Initialized
INFO - 2020-03-09 14:40:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-09 14:40:49 --> Final output sent to browser
DEBUG - 2020-03-09 14:40:49 --> Total execution time: 0.0394
INFO - 2020-03-09 14:41:26 --> Config Class Initialized
INFO - 2020-03-09 14:41:26 --> Hooks Class Initialized
DEBUG - 2020-03-09 14:41:26 --> UTF-8 Support Enabled
INFO - 2020-03-09 14:41:26 --> Utf8 Class Initialized
INFO - 2020-03-09 14:41:26 --> URI Class Initialized
INFO - 2020-03-09 14:41:26 --> Router Class Initialized
INFO - 2020-03-09 14:41:26 --> Output Class Initialized
INFO - 2020-03-09 14:41:26 --> Security Class Initialized
DEBUG - 2020-03-09 14:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 14:41:26 --> Input Class Initialized
INFO - 2020-03-09 14:41:26 --> Language Class Initialized
INFO - 2020-03-09 14:41:26 --> Loader Class Initialized
INFO - 2020-03-09 14:41:26 --> Helper loaded: url_helper
INFO - 2020-03-09 14:41:26 --> Helper loaded: string_helper
INFO - 2020-03-09 14:41:26 --> Database Driver Class Initialized
DEBUG - 2020-03-09 14:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 14:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 14:41:26 --> Controller Class Initialized
INFO - 2020-03-09 14:41:26 --> Model "M_tiket" initialized
INFO - 2020-03-09 14:41:26 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 14:41:26 --> Model "M_pesan" initialized
INFO - 2020-03-09 14:41:26 --> Helper loaded: form_helper
INFO - 2020-03-09 14:41:26 --> Form Validation Class Initialized
DEBUG - 2020-03-09 14:41:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-09 14:41:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-09 21:41:26 --> Final output sent to browser
DEBUG - 2020-03-09 21:41:26 --> Total execution time: 0.1647
INFO - 2020-03-09 14:41:28 --> Config Class Initialized
INFO - 2020-03-09 14:41:28 --> Hooks Class Initialized
DEBUG - 2020-03-09 14:41:28 --> UTF-8 Support Enabled
INFO - 2020-03-09 14:41:28 --> Utf8 Class Initialized
INFO - 2020-03-09 14:41:28 --> URI Class Initialized
INFO - 2020-03-09 14:41:28 --> Router Class Initialized
INFO - 2020-03-09 14:41:28 --> Output Class Initialized
INFO - 2020-03-09 14:41:28 --> Security Class Initialized
DEBUG - 2020-03-09 14:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 14:41:28 --> Input Class Initialized
INFO - 2020-03-09 14:41:28 --> Language Class Initialized
INFO - 2020-03-09 14:41:28 --> Loader Class Initialized
INFO - 2020-03-09 14:41:28 --> Helper loaded: url_helper
INFO - 2020-03-09 14:41:28 --> Helper loaded: string_helper
INFO - 2020-03-09 14:41:28 --> Database Driver Class Initialized
DEBUG - 2020-03-09 14:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 14:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 14:41:28 --> Controller Class Initialized
INFO - 2020-03-09 14:41:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 14:41:28 --> Pagination Class Initialized
INFO - 2020-03-09 14:41:28 --> Model "M_show" initialized
INFO - 2020-03-09 14:41:28 --> Helper loaded: form_helper
INFO - 2020-03-09 14:41:28 --> Form Validation Class Initialized
INFO - 2020-03-09 14:41:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 14:41:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 14:41:28 --> Final output sent to browser
DEBUG - 2020-03-09 14:41:28 --> Total execution time: 0.0091
INFO - 2020-03-09 14:42:07 --> Config Class Initialized
INFO - 2020-03-09 14:42:07 --> Hooks Class Initialized
DEBUG - 2020-03-09 14:42:07 --> UTF-8 Support Enabled
INFO - 2020-03-09 14:42:07 --> Utf8 Class Initialized
INFO - 2020-03-09 14:42:07 --> URI Class Initialized
INFO - 2020-03-09 14:42:07 --> Router Class Initialized
INFO - 2020-03-09 14:42:07 --> Output Class Initialized
INFO - 2020-03-09 14:42:07 --> Security Class Initialized
DEBUG - 2020-03-09 14:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 14:42:07 --> Input Class Initialized
INFO - 2020-03-09 14:42:07 --> Language Class Initialized
INFO - 2020-03-09 14:42:07 --> Loader Class Initialized
INFO - 2020-03-09 14:42:07 --> Helper loaded: url_helper
INFO - 2020-03-09 14:42:07 --> Helper loaded: string_helper
INFO - 2020-03-09 14:42:07 --> Database Driver Class Initialized
DEBUG - 2020-03-09 14:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 14:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 14:42:07 --> Controller Class Initialized
INFO - 2020-03-09 14:42:07 --> Model "M_tiket" initialized
INFO - 2020-03-09 14:42:07 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 14:42:07 --> Model "M_pesan" initialized
INFO - 2020-03-09 14:42:07 --> Helper loaded: form_helper
INFO - 2020-03-09 14:42:07 --> Form Validation Class Initialized
INFO - 2020-03-09 14:42:09 --> Config Class Initialized
INFO - 2020-03-09 14:42:09 --> Hooks Class Initialized
DEBUG - 2020-03-09 14:42:09 --> UTF-8 Support Enabled
INFO - 2020-03-09 14:42:09 --> Utf8 Class Initialized
INFO - 2020-03-09 14:42:09 --> URI Class Initialized
INFO - 2020-03-09 14:42:09 --> Router Class Initialized
INFO - 2020-03-09 14:42:09 --> Output Class Initialized
INFO - 2020-03-09 14:42:09 --> Security Class Initialized
DEBUG - 2020-03-09 14:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 14:42:09 --> Input Class Initialized
INFO - 2020-03-09 14:42:09 --> Language Class Initialized
ERROR - 2020-03-09 14:42:09 --> 404 Page Not Found: Pemesanan/bukti
INFO - 2020-03-09 14:42:30 --> Config Class Initialized
INFO - 2020-03-09 14:42:30 --> Hooks Class Initialized
DEBUG - 2020-03-09 14:42:30 --> UTF-8 Support Enabled
INFO - 2020-03-09 14:42:30 --> Utf8 Class Initialized
INFO - 2020-03-09 14:42:30 --> URI Class Initialized
INFO - 2020-03-09 14:42:30 --> Router Class Initialized
INFO - 2020-03-09 14:42:30 --> Output Class Initialized
INFO - 2020-03-09 14:42:30 --> Security Class Initialized
DEBUG - 2020-03-09 14:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 14:42:30 --> Input Class Initialized
INFO - 2020-03-09 14:42:30 --> Language Class Initialized
ERROR - 2020-03-09 14:42:30 --> 404 Page Not Found: Pemesanan/bukti
INFO - 2020-03-09 14:43:40 --> Config Class Initialized
INFO - 2020-03-09 14:43:40 --> Hooks Class Initialized
DEBUG - 2020-03-09 14:43:40 --> UTF-8 Support Enabled
INFO - 2020-03-09 14:43:40 --> Utf8 Class Initialized
INFO - 2020-03-09 14:43:40 --> URI Class Initialized
INFO - 2020-03-09 14:43:40 --> Router Class Initialized
INFO - 2020-03-09 14:43:40 --> Output Class Initialized
INFO - 2020-03-09 14:43:40 --> Security Class Initialized
DEBUG - 2020-03-09 14:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 14:43:40 --> Input Class Initialized
INFO - 2020-03-09 14:43:40 --> Language Class Initialized
INFO - 2020-03-09 14:43:40 --> Loader Class Initialized
INFO - 2020-03-09 14:43:40 --> Helper loaded: url_helper
INFO - 2020-03-09 14:43:40 --> Helper loaded: string_helper
INFO - 2020-03-09 14:43:40 --> Database Driver Class Initialized
DEBUG - 2020-03-09 14:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 14:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 14:43:40 --> Controller Class Initialized
INFO - 2020-03-09 14:43:40 --> Model "M_tiket" initialized
INFO - 2020-03-09 14:43:40 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 14:43:40 --> Model "M_pesan" initialized
INFO - 2020-03-09 14:43:40 --> Helper loaded: form_helper
INFO - 2020-03-09 14:43:40 --> Form Validation Class Initialized
INFO - 2020-03-09 14:43:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-09 14:43:40 --> Final output sent to browser
DEBUG - 2020-03-09 14:43:40 --> Total execution time: 0.0101
INFO - 2020-03-09 14:44:28 --> Config Class Initialized
INFO - 2020-03-09 14:44:28 --> Hooks Class Initialized
DEBUG - 2020-03-09 14:44:28 --> UTF-8 Support Enabled
INFO - 2020-03-09 14:44:28 --> Utf8 Class Initialized
INFO - 2020-03-09 14:44:28 --> URI Class Initialized
INFO - 2020-03-09 14:44:28 --> Router Class Initialized
INFO - 2020-03-09 14:44:28 --> Output Class Initialized
INFO - 2020-03-09 14:44:28 --> Security Class Initialized
DEBUG - 2020-03-09 14:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 14:44:28 --> Input Class Initialized
INFO - 2020-03-09 14:44:28 --> Language Class Initialized
INFO - 2020-03-09 14:44:28 --> Loader Class Initialized
INFO - 2020-03-09 14:44:28 --> Helper loaded: url_helper
INFO - 2020-03-09 14:44:28 --> Helper loaded: string_helper
INFO - 2020-03-09 14:44:28 --> Database Driver Class Initialized
DEBUG - 2020-03-09 14:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 14:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 14:44:28 --> Controller Class Initialized
INFO - 2020-03-09 14:44:28 --> Model "M_tiket" initialized
INFO - 2020-03-09 14:44:28 --> Model "M_pengunjung" initialized
INFO - 2020-03-09 14:44:28 --> Model "M_pesan" initialized
INFO - 2020-03-09 14:44:28 --> Helper loaded: form_helper
INFO - 2020-03-09 14:44:28 --> Form Validation Class Initialized
INFO - 2020-03-09 21:44:28 --> Upload Class Initialized
INFO - 2020-03-09 14:44:35 --> Config Class Initialized
INFO - 2020-03-09 14:44:35 --> Hooks Class Initialized
DEBUG - 2020-03-09 14:44:35 --> UTF-8 Support Enabled
INFO - 2020-03-09 14:44:35 --> Utf8 Class Initialized
INFO - 2020-03-09 14:44:35 --> URI Class Initialized
INFO - 2020-03-09 14:44:35 --> Router Class Initialized
INFO - 2020-03-09 14:44:35 --> Output Class Initialized
INFO - 2020-03-09 14:44:35 --> Security Class Initialized
DEBUG - 2020-03-09 14:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 14:44:35 --> Input Class Initialized
INFO - 2020-03-09 14:44:35 --> Language Class Initialized
INFO - 2020-03-09 14:44:35 --> Loader Class Initialized
INFO - 2020-03-09 14:44:35 --> Helper loaded: url_helper
INFO - 2020-03-09 14:44:35 --> Helper loaded: string_helper
INFO - 2020-03-09 14:44:35 --> Database Driver Class Initialized
DEBUG - 2020-03-09 14:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 14:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 14:44:35 --> Controller Class Initialized
INFO - 2020-03-09 14:44:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 14:44:35 --> Pagination Class Initialized
INFO - 2020-03-09 14:44:35 --> Model "M_show" initialized
INFO - 2020-03-09 14:44:35 --> Helper loaded: form_helper
INFO - 2020-03-09 14:44:35 --> Form Validation Class Initialized
INFO - 2020-03-09 14:44:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 14:44:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 14:44:35 --> Final output sent to browser
DEBUG - 2020-03-09 14:44:35 --> Total execution time: 0.0105
INFO - 2020-03-09 14:45:39 --> Config Class Initialized
INFO - 2020-03-09 14:45:39 --> Hooks Class Initialized
DEBUG - 2020-03-09 14:45:39 --> UTF-8 Support Enabled
INFO - 2020-03-09 14:45:39 --> Utf8 Class Initialized
INFO - 2020-03-09 14:45:39 --> URI Class Initialized
DEBUG - 2020-03-09 14:45:39 --> No URI present. Default controller set.
INFO - 2020-03-09 14:45:39 --> Router Class Initialized
INFO - 2020-03-09 14:45:39 --> Output Class Initialized
INFO - 2020-03-09 14:45:39 --> Security Class Initialized
DEBUG - 2020-03-09 14:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-09 14:45:39 --> Input Class Initialized
INFO - 2020-03-09 14:45:39 --> Language Class Initialized
INFO - 2020-03-09 14:45:39 --> Loader Class Initialized
INFO - 2020-03-09 14:45:39 --> Helper loaded: url_helper
INFO - 2020-03-09 14:45:39 --> Helper loaded: string_helper
INFO - 2020-03-09 14:45:39 --> Database Driver Class Initialized
DEBUG - 2020-03-09 14:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-09 14:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-09 14:45:39 --> Controller Class Initialized
INFO - 2020-03-09 14:45:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-09 14:45:39 --> Pagination Class Initialized
INFO - 2020-03-09 14:45:39 --> Model "M_show" initialized
INFO - 2020-03-09 14:45:39 --> Helper loaded: form_helper
INFO - 2020-03-09 14:45:39 --> Form Validation Class Initialized
INFO - 2020-03-09 14:45:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-09 14:45:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-09 14:45:39 --> Final output sent to browser
DEBUG - 2020-03-09 14:45:39 --> Total execution time: 0.1560
