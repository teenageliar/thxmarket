<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-12-31 06:49:44 --> Config Class Initialized
INFO - 2019-12-31 06:49:44 --> Hooks Class Initialized
DEBUG - 2019-12-31 06:49:44 --> UTF-8 Support Enabled
INFO - 2019-12-31 06:49:44 --> Utf8 Class Initialized
INFO - 2019-12-31 06:49:45 --> URI Class Initialized
INFO - 2019-12-31 06:49:45 --> Router Class Initialized
INFO - 2019-12-31 06:49:45 --> Output Class Initialized
INFO - 2019-12-31 06:49:45 --> Security Class Initialized
DEBUG - 2019-12-31 06:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 06:49:45 --> Input Class Initialized
INFO - 2019-12-31 06:49:45 --> Language Class Initialized
INFO - 2019-12-31 06:49:45 --> Loader Class Initialized
INFO - 2019-12-31 06:49:46 --> Helper loaded: url_helper
INFO - 2019-12-31 06:49:46 --> Database Driver Class Initialized
DEBUG - 2019-12-31 06:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 06:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 06:49:47 --> Controller Class Initialized
INFO - 2019-12-31 06:49:47 --> Model "M_login" initialized
INFO - 2019-12-31 06:49:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-31 06:49:47 --> Pagination Class Initialized
INFO - 2019-12-31 06:49:47 --> Model "M_pesan" initialized
INFO - 2019-12-31 06:49:47 --> Helper loaded: form_helper
INFO - 2019-12-31 06:49:47 --> Form Validation Class Initialized
INFO - 2019-12-31 06:49:48 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-31 06:49:48 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/cari_pemesanan.php
INFO - 2019-12-31 06:49:48 --> Final output sent to browser
DEBUG - 2019-12-31 06:49:48 --> Total execution time: 4.2540
INFO - 2019-12-31 12:21:20 --> Config Class Initialized
INFO - 2019-12-31 12:21:20 --> Hooks Class Initialized
DEBUG - 2019-12-31 12:21:20 --> UTF-8 Support Enabled
INFO - 2019-12-31 12:21:20 --> Utf8 Class Initialized
INFO - 2019-12-31 12:21:20 --> URI Class Initialized
DEBUG - 2019-12-31 12:21:20 --> No URI present. Default controller set.
INFO - 2019-12-31 12:21:20 --> Router Class Initialized
INFO - 2019-12-31 12:21:21 --> Output Class Initialized
INFO - 2019-12-31 12:21:21 --> Security Class Initialized
DEBUG - 2019-12-31 12:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 12:21:21 --> Input Class Initialized
INFO - 2019-12-31 12:21:21 --> Language Class Initialized
INFO - 2019-12-31 12:21:21 --> Loader Class Initialized
INFO - 2019-12-31 12:21:21 --> Helper loaded: url_helper
INFO - 2019-12-31 12:21:21 --> Database Driver Class Initialized
DEBUG - 2019-12-31 12:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 12:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 12:21:21 --> Controller Class Initialized
INFO - 2019-12-31 12:21:22 --> Model "M_login" initialized
INFO - 2019-12-31 12:21:22 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/login.php
INFO - 2019-12-31 12:21:22 --> Final output sent to browser
DEBUG - 2019-12-31 12:21:22 --> Total execution time: 2.0605
INFO - 2019-12-31 12:24:16 --> Config Class Initialized
INFO - 2019-12-31 12:24:16 --> Hooks Class Initialized
DEBUG - 2019-12-31 12:24:16 --> UTF-8 Support Enabled
INFO - 2019-12-31 12:24:16 --> Utf8 Class Initialized
INFO - 2019-12-31 12:24:16 --> URI Class Initialized
INFO - 2019-12-31 12:24:16 --> Router Class Initialized
INFO - 2019-12-31 12:24:16 --> Output Class Initialized
INFO - 2019-12-31 12:24:16 --> Security Class Initialized
DEBUG - 2019-12-31 12:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 12:24:16 --> Input Class Initialized
INFO - 2019-12-31 12:24:16 --> Language Class Initialized
INFO - 2019-12-31 12:24:16 --> Loader Class Initialized
INFO - 2019-12-31 12:24:16 --> Helper loaded: url_helper
INFO - 2019-12-31 12:24:16 --> Database Driver Class Initialized
DEBUG - 2019-12-31 12:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 12:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 12:24:16 --> Controller Class Initialized
INFO - 2019-12-31 12:24:16 --> Model "M_login" initialized
INFO - 2019-12-31 12:24:16 --> Config Class Initialized
INFO - 2019-12-31 12:24:16 --> Hooks Class Initialized
DEBUG - 2019-12-31 12:24:16 --> UTF-8 Support Enabled
INFO - 2019-12-31 12:24:16 --> Utf8 Class Initialized
INFO - 2019-12-31 12:24:16 --> URI Class Initialized
INFO - 2019-12-31 12:24:16 --> Router Class Initialized
INFO - 2019-12-31 12:24:16 --> Output Class Initialized
INFO - 2019-12-31 12:24:16 --> Security Class Initialized
DEBUG - 2019-12-31 12:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 12:24:16 --> Input Class Initialized
INFO - 2019-12-31 12:24:16 --> Language Class Initialized
INFO - 2019-12-31 12:24:16 --> Loader Class Initialized
INFO - 2019-12-31 12:24:16 --> Helper loaded: url_helper
INFO - 2019-12-31 12:24:16 --> Database Driver Class Initialized
DEBUG - 2019-12-31 12:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 12:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 12:24:16 --> Controller Class Initialized
INFO - 2019-12-31 12:24:17 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-31 12:24:17 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/beranda.php
INFO - 2019-12-31 12:24:17 --> Final output sent to browser
DEBUG - 2019-12-31 12:24:17 --> Total execution time: 0.6877
INFO - 2019-12-31 12:24:17 --> Config Class Initialized
INFO - 2019-12-31 12:24:17 --> Config Class Initialized
INFO - 2019-12-31 12:24:17 --> Hooks Class Initialized
INFO - 2019-12-31 12:24:17 --> Hooks Class Initialized
DEBUG - 2019-12-31 12:24:17 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 12:24:17 --> UTF-8 Support Enabled
INFO - 2019-12-31 12:24:17 --> Utf8 Class Initialized
INFO - 2019-12-31 12:24:17 --> Utf8 Class Initialized
INFO - 2019-12-31 12:24:17 --> URI Class Initialized
INFO - 2019-12-31 12:24:17 --> URI Class Initialized
INFO - 2019-12-31 12:24:17 --> Router Class Initialized
INFO - 2019-12-31 12:24:17 --> Router Class Initialized
INFO - 2019-12-31 12:24:17 --> Output Class Initialized
INFO - 2019-12-31 12:24:17 --> Output Class Initialized
INFO - 2019-12-31 12:24:17 --> Security Class Initialized
INFO - 2019-12-31 12:24:17 --> Security Class Initialized
DEBUG - 2019-12-31 12:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 12:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 12:24:17 --> Input Class Initialized
INFO - 2019-12-31 12:24:17 --> Input Class Initialized
INFO - 2019-12-31 12:24:17 --> Language Class Initialized
INFO - 2019-12-31 12:24:17 --> Language Class Initialized
ERROR - 2019-12-31 12:24:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-31 12:24:17 --> 404 Page Not Found: Assets/js
INFO - 2019-12-31 12:24:17 --> Config Class Initialized
INFO - 2019-12-31 12:24:17 --> Hooks Class Initialized
DEBUG - 2019-12-31 12:24:17 --> UTF-8 Support Enabled
INFO - 2019-12-31 12:24:17 --> Utf8 Class Initialized
INFO - 2019-12-31 12:24:17 --> URI Class Initialized
INFO - 2019-12-31 12:24:17 --> Router Class Initialized
INFO - 2019-12-31 12:24:17 --> Output Class Initialized
INFO - 2019-12-31 12:24:17 --> Security Class Initialized
DEBUG - 2019-12-31 12:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 12:24:17 --> Input Class Initialized
INFO - 2019-12-31 12:24:17 --> Language Class Initialized
ERROR - 2019-12-31 12:24:17 --> 404 Page Not Found: Assets/js
INFO - 2019-12-31 12:24:18 --> Config Class Initialized
INFO - 2019-12-31 12:24:18 --> Hooks Class Initialized
DEBUG - 2019-12-31 12:24:18 --> UTF-8 Support Enabled
INFO - 2019-12-31 12:24:18 --> Utf8 Class Initialized
INFO - 2019-12-31 12:24:18 --> URI Class Initialized
INFO - 2019-12-31 12:24:18 --> Router Class Initialized
INFO - 2019-12-31 12:24:18 --> Output Class Initialized
INFO - 2019-12-31 12:24:18 --> Security Class Initialized
DEBUG - 2019-12-31 12:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 12:24:18 --> Input Class Initialized
INFO - 2019-12-31 12:24:18 --> Language Class Initialized
ERROR - 2019-12-31 12:24:18 --> 404 Page Not Found: Assets/js
INFO - 2019-12-31 12:24:23 --> Config Class Initialized
INFO - 2019-12-31 12:24:23 --> Hooks Class Initialized
DEBUG - 2019-12-31 12:24:23 --> UTF-8 Support Enabled
INFO - 2019-12-31 12:24:23 --> Utf8 Class Initialized
INFO - 2019-12-31 12:24:23 --> URI Class Initialized
INFO - 2019-12-31 12:24:23 --> Router Class Initialized
INFO - 2019-12-31 12:24:23 --> Output Class Initialized
INFO - 2019-12-31 12:24:23 --> Security Class Initialized
DEBUG - 2019-12-31 12:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 12:24:23 --> Input Class Initialized
INFO - 2019-12-31 12:24:23 --> Language Class Initialized
INFO - 2019-12-31 12:24:23 --> Loader Class Initialized
INFO - 2019-12-31 12:24:23 --> Helper loaded: url_helper
INFO - 2019-12-31 12:24:23 --> Database Driver Class Initialized
DEBUG - 2019-12-31 12:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 12:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 12:24:23 --> Controller Class Initialized
INFO - 2019-12-31 12:24:23 --> Model "M_login" initialized
INFO - 2019-12-31 12:24:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-31 12:24:23 --> Pagination Class Initialized
INFO - 2019-12-31 12:24:23 --> Model "M_pesan" initialized
INFO - 2019-12-31 12:24:23 --> Helper loaded: form_helper
INFO - 2019-12-31 12:24:23 --> Form Validation Class Initialized
INFO - 2019-12-31 12:24:24 --> Config Class Initialized
INFO - 2019-12-31 12:24:24 --> Hooks Class Initialized
DEBUG - 2019-12-31 12:24:24 --> UTF-8 Support Enabled
INFO - 2019-12-31 12:24:24 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-31 12:24:24 --> Utf8 Class Initialized
INFO - 2019-12-31 12:24:24 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/cari_pemesanan.php
INFO - 2019-12-31 12:24:24 --> Final output sent to browser
INFO - 2019-12-31 12:24:24 --> URI Class Initialized
DEBUG - 2019-12-31 12:24:24 --> Total execution time: 0.9443
INFO - 2019-12-31 12:24:24 --> Router Class Initialized
INFO - 2019-12-31 12:24:24 --> Output Class Initialized
INFO - 2019-12-31 12:24:24 --> Security Class Initialized
DEBUG - 2019-12-31 12:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 12:24:24 --> Input Class Initialized
INFO - 2019-12-31 12:24:24 --> Language Class Initialized
INFO - 2019-12-31 12:24:24 --> Loader Class Initialized
INFO - 2019-12-31 12:24:24 --> Helper loaded: url_helper
INFO - 2019-12-31 12:24:24 --> Database Driver Class Initialized
DEBUG - 2019-12-31 12:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 12:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 12:24:24 --> Controller Class Initialized
INFO - 2019-12-31 12:24:24 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-31 12:24:24 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/beranda.php
INFO - 2019-12-31 12:24:24 --> Final output sent to browser
DEBUG - 2019-12-31 12:24:24 --> Total execution time: 0.3508
INFO - 2019-12-31 12:24:24 --> Config Class Initialized
INFO - 2019-12-31 12:24:24 --> Config Class Initialized
INFO - 2019-12-31 12:24:24 --> Hooks Class Initialized
INFO - 2019-12-31 12:24:24 --> Hooks Class Initialized
DEBUG - 2019-12-31 12:24:24 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 12:24:24 --> UTF-8 Support Enabled
INFO - 2019-12-31 12:24:24 --> Utf8 Class Initialized
INFO - 2019-12-31 12:24:24 --> Utf8 Class Initialized
INFO - 2019-12-31 12:24:24 --> URI Class Initialized
INFO - 2019-12-31 12:24:24 --> URI Class Initialized
INFO - 2019-12-31 12:24:24 --> Router Class Initialized
INFO - 2019-12-31 12:24:24 --> Router Class Initialized
INFO - 2019-12-31 12:24:24 --> Output Class Initialized
INFO - 2019-12-31 12:24:24 --> Output Class Initialized
INFO - 2019-12-31 12:24:24 --> Security Class Initialized
INFO - 2019-12-31 12:24:24 --> Security Class Initialized
DEBUG - 2019-12-31 12:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 12:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 12:24:24 --> Input Class Initialized
INFO - 2019-12-31 12:24:24 --> Input Class Initialized
INFO - 2019-12-31 12:24:24 --> Language Class Initialized
INFO - 2019-12-31 12:24:24 --> Language Class Initialized
ERROR - 2019-12-31 12:24:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-31 12:24:24 --> 404 Page Not Found: Assets/js
INFO - 2019-12-31 12:24:26 --> Config Class Initialized
INFO - 2019-12-31 12:24:26 --> Hooks Class Initialized
DEBUG - 2019-12-31 12:24:26 --> UTF-8 Support Enabled
INFO - 2019-12-31 12:24:26 --> Utf8 Class Initialized
INFO - 2019-12-31 12:24:26 --> URI Class Initialized
INFO - 2019-12-31 12:24:26 --> Router Class Initialized
INFO - 2019-12-31 12:24:26 --> Output Class Initialized
INFO - 2019-12-31 12:24:26 --> Security Class Initialized
DEBUG - 2019-12-31 12:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 12:24:26 --> Input Class Initialized
INFO - 2019-12-31 12:24:26 --> Language Class Initialized
INFO - 2019-12-31 12:24:26 --> Loader Class Initialized
INFO - 2019-12-31 12:24:26 --> Helper loaded: url_helper
INFO - 2019-12-31 12:24:26 --> Database Driver Class Initialized
DEBUG - 2019-12-31 12:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 12:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 12:24:26 --> Controller Class Initialized
INFO - 2019-12-31 12:24:26 --> Model "M_login" initialized
INFO - 2019-12-31 12:24:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-31 12:24:26 --> Pagination Class Initialized
INFO - 2019-12-31 12:24:26 --> Model "M_show" initialized
INFO - 2019-12-31 12:24:26 --> Helper loaded: form_helper
INFO - 2019-12-31 12:24:26 --> Form Validation Class Initialized
INFO - 2019-12-31 12:24:26 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-31 12:24:26 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/show/lihat_show.php
INFO - 2019-12-31 12:24:26 --> Final output sent to browser
DEBUG - 2019-12-31 12:24:26 --> Total execution time: 0.6888
INFO - 2019-12-31 12:24:26 --> Config Class Initialized
INFO - 2019-12-31 12:24:26 --> Config Class Initialized
INFO - 2019-12-31 12:24:26 --> Hooks Class Initialized
INFO - 2019-12-31 12:24:26 --> Hooks Class Initialized
DEBUG - 2019-12-31 12:24:26 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 12:24:26 --> UTF-8 Support Enabled
INFO - 2019-12-31 12:24:26 --> Utf8 Class Initialized
INFO - 2019-12-31 12:24:26 --> Utf8 Class Initialized
INFO - 2019-12-31 12:24:26 --> URI Class Initialized
INFO - 2019-12-31 12:24:26 --> URI Class Initialized
INFO - 2019-12-31 12:24:27 --> Router Class Initialized
INFO - 2019-12-31 12:24:27 --> Router Class Initialized
INFO - 2019-12-31 12:24:27 --> Output Class Initialized
INFO - 2019-12-31 12:24:27 --> Output Class Initialized
INFO - 2019-12-31 12:24:27 --> Security Class Initialized
INFO - 2019-12-31 12:24:27 --> Security Class Initialized
DEBUG - 2019-12-31 12:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 12:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 12:24:27 --> Input Class Initialized
INFO - 2019-12-31 12:24:27 --> Input Class Initialized
INFO - 2019-12-31 12:24:27 --> Language Class Initialized
INFO - 2019-12-31 12:24:27 --> Language Class Initialized
ERROR - 2019-12-31 12:24:27 --> 404 Page Not Found: Show/assets
ERROR - 2019-12-31 12:24:27 --> 404 Page Not Found: Show/assets
INFO - 2019-12-31 12:24:27 --> Config Class Initialized
INFO - 2019-12-31 12:24:27 --> Hooks Class Initialized
DEBUG - 2019-12-31 12:24:27 --> UTF-8 Support Enabled
INFO - 2019-12-31 12:24:27 --> Utf8 Class Initialized
INFO - 2019-12-31 12:24:27 --> URI Class Initialized
INFO - 2019-12-31 12:24:27 --> Router Class Initialized
INFO - 2019-12-31 12:24:27 --> Output Class Initialized
INFO - 2019-12-31 12:24:27 --> Security Class Initialized
DEBUG - 2019-12-31 12:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 12:24:27 --> Input Class Initialized
INFO - 2019-12-31 12:24:27 --> Language Class Initialized
ERROR - 2019-12-31 12:24:27 --> 404 Page Not Found: Show/assets
INFO - 2019-12-31 12:24:27 --> Config Class Initialized
INFO - 2019-12-31 12:24:27 --> Hooks Class Initialized
DEBUG - 2019-12-31 12:24:27 --> UTF-8 Support Enabled
INFO - 2019-12-31 12:24:27 --> Utf8 Class Initialized
INFO - 2019-12-31 12:24:27 --> URI Class Initialized
INFO - 2019-12-31 12:24:27 --> Router Class Initialized
INFO - 2019-12-31 12:24:27 --> Output Class Initialized
INFO - 2019-12-31 12:24:27 --> Security Class Initialized
DEBUG - 2019-12-31 12:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 12:24:27 --> Input Class Initialized
INFO - 2019-12-31 12:24:27 --> Language Class Initialized
ERROR - 2019-12-31 12:24:27 --> 404 Page Not Found: Show/assets
INFO - 2019-12-31 14:09:18 --> Config Class Initialized
INFO - 2019-12-31 14:09:18 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:09:18 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:09:18 --> Utf8 Class Initialized
INFO - 2019-12-31 14:09:18 --> URI Class Initialized
INFO - 2019-12-31 14:09:18 --> Router Class Initialized
INFO - 2019-12-31 14:09:18 --> Output Class Initialized
INFO - 2019-12-31 14:09:18 --> Security Class Initialized
DEBUG - 2019-12-31 14:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:09:18 --> Input Class Initialized
INFO - 2019-12-31 14:09:18 --> Language Class Initialized
INFO - 2019-12-31 14:09:18 --> Loader Class Initialized
INFO - 2019-12-31 14:09:18 --> Helper loaded: url_helper
INFO - 2019-12-31 14:09:18 --> Database Driver Class Initialized
DEBUG - 2019-12-31 14:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 14:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 14:09:18 --> Controller Class Initialized
INFO - 2019-12-31 14:09:18 --> Model "M_login" initialized
INFO - 2019-12-31 14:09:18 --> Model "M_tiket" initialized
INFO - 2019-12-31 14:09:18 --> Helper loaded: form_helper
INFO - 2019-12-31 14:09:18 --> Form Validation Class Initialized
INFO - 2019-12-31 14:09:18 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-31 14:09:18 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2019-12-31 14:09:18 --> Final output sent to browser
DEBUG - 2019-12-31 14:09:18 --> Total execution time: 0.7753
INFO - 2019-12-31 14:09:18 --> Config Class Initialized
INFO - 2019-12-31 14:09:18 --> Hooks Class Initialized
INFO - 2019-12-31 14:09:18 --> Config Class Initialized
INFO - 2019-12-31 14:09:19 --> Config Class Initialized
INFO - 2019-12-31 14:09:19 --> Config Class Initialized
INFO - 2019-12-31 14:09:19 --> Config Class Initialized
INFO - 2019-12-31 14:09:19 --> Hooks Class Initialized
INFO - 2019-12-31 14:09:19 --> Hooks Class Initialized
INFO - 2019-12-31 14:09:19 --> Hooks Class Initialized
INFO - 2019-12-31 14:09:19 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:09:19 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:09:19 --> Utf8 Class Initialized
DEBUG - 2019-12-31 14:09:19 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:09:19 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:09:19 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:09:19 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:09:19 --> Config Class Initialized
INFO - 2019-12-31 14:09:19 --> Utf8 Class Initialized
INFO - 2019-12-31 14:09:19 --> Hooks Class Initialized
INFO - 2019-12-31 14:09:19 --> Utf8 Class Initialized
INFO - 2019-12-31 14:09:19 --> Utf8 Class Initialized
INFO - 2019-12-31 14:09:19 --> Utf8 Class Initialized
INFO - 2019-12-31 14:09:19 --> URI Class Initialized
INFO - 2019-12-31 14:09:19 --> URI Class Initialized
INFO - 2019-12-31 14:09:19 --> URI Class Initialized
INFO - 2019-12-31 14:09:19 --> Router Class Initialized
INFO - 2019-12-31 14:09:19 --> URI Class Initialized
DEBUG - 2019-12-31 14:09:19 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:09:19 --> URI Class Initialized
INFO - 2019-12-31 14:09:19 --> Utf8 Class Initialized
INFO - 2019-12-31 14:09:19 --> Router Class Initialized
INFO - 2019-12-31 14:09:19 --> Output Class Initialized
INFO - 2019-12-31 14:09:19 --> Router Class Initialized
INFO - 2019-12-31 14:09:19 --> Router Class Initialized
INFO - 2019-12-31 14:09:19 --> Router Class Initialized
INFO - 2019-12-31 14:09:19 --> URI Class Initialized
INFO - 2019-12-31 14:09:19 --> Output Class Initialized
INFO - 2019-12-31 14:09:19 --> Output Class Initialized
INFO - 2019-12-31 14:09:19 --> Output Class Initialized
INFO - 2019-12-31 14:09:19 --> Security Class Initialized
INFO - 2019-12-31 14:09:19 --> Output Class Initialized
INFO - 2019-12-31 14:09:19 --> Security Class Initialized
INFO - 2019-12-31 14:09:19 --> Security Class Initialized
INFO - 2019-12-31 14:09:19 --> Security Class Initialized
INFO - 2019-12-31 14:09:19 --> Router Class Initialized
DEBUG - 2019-12-31 14:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:09:19 --> Security Class Initialized
INFO - 2019-12-31 14:09:19 --> Input Class Initialized
DEBUG - 2019-12-31 14:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:09:19 --> Output Class Initialized
DEBUG - 2019-12-31 14:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:09:19 --> Input Class Initialized
INFO - 2019-12-31 14:09:19 --> Input Class Initialized
INFO - 2019-12-31 14:09:19 --> Input Class Initialized
INFO - 2019-12-31 14:09:19 --> Language Class Initialized
INFO - 2019-12-31 14:09:19 --> Input Class Initialized
INFO - 2019-12-31 14:09:19 --> Security Class Initialized
INFO - 2019-12-31 14:09:19 --> Language Class Initialized
INFO - 2019-12-31 14:09:19 --> Language Class Initialized
INFO - 2019-12-31 14:09:19 --> Language Class Initialized
ERROR - 2019-12-31 14:09:19 --> 404 Page Not Found: Bower_components/jquery
DEBUG - 2019-12-31 14:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:09:19 --> Language Class Initialized
INFO - 2019-12-31 14:09:19 --> Input Class Initialized
ERROR - 2019-12-31 14:09:19 --> 404 Page Not Found: Bower_components/tether
ERROR - 2019-12-31 14:09:19 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2019-12-31 14:09:19 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2019-12-31 14:09:19 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2019-12-31 14:09:19 --> Config Class Initialized
INFO - 2019-12-31 14:09:19 --> Hooks Class Initialized
INFO - 2019-12-31 14:09:19 --> Language Class Initialized
INFO - 2019-12-31 14:09:19 --> Config Class Initialized
ERROR - 2019-12-31 14:09:19 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2019-12-31 14:09:19 --> Config Class Initialized
INFO - 2019-12-31 14:09:19 --> Config Class Initialized
DEBUG - 2019-12-31 14:09:19 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:09:19 --> Config Class Initialized
INFO - 2019-12-31 14:09:19 --> Utf8 Class Initialized
INFO - 2019-12-31 14:09:19 --> Hooks Class Initialized
INFO - 2019-12-31 14:09:19 --> Hooks Class Initialized
INFO - 2019-12-31 14:09:19 --> Hooks Class Initialized
INFO - 2019-12-31 14:09:19 --> Hooks Class Initialized
INFO - 2019-12-31 14:09:19 --> Config Class Initialized
INFO - 2019-12-31 14:09:19 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:09:19 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:09:19 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:09:19 --> URI Class Initialized
DEBUG - 2019-12-31 14:09:19 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:09:19 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:09:19 --> Utf8 Class Initialized
INFO - 2019-12-31 14:09:19 --> Utf8 Class Initialized
INFO - 2019-12-31 14:09:19 --> Utf8 Class Initialized
INFO - 2019-12-31 14:09:19 --> Utf8 Class Initialized
INFO - 2019-12-31 14:09:19 --> Router Class Initialized
DEBUG - 2019-12-31 14:09:19 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:09:19 --> Utf8 Class Initialized
INFO - 2019-12-31 14:09:19 --> URI Class Initialized
INFO - 2019-12-31 14:09:19 --> URI Class Initialized
INFO - 2019-12-31 14:09:19 --> URI Class Initialized
INFO - 2019-12-31 14:09:19 --> URI Class Initialized
INFO - 2019-12-31 14:09:19 --> Output Class Initialized
INFO - 2019-12-31 14:09:19 --> Router Class Initialized
INFO - 2019-12-31 14:09:19 --> Router Class Initialized
INFO - 2019-12-31 14:09:19 --> Security Class Initialized
INFO - 2019-12-31 14:09:19 --> Router Class Initialized
INFO - 2019-12-31 14:09:19 --> Router Class Initialized
INFO - 2019-12-31 14:09:19 --> URI Class Initialized
DEBUG - 2019-12-31 14:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:09:19 --> Output Class Initialized
INFO - 2019-12-31 14:09:19 --> Output Class Initialized
INFO - 2019-12-31 14:09:19 --> Output Class Initialized
INFO - 2019-12-31 14:09:19 --> Output Class Initialized
INFO - 2019-12-31 14:09:19 --> Router Class Initialized
INFO - 2019-12-31 14:09:19 --> Input Class Initialized
INFO - 2019-12-31 14:09:19 --> Security Class Initialized
INFO - 2019-12-31 14:09:19 --> Security Class Initialized
INFO - 2019-12-31 14:09:19 --> Security Class Initialized
INFO - 2019-12-31 14:09:19 --> Security Class Initialized
INFO - 2019-12-31 14:09:19 --> Output Class Initialized
INFO - 2019-12-31 14:09:19 --> Language Class Initialized
DEBUG - 2019-12-31 14:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:09:19 --> Security Class Initialized
DEBUG - 2019-12-31 14:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:09:19 --> Input Class Initialized
INFO - 2019-12-31 14:09:19 --> Input Class Initialized
INFO - 2019-12-31 14:09:19 --> Input Class Initialized
INFO - 2019-12-31 14:09:19 --> Input Class Initialized
DEBUG - 2019-12-31 14:09:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-12-31 14:09:19 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2019-12-31 14:09:19 --> Input Class Initialized
INFO - 2019-12-31 14:09:19 --> Language Class Initialized
INFO - 2019-12-31 14:09:19 --> Language Class Initialized
INFO - 2019-12-31 14:09:19 --> Language Class Initialized
INFO - 2019-12-31 14:09:19 --> Language Class Initialized
INFO - 2019-12-31 14:09:19 --> Config Class Initialized
INFO - 2019-12-31 14:09:19 --> Hooks Class Initialized
INFO - 2019-12-31 14:09:19 --> Language Class Initialized
ERROR - 2019-12-31 14:09:19 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2019-12-31 14:09:19 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2019-12-31 14:09:19 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2019-12-31 14:09:19 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2019-12-31 14:09:19 --> 404 Page Not Found: Bower_components/jquery-i18next
DEBUG - 2019-12-31 14:09:19 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:09:19 --> Utf8 Class Initialized
INFO - 2019-12-31 14:09:19 --> Config Class Initialized
INFO - 2019-12-31 14:09:19 --> Config Class Initialized
INFO - 2019-12-31 14:09:19 --> Hooks Class Initialized
INFO - 2019-12-31 14:09:19 --> Hooks Class Initialized
INFO - 2019-12-31 14:09:19 --> URI Class Initialized
DEBUG - 2019-12-31 14:09:19 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:09:19 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:09:19 --> Router Class Initialized
INFO - 2019-12-31 14:09:19 --> Utf8 Class Initialized
INFO - 2019-12-31 14:09:19 --> Utf8 Class Initialized
INFO - 2019-12-31 14:09:19 --> Output Class Initialized
INFO - 2019-12-31 14:09:19 --> URI Class Initialized
INFO - 2019-12-31 14:09:19 --> URI Class Initialized
INFO - 2019-12-31 14:09:19 --> Security Class Initialized
INFO - 2019-12-31 14:09:19 --> Router Class Initialized
DEBUG - 2019-12-31 14:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:09:19 --> Router Class Initialized
INFO - 2019-12-31 14:09:19 --> Input Class Initialized
INFO - 2019-12-31 14:09:19 --> Output Class Initialized
INFO - 2019-12-31 14:09:19 --> Output Class Initialized
INFO - 2019-12-31 14:09:19 --> Language Class Initialized
INFO - 2019-12-31 14:09:19 --> Security Class Initialized
INFO - 2019-12-31 14:09:19 --> Security Class Initialized
DEBUG - 2019-12-31 14:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:09:20 --> Loader Class Initialized
INFO - 2019-12-31 14:09:20 --> Input Class Initialized
INFO - 2019-12-31 14:09:20 --> Input Class Initialized
INFO - 2019-12-31 14:09:20 --> Helper loaded: url_helper
INFO - 2019-12-31 14:09:20 --> Language Class Initialized
INFO - 2019-12-31 14:09:20 --> Language Class Initialized
INFO - 2019-12-31 14:09:20 --> Database Driver Class Initialized
ERROR - 2019-12-31 14:09:20 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2019-12-31 14:09:20 --> Loader Class Initialized
DEBUG - 2019-12-31 14:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 14:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 14:09:20 --> Helper loaded: url_helper
INFO - 2019-12-31 14:09:20 --> Config Class Initialized
INFO - 2019-12-31 14:09:20 --> Hooks Class Initialized
INFO - 2019-12-31 14:09:20 --> Controller Class Initialized
INFO - 2019-12-31 14:09:20 --> Database Driver Class Initialized
INFO - 2019-12-31 14:09:20 --> Model "M_login" initialized
DEBUG - 2019-12-31 14:09:20 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 14:09:20 --> Utf8 Class Initialized
INFO - 2019-12-31 14:09:20 --> Model "M_tiket" initialized
INFO - 2019-12-31 14:09:20 --> URI Class Initialized
INFO - 2019-12-31 14:09:20 --> Helper loaded: form_helper
INFO - 2019-12-31 14:09:20 --> Form Validation Class Initialized
INFO - 2019-12-31 14:09:20 --> Router Class Initialized
INFO - 2019-12-31 14:09:20 --> Output Class Initialized
INFO - 2019-12-31 14:09:20 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2019-12-31 14:09:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2019-12-31 14:09:20 --> Security Class Initialized
DEBUG - 2019-12-31 14:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:09:20 --> Input Class Initialized
INFO - 2019-12-31 14:09:20 --> Language Class Initialized
ERROR - 2019-12-31 14:09:20 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2019-12-31 14:09:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
INFO - 2019-12-31 14:09:20 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2019-12-31 14:09:20 --> Final output sent to browser
INFO - 2019-12-31 14:09:20 --> Config Class Initialized
INFO - 2019-12-31 14:09:20 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:09:20 --> Total execution time: 0.5866
INFO - 2019-12-31 14:09:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-12-31 14:09:20 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:09:20 --> Utf8 Class Initialized
INFO - 2019-12-31 14:09:20 --> Controller Class Initialized
INFO - 2019-12-31 14:09:20 --> Model "M_login" initialized
INFO - 2019-12-31 14:09:20 --> URI Class Initialized
INFO - 2019-12-31 14:09:20 --> Model "M_tiket" initialized
INFO - 2019-12-31 14:09:20 --> Router Class Initialized
INFO - 2019-12-31 14:09:20 --> Output Class Initialized
INFO - 2019-12-31 14:09:20 --> Helper loaded: form_helper
INFO - 2019-12-31 14:09:20 --> Form Validation Class Initialized
INFO - 2019-12-31 14:09:20 --> Security Class Initialized
DEBUG - 2019-12-31 14:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:09:20 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-31 14:09:20 --> Input Class Initialized
ERROR - 2019-12-31 14:09:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2019-12-31 14:09:20 --> Language Class Initialized
ERROR - 2019-12-31 14:09:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
INFO - 2019-12-31 14:09:20 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
ERROR - 2019-12-31 14:09:20 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2019-12-31 14:09:20 --> Final output sent to browser
DEBUG - 2019-12-31 14:09:20 --> Total execution time: 0.7498
INFO - 2019-12-31 14:09:20 --> Config Class Initialized
INFO - 2019-12-31 14:09:20 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:09:20 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:09:20 --> Utf8 Class Initialized
INFO - 2019-12-31 14:09:20 --> URI Class Initialized
INFO - 2019-12-31 14:09:20 --> Router Class Initialized
INFO - 2019-12-31 14:09:20 --> Output Class Initialized
INFO - 2019-12-31 14:09:20 --> Security Class Initialized
DEBUG - 2019-12-31 14:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:09:20 --> Input Class Initialized
INFO - 2019-12-31 14:09:20 --> Language Class Initialized
ERROR - 2019-12-31 14:09:20 --> 404 Page Not Found: Bower_components/i18next
INFO - 2019-12-31 14:09:20 --> Config Class Initialized
INFO - 2019-12-31 14:09:20 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:09:20 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:09:20 --> Utf8 Class Initialized
INFO - 2019-12-31 14:09:20 --> URI Class Initialized
INFO - 2019-12-31 14:09:20 --> Router Class Initialized
INFO - 2019-12-31 14:09:20 --> Output Class Initialized
INFO - 2019-12-31 14:09:20 --> Security Class Initialized
DEBUG - 2019-12-31 14:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:09:20 --> Input Class Initialized
INFO - 2019-12-31 14:09:21 --> Language Class Initialized
ERROR - 2019-12-31 14:09:21 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2019-12-31 14:09:21 --> Config Class Initialized
INFO - 2019-12-31 14:09:21 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:09:21 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:09:21 --> Utf8 Class Initialized
INFO - 2019-12-31 14:09:21 --> URI Class Initialized
INFO - 2019-12-31 14:09:21 --> Router Class Initialized
INFO - 2019-12-31 14:09:21 --> Output Class Initialized
INFO - 2019-12-31 14:09:21 --> Security Class Initialized
DEBUG - 2019-12-31 14:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:09:21 --> Input Class Initialized
INFO - 2019-12-31 14:09:21 --> Language Class Initialized
ERROR - 2019-12-31 14:09:21 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2019-12-31 14:09:21 --> Config Class Initialized
INFO - 2019-12-31 14:09:21 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:09:21 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:09:21 --> Utf8 Class Initialized
INFO - 2019-12-31 14:09:21 --> URI Class Initialized
INFO - 2019-12-31 14:09:21 --> Router Class Initialized
INFO - 2019-12-31 14:09:21 --> Output Class Initialized
INFO - 2019-12-31 14:09:21 --> Security Class Initialized
DEBUG - 2019-12-31 14:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:09:21 --> Input Class Initialized
INFO - 2019-12-31 14:09:21 --> Language Class Initialized
ERROR - 2019-12-31 14:09:21 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2019-12-31 14:09:36 --> Config Class Initialized
INFO - 2019-12-31 14:09:36 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:09:36 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:09:36 --> Utf8 Class Initialized
INFO - 2019-12-31 14:09:36 --> URI Class Initialized
INFO - 2019-12-31 14:09:36 --> Router Class Initialized
INFO - 2019-12-31 14:09:36 --> Output Class Initialized
INFO - 2019-12-31 14:09:36 --> Security Class Initialized
DEBUG - 2019-12-31 14:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:09:36 --> Input Class Initialized
INFO - 2019-12-31 14:09:36 --> Language Class Initialized
INFO - 2019-12-31 14:09:36 --> Loader Class Initialized
INFO - 2019-12-31 14:09:37 --> Helper loaded: url_helper
INFO - 2019-12-31 14:09:37 --> Database Driver Class Initialized
DEBUG - 2019-12-31 14:09:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 14:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 14:09:37 --> Controller Class Initialized
INFO - 2019-12-31 14:09:37 --> Model "M_login" initialized
INFO - 2019-12-31 14:09:37 --> Model "M_tiket" initialized
INFO - 2019-12-31 14:09:37 --> Helper loaded: form_helper
INFO - 2019-12-31 14:09:37 --> Form Validation Class Initialized
ERROR - 2019-12-31 14:09:37 --> Severity: error --> Exception: Too few arguments to function Tiket::add(), 0 passed in C:\xampp\htdocs\Musikologi-1\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\Musikologi-1\application\controllers\Tiket.php 18
INFO - 2019-12-31 14:09:41 --> Config Class Initialized
INFO - 2019-12-31 14:09:41 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:09:41 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:09:41 --> Utf8 Class Initialized
INFO - 2019-12-31 14:09:41 --> URI Class Initialized
INFO - 2019-12-31 14:09:41 --> Router Class Initialized
INFO - 2019-12-31 14:09:41 --> Output Class Initialized
INFO - 2019-12-31 14:09:41 --> Security Class Initialized
DEBUG - 2019-12-31 14:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:09:41 --> Input Class Initialized
INFO - 2019-12-31 14:09:41 --> Language Class Initialized
INFO - 2019-12-31 14:09:41 --> Loader Class Initialized
INFO - 2019-12-31 14:09:41 --> Helper loaded: url_helper
INFO - 2019-12-31 14:09:41 --> Database Driver Class Initialized
DEBUG - 2019-12-31 14:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 14:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 14:09:41 --> Controller Class Initialized
INFO - 2019-12-31 14:09:41 --> Model "M_login" initialized
INFO - 2019-12-31 14:09:41 --> Model "M_tiket" initialized
INFO - 2019-12-31 14:09:41 --> Helper loaded: form_helper
INFO - 2019-12-31 14:09:41 --> Form Validation Class Initialized
INFO - 2019-12-31 14:09:41 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-31 14:09:41 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2019-12-31 14:09:41 --> Final output sent to browser
DEBUG - 2019-12-31 14:09:41 --> Total execution time: 0.4801
INFO - 2019-12-31 14:09:41 --> Config Class Initialized
INFO - 2019-12-31 14:09:41 --> Hooks Class Initialized
INFO - 2019-12-31 14:09:41 --> Config Class Initialized
INFO - 2019-12-31 14:09:41 --> Config Class Initialized
INFO - 2019-12-31 14:09:41 --> Hooks Class Initialized
INFO - 2019-12-31 14:09:41 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:09:41 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:09:41 --> Utf8 Class Initialized
DEBUG - 2019-12-31 14:09:41 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:09:41 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:09:41 --> Utf8 Class Initialized
INFO - 2019-12-31 14:09:41 --> Utf8 Class Initialized
INFO - 2019-12-31 14:09:41 --> URI Class Initialized
INFO - 2019-12-31 14:09:41 --> URI Class Initialized
INFO - 2019-12-31 14:09:41 --> URI Class Initialized
INFO - 2019-12-31 14:09:41 --> Router Class Initialized
INFO - 2019-12-31 14:09:41 --> Router Class Initialized
INFO - 2019-12-31 14:09:41 --> Output Class Initialized
INFO - 2019-12-31 14:09:41 --> Router Class Initialized
INFO - 2019-12-31 14:09:41 --> Security Class Initialized
INFO - 2019-12-31 14:09:41 --> Output Class Initialized
INFO - 2019-12-31 14:09:41 --> Output Class Initialized
DEBUG - 2019-12-31 14:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:09:41 --> Security Class Initialized
INFO - 2019-12-31 14:09:41 --> Security Class Initialized
INFO - 2019-12-31 14:09:41 --> Input Class Initialized
DEBUG - 2019-12-31 14:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:09:41 --> Input Class Initialized
INFO - 2019-12-31 14:09:41 --> Input Class Initialized
INFO - 2019-12-31 14:09:41 --> Language Class Initialized
ERROR - 2019-12-31 14:09:41 --> 404 Page Not Found: Bower_components/jquery
INFO - 2019-12-31 14:09:41 --> Language Class Initialized
INFO - 2019-12-31 14:09:41 --> Language Class Initialized
ERROR - 2019-12-31 14:09:41 --> 404 Page Not Found: Bower_components/tether
ERROR - 2019-12-31 14:09:41 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2019-12-31 14:09:50 --> Config Class Initialized
INFO - 2019-12-31 14:09:50 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:09:50 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:09:50 --> Utf8 Class Initialized
INFO - 2019-12-31 14:09:50 --> URI Class Initialized
INFO - 2019-12-31 14:09:50 --> Router Class Initialized
INFO - 2019-12-31 14:09:50 --> Output Class Initialized
INFO - 2019-12-31 14:09:50 --> Security Class Initialized
DEBUG - 2019-12-31 14:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:09:50 --> Input Class Initialized
INFO - 2019-12-31 14:09:50 --> Language Class Initialized
INFO - 2019-12-31 14:09:50 --> Loader Class Initialized
INFO - 2019-12-31 14:09:50 --> Helper loaded: url_helper
INFO - 2019-12-31 14:09:50 --> Database Driver Class Initialized
DEBUG - 2019-12-31 14:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 14:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 14:09:50 --> Controller Class Initialized
INFO - 2019-12-31 14:09:50 --> Model "M_login" initialized
INFO - 2019-12-31 14:09:50 --> Model "M_tiket" initialized
INFO - 2019-12-31 14:09:50 --> Helper loaded: form_helper
INFO - 2019-12-31 14:09:50 --> Form Validation Class Initialized
INFO - 2019-12-31 14:09:50 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-31 14:09:50 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/edit_form.php
INFO - 2019-12-31 14:09:50 --> Final output sent to browser
DEBUG - 2019-12-31 14:09:50 --> Total execution time: 0.6697
INFO - 2019-12-31 14:11:24 --> Config Class Initialized
INFO - 2019-12-31 14:11:24 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:11:24 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:24 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:24 --> URI Class Initialized
INFO - 2019-12-31 14:11:24 --> Router Class Initialized
INFO - 2019-12-31 14:11:24 --> Output Class Initialized
INFO - 2019-12-31 14:11:24 --> Security Class Initialized
DEBUG - 2019-12-31 14:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:25 --> Input Class Initialized
INFO - 2019-12-31 14:11:25 --> Language Class Initialized
INFO - 2019-12-31 14:11:25 --> Loader Class Initialized
INFO - 2019-12-31 14:11:25 --> Helper loaded: url_helper
INFO - 2019-12-31 14:11:25 --> Database Driver Class Initialized
DEBUG - 2019-12-31 14:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 14:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 14:11:25 --> Controller Class Initialized
INFO - 2019-12-31 14:11:25 --> Model "M_login" initialized
INFO - 2019-12-31 14:11:25 --> Model "M_tiket" initialized
INFO - 2019-12-31 14:11:25 --> Helper loaded: form_helper
INFO - 2019-12-31 14:11:25 --> Form Validation Class Initialized
INFO - 2019-12-31 14:11:25 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-31 14:11:25 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2019-12-31 14:11:25 --> Final output sent to browser
DEBUG - 2019-12-31 14:11:25 --> Total execution time: 0.4558
INFO - 2019-12-31 14:11:25 --> Config Class Initialized
INFO - 2019-12-31 14:11:25 --> Config Class Initialized
INFO - 2019-12-31 14:11:25 --> Config Class Initialized
INFO - 2019-12-31 14:11:25 --> Config Class Initialized
INFO - 2019-12-31 14:11:25 --> Config Class Initialized
INFO - 2019-12-31 14:11:25 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:25 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:25 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:25 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:25 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:25 --> Config Class Initialized
INFO - 2019-12-31 14:11:25 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:11:25 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:11:25 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:11:25 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:11:25 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:11:25 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:25 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:25 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:25 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:25 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:25 --> Utf8 Class Initialized
DEBUG - 2019-12-31 14:11:25 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:25 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:25 --> URI Class Initialized
INFO - 2019-12-31 14:11:25 --> URI Class Initialized
INFO - 2019-12-31 14:11:25 --> URI Class Initialized
INFO - 2019-12-31 14:11:25 --> URI Class Initialized
INFO - 2019-12-31 14:11:25 --> URI Class Initialized
INFO - 2019-12-31 14:11:25 --> Router Class Initialized
INFO - 2019-12-31 14:11:25 --> Router Class Initialized
INFO - 2019-12-31 14:11:25 --> Router Class Initialized
INFO - 2019-12-31 14:11:25 --> Router Class Initialized
INFO - 2019-12-31 14:11:25 --> URI Class Initialized
INFO - 2019-12-31 14:11:25 --> Router Class Initialized
INFO - 2019-12-31 14:11:25 --> Output Class Initialized
INFO - 2019-12-31 14:11:25 --> Output Class Initialized
INFO - 2019-12-31 14:11:25 --> Output Class Initialized
INFO - 2019-12-31 14:11:25 --> Output Class Initialized
INFO - 2019-12-31 14:11:25 --> Output Class Initialized
INFO - 2019-12-31 14:11:25 --> Router Class Initialized
INFO - 2019-12-31 14:11:25 --> Security Class Initialized
INFO - 2019-12-31 14:11:25 --> Security Class Initialized
INFO - 2019-12-31 14:11:25 --> Security Class Initialized
INFO - 2019-12-31 14:11:25 --> Security Class Initialized
INFO - 2019-12-31 14:11:25 --> Security Class Initialized
INFO - 2019-12-31 14:11:25 --> Output Class Initialized
DEBUG - 2019-12-31 14:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:25 --> Security Class Initialized
INFO - 2019-12-31 14:11:25 --> Input Class Initialized
INFO - 2019-12-31 14:11:25 --> Input Class Initialized
INFO - 2019-12-31 14:11:25 --> Input Class Initialized
INFO - 2019-12-31 14:11:25 --> Input Class Initialized
INFO - 2019-12-31 14:11:25 --> Input Class Initialized
DEBUG - 2019-12-31 14:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:25 --> Language Class Initialized
INFO - 2019-12-31 14:11:25 --> Language Class Initialized
INFO - 2019-12-31 14:11:25 --> Language Class Initialized
INFO - 2019-12-31 14:11:25 --> Language Class Initialized
INFO - 2019-12-31 14:11:25 --> Input Class Initialized
INFO - 2019-12-31 14:11:25 --> Language Class Initialized
INFO - 2019-12-31 14:11:25 --> Language Class Initialized
ERROR - 2019-12-31 14:11:25 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2019-12-31 14:11:25 --> 404 Page Not Found: Bower_components/tether
ERROR - 2019-12-31 14:11:25 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2019-12-31 14:11:25 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2019-12-31 14:11:25 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2019-12-31 14:11:25 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2019-12-31 14:11:25 --> Config Class Initialized
INFO - 2019-12-31 14:11:25 --> Config Class Initialized
INFO - 2019-12-31 14:11:25 --> Config Class Initialized
INFO - 2019-12-31 14:11:25 --> Config Class Initialized
INFO - 2019-12-31 14:11:25 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:25 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:25 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:25 --> Config Class Initialized
INFO - 2019-12-31 14:11:25 --> Config Class Initialized
INFO - 2019-12-31 14:11:25 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:25 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:11:25 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:11:25 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:25 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:11:25 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:25 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:25 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:25 --> Utf8 Class Initialized
DEBUG - 2019-12-31 14:11:25 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:11:25 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:11:25 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:25 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:25 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:25 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:25 --> URI Class Initialized
INFO - 2019-12-31 14:11:25 --> URI Class Initialized
INFO - 2019-12-31 14:11:25 --> URI Class Initialized
INFO - 2019-12-31 14:11:25 --> URI Class Initialized
INFO - 2019-12-31 14:11:25 --> Router Class Initialized
INFO - 2019-12-31 14:11:25 --> URI Class Initialized
INFO - 2019-12-31 14:11:25 --> Router Class Initialized
INFO - 2019-12-31 14:11:25 --> Router Class Initialized
INFO - 2019-12-31 14:11:25 --> URI Class Initialized
INFO - 2019-12-31 14:11:25 --> Router Class Initialized
INFO - 2019-12-31 14:11:25 --> Router Class Initialized
INFO - 2019-12-31 14:11:25 --> Output Class Initialized
INFO - 2019-12-31 14:11:25 --> Output Class Initialized
INFO - 2019-12-31 14:11:25 --> Output Class Initialized
INFO - 2019-12-31 14:11:25 --> Router Class Initialized
INFO - 2019-12-31 14:11:25 --> Security Class Initialized
INFO - 2019-12-31 14:11:25 --> Security Class Initialized
INFO - 2019-12-31 14:11:25 --> Output Class Initialized
INFO - 2019-12-31 14:11:25 --> Output Class Initialized
INFO - 2019-12-31 14:11:25 --> Security Class Initialized
INFO - 2019-12-31 14:11:25 --> Output Class Initialized
DEBUG - 2019-12-31 14:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:25 --> Security Class Initialized
DEBUG - 2019-12-31 14:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:25 --> Security Class Initialized
INFO - 2019-12-31 14:11:25 --> Security Class Initialized
DEBUG - 2019-12-31 14:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:25 --> Input Class Initialized
INFO - 2019-12-31 14:11:25 --> Input Class Initialized
INFO - 2019-12-31 14:11:25 --> Input Class Initialized
DEBUG - 2019-12-31 14:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:25 --> Input Class Initialized
INFO - 2019-12-31 14:11:25 --> Input Class Initialized
INFO - 2019-12-31 14:11:25 --> Input Class Initialized
INFO - 2019-12-31 14:11:25 --> Language Class Initialized
INFO - 2019-12-31 14:11:25 --> Language Class Initialized
INFO - 2019-12-31 14:11:25 --> Language Class Initialized
INFO - 2019-12-31 14:11:25 --> Language Class Initialized
INFO - 2019-12-31 14:11:25 --> Language Class Initialized
INFO - 2019-12-31 14:11:25 --> Language Class Initialized
ERROR - 2019-12-31 14:11:25 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2019-12-31 14:11:25 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2019-12-31 14:11:25 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2019-12-31 14:11:25 --> 404 Page Not Found: Bower_components/tether
ERROR - 2019-12-31 14:11:25 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2019-12-31 14:11:25 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2019-12-31 14:11:25 --> Config Class Initialized
INFO - 2019-12-31 14:11:25 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:25 --> Config Class Initialized
INFO - 2019-12-31 14:11:26 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:26 --> Config Class Initialized
DEBUG - 2019-12-31 14:11:26 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:26 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:26 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:11:26 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:26 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:26 --> URI Class Initialized
DEBUG - 2019-12-31 14:11:26 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:26 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:26 --> URI Class Initialized
INFO - 2019-12-31 14:11:26 --> Router Class Initialized
INFO - 2019-12-31 14:11:26 --> URI Class Initialized
INFO - 2019-12-31 14:11:26 --> Router Class Initialized
INFO - 2019-12-31 14:11:26 --> Output Class Initialized
INFO - 2019-12-31 14:11:26 --> Router Class Initialized
INFO - 2019-12-31 14:11:26 --> Security Class Initialized
INFO - 2019-12-31 14:11:26 --> Output Class Initialized
DEBUG - 2019-12-31 14:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:26 --> Security Class Initialized
INFO - 2019-12-31 14:11:26 --> Output Class Initialized
INFO - 2019-12-31 14:11:26 --> Input Class Initialized
DEBUG - 2019-12-31 14:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:26 --> Security Class Initialized
INFO - 2019-12-31 14:11:26 --> Input Class Initialized
INFO - 2019-12-31 14:11:26 --> Language Class Initialized
DEBUG - 2019-12-31 14:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:26 --> Input Class Initialized
INFO - 2019-12-31 14:11:26 --> Language Class Initialized
INFO - 2019-12-31 14:11:26 --> Loader Class Initialized
INFO - 2019-12-31 14:11:26 --> Language Class Initialized
INFO - 2019-12-31 14:11:26 --> Helper loaded: url_helper
INFO - 2019-12-31 14:11:26 --> Loader Class Initialized
INFO - 2019-12-31 14:11:26 --> Helper loaded: url_helper
ERROR - 2019-12-31 14:11:26 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2019-12-31 14:11:26 --> Database Driver Class Initialized
DEBUG - 2019-12-31 14:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 14:11:26 --> Database Driver Class Initialized
INFO - 2019-12-31 14:11:26 --> Config Class Initialized
INFO - 2019-12-31 14:11:26 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-12-31 14:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 14:11:26 --> Controller Class Initialized
DEBUG - 2019-12-31 14:11:26 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:26 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:26 --> Model "M_login" initialized
INFO - 2019-12-31 14:11:26 --> Model "M_tiket" initialized
INFO - 2019-12-31 14:11:26 --> URI Class Initialized
INFO - 2019-12-31 14:11:26 --> Router Class Initialized
INFO - 2019-12-31 14:11:26 --> Helper loaded: form_helper
INFO - 2019-12-31 14:11:26 --> Form Validation Class Initialized
INFO - 2019-12-31 14:11:26 --> Output Class Initialized
INFO - 2019-12-31 14:11:26 --> Security Class Initialized
INFO - 2019-12-31 14:11:26 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2019-12-31 14:11:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2019-12-31 14:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:26 --> Input Class Initialized
ERROR - 2019-12-31 14:11:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
INFO - 2019-12-31 14:11:26 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2019-12-31 14:11:26 --> Language Class Initialized
INFO - 2019-12-31 14:11:26 --> Final output sent to browser
ERROR - 2019-12-31 14:11:26 --> 404 Page Not Found: Bower_components/jquery-slimscroll
DEBUG - 2019-12-31 14:11:26 --> Total execution time: 0.4909
INFO - 2019-12-31 14:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 14:11:26 --> Config Class Initialized
INFO - 2019-12-31 14:11:26 --> Controller Class Initialized
INFO - 2019-12-31 14:11:26 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:26 --> Model "M_login" initialized
DEBUG - 2019-12-31 14:11:26 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:26 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:26 --> Model "M_tiket" initialized
INFO - 2019-12-31 14:11:26 --> URI Class Initialized
INFO - 2019-12-31 14:11:26 --> Helper loaded: form_helper
INFO - 2019-12-31 14:11:26 --> Form Validation Class Initialized
INFO - 2019-12-31 14:11:26 --> Router Class Initialized
INFO - 2019-12-31 14:11:26 --> Output Class Initialized
INFO - 2019-12-31 14:11:26 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2019-12-31 14:11:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2019-12-31 14:11:26 --> Security Class Initialized
ERROR - 2019-12-31 14:11:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
DEBUG - 2019-12-31 14:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:26 --> Input Class Initialized
INFO - 2019-12-31 14:11:26 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2019-12-31 14:11:26 --> Final output sent to browser
INFO - 2019-12-31 14:11:26 --> Language Class Initialized
DEBUG - 2019-12-31 14:11:26 --> Total execution time: 0.7101
ERROR - 2019-12-31 14:11:26 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2019-12-31 14:11:26 --> Config Class Initialized
INFO - 2019-12-31 14:11:26 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:11:26 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:26 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:26 --> URI Class Initialized
INFO - 2019-12-31 14:11:26 --> Router Class Initialized
INFO - 2019-12-31 14:11:26 --> Output Class Initialized
INFO - 2019-12-31 14:11:26 --> Security Class Initialized
DEBUG - 2019-12-31 14:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:26 --> Input Class Initialized
INFO - 2019-12-31 14:11:26 --> Language Class Initialized
ERROR - 2019-12-31 14:11:27 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2019-12-31 14:11:27 --> Config Class Initialized
INFO - 2019-12-31 14:11:27 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:11:27 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:27 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:27 --> URI Class Initialized
INFO - 2019-12-31 14:11:27 --> Router Class Initialized
INFO - 2019-12-31 14:11:27 --> Output Class Initialized
INFO - 2019-12-31 14:11:27 --> Security Class Initialized
DEBUG - 2019-12-31 14:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:27 --> Input Class Initialized
INFO - 2019-12-31 14:11:27 --> Language Class Initialized
ERROR - 2019-12-31 14:11:27 --> 404 Page Not Found: Bower_components/i18next
INFO - 2019-12-31 14:11:27 --> Config Class Initialized
INFO - 2019-12-31 14:11:27 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:11:27 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:27 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:27 --> URI Class Initialized
INFO - 2019-12-31 14:11:27 --> Router Class Initialized
INFO - 2019-12-31 14:11:27 --> Output Class Initialized
INFO - 2019-12-31 14:11:27 --> Security Class Initialized
DEBUG - 2019-12-31 14:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:27 --> Input Class Initialized
INFO - 2019-12-31 14:11:27 --> Language Class Initialized
ERROR - 2019-12-31 14:11:27 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2019-12-31 14:11:27 --> Config Class Initialized
INFO - 2019-12-31 14:11:27 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:11:27 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:27 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:27 --> URI Class Initialized
INFO - 2019-12-31 14:11:27 --> Router Class Initialized
INFO - 2019-12-31 14:11:27 --> Output Class Initialized
INFO - 2019-12-31 14:11:27 --> Security Class Initialized
DEBUG - 2019-12-31 14:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:27 --> Input Class Initialized
INFO - 2019-12-31 14:11:27 --> Language Class Initialized
ERROR - 2019-12-31 14:11:27 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2019-12-31 14:11:27 --> Config Class Initialized
INFO - 2019-12-31 14:11:27 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:11:27 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:27 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:27 --> URI Class Initialized
INFO - 2019-12-31 14:11:28 --> Router Class Initialized
INFO - 2019-12-31 14:11:28 --> Output Class Initialized
INFO - 2019-12-31 14:11:28 --> Security Class Initialized
DEBUG - 2019-12-31 14:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:28 --> Input Class Initialized
INFO - 2019-12-31 14:11:28 --> Language Class Initialized
ERROR - 2019-12-31 14:11:28 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2019-12-31 14:11:32 --> Config Class Initialized
INFO - 2019-12-31 14:11:32 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:11:32 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:32 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:32 --> URI Class Initialized
INFO - 2019-12-31 14:11:32 --> Router Class Initialized
INFO - 2019-12-31 14:11:32 --> Output Class Initialized
INFO - 2019-12-31 14:11:32 --> Security Class Initialized
DEBUG - 2019-12-31 14:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:32 --> Input Class Initialized
INFO - 2019-12-31 14:11:32 --> Language Class Initialized
INFO - 2019-12-31 14:11:32 --> Loader Class Initialized
INFO - 2019-12-31 14:11:32 --> Helper loaded: url_helper
INFO - 2019-12-31 14:11:32 --> Database Driver Class Initialized
DEBUG - 2019-12-31 14:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 14:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 14:11:32 --> Controller Class Initialized
INFO - 2019-12-31 14:11:32 --> Model "M_login" initialized
INFO - 2019-12-31 14:11:33 --> Model "M_tiket" initialized
INFO - 2019-12-31 14:11:33 --> Helper loaded: form_helper
INFO - 2019-12-31 14:11:33 --> Form Validation Class Initialized
INFO - 2019-12-31 14:11:33 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-31 14:11:33 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/edit_form.php
INFO - 2019-12-31 14:11:33 --> Final output sent to browser
DEBUG - 2019-12-31 14:11:33 --> Total execution time: 0.4607
INFO - 2019-12-31 14:11:40 --> Config Class Initialized
INFO - 2019-12-31 14:11:40 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:11:40 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:40 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:40 --> URI Class Initialized
INFO - 2019-12-31 14:11:40 --> Router Class Initialized
INFO - 2019-12-31 14:11:40 --> Output Class Initialized
INFO - 2019-12-31 14:11:40 --> Security Class Initialized
DEBUG - 2019-12-31 14:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:40 --> Input Class Initialized
INFO - 2019-12-31 14:11:40 --> Language Class Initialized
INFO - 2019-12-31 14:11:40 --> Loader Class Initialized
INFO - 2019-12-31 14:11:40 --> Helper loaded: url_helper
INFO - 2019-12-31 14:11:40 --> Database Driver Class Initialized
DEBUG - 2019-12-31 14:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 14:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 14:11:40 --> Controller Class Initialized
INFO - 2019-12-31 14:11:40 --> Model "M_login" initialized
INFO - 2019-12-31 14:11:40 --> Model "M_tiket" initialized
INFO - 2019-12-31 14:11:40 --> Helper loaded: form_helper
INFO - 2019-12-31 14:11:40 --> Form Validation Class Initialized
INFO - 2019-12-31 14:11:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-12-31 14:11:41 --> Config Class Initialized
INFO - 2019-12-31 14:11:41 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:11:41 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:41 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:41 --> URI Class Initialized
INFO - 2019-12-31 14:11:41 --> Router Class Initialized
INFO - 2019-12-31 14:11:41 --> Output Class Initialized
INFO - 2019-12-31 14:11:41 --> Security Class Initialized
DEBUG - 2019-12-31 14:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:41 --> Input Class Initialized
INFO - 2019-12-31 14:11:41 --> Language Class Initialized
INFO - 2019-12-31 14:11:41 --> Loader Class Initialized
INFO - 2019-12-31 14:11:41 --> Helper loaded: url_helper
INFO - 2019-12-31 14:11:41 --> Database Driver Class Initialized
DEBUG - 2019-12-31 14:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 14:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 14:11:41 --> Controller Class Initialized
INFO - 2019-12-31 14:11:41 --> Model "M_login" initialized
INFO - 2019-12-31 14:11:41 --> Model "M_tiket" initialized
INFO - 2019-12-31 14:11:41 --> Helper loaded: form_helper
INFO - 2019-12-31 14:11:41 --> Form Validation Class Initialized
INFO - 2019-12-31 14:11:41 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-31 14:11:41 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2019-12-31 14:11:41 --> Final output sent to browser
DEBUG - 2019-12-31 14:11:41 --> Total execution time: 0.4567
INFO - 2019-12-31 14:11:41 --> Config Class Initialized
INFO - 2019-12-31 14:11:41 --> Config Class Initialized
INFO - 2019-12-31 14:11:41 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:41 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:41 --> Config Class Initialized
INFO - 2019-12-31 14:11:41 --> Config Class Initialized
INFO - 2019-12-31 14:11:41 --> Config Class Initialized
INFO - 2019-12-31 14:11:41 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:41 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:41 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:11:41 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:11:41 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:41 --> Config Class Initialized
INFO - 2019-12-31 14:11:41 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:41 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:41 --> Utf8 Class Initialized
DEBUG - 2019-12-31 14:11:41 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:11:41 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:11:41 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:41 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:41 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:41 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:41 --> URI Class Initialized
INFO - 2019-12-31 14:11:41 --> URI Class Initialized
DEBUG - 2019-12-31 14:11:41 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:41 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:41 --> URI Class Initialized
INFO - 2019-12-31 14:11:41 --> URI Class Initialized
INFO - 2019-12-31 14:11:41 --> Router Class Initialized
INFO - 2019-12-31 14:11:41 --> Router Class Initialized
INFO - 2019-12-31 14:11:41 --> URI Class Initialized
INFO - 2019-12-31 14:11:41 --> URI Class Initialized
INFO - 2019-12-31 14:11:41 --> Output Class Initialized
INFO - 2019-12-31 14:11:41 --> Router Class Initialized
INFO - 2019-12-31 14:11:41 --> Router Class Initialized
INFO - 2019-12-31 14:11:41 --> Output Class Initialized
INFO - 2019-12-31 14:11:41 --> Router Class Initialized
INFO - 2019-12-31 14:11:41 --> Router Class Initialized
INFO - 2019-12-31 14:11:41 --> Output Class Initialized
INFO - 2019-12-31 14:11:41 --> Security Class Initialized
INFO - 2019-12-31 14:11:41 --> Output Class Initialized
INFO - 2019-12-31 14:11:41 --> Output Class Initialized
INFO - 2019-12-31 14:11:41 --> Security Class Initialized
DEBUG - 2019-12-31 14:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:41 --> Security Class Initialized
INFO - 2019-12-31 14:11:41 --> Security Class Initialized
INFO - 2019-12-31 14:11:41 --> Security Class Initialized
INFO - 2019-12-31 14:11:41 --> Output Class Initialized
INFO - 2019-12-31 14:11:41 --> Input Class Initialized
INFO - 2019-12-31 14:11:41 --> Input Class Initialized
INFO - 2019-12-31 14:11:41 --> Security Class Initialized
DEBUG - 2019-12-31 14:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:41 --> Input Class Initialized
INFO - 2019-12-31 14:11:41 --> Input Class Initialized
INFO - 2019-12-31 14:11:41 --> Input Class Initialized
INFO - 2019-12-31 14:11:41 --> Language Class Initialized
INFO - 2019-12-31 14:11:41 --> Language Class Initialized
DEBUG - 2019-12-31 14:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:42 --> Input Class Initialized
INFO - 2019-12-31 14:11:42 --> Language Class Initialized
ERROR - 2019-12-31 14:11:42 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2019-12-31 14:11:42 --> Language Class Initialized
ERROR - 2019-12-31 14:11:42 --> 404 Page Not Found: Bower_components/jquery
INFO - 2019-12-31 14:11:42 --> Language Class Initialized
INFO - 2019-12-31 14:11:42 --> Language Class Initialized
ERROR - 2019-12-31 14:11:42 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2019-12-31 14:11:42 --> 404 Page Not Found: Bower_components/tether
ERROR - 2019-12-31 14:11:42 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2019-12-31 14:11:42 --> Config Class Initialized
INFO - 2019-12-31 14:11:42 --> Config Class Initialized
ERROR - 2019-12-31 14:11:42 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2019-12-31 14:11:42 --> Config Class Initialized
INFO - 2019-12-31 14:11:42 --> Config Class Initialized
INFO - 2019-12-31 14:11:42 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:42 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:42 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:42 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:42 --> Config Class Initialized
INFO - 2019-12-31 14:11:42 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:42 --> Config Class Initialized
DEBUG - 2019-12-31 14:11:42 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:11:42 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:11:42 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:11:42 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:42 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:42 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:42 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:42 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:42 --> Utf8 Class Initialized
DEBUG - 2019-12-31 14:11:42 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:42 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:42 --> URI Class Initialized
INFO - 2019-12-31 14:11:42 --> URI Class Initialized
INFO - 2019-12-31 14:11:42 --> URI Class Initialized
INFO - 2019-12-31 14:11:42 --> URI Class Initialized
DEBUG - 2019-12-31 14:11:42 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:42 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:42 --> Router Class Initialized
INFO - 2019-12-31 14:11:42 --> URI Class Initialized
INFO - 2019-12-31 14:11:42 --> Router Class Initialized
INFO - 2019-12-31 14:11:42 --> Router Class Initialized
INFO - 2019-12-31 14:11:42 --> Router Class Initialized
INFO - 2019-12-31 14:11:42 --> Router Class Initialized
INFO - 2019-12-31 14:11:42 --> URI Class Initialized
INFO - 2019-12-31 14:11:42 --> Output Class Initialized
INFO - 2019-12-31 14:11:42 --> Output Class Initialized
INFO - 2019-12-31 14:11:42 --> Output Class Initialized
INFO - 2019-12-31 14:11:42 --> Output Class Initialized
INFO - 2019-12-31 14:11:42 --> Router Class Initialized
INFO - 2019-12-31 14:11:42 --> Output Class Initialized
INFO - 2019-12-31 14:11:42 --> Security Class Initialized
INFO - 2019-12-31 14:11:42 --> Security Class Initialized
INFO - 2019-12-31 14:11:42 --> Security Class Initialized
INFO - 2019-12-31 14:11:42 --> Security Class Initialized
DEBUG - 2019-12-31 14:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:42 --> Security Class Initialized
DEBUG - 2019-12-31 14:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:42 --> Output Class Initialized
DEBUG - 2019-12-31 14:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:42 --> Input Class Initialized
INFO - 2019-12-31 14:11:42 --> Input Class Initialized
INFO - 2019-12-31 14:11:42 --> Input Class Initialized
INFO - 2019-12-31 14:11:42 --> Input Class Initialized
INFO - 2019-12-31 14:11:42 --> Security Class Initialized
DEBUG - 2019-12-31 14:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:42 --> Input Class Initialized
INFO - 2019-12-31 14:11:42 --> Language Class Initialized
INFO - 2019-12-31 14:11:42 --> Language Class Initialized
INFO - 2019-12-31 14:11:42 --> Language Class Initialized
INFO - 2019-12-31 14:11:42 --> Language Class Initialized
DEBUG - 2019-12-31 14:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:42 --> Input Class Initialized
INFO - 2019-12-31 14:11:42 --> Language Class Initialized
ERROR - 2019-12-31 14:11:42 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2019-12-31 14:11:42 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2019-12-31 14:11:42 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2019-12-31 14:11:42 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2019-12-31 14:11:42 --> Language Class Initialized
ERROR - 2019-12-31 14:11:42 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2019-12-31 14:11:42 --> Config Class Initialized
INFO - 2019-12-31 14:11:42 --> Config Class Initialized
INFO - 2019-12-31 14:11:42 --> Config Class Initialized
INFO - 2019-12-31 14:11:42 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:42 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:42 --> Hooks Class Initialized
ERROR - 2019-12-31 14:11:42 --> 404 Page Not Found: Bower_components/jquery-i18next
DEBUG - 2019-12-31 14:11:42 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:11:42 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:11:42 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:42 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:42 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:42 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:42 --> URI Class Initialized
INFO - 2019-12-31 14:11:42 --> URI Class Initialized
INFO - 2019-12-31 14:11:42 --> URI Class Initialized
INFO - 2019-12-31 14:11:42 --> Router Class Initialized
INFO - 2019-12-31 14:11:42 --> Router Class Initialized
INFO - 2019-12-31 14:11:42 --> Router Class Initialized
INFO - 2019-12-31 14:11:42 --> Output Class Initialized
INFO - 2019-12-31 14:11:42 --> Output Class Initialized
INFO - 2019-12-31 14:11:42 --> Output Class Initialized
INFO - 2019-12-31 14:11:42 --> Security Class Initialized
INFO - 2019-12-31 14:11:42 --> Security Class Initialized
INFO - 2019-12-31 14:11:42 --> Security Class Initialized
DEBUG - 2019-12-31 14:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:42 --> Input Class Initialized
INFO - 2019-12-31 14:11:42 --> Input Class Initialized
INFO - 2019-12-31 14:11:42 --> Input Class Initialized
INFO - 2019-12-31 14:11:42 --> Language Class Initialized
INFO - 2019-12-31 14:11:42 --> Language Class Initialized
INFO - 2019-12-31 14:11:42 --> Language Class Initialized
ERROR - 2019-12-31 14:11:42 --> 404 Page Not Found: Bower_components/tether
INFO - 2019-12-31 14:11:42 --> Loader Class Initialized
INFO - 2019-12-31 14:11:42 --> Loader Class Initialized
INFO - 2019-12-31 14:11:42 --> Helper loaded: url_helper
INFO - 2019-12-31 14:11:42 --> Helper loaded: url_helper
INFO - 2019-12-31 14:11:42 --> Config Class Initialized
INFO - 2019-12-31 14:11:42 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:42 --> Database Driver Class Initialized
INFO - 2019-12-31 14:11:42 --> Database Driver Class Initialized
DEBUG - 2019-12-31 14:11:42 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-12-31 14:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 14:11:42 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 14:11:42 --> Controller Class Initialized
INFO - 2019-12-31 14:11:42 --> URI Class Initialized
INFO - 2019-12-31 14:11:42 --> Model "M_login" initialized
INFO - 2019-12-31 14:11:42 --> Router Class Initialized
INFO - 2019-12-31 14:11:42 --> Model "M_tiket" initialized
INFO - 2019-12-31 14:11:42 --> Output Class Initialized
INFO - 2019-12-31 14:11:42 --> Security Class Initialized
INFO - 2019-12-31 14:11:42 --> Helper loaded: form_helper
INFO - 2019-12-31 14:11:42 --> Form Validation Class Initialized
DEBUG - 2019-12-31 14:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:42 --> Input Class Initialized
INFO - 2019-12-31 14:11:42 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-31 14:11:42 --> Language Class Initialized
ERROR - 2019-12-31 14:11:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2019-12-31 14:11:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
ERROR - 2019-12-31 14:11:42 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2019-12-31 14:11:42 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2019-12-31 14:11:42 --> Config Class Initialized
INFO - 2019-12-31 14:11:42 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:42 --> Final output sent to browser
DEBUG - 2019-12-31 14:11:42 --> Total execution time: 0.5397
DEBUG - 2019-12-31 14:11:42 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:42 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 14:11:42 --> Controller Class Initialized
INFO - 2019-12-31 14:11:42 --> URI Class Initialized
INFO - 2019-12-31 14:11:42 --> Model "M_login" initialized
INFO - 2019-12-31 14:11:42 --> Router Class Initialized
INFO - 2019-12-31 14:11:42 --> Model "M_tiket" initialized
INFO - 2019-12-31 14:11:42 --> Output Class Initialized
INFO - 2019-12-31 14:11:43 --> Security Class Initialized
INFO - 2019-12-31 14:11:43 --> Helper loaded: form_helper
INFO - 2019-12-31 14:11:43 --> Form Validation Class Initialized
DEBUG - 2019-12-31 14:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:43 --> Input Class Initialized
INFO - 2019-12-31 14:11:43 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2019-12-31 14:11:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2019-12-31 14:11:43 --> Language Class Initialized
ERROR - 2019-12-31 14:11:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
ERROR - 2019-12-31 14:11:43 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2019-12-31 14:11:43 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2019-12-31 14:11:43 --> Config Class Initialized
INFO - 2019-12-31 14:11:43 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:43 --> Final output sent to browser
DEBUG - 2019-12-31 14:11:43 --> Total execution time: 0.7821
DEBUG - 2019-12-31 14:11:43 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:43 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:43 --> URI Class Initialized
INFO - 2019-12-31 14:11:43 --> Router Class Initialized
INFO - 2019-12-31 14:11:43 --> Output Class Initialized
INFO - 2019-12-31 14:11:43 --> Security Class Initialized
DEBUG - 2019-12-31 14:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:43 --> Input Class Initialized
INFO - 2019-12-31 14:11:43 --> Language Class Initialized
ERROR - 2019-12-31 14:11:43 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2019-12-31 14:11:43 --> Config Class Initialized
INFO - 2019-12-31 14:11:43 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:11:43 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:43 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:43 --> URI Class Initialized
INFO - 2019-12-31 14:11:43 --> Router Class Initialized
INFO - 2019-12-31 14:11:43 --> Output Class Initialized
INFO - 2019-12-31 14:11:43 --> Security Class Initialized
DEBUG - 2019-12-31 14:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:43 --> Input Class Initialized
INFO - 2019-12-31 14:11:43 --> Language Class Initialized
ERROR - 2019-12-31 14:11:43 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2019-12-31 14:11:43 --> Config Class Initialized
INFO - 2019-12-31 14:11:43 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:11:43 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:43 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:43 --> URI Class Initialized
INFO - 2019-12-31 14:11:43 --> Router Class Initialized
INFO - 2019-12-31 14:11:43 --> Output Class Initialized
INFO - 2019-12-31 14:11:43 --> Security Class Initialized
DEBUG - 2019-12-31 14:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:43 --> Input Class Initialized
INFO - 2019-12-31 14:11:43 --> Language Class Initialized
ERROR - 2019-12-31 14:11:43 --> 404 Page Not Found: Bower_components/i18next
INFO - 2019-12-31 14:11:43 --> Config Class Initialized
INFO - 2019-12-31 14:11:43 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:11:43 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:43 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:43 --> URI Class Initialized
INFO - 2019-12-31 14:11:43 --> Router Class Initialized
INFO - 2019-12-31 14:11:43 --> Output Class Initialized
INFO - 2019-12-31 14:11:43 --> Security Class Initialized
DEBUG - 2019-12-31 14:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:44 --> Input Class Initialized
INFO - 2019-12-31 14:11:44 --> Language Class Initialized
ERROR - 2019-12-31 14:11:44 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2019-12-31 14:11:44 --> Config Class Initialized
INFO - 2019-12-31 14:11:44 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:11:44 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:44 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:44 --> URI Class Initialized
INFO - 2019-12-31 14:11:44 --> Router Class Initialized
INFO - 2019-12-31 14:11:44 --> Output Class Initialized
INFO - 2019-12-31 14:11:44 --> Security Class Initialized
DEBUG - 2019-12-31 14:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:44 --> Input Class Initialized
INFO - 2019-12-31 14:11:44 --> Language Class Initialized
ERROR - 2019-12-31 14:11:44 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2019-12-31 14:11:44 --> Config Class Initialized
INFO - 2019-12-31 14:11:44 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:11:44 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:44 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:44 --> URI Class Initialized
INFO - 2019-12-31 14:11:44 --> Router Class Initialized
INFO - 2019-12-31 14:11:44 --> Output Class Initialized
INFO - 2019-12-31 14:11:44 --> Security Class Initialized
DEBUG - 2019-12-31 14:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:44 --> Input Class Initialized
INFO - 2019-12-31 14:11:44 --> Language Class Initialized
ERROR - 2019-12-31 14:11:44 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2019-12-31 14:11:47 --> Config Class Initialized
INFO - 2019-12-31 14:11:47 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:11:47 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:47 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:47 --> URI Class Initialized
INFO - 2019-12-31 14:11:47 --> Router Class Initialized
INFO - 2019-12-31 14:11:47 --> Output Class Initialized
INFO - 2019-12-31 14:11:47 --> Security Class Initialized
DEBUG - 2019-12-31 14:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:47 --> Input Class Initialized
INFO - 2019-12-31 14:11:47 --> Language Class Initialized
INFO - 2019-12-31 14:11:47 --> Loader Class Initialized
INFO - 2019-12-31 14:11:47 --> Helper loaded: url_helper
INFO - 2019-12-31 14:11:47 --> Database Driver Class Initialized
DEBUG - 2019-12-31 14:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 14:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 14:11:47 --> Controller Class Initialized
INFO - 2019-12-31 14:11:47 --> Model "M_login" initialized
INFO - 2019-12-31 14:11:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-31 14:11:47 --> Pagination Class Initialized
INFO - 2019-12-31 14:11:47 --> Model "M_show" initialized
INFO - 2019-12-31 14:11:47 --> Helper loaded: form_helper
INFO - 2019-12-31 14:11:47 --> Form Validation Class Initialized
INFO - 2019-12-31 14:11:47 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-31 14:11:47 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/show/lihat_show.php
INFO - 2019-12-31 14:11:47 --> Final output sent to browser
DEBUG - 2019-12-31 14:11:47 --> Total execution time: 0.5372
INFO - 2019-12-31 14:11:47 --> Config Class Initialized
INFO - 2019-12-31 14:11:47 --> Config Class Initialized
INFO - 2019-12-31 14:11:47 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:47 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:11:47 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:11:47 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:47 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:47 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:48 --> URI Class Initialized
INFO - 2019-12-31 14:11:48 --> URI Class Initialized
INFO - 2019-12-31 14:11:48 --> Router Class Initialized
INFO - 2019-12-31 14:11:48 --> Router Class Initialized
INFO - 2019-12-31 14:11:48 --> Output Class Initialized
INFO - 2019-12-31 14:11:48 --> Output Class Initialized
INFO - 2019-12-31 14:11:48 --> Security Class Initialized
INFO - 2019-12-31 14:11:48 --> Security Class Initialized
DEBUG - 2019-12-31 14:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:48 --> Input Class Initialized
INFO - 2019-12-31 14:11:48 --> Input Class Initialized
INFO - 2019-12-31 14:11:48 --> Language Class Initialized
INFO - 2019-12-31 14:11:48 --> Language Class Initialized
ERROR - 2019-12-31 14:11:48 --> 404 Page Not Found: Show/assets
ERROR - 2019-12-31 14:11:48 --> 404 Page Not Found: Show/assets
INFO - 2019-12-31 14:11:56 --> Config Class Initialized
INFO - 2019-12-31 14:11:56 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:11:56 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:57 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:57 --> URI Class Initialized
INFO - 2019-12-31 14:11:57 --> Router Class Initialized
INFO - 2019-12-31 14:11:57 --> Output Class Initialized
INFO - 2019-12-31 14:11:57 --> Security Class Initialized
DEBUG - 2019-12-31 14:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:57 --> Input Class Initialized
INFO - 2019-12-31 14:11:57 --> Language Class Initialized
INFO - 2019-12-31 14:11:57 --> Loader Class Initialized
INFO - 2019-12-31 14:11:57 --> Helper loaded: url_helper
INFO - 2019-12-31 14:11:57 --> Database Driver Class Initialized
DEBUG - 2019-12-31 14:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 14:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 14:11:57 --> Controller Class Initialized
INFO - 2019-12-31 14:11:57 --> Model "M_login" initialized
INFO - 2019-12-31 14:11:57 --> Model "M_tiket" initialized
INFO - 2019-12-31 14:11:57 --> Helper loaded: form_helper
INFO - 2019-12-31 14:11:57 --> Form Validation Class Initialized
INFO - 2019-12-31 14:11:57 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-31 14:11:57 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2019-12-31 14:11:57 --> Final output sent to browser
DEBUG - 2019-12-31 14:11:57 --> Total execution time: 0.5533
INFO - 2019-12-31 14:11:57 --> Config Class Initialized
INFO - 2019-12-31 14:11:57 --> Config Class Initialized
INFO - 2019-12-31 14:11:57 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:57 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:57 --> Config Class Initialized
INFO - 2019-12-31 14:11:57 --> Config Class Initialized
INFO - 2019-12-31 14:11:57 --> Config Class Initialized
INFO - 2019-12-31 14:11:57 --> Config Class Initialized
INFO - 2019-12-31 14:11:57 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:57 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:57 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:57 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:11:57 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:11:57 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:57 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:57 --> Utf8 Class Initialized
DEBUG - 2019-12-31 14:11:57 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:11:57 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:11:57 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:11:57 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:57 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:57 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:57 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:57 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:57 --> URI Class Initialized
INFO - 2019-12-31 14:11:57 --> URI Class Initialized
INFO - 2019-12-31 14:11:57 --> URI Class Initialized
INFO - 2019-12-31 14:11:57 --> URI Class Initialized
INFO - 2019-12-31 14:11:57 --> URI Class Initialized
INFO - 2019-12-31 14:11:57 --> Router Class Initialized
INFO - 2019-12-31 14:11:57 --> URI Class Initialized
INFO - 2019-12-31 14:11:57 --> Router Class Initialized
INFO - 2019-12-31 14:11:57 --> Router Class Initialized
INFO - 2019-12-31 14:11:57 --> Router Class Initialized
INFO - 2019-12-31 14:11:57 --> Router Class Initialized
INFO - 2019-12-31 14:11:57 --> Output Class Initialized
INFO - 2019-12-31 14:11:57 --> Router Class Initialized
INFO - 2019-12-31 14:11:57 --> Output Class Initialized
INFO - 2019-12-31 14:11:57 --> Security Class Initialized
INFO - 2019-12-31 14:11:57 --> Output Class Initialized
INFO - 2019-12-31 14:11:57 --> Output Class Initialized
INFO - 2019-12-31 14:11:57 --> Output Class Initialized
INFO - 2019-12-31 14:11:57 --> Security Class Initialized
INFO - 2019-12-31 14:11:57 --> Output Class Initialized
DEBUG - 2019-12-31 14:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:57 --> Security Class Initialized
INFO - 2019-12-31 14:11:57 --> Security Class Initialized
INFO - 2019-12-31 14:11:57 --> Security Class Initialized
INFO - 2019-12-31 14:11:57 --> Security Class Initialized
DEBUG - 2019-12-31 14:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:57 --> Input Class Initialized
INFO - 2019-12-31 14:11:57 --> Input Class Initialized
DEBUG - 2019-12-31 14:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:57 --> Input Class Initialized
INFO - 2019-12-31 14:11:57 --> Input Class Initialized
INFO - 2019-12-31 14:11:57 --> Input Class Initialized
INFO - 2019-12-31 14:11:57 --> Language Class Initialized
INFO - 2019-12-31 14:11:57 --> Language Class Initialized
INFO - 2019-12-31 14:11:57 --> Input Class Initialized
INFO - 2019-12-31 14:11:57 --> Language Class Initialized
INFO - 2019-12-31 14:11:57 --> Language Class Initialized
INFO - 2019-12-31 14:11:57 --> Language Class Initialized
ERROR - 2019-12-31 14:11:57 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2019-12-31 14:11:57 --> 404 Page Not Found: Bower_components/jquery
INFO - 2019-12-31 14:11:57 --> Language Class Initialized
ERROR - 2019-12-31 14:11:57 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2019-12-31 14:11:57 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2019-12-31 14:11:57 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2019-12-31 14:11:57 --> 404 Page Not Found: Bower_components/tether
INFO - 2019-12-31 14:11:57 --> Config Class Initialized
INFO - 2019-12-31 14:11:57 --> Config Class Initialized
INFO - 2019-12-31 14:11:57 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:57 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:57 --> Config Class Initialized
INFO - 2019-12-31 14:11:57 --> Config Class Initialized
INFO - 2019-12-31 14:11:57 --> Config Class Initialized
INFO - 2019-12-31 14:11:57 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:57 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:57 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:11:57 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:11:57 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:57 --> Config Class Initialized
INFO - 2019-12-31 14:11:57 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:57 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:57 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:11:57 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:11:57 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:11:57 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:58 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:58 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:58 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:58 --> URI Class Initialized
INFO - 2019-12-31 14:11:58 --> URI Class Initialized
DEBUG - 2019-12-31 14:11:58 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:58 --> URI Class Initialized
INFO - 2019-12-31 14:11:58 --> URI Class Initialized
INFO - 2019-12-31 14:11:58 --> URI Class Initialized
INFO - 2019-12-31 14:11:58 --> Router Class Initialized
INFO - 2019-12-31 14:11:58 --> Router Class Initialized
INFO - 2019-12-31 14:11:58 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:58 --> Router Class Initialized
INFO - 2019-12-31 14:11:58 --> Output Class Initialized
INFO - 2019-12-31 14:11:58 --> Output Class Initialized
INFO - 2019-12-31 14:11:58 --> Router Class Initialized
INFO - 2019-12-31 14:11:58 --> URI Class Initialized
INFO - 2019-12-31 14:11:58 --> Router Class Initialized
INFO - 2019-12-31 14:11:58 --> Security Class Initialized
INFO - 2019-12-31 14:11:58 --> Router Class Initialized
INFO - 2019-12-31 14:11:58 --> Output Class Initialized
INFO - 2019-12-31 14:11:58 --> Output Class Initialized
INFO - 2019-12-31 14:11:58 --> Security Class Initialized
INFO - 2019-12-31 14:11:58 --> Output Class Initialized
INFO - 2019-12-31 14:11:58 --> Security Class Initialized
INFO - 2019-12-31 14:11:58 --> Security Class Initialized
DEBUG - 2019-12-31 14:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:58 --> Output Class Initialized
INFO - 2019-12-31 14:11:58 --> Security Class Initialized
DEBUG - 2019-12-31 14:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:58 --> Input Class Initialized
DEBUG - 2019-12-31 14:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:58 --> Security Class Initialized
INFO - 2019-12-31 14:11:58 --> Input Class Initialized
INFO - 2019-12-31 14:11:58 --> Input Class Initialized
INFO - 2019-12-31 14:11:58 --> Input Class Initialized
INFO - 2019-12-31 14:11:58 --> Input Class Initialized
INFO - 2019-12-31 14:11:58 --> Language Class Initialized
INFO - 2019-12-31 14:11:58 --> Language Class Initialized
DEBUG - 2019-12-31 14:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:58 --> Input Class Initialized
INFO - 2019-12-31 14:11:58 --> Language Class Initialized
INFO - 2019-12-31 14:11:58 --> Language Class Initialized
INFO - 2019-12-31 14:11:58 --> Language Class Initialized
ERROR - 2019-12-31 14:11:58 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2019-12-31 14:11:58 --> 404 Page Not Found: Bower_components/i18next
INFO - 2019-12-31 14:11:58 --> Language Class Initialized
ERROR - 2019-12-31 14:11:58 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2019-12-31 14:11:58 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2019-12-31 14:11:58 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2019-12-31 14:11:58 --> Config Class Initialized
INFO - 2019-12-31 14:11:58 --> Config Class Initialized
INFO - 2019-12-31 14:11:58 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:58 --> Hooks Class Initialized
ERROR - 2019-12-31 14:11:58 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2019-12-31 14:11:58 --> Config Class Initialized
DEBUG - 2019-12-31 14:11:58 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:11:58 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:58 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:58 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:58 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:58 --> URI Class Initialized
INFO - 2019-12-31 14:11:58 --> URI Class Initialized
DEBUG - 2019-12-31 14:11:58 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:58 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:58 --> Router Class Initialized
INFO - 2019-12-31 14:11:58 --> Router Class Initialized
INFO - 2019-12-31 14:11:58 --> URI Class Initialized
INFO - 2019-12-31 14:11:58 --> Output Class Initialized
INFO - 2019-12-31 14:11:58 --> Output Class Initialized
INFO - 2019-12-31 14:11:58 --> Router Class Initialized
INFO - 2019-12-31 14:11:58 --> Security Class Initialized
INFO - 2019-12-31 14:11:58 --> Security Class Initialized
DEBUG - 2019-12-31 14:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:58 --> Output Class Initialized
INFO - 2019-12-31 14:11:58 --> Input Class Initialized
INFO - 2019-12-31 14:11:58 --> Input Class Initialized
INFO - 2019-12-31 14:11:58 --> Security Class Initialized
INFO - 2019-12-31 14:11:58 --> Language Class Initialized
INFO - 2019-12-31 14:11:58 --> Language Class Initialized
DEBUG - 2019-12-31 14:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:58 --> Input Class Initialized
INFO - 2019-12-31 14:11:58 --> Loader Class Initialized
INFO - 2019-12-31 14:11:58 --> Loader Class Initialized
INFO - 2019-12-31 14:11:58 --> Language Class Initialized
INFO - 2019-12-31 14:11:58 --> Helper loaded: url_helper
INFO - 2019-12-31 14:11:58 --> Helper loaded: url_helper
ERROR - 2019-12-31 14:11:58 --> 404 Page Not Found: Bower_components/tether
INFO - 2019-12-31 14:11:58 --> Database Driver Class Initialized
INFO - 2019-12-31 14:11:58 --> Database Driver Class Initialized
DEBUG - 2019-12-31 14:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-12-31 14:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 14:11:58 --> Config Class Initialized
INFO - 2019-12-31 14:11:58 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 14:11:58 --> Controller Class Initialized
DEBUG - 2019-12-31 14:11:58 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:58 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:58 --> Model "M_login" initialized
INFO - 2019-12-31 14:11:58 --> Model "M_tiket" initialized
INFO - 2019-12-31 14:11:58 --> URI Class Initialized
INFO - 2019-12-31 14:11:58 --> Router Class Initialized
INFO - 2019-12-31 14:11:58 --> Helper loaded: form_helper
INFO - 2019-12-31 14:11:58 --> Form Validation Class Initialized
INFO - 2019-12-31 14:11:58 --> Output Class Initialized
INFO - 2019-12-31 14:11:58 --> Security Class Initialized
INFO - 2019-12-31 14:11:58 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2019-12-31 14:11:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2019-12-31 14:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:58 --> Input Class Initialized
ERROR - 2019-12-31 14:11:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
INFO - 2019-12-31 14:11:58 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2019-12-31 14:11:58 --> Language Class Initialized
INFO - 2019-12-31 14:11:58 --> Final output sent to browser
ERROR - 2019-12-31 14:11:58 --> 404 Page Not Found: Bower_components/bootstrap
DEBUG - 2019-12-31 14:11:58 --> Total execution time: 0.5711
INFO - 2019-12-31 14:11:58 --> Config Class Initialized
INFO - 2019-12-31 14:11:58 --> Hooks Class Initialized
INFO - 2019-12-31 14:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 14:11:58 --> Controller Class Initialized
DEBUG - 2019-12-31 14:11:58 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:58 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:58 --> Model "M_login" initialized
INFO - 2019-12-31 14:11:58 --> Model "M_tiket" initialized
INFO - 2019-12-31 14:11:58 --> URI Class Initialized
INFO - 2019-12-31 14:11:58 --> Router Class Initialized
INFO - 2019-12-31 14:11:58 --> Helper loaded: form_helper
INFO - 2019-12-31 14:11:58 --> Form Validation Class Initialized
INFO - 2019-12-31 14:11:58 --> Output Class Initialized
INFO - 2019-12-31 14:11:58 --> Security Class Initialized
INFO - 2019-12-31 14:11:58 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2019-12-31 14:11:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2019-12-31 14:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:58 --> Input Class Initialized
ERROR - 2019-12-31 14:11:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
INFO - 2019-12-31 14:11:59 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2019-12-31 14:11:59 --> Language Class Initialized
INFO - 2019-12-31 14:11:59 --> Final output sent to browser
ERROR - 2019-12-31 14:11:59 --> 404 Page Not Found: Bower_components/jquery-slimscroll
DEBUG - 2019-12-31 14:11:59 --> Total execution time: 0.8035
INFO - 2019-12-31 14:11:59 --> Config Class Initialized
INFO - 2019-12-31 14:11:59 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:11:59 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:59 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:59 --> URI Class Initialized
INFO - 2019-12-31 14:11:59 --> Router Class Initialized
INFO - 2019-12-31 14:11:59 --> Output Class Initialized
INFO - 2019-12-31 14:11:59 --> Security Class Initialized
DEBUG - 2019-12-31 14:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:59 --> Input Class Initialized
INFO - 2019-12-31 14:11:59 --> Language Class Initialized
ERROR - 2019-12-31 14:11:59 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2019-12-31 14:11:59 --> Config Class Initialized
INFO - 2019-12-31 14:11:59 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:11:59 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:59 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:59 --> URI Class Initialized
INFO - 2019-12-31 14:11:59 --> Router Class Initialized
INFO - 2019-12-31 14:11:59 --> Output Class Initialized
INFO - 2019-12-31 14:11:59 --> Security Class Initialized
DEBUG - 2019-12-31 14:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:59 --> Input Class Initialized
INFO - 2019-12-31 14:11:59 --> Language Class Initialized
ERROR - 2019-12-31 14:11:59 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2019-12-31 14:11:59 --> Config Class Initialized
INFO - 2019-12-31 14:11:59 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:11:59 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:59 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:59 --> URI Class Initialized
INFO - 2019-12-31 14:11:59 --> Router Class Initialized
INFO - 2019-12-31 14:11:59 --> Output Class Initialized
INFO - 2019-12-31 14:11:59 --> Security Class Initialized
DEBUG - 2019-12-31 14:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:59 --> Input Class Initialized
INFO - 2019-12-31 14:11:59 --> Language Class Initialized
ERROR - 2019-12-31 14:11:59 --> 404 Page Not Found: Bower_components/i18next
INFO - 2019-12-31 14:11:59 --> Config Class Initialized
INFO - 2019-12-31 14:11:59 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:11:59 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:11:59 --> Utf8 Class Initialized
INFO - 2019-12-31 14:11:59 --> URI Class Initialized
INFO - 2019-12-31 14:11:59 --> Router Class Initialized
INFO - 2019-12-31 14:11:59 --> Output Class Initialized
INFO - 2019-12-31 14:11:59 --> Security Class Initialized
DEBUG - 2019-12-31 14:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:11:59 --> Input Class Initialized
INFO - 2019-12-31 14:11:59 --> Language Class Initialized
ERROR - 2019-12-31 14:11:59 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2019-12-31 14:12:00 --> Config Class Initialized
INFO - 2019-12-31 14:12:00 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:00 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:00 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:00 --> URI Class Initialized
INFO - 2019-12-31 14:12:00 --> Router Class Initialized
INFO - 2019-12-31 14:12:00 --> Output Class Initialized
INFO - 2019-12-31 14:12:00 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:00 --> Input Class Initialized
INFO - 2019-12-31 14:12:00 --> Language Class Initialized
ERROR - 2019-12-31 14:12:00 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2019-12-31 14:12:00 --> Config Class Initialized
INFO - 2019-12-31 14:12:00 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:00 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:00 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:00 --> URI Class Initialized
INFO - 2019-12-31 14:12:00 --> Router Class Initialized
INFO - 2019-12-31 14:12:00 --> Output Class Initialized
INFO - 2019-12-31 14:12:00 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:00 --> Input Class Initialized
INFO - 2019-12-31 14:12:00 --> Language Class Initialized
ERROR - 2019-12-31 14:12:00 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2019-12-31 14:12:07 --> Config Class Initialized
INFO - 2019-12-31 14:12:07 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:07 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:07 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:07 --> URI Class Initialized
INFO - 2019-12-31 14:12:07 --> Router Class Initialized
INFO - 2019-12-31 14:12:07 --> Output Class Initialized
INFO - 2019-12-31 14:12:07 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:07 --> Input Class Initialized
INFO - 2019-12-31 14:12:07 --> Language Class Initialized
INFO - 2019-12-31 14:12:07 --> Loader Class Initialized
INFO - 2019-12-31 14:12:07 --> Helper loaded: url_helper
INFO - 2019-12-31 14:12:07 --> Database Driver Class Initialized
DEBUG - 2019-12-31 14:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 14:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 14:12:07 --> Controller Class Initialized
INFO - 2019-12-31 14:12:07 --> Model "M_login" initialized
INFO - 2019-12-31 14:12:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-31 14:12:07 --> Pagination Class Initialized
INFO - 2019-12-31 14:12:07 --> Model "M_show" initialized
INFO - 2019-12-31 14:12:07 --> Helper loaded: form_helper
INFO - 2019-12-31 14:12:07 --> Form Validation Class Initialized
INFO - 2019-12-31 14:12:07 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-31 14:12:07 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/show/lihat_show.php
INFO - 2019-12-31 14:12:07 --> Final output sent to browser
DEBUG - 2019-12-31 14:12:08 --> Total execution time: 0.6555
INFO - 2019-12-31 14:12:15 --> Config Class Initialized
INFO - 2019-12-31 14:12:15 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:15 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:15 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:15 --> URI Class Initialized
INFO - 2019-12-31 14:12:15 --> Router Class Initialized
INFO - 2019-12-31 14:12:15 --> Output Class Initialized
INFO - 2019-12-31 14:12:15 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:15 --> Input Class Initialized
INFO - 2019-12-31 14:12:15 --> Language Class Initialized
INFO - 2019-12-31 14:12:15 --> Loader Class Initialized
INFO - 2019-12-31 14:12:15 --> Helper loaded: url_helper
INFO - 2019-12-31 14:12:15 --> Database Driver Class Initialized
DEBUG - 2019-12-31 14:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 14:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 14:12:15 --> Controller Class Initialized
INFO - 2019-12-31 14:12:15 --> Model "M_login" initialized
INFO - 2019-12-31 14:12:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-31 14:12:15 --> Pagination Class Initialized
INFO - 2019-12-31 14:12:15 --> Model "M_show" initialized
INFO - 2019-12-31 14:12:15 --> Helper loaded: form_helper
INFO - 2019-12-31 14:12:15 --> Form Validation Class Initialized
INFO - 2019-12-31 14:12:16 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-31 14:12:16 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/show/edit_show.php
INFO - 2019-12-31 14:12:16 --> Final output sent to browser
DEBUG - 2019-12-31 14:12:16 --> Total execution time: 0.6779
INFO - 2019-12-31 14:12:16 --> Config Class Initialized
INFO - 2019-12-31 14:12:16 --> Config Class Initialized
INFO - 2019-12-31 14:12:16 --> Config Class Initialized
INFO - 2019-12-31 14:12:16 --> Config Class Initialized
INFO - 2019-12-31 14:12:16 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:16 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:16 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:16 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:16 --> Config Class Initialized
INFO - 2019-12-31 14:12:16 --> Config Class Initialized
INFO - 2019-12-31 14:12:16 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:16 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:16 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:16 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:12:16 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:12:16 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:16 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:16 --> Utf8 Class Initialized
DEBUG - 2019-12-31 14:12:16 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:16 --> Utf8 Class Initialized
DEBUG - 2019-12-31 14:12:16 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:16 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:16 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:16 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:16 --> URI Class Initialized
INFO - 2019-12-31 14:12:16 --> URI Class Initialized
INFO - 2019-12-31 14:12:16 --> URI Class Initialized
INFO - 2019-12-31 14:12:16 --> URI Class Initialized
INFO - 2019-12-31 14:12:16 --> Router Class Initialized
INFO - 2019-12-31 14:12:16 --> Router Class Initialized
INFO - 2019-12-31 14:12:16 --> URI Class Initialized
INFO - 2019-12-31 14:12:16 --> Router Class Initialized
INFO - 2019-12-31 14:12:16 --> URI Class Initialized
INFO - 2019-12-31 14:12:16 --> Router Class Initialized
INFO - 2019-12-31 14:12:16 --> Output Class Initialized
INFO - 2019-12-31 14:12:16 --> Output Class Initialized
INFO - 2019-12-31 14:12:16 --> Router Class Initialized
INFO - 2019-12-31 14:12:16 --> Router Class Initialized
INFO - 2019-12-31 14:12:16 --> Output Class Initialized
INFO - 2019-12-31 14:12:16 --> Security Class Initialized
INFO - 2019-12-31 14:12:16 --> Security Class Initialized
INFO - 2019-12-31 14:12:16 --> Output Class Initialized
INFO - 2019-12-31 14:12:16 --> Output Class Initialized
INFO - 2019-12-31 14:12:16 --> Security Class Initialized
INFO - 2019-12-31 14:12:16 --> Output Class Initialized
INFO - 2019-12-31 14:12:16 --> Security Class Initialized
INFO - 2019-12-31 14:12:16 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:16 --> Security Class Initialized
INFO - 2019-12-31 14:12:16 --> Input Class Initialized
INFO - 2019-12-31 14:12:16 --> Input Class Initialized
INFO - 2019-12-31 14:12:16 --> Input Class Initialized
DEBUG - 2019-12-31 14:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:16 --> Input Class Initialized
INFO - 2019-12-31 14:12:16 --> Input Class Initialized
INFO - 2019-12-31 14:12:16 --> Input Class Initialized
INFO - 2019-12-31 14:12:16 --> Language Class Initialized
INFO - 2019-12-31 14:12:16 --> Language Class Initialized
INFO - 2019-12-31 14:12:16 --> Language Class Initialized
INFO - 2019-12-31 14:12:16 --> Language Class Initialized
INFO - 2019-12-31 14:12:16 --> Language Class Initialized
ERROR - 2019-12-31 14:12:16 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2019-12-31 14:12:16 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2019-12-31 14:12:16 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2019-12-31 14:12:16 --> Language Class Initialized
ERROR - 2019-12-31 14:12:16 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2019-12-31 14:12:16 --> 404 Page Not Found: Bower_components/tether
ERROR - 2019-12-31 14:12:16 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2019-12-31 14:12:16 --> Config Class Initialized
INFO - 2019-12-31 14:12:16 --> Config Class Initialized
INFO - 2019-12-31 14:12:16 --> Config Class Initialized
INFO - 2019-12-31 14:12:16 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:16 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:16 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:16 --> Config Class Initialized
INFO - 2019-12-31 14:12:16 --> Config Class Initialized
INFO - 2019-12-31 14:12:16 --> Config Class Initialized
INFO - 2019-12-31 14:12:16 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:16 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:16 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:16 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:12:16 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:12:16 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:16 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:16 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:16 --> Utf8 Class Initialized
DEBUG - 2019-12-31 14:12:16 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:12:16 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:12:16 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:16 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:16 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:16 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:16 --> URI Class Initialized
INFO - 2019-12-31 14:12:16 --> URI Class Initialized
INFO - 2019-12-31 14:12:16 --> URI Class Initialized
INFO - 2019-12-31 14:12:16 --> URI Class Initialized
INFO - 2019-12-31 14:12:16 --> URI Class Initialized
INFO - 2019-12-31 14:12:16 --> URI Class Initialized
INFO - 2019-12-31 14:12:16 --> Router Class Initialized
INFO - 2019-12-31 14:12:16 --> Router Class Initialized
INFO - 2019-12-31 14:12:16 --> Router Class Initialized
INFO - 2019-12-31 14:12:16 --> Router Class Initialized
INFO - 2019-12-31 14:12:16 --> Router Class Initialized
INFO - 2019-12-31 14:12:16 --> Router Class Initialized
INFO - 2019-12-31 14:12:16 --> Output Class Initialized
INFO - 2019-12-31 14:12:16 --> Output Class Initialized
INFO - 2019-12-31 14:12:16 --> Output Class Initialized
INFO - 2019-12-31 14:12:16 --> Output Class Initialized
INFO - 2019-12-31 14:12:16 --> Output Class Initialized
INFO - 2019-12-31 14:12:16 --> Security Class Initialized
INFO - 2019-12-31 14:12:16 --> Security Class Initialized
INFO - 2019-12-31 14:12:16 --> Output Class Initialized
INFO - 2019-12-31 14:12:16 --> Security Class Initialized
INFO - 2019-12-31 14:12:16 --> Security Class Initialized
INFO - 2019-12-31 14:12:16 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:16 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:16 --> Input Class Initialized
INFO - 2019-12-31 14:12:16 --> Input Class Initialized
DEBUG - 2019-12-31 14:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:16 --> Input Class Initialized
DEBUG - 2019-12-31 14:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:16 --> Input Class Initialized
INFO - 2019-12-31 14:12:16 --> Input Class Initialized
INFO - 2019-12-31 14:12:16 --> Input Class Initialized
INFO - 2019-12-31 14:12:16 --> Language Class Initialized
INFO - 2019-12-31 14:12:16 --> Language Class Initialized
INFO - 2019-12-31 14:12:16 --> Language Class Initialized
INFO - 2019-12-31 14:12:16 --> Language Class Initialized
INFO - 2019-12-31 14:12:16 --> Language Class Initialized
ERROR - 2019-12-31 14:12:16 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2019-12-31 14:12:16 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2019-12-31 14:12:16 --> Language Class Initialized
ERROR - 2019-12-31 14:12:16 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2019-12-31 14:12:16 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2019-12-31 14:12:16 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2019-12-31 14:12:16 --> Loader Class Initialized
INFO - 2019-12-31 14:12:16 --> Config Class Initialized
INFO - 2019-12-31 14:12:16 --> Config Class Initialized
INFO - 2019-12-31 14:12:16 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:16 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:16 --> Helper loaded: url_helper
DEBUG - 2019-12-31 14:12:16 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:12:16 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:16 --> Database Driver Class Initialized
INFO - 2019-12-31 14:12:16 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:16 --> Utf8 Class Initialized
DEBUG - 2019-12-31 14:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 14:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 14:12:16 --> URI Class Initialized
INFO - 2019-12-31 14:12:16 --> URI Class Initialized
INFO - 2019-12-31 14:12:16 --> Controller Class Initialized
INFO - 2019-12-31 14:12:16 --> Router Class Initialized
INFO - 2019-12-31 14:12:16 --> Router Class Initialized
INFO - 2019-12-31 14:12:16 --> Model "M_login" initialized
INFO - 2019-12-31 14:12:16 --> Output Class Initialized
INFO - 2019-12-31 14:12:16 --> Output Class Initialized
INFO - 2019-12-31 14:12:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-31 14:12:16 --> Security Class Initialized
INFO - 2019-12-31 14:12:16 --> Security Class Initialized
INFO - 2019-12-31 14:12:17 --> Pagination Class Initialized
DEBUG - 2019-12-31 14:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:17 --> Input Class Initialized
INFO - 2019-12-31 14:12:17 --> Input Class Initialized
INFO - 2019-12-31 14:12:17 --> Model "M_show" initialized
INFO - 2019-12-31 14:12:17 --> Language Class Initialized
INFO - 2019-12-31 14:12:17 --> Language Class Initialized
INFO - 2019-12-31 14:12:17 --> Helper loaded: form_helper
INFO - 2019-12-31 14:12:17 --> Form Validation Class Initialized
INFO - 2019-12-31 14:12:17 --> Loader Class Initialized
ERROR - 2019-12-31 14:12:17 --> 404 Page Not Found: Bower_components/tether
INFO - 2019-12-31 14:12:17 --> Helper loaded: url_helper
ERROR - 2019-12-31 14:12:17 --> 404 Page Not Found: 
INFO - 2019-12-31 14:12:17 --> Database Driver Class Initialized
INFO - 2019-12-31 14:12:17 --> Config Class Initialized
INFO - 2019-12-31 14:12:17 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 14:12:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-12-31 14:12:17 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:17 --> Controller Class Initialized
INFO - 2019-12-31 14:12:17 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:17 --> Model "M_login" initialized
INFO - 2019-12-31 14:12:17 --> URI Class Initialized
INFO - 2019-12-31 14:12:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-31 14:12:17 --> Router Class Initialized
INFO - 2019-12-31 14:12:17 --> Pagination Class Initialized
INFO - 2019-12-31 14:12:17 --> Output Class Initialized
INFO - 2019-12-31 14:12:17 --> Model "M_show" initialized
INFO - 2019-12-31 14:12:17 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:17 --> Helper loaded: form_helper
INFO - 2019-12-31 14:12:17 --> Input Class Initialized
INFO - 2019-12-31 14:12:17 --> Form Validation Class Initialized
INFO - 2019-12-31 14:12:17 --> Language Class Initialized
ERROR - 2019-12-31 14:12:17 --> 404 Page Not Found: 
ERROR - 2019-12-31 14:12:17 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2019-12-31 14:12:17 --> Config Class Initialized
INFO - 2019-12-31 14:12:17 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:17 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:17 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:17 --> URI Class Initialized
INFO - 2019-12-31 14:12:17 --> Router Class Initialized
INFO - 2019-12-31 14:12:17 --> Output Class Initialized
INFO - 2019-12-31 14:12:17 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:17 --> Input Class Initialized
INFO - 2019-12-31 14:12:17 --> Language Class Initialized
ERROR - 2019-12-31 14:12:17 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2019-12-31 14:12:17 --> Config Class Initialized
INFO - 2019-12-31 14:12:17 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:17 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:17 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:17 --> URI Class Initialized
INFO - 2019-12-31 14:12:17 --> Router Class Initialized
INFO - 2019-12-31 14:12:17 --> Output Class Initialized
INFO - 2019-12-31 14:12:17 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:18 --> Input Class Initialized
INFO - 2019-12-31 14:12:18 --> Language Class Initialized
ERROR - 2019-12-31 14:12:18 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2019-12-31 14:12:18 --> Config Class Initialized
INFO - 2019-12-31 14:12:18 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:18 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:18 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:18 --> URI Class Initialized
INFO - 2019-12-31 14:12:18 --> Router Class Initialized
INFO - 2019-12-31 14:12:18 --> Output Class Initialized
INFO - 2019-12-31 14:12:18 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:18 --> Input Class Initialized
INFO - 2019-12-31 14:12:18 --> Language Class Initialized
ERROR - 2019-12-31 14:12:18 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2019-12-31 14:12:18 --> Config Class Initialized
INFO - 2019-12-31 14:12:18 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:18 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:18 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:18 --> URI Class Initialized
INFO - 2019-12-31 14:12:18 --> Router Class Initialized
INFO - 2019-12-31 14:12:18 --> Output Class Initialized
INFO - 2019-12-31 14:12:18 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:18 --> Input Class Initialized
INFO - 2019-12-31 14:12:18 --> Language Class Initialized
ERROR - 2019-12-31 14:12:18 --> 404 Page Not Found: Bower_components/i18next
INFO - 2019-12-31 14:12:18 --> Config Class Initialized
INFO - 2019-12-31 14:12:18 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:18 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:18 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:18 --> URI Class Initialized
INFO - 2019-12-31 14:12:18 --> Router Class Initialized
INFO - 2019-12-31 14:12:18 --> Output Class Initialized
INFO - 2019-12-31 14:12:18 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:18 --> Input Class Initialized
INFO - 2019-12-31 14:12:18 --> Language Class Initialized
ERROR - 2019-12-31 14:12:19 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2019-12-31 14:12:19 --> Config Class Initialized
INFO - 2019-12-31 14:12:19 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:19 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:19 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:19 --> URI Class Initialized
INFO - 2019-12-31 14:12:19 --> Router Class Initialized
INFO - 2019-12-31 14:12:19 --> Output Class Initialized
INFO - 2019-12-31 14:12:19 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:19 --> Input Class Initialized
INFO - 2019-12-31 14:12:19 --> Language Class Initialized
ERROR - 2019-12-31 14:12:19 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2019-12-31 14:12:19 --> Config Class Initialized
INFO - 2019-12-31 14:12:19 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:19 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:19 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:19 --> URI Class Initialized
INFO - 2019-12-31 14:12:19 --> Router Class Initialized
INFO - 2019-12-31 14:12:19 --> Output Class Initialized
INFO - 2019-12-31 14:12:19 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:19 --> Input Class Initialized
INFO - 2019-12-31 14:12:19 --> Language Class Initialized
ERROR - 2019-12-31 14:12:19 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2019-12-31 14:12:19 --> Config Class Initialized
INFO - 2019-12-31 14:12:19 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:19 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:19 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:19 --> URI Class Initialized
INFO - 2019-12-31 14:12:19 --> Router Class Initialized
INFO - 2019-12-31 14:12:19 --> Output Class Initialized
INFO - 2019-12-31 14:12:19 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:19 --> Input Class Initialized
INFO - 2019-12-31 14:12:19 --> Language Class Initialized
INFO - 2019-12-31 14:12:19 --> Loader Class Initialized
INFO - 2019-12-31 14:12:19 --> Helper loaded: url_helper
INFO - 2019-12-31 14:12:19 --> Database Driver Class Initialized
DEBUG - 2019-12-31 14:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 14:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 14:12:20 --> Controller Class Initialized
INFO - 2019-12-31 14:12:20 --> Model "M_login" initialized
INFO - 2019-12-31 14:12:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-31 14:12:20 --> Pagination Class Initialized
INFO - 2019-12-31 14:12:20 --> Model "M_show" initialized
INFO - 2019-12-31 14:12:20 --> Helper loaded: form_helper
INFO - 2019-12-31 14:12:20 --> Form Validation Class Initialized
ERROR - 2019-12-31 14:12:20 --> 404 Page Not Found: 
INFO - 2019-12-31 14:12:20 --> Config Class Initialized
INFO - 2019-12-31 14:12:20 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:20 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:20 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:20 --> URI Class Initialized
INFO - 2019-12-31 14:12:20 --> Router Class Initialized
INFO - 2019-12-31 14:12:20 --> Output Class Initialized
INFO - 2019-12-31 14:12:20 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:20 --> Input Class Initialized
INFO - 2019-12-31 14:12:20 --> Language Class Initialized
INFO - 2019-12-31 14:12:20 --> Loader Class Initialized
INFO - 2019-12-31 14:12:20 --> Helper loaded: url_helper
INFO - 2019-12-31 14:12:20 --> Database Driver Class Initialized
DEBUG - 2019-12-31 14:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 14:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 14:12:20 --> Controller Class Initialized
INFO - 2019-12-31 14:12:20 --> Model "M_login" initialized
INFO - 2019-12-31 14:12:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-31 14:12:20 --> Pagination Class Initialized
INFO - 2019-12-31 14:12:20 --> Model "M_show" initialized
INFO - 2019-12-31 14:12:20 --> Helper loaded: form_helper
INFO - 2019-12-31 14:12:20 --> Form Validation Class Initialized
ERROR - 2019-12-31 14:12:20 --> 404 Page Not Found: 
INFO - 2019-12-31 14:12:24 --> Config Class Initialized
INFO - 2019-12-31 14:12:24 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:24 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:24 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:24 --> URI Class Initialized
INFO - 2019-12-31 14:12:24 --> Router Class Initialized
INFO - 2019-12-31 14:12:24 --> Output Class Initialized
INFO - 2019-12-31 14:12:24 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:24 --> Input Class Initialized
INFO - 2019-12-31 14:12:24 --> Language Class Initialized
INFO - 2019-12-31 14:12:24 --> Loader Class Initialized
INFO - 2019-12-31 14:12:24 --> Helper loaded: url_helper
INFO - 2019-12-31 14:12:24 --> Database Driver Class Initialized
DEBUG - 2019-12-31 14:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 14:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 14:12:24 --> Controller Class Initialized
INFO - 2019-12-31 14:12:24 --> Model "M_login" initialized
INFO - 2019-12-31 14:12:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-31 14:12:24 --> Pagination Class Initialized
INFO - 2019-12-31 14:12:24 --> Model "M_show" initialized
INFO - 2019-12-31 14:12:24 --> Helper loaded: form_helper
INFO - 2019-12-31 14:12:24 --> Form Validation Class Initialized
INFO - 2019-12-31 14:12:24 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2019-12-31 14:12:25 --> Severity: Notice --> Undefined index: edit C:\xampp\htdocs\Musikologi-1\application\models\M_show.php 77
INFO - 2019-12-31 14:12:25 --> Config Class Initialized
INFO - 2019-12-31 14:12:25 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:25 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:25 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:25 --> URI Class Initialized
INFO - 2019-12-31 14:12:25 --> Router Class Initialized
INFO - 2019-12-31 14:12:25 --> Output Class Initialized
INFO - 2019-12-31 14:12:25 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:25 --> Input Class Initialized
INFO - 2019-12-31 14:12:25 --> Language Class Initialized
INFO - 2019-12-31 14:12:25 --> Loader Class Initialized
INFO - 2019-12-31 14:12:25 --> Helper loaded: url_helper
INFO - 2019-12-31 14:12:25 --> Database Driver Class Initialized
DEBUG - 2019-12-31 14:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 14:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 14:12:25 --> Controller Class Initialized
INFO - 2019-12-31 14:12:25 --> Model "M_login" initialized
INFO - 2019-12-31 14:12:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-31 14:12:25 --> Pagination Class Initialized
INFO - 2019-12-31 14:12:25 --> Model "M_show" initialized
INFO - 2019-12-31 14:12:25 --> Helper loaded: form_helper
INFO - 2019-12-31 14:12:25 --> Form Validation Class Initialized
INFO - 2019-12-31 14:12:25 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-31 14:12:25 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/show/lihat_show.php
INFO - 2019-12-31 14:12:25 --> Final output sent to browser
DEBUG - 2019-12-31 14:12:25 --> Total execution time: 0.5615
INFO - 2019-12-31 14:12:25 --> Config Class Initialized
INFO - 2019-12-31 14:12:25 --> Config Class Initialized
INFO - 2019-12-31 14:12:25 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:25 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:25 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:12:25 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:25 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:25 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:26 --> URI Class Initialized
INFO - 2019-12-31 14:12:26 --> URI Class Initialized
INFO - 2019-12-31 14:12:26 --> Router Class Initialized
INFO - 2019-12-31 14:12:26 --> Router Class Initialized
INFO - 2019-12-31 14:12:26 --> Output Class Initialized
INFO - 2019-12-31 14:12:26 --> Output Class Initialized
INFO - 2019-12-31 14:12:26 --> Security Class Initialized
INFO - 2019-12-31 14:12:26 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:26 --> Input Class Initialized
INFO - 2019-12-31 14:12:26 --> Input Class Initialized
INFO - 2019-12-31 14:12:26 --> Language Class Initialized
INFO - 2019-12-31 14:12:26 --> Language Class Initialized
ERROR - 2019-12-31 14:12:26 --> 404 Page Not Found: Show/assets
ERROR - 2019-12-31 14:12:26 --> 404 Page Not Found: Show/assets
INFO - 2019-12-31 14:12:28 --> Config Class Initialized
INFO - 2019-12-31 14:12:28 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:28 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:28 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:28 --> URI Class Initialized
INFO - 2019-12-31 14:12:28 --> Router Class Initialized
INFO - 2019-12-31 14:12:28 --> Output Class Initialized
INFO - 2019-12-31 14:12:28 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:28 --> Input Class Initialized
INFO - 2019-12-31 14:12:28 --> Language Class Initialized
INFO - 2019-12-31 14:12:28 --> Loader Class Initialized
INFO - 2019-12-31 14:12:28 --> Helper loaded: url_helper
INFO - 2019-12-31 14:12:28 --> Database Driver Class Initialized
DEBUG - 2019-12-31 14:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 14:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 14:12:28 --> Controller Class Initialized
INFO - 2019-12-31 14:12:29 --> Model "M_login" initialized
INFO - 2019-12-31 14:12:29 --> Model "M_tiket" initialized
INFO - 2019-12-31 14:12:29 --> Helper loaded: form_helper
INFO - 2019-12-31 14:12:29 --> Form Validation Class Initialized
INFO - 2019-12-31 14:12:29 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-31 14:12:29 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2019-12-31 14:12:29 --> Final output sent to browser
DEBUG - 2019-12-31 14:12:29 --> Total execution time: 0.5263
INFO - 2019-12-31 14:12:29 --> Config Class Initialized
INFO - 2019-12-31 14:12:29 --> Config Class Initialized
INFO - 2019-12-31 14:12:29 --> Config Class Initialized
INFO - 2019-12-31 14:12:29 --> Config Class Initialized
INFO - 2019-12-31 14:12:29 --> Config Class Initialized
INFO - 2019-12-31 14:12:29 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:29 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:29 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:29 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:29 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:29 --> Config Class Initialized
INFO - 2019-12-31 14:12:29 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:29 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:12:29 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:12:29 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:12:29 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:12:29 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:29 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:29 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:29 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:29 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:29 --> Utf8 Class Initialized
DEBUG - 2019-12-31 14:12:29 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:29 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:29 --> URI Class Initialized
INFO - 2019-12-31 14:12:29 --> URI Class Initialized
INFO - 2019-12-31 14:12:29 --> URI Class Initialized
INFO - 2019-12-31 14:12:29 --> URI Class Initialized
INFO - 2019-12-31 14:12:29 --> URI Class Initialized
INFO - 2019-12-31 14:12:29 --> URI Class Initialized
INFO - 2019-12-31 14:12:29 --> Router Class Initialized
INFO - 2019-12-31 14:12:29 --> Router Class Initialized
INFO - 2019-12-31 14:12:29 --> Router Class Initialized
INFO - 2019-12-31 14:12:29 --> Router Class Initialized
INFO - 2019-12-31 14:12:29 --> Router Class Initialized
INFO - 2019-12-31 14:12:29 --> Output Class Initialized
INFO - 2019-12-31 14:12:29 --> Router Class Initialized
INFO - 2019-12-31 14:12:29 --> Output Class Initialized
INFO - 2019-12-31 14:12:29 --> Output Class Initialized
INFO - 2019-12-31 14:12:29 --> Output Class Initialized
INFO - 2019-12-31 14:12:29 --> Output Class Initialized
INFO - 2019-12-31 14:12:29 --> Security Class Initialized
INFO - 2019-12-31 14:12:29 --> Security Class Initialized
INFO - 2019-12-31 14:12:29 --> Security Class Initialized
INFO - 2019-12-31 14:12:29 --> Security Class Initialized
INFO - 2019-12-31 14:12:29 --> Output Class Initialized
INFO - 2019-12-31 14:12:29 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:29 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:29 --> Input Class Initialized
INFO - 2019-12-31 14:12:29 --> Input Class Initialized
INFO - 2019-12-31 14:12:29 --> Input Class Initialized
INFO - 2019-12-31 14:12:29 --> Input Class Initialized
INFO - 2019-12-31 14:12:29 --> Input Class Initialized
DEBUG - 2019-12-31 14:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:29 --> Input Class Initialized
INFO - 2019-12-31 14:12:29 --> Language Class Initialized
INFO - 2019-12-31 14:12:29 --> Language Class Initialized
INFO - 2019-12-31 14:12:29 --> Language Class Initialized
INFO - 2019-12-31 14:12:29 --> Language Class Initialized
INFO - 2019-12-31 14:12:29 --> Language Class Initialized
INFO - 2019-12-31 14:12:29 --> Language Class Initialized
ERROR - 2019-12-31 14:12:29 --> 404 Page Not Found: Bower_components/tether
ERROR - 2019-12-31 14:12:29 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2019-12-31 14:12:29 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2019-12-31 14:12:29 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2019-12-31 14:12:29 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2019-12-31 14:12:29 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2019-12-31 14:12:29 --> Config Class Initialized
INFO - 2019-12-31 14:12:29 --> Config Class Initialized
INFO - 2019-12-31 14:12:29 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:29 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:29 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:29 --> Config Class Initialized
INFO - 2019-12-31 14:12:29 --> Config Class Initialized
INFO - 2019-12-31 14:12:29 --> Config Class Initialized
INFO - 2019-12-31 14:12:29 --> Config Class Initialized
INFO - 2019-12-31 14:12:29 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:29 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:29 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:29 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:29 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:29 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:29 --> URI Class Initialized
DEBUG - 2019-12-31 14:12:29 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:12:29 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:12:29 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:29 --> Utf8 Class Initialized
DEBUG - 2019-12-31 14:12:29 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:29 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:29 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:29 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:29 --> URI Class Initialized
INFO - 2019-12-31 14:12:29 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:29 --> Router Class Initialized
INFO - 2019-12-31 14:12:29 --> URI Class Initialized
INFO - 2019-12-31 14:12:29 --> URI Class Initialized
INFO - 2019-12-31 14:12:29 --> Router Class Initialized
INFO - 2019-12-31 14:12:29 --> Output Class Initialized
INFO - 2019-12-31 14:12:29 --> URI Class Initialized
INFO - 2019-12-31 14:12:29 --> URI Class Initialized
INFO - 2019-12-31 14:12:29 --> Security Class Initialized
INFO - 2019-12-31 14:12:29 --> Router Class Initialized
INFO - 2019-12-31 14:12:29 --> Router Class Initialized
INFO - 2019-12-31 14:12:29 --> Router Class Initialized
INFO - 2019-12-31 14:12:29 --> Router Class Initialized
INFO - 2019-12-31 14:12:29 --> Output Class Initialized
DEBUG - 2019-12-31 14:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:29 --> Security Class Initialized
INFO - 2019-12-31 14:12:29 --> Output Class Initialized
INFO - 2019-12-31 14:12:29 --> Output Class Initialized
INFO - 2019-12-31 14:12:29 --> Output Class Initialized
INFO - 2019-12-31 14:12:29 --> Output Class Initialized
DEBUG - 2019-12-31 14:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:29 --> Security Class Initialized
INFO - 2019-12-31 14:12:29 --> Security Class Initialized
INFO - 2019-12-31 14:12:29 --> Security Class Initialized
INFO - 2019-12-31 14:12:29 --> Input Class Initialized
INFO - 2019-12-31 14:12:29 --> Security Class Initialized
INFO - 2019-12-31 14:12:29 --> Input Class Initialized
INFO - 2019-12-31 14:12:29 --> Language Class Initialized
DEBUG - 2019-12-31 14:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:29 --> Input Class Initialized
INFO - 2019-12-31 14:12:29 --> Input Class Initialized
INFO - 2019-12-31 14:12:29 --> Input Class Initialized
INFO - 2019-12-31 14:12:29 --> Input Class Initialized
INFO - 2019-12-31 14:12:29 --> Language Class Initialized
ERROR - 2019-12-31 14:12:29 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2019-12-31 14:12:29 --> Language Class Initialized
INFO - 2019-12-31 14:12:29 --> Language Class Initialized
ERROR - 2019-12-31 14:12:29 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2019-12-31 14:12:29 --> Language Class Initialized
INFO - 2019-12-31 14:12:29 --> Language Class Initialized
INFO - 2019-12-31 14:12:29 --> Config Class Initialized
INFO - 2019-12-31 14:12:29 --> Hooks Class Initialized
ERROR - 2019-12-31 14:12:29 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2019-12-31 14:12:29 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2019-12-31 14:12:29 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2019-12-31 14:12:29 --> 404 Page Not Found: Bower_components/i18next
INFO - 2019-12-31 14:12:29 --> Config Class Initialized
INFO - 2019-12-31 14:12:29 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:29 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:29 --> Config Class Initialized
INFO - 2019-12-31 14:12:29 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:29 --> Utf8 Class Initialized
DEBUG - 2019-12-31 14:12:29 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:29 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:29 --> URI Class Initialized
DEBUG - 2019-12-31 14:12:29 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:29 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:29 --> URI Class Initialized
INFO - 2019-12-31 14:12:29 --> Router Class Initialized
INFO - 2019-12-31 14:12:29 --> URI Class Initialized
INFO - 2019-12-31 14:12:29 --> Router Class Initialized
INFO - 2019-12-31 14:12:29 --> Output Class Initialized
INFO - 2019-12-31 14:12:29 --> Output Class Initialized
INFO - 2019-12-31 14:12:29 --> Router Class Initialized
INFO - 2019-12-31 14:12:29 --> Security Class Initialized
INFO - 2019-12-31 14:12:30 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:30 --> Output Class Initialized
INFO - 2019-12-31 14:12:30 --> Input Class Initialized
DEBUG - 2019-12-31 14:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:30 --> Security Class Initialized
INFO - 2019-12-31 14:12:30 --> Input Class Initialized
INFO - 2019-12-31 14:12:30 --> Language Class Initialized
DEBUG - 2019-12-31 14:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:30 --> Input Class Initialized
INFO - 2019-12-31 14:12:30 --> Language Class Initialized
INFO - 2019-12-31 14:12:30 --> Loader Class Initialized
INFO - 2019-12-31 14:12:30 --> Language Class Initialized
INFO - 2019-12-31 14:12:30 --> Helper loaded: url_helper
INFO - 2019-12-31 14:12:30 --> Loader Class Initialized
ERROR - 2019-12-31 14:12:30 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2019-12-31 14:12:30 --> Helper loaded: url_helper
INFO - 2019-12-31 14:12:30 --> Database Driver Class Initialized
DEBUG - 2019-12-31 14:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 14:12:30 --> Database Driver Class Initialized
INFO - 2019-12-31 14:12:30 --> Config Class Initialized
INFO - 2019-12-31 14:12:30 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-12-31 14:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 14:12:30 --> Controller Class Initialized
DEBUG - 2019-12-31 14:12:30 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:30 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:30 --> Model "M_login" initialized
INFO - 2019-12-31 14:12:30 --> Model "M_tiket" initialized
INFO - 2019-12-31 14:12:30 --> URI Class Initialized
INFO - 2019-12-31 14:12:30 --> Router Class Initialized
INFO - 2019-12-31 14:12:30 --> Helper loaded: form_helper
INFO - 2019-12-31 14:12:30 --> Form Validation Class Initialized
INFO - 2019-12-31 14:12:30 --> Output Class Initialized
INFO - 2019-12-31 14:12:30 --> Security Class Initialized
INFO - 2019-12-31 14:12:30 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2019-12-31 14:12:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2019-12-31 14:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:30 --> Input Class Initialized
ERROR - 2019-12-31 14:12:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
INFO - 2019-12-31 14:12:30 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2019-12-31 14:12:30 --> Language Class Initialized
INFO - 2019-12-31 14:12:30 --> Final output sent to browser
ERROR - 2019-12-31 14:12:30 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2019-12-31 14:12:30 --> Total execution time: 0.6110
INFO - 2019-12-31 14:12:30 --> Config Class Initialized
INFO - 2019-12-31 14:12:30 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 14:12:30 --> Controller Class Initialized
DEBUG - 2019-12-31 14:12:30 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:30 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:30 --> Model "M_login" initialized
INFO - 2019-12-31 14:12:30 --> Model "M_tiket" initialized
INFO - 2019-12-31 14:12:30 --> URI Class Initialized
INFO - 2019-12-31 14:12:30 --> Router Class Initialized
INFO - 2019-12-31 14:12:30 --> Helper loaded: form_helper
INFO - 2019-12-31 14:12:30 --> Form Validation Class Initialized
INFO - 2019-12-31 14:12:30 --> Output Class Initialized
INFO - 2019-12-31 14:12:30 --> Security Class Initialized
INFO - 2019-12-31 14:12:30 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2019-12-31 14:12:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2019-12-31 14:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:30 --> Input Class Initialized
ERROR - 2019-12-31 14:12:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
INFO - 2019-12-31 14:12:30 --> Language Class Initialized
INFO - 2019-12-31 14:12:30 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2019-12-31 14:12:30 --> Final output sent to browser
ERROR - 2019-12-31 14:12:30 --> 404 Page Not Found: Bower_components/i18next
DEBUG - 2019-12-31 14:12:30 --> Total execution time: 0.8976
INFO - 2019-12-31 14:12:30 --> Config Class Initialized
INFO - 2019-12-31 14:12:30 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:30 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:30 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:30 --> URI Class Initialized
INFO - 2019-12-31 14:12:30 --> Router Class Initialized
INFO - 2019-12-31 14:12:30 --> Output Class Initialized
INFO - 2019-12-31 14:12:30 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:31 --> Input Class Initialized
INFO - 2019-12-31 14:12:31 --> Language Class Initialized
ERROR - 2019-12-31 14:12:31 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2019-12-31 14:12:31 --> Config Class Initialized
INFO - 2019-12-31 14:12:31 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:31 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:31 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:31 --> URI Class Initialized
INFO - 2019-12-31 14:12:31 --> Router Class Initialized
INFO - 2019-12-31 14:12:31 --> Output Class Initialized
INFO - 2019-12-31 14:12:31 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:31 --> Input Class Initialized
INFO - 2019-12-31 14:12:31 --> Language Class Initialized
ERROR - 2019-12-31 14:12:31 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2019-12-31 14:12:32 --> Config Class Initialized
INFO - 2019-12-31 14:12:32 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:32 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:32 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:32 --> URI Class Initialized
INFO - 2019-12-31 14:12:32 --> Router Class Initialized
INFO - 2019-12-31 14:12:32 --> Output Class Initialized
INFO - 2019-12-31 14:12:32 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:32 --> Input Class Initialized
INFO - 2019-12-31 14:12:32 --> Language Class Initialized
INFO - 2019-12-31 14:12:32 --> Loader Class Initialized
INFO - 2019-12-31 14:12:32 --> Helper loaded: url_helper
INFO - 2019-12-31 14:12:32 --> Database Driver Class Initialized
DEBUG - 2019-12-31 14:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 14:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 14:12:32 --> Controller Class Initialized
INFO - 2019-12-31 14:12:32 --> Model "M_login" initialized
INFO - 2019-12-31 14:12:32 --> Model "M_tiket" initialized
INFO - 2019-12-31 14:12:32 --> Helper loaded: form_helper
INFO - 2019-12-31 14:12:32 --> Form Validation Class Initialized
INFO - 2019-12-31 14:12:32 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-31 14:12:32 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/edit_form.php
INFO - 2019-12-31 14:12:32 --> Final output sent to browser
DEBUG - 2019-12-31 14:12:32 --> Total execution time: 0.5872
INFO - 2019-12-31 14:12:39 --> Config Class Initialized
INFO - 2019-12-31 14:12:39 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:39 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:39 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:39 --> URI Class Initialized
INFO - 2019-12-31 14:12:39 --> Router Class Initialized
INFO - 2019-12-31 14:12:39 --> Output Class Initialized
INFO - 2019-12-31 14:12:39 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:39 --> Input Class Initialized
INFO - 2019-12-31 14:12:39 --> Language Class Initialized
INFO - 2019-12-31 14:12:39 --> Loader Class Initialized
INFO - 2019-12-31 14:12:39 --> Helper loaded: url_helper
INFO - 2019-12-31 14:12:39 --> Database Driver Class Initialized
DEBUG - 2019-12-31 14:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 14:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 14:12:39 --> Controller Class Initialized
INFO - 2019-12-31 14:12:39 --> Model "M_login" initialized
INFO - 2019-12-31 14:12:39 --> Model "M_tiket" initialized
INFO - 2019-12-31 14:12:39 --> Helper loaded: form_helper
INFO - 2019-12-31 14:12:39 --> Form Validation Class Initialized
INFO - 2019-12-31 14:12:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-12-31 14:12:39 --> Config Class Initialized
INFO - 2019-12-31 14:12:39 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:39 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:39 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:39 --> URI Class Initialized
INFO - 2019-12-31 14:12:40 --> Router Class Initialized
INFO - 2019-12-31 14:12:40 --> Output Class Initialized
INFO - 2019-12-31 14:12:40 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:40 --> Input Class Initialized
INFO - 2019-12-31 14:12:40 --> Language Class Initialized
INFO - 2019-12-31 14:12:40 --> Loader Class Initialized
INFO - 2019-12-31 14:12:40 --> Helper loaded: url_helper
INFO - 2019-12-31 14:12:40 --> Database Driver Class Initialized
DEBUG - 2019-12-31 14:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 14:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 14:12:40 --> Controller Class Initialized
INFO - 2019-12-31 14:12:40 --> Model "M_login" initialized
INFO - 2019-12-31 14:12:40 --> Model "M_tiket" initialized
INFO - 2019-12-31 14:12:40 --> Helper loaded: form_helper
INFO - 2019-12-31 14:12:40 --> Form Validation Class Initialized
INFO - 2019-12-31 14:12:40 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-31 14:12:40 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2019-12-31 14:12:40 --> Final output sent to browser
DEBUG - 2019-12-31 14:12:40 --> Total execution time: 0.5330
INFO - 2019-12-31 14:12:40 --> Config Class Initialized
INFO - 2019-12-31 14:12:40 --> Config Class Initialized
INFO - 2019-12-31 14:12:40 --> Config Class Initialized
INFO - 2019-12-31 14:12:40 --> Config Class Initialized
INFO - 2019-12-31 14:12:40 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:40 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:40 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:40 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:40 --> Config Class Initialized
INFO - 2019-12-31 14:12:40 --> Config Class Initialized
INFO - 2019-12-31 14:12:40 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:40 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:40 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:12:40 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:12:40 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:12:40 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:40 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:40 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:40 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:40 --> Utf8 Class Initialized
DEBUG - 2019-12-31 14:12:40 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:12:40 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:40 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:40 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:40 --> URI Class Initialized
INFO - 2019-12-31 14:12:40 --> URI Class Initialized
INFO - 2019-12-31 14:12:40 --> URI Class Initialized
INFO - 2019-12-31 14:12:40 --> URI Class Initialized
INFO - 2019-12-31 14:12:40 --> URI Class Initialized
INFO - 2019-12-31 14:12:40 --> URI Class Initialized
INFO - 2019-12-31 14:12:40 --> Router Class Initialized
INFO - 2019-12-31 14:12:40 --> Router Class Initialized
INFO - 2019-12-31 14:12:40 --> Router Class Initialized
INFO - 2019-12-31 14:12:40 --> Router Class Initialized
INFO - 2019-12-31 14:12:40 --> Router Class Initialized
INFO - 2019-12-31 14:12:40 --> Output Class Initialized
INFO - 2019-12-31 14:12:40 --> Router Class Initialized
INFO - 2019-12-31 14:12:40 --> Output Class Initialized
INFO - 2019-12-31 14:12:40 --> Output Class Initialized
INFO - 2019-12-31 14:12:40 --> Output Class Initialized
INFO - 2019-12-31 14:12:40 --> Output Class Initialized
INFO - 2019-12-31 14:12:40 --> Security Class Initialized
INFO - 2019-12-31 14:12:40 --> Security Class Initialized
INFO - 2019-12-31 14:12:40 --> Security Class Initialized
INFO - 2019-12-31 14:12:40 --> Output Class Initialized
INFO - 2019-12-31 14:12:40 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:40 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:40 --> Security Class Initialized
INFO - 2019-12-31 14:12:40 --> Input Class Initialized
INFO - 2019-12-31 14:12:40 --> Input Class Initialized
INFO - 2019-12-31 14:12:40 --> Input Class Initialized
INFO - 2019-12-31 14:12:40 --> Input Class Initialized
DEBUG - 2019-12-31 14:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:40 --> Input Class Initialized
INFO - 2019-12-31 14:12:40 --> Input Class Initialized
INFO - 2019-12-31 14:12:40 --> Language Class Initialized
INFO - 2019-12-31 14:12:40 --> Language Class Initialized
INFO - 2019-12-31 14:12:40 --> Language Class Initialized
INFO - 2019-12-31 14:12:40 --> Language Class Initialized
INFO - 2019-12-31 14:12:40 --> Language Class Initialized
INFO - 2019-12-31 14:12:40 --> Language Class Initialized
ERROR - 2019-12-31 14:12:40 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2019-12-31 14:12:40 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2019-12-31 14:12:40 --> 404 Page Not Found: Bower_components/tether
ERROR - 2019-12-31 14:12:40 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2019-12-31 14:12:40 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2019-12-31 14:12:40 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2019-12-31 14:12:40 --> Config Class Initialized
INFO - 2019-12-31 14:12:40 --> Config Class Initialized
INFO - 2019-12-31 14:12:40 --> Config Class Initialized
INFO - 2019-12-31 14:12:40 --> Config Class Initialized
INFO - 2019-12-31 14:12:40 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:40 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:40 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:40 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:40 --> Config Class Initialized
INFO - 2019-12-31 14:12:40 --> Config Class Initialized
INFO - 2019-12-31 14:12:40 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:40 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:40 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:12:40 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:12:40 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:12:40 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:40 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:40 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:40 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:40 --> Utf8 Class Initialized
DEBUG - 2019-12-31 14:12:40 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:12:40 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:40 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:40 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:40 --> URI Class Initialized
INFO - 2019-12-31 14:12:40 --> URI Class Initialized
INFO - 2019-12-31 14:12:40 --> URI Class Initialized
INFO - 2019-12-31 14:12:40 --> URI Class Initialized
INFO - 2019-12-31 14:12:40 --> URI Class Initialized
INFO - 2019-12-31 14:12:40 --> Router Class Initialized
INFO - 2019-12-31 14:12:40 --> Router Class Initialized
INFO - 2019-12-31 14:12:40 --> URI Class Initialized
INFO - 2019-12-31 14:12:40 --> Router Class Initialized
INFO - 2019-12-31 14:12:40 --> Router Class Initialized
INFO - 2019-12-31 14:12:40 --> Output Class Initialized
INFO - 2019-12-31 14:12:40 --> Output Class Initialized
INFO - 2019-12-31 14:12:40 --> Router Class Initialized
INFO - 2019-12-31 14:12:40 --> Output Class Initialized
INFO - 2019-12-31 14:12:40 --> Output Class Initialized
INFO - 2019-12-31 14:12:40 --> Router Class Initialized
INFO - 2019-12-31 14:12:41 --> Security Class Initialized
INFO - 2019-12-31 14:12:41 --> Security Class Initialized
INFO - 2019-12-31 14:12:41 --> Security Class Initialized
INFO - 2019-12-31 14:12:41 --> Security Class Initialized
INFO - 2019-12-31 14:12:41 --> Output Class Initialized
INFO - 2019-12-31 14:12:41 --> Output Class Initialized
DEBUG - 2019-12-31 14:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:41 --> Security Class Initialized
INFO - 2019-12-31 14:12:41 --> Security Class Initialized
INFO - 2019-12-31 14:12:41 --> Input Class Initialized
INFO - 2019-12-31 14:12:41 --> Input Class Initialized
INFO - 2019-12-31 14:12:41 --> Input Class Initialized
INFO - 2019-12-31 14:12:41 --> Input Class Initialized
DEBUG - 2019-12-31 14:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:41 --> Input Class Initialized
INFO - 2019-12-31 14:12:41 --> Language Class Initialized
INFO - 2019-12-31 14:12:41 --> Input Class Initialized
INFO - 2019-12-31 14:12:41 --> Language Class Initialized
INFO - 2019-12-31 14:12:41 --> Language Class Initialized
INFO - 2019-12-31 14:12:41 --> Language Class Initialized
INFO - 2019-12-31 14:12:41 --> Language Class Initialized
INFO - 2019-12-31 14:12:41 --> Language Class Initialized
ERROR - 2019-12-31 14:12:41 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2019-12-31 14:12:41 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2019-12-31 14:12:41 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2019-12-31 14:12:41 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2019-12-31 14:12:41 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2019-12-31 14:12:41 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2019-12-31 14:12:41 --> Config Class Initialized
INFO - 2019-12-31 14:12:41 --> Config Class Initialized
INFO - 2019-12-31 14:12:41 --> Config Class Initialized
INFO - 2019-12-31 14:12:41 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:41 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:41 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:41 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:12:41 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:12:41 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:41 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:41 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:41 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:41 --> URI Class Initialized
INFO - 2019-12-31 14:12:41 --> URI Class Initialized
INFO - 2019-12-31 14:12:41 --> URI Class Initialized
INFO - 2019-12-31 14:12:41 --> Router Class Initialized
INFO - 2019-12-31 14:12:41 --> Router Class Initialized
INFO - 2019-12-31 14:12:41 --> Router Class Initialized
INFO - 2019-12-31 14:12:41 --> Output Class Initialized
INFO - 2019-12-31 14:12:41 --> Output Class Initialized
INFO - 2019-12-31 14:12:41 --> Output Class Initialized
INFO - 2019-12-31 14:12:41 --> Security Class Initialized
INFO - 2019-12-31 14:12:41 --> Security Class Initialized
INFO - 2019-12-31 14:12:41 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:41 --> Input Class Initialized
INFO - 2019-12-31 14:12:41 --> Input Class Initialized
INFO - 2019-12-31 14:12:41 --> Input Class Initialized
INFO - 2019-12-31 14:12:41 --> Language Class Initialized
INFO - 2019-12-31 14:12:41 --> Language Class Initialized
INFO - 2019-12-31 14:12:41 --> Language Class Initialized
ERROR - 2019-12-31 14:12:41 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2019-12-31 14:12:41 --> Loader Class Initialized
INFO - 2019-12-31 14:12:41 --> Loader Class Initialized
INFO - 2019-12-31 14:12:41 --> Helper loaded: url_helper
INFO - 2019-12-31 14:12:41 --> Helper loaded: url_helper
INFO - 2019-12-31 14:12:41 --> Config Class Initialized
INFO - 2019-12-31 14:12:41 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:41 --> Database Driver Class Initialized
INFO - 2019-12-31 14:12:41 --> Database Driver Class Initialized
DEBUG - 2019-12-31 14:12:41 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-12-31 14:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 14:12:41 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 14:12:41 --> Controller Class Initialized
INFO - 2019-12-31 14:12:41 --> URI Class Initialized
INFO - 2019-12-31 14:12:41 --> Model "M_login" initialized
INFO - 2019-12-31 14:12:41 --> Router Class Initialized
INFO - 2019-12-31 14:12:41 --> Model "M_tiket" initialized
INFO - 2019-12-31 14:12:41 --> Output Class Initialized
INFO - 2019-12-31 14:12:41 --> Security Class Initialized
INFO - 2019-12-31 14:12:41 --> Helper loaded: form_helper
INFO - 2019-12-31 14:12:41 --> Form Validation Class Initialized
DEBUG - 2019-12-31 14:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:41 --> Input Class Initialized
INFO - 2019-12-31 14:12:41 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-31 14:12:41 --> Language Class Initialized
ERROR - 2019-12-31 14:12:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2019-12-31 14:12:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
ERROR - 2019-12-31 14:12:41 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2019-12-31 14:12:41 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2019-12-31 14:12:41 --> Config Class Initialized
INFO - 2019-12-31 14:12:41 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:41 --> Final output sent to browser
DEBUG - 2019-12-31 14:12:41 --> Total execution time: 0.6343
DEBUG - 2019-12-31 14:12:41 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:41 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 14:12:41 --> Controller Class Initialized
INFO - 2019-12-31 14:12:41 --> URI Class Initialized
INFO - 2019-12-31 14:12:41 --> Model "M_login" initialized
INFO - 2019-12-31 14:12:41 --> Router Class Initialized
INFO - 2019-12-31 14:12:41 --> Model "M_tiket" initialized
INFO - 2019-12-31 14:12:41 --> Output Class Initialized
INFO - 2019-12-31 14:12:41 --> Security Class Initialized
INFO - 2019-12-31 14:12:41 --> Helper loaded: form_helper
INFO - 2019-12-31 14:12:42 --> Form Validation Class Initialized
DEBUG - 2019-12-31 14:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:42 --> Input Class Initialized
INFO - 2019-12-31 14:12:42 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-31 14:12:42 --> Language Class Initialized
ERROR - 2019-12-31 14:12:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2019-12-31 14:12:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
ERROR - 2019-12-31 14:12:42 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2019-12-31 14:12:42 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2019-12-31 14:12:42 --> Config Class Initialized
INFO - 2019-12-31 14:12:42 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:42 --> Final output sent to browser
DEBUG - 2019-12-31 14:12:42 --> Total execution time: 0.9352
DEBUG - 2019-12-31 14:12:42 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:42 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:42 --> URI Class Initialized
INFO - 2019-12-31 14:12:42 --> Router Class Initialized
INFO - 2019-12-31 14:12:42 --> Output Class Initialized
INFO - 2019-12-31 14:12:42 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:42 --> Input Class Initialized
INFO - 2019-12-31 14:12:42 --> Language Class Initialized
ERROR - 2019-12-31 14:12:42 --> 404 Page Not Found: Bower_components/i18next
INFO - 2019-12-31 14:12:42 --> Config Class Initialized
INFO - 2019-12-31 14:12:42 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:42 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:42 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:42 --> URI Class Initialized
INFO - 2019-12-31 14:12:42 --> Router Class Initialized
INFO - 2019-12-31 14:12:42 --> Output Class Initialized
INFO - 2019-12-31 14:12:42 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:42 --> Input Class Initialized
INFO - 2019-12-31 14:12:42 --> Language Class Initialized
ERROR - 2019-12-31 14:12:42 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2019-12-31 14:12:42 --> Config Class Initialized
INFO - 2019-12-31 14:12:42 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:42 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:42 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:42 --> URI Class Initialized
INFO - 2019-12-31 14:12:42 --> Router Class Initialized
INFO - 2019-12-31 14:12:42 --> Output Class Initialized
INFO - 2019-12-31 14:12:42 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:42 --> Input Class Initialized
INFO - 2019-12-31 14:12:42 --> Language Class Initialized
ERROR - 2019-12-31 14:12:42 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2019-12-31 14:12:42 --> Config Class Initialized
INFO - 2019-12-31 14:12:42 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:43 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:43 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:43 --> URI Class Initialized
INFO - 2019-12-31 14:12:43 --> Router Class Initialized
INFO - 2019-12-31 14:12:43 --> Output Class Initialized
INFO - 2019-12-31 14:12:43 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:43 --> Input Class Initialized
INFO - 2019-12-31 14:12:43 --> Language Class Initialized
ERROR - 2019-12-31 14:12:43 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2019-12-31 14:12:47 --> Config Class Initialized
INFO - 2019-12-31 14:12:47 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:47 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:47 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:47 --> URI Class Initialized
INFO - 2019-12-31 14:12:47 --> Router Class Initialized
INFO - 2019-12-31 14:12:47 --> Output Class Initialized
INFO - 2019-12-31 14:12:47 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:47 --> Input Class Initialized
INFO - 2019-12-31 14:12:47 --> Language Class Initialized
INFO - 2019-12-31 14:12:47 --> Loader Class Initialized
INFO - 2019-12-31 14:12:47 --> Helper loaded: url_helper
INFO - 2019-12-31 14:12:47 --> Database Driver Class Initialized
DEBUG - 2019-12-31 14:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 14:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 14:12:47 --> Controller Class Initialized
INFO - 2019-12-31 14:12:47 --> Model "M_login" initialized
INFO - 2019-12-31 14:12:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-31 14:12:47 --> Pagination Class Initialized
INFO - 2019-12-31 14:12:47 --> Model "M_show" initialized
INFO - 2019-12-31 14:12:47 --> Helper loaded: form_helper
INFO - 2019-12-31 14:12:47 --> Form Validation Class Initialized
INFO - 2019-12-31 14:12:48 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-31 14:12:48 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/show/lihat_show.php
INFO - 2019-12-31 14:12:48 --> Final output sent to browser
DEBUG - 2019-12-31 14:12:48 --> Total execution time: 0.6786
INFO - 2019-12-31 14:12:48 --> Config Class Initialized
INFO - 2019-12-31 14:12:48 --> Config Class Initialized
INFO - 2019-12-31 14:12:48 --> Hooks Class Initialized
INFO - 2019-12-31 14:12:48 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:48 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:12:48 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:48 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:48 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:48 --> URI Class Initialized
INFO - 2019-12-31 14:12:48 --> URI Class Initialized
INFO - 2019-12-31 14:12:48 --> Router Class Initialized
INFO - 2019-12-31 14:12:48 --> Router Class Initialized
INFO - 2019-12-31 14:12:48 --> Output Class Initialized
INFO - 2019-12-31 14:12:48 --> Output Class Initialized
INFO - 2019-12-31 14:12:48 --> Security Class Initialized
INFO - 2019-12-31 14:12:48 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:48 --> Input Class Initialized
INFO - 2019-12-31 14:12:48 --> Input Class Initialized
INFO - 2019-12-31 14:12:48 --> Language Class Initialized
INFO - 2019-12-31 14:12:48 --> Language Class Initialized
ERROR - 2019-12-31 14:12:48 --> 404 Page Not Found: Show/assets
ERROR - 2019-12-31 14:12:48 --> 404 Page Not Found: Show/assets
INFO - 2019-12-31 14:12:48 --> Config Class Initialized
INFO - 2019-12-31 14:12:48 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:12:48 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:12:48 --> Utf8 Class Initialized
INFO - 2019-12-31 14:12:48 --> URI Class Initialized
INFO - 2019-12-31 14:12:48 --> Router Class Initialized
INFO - 2019-12-31 14:12:48 --> Output Class Initialized
INFO - 2019-12-31 14:12:48 --> Security Class Initialized
DEBUG - 2019-12-31 14:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:12:48 --> Input Class Initialized
INFO - 2019-12-31 14:12:48 --> Language Class Initialized
ERROR - 2019-12-31 14:12:48 --> 404 Page Not Found: Show/assets
INFO - 2019-12-31 14:13:08 --> Config Class Initialized
INFO - 2019-12-31 14:13:08 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:13:08 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:13:08 --> Utf8 Class Initialized
INFO - 2019-12-31 14:13:08 --> URI Class Initialized
INFO - 2019-12-31 14:13:08 --> Router Class Initialized
INFO - 2019-12-31 14:13:08 --> Output Class Initialized
INFO - 2019-12-31 14:13:08 --> Security Class Initialized
DEBUG - 2019-12-31 14:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:13:08 --> Input Class Initialized
INFO - 2019-12-31 14:13:08 --> Language Class Initialized
INFO - 2019-12-31 14:13:08 --> Loader Class Initialized
INFO - 2019-12-31 14:13:08 --> Helper loaded: url_helper
INFO - 2019-12-31 14:13:08 --> Database Driver Class Initialized
DEBUG - 2019-12-31 14:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 14:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 14:13:09 --> Controller Class Initialized
INFO - 2019-12-31 14:13:09 --> Model "M_login" initialized
INFO - 2019-12-31 14:13:09 --> Model "M_tiket" initialized
INFO - 2019-12-31 14:13:09 --> Helper loaded: form_helper
INFO - 2019-12-31 14:13:09 --> Form Validation Class Initialized
INFO - 2019-12-31 14:13:09 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-31 14:13:09 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2019-12-31 14:13:09 --> Final output sent to browser
DEBUG - 2019-12-31 14:13:09 --> Total execution time: 0.5441
INFO - 2019-12-31 14:13:09 --> Config Class Initialized
INFO - 2019-12-31 14:13:09 --> Config Class Initialized
INFO - 2019-12-31 14:13:09 --> Config Class Initialized
INFO - 2019-12-31 14:13:09 --> Hooks Class Initialized
INFO - 2019-12-31 14:13:09 --> Config Class Initialized
INFO - 2019-12-31 14:13:09 --> Config Class Initialized
INFO - 2019-12-31 14:13:09 --> Config Class Initialized
INFO - 2019-12-31 14:13:09 --> Hooks Class Initialized
INFO - 2019-12-31 14:13:09 --> Hooks Class Initialized
INFO - 2019-12-31 14:13:09 --> Hooks Class Initialized
INFO - 2019-12-31 14:13:09 --> Hooks Class Initialized
INFO - 2019-12-31 14:13:09 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:13:09 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:13:09 --> Utf8 Class Initialized
DEBUG - 2019-12-31 14:13:09 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:13:09 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:13:09 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:13:09 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:13:09 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:13:09 --> Utf8 Class Initialized
INFO - 2019-12-31 14:13:09 --> Utf8 Class Initialized
INFO - 2019-12-31 14:13:09 --> Utf8 Class Initialized
INFO - 2019-12-31 14:13:09 --> Utf8 Class Initialized
INFO - 2019-12-31 14:13:09 --> Utf8 Class Initialized
INFO - 2019-12-31 14:13:09 --> URI Class Initialized
INFO - 2019-12-31 14:13:09 --> URI Class Initialized
INFO - 2019-12-31 14:13:09 --> URI Class Initialized
INFO - 2019-12-31 14:13:09 --> URI Class Initialized
INFO - 2019-12-31 14:13:09 --> URI Class Initialized
INFO - 2019-12-31 14:13:09 --> URI Class Initialized
INFO - 2019-12-31 14:13:09 --> Router Class Initialized
INFO - 2019-12-31 14:13:09 --> Router Class Initialized
INFO - 2019-12-31 14:13:09 --> Router Class Initialized
INFO - 2019-12-31 14:13:09 --> Router Class Initialized
INFO - 2019-12-31 14:13:09 --> Router Class Initialized
INFO - 2019-12-31 14:13:09 --> Output Class Initialized
INFO - 2019-12-31 14:13:09 --> Router Class Initialized
INFO - 2019-12-31 14:13:09 --> Output Class Initialized
INFO - 2019-12-31 14:13:09 --> Output Class Initialized
INFO - 2019-12-31 14:13:09 --> Output Class Initialized
INFO - 2019-12-31 14:13:09 --> Output Class Initialized
INFO - 2019-12-31 14:13:09 --> Output Class Initialized
INFO - 2019-12-31 14:13:09 --> Security Class Initialized
INFO - 2019-12-31 14:13:09 --> Security Class Initialized
INFO - 2019-12-31 14:13:09 --> Security Class Initialized
INFO - 2019-12-31 14:13:09 --> Security Class Initialized
DEBUG - 2019-12-31 14:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:13:09 --> Security Class Initialized
INFO - 2019-12-31 14:13:09 --> Security Class Initialized
INFO - 2019-12-31 14:13:09 --> Input Class Initialized
DEBUG - 2019-12-31 14:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:13:09 --> Input Class Initialized
INFO - 2019-12-31 14:13:09 --> Input Class Initialized
INFO - 2019-12-31 14:13:09 --> Input Class Initialized
INFO - 2019-12-31 14:13:09 --> Input Class Initialized
INFO - 2019-12-31 14:13:09 --> Input Class Initialized
INFO - 2019-12-31 14:13:09 --> Language Class Initialized
INFO - 2019-12-31 14:13:09 --> Language Class Initialized
INFO - 2019-12-31 14:13:09 --> Language Class Initialized
INFO - 2019-12-31 14:13:09 --> Language Class Initialized
ERROR - 2019-12-31 14:13:09 --> 404 Page Not Found: Bower_components/jquery
INFO - 2019-12-31 14:13:09 --> Language Class Initialized
INFO - 2019-12-31 14:13:09 --> Language Class Initialized
ERROR - 2019-12-31 14:13:09 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2019-12-31 14:13:09 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2019-12-31 14:13:09 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2019-12-31 14:13:09 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2019-12-31 14:13:09 --> 404 Page Not Found: Bower_components/tether
INFO - 2019-12-31 14:13:09 --> Config Class Initialized
INFO - 2019-12-31 14:13:09 --> Hooks Class Initialized
INFO - 2019-12-31 14:13:09 --> Config Class Initialized
INFO - 2019-12-31 14:13:09 --> Config Class Initialized
INFO - 2019-12-31 14:13:09 --> Config Class Initialized
INFO - 2019-12-31 14:13:09 --> Hooks Class Initialized
INFO - 2019-12-31 14:13:09 --> Hooks Class Initialized
INFO - 2019-12-31 14:13:09 --> Hooks Class Initialized
INFO - 2019-12-31 14:13:09 --> Config Class Initialized
INFO - 2019-12-31 14:13:09 --> Config Class Initialized
DEBUG - 2019-12-31 14:13:09 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:13:09 --> Utf8 Class Initialized
INFO - 2019-12-31 14:13:09 --> Hooks Class Initialized
INFO - 2019-12-31 14:13:09 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:13:09 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:13:09 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:13:09 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:13:09 --> Utf8 Class Initialized
INFO - 2019-12-31 14:13:09 --> Utf8 Class Initialized
INFO - 2019-12-31 14:13:09 --> Utf8 Class Initialized
INFO - 2019-12-31 14:13:09 --> URI Class Initialized
DEBUG - 2019-12-31 14:13:09 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:13:09 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:13:09 --> Utf8 Class Initialized
INFO - 2019-12-31 14:13:09 --> URI Class Initialized
INFO - 2019-12-31 14:13:09 --> Utf8 Class Initialized
INFO - 2019-12-31 14:13:09 --> URI Class Initialized
INFO - 2019-12-31 14:13:09 --> URI Class Initialized
INFO - 2019-12-31 14:13:09 --> Router Class Initialized
INFO - 2019-12-31 14:13:09 --> Router Class Initialized
INFO - 2019-12-31 14:13:09 --> Router Class Initialized
INFO - 2019-12-31 14:13:09 --> Output Class Initialized
INFO - 2019-12-31 14:13:09 --> URI Class Initialized
INFO - 2019-12-31 14:13:09 --> Router Class Initialized
INFO - 2019-12-31 14:13:09 --> URI Class Initialized
INFO - 2019-12-31 14:13:09 --> Router Class Initialized
INFO - 2019-12-31 14:13:09 --> Output Class Initialized
INFO - 2019-12-31 14:13:09 --> Router Class Initialized
INFO - 2019-12-31 14:13:09 --> Output Class Initialized
INFO - 2019-12-31 14:13:09 --> Security Class Initialized
INFO - 2019-12-31 14:13:09 --> Output Class Initialized
DEBUG - 2019-12-31 14:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:13:09 --> Security Class Initialized
INFO - 2019-12-31 14:13:09 --> Output Class Initialized
INFO - 2019-12-31 14:13:09 --> Output Class Initialized
INFO - 2019-12-31 14:13:09 --> Security Class Initialized
INFO - 2019-12-31 14:13:09 --> Security Class Initialized
INFO - 2019-12-31 14:13:09 --> Input Class Initialized
INFO - 2019-12-31 14:13:09 --> Security Class Initialized
DEBUG - 2019-12-31 14:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:13:09 --> Security Class Initialized
INFO - 2019-12-31 14:13:10 --> Input Class Initialized
INFO - 2019-12-31 14:13:10 --> Input Class Initialized
INFO - 2019-12-31 14:13:10 --> Input Class Initialized
INFO - 2019-12-31 14:13:10 --> Language Class Initialized
DEBUG - 2019-12-31 14:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-31 14:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:13:10 --> Input Class Initialized
INFO - 2019-12-31 14:13:10 --> Input Class Initialized
INFO - 2019-12-31 14:13:10 --> Language Class Initialized
INFO - 2019-12-31 14:13:10 --> Language Class Initialized
INFO - 2019-12-31 14:13:10 --> Language Class Initialized
ERROR - 2019-12-31 14:13:10 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2019-12-31 14:13:10 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2019-12-31 14:13:10 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2019-12-31 14:13:10 --> Language Class Initialized
INFO - 2019-12-31 14:13:10 --> Language Class Initialized
INFO - 2019-12-31 14:13:10 --> Loader Class Initialized
INFO - 2019-12-31 14:13:10 --> Config Class Initialized
INFO - 2019-12-31 14:13:10 --> Hooks Class Initialized
INFO - 2019-12-31 14:13:10 --> Helper loaded: url_helper
ERROR - 2019-12-31 14:13:10 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2019-12-31 14:13:10 --> 404 Page Not Found: Bower_components/i18next
INFO - 2019-12-31 14:13:10 --> Config Class Initialized
INFO - 2019-12-31 14:13:10 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:13:10 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:13:10 --> Database Driver Class Initialized
INFO - 2019-12-31 14:13:10 --> Utf8 Class Initialized
DEBUG - 2019-12-31 14:13:10 --> UTF-8 Support Enabled
DEBUG - 2019-12-31 14:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 14:13:10 --> Utf8 Class Initialized
INFO - 2019-12-31 14:13:10 --> URI Class Initialized
INFO - 2019-12-31 14:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 14:13:10 --> Controller Class Initialized
INFO - 2019-12-31 14:13:10 --> URI Class Initialized
INFO - 2019-12-31 14:13:10 --> Router Class Initialized
INFO - 2019-12-31 14:13:10 --> Model "M_login" initialized
INFO - 2019-12-31 14:13:10 --> Router Class Initialized
INFO - 2019-12-31 14:13:10 --> Output Class Initialized
INFO - 2019-12-31 14:13:10 --> Model "M_tiket" initialized
INFO - 2019-12-31 14:13:10 --> Security Class Initialized
INFO - 2019-12-31 14:13:10 --> Output Class Initialized
DEBUG - 2019-12-31 14:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:13:10 --> Security Class Initialized
INFO - 2019-12-31 14:13:10 --> Helper loaded: form_helper
INFO - 2019-12-31 14:13:10 --> Form Validation Class Initialized
INFO - 2019-12-31 14:13:10 --> Input Class Initialized
DEBUG - 2019-12-31 14:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:13:10 --> Input Class Initialized
INFO - 2019-12-31 14:13:10 --> Language Class Initialized
INFO - 2019-12-31 14:13:10 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2019-12-31 14:13:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2019-12-31 14:13:10 --> Language Class Initialized
ERROR - 2019-12-31 14:13:10 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2019-12-31 14:13:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
INFO - 2019-12-31 14:13:10 --> Loader Class Initialized
INFO - 2019-12-31 14:13:10 --> Config Class Initialized
INFO - 2019-12-31 14:13:10 --> Hooks Class Initialized
INFO - 2019-12-31 14:13:10 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2019-12-31 14:13:10 --> Helper loaded: url_helper
INFO - 2019-12-31 14:13:10 --> Final output sent to browser
DEBUG - 2019-12-31 14:13:10 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:13:10 --> Database Driver Class Initialized
INFO - 2019-12-31 14:13:10 --> Utf8 Class Initialized
DEBUG - 2019-12-31 14:13:10 --> Total execution time: 0.6502
DEBUG - 2019-12-31 14:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-31 14:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-31 14:13:10 --> URI Class Initialized
INFO - 2019-12-31 14:13:10 --> Controller Class Initialized
INFO - 2019-12-31 14:13:10 --> Router Class Initialized
INFO - 2019-12-31 14:13:10 --> Model "M_login" initialized
INFO - 2019-12-31 14:13:10 --> Output Class Initialized
INFO - 2019-12-31 14:13:10 --> Model "M_tiket" initialized
INFO - 2019-12-31 14:13:10 --> Security Class Initialized
DEBUG - 2019-12-31 14:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:13:10 --> Helper loaded: form_helper
INFO - 2019-12-31 14:13:10 --> Input Class Initialized
INFO - 2019-12-31 14:13:10 --> Form Validation Class Initialized
INFO - 2019-12-31 14:13:10 --> Language Class Initialized
INFO - 2019-12-31 14:13:10 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2019-12-31 14:13:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
ERROR - 2019-12-31 14:13:10 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2019-12-31 14:13:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
INFO - 2019-12-31 14:13:10 --> Config Class Initialized
INFO - 2019-12-31 14:13:10 --> Hooks Class Initialized
INFO - 2019-12-31 14:13:10 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2019-12-31 14:13:10 --> Final output sent to browser
DEBUG - 2019-12-31 14:13:10 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:13:10 --> Utf8 Class Initialized
DEBUG - 2019-12-31 14:13:10 --> Total execution time: 0.6507
INFO - 2019-12-31 14:13:10 --> URI Class Initialized
INFO - 2019-12-31 14:13:10 --> Router Class Initialized
INFO - 2019-12-31 14:13:10 --> Output Class Initialized
INFO - 2019-12-31 14:13:10 --> Security Class Initialized
DEBUG - 2019-12-31 14:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:13:10 --> Input Class Initialized
INFO - 2019-12-31 14:13:10 --> Language Class Initialized
ERROR - 2019-12-31 14:13:10 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2019-12-31 14:13:11 --> Config Class Initialized
INFO - 2019-12-31 14:13:11 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:13:11 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:13:11 --> Utf8 Class Initialized
INFO - 2019-12-31 14:13:11 --> URI Class Initialized
INFO - 2019-12-31 14:13:11 --> Router Class Initialized
INFO - 2019-12-31 14:13:11 --> Output Class Initialized
INFO - 2019-12-31 14:13:11 --> Security Class Initialized
DEBUG - 2019-12-31 14:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:13:11 --> Input Class Initialized
INFO - 2019-12-31 14:13:11 --> Language Class Initialized
ERROR - 2019-12-31 14:13:11 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2019-12-31 14:13:11 --> Config Class Initialized
INFO - 2019-12-31 14:13:11 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:13:11 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:13:11 --> Utf8 Class Initialized
INFO - 2019-12-31 14:13:11 --> URI Class Initialized
INFO - 2019-12-31 14:13:11 --> Router Class Initialized
INFO - 2019-12-31 14:13:11 --> Output Class Initialized
INFO - 2019-12-31 14:13:11 --> Security Class Initialized
DEBUG - 2019-12-31 14:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:13:11 --> Input Class Initialized
INFO - 2019-12-31 14:13:11 --> Language Class Initialized
ERROR - 2019-12-31 14:13:11 --> 404 Page Not Found: Bower_components/i18next
INFO - 2019-12-31 14:13:11 --> Config Class Initialized
INFO - 2019-12-31 14:13:11 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:13:11 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:13:11 --> Utf8 Class Initialized
INFO - 2019-12-31 14:13:11 --> URI Class Initialized
INFO - 2019-12-31 14:13:11 --> Router Class Initialized
INFO - 2019-12-31 14:13:11 --> Output Class Initialized
INFO - 2019-12-31 14:13:11 --> Security Class Initialized
DEBUG - 2019-12-31 14:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:13:11 --> Input Class Initialized
INFO - 2019-12-31 14:13:11 --> Language Class Initialized
ERROR - 2019-12-31 14:13:11 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2019-12-31 14:13:11 --> Config Class Initialized
INFO - 2019-12-31 14:13:11 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:13:11 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:13:11 --> Utf8 Class Initialized
INFO - 2019-12-31 14:13:11 --> URI Class Initialized
INFO - 2019-12-31 14:13:11 --> Router Class Initialized
INFO - 2019-12-31 14:13:11 --> Output Class Initialized
INFO - 2019-12-31 14:13:11 --> Security Class Initialized
DEBUG - 2019-12-31 14:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:13:12 --> Input Class Initialized
INFO - 2019-12-31 14:13:12 --> Language Class Initialized
ERROR - 2019-12-31 14:13:12 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2019-12-31 14:13:12 --> Config Class Initialized
INFO - 2019-12-31 14:13:12 --> Hooks Class Initialized
DEBUG - 2019-12-31 14:13:12 --> UTF-8 Support Enabled
INFO - 2019-12-31 14:13:12 --> Utf8 Class Initialized
INFO - 2019-12-31 14:13:12 --> URI Class Initialized
INFO - 2019-12-31 14:13:12 --> Router Class Initialized
INFO - 2019-12-31 14:13:12 --> Output Class Initialized
INFO - 2019-12-31 14:13:12 --> Security Class Initialized
DEBUG - 2019-12-31 14:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-31 14:13:12 --> Input Class Initialized
INFO - 2019-12-31 14:13:12 --> Language Class Initialized
ERROR - 2019-12-31 14:13:12 --> 404 Page Not Found: Bower_components/jquery-i18next
