<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-12-27 06:49:55 --> Config Class Initialized
INFO - 2019-12-27 06:49:55 --> Hooks Class Initialized
DEBUG - 2019-12-27 06:49:56 --> UTF-8 Support Enabled
INFO - 2019-12-27 06:49:56 --> Utf8 Class Initialized
INFO - 2019-12-27 06:49:56 --> URI Class Initialized
DEBUG - 2019-12-27 06:49:56 --> No URI present. Default controller set.
INFO - 2019-12-27 06:49:56 --> Router Class Initialized
INFO - 2019-12-27 06:49:56 --> Output Class Initialized
INFO - 2019-12-27 06:49:56 --> Security Class Initialized
DEBUG - 2019-12-27 06:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-27 06:49:56 --> Input Class Initialized
INFO - 2019-12-27 06:49:56 --> Language Class Initialized
INFO - 2019-12-27 06:49:56 --> Loader Class Initialized
INFO - 2019-12-27 06:49:56 --> Helper loaded: url_helper
INFO - 2019-12-27 06:49:56 --> Database Driver Class Initialized
DEBUG - 2019-12-27 06:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-27 06:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-27 06:49:56 --> Controller Class Initialized
INFO - 2019-12-27 06:49:56 --> Model "M_login" initialized
INFO - 2019-12-27 06:49:56 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/login.php
INFO - 2019-12-27 06:49:56 --> Final output sent to browser
DEBUG - 2019-12-27 06:49:56 --> Total execution time: 0.9455
INFO - 2019-12-27 06:50:11 --> Config Class Initialized
INFO - 2019-12-27 06:50:11 --> Hooks Class Initialized
DEBUG - 2019-12-27 06:50:11 --> UTF-8 Support Enabled
INFO - 2019-12-27 06:50:11 --> Utf8 Class Initialized
INFO - 2019-12-27 06:50:11 --> URI Class Initialized
INFO - 2019-12-27 06:50:11 --> Router Class Initialized
INFO - 2019-12-27 06:50:11 --> Output Class Initialized
INFO - 2019-12-27 06:50:11 --> Security Class Initialized
DEBUG - 2019-12-27 06:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-27 06:50:11 --> Input Class Initialized
INFO - 2019-12-27 06:50:11 --> Language Class Initialized
INFO - 2019-12-27 06:50:11 --> Loader Class Initialized
INFO - 2019-12-27 06:50:11 --> Helper loaded: url_helper
INFO - 2019-12-27 06:50:11 --> Database Driver Class Initialized
DEBUG - 2019-12-27 06:50:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-27 06:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-27 06:50:11 --> Controller Class Initialized
INFO - 2019-12-27 06:50:12 --> Model "M_login" initialized
INFO - 2019-12-27 06:50:12 --> Config Class Initialized
INFO - 2019-12-27 06:50:12 --> Hooks Class Initialized
DEBUG - 2019-12-27 06:50:12 --> UTF-8 Support Enabled
INFO - 2019-12-27 06:50:12 --> Utf8 Class Initialized
INFO - 2019-12-27 06:50:12 --> URI Class Initialized
INFO - 2019-12-27 06:50:12 --> Router Class Initialized
INFO - 2019-12-27 06:50:12 --> Output Class Initialized
INFO - 2019-12-27 06:50:12 --> Security Class Initialized
DEBUG - 2019-12-27 06:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-27 06:50:12 --> Input Class Initialized
INFO - 2019-12-27 06:50:12 --> Language Class Initialized
INFO - 2019-12-27 06:50:12 --> Loader Class Initialized
INFO - 2019-12-27 06:50:12 --> Helper loaded: url_helper
INFO - 2019-12-27 06:50:12 --> Database Driver Class Initialized
DEBUG - 2019-12-27 06:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-27 06:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-27 06:50:12 --> Controller Class Initialized
INFO - 2019-12-27 06:50:12 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-27 06:50:12 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/beranda.php
INFO - 2019-12-27 06:50:12 --> Final output sent to browser
DEBUG - 2019-12-27 06:50:12 --> Total execution time: 0.4941
INFO - 2019-12-27 06:50:12 --> Config Class Initialized
INFO - 2019-12-27 06:50:12 --> Config Class Initialized
INFO - 2019-12-27 06:50:12 --> Hooks Class Initialized
INFO - 2019-12-27 06:50:12 --> Hooks Class Initialized
DEBUG - 2019-12-27 06:50:12 --> UTF-8 Support Enabled
DEBUG - 2019-12-27 06:50:12 --> UTF-8 Support Enabled
INFO - 2019-12-27 06:50:12 --> Utf8 Class Initialized
INFO - 2019-12-27 06:50:12 --> Utf8 Class Initialized
INFO - 2019-12-27 06:50:12 --> URI Class Initialized
INFO - 2019-12-27 06:50:12 --> URI Class Initialized
INFO - 2019-12-27 06:50:12 --> Router Class Initialized
INFO - 2019-12-27 06:50:12 --> Router Class Initialized
INFO - 2019-12-27 06:50:12 --> Output Class Initialized
INFO - 2019-12-27 06:50:12 --> Output Class Initialized
INFO - 2019-12-27 06:50:12 --> Security Class Initialized
INFO - 2019-12-27 06:50:12 --> Security Class Initialized
DEBUG - 2019-12-27 06:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-27 06:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-27 06:50:12 --> Input Class Initialized
INFO - 2019-12-27 06:50:12 --> Input Class Initialized
INFO - 2019-12-27 06:50:13 --> Language Class Initialized
INFO - 2019-12-27 06:50:13 --> Language Class Initialized
ERROR - 2019-12-27 06:50:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-12-27 06:50:13 --> 404 Page Not Found: Assets/js
INFO - 2019-12-27 06:50:13 --> Config Class Initialized
INFO - 2019-12-27 06:50:13 --> Hooks Class Initialized
DEBUG - 2019-12-27 06:50:13 --> UTF-8 Support Enabled
INFO - 2019-12-27 06:50:13 --> Utf8 Class Initialized
INFO - 2019-12-27 06:50:13 --> URI Class Initialized
INFO - 2019-12-27 06:50:13 --> Router Class Initialized
INFO - 2019-12-27 06:50:13 --> Output Class Initialized
INFO - 2019-12-27 06:50:13 --> Security Class Initialized
DEBUG - 2019-12-27 06:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-27 06:50:13 --> Input Class Initialized
INFO - 2019-12-27 06:50:13 --> Language Class Initialized
ERROR - 2019-12-27 06:50:13 --> 404 Page Not Found: Assets/js
INFO - 2019-12-27 12:44:01 --> Config Class Initialized
INFO - 2019-12-27 12:44:01 --> Hooks Class Initialized
DEBUG - 2019-12-27 12:44:01 --> UTF-8 Support Enabled
INFO - 2019-12-27 12:44:01 --> Utf8 Class Initialized
INFO - 2019-12-27 12:44:01 --> URI Class Initialized
INFO - 2019-12-27 12:44:01 --> Router Class Initialized
INFO - 2019-12-27 12:44:01 --> Output Class Initialized
INFO - 2019-12-27 12:44:01 --> Security Class Initialized
DEBUG - 2019-12-27 12:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-27 12:44:01 --> Input Class Initialized
INFO - 2019-12-27 12:44:01 --> Language Class Initialized
INFO - 2019-12-27 12:44:01 --> Loader Class Initialized
INFO - 2019-12-27 12:44:01 --> Helper loaded: url_helper
INFO - 2019-12-27 12:44:01 --> Database Driver Class Initialized
DEBUG - 2019-12-27 12:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-27 12:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-27 12:44:01 --> Controller Class Initialized
INFO - 2019-12-27 12:44:01 --> Model "M_login" initialized
INFO - 2019-12-27 12:44:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-27 12:44:02 --> Pagination Class Initialized
INFO - 2019-12-27 12:44:02 --> Model "M_pesan" initialized
INFO - 2019-12-27 12:44:02 --> Helper loaded: form_helper
INFO - 2019-12-27 12:44:02 --> Form Validation Class Initialized
INFO - 2019-12-27 12:44:02 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-27 12:44:02 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/lihat_pemesanan.php
INFO - 2019-12-27 12:44:02 --> Final output sent to browser
DEBUG - 2019-12-27 12:44:02 --> Total execution time: 0.8303
INFO - 2019-12-27 12:44:02 --> Config Class Initialized
INFO - 2019-12-27 12:44:02 --> Hooks Class Initialized
INFO - 2019-12-27 12:44:02 --> Config Class Initialized
INFO - 2019-12-27 12:44:02 --> Hooks Class Initialized
DEBUG - 2019-12-27 12:44:02 --> UTF-8 Support Enabled
INFO - 2019-12-27 12:44:02 --> Utf8 Class Initialized
DEBUG - 2019-12-27 12:44:02 --> UTF-8 Support Enabled
INFO - 2019-12-27 12:44:02 --> Utf8 Class Initialized
INFO - 2019-12-27 12:44:02 --> URI Class Initialized
INFO - 2019-12-27 12:44:02 --> URI Class Initialized
INFO - 2019-12-27 12:44:02 --> Router Class Initialized
INFO - 2019-12-27 12:44:02 --> Router Class Initialized
INFO - 2019-12-27 12:44:02 --> Output Class Initialized
INFO - 2019-12-27 12:44:02 --> Security Class Initialized
INFO - 2019-12-27 12:44:02 --> Output Class Initialized
INFO - 2019-12-27 12:44:02 --> Security Class Initialized
DEBUG - 2019-12-27 12:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-27 12:44:02 --> Input Class Initialized
DEBUG - 2019-12-27 12:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-27 12:44:02 --> Input Class Initialized
INFO - 2019-12-27 12:44:02 --> Language Class Initialized
INFO - 2019-12-27 12:44:02 --> Language Class Initialized
ERROR - 2019-12-27 12:44:02 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-27 12:44:02 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-27 12:44:03 --> Config Class Initialized
INFO - 2019-12-27 12:44:03 --> Hooks Class Initialized
DEBUG - 2019-12-27 12:44:03 --> UTF-8 Support Enabled
INFO - 2019-12-27 12:44:03 --> Utf8 Class Initialized
INFO - 2019-12-27 12:44:03 --> URI Class Initialized
INFO - 2019-12-27 12:44:03 --> Router Class Initialized
INFO - 2019-12-27 12:44:03 --> Output Class Initialized
INFO - 2019-12-27 12:44:03 --> Security Class Initialized
DEBUG - 2019-12-27 12:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-27 12:44:03 --> Input Class Initialized
INFO - 2019-12-27 12:44:03 --> Language Class Initialized
ERROR - 2019-12-27 12:44:03 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-27 12:44:03 --> Config Class Initialized
INFO - 2019-12-27 12:44:03 --> Hooks Class Initialized
DEBUG - 2019-12-27 12:44:03 --> UTF-8 Support Enabled
INFO - 2019-12-27 12:44:03 --> Utf8 Class Initialized
INFO - 2019-12-27 12:44:03 --> URI Class Initialized
INFO - 2019-12-27 12:44:03 --> Router Class Initialized
INFO - 2019-12-27 12:44:03 --> Output Class Initialized
INFO - 2019-12-27 12:44:03 --> Security Class Initialized
DEBUG - 2019-12-27 12:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-27 12:44:03 --> Input Class Initialized
INFO - 2019-12-27 12:44:03 --> Language Class Initialized
ERROR - 2019-12-27 12:44:03 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-27 12:44:29 --> Config Class Initialized
INFO - 2019-12-27 12:44:29 --> Hooks Class Initialized
DEBUG - 2019-12-27 12:44:29 --> UTF-8 Support Enabled
INFO - 2019-12-27 12:44:29 --> Utf8 Class Initialized
INFO - 2019-12-27 12:44:29 --> URI Class Initialized
INFO - 2019-12-27 12:44:29 --> Router Class Initialized
INFO - 2019-12-27 12:44:29 --> Output Class Initialized
INFO - 2019-12-27 12:44:29 --> Security Class Initialized
DEBUG - 2019-12-27 12:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-27 12:44:29 --> Input Class Initialized
INFO - 2019-12-27 12:44:29 --> Language Class Initialized
INFO - 2019-12-27 12:44:29 --> Loader Class Initialized
INFO - 2019-12-27 12:44:29 --> Helper loaded: url_helper
INFO - 2019-12-27 12:44:29 --> Database Driver Class Initialized
DEBUG - 2019-12-27 12:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-12-27 12:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-12-27 12:44:29 --> Controller Class Initialized
INFO - 2019-12-27 12:44:29 --> Model "M_login" initialized
INFO - 2019-12-27 12:44:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-27 12:44:29 --> Pagination Class Initialized
INFO - 2019-12-27 12:44:29 --> Model "M_pesan" initialized
INFO - 2019-12-27 12:44:29 --> Helper loaded: form_helper
INFO - 2019-12-27 12:44:29 --> Form Validation Class Initialized
INFO - 2019-12-27 12:44:29 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2019-12-27 12:44:29 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/pemesanan/lihat_pemesanan.php
INFO - 2019-12-27 12:44:29 --> Final output sent to browser
DEBUG - 2019-12-27 12:44:29 --> Total execution time: 0.3903
INFO - 2019-12-27 12:44:29 --> Config Class Initialized
INFO - 2019-12-27 12:44:29 --> Config Class Initialized
INFO - 2019-12-27 12:44:29 --> Hooks Class Initialized
INFO - 2019-12-27 12:44:29 --> Hooks Class Initialized
DEBUG - 2019-12-27 12:44:29 --> UTF-8 Support Enabled
DEBUG - 2019-12-27 12:44:29 --> UTF-8 Support Enabled
INFO - 2019-12-27 12:44:29 --> Utf8 Class Initialized
INFO - 2019-12-27 12:44:29 --> Utf8 Class Initialized
INFO - 2019-12-27 12:44:29 --> URI Class Initialized
INFO - 2019-12-27 12:44:29 --> URI Class Initialized
INFO - 2019-12-27 12:44:29 --> Router Class Initialized
INFO - 2019-12-27 12:44:29 --> Router Class Initialized
INFO - 2019-12-27 12:44:29 --> Output Class Initialized
INFO - 2019-12-27 12:44:29 --> Output Class Initialized
INFO - 2019-12-27 12:44:29 --> Security Class Initialized
INFO - 2019-12-27 12:44:29 --> Security Class Initialized
DEBUG - 2019-12-27 12:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-27 12:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-27 12:44:29 --> Input Class Initialized
INFO - 2019-12-27 12:44:29 --> Input Class Initialized
INFO - 2019-12-27 12:44:29 --> Language Class Initialized
INFO - 2019-12-27 12:44:29 --> Language Class Initialized
ERROR - 2019-12-27 12:44:29 --> 404 Page Not Found: Pemesanan/assets
ERROR - 2019-12-27 12:44:29 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-27 12:44:30 --> Config Class Initialized
INFO - 2019-12-27 12:44:30 --> Hooks Class Initialized
DEBUG - 2019-12-27 12:44:30 --> UTF-8 Support Enabled
INFO - 2019-12-27 12:44:30 --> Utf8 Class Initialized
INFO - 2019-12-27 12:44:30 --> URI Class Initialized
INFO - 2019-12-27 12:44:30 --> Router Class Initialized
INFO - 2019-12-27 12:44:30 --> Output Class Initialized
INFO - 2019-12-27 12:44:30 --> Security Class Initialized
DEBUG - 2019-12-27 12:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-27 12:44:30 --> Input Class Initialized
INFO - 2019-12-27 12:44:30 --> Language Class Initialized
ERROR - 2019-12-27 12:44:30 --> 404 Page Not Found: Pemesanan/assets
INFO - 2019-12-27 12:44:30 --> Config Class Initialized
INFO - 2019-12-27 12:44:30 --> Hooks Class Initialized
DEBUG - 2019-12-27 12:44:30 --> UTF-8 Support Enabled
INFO - 2019-12-27 12:44:30 --> Utf8 Class Initialized
INFO - 2019-12-27 12:44:30 --> URI Class Initialized
INFO - 2019-12-27 12:44:30 --> Router Class Initialized
INFO - 2019-12-27 12:44:30 --> Output Class Initialized
INFO - 2019-12-27 12:44:30 --> Security Class Initialized
DEBUG - 2019-12-27 12:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-27 12:44:30 --> Input Class Initialized
INFO - 2019-12-27 12:44:30 --> Language Class Initialized
ERROR - 2019-12-27 12:44:30 --> 404 Page Not Found: Pemesanan/assets
