<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-03-05 00:46:15 --> Final output sent to browser
DEBUG - 2020-03-05 00:46:15 --> Total execution time: 0.1840
INFO - 2020-03-05 04:04:04 --> Upload Class Initialized
INFO - 2020-03-05 00:02:03 --> Config Class Initialized
INFO - 2020-03-05 00:02:03 --> Hooks Class Initialized
DEBUG - 2020-03-05 00:02:03 --> UTF-8 Support Enabled
INFO - 2020-03-05 00:02:03 --> Utf8 Class Initialized
INFO - 2020-03-05 00:02:03 --> URI Class Initialized
INFO - 2020-03-05 00:02:03 --> Router Class Initialized
INFO - 2020-03-05 00:02:03 --> Output Class Initialized
INFO - 2020-03-05 00:02:03 --> Security Class Initialized
DEBUG - 2020-03-05 00:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 00:02:03 --> Input Class Initialized
INFO - 2020-03-05 00:02:03 --> Language Class Initialized
INFO - 2020-03-05 00:02:03 --> Loader Class Initialized
INFO - 2020-03-05 00:02:03 --> Helper loaded: url_helper
INFO - 2020-03-05 00:02:03 --> Helper loaded: string_helper
INFO - 2020-03-05 00:02:03 --> Database Driver Class Initialized
DEBUG - 2020-03-05 00:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 00:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 00:02:03 --> Controller Class Initialized
INFO - 2020-03-05 00:02:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 00:02:03 --> Pagination Class Initialized
INFO - 2020-03-05 00:02:03 --> Model "M_show" initialized
INFO - 2020-03-05 00:02:03 --> Helper loaded: form_helper
INFO - 2020-03-05 00:02:03 --> Form Validation Class Initialized
INFO - 2020-03-05 00:02:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 00:02:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 00:02:03 --> Final output sent to browser
DEBUG - 2020-03-05 00:02:03 --> Total execution time: 0.0339
INFO - 2020-03-05 00:10:39 --> Config Class Initialized
INFO - 2020-03-05 00:10:39 --> Hooks Class Initialized
DEBUG - 2020-03-05 00:10:39 --> UTF-8 Support Enabled
INFO - 2020-03-05 00:10:39 --> Utf8 Class Initialized
INFO - 2020-03-05 00:10:39 --> URI Class Initialized
DEBUG - 2020-03-05 00:10:39 --> No URI present. Default controller set.
INFO - 2020-03-05 00:10:39 --> Router Class Initialized
INFO - 2020-03-05 00:10:39 --> Output Class Initialized
INFO - 2020-03-05 00:10:39 --> Security Class Initialized
DEBUG - 2020-03-05 00:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 00:10:39 --> Input Class Initialized
INFO - 2020-03-05 00:10:39 --> Language Class Initialized
INFO - 2020-03-05 00:10:39 --> Loader Class Initialized
INFO - 2020-03-05 00:10:39 --> Helper loaded: url_helper
INFO - 2020-03-05 00:10:39 --> Helper loaded: string_helper
INFO - 2020-03-05 00:10:39 --> Database Driver Class Initialized
DEBUG - 2020-03-05 00:10:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 00:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 00:10:39 --> Controller Class Initialized
INFO - 2020-03-05 00:10:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 00:10:39 --> Pagination Class Initialized
INFO - 2020-03-05 00:10:39 --> Model "M_show" initialized
INFO - 2020-03-05 00:10:39 --> Helper loaded: form_helper
INFO - 2020-03-05 00:10:39 --> Form Validation Class Initialized
INFO - 2020-03-05 00:10:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 00:10:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 00:10:39 --> Final output sent to browser
DEBUG - 2020-03-05 00:10:39 --> Total execution time: 0.0299
INFO - 2020-03-05 00:27:07 --> Config Class Initialized
INFO - 2020-03-05 00:27:07 --> Hooks Class Initialized
DEBUG - 2020-03-05 00:27:07 --> UTF-8 Support Enabled
INFO - 2020-03-05 00:27:07 --> Utf8 Class Initialized
INFO - 2020-03-05 00:27:07 --> URI Class Initialized
DEBUG - 2020-03-05 00:27:07 --> No URI present. Default controller set.
INFO - 2020-03-05 00:27:07 --> Router Class Initialized
INFO - 2020-03-05 00:27:07 --> Output Class Initialized
INFO - 2020-03-05 00:27:07 --> Security Class Initialized
DEBUG - 2020-03-05 00:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 00:27:07 --> Input Class Initialized
INFO - 2020-03-05 00:27:07 --> Language Class Initialized
INFO - 2020-03-05 00:27:07 --> Loader Class Initialized
INFO - 2020-03-05 00:27:07 --> Helper loaded: url_helper
INFO - 2020-03-05 00:27:07 --> Helper loaded: string_helper
INFO - 2020-03-05 00:27:07 --> Database Driver Class Initialized
DEBUG - 2020-03-05 00:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 00:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 00:27:07 --> Controller Class Initialized
INFO - 2020-03-05 00:27:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 00:27:07 --> Pagination Class Initialized
INFO - 2020-03-05 00:27:07 --> Model "M_show" initialized
INFO - 2020-03-05 00:27:07 --> Helper loaded: form_helper
INFO - 2020-03-05 00:27:07 --> Form Validation Class Initialized
INFO - 2020-03-05 00:27:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 00:27:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 00:27:07 --> Final output sent to browser
DEBUG - 2020-03-05 00:27:07 --> Total execution time: 0.0433
INFO - 2020-03-05 00:27:13 --> Config Class Initialized
INFO - 2020-03-05 00:27:13 --> Hooks Class Initialized
DEBUG - 2020-03-05 00:27:13 --> UTF-8 Support Enabled
INFO - 2020-03-05 00:27:13 --> Utf8 Class Initialized
INFO - 2020-03-05 00:27:13 --> URI Class Initialized
INFO - 2020-03-05 00:27:13 --> Router Class Initialized
INFO - 2020-03-05 00:27:13 --> Output Class Initialized
INFO - 2020-03-05 00:27:13 --> Security Class Initialized
DEBUG - 2020-03-05 00:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 00:27:13 --> Input Class Initialized
INFO - 2020-03-05 00:27:13 --> Language Class Initialized
INFO - 2020-03-05 00:27:13 --> Loader Class Initialized
INFO - 2020-03-05 00:27:13 --> Helper loaded: url_helper
INFO - 2020-03-05 00:27:13 --> Helper loaded: string_helper
INFO - 2020-03-05 00:27:13 --> Database Driver Class Initialized
DEBUG - 2020-03-05 00:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 00:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 00:27:13 --> Controller Class Initialized
INFO - 2020-03-05 00:27:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 00:27:13 --> Pagination Class Initialized
INFO - 2020-03-05 00:27:13 --> Model "M_show" initialized
INFO - 2020-03-05 00:27:13 --> Helper loaded: form_helper
INFO - 2020-03-05 00:27:13 --> Form Validation Class Initialized
INFO - 2020-03-05 00:27:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 00:27:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 00:27:13 --> Final output sent to browser
DEBUG - 2020-03-05 00:27:13 --> Total execution time: 0.0077
INFO - 2020-03-05 00:27:14 --> Config Class Initialized
INFO - 2020-03-05 00:27:14 --> Hooks Class Initialized
DEBUG - 2020-03-05 00:27:14 --> UTF-8 Support Enabled
INFO - 2020-03-05 00:27:14 --> Utf8 Class Initialized
INFO - 2020-03-05 00:27:14 --> URI Class Initialized
INFO - 2020-03-05 00:27:14 --> Router Class Initialized
INFO - 2020-03-05 00:27:14 --> Output Class Initialized
INFO - 2020-03-05 00:27:14 --> Security Class Initialized
DEBUG - 2020-03-05 00:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 00:27:14 --> Input Class Initialized
INFO - 2020-03-05 00:27:14 --> Language Class Initialized
ERROR - 2020-03-05 00:27:14 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-05 00:27:22 --> Config Class Initialized
INFO - 2020-03-05 00:27:22 --> Hooks Class Initialized
DEBUG - 2020-03-05 00:27:22 --> UTF-8 Support Enabled
INFO - 2020-03-05 00:27:22 --> Utf8 Class Initialized
INFO - 2020-03-05 00:27:22 --> URI Class Initialized
INFO - 2020-03-05 00:27:22 --> Router Class Initialized
INFO - 2020-03-05 00:27:22 --> Output Class Initialized
INFO - 2020-03-05 00:27:22 --> Security Class Initialized
DEBUG - 2020-03-05 00:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 00:27:22 --> Input Class Initialized
INFO - 2020-03-05 00:27:22 --> Language Class Initialized
INFO - 2020-03-05 00:27:22 --> Loader Class Initialized
INFO - 2020-03-05 00:27:22 --> Helper loaded: url_helper
INFO - 2020-03-05 00:27:22 --> Helper loaded: string_helper
INFO - 2020-03-05 00:27:22 --> Database Driver Class Initialized
DEBUG - 2020-03-05 00:27:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 00:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 00:27:22 --> Controller Class Initialized
INFO - 2020-03-05 00:27:22 --> Model "M_tiket" initialized
INFO - 2020-03-05 00:27:22 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 00:27:22 --> Model "M_pesan" initialized
INFO - 2020-03-05 00:27:22 --> Helper loaded: form_helper
INFO - 2020-03-05 00:27:22 --> Form Validation Class Initialized
INFO - 2020-03-05 00:27:22 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 00:27:22 --> Final output sent to browser
DEBUG - 2020-03-05 00:27:22 --> Total execution time: 0.0104
INFO - 2020-03-05 00:27:32 --> Config Class Initialized
INFO - 2020-03-05 00:27:32 --> Hooks Class Initialized
DEBUG - 2020-03-05 00:27:32 --> UTF-8 Support Enabled
INFO - 2020-03-05 00:27:32 --> Utf8 Class Initialized
INFO - 2020-03-05 00:27:32 --> URI Class Initialized
DEBUG - 2020-03-05 00:27:32 --> No URI present. Default controller set.
INFO - 2020-03-05 00:27:32 --> Router Class Initialized
INFO - 2020-03-05 00:27:32 --> Output Class Initialized
INFO - 2020-03-05 00:27:32 --> Security Class Initialized
DEBUG - 2020-03-05 00:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 00:27:32 --> Input Class Initialized
INFO - 2020-03-05 00:27:32 --> Language Class Initialized
INFO - 2020-03-05 00:27:32 --> Loader Class Initialized
INFO - 2020-03-05 00:27:32 --> Helper loaded: url_helper
INFO - 2020-03-05 00:27:32 --> Helper loaded: string_helper
INFO - 2020-03-05 00:27:32 --> Database Driver Class Initialized
DEBUG - 2020-03-05 00:27:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 00:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 00:27:32 --> Controller Class Initialized
INFO - 2020-03-05 00:27:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 00:27:32 --> Pagination Class Initialized
INFO - 2020-03-05 00:27:32 --> Model "M_show" initialized
INFO - 2020-03-05 00:27:32 --> Helper loaded: form_helper
INFO - 2020-03-05 00:27:32 --> Form Validation Class Initialized
INFO - 2020-03-05 00:27:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 00:27:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 00:27:32 --> Final output sent to browser
DEBUG - 2020-03-05 00:27:32 --> Total execution time: 0.0056
INFO - 2020-03-05 00:27:33 --> Config Class Initialized
INFO - 2020-03-05 00:27:33 --> Hooks Class Initialized
DEBUG - 2020-03-05 00:27:33 --> UTF-8 Support Enabled
INFO - 2020-03-05 00:27:33 --> Utf8 Class Initialized
INFO - 2020-03-05 00:27:33 --> URI Class Initialized
INFO - 2020-03-05 00:27:33 --> Router Class Initialized
INFO - 2020-03-05 00:27:33 --> Output Class Initialized
INFO - 2020-03-05 00:27:33 --> Security Class Initialized
DEBUG - 2020-03-05 00:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 00:27:33 --> Input Class Initialized
INFO - 2020-03-05 00:27:33 --> Language Class Initialized
INFO - 2020-03-05 00:27:33 --> Loader Class Initialized
INFO - 2020-03-05 00:27:33 --> Helper loaded: url_helper
INFO - 2020-03-05 00:27:33 --> Helper loaded: string_helper
INFO - 2020-03-05 00:27:33 --> Database Driver Class Initialized
DEBUG - 2020-03-05 00:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 00:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 00:27:33 --> Controller Class Initialized
INFO - 2020-03-05 00:27:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 00:27:33 --> Pagination Class Initialized
INFO - 2020-03-05 00:27:33 --> Model "M_show" initialized
INFO - 2020-03-05 00:27:33 --> Helper loaded: form_helper
INFO - 2020-03-05 00:27:33 --> Form Validation Class Initialized
INFO - 2020-03-05 00:27:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 00:27:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 00:27:33 --> Final output sent to browser
DEBUG - 2020-03-05 00:27:33 --> Total execution time: 0.0067
INFO - 2020-03-05 00:27:56 --> Config Class Initialized
INFO - 2020-03-05 00:27:56 --> Hooks Class Initialized
DEBUG - 2020-03-05 00:27:56 --> UTF-8 Support Enabled
INFO - 2020-03-05 00:27:56 --> Utf8 Class Initialized
INFO - 2020-03-05 00:27:56 --> URI Class Initialized
INFO - 2020-03-05 00:27:56 --> Router Class Initialized
INFO - 2020-03-05 00:27:56 --> Output Class Initialized
INFO - 2020-03-05 00:27:56 --> Security Class Initialized
DEBUG - 2020-03-05 00:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 00:27:56 --> Input Class Initialized
INFO - 2020-03-05 00:27:56 --> Language Class Initialized
INFO - 2020-03-05 00:27:56 --> Loader Class Initialized
INFO - 2020-03-05 00:27:56 --> Helper loaded: url_helper
INFO - 2020-03-05 00:27:56 --> Helper loaded: string_helper
INFO - 2020-03-05 00:27:56 --> Database Driver Class Initialized
DEBUG - 2020-03-05 00:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 00:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 00:27:56 --> Controller Class Initialized
INFO - 2020-03-05 00:27:56 --> Model "M_tiket" initialized
INFO - 2020-03-05 00:27:56 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 00:27:56 --> Model "M_pesan" initialized
INFO - 2020-03-05 00:27:56 --> Helper loaded: form_helper
INFO - 2020-03-05 00:27:56 --> Form Validation Class Initialized
INFO - 2020-03-05 00:27:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-05 00:27:56 --> Final output sent to browser
DEBUG - 2020-03-05 00:27:56 --> Total execution time: 0.0239
INFO - 2020-03-05 00:29:37 --> Config Class Initialized
INFO - 2020-03-05 00:29:37 --> Hooks Class Initialized
DEBUG - 2020-03-05 00:29:37 --> UTF-8 Support Enabled
INFO - 2020-03-05 00:29:37 --> Utf8 Class Initialized
INFO - 2020-03-05 00:29:37 --> URI Class Initialized
INFO - 2020-03-05 00:29:37 --> Router Class Initialized
INFO - 2020-03-05 00:29:37 --> Output Class Initialized
INFO - 2020-03-05 00:29:37 --> Security Class Initialized
DEBUG - 2020-03-05 00:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 00:29:37 --> Input Class Initialized
INFO - 2020-03-05 00:29:37 --> Language Class Initialized
INFO - 2020-03-05 00:29:37 --> Loader Class Initialized
INFO - 2020-03-05 00:29:37 --> Helper loaded: url_helper
INFO - 2020-03-05 00:29:37 --> Helper loaded: string_helper
INFO - 2020-03-05 00:29:37 --> Database Driver Class Initialized
DEBUG - 2020-03-05 00:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 00:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 00:29:37 --> Controller Class Initialized
INFO - 2020-03-05 00:29:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 00:29:37 --> Pagination Class Initialized
INFO - 2020-03-05 00:29:37 --> Model "M_show" initialized
INFO - 2020-03-05 00:29:37 --> Helper loaded: form_helper
INFO - 2020-03-05 00:29:37 --> Form Validation Class Initialized
INFO - 2020-03-05 00:29:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 00:29:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 00:29:37 --> Final output sent to browser
DEBUG - 2020-03-05 00:29:37 --> Total execution time: 0.0332
INFO - 2020-03-05 00:29:40 --> Config Class Initialized
INFO - 2020-03-05 00:29:40 --> Hooks Class Initialized
DEBUG - 2020-03-05 00:29:40 --> UTF-8 Support Enabled
INFO - 2020-03-05 00:29:40 --> Utf8 Class Initialized
INFO - 2020-03-05 00:29:40 --> URI Class Initialized
INFO - 2020-03-05 00:29:40 --> Router Class Initialized
INFO - 2020-03-05 00:29:40 --> Output Class Initialized
INFO - 2020-03-05 00:29:40 --> Security Class Initialized
DEBUG - 2020-03-05 00:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 00:29:40 --> Input Class Initialized
INFO - 2020-03-05 00:29:40 --> Language Class Initialized
INFO - 2020-03-05 00:29:40 --> Loader Class Initialized
INFO - 2020-03-05 00:29:40 --> Helper loaded: url_helper
INFO - 2020-03-05 00:29:40 --> Helper loaded: string_helper
INFO - 2020-03-05 00:29:40 --> Database Driver Class Initialized
DEBUG - 2020-03-05 00:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 00:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 00:29:40 --> Controller Class Initialized
INFO - 2020-03-05 00:29:40 --> Model "M_tiket" initialized
INFO - 2020-03-05 00:29:40 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 00:29:40 --> Model "M_pesan" initialized
INFO - 2020-03-05 00:29:40 --> Helper loaded: form_helper
INFO - 2020-03-05 00:29:40 --> Form Validation Class Initialized
DEBUG - 2020-03-05 00:29:40 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2020-03-05 00:29:40 --> Severity: Notice --> Undefined index: total_bayar /home/u107185497/domains/musikologifest.com/public_html/application/controllers/Tiket.php 81
ERROR - 2020-03-05 00:29:40 --> Severity: Notice --> Undefined index: jumlah_pesanan /home/u107185497/domains/musikologifest.com/public_html/application/controllers/Tiket.php 82
INFO - 2020-03-05 00:29:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-05 00:29:40 --> Final output sent to browser
DEBUG - 2020-03-05 00:29:40 --> Total execution time: 0.2577
INFO - 2020-03-05 00:29:45 --> Config Class Initialized
INFO - 2020-03-05 00:29:45 --> Hooks Class Initialized
DEBUG - 2020-03-05 00:29:45 --> UTF-8 Support Enabled
INFO - 2020-03-05 00:29:45 --> Utf8 Class Initialized
INFO - 2020-03-05 00:29:45 --> URI Class Initialized
INFO - 2020-03-05 00:29:45 --> Router Class Initialized
INFO - 2020-03-05 00:29:45 --> Output Class Initialized
INFO - 2020-03-05 00:29:45 --> Security Class Initialized
DEBUG - 2020-03-05 00:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 00:29:45 --> Input Class Initialized
INFO - 2020-03-05 00:29:45 --> Language Class Initialized
INFO - 2020-03-05 00:29:45 --> Loader Class Initialized
INFO - 2020-03-05 00:29:45 --> Helper loaded: url_helper
INFO - 2020-03-05 00:29:45 --> Helper loaded: string_helper
INFO - 2020-03-05 00:29:45 --> Database Driver Class Initialized
DEBUG - 2020-03-05 00:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 00:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 00:29:45 --> Controller Class Initialized
INFO - 2020-03-05 00:29:45 --> Model "M_tiket" initialized
INFO - 2020-03-05 00:29:45 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 00:29:45 --> Model "M_pesan" initialized
INFO - 2020-03-05 00:29:45 --> Helper loaded: form_helper
INFO - 2020-03-05 00:29:45 --> Form Validation Class Initialized
INFO - 2020-03-05 00:29:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-05 00:29:45 --> Final output sent to browser
DEBUG - 2020-03-05 00:29:45 --> Total execution time: 0.0076
INFO - 2020-03-05 00:29:49 --> Config Class Initialized
INFO - 2020-03-05 00:29:49 --> Hooks Class Initialized
DEBUG - 2020-03-05 00:29:49 --> UTF-8 Support Enabled
INFO - 2020-03-05 00:29:49 --> Utf8 Class Initialized
INFO - 2020-03-05 00:29:49 --> URI Class Initialized
INFO - 2020-03-05 00:29:49 --> Router Class Initialized
INFO - 2020-03-05 00:29:49 --> Output Class Initialized
INFO - 2020-03-05 00:29:49 --> Security Class Initialized
DEBUG - 2020-03-05 00:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 00:29:49 --> Input Class Initialized
INFO - 2020-03-05 00:29:49 --> Language Class Initialized
INFO - 2020-03-05 00:29:49 --> Loader Class Initialized
INFO - 2020-03-05 00:29:49 --> Helper loaded: url_helper
INFO - 2020-03-05 00:29:49 --> Helper loaded: string_helper
INFO - 2020-03-05 00:29:49 --> Database Driver Class Initialized
DEBUG - 2020-03-05 00:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 00:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 00:29:49 --> Controller Class Initialized
INFO - 2020-03-05 00:29:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 00:29:49 --> Pagination Class Initialized
INFO - 2020-03-05 00:29:49 --> Model "M_show" initialized
INFO - 2020-03-05 00:29:49 --> Helper loaded: form_helper
INFO - 2020-03-05 00:29:49 --> Form Validation Class Initialized
INFO - 2020-03-05 00:29:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 00:29:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 00:29:49 --> Final output sent to browser
DEBUG - 2020-03-05 00:29:49 --> Total execution time: 0.0054
INFO - 2020-03-05 00:30:01 --> Config Class Initialized
INFO - 2020-03-05 00:30:01 --> Hooks Class Initialized
DEBUG - 2020-03-05 00:30:01 --> UTF-8 Support Enabled
INFO - 2020-03-05 00:30:01 --> Utf8 Class Initialized
INFO - 2020-03-05 00:30:01 --> URI Class Initialized
INFO - 2020-03-05 00:30:01 --> Router Class Initialized
INFO - 2020-03-05 00:30:01 --> Output Class Initialized
INFO - 2020-03-05 00:30:01 --> Security Class Initialized
DEBUG - 2020-03-05 00:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 00:30:01 --> Input Class Initialized
INFO - 2020-03-05 00:30:01 --> Language Class Initialized
INFO - 2020-03-05 00:30:01 --> Loader Class Initialized
INFO - 2020-03-05 00:30:01 --> Helper loaded: url_helper
INFO - 2020-03-05 00:30:01 --> Helper loaded: string_helper
INFO - 2020-03-05 00:30:01 --> Database Driver Class Initialized
DEBUG - 2020-03-05 00:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 00:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 00:30:01 --> Controller Class Initialized
INFO - 2020-03-05 00:30:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 00:30:01 --> Pagination Class Initialized
INFO - 2020-03-05 00:30:01 --> Model "M_show" initialized
INFO - 2020-03-05 00:30:01 --> Helper loaded: form_helper
INFO - 2020-03-05 00:30:01 --> Form Validation Class Initialized
INFO - 2020-03-05 00:30:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 00:30:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-05 00:30:01 --> Final output sent to browser
DEBUG - 2020-03-05 00:30:01 --> Total execution time: 0.0207
INFO - 2020-03-05 00:36:08 --> Config Class Initialized
INFO - 2020-03-05 00:36:08 --> Hooks Class Initialized
DEBUG - 2020-03-05 00:36:08 --> UTF-8 Support Enabled
INFO - 2020-03-05 00:36:08 --> Utf8 Class Initialized
INFO - 2020-03-05 00:36:08 --> URI Class Initialized
DEBUG - 2020-03-05 00:36:08 --> No URI present. Default controller set.
INFO - 2020-03-05 00:36:08 --> Router Class Initialized
INFO - 2020-03-05 00:36:08 --> Output Class Initialized
INFO - 2020-03-05 00:36:08 --> Security Class Initialized
DEBUG - 2020-03-05 00:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 00:36:08 --> Input Class Initialized
INFO - 2020-03-05 00:36:08 --> Language Class Initialized
INFO - 2020-03-05 00:36:08 --> Loader Class Initialized
INFO - 2020-03-05 00:36:08 --> Helper loaded: url_helper
INFO - 2020-03-05 00:36:08 --> Helper loaded: string_helper
INFO - 2020-03-05 00:36:08 --> Database Driver Class Initialized
DEBUG - 2020-03-05 00:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 00:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 00:36:09 --> Controller Class Initialized
INFO - 2020-03-05 00:36:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 00:36:09 --> Pagination Class Initialized
INFO - 2020-03-05 00:36:09 --> Model "M_show" initialized
INFO - 2020-03-05 00:36:09 --> Helper loaded: form_helper
INFO - 2020-03-05 00:36:09 --> Form Validation Class Initialized
INFO - 2020-03-05 00:36:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 00:36:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 00:36:09 --> Final output sent to browser
DEBUG - 2020-03-05 00:36:09 --> Total execution time: 0.2778
INFO - 2020-03-05 00:45:20 --> Config Class Initialized
INFO - 2020-03-05 00:45:20 --> Hooks Class Initialized
DEBUG - 2020-03-05 00:45:20 --> UTF-8 Support Enabled
INFO - 2020-03-05 00:45:20 --> Utf8 Class Initialized
INFO - 2020-03-05 00:45:20 --> URI Class Initialized
INFO - 2020-03-05 00:45:20 --> Router Class Initialized
INFO - 2020-03-05 00:45:20 --> Output Class Initialized
INFO - 2020-03-05 00:45:20 --> Security Class Initialized
DEBUG - 2020-03-05 00:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 00:45:20 --> Input Class Initialized
INFO - 2020-03-05 00:45:20 --> Language Class Initialized
INFO - 2020-03-05 00:45:20 --> Loader Class Initialized
INFO - 2020-03-05 00:45:20 --> Helper loaded: url_helper
INFO - 2020-03-05 00:45:20 --> Helper loaded: string_helper
INFO - 2020-03-05 00:45:20 --> Database Driver Class Initialized
DEBUG - 2020-03-05 00:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 00:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 00:45:20 --> Controller Class Initialized
INFO - 2020-03-05 00:45:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 00:45:20 --> Pagination Class Initialized
INFO - 2020-03-05 00:45:20 --> Model "M_show" initialized
INFO - 2020-03-05 00:45:20 --> Helper loaded: form_helper
INFO - 2020-03-05 00:45:20 --> Form Validation Class Initialized
INFO - 2020-03-05 00:45:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 00:45:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 00:45:20 --> Final output sent to browser
DEBUG - 2020-03-05 00:45:20 --> Total execution time: 0.0306
INFO - 2020-03-05 01:20:34 --> Config Class Initialized
INFO - 2020-03-05 01:20:34 --> Hooks Class Initialized
DEBUG - 2020-03-05 01:20:34 --> UTF-8 Support Enabled
INFO - 2020-03-05 01:20:34 --> Utf8 Class Initialized
INFO - 2020-03-05 01:20:34 --> URI Class Initialized
INFO - 2020-03-05 01:20:34 --> Router Class Initialized
INFO - 2020-03-05 01:20:34 --> Output Class Initialized
INFO - 2020-03-05 01:20:34 --> Security Class Initialized
DEBUG - 2020-03-05 01:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 01:20:34 --> Input Class Initialized
INFO - 2020-03-05 01:20:34 --> Language Class Initialized
INFO - 2020-03-05 01:20:34 --> Loader Class Initialized
INFO - 2020-03-05 01:20:34 --> Helper loaded: url_helper
INFO - 2020-03-05 01:20:34 --> Helper loaded: string_helper
INFO - 2020-03-05 01:20:34 --> Database Driver Class Initialized
DEBUG - 2020-03-05 01:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 01:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 01:20:34 --> Controller Class Initialized
INFO - 2020-03-05 01:20:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 01:20:34 --> Pagination Class Initialized
INFO - 2020-03-05 01:20:34 --> Model "M_show" initialized
INFO - 2020-03-05 01:20:34 --> Helper loaded: form_helper
INFO - 2020-03-05 01:20:34 --> Form Validation Class Initialized
INFO - 2020-03-05 01:20:34 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 01:20:34 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 01:20:34 --> Final output sent to browser
DEBUG - 2020-03-05 01:20:34 --> Total execution time: 0.1183
INFO - 2020-03-05 01:30:44 --> Config Class Initialized
INFO - 2020-03-05 01:30:44 --> Hooks Class Initialized
DEBUG - 2020-03-05 01:30:44 --> UTF-8 Support Enabled
INFO - 2020-03-05 01:30:44 --> Utf8 Class Initialized
INFO - 2020-03-05 01:30:44 --> URI Class Initialized
INFO - 2020-03-05 01:30:44 --> Router Class Initialized
INFO - 2020-03-05 01:30:44 --> Output Class Initialized
INFO - 2020-03-05 01:30:44 --> Security Class Initialized
DEBUG - 2020-03-05 01:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 01:30:44 --> Input Class Initialized
INFO - 2020-03-05 01:30:44 --> Language Class Initialized
INFO - 2020-03-05 01:30:44 --> Loader Class Initialized
INFO - 2020-03-05 01:30:44 --> Helper loaded: url_helper
INFO - 2020-03-05 01:30:44 --> Helper loaded: string_helper
INFO - 2020-03-05 01:30:44 --> Database Driver Class Initialized
DEBUG - 2020-03-05 01:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 01:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 01:30:44 --> Controller Class Initialized
INFO - 2020-03-05 01:30:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 01:30:44 --> Pagination Class Initialized
INFO - 2020-03-05 01:30:44 --> Model "M_show" initialized
INFO - 2020-03-05 01:30:44 --> Helper loaded: form_helper
INFO - 2020-03-05 01:30:44 --> Form Validation Class Initialized
INFO - 2020-03-05 01:30:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 01:30:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 01:30:44 --> Final output sent to browser
DEBUG - 2020-03-05 01:30:44 --> Total execution time: 0.0337
INFO - 2020-03-05 01:32:44 --> Config Class Initialized
INFO - 2020-03-05 01:32:44 --> Hooks Class Initialized
DEBUG - 2020-03-05 01:32:44 --> UTF-8 Support Enabled
INFO - 2020-03-05 01:32:44 --> Utf8 Class Initialized
INFO - 2020-03-05 01:32:44 --> URI Class Initialized
DEBUG - 2020-03-05 01:32:44 --> No URI present. Default controller set.
INFO - 2020-03-05 01:32:44 --> Router Class Initialized
INFO - 2020-03-05 01:32:44 --> Output Class Initialized
INFO - 2020-03-05 01:32:44 --> Security Class Initialized
DEBUG - 2020-03-05 01:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 01:32:44 --> Input Class Initialized
INFO - 2020-03-05 01:32:44 --> Language Class Initialized
INFO - 2020-03-05 01:32:44 --> Loader Class Initialized
INFO - 2020-03-05 01:32:44 --> Helper loaded: url_helper
INFO - 2020-03-05 01:32:44 --> Helper loaded: string_helper
INFO - 2020-03-05 01:32:44 --> Database Driver Class Initialized
DEBUG - 2020-03-05 01:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 01:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 01:32:44 --> Controller Class Initialized
INFO - 2020-03-05 01:32:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 01:32:44 --> Pagination Class Initialized
INFO - 2020-03-05 01:32:44 --> Model "M_show" initialized
INFO - 2020-03-05 01:32:44 --> Helper loaded: form_helper
INFO - 2020-03-05 01:32:44 --> Form Validation Class Initialized
INFO - 2020-03-05 01:32:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 01:32:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 01:32:44 --> Final output sent to browser
DEBUG - 2020-03-05 01:32:44 --> Total execution time: 0.0301
INFO - 2020-03-05 01:33:09 --> Config Class Initialized
INFO - 2020-03-05 01:33:09 --> Hooks Class Initialized
DEBUG - 2020-03-05 01:33:09 --> UTF-8 Support Enabled
INFO - 2020-03-05 01:33:09 --> Utf8 Class Initialized
INFO - 2020-03-05 01:33:09 --> URI Class Initialized
DEBUG - 2020-03-05 01:33:09 --> No URI present. Default controller set.
INFO - 2020-03-05 01:33:09 --> Router Class Initialized
INFO - 2020-03-05 01:33:09 --> Output Class Initialized
INFO - 2020-03-05 01:33:09 --> Security Class Initialized
DEBUG - 2020-03-05 01:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 01:33:09 --> Input Class Initialized
INFO - 2020-03-05 01:33:09 --> Language Class Initialized
INFO - 2020-03-05 01:33:09 --> Loader Class Initialized
INFO - 2020-03-05 01:33:09 --> Helper loaded: url_helper
INFO - 2020-03-05 01:33:09 --> Helper loaded: string_helper
INFO - 2020-03-05 01:33:09 --> Database Driver Class Initialized
DEBUG - 2020-03-05 01:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 01:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 01:33:09 --> Controller Class Initialized
INFO - 2020-03-05 01:33:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 01:33:09 --> Pagination Class Initialized
INFO - 2020-03-05 01:33:09 --> Model "M_show" initialized
INFO - 2020-03-05 01:33:09 --> Helper loaded: form_helper
INFO - 2020-03-05 01:33:09 --> Form Validation Class Initialized
INFO - 2020-03-05 01:33:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 01:33:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 01:33:09 --> Final output sent to browser
DEBUG - 2020-03-05 01:33:09 --> Total execution time: 0.0058
INFO - 2020-03-05 01:33:46 --> Config Class Initialized
INFO - 2020-03-05 01:33:46 --> Hooks Class Initialized
DEBUG - 2020-03-05 01:33:46 --> UTF-8 Support Enabled
INFO - 2020-03-05 01:33:46 --> Utf8 Class Initialized
INFO - 2020-03-05 01:33:46 --> URI Class Initialized
INFO - 2020-03-05 01:33:46 --> Router Class Initialized
INFO - 2020-03-05 01:33:46 --> Output Class Initialized
INFO - 2020-03-05 01:33:46 --> Security Class Initialized
DEBUG - 2020-03-05 01:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 01:33:46 --> Input Class Initialized
INFO - 2020-03-05 01:33:46 --> Language Class Initialized
INFO - 2020-03-05 01:33:46 --> Loader Class Initialized
INFO - 2020-03-05 01:33:46 --> Helper loaded: url_helper
INFO - 2020-03-05 01:33:46 --> Helper loaded: string_helper
INFO - 2020-03-05 01:33:46 --> Database Driver Class Initialized
DEBUG - 2020-03-05 01:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 01:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 01:33:46 --> Controller Class Initialized
INFO - 2020-03-05 01:33:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 01:33:46 --> Pagination Class Initialized
INFO - 2020-03-05 01:33:46 --> Model "M_show" initialized
INFO - 2020-03-05 01:33:46 --> Helper loaded: form_helper
INFO - 2020-03-05 01:33:46 --> Form Validation Class Initialized
INFO - 2020-03-05 01:33:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 01:33:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 01:33:46 --> Final output sent to browser
DEBUG - 2020-03-05 01:33:46 --> Total execution time: 0.0079
INFO - 2020-03-05 01:33:48 --> Config Class Initialized
INFO - 2020-03-05 01:33:48 --> Hooks Class Initialized
DEBUG - 2020-03-05 01:33:48 --> UTF-8 Support Enabled
INFO - 2020-03-05 01:33:48 --> Utf8 Class Initialized
INFO - 2020-03-05 01:33:48 --> URI Class Initialized
INFO - 2020-03-05 01:33:48 --> Router Class Initialized
INFO - 2020-03-05 01:33:48 --> Output Class Initialized
INFO - 2020-03-05 01:33:48 --> Security Class Initialized
DEBUG - 2020-03-05 01:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 01:33:48 --> Input Class Initialized
INFO - 2020-03-05 01:33:48 --> Language Class Initialized
ERROR - 2020-03-05 01:33:48 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-05 01:34:01 --> Config Class Initialized
INFO - 2020-03-05 01:34:01 --> Hooks Class Initialized
DEBUG - 2020-03-05 01:34:01 --> UTF-8 Support Enabled
INFO - 2020-03-05 01:34:01 --> Utf8 Class Initialized
INFO - 2020-03-05 01:34:01 --> URI Class Initialized
INFO - 2020-03-05 01:34:01 --> Router Class Initialized
INFO - 2020-03-05 01:34:01 --> Output Class Initialized
INFO - 2020-03-05 01:34:01 --> Security Class Initialized
DEBUG - 2020-03-05 01:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 01:34:01 --> Input Class Initialized
INFO - 2020-03-05 01:34:01 --> Language Class Initialized
INFO - 2020-03-05 01:34:01 --> Loader Class Initialized
INFO - 2020-03-05 01:34:01 --> Helper loaded: url_helper
INFO - 2020-03-05 01:34:01 --> Helper loaded: string_helper
INFO - 2020-03-05 01:34:01 --> Database Driver Class Initialized
DEBUG - 2020-03-05 01:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 01:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 01:34:01 --> Controller Class Initialized
INFO - 2020-03-05 01:34:01 --> Model "M_tiket" initialized
INFO - 2020-03-05 01:34:01 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 01:34:01 --> Model "M_pesan" initialized
INFO - 2020-03-05 01:34:01 --> Helper loaded: form_helper
INFO - 2020-03-05 01:34:01 --> Form Validation Class Initialized
INFO - 2020-03-05 01:34:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 01:34:01 --> Final output sent to browser
DEBUG - 2020-03-05 01:34:01 --> Total execution time: 0.0096
INFO - 2020-03-05 01:34:16 --> Config Class Initialized
INFO - 2020-03-05 01:34:16 --> Hooks Class Initialized
DEBUG - 2020-03-05 01:34:16 --> UTF-8 Support Enabled
INFO - 2020-03-05 01:34:16 --> Utf8 Class Initialized
INFO - 2020-03-05 01:34:16 --> URI Class Initialized
INFO - 2020-03-05 01:34:16 --> Router Class Initialized
INFO - 2020-03-05 01:34:16 --> Output Class Initialized
INFO - 2020-03-05 01:34:16 --> Security Class Initialized
DEBUG - 2020-03-05 01:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 01:34:16 --> Input Class Initialized
INFO - 2020-03-05 01:34:16 --> Language Class Initialized
INFO - 2020-03-05 01:34:16 --> Loader Class Initialized
INFO - 2020-03-05 01:34:16 --> Helper loaded: url_helper
INFO - 2020-03-05 01:34:16 --> Helper loaded: string_helper
INFO - 2020-03-05 01:34:16 --> Database Driver Class Initialized
DEBUG - 2020-03-05 01:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 01:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 01:34:16 --> Controller Class Initialized
INFO - 2020-03-05 01:34:16 --> Model "M_tiket" initialized
INFO - 2020-03-05 01:34:16 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 01:34:16 --> Model "M_pesan" initialized
INFO - 2020-03-05 01:34:16 --> Helper loaded: form_helper
INFO - 2020-03-05 01:34:16 --> Form Validation Class Initialized
INFO - 2020-03-05 01:34:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-05 01:34:16 --> Final output sent to browser
DEBUG - 2020-03-05 01:34:16 --> Total execution time: 0.0077
INFO - 2020-03-05 01:45:17 --> Config Class Initialized
INFO - 2020-03-05 01:45:17 --> Hooks Class Initialized
DEBUG - 2020-03-05 01:45:17 --> UTF-8 Support Enabled
INFO - 2020-03-05 01:45:17 --> Utf8 Class Initialized
INFO - 2020-03-05 01:45:17 --> URI Class Initialized
INFO - 2020-03-05 01:45:17 --> Router Class Initialized
INFO - 2020-03-05 01:45:17 --> Output Class Initialized
INFO - 2020-03-05 01:45:17 --> Security Class Initialized
DEBUG - 2020-03-05 01:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 01:45:17 --> Input Class Initialized
INFO - 2020-03-05 01:45:17 --> Language Class Initialized
INFO - 2020-03-05 01:45:17 --> Loader Class Initialized
INFO - 2020-03-05 01:45:17 --> Helper loaded: url_helper
INFO - 2020-03-05 01:45:17 --> Helper loaded: string_helper
INFO - 2020-03-05 01:45:17 --> Database Driver Class Initialized
DEBUG - 2020-03-05 01:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 01:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 01:45:17 --> Controller Class Initialized
INFO - 2020-03-05 01:45:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 01:45:17 --> Pagination Class Initialized
INFO - 2020-03-05 01:45:17 --> Model "M_show" initialized
INFO - 2020-03-05 01:45:17 --> Helper loaded: form_helper
INFO - 2020-03-05 01:45:17 --> Form Validation Class Initialized
INFO - 2020-03-05 01:45:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 01:45:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 01:45:17 --> Final output sent to browser
DEBUG - 2020-03-05 01:45:17 --> Total execution time: 0.0324
INFO - 2020-03-05 01:45:54 --> Config Class Initialized
INFO - 2020-03-05 01:45:54 --> Hooks Class Initialized
DEBUG - 2020-03-05 01:45:54 --> UTF-8 Support Enabled
INFO - 2020-03-05 01:45:54 --> Utf8 Class Initialized
INFO - 2020-03-05 01:45:54 --> URI Class Initialized
DEBUG - 2020-03-05 01:45:54 --> No URI present. Default controller set.
INFO - 2020-03-05 01:45:54 --> Router Class Initialized
INFO - 2020-03-05 01:45:54 --> Output Class Initialized
INFO - 2020-03-05 01:45:54 --> Security Class Initialized
DEBUG - 2020-03-05 01:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 01:45:54 --> Input Class Initialized
INFO - 2020-03-05 01:45:54 --> Language Class Initialized
INFO - 2020-03-05 01:45:54 --> Loader Class Initialized
INFO - 2020-03-05 01:45:54 --> Helper loaded: url_helper
INFO - 2020-03-05 01:45:54 --> Helper loaded: string_helper
INFO - 2020-03-05 01:45:54 --> Database Driver Class Initialized
DEBUG - 2020-03-05 01:45:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 01:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 01:45:54 --> Controller Class Initialized
INFO - 2020-03-05 01:45:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 01:45:54 --> Pagination Class Initialized
INFO - 2020-03-05 01:45:54 --> Model "M_show" initialized
INFO - 2020-03-05 01:45:54 --> Helper loaded: form_helper
INFO - 2020-03-05 01:45:54 --> Form Validation Class Initialized
INFO - 2020-03-05 01:45:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 01:45:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 01:45:54 --> Final output sent to browser
DEBUG - 2020-03-05 01:45:54 --> Total execution time: 0.0060
INFO - 2020-03-05 01:46:07 --> Config Class Initialized
INFO - 2020-03-05 01:46:07 --> Hooks Class Initialized
DEBUG - 2020-03-05 01:46:07 --> UTF-8 Support Enabled
INFO - 2020-03-05 01:46:07 --> Utf8 Class Initialized
INFO - 2020-03-05 01:46:07 --> URI Class Initialized
INFO - 2020-03-05 01:46:07 --> Router Class Initialized
INFO - 2020-03-05 01:46:07 --> Output Class Initialized
INFO - 2020-03-05 01:46:07 --> Security Class Initialized
DEBUG - 2020-03-05 01:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 01:46:07 --> Input Class Initialized
INFO - 2020-03-05 01:46:07 --> Language Class Initialized
INFO - 2020-03-05 01:46:07 --> Loader Class Initialized
INFO - 2020-03-05 01:46:07 --> Helper loaded: url_helper
INFO - 2020-03-05 01:46:07 --> Helper loaded: string_helper
INFO - 2020-03-05 01:46:07 --> Database Driver Class Initialized
DEBUG - 2020-03-05 01:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 01:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 01:46:07 --> Controller Class Initialized
INFO - 2020-03-05 01:46:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 01:46:07 --> Pagination Class Initialized
INFO - 2020-03-05 01:46:07 --> Model "M_show" initialized
INFO - 2020-03-05 01:46:07 --> Helper loaded: form_helper
INFO - 2020-03-05 01:46:07 --> Form Validation Class Initialized
INFO - 2020-03-05 01:46:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 01:46:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-05 01:46:07 --> Final output sent to browser
DEBUG - 2020-03-05 01:46:07 --> Total execution time: 0.0643
INFO - 2020-03-05 01:46:28 --> Config Class Initialized
INFO - 2020-03-05 01:46:28 --> Hooks Class Initialized
DEBUG - 2020-03-05 01:46:28 --> UTF-8 Support Enabled
INFO - 2020-03-05 01:46:28 --> Utf8 Class Initialized
INFO - 2020-03-05 01:46:28 --> URI Class Initialized
INFO - 2020-03-05 01:46:28 --> Router Class Initialized
INFO - 2020-03-05 01:46:28 --> Output Class Initialized
INFO - 2020-03-05 01:46:28 --> Security Class Initialized
DEBUG - 2020-03-05 01:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 01:46:28 --> Input Class Initialized
INFO - 2020-03-05 01:46:28 --> Language Class Initialized
INFO - 2020-03-05 01:46:28 --> Loader Class Initialized
INFO - 2020-03-05 01:46:28 --> Helper loaded: url_helper
INFO - 2020-03-05 01:46:28 --> Helper loaded: string_helper
INFO - 2020-03-05 01:46:28 --> Database Driver Class Initialized
DEBUG - 2020-03-05 01:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 01:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 01:46:28 --> Controller Class Initialized
INFO - 2020-03-05 01:46:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 01:46:28 --> Pagination Class Initialized
INFO - 2020-03-05 01:46:28 --> Model "M_show" initialized
INFO - 2020-03-05 01:46:28 --> Helper loaded: form_helper
INFO - 2020-03-05 01:46:28 --> Form Validation Class Initialized
INFO - 2020-03-05 01:46:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 01:46:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 01:46:28 --> Final output sent to browser
DEBUG - 2020-03-05 01:46:28 --> Total execution time: 0.0061
INFO - 2020-03-05 01:46:31 --> Config Class Initialized
INFO - 2020-03-05 01:46:31 --> Hooks Class Initialized
DEBUG - 2020-03-05 01:46:31 --> UTF-8 Support Enabled
INFO - 2020-03-05 01:46:31 --> Utf8 Class Initialized
INFO - 2020-03-05 01:46:31 --> URI Class Initialized
INFO - 2020-03-05 01:46:31 --> Router Class Initialized
INFO - 2020-03-05 01:46:31 --> Output Class Initialized
INFO - 2020-03-05 01:46:31 --> Security Class Initialized
DEBUG - 2020-03-05 01:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 01:46:31 --> Input Class Initialized
INFO - 2020-03-05 01:46:31 --> Language Class Initialized
INFO - 2020-03-05 01:46:31 --> Loader Class Initialized
INFO - 2020-03-05 01:46:31 --> Helper loaded: url_helper
INFO - 2020-03-05 01:46:31 --> Helper loaded: string_helper
INFO - 2020-03-05 01:46:31 --> Database Driver Class Initialized
DEBUG - 2020-03-05 01:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 01:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 01:46:31 --> Controller Class Initialized
INFO - 2020-03-05 01:46:31 --> Model "M_tiket" initialized
INFO - 2020-03-05 01:46:31 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 01:46:31 --> Model "M_pesan" initialized
INFO - 2020-03-05 01:46:31 --> Helper loaded: form_helper
INFO - 2020-03-05 01:46:31 --> Form Validation Class Initialized
INFO - 2020-03-05 01:46:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 01:46:31 --> Final output sent to browser
DEBUG - 2020-03-05 01:46:31 --> Total execution time: 0.0097
INFO - 2020-03-05 01:46:38 --> Config Class Initialized
INFO - 2020-03-05 01:46:38 --> Hooks Class Initialized
DEBUG - 2020-03-05 01:46:38 --> UTF-8 Support Enabled
INFO - 2020-03-05 01:46:38 --> Utf8 Class Initialized
INFO - 2020-03-05 01:46:38 --> URI Class Initialized
INFO - 2020-03-05 01:46:38 --> Router Class Initialized
INFO - 2020-03-05 01:46:38 --> Output Class Initialized
INFO - 2020-03-05 01:46:38 --> Security Class Initialized
DEBUG - 2020-03-05 01:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 01:46:38 --> Input Class Initialized
INFO - 2020-03-05 01:46:38 --> Language Class Initialized
INFO - 2020-03-05 01:46:38 --> Loader Class Initialized
INFO - 2020-03-05 01:46:38 --> Helper loaded: url_helper
INFO - 2020-03-05 01:46:38 --> Helper loaded: string_helper
INFO - 2020-03-05 01:46:38 --> Database Driver Class Initialized
DEBUG - 2020-03-05 01:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 01:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 01:46:38 --> Controller Class Initialized
INFO - 2020-03-05 01:46:38 --> Model "M_tiket" initialized
INFO - 2020-03-05 01:46:38 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 01:46:38 --> Model "M_pesan" initialized
INFO - 2020-03-05 01:46:38 --> Helper loaded: form_helper
INFO - 2020-03-05 01:46:38 --> Form Validation Class Initialized
INFO - 2020-03-05 01:46:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-05 01:46:38 --> Final output sent to browser
DEBUG - 2020-03-05 01:46:38 --> Total execution time: 0.0075
INFO - 2020-03-05 01:48:16 --> Config Class Initialized
INFO - 2020-03-05 01:48:16 --> Hooks Class Initialized
DEBUG - 2020-03-05 01:48:16 --> UTF-8 Support Enabled
INFO - 2020-03-05 01:48:16 --> Utf8 Class Initialized
INFO - 2020-03-05 01:48:16 --> URI Class Initialized
INFO - 2020-03-05 01:48:16 --> Router Class Initialized
INFO - 2020-03-05 01:48:16 --> Output Class Initialized
INFO - 2020-03-05 01:48:16 --> Security Class Initialized
DEBUG - 2020-03-05 01:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 01:48:16 --> Input Class Initialized
INFO - 2020-03-05 01:48:16 --> Language Class Initialized
INFO - 2020-03-05 01:48:16 --> Loader Class Initialized
INFO - 2020-03-05 01:48:16 --> Helper loaded: url_helper
INFO - 2020-03-05 01:48:16 --> Helper loaded: string_helper
INFO - 2020-03-05 01:48:16 --> Database Driver Class Initialized
DEBUG - 2020-03-05 01:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 01:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 01:48:16 --> Controller Class Initialized
INFO - 2020-03-05 01:48:16 --> Model "M_tiket" initialized
INFO - 2020-03-05 01:48:16 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 01:48:16 --> Model "M_pesan" initialized
INFO - 2020-03-05 01:48:16 --> Helper loaded: form_helper
INFO - 2020-03-05 01:48:16 --> Form Validation Class Initialized
DEBUG - 2020-03-05 01:48:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-05 01:48:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-05 08:48:16 --> Final output sent to browser
DEBUG - 2020-03-05 08:48:16 --> Total execution time: 0.2642
INFO - 2020-03-05 01:48:19 --> Config Class Initialized
INFO - 2020-03-05 01:48:19 --> Hooks Class Initialized
DEBUG - 2020-03-05 01:48:19 --> UTF-8 Support Enabled
INFO - 2020-03-05 01:48:19 --> Utf8 Class Initialized
INFO - 2020-03-05 01:48:19 --> URI Class Initialized
INFO - 2020-03-05 01:48:19 --> Router Class Initialized
INFO - 2020-03-05 01:48:19 --> Output Class Initialized
INFO - 2020-03-05 01:48:19 --> Security Class Initialized
DEBUG - 2020-03-05 01:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 01:48:19 --> Input Class Initialized
INFO - 2020-03-05 01:48:19 --> Language Class Initialized
INFO - 2020-03-05 01:48:19 --> Loader Class Initialized
INFO - 2020-03-05 01:48:19 --> Helper loaded: url_helper
INFO - 2020-03-05 01:48:19 --> Helper loaded: string_helper
INFO - 2020-03-05 01:48:19 --> Database Driver Class Initialized
DEBUG - 2020-03-05 01:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 01:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 01:48:19 --> Controller Class Initialized
INFO - 2020-03-05 01:48:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 01:48:19 --> Pagination Class Initialized
INFO - 2020-03-05 01:48:19 --> Model "M_show" initialized
INFO - 2020-03-05 01:48:19 --> Helper loaded: form_helper
INFO - 2020-03-05 01:48:19 --> Form Validation Class Initialized
INFO - 2020-03-05 01:48:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 01:48:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 01:48:19 --> Final output sent to browser
DEBUG - 2020-03-05 01:48:19 --> Total execution time: 0.0082
INFO - 2020-03-05 01:48:48 --> Config Class Initialized
INFO - 2020-03-05 01:48:48 --> Hooks Class Initialized
DEBUG - 2020-03-05 01:48:48 --> UTF-8 Support Enabled
INFO - 2020-03-05 01:48:48 --> Utf8 Class Initialized
INFO - 2020-03-05 01:48:48 --> URI Class Initialized
INFO - 2020-03-05 01:48:48 --> Router Class Initialized
INFO - 2020-03-05 01:48:48 --> Output Class Initialized
INFO - 2020-03-05 01:48:48 --> Security Class Initialized
DEBUG - 2020-03-05 01:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 01:48:48 --> Input Class Initialized
INFO - 2020-03-05 01:48:48 --> Language Class Initialized
INFO - 2020-03-05 01:48:48 --> Loader Class Initialized
INFO - 2020-03-05 01:48:48 --> Helper loaded: url_helper
INFO - 2020-03-05 01:48:48 --> Helper loaded: string_helper
INFO - 2020-03-05 01:48:48 --> Database Driver Class Initialized
DEBUG - 2020-03-05 01:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 01:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 01:48:48 --> Controller Class Initialized
INFO - 2020-03-05 01:48:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 01:48:48 --> Pagination Class Initialized
INFO - 2020-03-05 01:48:48 --> Model "M_show" initialized
INFO - 2020-03-05 01:48:48 --> Helper loaded: form_helper
INFO - 2020-03-05 01:48:48 --> Form Validation Class Initialized
INFO - 2020-03-05 01:48:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 01:48:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/gal.php
INFO - 2020-03-05 01:48:48 --> Final output sent to browser
DEBUG - 2020-03-05 01:48:48 --> Total execution time: 0.0214
INFO - 2020-03-05 01:49:10 --> Config Class Initialized
INFO - 2020-03-05 01:49:10 --> Hooks Class Initialized
DEBUG - 2020-03-05 01:49:10 --> UTF-8 Support Enabled
INFO - 2020-03-05 01:49:10 --> Utf8 Class Initialized
INFO - 2020-03-05 01:49:10 --> URI Class Initialized
INFO - 2020-03-05 01:49:10 --> Router Class Initialized
INFO - 2020-03-05 01:49:10 --> Output Class Initialized
INFO - 2020-03-05 01:49:10 --> Security Class Initialized
DEBUG - 2020-03-05 01:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 01:49:10 --> Input Class Initialized
INFO - 2020-03-05 01:49:10 --> Language Class Initialized
INFO - 2020-03-05 01:49:10 --> Loader Class Initialized
INFO - 2020-03-05 01:49:10 --> Helper loaded: url_helper
INFO - 2020-03-05 01:49:10 --> Helper loaded: string_helper
INFO - 2020-03-05 01:49:10 --> Database Driver Class Initialized
DEBUG - 2020-03-05 01:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 01:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 01:49:10 --> Controller Class Initialized
INFO - 2020-03-05 01:49:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 01:49:10 --> Pagination Class Initialized
INFO - 2020-03-05 01:49:10 --> Model "M_show" initialized
INFO - 2020-03-05 01:49:10 --> Helper loaded: form_helper
INFO - 2020-03-05 01:49:10 --> Form Validation Class Initialized
INFO - 2020-03-05 01:49:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 01:49:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/hub.php
INFO - 2020-03-05 01:49:10 --> Final output sent to browser
DEBUG - 2020-03-05 01:49:10 --> Total execution time: 0.0054
INFO - 2020-03-05 01:49:20 --> Config Class Initialized
INFO - 2020-03-05 01:49:20 --> Hooks Class Initialized
DEBUG - 2020-03-05 01:49:20 --> UTF-8 Support Enabled
INFO - 2020-03-05 01:49:20 --> Utf8 Class Initialized
INFO - 2020-03-05 01:49:20 --> URI Class Initialized
INFO - 2020-03-05 01:49:20 --> Router Class Initialized
INFO - 2020-03-05 01:49:20 --> Output Class Initialized
INFO - 2020-03-05 01:49:20 --> Security Class Initialized
DEBUG - 2020-03-05 01:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 01:49:20 --> Input Class Initialized
INFO - 2020-03-05 01:49:20 --> Language Class Initialized
INFO - 2020-03-05 01:49:20 --> Loader Class Initialized
INFO - 2020-03-05 01:49:20 --> Helper loaded: url_helper
INFO - 2020-03-05 01:49:20 --> Helper loaded: string_helper
INFO - 2020-03-05 01:49:20 --> Database Driver Class Initialized
DEBUG - 2020-03-05 01:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 01:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 01:49:20 --> Controller Class Initialized
INFO - 2020-03-05 01:49:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 01:49:20 --> Pagination Class Initialized
INFO - 2020-03-05 01:49:20 --> Model "M_show" initialized
INFO - 2020-03-05 01:49:20 --> Helper loaded: form_helper
INFO - 2020-03-05 01:49:20 --> Form Validation Class Initialized
INFO - 2020-03-05 01:49:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 01:49:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/gal.php
INFO - 2020-03-05 01:49:20 --> Final output sent to browser
DEBUG - 2020-03-05 01:49:20 --> Total execution time: 0.0061
INFO - 2020-03-05 01:53:10 --> Config Class Initialized
INFO - 2020-03-05 01:53:10 --> Hooks Class Initialized
DEBUG - 2020-03-05 01:53:10 --> UTF-8 Support Enabled
INFO - 2020-03-05 01:53:10 --> Utf8 Class Initialized
INFO - 2020-03-05 01:53:10 --> URI Class Initialized
INFO - 2020-03-05 01:53:10 --> Router Class Initialized
INFO - 2020-03-05 01:53:10 --> Output Class Initialized
INFO - 2020-03-05 01:53:10 --> Security Class Initialized
DEBUG - 2020-03-05 01:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 01:53:10 --> Input Class Initialized
INFO - 2020-03-05 01:53:10 --> Language Class Initialized
INFO - 2020-03-05 01:53:10 --> Loader Class Initialized
INFO - 2020-03-05 01:53:10 --> Helper loaded: url_helper
INFO - 2020-03-05 01:53:10 --> Helper loaded: string_helper
INFO - 2020-03-05 01:53:10 --> Database Driver Class Initialized
DEBUG - 2020-03-05 01:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 01:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 01:53:10 --> Controller Class Initialized
INFO - 2020-03-05 01:53:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 01:53:10 --> Pagination Class Initialized
INFO - 2020-03-05 01:53:10 --> Model "M_show" initialized
INFO - 2020-03-05 01:53:10 --> Helper loaded: form_helper
INFO - 2020-03-05 01:53:10 --> Form Validation Class Initialized
INFO - 2020-03-05 01:53:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 01:53:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 01:53:10 --> Final output sent to browser
DEBUG - 2020-03-05 01:53:10 --> Total execution time: 0.0318
INFO - 2020-03-05 01:53:23 --> Config Class Initialized
INFO - 2020-03-05 01:53:23 --> Hooks Class Initialized
DEBUG - 2020-03-05 01:53:23 --> UTF-8 Support Enabled
INFO - 2020-03-05 01:53:23 --> Utf8 Class Initialized
INFO - 2020-03-05 01:53:23 --> URI Class Initialized
INFO - 2020-03-05 01:53:23 --> Router Class Initialized
INFO - 2020-03-05 01:53:23 --> Output Class Initialized
INFO - 2020-03-05 01:53:23 --> Security Class Initialized
DEBUG - 2020-03-05 01:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 01:53:23 --> Input Class Initialized
INFO - 2020-03-05 01:53:23 --> Language Class Initialized
INFO - 2020-03-05 01:53:23 --> Loader Class Initialized
INFO - 2020-03-05 01:53:23 --> Helper loaded: url_helper
INFO - 2020-03-05 01:53:23 --> Helper loaded: string_helper
INFO - 2020-03-05 01:53:23 --> Database Driver Class Initialized
DEBUG - 2020-03-05 01:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 01:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 01:53:23 --> Controller Class Initialized
INFO - 2020-03-05 01:53:23 --> Model "M_tiket" initialized
INFO - 2020-03-05 01:53:23 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 01:53:23 --> Model "M_pesan" initialized
INFO - 2020-03-05 01:53:23 --> Helper loaded: form_helper
INFO - 2020-03-05 01:53:23 --> Form Validation Class Initialized
INFO - 2020-03-05 01:53:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 01:53:23 --> Final output sent to browser
DEBUG - 2020-03-05 01:53:23 --> Total execution time: 0.0121
INFO - 2020-03-05 01:59:25 --> Config Class Initialized
INFO - 2020-03-05 01:59:25 --> Hooks Class Initialized
DEBUG - 2020-03-05 01:59:25 --> UTF-8 Support Enabled
INFO - 2020-03-05 01:59:25 --> Utf8 Class Initialized
INFO - 2020-03-05 01:59:25 --> URI Class Initialized
INFO - 2020-03-05 01:59:25 --> Router Class Initialized
INFO - 2020-03-05 01:59:25 --> Output Class Initialized
INFO - 2020-03-05 01:59:25 --> Security Class Initialized
DEBUG - 2020-03-05 01:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 01:59:25 --> Input Class Initialized
INFO - 2020-03-05 01:59:25 --> Language Class Initialized
INFO - 2020-03-05 01:59:25 --> Loader Class Initialized
INFO - 2020-03-05 01:59:25 --> Helper loaded: url_helper
INFO - 2020-03-05 01:59:25 --> Helper loaded: string_helper
INFO - 2020-03-05 01:59:25 --> Database Driver Class Initialized
DEBUG - 2020-03-05 01:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 01:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 01:59:25 --> Controller Class Initialized
INFO - 2020-03-05 01:59:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 01:59:25 --> Pagination Class Initialized
INFO - 2020-03-05 01:59:25 --> Model "M_show" initialized
INFO - 2020-03-05 01:59:25 --> Helper loaded: form_helper
INFO - 2020-03-05 01:59:25 --> Form Validation Class Initialized
INFO - 2020-03-05 01:59:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 01:59:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 01:59:25 --> Final output sent to browser
DEBUG - 2020-03-05 01:59:25 --> Total execution time: 0.0317
INFO - 2020-03-05 02:03:07 --> Config Class Initialized
INFO - 2020-03-05 02:03:07 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:03:07 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:03:07 --> Utf8 Class Initialized
INFO - 2020-03-05 02:03:07 --> URI Class Initialized
INFO - 2020-03-05 02:03:07 --> Router Class Initialized
INFO - 2020-03-05 02:03:07 --> Output Class Initialized
INFO - 2020-03-05 02:03:07 --> Security Class Initialized
DEBUG - 2020-03-05 02:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:03:07 --> Input Class Initialized
INFO - 2020-03-05 02:03:07 --> Language Class Initialized
INFO - 2020-03-05 02:03:07 --> Loader Class Initialized
INFO - 2020-03-05 02:03:07 --> Helper loaded: url_helper
INFO - 2020-03-05 02:03:07 --> Helper loaded: string_helper
INFO - 2020-03-05 02:03:07 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:03:07 --> Controller Class Initialized
INFO - 2020-03-05 02:03:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 02:03:07 --> Pagination Class Initialized
INFO - 2020-03-05 02:03:07 --> Model "M_show" initialized
INFO - 2020-03-05 02:03:07 --> Helper loaded: form_helper
INFO - 2020-03-05 02:03:07 --> Form Validation Class Initialized
INFO - 2020-03-05 02:03:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 02:03:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 02:03:07 --> Final output sent to browser
DEBUG - 2020-03-05 02:03:07 --> Total execution time: 0.0450
INFO - 2020-03-05 02:04:50 --> Config Class Initialized
INFO - 2020-03-05 02:04:50 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:04:50 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:04:50 --> Utf8 Class Initialized
INFO - 2020-03-05 02:04:50 --> URI Class Initialized
INFO - 2020-03-05 02:04:50 --> Router Class Initialized
INFO - 2020-03-05 02:04:50 --> Output Class Initialized
INFO - 2020-03-05 02:04:50 --> Security Class Initialized
DEBUG - 2020-03-05 02:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:04:50 --> Input Class Initialized
INFO - 2020-03-05 02:04:50 --> Language Class Initialized
INFO - 2020-03-05 02:04:50 --> Loader Class Initialized
INFO - 2020-03-05 02:04:50 --> Helper loaded: url_helper
INFO - 2020-03-05 02:04:50 --> Helper loaded: string_helper
INFO - 2020-03-05 02:04:50 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:04:50 --> Controller Class Initialized
INFO - 2020-03-05 02:04:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 02:04:50 --> Pagination Class Initialized
INFO - 2020-03-05 02:04:50 --> Model "M_show" initialized
INFO - 2020-03-05 02:04:50 --> Helper loaded: form_helper
INFO - 2020-03-05 02:04:50 --> Form Validation Class Initialized
INFO - 2020-03-05 02:04:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 02:04:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 02:04:50 --> Final output sent to browser
DEBUG - 2020-03-05 02:04:50 --> Total execution time: 0.1616
INFO - 2020-03-05 02:05:02 --> Config Class Initialized
INFO - 2020-03-05 02:05:02 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:05:02 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:05:02 --> Utf8 Class Initialized
INFO - 2020-03-05 02:05:02 --> URI Class Initialized
INFO - 2020-03-05 02:05:02 --> Router Class Initialized
INFO - 2020-03-05 02:05:02 --> Output Class Initialized
INFO - 2020-03-05 02:05:02 --> Security Class Initialized
DEBUG - 2020-03-05 02:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:05:02 --> Input Class Initialized
INFO - 2020-03-05 02:05:02 --> Language Class Initialized
INFO - 2020-03-05 02:05:02 --> Loader Class Initialized
INFO - 2020-03-05 02:05:02 --> Helper loaded: url_helper
INFO - 2020-03-05 02:05:02 --> Helper loaded: string_helper
INFO - 2020-03-05 02:05:02 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:05:02 --> Controller Class Initialized
INFO - 2020-03-05 02:05:02 --> Model "M_tiket" initialized
INFO - 2020-03-05 02:05:02 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 02:05:02 --> Model "M_pesan" initialized
INFO - 2020-03-05 02:05:02 --> Helper loaded: form_helper
INFO - 2020-03-05 02:05:02 --> Form Validation Class Initialized
INFO - 2020-03-05 02:05:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 02:05:02 --> Final output sent to browser
DEBUG - 2020-03-05 02:05:02 --> Total execution time: 0.0100
INFO - 2020-03-05 02:05:02 --> Config Class Initialized
INFO - 2020-03-05 02:05:02 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:05:02 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:05:02 --> Utf8 Class Initialized
INFO - 2020-03-05 02:05:02 --> URI Class Initialized
INFO - 2020-03-05 02:05:02 --> Router Class Initialized
INFO - 2020-03-05 02:05:02 --> Output Class Initialized
INFO - 2020-03-05 02:05:02 --> Security Class Initialized
DEBUG - 2020-03-05 02:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:05:02 --> Input Class Initialized
INFO - 2020-03-05 02:05:02 --> Language Class Initialized
INFO - 2020-03-05 02:05:02 --> Loader Class Initialized
INFO - 2020-03-05 02:05:02 --> Helper loaded: url_helper
INFO - 2020-03-05 02:05:02 --> Helper loaded: string_helper
INFO - 2020-03-05 02:05:02 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:05:02 --> Controller Class Initialized
INFO - 2020-03-05 02:05:02 --> Model "M_tiket" initialized
INFO - 2020-03-05 02:05:02 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 02:05:02 --> Model "M_pesan" initialized
INFO - 2020-03-05 02:05:02 --> Helper loaded: form_helper
INFO - 2020-03-05 02:05:02 --> Form Validation Class Initialized
INFO - 2020-03-05 02:05:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 02:05:02 --> Final output sent to browser
DEBUG - 2020-03-05 02:05:02 --> Total execution time: 0.0047
INFO - 2020-03-05 02:05:06 --> Config Class Initialized
INFO - 2020-03-05 02:05:06 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:05:06 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:05:06 --> Utf8 Class Initialized
INFO - 2020-03-05 02:05:06 --> URI Class Initialized
INFO - 2020-03-05 02:05:06 --> Router Class Initialized
INFO - 2020-03-05 02:05:06 --> Output Class Initialized
INFO - 2020-03-05 02:05:06 --> Security Class Initialized
DEBUG - 2020-03-05 02:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:05:06 --> Input Class Initialized
INFO - 2020-03-05 02:05:06 --> Language Class Initialized
INFO - 2020-03-05 02:05:06 --> Loader Class Initialized
INFO - 2020-03-05 02:05:06 --> Helper loaded: url_helper
INFO - 2020-03-05 02:05:06 --> Helper loaded: string_helper
INFO - 2020-03-05 02:05:06 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:05:06 --> Controller Class Initialized
INFO - 2020-03-05 02:05:06 --> Model "M_tiket" initialized
INFO - 2020-03-05 02:05:06 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 02:05:06 --> Model "M_pesan" initialized
INFO - 2020-03-05 02:05:06 --> Helper loaded: form_helper
INFO - 2020-03-05 02:05:06 --> Form Validation Class Initialized
INFO - 2020-03-05 02:05:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-05 02:05:06 --> Final output sent to browser
DEBUG - 2020-03-05 02:05:06 --> Total execution time: 0.0089
INFO - 2020-03-05 02:05:06 --> Config Class Initialized
INFO - 2020-03-05 02:05:06 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:05:06 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:05:06 --> Utf8 Class Initialized
INFO - 2020-03-05 02:05:06 --> URI Class Initialized
INFO - 2020-03-05 02:05:06 --> Router Class Initialized
INFO - 2020-03-05 02:05:06 --> Output Class Initialized
INFO - 2020-03-05 02:05:06 --> Security Class Initialized
DEBUG - 2020-03-05 02:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:05:06 --> Input Class Initialized
INFO - 2020-03-05 02:05:06 --> Language Class Initialized
INFO - 2020-03-05 02:05:06 --> Loader Class Initialized
INFO - 2020-03-05 02:05:06 --> Helper loaded: url_helper
INFO - 2020-03-05 02:05:06 --> Helper loaded: string_helper
INFO - 2020-03-05 02:05:06 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:05:06 --> Controller Class Initialized
INFO - 2020-03-05 02:05:06 --> Model "M_tiket" initialized
INFO - 2020-03-05 02:05:06 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 02:05:06 --> Model "M_pesan" initialized
INFO - 2020-03-05 02:05:06 --> Helper loaded: form_helper
INFO - 2020-03-05 02:05:06 --> Form Validation Class Initialized
INFO - 2020-03-05 02:05:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-05 02:05:06 --> Final output sent to browser
DEBUG - 2020-03-05 02:05:06 --> Total execution time: 0.0075
INFO - 2020-03-05 02:05:06 --> Config Class Initialized
INFO - 2020-03-05 02:05:06 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:05:06 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:05:06 --> Utf8 Class Initialized
INFO - 2020-03-05 02:05:06 --> URI Class Initialized
INFO - 2020-03-05 02:05:06 --> Router Class Initialized
INFO - 2020-03-05 02:05:06 --> Output Class Initialized
INFO - 2020-03-05 02:05:06 --> Security Class Initialized
DEBUG - 2020-03-05 02:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:05:06 --> Input Class Initialized
INFO - 2020-03-05 02:05:06 --> Language Class Initialized
INFO - 2020-03-05 02:05:06 --> Loader Class Initialized
INFO - 2020-03-05 02:05:06 --> Helper loaded: url_helper
INFO - 2020-03-05 02:05:06 --> Helper loaded: string_helper
INFO - 2020-03-05 02:05:06 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:05:06 --> Controller Class Initialized
INFO - 2020-03-05 02:05:06 --> Model "M_tiket" initialized
INFO - 2020-03-05 02:05:06 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 02:05:06 --> Model "M_pesan" initialized
INFO - 2020-03-05 02:05:06 --> Helper loaded: form_helper
INFO - 2020-03-05 02:05:06 --> Form Validation Class Initialized
INFO - 2020-03-05 02:05:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-05 02:05:06 --> Final output sent to browser
DEBUG - 2020-03-05 02:05:06 --> Total execution time: 0.0045
INFO - 2020-03-05 02:05:39 --> Config Class Initialized
INFO - 2020-03-05 02:05:39 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:05:39 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:05:39 --> Utf8 Class Initialized
INFO - 2020-03-05 02:05:39 --> URI Class Initialized
INFO - 2020-03-05 02:05:39 --> Router Class Initialized
INFO - 2020-03-05 02:05:39 --> Output Class Initialized
INFO - 2020-03-05 02:05:39 --> Security Class Initialized
DEBUG - 2020-03-05 02:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:05:39 --> Input Class Initialized
INFO - 2020-03-05 02:05:39 --> Language Class Initialized
INFO - 2020-03-05 02:05:39 --> Loader Class Initialized
INFO - 2020-03-05 02:05:39 --> Helper loaded: url_helper
INFO - 2020-03-05 02:05:39 --> Helper loaded: string_helper
INFO - 2020-03-05 02:05:39 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:05:39 --> Controller Class Initialized
INFO - 2020-03-05 02:05:39 --> Model "M_tiket" initialized
INFO - 2020-03-05 02:05:39 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 02:05:39 --> Model "M_pesan" initialized
INFO - 2020-03-05 02:05:39 --> Helper loaded: form_helper
INFO - 2020-03-05 02:05:39 --> Form Validation Class Initialized
INFO - 2020-03-05 02:05:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 02:05:39 --> Final output sent to browser
DEBUG - 2020-03-05 02:05:39 --> Total execution time: 0.0079
INFO - 2020-03-05 02:05:39 --> Config Class Initialized
INFO - 2020-03-05 02:05:39 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:05:39 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:05:39 --> Utf8 Class Initialized
INFO - 2020-03-05 02:05:39 --> URI Class Initialized
INFO - 2020-03-05 02:05:39 --> Router Class Initialized
INFO - 2020-03-05 02:05:39 --> Output Class Initialized
INFO - 2020-03-05 02:05:39 --> Security Class Initialized
DEBUG - 2020-03-05 02:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:05:39 --> Input Class Initialized
INFO - 2020-03-05 02:05:39 --> Language Class Initialized
INFO - 2020-03-05 02:05:39 --> Loader Class Initialized
INFO - 2020-03-05 02:05:39 --> Helper loaded: url_helper
INFO - 2020-03-05 02:05:39 --> Helper loaded: string_helper
INFO - 2020-03-05 02:05:39 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:05:39 --> Controller Class Initialized
INFO - 2020-03-05 02:05:39 --> Model "M_tiket" initialized
INFO - 2020-03-05 02:05:39 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 02:05:39 --> Model "M_pesan" initialized
INFO - 2020-03-05 02:05:39 --> Helper loaded: form_helper
INFO - 2020-03-05 02:05:39 --> Form Validation Class Initialized
INFO - 2020-03-05 02:05:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 02:05:39 --> Final output sent to browser
DEBUG - 2020-03-05 02:05:39 --> Total execution time: 0.0066
INFO - 2020-03-05 02:05:43 --> Config Class Initialized
INFO - 2020-03-05 02:05:43 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:05:43 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:05:43 --> Utf8 Class Initialized
INFO - 2020-03-05 02:05:43 --> URI Class Initialized
INFO - 2020-03-05 02:05:43 --> Router Class Initialized
INFO - 2020-03-05 02:05:43 --> Output Class Initialized
INFO - 2020-03-05 02:05:43 --> Security Class Initialized
DEBUG - 2020-03-05 02:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:05:43 --> Input Class Initialized
INFO - 2020-03-05 02:05:43 --> Language Class Initialized
INFO - 2020-03-05 02:05:43 --> Loader Class Initialized
INFO - 2020-03-05 02:05:43 --> Helper loaded: url_helper
INFO - 2020-03-05 02:05:43 --> Helper loaded: string_helper
INFO - 2020-03-05 02:05:43 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:05:43 --> Controller Class Initialized
INFO - 2020-03-05 02:05:43 --> Model "M_tiket" initialized
INFO - 2020-03-05 02:05:43 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 02:05:43 --> Model "M_pesan" initialized
INFO - 2020-03-05 02:05:43 --> Helper loaded: form_helper
INFO - 2020-03-05 02:05:43 --> Form Validation Class Initialized
INFO - 2020-03-05 02:05:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-05 02:05:43 --> Final output sent to browser
DEBUG - 2020-03-05 02:05:43 --> Total execution time: 0.0069
INFO - 2020-03-05 02:05:43 --> Config Class Initialized
INFO - 2020-03-05 02:05:43 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:05:43 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:05:43 --> Utf8 Class Initialized
INFO - 2020-03-05 02:05:43 --> URI Class Initialized
INFO - 2020-03-05 02:05:43 --> Router Class Initialized
INFO - 2020-03-05 02:05:43 --> Output Class Initialized
INFO - 2020-03-05 02:05:43 --> Security Class Initialized
DEBUG - 2020-03-05 02:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:05:43 --> Input Class Initialized
INFO - 2020-03-05 02:05:43 --> Language Class Initialized
INFO - 2020-03-05 02:05:43 --> Loader Class Initialized
INFO - 2020-03-05 02:05:43 --> Helper loaded: url_helper
INFO - 2020-03-05 02:05:43 --> Helper loaded: string_helper
INFO - 2020-03-05 02:05:43 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:05:43 --> Controller Class Initialized
INFO - 2020-03-05 02:05:43 --> Model "M_tiket" initialized
INFO - 2020-03-05 02:05:43 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 02:05:43 --> Model "M_pesan" initialized
INFO - 2020-03-05 02:05:43 --> Helper loaded: form_helper
INFO - 2020-03-05 02:05:43 --> Form Validation Class Initialized
INFO - 2020-03-05 02:05:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-05 02:05:43 --> Final output sent to browser
DEBUG - 2020-03-05 02:05:43 --> Total execution time: 0.0074
INFO - 2020-03-05 02:05:44 --> Config Class Initialized
INFO - 2020-03-05 02:05:44 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:05:44 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:05:44 --> Utf8 Class Initialized
INFO - 2020-03-05 02:05:44 --> URI Class Initialized
INFO - 2020-03-05 02:05:44 --> Router Class Initialized
INFO - 2020-03-05 02:05:44 --> Output Class Initialized
INFO - 2020-03-05 02:05:44 --> Security Class Initialized
DEBUG - 2020-03-05 02:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:05:44 --> Input Class Initialized
INFO - 2020-03-05 02:05:44 --> Language Class Initialized
INFO - 2020-03-05 02:05:44 --> Loader Class Initialized
INFO - 2020-03-05 02:05:44 --> Helper loaded: url_helper
INFO - 2020-03-05 02:05:44 --> Helper loaded: string_helper
INFO - 2020-03-05 02:05:44 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:05:44 --> Controller Class Initialized
INFO - 2020-03-05 02:05:44 --> Model "M_tiket" initialized
INFO - 2020-03-05 02:05:44 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 02:05:44 --> Model "M_pesan" initialized
INFO - 2020-03-05 02:05:44 --> Helper loaded: form_helper
INFO - 2020-03-05 02:05:44 --> Form Validation Class Initialized
INFO - 2020-03-05 02:05:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-05 02:05:44 --> Final output sent to browser
DEBUG - 2020-03-05 02:05:44 --> Total execution time: 0.0068
INFO - 2020-03-05 02:17:43 --> Config Class Initialized
INFO - 2020-03-05 02:17:43 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:17:43 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:17:43 --> Utf8 Class Initialized
INFO - 2020-03-05 02:17:43 --> URI Class Initialized
INFO - 2020-03-05 02:17:43 --> Router Class Initialized
INFO - 2020-03-05 02:17:43 --> Output Class Initialized
INFO - 2020-03-05 02:17:43 --> Security Class Initialized
DEBUG - 2020-03-05 02:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:17:43 --> Input Class Initialized
INFO - 2020-03-05 02:17:43 --> Language Class Initialized
INFO - 2020-03-05 02:17:43 --> Loader Class Initialized
INFO - 2020-03-05 02:17:43 --> Helper loaded: url_helper
INFO - 2020-03-05 02:17:43 --> Helper loaded: string_helper
INFO - 2020-03-05 02:17:43 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:17:43 --> Controller Class Initialized
INFO - 2020-03-05 02:17:43 --> Model "M_tiket" initialized
INFO - 2020-03-05 02:17:43 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 02:17:43 --> Model "M_pesan" initialized
INFO - 2020-03-05 02:17:43 --> Helper loaded: form_helper
INFO - 2020-03-05 02:17:43 --> Form Validation Class Initialized
INFO - 2020-03-05 02:17:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 02:17:43 --> Final output sent to browser
DEBUG - 2020-03-05 02:17:43 --> Total execution time: 0.0371
INFO - 2020-03-05 02:22:49 --> Config Class Initialized
INFO - 2020-03-05 02:22:49 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:22:49 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:22:49 --> Utf8 Class Initialized
INFO - 2020-03-05 02:22:49 --> URI Class Initialized
INFO - 2020-03-05 02:22:49 --> Router Class Initialized
INFO - 2020-03-05 02:22:49 --> Output Class Initialized
INFO - 2020-03-05 02:22:49 --> Security Class Initialized
DEBUG - 2020-03-05 02:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:22:49 --> Input Class Initialized
INFO - 2020-03-05 02:22:49 --> Language Class Initialized
INFO - 2020-03-05 02:22:49 --> Loader Class Initialized
INFO - 2020-03-05 02:22:49 --> Helper loaded: url_helper
INFO - 2020-03-05 02:22:49 --> Helper loaded: string_helper
INFO - 2020-03-05 02:22:49 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:22:49 --> Controller Class Initialized
INFO - 2020-03-05 02:22:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 02:22:49 --> Pagination Class Initialized
INFO - 2020-03-05 02:22:49 --> Model "M_show" initialized
INFO - 2020-03-05 02:22:49 --> Helper loaded: form_helper
INFO - 2020-03-05 02:22:49 --> Form Validation Class Initialized
INFO - 2020-03-05 02:22:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 02:22:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 02:22:49 --> Final output sent to browser
DEBUG - 2020-03-05 02:22:49 --> Total execution time: 0.1692
INFO - 2020-03-05 02:29:26 --> Config Class Initialized
INFO - 2020-03-05 02:29:26 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:29:26 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:29:26 --> Utf8 Class Initialized
INFO - 2020-03-05 02:29:26 --> URI Class Initialized
INFO - 2020-03-05 02:29:26 --> Router Class Initialized
INFO - 2020-03-05 02:29:26 --> Output Class Initialized
INFO - 2020-03-05 02:29:26 --> Security Class Initialized
DEBUG - 2020-03-05 02:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:29:26 --> Input Class Initialized
INFO - 2020-03-05 02:29:26 --> Language Class Initialized
INFO - 2020-03-05 02:29:26 --> Loader Class Initialized
INFO - 2020-03-05 02:29:26 --> Helper loaded: url_helper
INFO - 2020-03-05 02:29:26 --> Helper loaded: string_helper
INFO - 2020-03-05 02:29:26 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:29:26 --> Controller Class Initialized
INFO - 2020-03-05 02:29:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 02:29:26 --> Pagination Class Initialized
INFO - 2020-03-05 02:29:26 --> Model "M_show" initialized
INFO - 2020-03-05 02:29:26 --> Helper loaded: form_helper
INFO - 2020-03-05 02:29:26 --> Form Validation Class Initialized
INFO - 2020-03-05 02:29:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 02:29:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 02:29:26 --> Final output sent to browser
DEBUG - 2020-03-05 02:29:26 --> Total execution time: 0.0572
INFO - 2020-03-05 02:41:40 --> Config Class Initialized
INFO - 2020-03-05 02:41:40 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:41:40 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:41:40 --> Utf8 Class Initialized
INFO - 2020-03-05 02:41:40 --> URI Class Initialized
DEBUG - 2020-03-05 02:41:40 --> No URI present. Default controller set.
INFO - 2020-03-05 02:41:40 --> Router Class Initialized
INFO - 2020-03-05 02:41:40 --> Output Class Initialized
INFO - 2020-03-05 02:41:40 --> Security Class Initialized
DEBUG - 2020-03-05 02:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:41:40 --> Input Class Initialized
INFO - 2020-03-05 02:41:40 --> Language Class Initialized
INFO - 2020-03-05 02:41:40 --> Loader Class Initialized
INFO - 2020-03-05 02:41:40 --> Helper loaded: url_helper
INFO - 2020-03-05 02:41:40 --> Helper loaded: string_helper
INFO - 2020-03-05 02:41:40 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:41:40 --> Controller Class Initialized
INFO - 2020-03-05 02:41:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 02:41:40 --> Pagination Class Initialized
INFO - 2020-03-05 02:41:40 --> Model "M_show" initialized
INFO - 2020-03-05 02:41:40 --> Helper loaded: form_helper
INFO - 2020-03-05 02:41:40 --> Form Validation Class Initialized
INFO - 2020-03-05 02:41:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 02:41:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 02:41:40 --> Final output sent to browser
DEBUG - 2020-03-05 02:41:40 --> Total execution time: 0.0294
INFO - 2020-03-05 02:41:51 --> Config Class Initialized
INFO - 2020-03-05 02:41:51 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:41:51 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:41:51 --> Utf8 Class Initialized
INFO - 2020-03-05 02:41:51 --> URI Class Initialized
INFO - 2020-03-05 02:41:51 --> Router Class Initialized
INFO - 2020-03-05 02:41:51 --> Output Class Initialized
INFO - 2020-03-05 02:41:51 --> Security Class Initialized
DEBUG - 2020-03-05 02:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:41:51 --> Input Class Initialized
INFO - 2020-03-05 02:41:51 --> Language Class Initialized
INFO - 2020-03-05 02:41:51 --> Loader Class Initialized
INFO - 2020-03-05 02:41:51 --> Helper loaded: url_helper
INFO - 2020-03-05 02:41:51 --> Helper loaded: string_helper
INFO - 2020-03-05 02:41:51 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:41:51 --> Controller Class Initialized
INFO - 2020-03-05 02:41:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 02:41:51 --> Pagination Class Initialized
INFO - 2020-03-05 02:41:51 --> Model "M_show" initialized
INFO - 2020-03-05 02:41:51 --> Helper loaded: form_helper
INFO - 2020-03-05 02:41:51 --> Form Validation Class Initialized
INFO - 2020-03-05 02:41:51 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 02:41:51 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 02:41:51 --> Final output sent to browser
DEBUG - 2020-03-05 02:41:51 --> Total execution time: 0.0093
INFO - 2020-03-05 02:41:54 --> Config Class Initialized
INFO - 2020-03-05 02:41:54 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:41:54 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:41:54 --> Utf8 Class Initialized
INFO - 2020-03-05 02:41:54 --> URI Class Initialized
INFO - 2020-03-05 02:41:54 --> Router Class Initialized
INFO - 2020-03-05 02:41:54 --> Output Class Initialized
INFO - 2020-03-05 02:41:54 --> Security Class Initialized
DEBUG - 2020-03-05 02:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:41:54 --> Input Class Initialized
INFO - 2020-03-05 02:41:54 --> Language Class Initialized
ERROR - 2020-03-05 02:41:54 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-05 02:41:59 --> Config Class Initialized
INFO - 2020-03-05 02:41:59 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:41:59 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:41:59 --> Utf8 Class Initialized
INFO - 2020-03-05 02:41:59 --> URI Class Initialized
INFO - 2020-03-05 02:41:59 --> Router Class Initialized
INFO - 2020-03-05 02:41:59 --> Output Class Initialized
INFO - 2020-03-05 02:41:59 --> Security Class Initialized
DEBUG - 2020-03-05 02:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:41:59 --> Input Class Initialized
INFO - 2020-03-05 02:41:59 --> Language Class Initialized
INFO - 2020-03-05 02:41:59 --> Loader Class Initialized
INFO - 2020-03-05 02:41:59 --> Helper loaded: url_helper
INFO - 2020-03-05 02:41:59 --> Helper loaded: string_helper
INFO - 2020-03-05 02:41:59 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:41:59 --> Controller Class Initialized
INFO - 2020-03-05 02:41:59 --> Model "M_tiket" initialized
INFO - 2020-03-05 02:41:59 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 02:41:59 --> Model "M_pesan" initialized
INFO - 2020-03-05 02:41:59 --> Helper loaded: form_helper
INFO - 2020-03-05 02:41:59 --> Form Validation Class Initialized
INFO - 2020-03-05 02:41:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 02:41:59 --> Final output sent to browser
DEBUG - 2020-03-05 02:41:59 --> Total execution time: 0.0100
INFO - 2020-03-05 02:42:07 --> Config Class Initialized
INFO - 2020-03-05 02:42:07 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:42:07 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:42:07 --> Utf8 Class Initialized
INFO - 2020-03-05 02:42:07 --> URI Class Initialized
INFO - 2020-03-05 02:42:07 --> Router Class Initialized
INFO - 2020-03-05 02:42:07 --> Output Class Initialized
INFO - 2020-03-05 02:42:07 --> Security Class Initialized
DEBUG - 2020-03-05 02:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:42:07 --> Input Class Initialized
INFO - 2020-03-05 02:42:07 --> Language Class Initialized
INFO - 2020-03-05 02:42:07 --> Loader Class Initialized
INFO - 2020-03-05 02:42:07 --> Helper loaded: url_helper
INFO - 2020-03-05 02:42:07 --> Helper loaded: string_helper
INFO - 2020-03-05 02:42:07 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:42:07 --> Controller Class Initialized
INFO - 2020-03-05 02:42:07 --> Model "M_tiket" initialized
INFO - 2020-03-05 02:42:07 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 02:42:07 --> Model "M_pesan" initialized
INFO - 2020-03-05 02:42:07 --> Helper loaded: form_helper
INFO - 2020-03-05 02:42:07 --> Form Validation Class Initialized
INFO - 2020-03-05 02:42:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-05 02:42:07 --> Final output sent to browser
DEBUG - 2020-03-05 02:42:07 --> Total execution time: 0.0090
INFO - 2020-03-05 02:42:25 --> Config Class Initialized
INFO - 2020-03-05 02:42:25 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:42:25 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:42:25 --> Utf8 Class Initialized
INFO - 2020-03-05 02:42:25 --> URI Class Initialized
INFO - 2020-03-05 02:42:25 --> Router Class Initialized
INFO - 2020-03-05 02:42:25 --> Output Class Initialized
INFO - 2020-03-05 02:42:25 --> Security Class Initialized
DEBUG - 2020-03-05 02:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:42:25 --> Input Class Initialized
INFO - 2020-03-05 02:42:25 --> Language Class Initialized
INFO - 2020-03-05 02:42:25 --> Loader Class Initialized
INFO - 2020-03-05 02:42:25 --> Helper loaded: url_helper
INFO - 2020-03-05 02:42:25 --> Helper loaded: string_helper
INFO - 2020-03-05 02:42:25 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:42:25 --> Controller Class Initialized
INFO - 2020-03-05 02:42:25 --> Model "M_tiket" initialized
INFO - 2020-03-05 02:42:25 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 02:42:25 --> Model "M_pesan" initialized
INFO - 2020-03-05 02:42:25 --> Helper loaded: form_helper
INFO - 2020-03-05 02:42:25 --> Form Validation Class Initialized
INFO - 2020-03-05 02:42:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 02:42:25 --> Final output sent to browser
DEBUG - 2020-03-05 02:42:25 --> Total execution time: 0.0078
INFO - 2020-03-05 02:42:27 --> Config Class Initialized
INFO - 2020-03-05 02:42:27 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:42:27 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:42:27 --> Utf8 Class Initialized
INFO - 2020-03-05 02:42:27 --> URI Class Initialized
INFO - 2020-03-05 02:42:27 --> Router Class Initialized
INFO - 2020-03-05 02:42:27 --> Output Class Initialized
INFO - 2020-03-05 02:42:27 --> Security Class Initialized
DEBUG - 2020-03-05 02:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:42:27 --> Input Class Initialized
INFO - 2020-03-05 02:42:27 --> Language Class Initialized
INFO - 2020-03-05 02:42:27 --> Loader Class Initialized
INFO - 2020-03-05 02:42:27 --> Helper loaded: url_helper
INFO - 2020-03-05 02:42:27 --> Helper loaded: string_helper
INFO - 2020-03-05 02:42:27 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:42:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:42:27 --> Controller Class Initialized
INFO - 2020-03-05 02:42:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 02:42:27 --> Pagination Class Initialized
INFO - 2020-03-05 02:42:27 --> Model "M_show" initialized
INFO - 2020-03-05 02:42:27 --> Helper loaded: form_helper
INFO - 2020-03-05 02:42:27 --> Form Validation Class Initialized
INFO - 2020-03-05 02:42:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 02:42:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 02:42:27 --> Final output sent to browser
DEBUG - 2020-03-05 02:42:27 --> Total execution time: 0.0073
INFO - 2020-03-05 02:42:31 --> Config Class Initialized
INFO - 2020-03-05 02:42:31 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:42:31 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:42:31 --> Utf8 Class Initialized
INFO - 2020-03-05 02:42:31 --> URI Class Initialized
INFO - 2020-03-05 02:42:31 --> Router Class Initialized
INFO - 2020-03-05 02:42:31 --> Output Class Initialized
INFO - 2020-03-05 02:42:31 --> Security Class Initialized
DEBUG - 2020-03-05 02:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:42:31 --> Input Class Initialized
INFO - 2020-03-05 02:42:31 --> Language Class Initialized
INFO - 2020-03-05 02:42:31 --> Loader Class Initialized
INFO - 2020-03-05 02:42:31 --> Helper loaded: url_helper
INFO - 2020-03-05 02:42:31 --> Helper loaded: string_helper
INFO - 2020-03-05 02:42:31 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:42:31 --> Controller Class Initialized
INFO - 2020-03-05 02:42:31 --> Model "M_tiket" initialized
INFO - 2020-03-05 02:42:31 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 02:42:31 --> Model "M_pesan" initialized
INFO - 2020-03-05 02:42:31 --> Helper loaded: form_helper
INFO - 2020-03-05 02:42:31 --> Form Validation Class Initialized
INFO - 2020-03-05 02:42:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 02:42:31 --> Final output sent to browser
DEBUG - 2020-03-05 02:42:31 --> Total execution time: 0.0073
INFO - 2020-03-05 02:42:46 --> Config Class Initialized
INFO - 2020-03-05 02:42:46 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:42:46 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:42:46 --> Utf8 Class Initialized
INFO - 2020-03-05 02:42:46 --> URI Class Initialized
DEBUG - 2020-03-05 02:42:46 --> No URI present. Default controller set.
INFO - 2020-03-05 02:42:46 --> Router Class Initialized
INFO - 2020-03-05 02:42:46 --> Output Class Initialized
INFO - 2020-03-05 02:42:46 --> Security Class Initialized
DEBUG - 2020-03-05 02:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:42:46 --> Input Class Initialized
INFO - 2020-03-05 02:42:46 --> Language Class Initialized
INFO - 2020-03-05 02:42:46 --> Loader Class Initialized
INFO - 2020-03-05 02:42:46 --> Helper loaded: url_helper
INFO - 2020-03-05 02:42:46 --> Helper loaded: string_helper
INFO - 2020-03-05 02:42:46 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:42:46 --> Controller Class Initialized
INFO - 2020-03-05 02:42:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 02:42:46 --> Pagination Class Initialized
INFO - 2020-03-05 02:42:46 --> Model "M_show" initialized
INFO - 2020-03-05 02:42:46 --> Helper loaded: form_helper
INFO - 2020-03-05 02:42:46 --> Form Validation Class Initialized
INFO - 2020-03-05 02:42:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 02:42:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 02:42:46 --> Final output sent to browser
DEBUG - 2020-03-05 02:42:46 --> Total execution time: 0.0050
INFO - 2020-03-05 02:51:27 --> Config Class Initialized
INFO - 2020-03-05 02:51:27 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:51:27 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:51:27 --> Utf8 Class Initialized
INFO - 2020-03-05 02:51:27 --> URI Class Initialized
INFO - 2020-03-05 02:51:27 --> Router Class Initialized
INFO - 2020-03-05 02:51:27 --> Output Class Initialized
INFO - 2020-03-05 02:51:27 --> Security Class Initialized
DEBUG - 2020-03-05 02:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:51:27 --> Input Class Initialized
INFO - 2020-03-05 02:51:27 --> Language Class Initialized
INFO - 2020-03-05 02:51:27 --> Loader Class Initialized
INFO - 2020-03-05 02:51:27 --> Helper loaded: url_helper
INFO - 2020-03-05 02:51:27 --> Helper loaded: string_helper
INFO - 2020-03-05 02:51:27 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:51:27 --> Controller Class Initialized
INFO - 2020-03-05 02:51:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 02:51:27 --> Pagination Class Initialized
INFO - 2020-03-05 02:51:27 --> Model "M_show" initialized
INFO - 2020-03-05 02:51:27 --> Helper loaded: form_helper
INFO - 2020-03-05 02:51:27 --> Form Validation Class Initialized
INFO - 2020-03-05 02:51:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 02:51:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 02:51:27 --> Final output sent to browser
DEBUG - 2020-03-05 02:51:27 --> Total execution time: 0.0376
INFO - 2020-03-05 02:58:50 --> Config Class Initialized
INFO - 2020-03-05 02:58:50 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:58:50 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:58:50 --> Utf8 Class Initialized
INFO - 2020-03-05 02:58:50 --> URI Class Initialized
DEBUG - 2020-03-05 02:58:50 --> No URI present. Default controller set.
INFO - 2020-03-05 02:58:50 --> Router Class Initialized
INFO - 2020-03-05 02:58:50 --> Output Class Initialized
INFO - 2020-03-05 02:58:50 --> Security Class Initialized
DEBUG - 2020-03-05 02:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:58:50 --> Input Class Initialized
INFO - 2020-03-05 02:58:50 --> Language Class Initialized
INFO - 2020-03-05 02:58:50 --> Loader Class Initialized
INFO - 2020-03-05 02:58:50 --> Helper loaded: url_helper
INFO - 2020-03-05 02:58:50 --> Helper loaded: string_helper
INFO - 2020-03-05 02:58:50 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:58:50 --> Controller Class Initialized
INFO - 2020-03-05 02:58:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 02:58:50 --> Pagination Class Initialized
INFO - 2020-03-05 02:58:50 --> Model "M_show" initialized
INFO - 2020-03-05 02:58:50 --> Helper loaded: form_helper
INFO - 2020-03-05 02:58:50 --> Form Validation Class Initialized
INFO - 2020-03-05 02:58:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 02:58:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 02:58:50 --> Final output sent to browser
DEBUG - 2020-03-05 02:58:50 --> Total execution time: 0.0311
INFO - 2020-03-05 02:58:54 --> Config Class Initialized
INFO - 2020-03-05 02:58:54 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:58:54 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:58:54 --> Utf8 Class Initialized
INFO - 2020-03-05 02:58:54 --> URI Class Initialized
INFO - 2020-03-05 02:58:54 --> Router Class Initialized
INFO - 2020-03-05 02:58:54 --> Output Class Initialized
INFO - 2020-03-05 02:58:54 --> Security Class Initialized
DEBUG - 2020-03-05 02:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:58:54 --> Input Class Initialized
INFO - 2020-03-05 02:58:54 --> Language Class Initialized
INFO - 2020-03-05 02:58:54 --> Loader Class Initialized
INFO - 2020-03-05 02:58:54 --> Helper loaded: url_helper
INFO - 2020-03-05 02:58:54 --> Helper loaded: string_helper
INFO - 2020-03-05 02:58:54 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:58:54 --> Controller Class Initialized
INFO - 2020-03-05 02:58:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 02:58:54 --> Pagination Class Initialized
INFO - 2020-03-05 02:58:54 --> Model "M_show" initialized
INFO - 2020-03-05 02:58:54 --> Helper loaded: form_helper
INFO - 2020-03-05 02:58:54 --> Form Validation Class Initialized
INFO - 2020-03-05 02:58:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 02:58:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 02:58:54 --> Final output sent to browser
DEBUG - 2020-03-05 02:58:54 --> Total execution time: 0.0088
INFO - 2020-03-05 02:58:54 --> Config Class Initialized
INFO - 2020-03-05 02:58:54 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:58:54 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:58:54 --> Utf8 Class Initialized
INFO - 2020-03-05 02:58:54 --> URI Class Initialized
INFO - 2020-03-05 02:58:54 --> Router Class Initialized
INFO - 2020-03-05 02:58:54 --> Output Class Initialized
INFO - 2020-03-05 02:58:54 --> Security Class Initialized
DEBUG - 2020-03-05 02:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:58:54 --> Input Class Initialized
INFO - 2020-03-05 02:58:54 --> Language Class Initialized
ERROR - 2020-03-05 02:58:54 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-05 02:58:58 --> Config Class Initialized
INFO - 2020-03-05 02:58:58 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:58:58 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:58:58 --> Utf8 Class Initialized
INFO - 2020-03-05 02:58:58 --> URI Class Initialized
INFO - 2020-03-05 02:58:58 --> Router Class Initialized
INFO - 2020-03-05 02:58:58 --> Output Class Initialized
INFO - 2020-03-05 02:58:58 --> Security Class Initialized
DEBUG - 2020-03-05 02:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:58:58 --> Input Class Initialized
INFO - 2020-03-05 02:58:58 --> Language Class Initialized
INFO - 2020-03-05 02:58:58 --> Loader Class Initialized
INFO - 2020-03-05 02:58:58 --> Helper loaded: url_helper
INFO - 2020-03-05 02:58:58 --> Helper loaded: string_helper
INFO - 2020-03-05 02:58:58 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:58:58 --> Controller Class Initialized
INFO - 2020-03-05 02:58:58 --> Model "M_tiket" initialized
INFO - 2020-03-05 02:58:58 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 02:58:58 --> Model "M_pesan" initialized
INFO - 2020-03-05 02:58:58 --> Helper loaded: form_helper
INFO - 2020-03-05 02:58:58 --> Form Validation Class Initialized
INFO - 2020-03-05 02:58:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 02:58:58 --> Final output sent to browser
DEBUG - 2020-03-05 02:58:58 --> Total execution time: 0.0109
INFO - 2020-03-05 02:59:01 --> Config Class Initialized
INFO - 2020-03-05 02:59:01 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:59:01 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:59:01 --> Utf8 Class Initialized
INFO - 2020-03-05 02:59:01 --> URI Class Initialized
INFO - 2020-03-05 02:59:01 --> Router Class Initialized
INFO - 2020-03-05 02:59:01 --> Output Class Initialized
INFO - 2020-03-05 02:59:01 --> Security Class Initialized
DEBUG - 2020-03-05 02:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:59:01 --> Input Class Initialized
INFO - 2020-03-05 02:59:01 --> Language Class Initialized
INFO - 2020-03-05 02:59:01 --> Loader Class Initialized
INFO - 2020-03-05 02:59:01 --> Helper loaded: url_helper
INFO - 2020-03-05 02:59:01 --> Helper loaded: string_helper
INFO - 2020-03-05 02:59:01 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:59:01 --> Controller Class Initialized
INFO - 2020-03-05 02:59:01 --> Model "M_tiket" initialized
INFO - 2020-03-05 02:59:01 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 02:59:01 --> Model "M_pesan" initialized
INFO - 2020-03-05 02:59:01 --> Helper loaded: form_helper
INFO - 2020-03-05 02:59:01 --> Form Validation Class Initialized
INFO - 2020-03-05 02:59:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-05 02:59:01 --> Final output sent to browser
DEBUG - 2020-03-05 02:59:01 --> Total execution time: 0.0079
INFO - 2020-03-05 03:00:41 --> Config Class Initialized
INFO - 2020-03-05 03:00:41 --> Hooks Class Initialized
DEBUG - 2020-03-05 03:00:41 --> UTF-8 Support Enabled
INFO - 2020-03-05 03:00:41 --> Utf8 Class Initialized
INFO - 2020-03-05 03:00:41 --> URI Class Initialized
INFO - 2020-03-05 03:00:41 --> Router Class Initialized
INFO - 2020-03-05 03:00:41 --> Output Class Initialized
INFO - 2020-03-05 03:00:41 --> Security Class Initialized
DEBUG - 2020-03-05 03:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 03:00:41 --> Input Class Initialized
INFO - 2020-03-05 03:00:41 --> Language Class Initialized
INFO - 2020-03-05 03:00:41 --> Loader Class Initialized
INFO - 2020-03-05 03:00:41 --> Helper loaded: url_helper
INFO - 2020-03-05 03:00:41 --> Helper loaded: string_helper
INFO - 2020-03-05 03:00:41 --> Database Driver Class Initialized
DEBUG - 2020-03-05 03:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 03:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 03:00:41 --> Controller Class Initialized
INFO - 2020-03-05 03:00:41 --> Model "M_tiket" initialized
INFO - 2020-03-05 03:00:41 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 03:00:41 --> Model "M_pesan" initialized
INFO - 2020-03-05 03:00:41 --> Helper loaded: form_helper
INFO - 2020-03-05 03:00:41 --> Form Validation Class Initialized
DEBUG - 2020-03-05 03:00:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-05 03:00:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-05 03:00:41 --> Final output sent to browser
DEBUG - 2020-03-05 03:00:41 --> Total execution time: 0.0445
INFO - 2020-03-05 03:00:46 --> Config Class Initialized
INFO - 2020-03-05 03:00:46 --> Hooks Class Initialized
DEBUG - 2020-03-05 03:00:46 --> UTF-8 Support Enabled
INFO - 2020-03-05 03:00:46 --> Utf8 Class Initialized
INFO - 2020-03-05 03:00:46 --> URI Class Initialized
INFO - 2020-03-05 03:00:46 --> Router Class Initialized
INFO - 2020-03-05 03:00:46 --> Output Class Initialized
INFO - 2020-03-05 03:00:46 --> Security Class Initialized
DEBUG - 2020-03-05 03:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 03:00:46 --> Input Class Initialized
INFO - 2020-03-05 03:00:46 --> Language Class Initialized
INFO - 2020-03-05 03:00:46 --> Loader Class Initialized
INFO - 2020-03-05 03:00:46 --> Helper loaded: url_helper
INFO - 2020-03-05 03:00:46 --> Helper loaded: string_helper
INFO - 2020-03-05 03:00:46 --> Database Driver Class Initialized
DEBUG - 2020-03-05 03:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 03:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 03:00:46 --> Controller Class Initialized
INFO - 2020-03-05 03:00:46 --> Model "M_tiket" initialized
INFO - 2020-03-05 03:00:46 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 03:00:46 --> Model "M_pesan" initialized
INFO - 2020-03-05 03:00:46 --> Helper loaded: form_helper
INFO - 2020-03-05 03:00:46 --> Form Validation Class Initialized
INFO - 2020-03-05 03:00:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-05 03:00:46 --> Final output sent to browser
DEBUG - 2020-03-05 03:00:46 --> Total execution time: 0.0084
INFO - 2020-03-05 03:01:09 --> Config Class Initialized
INFO - 2020-03-05 03:01:09 --> Hooks Class Initialized
DEBUG - 2020-03-05 03:01:09 --> UTF-8 Support Enabled
INFO - 2020-03-05 03:01:09 --> Utf8 Class Initialized
INFO - 2020-03-05 03:01:09 --> URI Class Initialized
INFO - 2020-03-05 03:01:09 --> Router Class Initialized
INFO - 2020-03-05 03:01:09 --> Output Class Initialized
INFO - 2020-03-05 03:01:09 --> Security Class Initialized
DEBUG - 2020-03-05 03:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 03:01:09 --> Input Class Initialized
INFO - 2020-03-05 03:01:09 --> Language Class Initialized
INFO - 2020-03-05 03:01:09 --> Loader Class Initialized
INFO - 2020-03-05 03:01:09 --> Helper loaded: url_helper
INFO - 2020-03-05 03:01:09 --> Helper loaded: string_helper
INFO - 2020-03-05 03:01:09 --> Database Driver Class Initialized
DEBUG - 2020-03-05 03:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 03:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 03:01:09 --> Controller Class Initialized
INFO - 2020-03-05 03:01:09 --> Model "M_tiket" initialized
INFO - 2020-03-05 03:01:09 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 03:01:09 --> Model "M_pesan" initialized
INFO - 2020-03-05 03:01:09 --> Helper loaded: form_helper
INFO - 2020-03-05 03:01:09 --> Form Validation Class Initialized
DEBUG - 2020-03-05 03:01:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-05 03:01:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-05 03:01:09 --> Final output sent to browser
DEBUG - 2020-03-05 03:01:09 --> Total execution time: 0.0075
INFO - 2020-03-05 03:01:13 --> Config Class Initialized
INFO - 2020-03-05 03:01:13 --> Hooks Class Initialized
DEBUG - 2020-03-05 03:01:13 --> UTF-8 Support Enabled
INFO - 2020-03-05 03:01:13 --> Utf8 Class Initialized
INFO - 2020-03-05 03:01:13 --> URI Class Initialized
INFO - 2020-03-05 03:01:13 --> Router Class Initialized
INFO - 2020-03-05 03:01:13 --> Output Class Initialized
INFO - 2020-03-05 03:01:13 --> Security Class Initialized
DEBUG - 2020-03-05 03:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 03:01:13 --> Input Class Initialized
INFO - 2020-03-05 03:01:13 --> Language Class Initialized
INFO - 2020-03-05 03:01:13 --> Loader Class Initialized
INFO - 2020-03-05 03:01:13 --> Helper loaded: url_helper
INFO - 2020-03-05 03:01:13 --> Helper loaded: string_helper
INFO - 2020-03-05 03:01:13 --> Database Driver Class Initialized
DEBUG - 2020-03-05 03:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 03:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 03:01:13 --> Controller Class Initialized
INFO - 2020-03-05 03:01:13 --> Model "M_tiket" initialized
INFO - 2020-03-05 03:01:13 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 03:01:13 --> Model "M_pesan" initialized
INFO - 2020-03-05 03:01:13 --> Helper loaded: form_helper
INFO - 2020-03-05 03:01:13 --> Form Validation Class Initialized
INFO - 2020-03-05 03:01:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-05 03:01:13 --> Final output sent to browser
DEBUG - 2020-03-05 03:01:13 --> Total execution time: 0.0066
INFO - 2020-03-05 03:40:29 --> Config Class Initialized
INFO - 2020-03-05 03:40:29 --> Hooks Class Initialized
DEBUG - 2020-03-05 03:40:29 --> UTF-8 Support Enabled
INFO - 2020-03-05 03:40:29 --> Utf8 Class Initialized
INFO - 2020-03-05 03:40:29 --> URI Class Initialized
DEBUG - 2020-03-05 03:40:29 --> No URI present. Default controller set.
INFO - 2020-03-05 03:40:29 --> Router Class Initialized
INFO - 2020-03-05 03:40:29 --> Output Class Initialized
INFO - 2020-03-05 03:40:29 --> Security Class Initialized
DEBUG - 2020-03-05 03:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 03:40:29 --> Input Class Initialized
INFO - 2020-03-05 03:40:29 --> Language Class Initialized
INFO - 2020-03-05 03:40:29 --> Loader Class Initialized
INFO - 2020-03-05 03:40:29 --> Helper loaded: url_helper
INFO - 2020-03-05 03:40:29 --> Helper loaded: string_helper
INFO - 2020-03-05 03:40:29 --> Database Driver Class Initialized
DEBUG - 2020-03-05 03:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 03:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 03:40:29 --> Controller Class Initialized
INFO - 2020-03-05 03:40:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 03:40:29 --> Pagination Class Initialized
INFO - 2020-03-05 03:40:29 --> Model "M_show" initialized
INFO - 2020-03-05 03:40:29 --> Helper loaded: form_helper
INFO - 2020-03-05 03:40:29 --> Form Validation Class Initialized
INFO - 2020-03-05 03:40:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 03:40:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 03:40:29 --> Final output sent to browser
DEBUG - 2020-03-05 03:40:29 --> Total execution time: 0.0410
INFO - 2020-03-05 03:41:21 --> Config Class Initialized
INFO - 2020-03-05 03:41:21 --> Hooks Class Initialized
DEBUG - 2020-03-05 03:41:21 --> UTF-8 Support Enabled
INFO - 2020-03-05 03:41:21 --> Utf8 Class Initialized
INFO - 2020-03-05 03:41:21 --> URI Class Initialized
INFO - 2020-03-05 03:41:21 --> Router Class Initialized
INFO - 2020-03-05 03:41:21 --> Output Class Initialized
INFO - 2020-03-05 03:41:21 --> Security Class Initialized
DEBUG - 2020-03-05 03:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 03:41:21 --> Input Class Initialized
INFO - 2020-03-05 03:41:21 --> Language Class Initialized
INFO - 2020-03-05 03:41:21 --> Loader Class Initialized
INFO - 2020-03-05 03:41:21 --> Helper loaded: url_helper
INFO - 2020-03-05 03:41:21 --> Helper loaded: string_helper
INFO - 2020-03-05 03:41:21 --> Database Driver Class Initialized
DEBUG - 2020-03-05 03:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 03:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 03:41:21 --> Controller Class Initialized
INFO - 2020-03-05 03:41:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 03:41:21 --> Pagination Class Initialized
INFO - 2020-03-05 03:41:21 --> Model "M_show" initialized
INFO - 2020-03-05 03:41:21 --> Helper loaded: form_helper
INFO - 2020-03-05 03:41:21 --> Form Validation Class Initialized
INFO - 2020-03-05 03:41:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 03:41:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 03:41:21 --> Final output sent to browser
DEBUG - 2020-03-05 03:41:21 --> Total execution time: 0.0090
INFO - 2020-03-05 03:41:23 --> Config Class Initialized
INFO - 2020-03-05 03:41:23 --> Hooks Class Initialized
DEBUG - 2020-03-05 03:41:23 --> UTF-8 Support Enabled
INFO - 2020-03-05 03:41:23 --> Utf8 Class Initialized
INFO - 2020-03-05 03:41:23 --> URI Class Initialized
INFO - 2020-03-05 03:41:23 --> Router Class Initialized
INFO - 2020-03-05 03:41:23 --> Output Class Initialized
INFO - 2020-03-05 03:41:23 --> Security Class Initialized
DEBUG - 2020-03-05 03:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 03:41:23 --> Input Class Initialized
INFO - 2020-03-05 03:41:23 --> Language Class Initialized
ERROR - 2020-03-05 03:41:23 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-05 03:41:25 --> Config Class Initialized
INFO - 2020-03-05 03:41:25 --> Hooks Class Initialized
DEBUG - 2020-03-05 03:41:25 --> UTF-8 Support Enabled
INFO - 2020-03-05 03:41:25 --> Utf8 Class Initialized
INFO - 2020-03-05 03:41:25 --> URI Class Initialized
INFO - 2020-03-05 03:41:25 --> Router Class Initialized
INFO - 2020-03-05 03:41:25 --> Output Class Initialized
INFO - 2020-03-05 03:41:25 --> Security Class Initialized
DEBUG - 2020-03-05 03:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 03:41:25 --> Input Class Initialized
INFO - 2020-03-05 03:41:25 --> Language Class Initialized
INFO - 2020-03-05 03:41:25 --> Loader Class Initialized
INFO - 2020-03-05 03:41:25 --> Helper loaded: url_helper
INFO - 2020-03-05 03:41:25 --> Helper loaded: string_helper
INFO - 2020-03-05 03:41:25 --> Database Driver Class Initialized
DEBUG - 2020-03-05 03:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 03:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 03:41:25 --> Controller Class Initialized
INFO - 2020-03-05 03:41:25 --> Model "M_tiket" initialized
INFO - 2020-03-05 03:41:25 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 03:41:25 --> Model "M_pesan" initialized
INFO - 2020-03-05 03:41:25 --> Helper loaded: form_helper
INFO - 2020-03-05 03:41:25 --> Form Validation Class Initialized
INFO - 2020-03-05 03:41:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 03:41:25 --> Final output sent to browser
DEBUG - 2020-03-05 03:41:25 --> Total execution time: 0.0103
INFO - 2020-03-05 03:45:27 --> Config Class Initialized
INFO - 2020-03-05 03:45:27 --> Hooks Class Initialized
DEBUG - 2020-03-05 03:45:27 --> UTF-8 Support Enabled
INFO - 2020-03-05 03:45:27 --> Utf8 Class Initialized
INFO - 2020-03-05 03:45:27 --> URI Class Initialized
INFO - 2020-03-05 03:45:27 --> Router Class Initialized
INFO - 2020-03-05 03:45:27 --> Output Class Initialized
INFO - 2020-03-05 03:45:27 --> Security Class Initialized
DEBUG - 2020-03-05 03:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 03:45:27 --> Input Class Initialized
INFO - 2020-03-05 03:45:27 --> Language Class Initialized
INFO - 2020-03-05 03:45:27 --> Loader Class Initialized
INFO - 2020-03-05 03:45:27 --> Helper loaded: url_helper
INFO - 2020-03-05 03:45:27 --> Helper loaded: string_helper
INFO - 2020-03-05 03:45:27 --> Database Driver Class Initialized
DEBUG - 2020-03-05 03:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 03:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 03:45:27 --> Controller Class Initialized
INFO - 2020-03-05 03:45:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 03:45:27 --> Pagination Class Initialized
INFO - 2020-03-05 03:45:27 --> Model "M_show" initialized
INFO - 2020-03-05 03:45:27 --> Helper loaded: form_helper
INFO - 2020-03-05 03:45:27 --> Form Validation Class Initialized
INFO - 2020-03-05 03:45:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 03:45:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 03:45:27 --> Final output sent to browser
DEBUG - 2020-03-05 03:45:27 --> Total execution time: 0.0345
INFO - 2020-03-05 03:45:39 --> Config Class Initialized
INFO - 2020-03-05 03:45:39 --> Hooks Class Initialized
DEBUG - 2020-03-05 03:45:39 --> UTF-8 Support Enabled
INFO - 2020-03-05 03:45:39 --> Utf8 Class Initialized
INFO - 2020-03-05 03:45:39 --> URI Class Initialized
INFO - 2020-03-05 03:45:39 --> Router Class Initialized
INFO - 2020-03-05 03:45:39 --> Output Class Initialized
INFO - 2020-03-05 03:45:39 --> Security Class Initialized
DEBUG - 2020-03-05 03:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 03:45:39 --> Input Class Initialized
INFO - 2020-03-05 03:45:39 --> Language Class Initialized
INFO - 2020-03-05 03:45:39 --> Loader Class Initialized
INFO - 2020-03-05 03:45:39 --> Helper loaded: url_helper
INFO - 2020-03-05 03:45:39 --> Helper loaded: string_helper
INFO - 2020-03-05 03:45:39 --> Database Driver Class Initialized
DEBUG - 2020-03-05 03:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 03:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 03:45:39 --> Controller Class Initialized
INFO - 2020-03-05 03:45:39 --> Model "M_tiket" initialized
INFO - 2020-03-05 03:45:39 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 03:45:39 --> Model "M_pesan" initialized
INFO - 2020-03-05 03:45:39 --> Helper loaded: form_helper
INFO - 2020-03-05 03:45:39 --> Form Validation Class Initialized
INFO - 2020-03-05 03:45:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 03:45:39 --> Final output sent to browser
DEBUG - 2020-03-05 03:45:39 --> Total execution time: 0.0108
INFO - 2020-03-05 03:52:13 --> Config Class Initialized
INFO - 2020-03-05 03:52:13 --> Hooks Class Initialized
DEBUG - 2020-03-05 03:52:13 --> UTF-8 Support Enabled
INFO - 2020-03-05 03:52:13 --> Utf8 Class Initialized
INFO - 2020-03-05 03:52:13 --> URI Class Initialized
INFO - 2020-03-05 03:52:13 --> Router Class Initialized
INFO - 2020-03-05 03:52:13 --> Output Class Initialized
INFO - 2020-03-05 03:52:13 --> Security Class Initialized
DEBUG - 2020-03-05 03:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 03:52:13 --> Input Class Initialized
INFO - 2020-03-05 03:52:13 --> Language Class Initialized
INFO - 2020-03-05 03:52:13 --> Loader Class Initialized
INFO - 2020-03-05 03:52:13 --> Helper loaded: url_helper
INFO - 2020-03-05 03:52:13 --> Helper loaded: string_helper
INFO - 2020-03-05 03:52:13 --> Database Driver Class Initialized
DEBUG - 2020-03-05 03:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 03:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 03:52:13 --> Controller Class Initialized
INFO - 2020-03-05 03:52:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 03:52:13 --> Pagination Class Initialized
INFO - 2020-03-05 03:52:13 --> Model "M_show" initialized
INFO - 2020-03-05 03:52:13 --> Helper loaded: form_helper
INFO - 2020-03-05 03:52:13 --> Form Validation Class Initialized
INFO - 2020-03-05 03:52:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 03:52:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 03:52:13 --> Final output sent to browser
DEBUG - 2020-03-05 03:52:13 --> Total execution time: 0.0327
INFO - 2020-03-05 03:52:19 --> Config Class Initialized
INFO - 2020-03-05 03:52:19 --> Hooks Class Initialized
DEBUG - 2020-03-05 03:52:19 --> UTF-8 Support Enabled
INFO - 2020-03-05 03:52:19 --> Utf8 Class Initialized
INFO - 2020-03-05 03:52:19 --> URI Class Initialized
INFO - 2020-03-05 03:52:19 --> Router Class Initialized
INFO - 2020-03-05 03:52:19 --> Output Class Initialized
INFO - 2020-03-05 03:52:19 --> Security Class Initialized
DEBUG - 2020-03-05 03:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 03:52:19 --> Input Class Initialized
INFO - 2020-03-05 03:52:19 --> Language Class Initialized
INFO - 2020-03-05 03:52:19 --> Loader Class Initialized
INFO - 2020-03-05 03:52:19 --> Helper loaded: url_helper
INFO - 2020-03-05 03:52:19 --> Helper loaded: string_helper
INFO - 2020-03-05 03:52:19 --> Database Driver Class Initialized
DEBUG - 2020-03-05 03:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 03:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 03:52:19 --> Controller Class Initialized
INFO - 2020-03-05 03:52:19 --> Model "M_tiket" initialized
INFO - 2020-03-05 03:52:19 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 03:52:19 --> Model "M_pesan" initialized
INFO - 2020-03-05 03:52:19 --> Helper loaded: form_helper
INFO - 2020-03-05 03:52:19 --> Form Validation Class Initialized
INFO - 2020-03-05 03:52:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 03:52:19 --> Final output sent to browser
DEBUG - 2020-03-05 03:52:19 --> Total execution time: 0.0159
INFO - 2020-03-05 03:52:20 --> Config Class Initialized
INFO - 2020-03-05 03:52:20 --> Hooks Class Initialized
DEBUG - 2020-03-05 03:52:20 --> UTF-8 Support Enabled
INFO - 2020-03-05 03:52:20 --> Utf8 Class Initialized
INFO - 2020-03-05 03:52:20 --> URI Class Initialized
INFO - 2020-03-05 03:52:20 --> Router Class Initialized
INFO - 2020-03-05 03:52:20 --> Output Class Initialized
INFO - 2020-03-05 03:52:20 --> Security Class Initialized
DEBUG - 2020-03-05 03:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 03:52:20 --> Input Class Initialized
INFO - 2020-03-05 03:52:20 --> Language Class Initialized
INFO - 2020-03-05 03:52:20 --> Loader Class Initialized
INFO - 2020-03-05 03:52:20 --> Helper loaded: url_helper
INFO - 2020-03-05 03:52:20 --> Helper loaded: string_helper
INFO - 2020-03-05 03:52:20 --> Database Driver Class Initialized
DEBUG - 2020-03-05 03:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 03:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 03:52:20 --> Controller Class Initialized
INFO - 2020-03-05 03:52:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 03:52:20 --> Pagination Class Initialized
INFO - 2020-03-05 03:52:20 --> Model "M_show" initialized
INFO - 2020-03-05 03:52:20 --> Helper loaded: form_helper
INFO - 2020-03-05 03:52:20 --> Form Validation Class Initialized
INFO - 2020-03-05 03:52:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 03:52:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 03:52:20 --> Final output sent to browser
DEBUG - 2020-03-05 03:52:20 --> Total execution time: 0.0058
INFO - 2020-03-05 03:52:21 --> Config Class Initialized
INFO - 2020-03-05 03:52:21 --> Hooks Class Initialized
DEBUG - 2020-03-05 03:52:21 --> UTF-8 Support Enabled
INFO - 2020-03-05 03:52:21 --> Utf8 Class Initialized
INFO - 2020-03-05 03:52:21 --> URI Class Initialized
INFO - 2020-03-05 03:52:21 --> Router Class Initialized
INFO - 2020-03-05 03:52:21 --> Output Class Initialized
INFO - 2020-03-05 03:52:21 --> Security Class Initialized
DEBUG - 2020-03-05 03:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 03:52:21 --> Input Class Initialized
INFO - 2020-03-05 03:52:21 --> Language Class Initialized
ERROR - 2020-03-05 03:52:21 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-05 03:52:31 --> Config Class Initialized
INFO - 2020-03-05 03:52:31 --> Hooks Class Initialized
DEBUG - 2020-03-05 03:52:31 --> UTF-8 Support Enabled
INFO - 2020-03-05 03:52:31 --> Utf8 Class Initialized
INFO - 2020-03-05 03:52:31 --> URI Class Initialized
INFO - 2020-03-05 03:52:31 --> Router Class Initialized
INFO - 2020-03-05 03:52:31 --> Output Class Initialized
INFO - 2020-03-05 03:52:31 --> Security Class Initialized
DEBUG - 2020-03-05 03:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 03:52:31 --> Input Class Initialized
INFO - 2020-03-05 03:52:31 --> Language Class Initialized
INFO - 2020-03-05 03:52:31 --> Loader Class Initialized
INFO - 2020-03-05 03:52:31 --> Helper loaded: url_helper
INFO - 2020-03-05 03:52:31 --> Helper loaded: string_helper
INFO - 2020-03-05 03:52:31 --> Database Driver Class Initialized
DEBUG - 2020-03-05 03:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 03:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 03:52:31 --> Controller Class Initialized
INFO - 2020-03-05 03:52:31 --> Model "M_tiket" initialized
INFO - 2020-03-05 03:52:31 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 03:52:31 --> Model "M_pesan" initialized
INFO - 2020-03-05 03:52:31 --> Helper loaded: form_helper
INFO - 2020-03-05 03:52:31 --> Form Validation Class Initialized
INFO - 2020-03-05 03:52:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-05 03:52:31 --> Final output sent to browser
DEBUG - 2020-03-05 03:52:31 --> Total execution time: 0.0071
INFO - 2020-03-05 03:53:28 --> Config Class Initialized
INFO - 2020-03-05 03:53:28 --> Hooks Class Initialized
DEBUG - 2020-03-05 03:53:28 --> UTF-8 Support Enabled
INFO - 2020-03-05 03:53:28 --> Utf8 Class Initialized
INFO - 2020-03-05 03:53:28 --> URI Class Initialized
INFO - 2020-03-05 03:53:28 --> Router Class Initialized
INFO - 2020-03-05 03:53:28 --> Output Class Initialized
INFO - 2020-03-05 03:53:28 --> Security Class Initialized
DEBUG - 2020-03-05 03:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 03:53:28 --> Input Class Initialized
INFO - 2020-03-05 03:53:28 --> Language Class Initialized
INFO - 2020-03-05 03:53:28 --> Loader Class Initialized
INFO - 2020-03-05 03:53:28 --> Helper loaded: url_helper
INFO - 2020-03-05 03:53:28 --> Helper loaded: string_helper
INFO - 2020-03-05 03:53:28 --> Database Driver Class Initialized
DEBUG - 2020-03-05 03:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 03:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 03:53:28 --> Controller Class Initialized
INFO - 2020-03-05 03:53:28 --> Model "M_tiket" initialized
INFO - 2020-03-05 03:53:28 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 03:53:28 --> Model "M_pesan" initialized
INFO - 2020-03-05 03:53:28 --> Helper loaded: form_helper
INFO - 2020-03-05 03:53:28 --> Form Validation Class Initialized
INFO - 2020-03-05 03:53:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 03:53:28 --> Final output sent to browser
DEBUG - 2020-03-05 03:53:28 --> Total execution time: 0.0078
INFO - 2020-03-05 04:00:12 --> Config Class Initialized
INFO - 2020-03-05 04:00:12 --> Hooks Class Initialized
DEBUG - 2020-03-05 04:00:12 --> UTF-8 Support Enabled
INFO - 2020-03-05 04:00:12 --> Utf8 Class Initialized
INFO - 2020-03-05 04:00:12 --> URI Class Initialized
INFO - 2020-03-05 04:00:12 --> Router Class Initialized
INFO - 2020-03-05 04:00:12 --> Output Class Initialized
INFO - 2020-03-05 04:00:12 --> Security Class Initialized
DEBUG - 2020-03-05 04:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 04:00:12 --> Input Class Initialized
INFO - 2020-03-05 04:00:12 --> Language Class Initialized
INFO - 2020-03-05 04:00:12 --> Loader Class Initialized
INFO - 2020-03-05 04:00:12 --> Helper loaded: url_helper
INFO - 2020-03-05 04:00:12 --> Helper loaded: string_helper
INFO - 2020-03-05 04:00:12 --> Database Driver Class Initialized
DEBUG - 2020-03-05 04:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 04:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 04:00:12 --> Controller Class Initialized
INFO - 2020-03-05 04:00:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 04:00:12 --> Pagination Class Initialized
INFO - 2020-03-05 04:00:12 --> Model "M_show" initialized
INFO - 2020-03-05 04:00:12 --> Helper loaded: form_helper
INFO - 2020-03-05 04:00:12 --> Form Validation Class Initialized
INFO - 2020-03-05 04:00:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 04:00:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 04:00:12 --> Final output sent to browser
DEBUG - 2020-03-05 04:00:12 --> Total execution time: 0.0369
INFO - 2020-03-05 04:00:28 --> Config Class Initialized
INFO - 2020-03-05 04:00:28 --> Hooks Class Initialized
DEBUG - 2020-03-05 04:00:28 --> UTF-8 Support Enabled
INFO - 2020-03-05 04:00:28 --> Utf8 Class Initialized
INFO - 2020-03-05 04:00:28 --> URI Class Initialized
INFO - 2020-03-05 04:00:28 --> Router Class Initialized
INFO - 2020-03-05 04:00:28 --> Output Class Initialized
INFO - 2020-03-05 04:00:28 --> Security Class Initialized
DEBUG - 2020-03-05 04:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 04:00:28 --> Input Class Initialized
INFO - 2020-03-05 04:00:28 --> Language Class Initialized
INFO - 2020-03-05 04:00:28 --> Loader Class Initialized
INFO - 2020-03-05 04:00:28 --> Helper loaded: url_helper
INFO - 2020-03-05 04:00:28 --> Helper loaded: string_helper
INFO - 2020-03-05 04:00:28 --> Database Driver Class Initialized
DEBUG - 2020-03-05 04:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 04:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 04:00:28 --> Controller Class Initialized
INFO - 2020-03-05 04:00:28 --> Model "M_tiket" initialized
INFO - 2020-03-05 04:00:28 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 04:00:28 --> Model "M_pesan" initialized
INFO - 2020-03-05 04:00:28 --> Helper loaded: form_helper
INFO - 2020-03-05 04:00:28 --> Form Validation Class Initialized
INFO - 2020-03-05 04:00:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 04:00:28 --> Final output sent to browser
DEBUG - 2020-03-05 04:00:28 --> Total execution time: 0.0099
INFO - 2020-03-05 04:00:48 --> Config Class Initialized
INFO - 2020-03-05 04:00:48 --> Hooks Class Initialized
DEBUG - 2020-03-05 04:00:48 --> UTF-8 Support Enabled
INFO - 2020-03-05 04:00:48 --> Utf8 Class Initialized
INFO - 2020-03-05 04:00:48 --> URI Class Initialized
INFO - 2020-03-05 04:00:48 --> Router Class Initialized
INFO - 2020-03-05 04:00:48 --> Output Class Initialized
INFO - 2020-03-05 04:00:48 --> Security Class Initialized
DEBUG - 2020-03-05 04:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 04:00:48 --> Input Class Initialized
INFO - 2020-03-05 04:00:48 --> Language Class Initialized
INFO - 2020-03-05 04:00:48 --> Loader Class Initialized
INFO - 2020-03-05 04:00:48 --> Helper loaded: url_helper
INFO - 2020-03-05 04:00:48 --> Helper loaded: string_helper
INFO - 2020-03-05 04:00:48 --> Database Driver Class Initialized
DEBUG - 2020-03-05 04:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 04:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 04:00:48 --> Controller Class Initialized
INFO - 2020-03-05 04:00:48 --> Model "M_tiket" initialized
INFO - 2020-03-05 04:00:48 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 04:00:48 --> Model "M_pesan" initialized
INFO - 2020-03-05 04:00:48 --> Helper loaded: form_helper
INFO - 2020-03-05 04:00:48 --> Form Validation Class Initialized
INFO - 2020-03-05 04:00:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-05 04:00:48 --> Final output sent to browser
DEBUG - 2020-03-05 04:00:48 --> Total execution time: 0.0093
INFO - 2020-03-05 04:00:56 --> Config Class Initialized
INFO - 2020-03-05 04:00:56 --> Hooks Class Initialized
DEBUG - 2020-03-05 04:00:56 --> UTF-8 Support Enabled
INFO - 2020-03-05 04:00:56 --> Utf8 Class Initialized
INFO - 2020-03-05 04:00:56 --> URI Class Initialized
INFO - 2020-03-05 04:00:56 --> Router Class Initialized
INFO - 2020-03-05 04:00:56 --> Output Class Initialized
INFO - 2020-03-05 04:00:56 --> Security Class Initialized
DEBUG - 2020-03-05 04:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 04:00:56 --> Input Class Initialized
INFO - 2020-03-05 04:00:56 --> Language Class Initialized
INFO - 2020-03-05 04:00:56 --> Loader Class Initialized
INFO - 2020-03-05 04:00:56 --> Helper loaded: url_helper
INFO - 2020-03-05 04:00:56 --> Helper loaded: string_helper
INFO - 2020-03-05 04:00:56 --> Database Driver Class Initialized
DEBUG - 2020-03-05 04:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 04:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 04:00:56 --> Controller Class Initialized
INFO - 2020-03-05 04:00:56 --> Model "M_tiket" initialized
INFO - 2020-03-05 04:00:56 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 04:00:56 --> Model "M_pesan" initialized
INFO - 2020-03-05 04:00:56 --> Helper loaded: form_helper
INFO - 2020-03-05 04:00:56 --> Form Validation Class Initialized
INFO - 2020-03-05 04:00:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 04:00:56 --> Final output sent to browser
DEBUG - 2020-03-05 04:00:56 --> Total execution time: 0.0094
INFO - 2020-03-05 04:12:37 --> Config Class Initialized
INFO - 2020-03-05 04:12:37 --> Hooks Class Initialized
DEBUG - 2020-03-05 04:12:37 --> UTF-8 Support Enabled
INFO - 2020-03-05 04:12:37 --> Utf8 Class Initialized
INFO - 2020-03-05 04:12:37 --> URI Class Initialized
INFO - 2020-03-05 04:12:37 --> Router Class Initialized
INFO - 2020-03-05 04:12:37 --> Output Class Initialized
INFO - 2020-03-05 04:12:37 --> Security Class Initialized
DEBUG - 2020-03-05 04:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 04:12:37 --> Input Class Initialized
INFO - 2020-03-05 04:12:37 --> Language Class Initialized
INFO - 2020-03-05 04:12:37 --> Loader Class Initialized
INFO - 2020-03-05 04:12:37 --> Helper loaded: url_helper
INFO - 2020-03-05 04:12:37 --> Helper loaded: string_helper
INFO - 2020-03-05 04:12:37 --> Database Driver Class Initialized
DEBUG - 2020-03-05 04:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 04:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 04:12:37 --> Controller Class Initialized
INFO - 2020-03-05 04:12:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 04:12:37 --> Pagination Class Initialized
INFO - 2020-03-05 04:12:37 --> Model "M_show" initialized
INFO - 2020-03-05 04:12:37 --> Helper loaded: form_helper
INFO - 2020-03-05 04:12:37 --> Form Validation Class Initialized
INFO - 2020-03-05 04:12:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 04:12:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 04:12:37 --> Final output sent to browser
DEBUG - 2020-03-05 04:12:37 --> Total execution time: 0.0318
INFO - 2020-03-05 04:13:17 --> Config Class Initialized
INFO - 2020-03-05 04:13:17 --> Hooks Class Initialized
DEBUG - 2020-03-05 04:13:17 --> UTF-8 Support Enabled
INFO - 2020-03-05 04:13:17 --> Utf8 Class Initialized
INFO - 2020-03-05 04:13:17 --> URI Class Initialized
INFO - 2020-03-05 04:13:17 --> Router Class Initialized
INFO - 2020-03-05 04:13:17 --> Output Class Initialized
INFO - 2020-03-05 04:13:17 --> Security Class Initialized
DEBUG - 2020-03-05 04:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 04:13:17 --> Input Class Initialized
INFO - 2020-03-05 04:13:17 --> Language Class Initialized
INFO - 2020-03-05 04:13:17 --> Loader Class Initialized
INFO - 2020-03-05 04:13:17 --> Helper loaded: url_helper
INFO - 2020-03-05 04:13:17 --> Helper loaded: string_helper
INFO - 2020-03-05 04:13:17 --> Database Driver Class Initialized
DEBUG - 2020-03-05 04:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 04:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 04:13:17 --> Controller Class Initialized
INFO - 2020-03-05 04:13:17 --> Model "M_tiket" initialized
INFO - 2020-03-05 04:13:17 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 04:13:17 --> Model "M_pesan" initialized
INFO - 2020-03-05 04:13:17 --> Helper loaded: form_helper
INFO - 2020-03-05 04:13:17 --> Form Validation Class Initialized
INFO - 2020-03-05 04:13:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 04:13:17 --> Final output sent to browser
DEBUG - 2020-03-05 04:13:17 --> Total execution time: 0.0107
INFO - 2020-03-05 04:13:45 --> Config Class Initialized
INFO - 2020-03-05 04:13:45 --> Hooks Class Initialized
DEBUG - 2020-03-05 04:13:45 --> UTF-8 Support Enabled
INFO - 2020-03-05 04:13:45 --> Utf8 Class Initialized
INFO - 2020-03-05 04:13:45 --> URI Class Initialized
INFO - 2020-03-05 04:13:45 --> Router Class Initialized
INFO - 2020-03-05 04:13:45 --> Output Class Initialized
INFO - 2020-03-05 04:13:45 --> Security Class Initialized
DEBUG - 2020-03-05 04:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 04:13:45 --> Input Class Initialized
INFO - 2020-03-05 04:13:45 --> Language Class Initialized
INFO - 2020-03-05 04:13:45 --> Loader Class Initialized
INFO - 2020-03-05 04:13:45 --> Helper loaded: url_helper
INFO - 2020-03-05 04:13:45 --> Helper loaded: string_helper
INFO - 2020-03-05 04:13:45 --> Database Driver Class Initialized
DEBUG - 2020-03-05 04:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 04:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 04:13:45 --> Controller Class Initialized
INFO - 2020-03-05 04:13:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 04:13:45 --> Pagination Class Initialized
INFO - 2020-03-05 04:13:45 --> Model "M_show" initialized
INFO - 2020-03-05 04:13:45 --> Helper loaded: form_helper
INFO - 2020-03-05 04:13:45 --> Form Validation Class Initialized
INFO - 2020-03-05 04:13:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 04:13:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 04:13:45 --> Final output sent to browser
DEBUG - 2020-03-05 04:13:45 --> Total execution time: 0.0079
INFO - 2020-03-05 04:13:46 --> Config Class Initialized
INFO - 2020-03-05 04:13:46 --> Hooks Class Initialized
DEBUG - 2020-03-05 04:13:46 --> UTF-8 Support Enabled
INFO - 2020-03-05 04:13:46 --> Utf8 Class Initialized
INFO - 2020-03-05 04:13:46 --> URI Class Initialized
INFO - 2020-03-05 04:13:46 --> Router Class Initialized
INFO - 2020-03-05 04:13:46 --> Output Class Initialized
INFO - 2020-03-05 04:13:46 --> Security Class Initialized
DEBUG - 2020-03-05 04:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 04:13:46 --> Input Class Initialized
INFO - 2020-03-05 04:13:46 --> Language Class Initialized
ERROR - 2020-03-05 04:13:46 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-05 04:14:09 --> Config Class Initialized
INFO - 2020-03-05 04:14:09 --> Hooks Class Initialized
DEBUG - 2020-03-05 04:14:09 --> UTF-8 Support Enabled
INFO - 2020-03-05 04:14:09 --> Utf8 Class Initialized
INFO - 2020-03-05 04:14:09 --> URI Class Initialized
INFO - 2020-03-05 04:14:09 --> Router Class Initialized
INFO - 2020-03-05 04:14:09 --> Output Class Initialized
INFO - 2020-03-05 04:14:09 --> Security Class Initialized
DEBUG - 2020-03-05 04:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 04:14:09 --> Input Class Initialized
INFO - 2020-03-05 04:14:09 --> Language Class Initialized
INFO - 2020-03-05 04:14:09 --> Loader Class Initialized
INFO - 2020-03-05 04:14:09 --> Helper loaded: url_helper
INFO - 2020-03-05 04:14:09 --> Helper loaded: string_helper
INFO - 2020-03-05 04:14:09 --> Database Driver Class Initialized
DEBUG - 2020-03-05 04:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 04:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 04:14:09 --> Controller Class Initialized
INFO - 2020-03-05 04:14:09 --> Model "M_tiket" initialized
INFO - 2020-03-05 04:14:09 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 04:14:09 --> Model "M_pesan" initialized
INFO - 2020-03-05 04:14:09 --> Helper loaded: form_helper
INFO - 2020-03-05 04:14:09 --> Form Validation Class Initialized
INFO - 2020-03-05 04:14:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 04:14:09 --> Final output sent to browser
DEBUG - 2020-03-05 04:14:09 --> Total execution time: 0.0075
INFO - 2020-03-05 04:14:10 --> Config Class Initialized
INFO - 2020-03-05 04:14:10 --> Hooks Class Initialized
DEBUG - 2020-03-05 04:14:10 --> UTF-8 Support Enabled
INFO - 2020-03-05 04:14:10 --> Utf8 Class Initialized
INFO - 2020-03-05 04:14:10 --> URI Class Initialized
INFO - 2020-03-05 04:14:10 --> Router Class Initialized
INFO - 2020-03-05 04:14:10 --> Output Class Initialized
INFO - 2020-03-05 04:14:10 --> Security Class Initialized
DEBUG - 2020-03-05 04:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 04:14:10 --> Input Class Initialized
INFO - 2020-03-05 04:14:10 --> Language Class Initialized
INFO - 2020-03-05 04:14:10 --> Loader Class Initialized
INFO - 2020-03-05 04:14:10 --> Helper loaded: url_helper
INFO - 2020-03-05 04:14:10 --> Helper loaded: string_helper
INFO - 2020-03-05 04:14:10 --> Database Driver Class Initialized
DEBUG - 2020-03-05 04:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 04:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 04:14:10 --> Controller Class Initialized
INFO - 2020-03-05 04:14:10 --> Model "M_tiket" initialized
INFO - 2020-03-05 04:14:10 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 04:14:10 --> Model "M_pesan" initialized
INFO - 2020-03-05 04:14:10 --> Helper loaded: form_helper
INFO - 2020-03-05 04:14:10 --> Form Validation Class Initialized
INFO - 2020-03-05 04:14:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 04:14:10 --> Final output sent to browser
DEBUG - 2020-03-05 04:14:10 --> Total execution time: 0.0068
INFO - 2020-03-05 04:14:14 --> Config Class Initialized
INFO - 2020-03-05 04:14:14 --> Hooks Class Initialized
DEBUG - 2020-03-05 04:14:14 --> UTF-8 Support Enabled
INFO - 2020-03-05 04:14:14 --> Utf8 Class Initialized
INFO - 2020-03-05 04:14:14 --> URI Class Initialized
INFO - 2020-03-05 04:14:14 --> Router Class Initialized
INFO - 2020-03-05 04:14:14 --> Output Class Initialized
INFO - 2020-03-05 04:14:14 --> Security Class Initialized
DEBUG - 2020-03-05 04:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 04:14:14 --> Input Class Initialized
INFO - 2020-03-05 04:14:14 --> Language Class Initialized
INFO - 2020-03-05 04:14:14 --> Loader Class Initialized
INFO - 2020-03-05 04:14:14 --> Helper loaded: url_helper
INFO - 2020-03-05 04:14:14 --> Helper loaded: string_helper
INFO - 2020-03-05 04:14:14 --> Database Driver Class Initialized
DEBUG - 2020-03-05 04:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 04:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 04:14:14 --> Controller Class Initialized
INFO - 2020-03-05 04:14:14 --> Model "M_tiket" initialized
INFO - 2020-03-05 04:14:14 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 04:14:14 --> Model "M_pesan" initialized
INFO - 2020-03-05 04:14:14 --> Helper loaded: form_helper
INFO - 2020-03-05 04:14:14 --> Form Validation Class Initialized
INFO - 2020-03-05 04:14:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 04:14:14 --> Final output sent to browser
DEBUG - 2020-03-05 04:14:14 --> Total execution time: 0.0096
INFO - 2020-03-05 04:31:18 --> Config Class Initialized
INFO - 2020-03-05 04:31:18 --> Hooks Class Initialized
DEBUG - 2020-03-05 04:31:18 --> UTF-8 Support Enabled
INFO - 2020-03-05 04:31:18 --> Utf8 Class Initialized
INFO - 2020-03-05 04:31:18 --> URI Class Initialized
INFO - 2020-03-05 04:31:18 --> Router Class Initialized
INFO - 2020-03-05 04:31:18 --> Output Class Initialized
INFO - 2020-03-05 04:31:18 --> Security Class Initialized
DEBUG - 2020-03-05 04:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 04:31:18 --> Input Class Initialized
INFO - 2020-03-05 04:31:18 --> Language Class Initialized
INFO - 2020-03-05 04:31:18 --> Loader Class Initialized
INFO - 2020-03-05 04:31:18 --> Helper loaded: url_helper
INFO - 2020-03-05 04:31:18 --> Helper loaded: string_helper
INFO - 2020-03-05 04:31:18 --> Database Driver Class Initialized
DEBUG - 2020-03-05 04:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 04:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 04:31:18 --> Controller Class Initialized
INFO - 2020-03-05 04:31:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 04:31:18 --> Pagination Class Initialized
INFO - 2020-03-05 04:31:18 --> Model "M_show" initialized
INFO - 2020-03-05 04:31:18 --> Helper loaded: form_helper
INFO - 2020-03-05 04:31:18 --> Form Validation Class Initialized
INFO - 2020-03-05 04:31:18 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 04:31:18 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 04:31:18 --> Final output sent to browser
DEBUG - 2020-03-05 04:31:18 --> Total execution time: 0.0425
INFO - 2020-03-05 04:34:12 --> Config Class Initialized
INFO - 2020-03-05 04:34:12 --> Hooks Class Initialized
DEBUG - 2020-03-05 04:34:12 --> UTF-8 Support Enabled
INFO - 2020-03-05 04:34:12 --> Utf8 Class Initialized
INFO - 2020-03-05 04:34:12 --> URI Class Initialized
INFO - 2020-03-05 04:34:12 --> Router Class Initialized
INFO - 2020-03-05 04:34:12 --> Output Class Initialized
INFO - 2020-03-05 04:34:12 --> Security Class Initialized
DEBUG - 2020-03-05 04:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 04:34:12 --> Input Class Initialized
INFO - 2020-03-05 04:34:12 --> Language Class Initialized
INFO - 2020-03-05 04:34:12 --> Loader Class Initialized
INFO - 2020-03-05 04:34:12 --> Helper loaded: url_helper
INFO - 2020-03-05 04:34:12 --> Helper loaded: string_helper
INFO - 2020-03-05 04:34:12 --> Database Driver Class Initialized
DEBUG - 2020-03-05 04:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 04:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 04:34:12 --> Controller Class Initialized
INFO - 2020-03-05 04:34:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 04:34:12 --> Pagination Class Initialized
INFO - 2020-03-05 04:34:12 --> Model "M_show" initialized
INFO - 2020-03-05 04:34:12 --> Helper loaded: form_helper
INFO - 2020-03-05 04:34:12 --> Form Validation Class Initialized
INFO - 2020-03-05 04:34:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 04:34:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 04:34:12 --> Final output sent to browser
DEBUG - 2020-03-05 04:34:12 --> Total execution time: 0.0319
INFO - 2020-03-05 04:40:29 --> Config Class Initialized
INFO - 2020-03-05 04:40:29 --> Hooks Class Initialized
DEBUG - 2020-03-05 04:40:29 --> UTF-8 Support Enabled
INFO - 2020-03-05 04:40:29 --> Utf8 Class Initialized
INFO - 2020-03-05 04:40:29 --> URI Class Initialized
INFO - 2020-03-05 04:40:29 --> Router Class Initialized
INFO - 2020-03-05 04:40:29 --> Output Class Initialized
INFO - 2020-03-05 04:40:29 --> Security Class Initialized
DEBUG - 2020-03-05 04:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 04:40:29 --> Input Class Initialized
INFO - 2020-03-05 04:40:29 --> Language Class Initialized
INFO - 2020-03-05 04:40:29 --> Loader Class Initialized
INFO - 2020-03-05 04:40:29 --> Helper loaded: url_helper
INFO - 2020-03-05 04:40:29 --> Helper loaded: string_helper
INFO - 2020-03-05 04:40:29 --> Database Driver Class Initialized
DEBUG - 2020-03-05 04:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 04:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 04:40:29 --> Controller Class Initialized
INFO - 2020-03-05 04:40:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 04:40:29 --> Pagination Class Initialized
INFO - 2020-03-05 04:40:29 --> Model "M_show" initialized
INFO - 2020-03-05 04:40:29 --> Helper loaded: form_helper
INFO - 2020-03-05 04:40:29 --> Form Validation Class Initialized
INFO - 2020-03-05 04:40:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 04:40:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 04:40:29 --> Final output sent to browser
DEBUG - 2020-03-05 04:40:29 --> Total execution time: 0.0327
INFO - 2020-03-05 05:12:37 --> Config Class Initialized
INFO - 2020-03-05 05:12:37 --> Hooks Class Initialized
DEBUG - 2020-03-05 05:12:37 --> UTF-8 Support Enabled
INFO - 2020-03-05 05:12:37 --> Utf8 Class Initialized
INFO - 2020-03-05 05:12:37 --> URI Class Initialized
INFO - 2020-03-05 05:12:37 --> Router Class Initialized
INFO - 2020-03-05 05:12:37 --> Output Class Initialized
INFO - 2020-03-05 05:12:37 --> Security Class Initialized
DEBUG - 2020-03-05 05:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 05:12:37 --> Input Class Initialized
INFO - 2020-03-05 05:12:37 --> Language Class Initialized
INFO - 2020-03-05 05:12:37 --> Loader Class Initialized
INFO - 2020-03-05 05:12:37 --> Helper loaded: url_helper
INFO - 2020-03-05 05:12:37 --> Helper loaded: string_helper
INFO - 2020-03-05 05:12:37 --> Database Driver Class Initialized
DEBUG - 2020-03-05 05:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 05:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 05:12:37 --> Controller Class Initialized
INFO - 2020-03-05 05:12:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 05:12:37 --> Pagination Class Initialized
INFO - 2020-03-05 05:12:37 --> Model "M_show" initialized
INFO - 2020-03-05 05:12:37 --> Helper loaded: form_helper
INFO - 2020-03-05 05:12:37 --> Form Validation Class Initialized
INFO - 2020-03-05 05:12:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 05:12:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 05:12:37 --> Final output sent to browser
DEBUG - 2020-03-05 05:12:37 --> Total execution time: 0.1088
INFO - 2020-03-05 05:24:37 --> Config Class Initialized
INFO - 2020-03-05 05:24:37 --> Hooks Class Initialized
DEBUG - 2020-03-05 05:24:37 --> UTF-8 Support Enabled
INFO - 2020-03-05 05:24:37 --> Utf8 Class Initialized
INFO - 2020-03-05 05:24:37 --> URI Class Initialized
INFO - 2020-03-05 05:24:37 --> Router Class Initialized
INFO - 2020-03-05 05:24:37 --> Output Class Initialized
INFO - 2020-03-05 05:24:37 --> Security Class Initialized
DEBUG - 2020-03-05 05:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 05:24:37 --> Input Class Initialized
INFO - 2020-03-05 05:24:37 --> Language Class Initialized
INFO - 2020-03-05 05:24:37 --> Loader Class Initialized
INFO - 2020-03-05 05:24:37 --> Helper loaded: url_helper
INFO - 2020-03-05 05:24:37 --> Helper loaded: string_helper
INFO - 2020-03-05 05:24:37 --> Database Driver Class Initialized
DEBUG - 2020-03-05 05:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 05:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 05:24:37 --> Controller Class Initialized
INFO - 2020-03-05 05:24:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 05:24:37 --> Pagination Class Initialized
INFO - 2020-03-05 05:24:37 --> Model "M_show" initialized
INFO - 2020-03-05 05:24:37 --> Helper loaded: form_helper
INFO - 2020-03-05 05:24:37 --> Form Validation Class Initialized
INFO - 2020-03-05 05:24:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 05:24:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 05:24:37 --> Final output sent to browser
DEBUG - 2020-03-05 05:24:37 --> Total execution time: 0.0440
INFO - 2020-03-05 05:24:38 --> Config Class Initialized
INFO - 2020-03-05 05:24:38 --> Hooks Class Initialized
DEBUG - 2020-03-05 05:24:38 --> UTF-8 Support Enabled
INFO - 2020-03-05 05:24:38 --> Utf8 Class Initialized
INFO - 2020-03-05 05:24:38 --> URI Class Initialized
INFO - 2020-03-05 05:24:38 --> Router Class Initialized
INFO - 2020-03-05 05:24:38 --> Output Class Initialized
INFO - 2020-03-05 05:24:38 --> Security Class Initialized
DEBUG - 2020-03-05 05:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 05:24:38 --> Input Class Initialized
INFO - 2020-03-05 05:24:38 --> Language Class Initialized
INFO - 2020-03-05 05:24:38 --> Loader Class Initialized
INFO - 2020-03-05 05:24:38 --> Helper loaded: url_helper
INFO - 2020-03-05 05:24:38 --> Helper loaded: string_helper
INFO - 2020-03-05 05:24:38 --> Database Driver Class Initialized
DEBUG - 2020-03-05 05:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 05:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 05:24:38 --> Controller Class Initialized
INFO - 2020-03-05 05:24:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 05:24:38 --> Pagination Class Initialized
INFO - 2020-03-05 05:24:38 --> Model "M_show" initialized
INFO - 2020-03-05 05:24:38 --> Helper loaded: form_helper
INFO - 2020-03-05 05:24:38 --> Form Validation Class Initialized
INFO - 2020-03-05 05:24:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 05:24:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 05:24:38 --> Final output sent to browser
DEBUG - 2020-03-05 05:24:38 --> Total execution time: 0.0089
INFO - 2020-03-05 05:24:38 --> Config Class Initialized
INFO - 2020-03-05 05:24:38 --> Hooks Class Initialized
DEBUG - 2020-03-05 05:24:38 --> UTF-8 Support Enabled
INFO - 2020-03-05 05:24:38 --> Utf8 Class Initialized
INFO - 2020-03-05 05:24:38 --> URI Class Initialized
INFO - 2020-03-05 05:24:38 --> Router Class Initialized
INFO - 2020-03-05 05:24:38 --> Output Class Initialized
INFO - 2020-03-05 05:24:38 --> Security Class Initialized
DEBUG - 2020-03-05 05:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 05:24:38 --> Input Class Initialized
INFO - 2020-03-05 05:24:38 --> Language Class Initialized
ERROR - 2020-03-05 05:24:38 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-05 05:24:38 --> Config Class Initialized
INFO - 2020-03-05 05:24:38 --> Hooks Class Initialized
DEBUG - 2020-03-05 05:24:38 --> UTF-8 Support Enabled
INFO - 2020-03-05 05:24:38 --> Utf8 Class Initialized
INFO - 2020-03-05 05:24:38 --> URI Class Initialized
INFO - 2020-03-05 05:24:38 --> Router Class Initialized
INFO - 2020-03-05 05:24:38 --> Output Class Initialized
INFO - 2020-03-05 05:24:38 --> Security Class Initialized
DEBUG - 2020-03-05 05:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 05:24:38 --> Input Class Initialized
INFO - 2020-03-05 05:24:38 --> Language Class Initialized
INFO - 2020-03-05 05:24:38 --> Loader Class Initialized
INFO - 2020-03-05 05:24:38 --> Helper loaded: url_helper
INFO - 2020-03-05 05:24:38 --> Helper loaded: string_helper
INFO - 2020-03-05 05:24:38 --> Database Driver Class Initialized
DEBUG - 2020-03-05 05:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 05:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 05:24:38 --> Controller Class Initialized
INFO - 2020-03-05 05:24:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 05:24:38 --> Pagination Class Initialized
INFO - 2020-03-05 05:24:38 --> Model "M_show" initialized
INFO - 2020-03-05 05:24:38 --> Helper loaded: form_helper
INFO - 2020-03-05 05:24:38 --> Form Validation Class Initialized
INFO - 2020-03-05 05:24:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 05:24:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 05:24:38 --> Final output sent to browser
DEBUG - 2020-03-05 05:24:38 --> Total execution time: 0.0056
INFO - 2020-03-05 05:24:49 --> Config Class Initialized
INFO - 2020-03-05 05:24:49 --> Hooks Class Initialized
DEBUG - 2020-03-05 05:24:49 --> UTF-8 Support Enabled
INFO - 2020-03-05 05:24:49 --> Utf8 Class Initialized
INFO - 2020-03-05 05:24:49 --> URI Class Initialized
DEBUG - 2020-03-05 05:24:49 --> No URI present. Default controller set.
INFO - 2020-03-05 05:24:49 --> Router Class Initialized
INFO - 2020-03-05 05:24:49 --> Output Class Initialized
INFO - 2020-03-05 05:24:49 --> Security Class Initialized
DEBUG - 2020-03-05 05:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 05:24:49 --> Input Class Initialized
INFO - 2020-03-05 05:24:49 --> Language Class Initialized
INFO - 2020-03-05 05:24:49 --> Loader Class Initialized
INFO - 2020-03-05 05:24:49 --> Helper loaded: url_helper
INFO - 2020-03-05 05:24:49 --> Helper loaded: string_helper
INFO - 2020-03-05 05:24:49 --> Database Driver Class Initialized
DEBUG - 2020-03-05 05:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 05:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 05:24:49 --> Controller Class Initialized
INFO - 2020-03-05 05:24:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 05:24:49 --> Pagination Class Initialized
INFO - 2020-03-05 05:24:49 --> Model "M_show" initialized
INFO - 2020-03-05 05:24:49 --> Helper loaded: form_helper
INFO - 2020-03-05 05:24:49 --> Form Validation Class Initialized
INFO - 2020-03-05 05:24:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 05:24:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 05:24:49 --> Final output sent to browser
DEBUG - 2020-03-05 05:24:49 --> Total execution time: 0.0057
INFO - 2020-03-05 05:24:53 --> Config Class Initialized
INFO - 2020-03-05 05:24:53 --> Hooks Class Initialized
DEBUG - 2020-03-05 05:24:53 --> UTF-8 Support Enabled
INFO - 2020-03-05 05:24:53 --> Utf8 Class Initialized
INFO - 2020-03-05 05:24:53 --> URI Class Initialized
INFO - 2020-03-05 05:24:53 --> Router Class Initialized
INFO - 2020-03-05 05:24:53 --> Output Class Initialized
INFO - 2020-03-05 05:24:53 --> Security Class Initialized
DEBUG - 2020-03-05 05:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 05:24:53 --> Input Class Initialized
INFO - 2020-03-05 05:24:53 --> Language Class Initialized
INFO - 2020-03-05 05:24:53 --> Loader Class Initialized
INFO - 2020-03-05 05:24:53 --> Helper loaded: url_helper
INFO - 2020-03-05 05:24:53 --> Helper loaded: string_helper
INFO - 2020-03-05 05:24:53 --> Database Driver Class Initialized
DEBUG - 2020-03-05 05:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 05:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 05:24:53 --> Controller Class Initialized
INFO - 2020-03-05 05:24:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 05:24:53 --> Pagination Class Initialized
INFO - 2020-03-05 05:24:53 --> Model "M_show" initialized
INFO - 2020-03-05 05:24:53 --> Helper loaded: form_helper
INFO - 2020-03-05 05:24:53 --> Form Validation Class Initialized
INFO - 2020-03-05 05:24:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 05:24:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-05 05:24:53 --> Final output sent to browser
DEBUG - 2020-03-05 05:24:53 --> Total execution time: 0.0322
INFO - 2020-03-05 05:24:59 --> Config Class Initialized
INFO - 2020-03-05 05:24:59 --> Hooks Class Initialized
DEBUG - 2020-03-05 05:24:59 --> UTF-8 Support Enabled
INFO - 2020-03-05 05:24:59 --> Utf8 Class Initialized
INFO - 2020-03-05 05:24:59 --> URI Class Initialized
INFO - 2020-03-05 05:24:59 --> Router Class Initialized
INFO - 2020-03-05 05:24:59 --> Output Class Initialized
INFO - 2020-03-05 05:24:59 --> Security Class Initialized
DEBUG - 2020-03-05 05:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 05:24:59 --> Input Class Initialized
INFO - 2020-03-05 05:24:59 --> Language Class Initialized
INFO - 2020-03-05 05:24:59 --> Loader Class Initialized
INFO - 2020-03-05 05:24:59 --> Helper loaded: url_helper
INFO - 2020-03-05 05:24:59 --> Helper loaded: string_helper
INFO - 2020-03-05 05:24:59 --> Database Driver Class Initialized
DEBUG - 2020-03-05 05:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 05:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 05:24:59 --> Controller Class Initialized
INFO - 2020-03-05 05:24:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 05:24:59 --> Pagination Class Initialized
INFO - 2020-03-05 05:24:59 --> Model "M_show" initialized
INFO - 2020-03-05 05:24:59 --> Helper loaded: form_helper
INFO - 2020-03-05 05:24:59 --> Form Validation Class Initialized
INFO - 2020-03-05 05:24:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 05:24:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 05:24:59 --> Final output sent to browser
DEBUG - 2020-03-05 05:24:59 --> Total execution time: 0.0061
INFO - 2020-03-05 05:25:00 --> Config Class Initialized
INFO - 2020-03-05 05:25:00 --> Hooks Class Initialized
DEBUG - 2020-03-05 05:25:00 --> UTF-8 Support Enabled
INFO - 2020-03-05 05:25:00 --> Utf8 Class Initialized
INFO - 2020-03-05 05:25:00 --> URI Class Initialized
INFO - 2020-03-05 05:25:00 --> Router Class Initialized
INFO - 2020-03-05 05:25:00 --> Output Class Initialized
INFO - 2020-03-05 05:25:00 --> Security Class Initialized
DEBUG - 2020-03-05 05:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 05:25:00 --> Input Class Initialized
INFO - 2020-03-05 05:25:00 --> Language Class Initialized
ERROR - 2020-03-05 05:25:00 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-05 05:25:04 --> Config Class Initialized
INFO - 2020-03-05 05:25:04 --> Hooks Class Initialized
DEBUG - 2020-03-05 05:25:04 --> UTF-8 Support Enabled
INFO - 2020-03-05 05:25:04 --> Utf8 Class Initialized
INFO - 2020-03-05 05:25:04 --> URI Class Initialized
INFO - 2020-03-05 05:25:04 --> Router Class Initialized
INFO - 2020-03-05 05:25:04 --> Output Class Initialized
INFO - 2020-03-05 05:25:04 --> Security Class Initialized
DEBUG - 2020-03-05 05:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 05:25:04 --> Input Class Initialized
INFO - 2020-03-05 05:25:04 --> Language Class Initialized
INFO - 2020-03-05 05:25:04 --> Loader Class Initialized
INFO - 2020-03-05 05:25:04 --> Helper loaded: url_helper
INFO - 2020-03-05 05:25:04 --> Helper loaded: string_helper
INFO - 2020-03-05 05:25:04 --> Database Driver Class Initialized
DEBUG - 2020-03-05 05:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 05:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 05:25:04 --> Controller Class Initialized
INFO - 2020-03-05 05:25:04 --> Model "M_tiket" initialized
INFO - 2020-03-05 05:25:04 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 05:25:04 --> Model "M_pesan" initialized
INFO - 2020-03-05 05:25:04 --> Helper loaded: form_helper
INFO - 2020-03-05 05:25:04 --> Form Validation Class Initialized
INFO - 2020-03-05 05:25:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 05:25:04 --> Final output sent to browser
DEBUG - 2020-03-05 05:25:04 --> Total execution time: 0.0307
INFO - 2020-03-05 05:26:30 --> Config Class Initialized
INFO - 2020-03-05 05:26:30 --> Hooks Class Initialized
DEBUG - 2020-03-05 05:26:30 --> UTF-8 Support Enabled
INFO - 2020-03-05 05:26:30 --> Utf8 Class Initialized
INFO - 2020-03-05 05:26:30 --> URI Class Initialized
DEBUG - 2020-03-05 05:26:30 --> No URI present. Default controller set.
INFO - 2020-03-05 05:26:30 --> Router Class Initialized
INFO - 2020-03-05 05:26:30 --> Output Class Initialized
INFO - 2020-03-05 05:26:30 --> Security Class Initialized
DEBUG - 2020-03-05 05:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 05:26:30 --> Input Class Initialized
INFO - 2020-03-05 05:26:30 --> Language Class Initialized
INFO - 2020-03-05 05:26:30 --> Loader Class Initialized
INFO - 2020-03-05 05:26:30 --> Helper loaded: url_helper
INFO - 2020-03-05 05:26:30 --> Helper loaded: string_helper
INFO - 2020-03-05 05:26:30 --> Database Driver Class Initialized
DEBUG - 2020-03-05 05:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 05:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 05:26:30 --> Controller Class Initialized
INFO - 2020-03-05 05:26:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 05:26:30 --> Pagination Class Initialized
INFO - 2020-03-05 05:26:30 --> Model "M_show" initialized
INFO - 2020-03-05 05:26:30 --> Helper loaded: form_helper
INFO - 2020-03-05 05:26:30 --> Form Validation Class Initialized
INFO - 2020-03-05 05:26:30 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 05:26:30 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 05:26:30 --> Final output sent to browser
DEBUG - 2020-03-05 05:26:30 --> Total execution time: 0.0309
INFO - 2020-03-05 05:26:31 --> Config Class Initialized
INFO - 2020-03-05 05:26:31 --> Hooks Class Initialized
DEBUG - 2020-03-05 05:26:31 --> UTF-8 Support Enabled
INFO - 2020-03-05 05:26:31 --> Utf8 Class Initialized
INFO - 2020-03-05 05:26:31 --> URI Class Initialized
DEBUG - 2020-03-05 05:26:31 --> No URI present. Default controller set.
INFO - 2020-03-05 05:26:31 --> Router Class Initialized
INFO - 2020-03-05 05:26:31 --> Output Class Initialized
INFO - 2020-03-05 05:26:31 --> Security Class Initialized
DEBUG - 2020-03-05 05:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 05:26:31 --> Input Class Initialized
INFO - 2020-03-05 05:26:31 --> Language Class Initialized
INFO - 2020-03-05 05:26:31 --> Loader Class Initialized
INFO - 2020-03-05 05:26:31 --> Helper loaded: url_helper
INFO - 2020-03-05 05:26:31 --> Helper loaded: string_helper
INFO - 2020-03-05 05:26:31 --> Database Driver Class Initialized
DEBUG - 2020-03-05 05:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 05:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 05:26:31 --> Controller Class Initialized
INFO - 2020-03-05 05:26:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 05:26:31 --> Pagination Class Initialized
INFO - 2020-03-05 05:26:31 --> Model "M_show" initialized
INFO - 2020-03-05 05:26:31 --> Helper loaded: form_helper
INFO - 2020-03-05 05:26:31 --> Form Validation Class Initialized
INFO - 2020-03-05 05:26:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 05:26:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 05:26:31 --> Final output sent to browser
DEBUG - 2020-03-05 05:26:31 --> Total execution time: 0.0054
INFO - 2020-03-05 05:26:44 --> Config Class Initialized
INFO - 2020-03-05 05:26:44 --> Hooks Class Initialized
DEBUG - 2020-03-05 05:26:44 --> UTF-8 Support Enabled
INFO - 2020-03-05 05:26:44 --> Utf8 Class Initialized
INFO - 2020-03-05 05:26:44 --> URI Class Initialized
INFO - 2020-03-05 05:26:44 --> Router Class Initialized
INFO - 2020-03-05 05:26:44 --> Output Class Initialized
INFO - 2020-03-05 05:26:44 --> Security Class Initialized
DEBUG - 2020-03-05 05:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 05:26:44 --> Input Class Initialized
INFO - 2020-03-05 05:26:44 --> Language Class Initialized
INFO - 2020-03-05 05:26:44 --> Loader Class Initialized
INFO - 2020-03-05 05:26:44 --> Helper loaded: url_helper
INFO - 2020-03-05 05:26:44 --> Helper loaded: string_helper
INFO - 2020-03-05 05:26:44 --> Database Driver Class Initialized
DEBUG - 2020-03-05 05:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 05:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 05:26:44 --> Controller Class Initialized
INFO - 2020-03-05 05:26:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 05:26:44 --> Pagination Class Initialized
INFO - 2020-03-05 05:26:44 --> Model "M_show" initialized
INFO - 2020-03-05 05:26:44 --> Helper loaded: form_helper
INFO - 2020-03-05 05:26:44 --> Form Validation Class Initialized
INFO - 2020-03-05 05:26:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 05:26:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 05:26:44 --> Final output sent to browser
DEBUG - 2020-03-05 05:26:44 --> Total execution time: 0.0112
INFO - 2020-03-05 05:27:23 --> Config Class Initialized
INFO - 2020-03-05 05:27:23 --> Hooks Class Initialized
DEBUG - 2020-03-05 05:27:23 --> UTF-8 Support Enabled
INFO - 2020-03-05 05:27:23 --> Utf8 Class Initialized
INFO - 2020-03-05 05:27:23 --> URI Class Initialized
INFO - 2020-03-05 05:27:23 --> Router Class Initialized
INFO - 2020-03-05 05:27:23 --> Output Class Initialized
INFO - 2020-03-05 05:27:23 --> Security Class Initialized
DEBUG - 2020-03-05 05:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 05:27:23 --> Input Class Initialized
INFO - 2020-03-05 05:27:23 --> Language Class Initialized
INFO - 2020-03-05 05:27:23 --> Loader Class Initialized
INFO - 2020-03-05 05:27:23 --> Helper loaded: url_helper
INFO - 2020-03-05 05:27:23 --> Helper loaded: string_helper
INFO - 2020-03-05 05:27:23 --> Database Driver Class Initialized
DEBUG - 2020-03-05 05:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 05:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 05:27:23 --> Controller Class Initialized
INFO - 2020-03-05 05:27:23 --> Model "M_tiket" initialized
INFO - 2020-03-05 05:27:23 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 05:27:23 --> Model "M_pesan" initialized
INFO - 2020-03-05 05:27:23 --> Helper loaded: form_helper
INFO - 2020-03-05 05:27:23 --> Form Validation Class Initialized
INFO - 2020-03-05 05:27:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 05:27:23 --> Final output sent to browser
DEBUG - 2020-03-05 05:27:23 --> Total execution time: 0.0123
INFO - 2020-03-05 06:10:35 --> Config Class Initialized
INFO - 2020-03-05 06:10:35 --> Hooks Class Initialized
DEBUG - 2020-03-05 06:10:35 --> UTF-8 Support Enabled
INFO - 2020-03-05 06:10:35 --> Utf8 Class Initialized
INFO - 2020-03-05 06:10:35 --> URI Class Initialized
DEBUG - 2020-03-05 06:10:35 --> No URI present. Default controller set.
INFO - 2020-03-05 06:10:35 --> Router Class Initialized
INFO - 2020-03-05 06:10:35 --> Output Class Initialized
INFO - 2020-03-05 06:10:35 --> Security Class Initialized
DEBUG - 2020-03-05 06:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 06:10:35 --> Input Class Initialized
INFO - 2020-03-05 06:10:35 --> Language Class Initialized
INFO - 2020-03-05 06:10:35 --> Loader Class Initialized
INFO - 2020-03-05 06:10:35 --> Helper loaded: url_helper
INFO - 2020-03-05 06:10:35 --> Helper loaded: string_helper
INFO - 2020-03-05 06:10:35 --> Database Driver Class Initialized
DEBUG - 2020-03-05 06:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 06:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 06:10:35 --> Controller Class Initialized
INFO - 2020-03-05 06:10:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 06:10:35 --> Pagination Class Initialized
INFO - 2020-03-05 06:10:35 --> Model "M_show" initialized
INFO - 2020-03-05 06:10:35 --> Helper loaded: form_helper
INFO - 2020-03-05 06:10:35 --> Form Validation Class Initialized
INFO - 2020-03-05 06:10:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 06:10:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 06:10:35 --> Final output sent to browser
DEBUG - 2020-03-05 06:10:35 --> Total execution time: 0.0348
INFO - 2020-03-05 06:16:14 --> Config Class Initialized
INFO - 2020-03-05 06:16:14 --> Hooks Class Initialized
DEBUG - 2020-03-05 06:16:14 --> UTF-8 Support Enabled
INFO - 2020-03-05 06:16:14 --> Utf8 Class Initialized
INFO - 2020-03-05 06:16:14 --> URI Class Initialized
INFO - 2020-03-05 06:16:14 --> Router Class Initialized
INFO - 2020-03-05 06:16:14 --> Output Class Initialized
INFO - 2020-03-05 06:16:14 --> Security Class Initialized
DEBUG - 2020-03-05 06:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 06:16:14 --> Input Class Initialized
INFO - 2020-03-05 06:16:14 --> Language Class Initialized
INFO - 2020-03-05 06:16:14 --> Loader Class Initialized
INFO - 2020-03-05 06:16:14 --> Helper loaded: url_helper
INFO - 2020-03-05 06:16:14 --> Helper loaded: string_helper
INFO - 2020-03-05 06:16:14 --> Database Driver Class Initialized
DEBUG - 2020-03-05 06:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 06:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 06:16:14 --> Controller Class Initialized
INFO - 2020-03-05 06:16:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 06:16:14 --> Pagination Class Initialized
INFO - 2020-03-05 06:16:14 --> Model "M_show" initialized
INFO - 2020-03-05 06:16:14 --> Helper loaded: form_helper
INFO - 2020-03-05 06:16:14 --> Form Validation Class Initialized
INFO - 2020-03-05 06:16:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 06:16:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 06:16:14 --> Final output sent to browser
DEBUG - 2020-03-05 06:16:14 --> Total execution time: 0.0463
INFO - 2020-03-05 06:35:24 --> Config Class Initialized
INFO - 2020-03-05 06:35:24 --> Hooks Class Initialized
DEBUG - 2020-03-05 06:35:24 --> UTF-8 Support Enabled
INFO - 2020-03-05 06:35:24 --> Utf8 Class Initialized
INFO - 2020-03-05 06:35:24 --> URI Class Initialized
INFO - 2020-03-05 06:35:24 --> Router Class Initialized
INFO - 2020-03-05 06:35:24 --> Output Class Initialized
INFO - 2020-03-05 06:35:24 --> Security Class Initialized
DEBUG - 2020-03-05 06:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 06:35:24 --> Input Class Initialized
INFO - 2020-03-05 06:35:24 --> Language Class Initialized
INFO - 2020-03-05 06:35:24 --> Loader Class Initialized
INFO - 2020-03-05 06:35:24 --> Helper loaded: url_helper
INFO - 2020-03-05 06:35:24 --> Helper loaded: string_helper
INFO - 2020-03-05 06:35:24 --> Database Driver Class Initialized
DEBUG - 2020-03-05 06:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 06:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 06:35:24 --> Controller Class Initialized
INFO - 2020-03-05 06:35:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 06:35:24 --> Pagination Class Initialized
INFO - 2020-03-05 06:35:24 --> Model "M_show" initialized
INFO - 2020-03-05 06:35:24 --> Helper loaded: form_helper
INFO - 2020-03-05 06:35:24 --> Form Validation Class Initialized
INFO - 2020-03-05 06:35:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 06:35:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 06:35:24 --> Final output sent to browser
DEBUG - 2020-03-05 06:35:24 --> Total execution time: 0.0344
INFO - 2020-03-05 06:40:00 --> Config Class Initialized
INFO - 2020-03-05 06:40:00 --> Hooks Class Initialized
DEBUG - 2020-03-05 06:40:00 --> UTF-8 Support Enabled
INFO - 2020-03-05 06:40:00 --> Utf8 Class Initialized
INFO - 2020-03-05 06:40:00 --> URI Class Initialized
INFO - 2020-03-05 06:40:00 --> Router Class Initialized
INFO - 2020-03-05 06:40:00 --> Output Class Initialized
INFO - 2020-03-05 06:40:00 --> Security Class Initialized
DEBUG - 2020-03-05 06:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 06:40:00 --> Input Class Initialized
INFO - 2020-03-05 06:40:00 --> Language Class Initialized
INFO - 2020-03-05 06:40:00 --> Loader Class Initialized
INFO - 2020-03-05 06:40:00 --> Helper loaded: url_helper
INFO - 2020-03-05 06:40:00 --> Helper loaded: string_helper
INFO - 2020-03-05 06:40:00 --> Database Driver Class Initialized
DEBUG - 2020-03-05 06:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 06:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 06:40:00 --> Controller Class Initialized
INFO - 2020-03-05 06:40:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 06:40:00 --> Pagination Class Initialized
INFO - 2020-03-05 06:40:00 --> Model "M_show" initialized
INFO - 2020-03-05 06:40:00 --> Helper loaded: form_helper
INFO - 2020-03-05 06:40:00 --> Form Validation Class Initialized
INFO - 2020-03-05 06:40:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 06:40:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 06:40:00 --> Final output sent to browser
DEBUG - 2020-03-05 06:40:00 --> Total execution time: 0.2977
INFO - 2020-03-05 06:40:13 --> Config Class Initialized
INFO - 2020-03-05 06:40:13 --> Hooks Class Initialized
DEBUG - 2020-03-05 06:40:13 --> UTF-8 Support Enabled
INFO - 2020-03-05 06:40:13 --> Utf8 Class Initialized
INFO - 2020-03-05 06:40:13 --> URI Class Initialized
INFO - 2020-03-05 06:40:13 --> Router Class Initialized
INFO - 2020-03-05 06:40:13 --> Output Class Initialized
INFO - 2020-03-05 06:40:13 --> Security Class Initialized
DEBUG - 2020-03-05 06:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 06:40:13 --> Input Class Initialized
INFO - 2020-03-05 06:40:13 --> Language Class Initialized
INFO - 2020-03-05 06:40:13 --> Loader Class Initialized
INFO - 2020-03-05 06:40:13 --> Helper loaded: url_helper
INFO - 2020-03-05 06:40:13 --> Helper loaded: string_helper
INFO - 2020-03-05 06:40:13 --> Database Driver Class Initialized
DEBUG - 2020-03-05 06:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 06:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 06:40:13 --> Controller Class Initialized
INFO - 2020-03-05 06:40:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 06:40:13 --> Pagination Class Initialized
INFO - 2020-03-05 06:40:13 --> Model "M_show" initialized
INFO - 2020-03-05 06:40:13 --> Helper loaded: form_helper
INFO - 2020-03-05 06:40:13 --> Form Validation Class Initialized
INFO - 2020-03-05 06:40:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 06:40:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 06:40:13 --> Final output sent to browser
DEBUG - 2020-03-05 06:40:13 --> Total execution time: 0.0071
INFO - 2020-03-05 06:52:43 --> Config Class Initialized
INFO - 2020-03-05 06:52:43 --> Hooks Class Initialized
DEBUG - 2020-03-05 06:52:43 --> UTF-8 Support Enabled
INFO - 2020-03-05 06:52:43 --> Utf8 Class Initialized
INFO - 2020-03-05 06:52:43 --> URI Class Initialized
INFO - 2020-03-05 06:52:43 --> Router Class Initialized
INFO - 2020-03-05 06:52:43 --> Output Class Initialized
INFO - 2020-03-05 06:52:43 --> Security Class Initialized
DEBUG - 2020-03-05 06:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 06:52:43 --> Input Class Initialized
INFO - 2020-03-05 06:52:43 --> Language Class Initialized
INFO - 2020-03-05 06:52:43 --> Loader Class Initialized
INFO - 2020-03-05 06:52:43 --> Helper loaded: url_helper
INFO - 2020-03-05 06:52:43 --> Helper loaded: string_helper
INFO - 2020-03-05 06:52:43 --> Database Driver Class Initialized
DEBUG - 2020-03-05 06:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 06:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 06:52:44 --> Controller Class Initialized
INFO - 2020-03-05 06:52:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 06:52:44 --> Pagination Class Initialized
INFO - 2020-03-05 06:52:44 --> Model "M_show" initialized
INFO - 2020-03-05 06:52:44 --> Helper loaded: form_helper
INFO - 2020-03-05 06:52:44 --> Form Validation Class Initialized
INFO - 2020-03-05 06:52:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 06:52:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 06:52:44 --> Final output sent to browser
DEBUG - 2020-03-05 06:52:44 --> Total execution time: 0.0759
INFO - 2020-03-05 06:53:01 --> Config Class Initialized
INFO - 2020-03-05 06:53:01 --> Hooks Class Initialized
DEBUG - 2020-03-05 06:53:01 --> UTF-8 Support Enabled
INFO - 2020-03-05 06:53:01 --> Utf8 Class Initialized
INFO - 2020-03-05 06:53:01 --> URI Class Initialized
INFO - 2020-03-05 06:53:01 --> Router Class Initialized
INFO - 2020-03-05 06:53:01 --> Output Class Initialized
INFO - 2020-03-05 06:53:01 --> Security Class Initialized
DEBUG - 2020-03-05 06:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 06:53:01 --> Input Class Initialized
INFO - 2020-03-05 06:53:01 --> Language Class Initialized
INFO - 2020-03-05 06:53:01 --> Loader Class Initialized
INFO - 2020-03-05 06:53:01 --> Helper loaded: url_helper
INFO - 2020-03-05 06:53:01 --> Helper loaded: string_helper
INFO - 2020-03-05 06:53:01 --> Database Driver Class Initialized
DEBUG - 2020-03-05 06:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 06:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 06:53:01 --> Controller Class Initialized
INFO - 2020-03-05 06:53:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 06:53:01 --> Pagination Class Initialized
INFO - 2020-03-05 06:53:01 --> Model "M_show" initialized
INFO - 2020-03-05 06:53:01 --> Helper loaded: form_helper
INFO - 2020-03-05 06:53:01 --> Form Validation Class Initialized
INFO - 2020-03-05 06:53:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 06:53:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-05 06:53:01 --> Final output sent to browser
DEBUG - 2020-03-05 06:53:01 --> Total execution time: 0.0091
INFO - 2020-03-05 07:14:53 --> Config Class Initialized
INFO - 2020-03-05 07:14:53 --> Hooks Class Initialized
DEBUG - 2020-03-05 07:14:53 --> UTF-8 Support Enabled
INFO - 2020-03-05 07:14:53 --> Utf8 Class Initialized
INFO - 2020-03-05 07:14:53 --> URI Class Initialized
INFO - 2020-03-05 07:14:53 --> Router Class Initialized
INFO - 2020-03-05 07:14:53 --> Output Class Initialized
INFO - 2020-03-05 07:14:53 --> Security Class Initialized
DEBUG - 2020-03-05 07:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 07:14:53 --> Input Class Initialized
INFO - 2020-03-05 07:14:53 --> Language Class Initialized
INFO - 2020-03-05 07:14:53 --> Loader Class Initialized
INFO - 2020-03-05 07:14:53 --> Helper loaded: url_helper
INFO - 2020-03-05 07:14:53 --> Helper loaded: string_helper
INFO - 2020-03-05 07:14:53 --> Database Driver Class Initialized
DEBUG - 2020-03-05 07:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 07:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 07:14:53 --> Controller Class Initialized
INFO - 2020-03-05 07:14:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 07:14:53 --> Pagination Class Initialized
INFO - 2020-03-05 07:14:53 --> Model "M_show" initialized
INFO - 2020-03-05 07:14:53 --> Helper loaded: form_helper
INFO - 2020-03-05 07:14:53 --> Form Validation Class Initialized
INFO - 2020-03-05 07:14:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 07:14:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 07:14:53 --> Final output sent to browser
DEBUG - 2020-03-05 07:14:53 --> Total execution time: 0.0987
INFO - 2020-03-05 07:15:09 --> Config Class Initialized
INFO - 2020-03-05 07:15:09 --> Hooks Class Initialized
DEBUG - 2020-03-05 07:15:09 --> UTF-8 Support Enabled
INFO - 2020-03-05 07:15:09 --> Utf8 Class Initialized
INFO - 2020-03-05 07:15:09 --> URI Class Initialized
INFO - 2020-03-05 07:15:09 --> Router Class Initialized
INFO - 2020-03-05 07:15:09 --> Output Class Initialized
INFO - 2020-03-05 07:15:09 --> Security Class Initialized
DEBUG - 2020-03-05 07:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 07:15:09 --> Input Class Initialized
INFO - 2020-03-05 07:15:09 --> Language Class Initialized
INFO - 2020-03-05 07:15:09 --> Loader Class Initialized
INFO - 2020-03-05 07:15:09 --> Helper loaded: url_helper
INFO - 2020-03-05 07:15:09 --> Helper loaded: string_helper
INFO - 2020-03-05 07:15:09 --> Database Driver Class Initialized
DEBUG - 2020-03-05 07:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 07:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 07:15:09 --> Controller Class Initialized
INFO - 2020-03-05 07:15:09 --> Model "M_tiket" initialized
INFO - 2020-03-05 07:15:09 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 07:15:09 --> Model "M_pesan" initialized
INFO - 2020-03-05 07:15:09 --> Helper loaded: form_helper
INFO - 2020-03-05 07:15:09 --> Form Validation Class Initialized
INFO - 2020-03-05 07:15:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 07:15:09 --> Final output sent to browser
DEBUG - 2020-03-05 07:15:09 --> Total execution time: 0.0935
INFO - 2020-03-05 07:32:34 --> Config Class Initialized
INFO - 2020-03-05 07:32:34 --> Hooks Class Initialized
DEBUG - 2020-03-05 07:32:34 --> UTF-8 Support Enabled
INFO - 2020-03-05 07:32:34 --> Utf8 Class Initialized
INFO - 2020-03-05 07:32:34 --> URI Class Initialized
INFO - 2020-03-05 07:32:34 --> Router Class Initialized
INFO - 2020-03-05 07:32:34 --> Output Class Initialized
INFO - 2020-03-05 07:32:34 --> Security Class Initialized
DEBUG - 2020-03-05 07:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 07:32:34 --> Input Class Initialized
INFO - 2020-03-05 07:32:34 --> Language Class Initialized
INFO - 2020-03-05 07:32:34 --> Loader Class Initialized
INFO - 2020-03-05 07:32:34 --> Helper loaded: url_helper
INFO - 2020-03-05 07:32:34 --> Helper loaded: string_helper
INFO - 2020-03-05 07:32:34 --> Database Driver Class Initialized
DEBUG - 2020-03-05 07:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 07:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 07:32:34 --> Controller Class Initialized
INFO - 2020-03-05 07:32:34 --> Model "M_tiket" initialized
INFO - 2020-03-05 07:32:34 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 07:32:34 --> Model "M_pesan" initialized
INFO - 2020-03-05 07:32:34 --> Helper loaded: form_helper
INFO - 2020-03-05 07:32:34 --> Form Validation Class Initialized
INFO - 2020-03-05 07:32:34 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 07:32:34 --> Final output sent to browser
DEBUG - 2020-03-05 07:32:34 --> Total execution time: 0.0330
INFO - 2020-03-05 07:41:31 --> Config Class Initialized
INFO - 2020-03-05 07:41:31 --> Hooks Class Initialized
DEBUG - 2020-03-05 07:41:31 --> UTF-8 Support Enabled
INFO - 2020-03-05 07:41:31 --> Utf8 Class Initialized
INFO - 2020-03-05 07:41:31 --> URI Class Initialized
INFO - 2020-03-05 07:41:31 --> Router Class Initialized
INFO - 2020-03-05 07:41:31 --> Output Class Initialized
INFO - 2020-03-05 07:41:31 --> Security Class Initialized
DEBUG - 2020-03-05 07:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 07:41:31 --> Input Class Initialized
INFO - 2020-03-05 07:41:31 --> Language Class Initialized
INFO - 2020-03-05 07:41:31 --> Loader Class Initialized
INFO - 2020-03-05 07:41:31 --> Helper loaded: url_helper
INFO - 2020-03-05 07:41:31 --> Helper loaded: string_helper
INFO - 2020-03-05 07:41:31 --> Database Driver Class Initialized
DEBUG - 2020-03-05 07:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 07:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 07:41:31 --> Controller Class Initialized
INFO - 2020-03-05 07:41:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 07:41:31 --> Pagination Class Initialized
INFO - 2020-03-05 07:41:31 --> Model "M_show" initialized
INFO - 2020-03-05 07:41:31 --> Helper loaded: form_helper
INFO - 2020-03-05 07:41:31 --> Form Validation Class Initialized
INFO - 2020-03-05 07:41:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 07:41:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 07:41:31 --> Final output sent to browser
DEBUG - 2020-03-05 07:41:31 --> Total execution time: 0.0445
INFO - 2020-03-05 07:50:56 --> Config Class Initialized
INFO - 2020-03-05 07:50:56 --> Hooks Class Initialized
DEBUG - 2020-03-05 07:50:56 --> UTF-8 Support Enabled
INFO - 2020-03-05 07:50:56 --> Utf8 Class Initialized
INFO - 2020-03-05 07:50:56 --> URI Class Initialized
DEBUG - 2020-03-05 07:50:56 --> No URI present. Default controller set.
INFO - 2020-03-05 07:50:56 --> Router Class Initialized
INFO - 2020-03-05 07:50:56 --> Output Class Initialized
INFO - 2020-03-05 07:50:56 --> Security Class Initialized
DEBUG - 2020-03-05 07:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 07:50:56 --> Input Class Initialized
INFO - 2020-03-05 07:50:56 --> Language Class Initialized
INFO - 2020-03-05 07:50:56 --> Loader Class Initialized
INFO - 2020-03-05 07:50:56 --> Helper loaded: url_helper
INFO - 2020-03-05 07:50:56 --> Helper loaded: string_helper
INFO - 2020-03-05 07:50:56 --> Database Driver Class Initialized
DEBUG - 2020-03-05 07:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 07:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 07:50:56 --> Controller Class Initialized
INFO - 2020-03-05 07:50:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 07:50:56 --> Pagination Class Initialized
INFO - 2020-03-05 07:50:56 --> Model "M_show" initialized
INFO - 2020-03-05 07:50:56 --> Helper loaded: form_helper
INFO - 2020-03-05 07:50:56 --> Form Validation Class Initialized
INFO - 2020-03-05 07:50:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 07:50:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 07:50:56 --> Final output sent to browser
DEBUG - 2020-03-05 07:50:56 --> Total execution time: 0.0338
INFO - 2020-03-05 08:00:36 --> Config Class Initialized
INFO - 2020-03-05 08:00:36 --> Hooks Class Initialized
DEBUG - 2020-03-05 08:00:36 --> UTF-8 Support Enabled
INFO - 2020-03-05 08:00:36 --> Utf8 Class Initialized
INFO - 2020-03-05 08:00:36 --> URI Class Initialized
INFO - 2020-03-05 08:00:36 --> Router Class Initialized
INFO - 2020-03-05 08:00:36 --> Output Class Initialized
INFO - 2020-03-05 08:00:36 --> Security Class Initialized
DEBUG - 2020-03-05 08:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 08:00:36 --> Input Class Initialized
INFO - 2020-03-05 08:00:36 --> Language Class Initialized
INFO - 2020-03-05 08:00:36 --> Loader Class Initialized
INFO - 2020-03-05 08:00:36 --> Helper loaded: url_helper
INFO - 2020-03-05 08:00:36 --> Helper loaded: string_helper
INFO - 2020-03-05 08:00:36 --> Database Driver Class Initialized
DEBUG - 2020-03-05 08:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 08:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 08:00:36 --> Controller Class Initialized
INFO - 2020-03-05 08:00:36 --> Model "M_tiket" initialized
INFO - 2020-03-05 08:00:36 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 08:00:36 --> Model "M_pesan" initialized
INFO - 2020-03-05 08:00:36 --> Helper loaded: form_helper
INFO - 2020-03-05 08:00:36 --> Form Validation Class Initialized
INFO - 2020-03-05 08:00:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 08:00:36 --> Final output sent to browser
DEBUG - 2020-03-05 08:00:36 --> Total execution time: 0.0330
INFO - 2020-03-05 08:13:18 --> Config Class Initialized
INFO - 2020-03-05 08:13:18 --> Hooks Class Initialized
DEBUG - 2020-03-05 08:13:18 --> UTF-8 Support Enabled
INFO - 2020-03-05 08:13:18 --> Utf8 Class Initialized
INFO - 2020-03-05 08:13:18 --> URI Class Initialized
INFO - 2020-03-05 08:13:18 --> Router Class Initialized
INFO - 2020-03-05 08:13:18 --> Output Class Initialized
INFO - 2020-03-05 08:13:18 --> Security Class Initialized
DEBUG - 2020-03-05 08:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 08:13:18 --> Input Class Initialized
INFO - 2020-03-05 08:13:18 --> Language Class Initialized
INFO - 2020-03-05 08:13:18 --> Loader Class Initialized
INFO - 2020-03-05 08:13:18 --> Helper loaded: url_helper
INFO - 2020-03-05 08:13:18 --> Helper loaded: string_helper
INFO - 2020-03-05 08:13:18 --> Database Driver Class Initialized
DEBUG - 2020-03-05 08:13:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 08:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 08:13:18 --> Controller Class Initialized
INFO - 2020-03-05 08:13:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 08:13:18 --> Pagination Class Initialized
INFO - 2020-03-05 08:13:18 --> Model "M_show" initialized
INFO - 2020-03-05 08:13:18 --> Helper loaded: form_helper
INFO - 2020-03-05 08:13:18 --> Form Validation Class Initialized
INFO - 2020-03-05 08:13:18 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 08:13:18 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 08:13:18 --> Final output sent to browser
DEBUG - 2020-03-05 08:13:18 --> Total execution time: 0.0317
INFO - 2020-03-05 08:14:44 --> Config Class Initialized
INFO - 2020-03-05 08:14:44 --> Hooks Class Initialized
DEBUG - 2020-03-05 08:14:44 --> UTF-8 Support Enabled
INFO - 2020-03-05 08:14:44 --> Utf8 Class Initialized
INFO - 2020-03-05 08:14:44 --> URI Class Initialized
DEBUG - 2020-03-05 08:14:44 --> No URI present. Default controller set.
INFO - 2020-03-05 08:14:44 --> Router Class Initialized
INFO - 2020-03-05 08:14:44 --> Output Class Initialized
INFO - 2020-03-05 08:14:44 --> Security Class Initialized
DEBUG - 2020-03-05 08:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 08:14:44 --> Input Class Initialized
INFO - 2020-03-05 08:14:44 --> Language Class Initialized
INFO - 2020-03-05 08:14:44 --> Loader Class Initialized
INFO - 2020-03-05 08:14:44 --> Helper loaded: url_helper
INFO - 2020-03-05 08:14:44 --> Helper loaded: string_helper
INFO - 2020-03-05 08:14:44 --> Database Driver Class Initialized
DEBUG - 2020-03-05 08:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 08:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 08:14:44 --> Controller Class Initialized
INFO - 2020-03-05 08:14:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 08:14:44 --> Pagination Class Initialized
INFO - 2020-03-05 08:14:44 --> Model "M_show" initialized
INFO - 2020-03-05 08:14:44 --> Helper loaded: form_helper
INFO - 2020-03-05 08:14:44 --> Form Validation Class Initialized
INFO - 2020-03-05 08:14:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 08:14:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 08:14:44 --> Final output sent to browser
DEBUG - 2020-03-05 08:14:44 --> Total execution time: 0.0331
INFO - 2020-03-05 08:23:37 --> Config Class Initialized
INFO - 2020-03-05 08:23:37 --> Hooks Class Initialized
DEBUG - 2020-03-05 08:23:37 --> UTF-8 Support Enabled
INFO - 2020-03-05 08:23:37 --> Utf8 Class Initialized
INFO - 2020-03-05 08:23:37 --> URI Class Initialized
INFO - 2020-03-05 08:23:37 --> Router Class Initialized
INFO - 2020-03-05 08:23:37 --> Output Class Initialized
INFO - 2020-03-05 08:23:37 --> Security Class Initialized
DEBUG - 2020-03-05 08:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 08:23:37 --> Input Class Initialized
INFO - 2020-03-05 08:23:37 --> Language Class Initialized
INFO - 2020-03-05 08:23:37 --> Loader Class Initialized
INFO - 2020-03-05 08:23:37 --> Helper loaded: url_helper
INFO - 2020-03-05 08:23:37 --> Helper loaded: string_helper
INFO - 2020-03-05 08:23:37 --> Database Driver Class Initialized
DEBUG - 2020-03-05 08:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 08:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 08:23:37 --> Controller Class Initialized
INFO - 2020-03-05 08:23:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 08:23:37 --> Pagination Class Initialized
INFO - 2020-03-05 08:23:37 --> Model "M_show" initialized
INFO - 2020-03-05 08:23:37 --> Helper loaded: form_helper
INFO - 2020-03-05 08:23:37 --> Form Validation Class Initialized
INFO - 2020-03-05 08:23:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 08:23:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 08:23:37 --> Final output sent to browser
DEBUG - 2020-03-05 08:23:37 --> Total execution time: 0.0465
INFO - 2020-03-05 08:34:28 --> Config Class Initialized
INFO - 2020-03-05 08:34:28 --> Hooks Class Initialized
DEBUG - 2020-03-05 08:34:28 --> UTF-8 Support Enabled
INFO - 2020-03-05 08:34:28 --> Utf8 Class Initialized
INFO - 2020-03-05 08:34:28 --> URI Class Initialized
DEBUG - 2020-03-05 08:34:28 --> No URI present. Default controller set.
INFO - 2020-03-05 08:34:28 --> Router Class Initialized
INFO - 2020-03-05 08:34:28 --> Output Class Initialized
INFO - 2020-03-05 08:34:28 --> Security Class Initialized
DEBUG - 2020-03-05 08:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 08:34:28 --> Input Class Initialized
INFO - 2020-03-05 08:34:28 --> Language Class Initialized
INFO - 2020-03-05 08:34:28 --> Loader Class Initialized
INFO - 2020-03-05 08:34:28 --> Helper loaded: url_helper
INFO - 2020-03-05 08:34:28 --> Helper loaded: string_helper
INFO - 2020-03-05 08:34:28 --> Database Driver Class Initialized
DEBUG - 2020-03-05 08:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 08:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 08:34:29 --> Controller Class Initialized
INFO - 2020-03-05 08:34:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 08:34:29 --> Pagination Class Initialized
INFO - 2020-03-05 08:34:29 --> Model "M_show" initialized
INFO - 2020-03-05 08:34:29 --> Helper loaded: form_helper
INFO - 2020-03-05 08:34:29 --> Form Validation Class Initialized
INFO - 2020-03-05 08:34:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 08:34:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 08:34:29 --> Final output sent to browser
DEBUG - 2020-03-05 08:34:29 --> Total execution time: 0.1412
INFO - 2020-03-05 08:34:42 --> Config Class Initialized
INFO - 2020-03-05 08:34:42 --> Hooks Class Initialized
DEBUG - 2020-03-05 08:34:42 --> UTF-8 Support Enabled
INFO - 2020-03-05 08:34:42 --> Utf8 Class Initialized
INFO - 2020-03-05 08:34:42 --> URI Class Initialized
DEBUG - 2020-03-05 08:34:42 --> No URI present. Default controller set.
INFO - 2020-03-05 08:34:42 --> Router Class Initialized
INFO - 2020-03-05 08:34:42 --> Output Class Initialized
INFO - 2020-03-05 08:34:42 --> Security Class Initialized
DEBUG - 2020-03-05 08:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 08:34:42 --> Input Class Initialized
INFO - 2020-03-05 08:34:42 --> Language Class Initialized
INFO - 2020-03-05 08:34:42 --> Loader Class Initialized
INFO - 2020-03-05 08:34:42 --> Helper loaded: url_helper
INFO - 2020-03-05 08:34:42 --> Helper loaded: string_helper
INFO - 2020-03-05 08:34:42 --> Database Driver Class Initialized
DEBUG - 2020-03-05 08:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 08:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 08:34:42 --> Controller Class Initialized
INFO - 2020-03-05 08:34:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 08:34:42 --> Pagination Class Initialized
INFO - 2020-03-05 08:34:42 --> Model "M_show" initialized
INFO - 2020-03-05 08:34:42 --> Helper loaded: form_helper
INFO - 2020-03-05 08:34:42 --> Form Validation Class Initialized
INFO - 2020-03-05 08:34:42 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 08:34:42 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 08:34:42 --> Final output sent to browser
DEBUG - 2020-03-05 08:34:42 --> Total execution time: 0.0056
INFO - 2020-03-05 08:34:57 --> Config Class Initialized
INFO - 2020-03-05 08:34:57 --> Hooks Class Initialized
DEBUG - 2020-03-05 08:34:57 --> UTF-8 Support Enabled
INFO - 2020-03-05 08:34:57 --> Utf8 Class Initialized
INFO - 2020-03-05 08:34:57 --> URI Class Initialized
INFO - 2020-03-05 08:34:57 --> Router Class Initialized
INFO - 2020-03-05 08:34:57 --> Output Class Initialized
INFO - 2020-03-05 08:34:57 --> Security Class Initialized
DEBUG - 2020-03-05 08:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 08:34:57 --> Input Class Initialized
INFO - 2020-03-05 08:34:57 --> Language Class Initialized
INFO - 2020-03-05 08:34:57 --> Loader Class Initialized
INFO - 2020-03-05 08:34:57 --> Helper loaded: url_helper
INFO - 2020-03-05 08:34:57 --> Helper loaded: string_helper
INFO - 2020-03-05 08:34:57 --> Database Driver Class Initialized
DEBUG - 2020-03-05 08:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 08:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 08:34:57 --> Controller Class Initialized
INFO - 2020-03-05 08:34:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 08:34:57 --> Pagination Class Initialized
INFO - 2020-03-05 08:34:57 --> Model "M_show" initialized
INFO - 2020-03-05 08:34:57 --> Helper loaded: form_helper
INFO - 2020-03-05 08:34:57 --> Form Validation Class Initialized
INFO - 2020-03-05 08:34:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 08:34:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 08:34:57 --> Final output sent to browser
DEBUG - 2020-03-05 08:34:57 --> Total execution time: 0.0102
INFO - 2020-03-05 08:34:58 --> Config Class Initialized
INFO - 2020-03-05 08:34:58 --> Hooks Class Initialized
DEBUG - 2020-03-05 08:34:58 --> UTF-8 Support Enabled
INFO - 2020-03-05 08:34:58 --> Utf8 Class Initialized
INFO - 2020-03-05 08:34:58 --> URI Class Initialized
INFO - 2020-03-05 08:34:58 --> Router Class Initialized
INFO - 2020-03-05 08:34:58 --> Output Class Initialized
INFO - 2020-03-05 08:34:58 --> Security Class Initialized
DEBUG - 2020-03-05 08:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 08:34:58 --> Input Class Initialized
INFO - 2020-03-05 08:34:58 --> Language Class Initialized
ERROR - 2020-03-05 08:34:58 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-05 08:35:00 --> Config Class Initialized
INFO - 2020-03-05 08:35:00 --> Hooks Class Initialized
DEBUG - 2020-03-05 08:35:00 --> UTF-8 Support Enabled
INFO - 2020-03-05 08:35:00 --> Utf8 Class Initialized
INFO - 2020-03-05 08:35:00 --> URI Class Initialized
INFO - 2020-03-05 08:35:00 --> Router Class Initialized
INFO - 2020-03-05 08:35:00 --> Output Class Initialized
INFO - 2020-03-05 08:35:00 --> Security Class Initialized
DEBUG - 2020-03-05 08:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 08:35:00 --> Input Class Initialized
INFO - 2020-03-05 08:35:00 --> Language Class Initialized
INFO - 2020-03-05 08:35:00 --> Loader Class Initialized
INFO - 2020-03-05 08:35:00 --> Helper loaded: url_helper
INFO - 2020-03-05 08:35:00 --> Helper loaded: string_helper
INFO - 2020-03-05 08:35:00 --> Database Driver Class Initialized
DEBUG - 2020-03-05 08:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 08:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 08:35:00 --> Controller Class Initialized
INFO - 2020-03-05 08:35:00 --> Model "M_tiket" initialized
INFO - 2020-03-05 08:35:00 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 08:35:00 --> Model "M_pesan" initialized
INFO - 2020-03-05 08:35:00 --> Helper loaded: form_helper
INFO - 2020-03-05 08:35:00 --> Form Validation Class Initialized
INFO - 2020-03-05 08:35:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 08:35:00 --> Final output sent to browser
DEBUG - 2020-03-05 08:35:00 --> Total execution time: 0.0135
INFO - 2020-03-05 08:35:24 --> Config Class Initialized
INFO - 2020-03-05 08:35:24 --> Hooks Class Initialized
DEBUG - 2020-03-05 08:35:24 --> UTF-8 Support Enabled
INFO - 2020-03-05 08:35:24 --> Utf8 Class Initialized
INFO - 2020-03-05 08:35:24 --> URI Class Initialized
INFO - 2020-03-05 08:35:24 --> Router Class Initialized
INFO - 2020-03-05 08:35:24 --> Output Class Initialized
INFO - 2020-03-05 08:35:24 --> Security Class Initialized
DEBUG - 2020-03-05 08:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 08:35:24 --> Input Class Initialized
INFO - 2020-03-05 08:35:24 --> Language Class Initialized
INFO - 2020-03-05 08:35:24 --> Loader Class Initialized
INFO - 2020-03-05 08:35:24 --> Helper loaded: url_helper
INFO - 2020-03-05 08:35:24 --> Helper loaded: string_helper
INFO - 2020-03-05 08:35:24 --> Database Driver Class Initialized
DEBUG - 2020-03-05 08:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 08:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 08:35:24 --> Controller Class Initialized
INFO - 2020-03-05 08:35:24 --> Model "M_tiket" initialized
INFO - 2020-03-05 08:35:24 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 08:35:24 --> Model "M_pesan" initialized
INFO - 2020-03-05 08:35:24 --> Helper loaded: form_helper
INFO - 2020-03-05 08:35:24 --> Form Validation Class Initialized
INFO - 2020-03-05 08:35:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-05 08:35:24 --> Final output sent to browser
DEBUG - 2020-03-05 08:35:24 --> Total execution time: 0.0244
INFO - 2020-03-05 08:36:48 --> Config Class Initialized
INFO - 2020-03-05 08:36:48 --> Hooks Class Initialized
DEBUG - 2020-03-05 08:36:48 --> UTF-8 Support Enabled
INFO - 2020-03-05 08:36:48 --> Utf8 Class Initialized
INFO - 2020-03-05 08:36:48 --> URI Class Initialized
INFO - 2020-03-05 08:36:48 --> Router Class Initialized
INFO - 2020-03-05 08:36:48 --> Output Class Initialized
INFO - 2020-03-05 08:36:48 --> Security Class Initialized
DEBUG - 2020-03-05 08:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 08:36:48 --> Input Class Initialized
INFO - 2020-03-05 08:36:48 --> Language Class Initialized
INFO - 2020-03-05 08:36:48 --> Loader Class Initialized
INFO - 2020-03-05 08:36:48 --> Helper loaded: url_helper
INFO - 2020-03-05 08:36:48 --> Helper loaded: string_helper
INFO - 2020-03-05 08:36:48 --> Database Driver Class Initialized
DEBUG - 2020-03-05 08:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 08:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 08:36:48 --> Controller Class Initialized
INFO - 2020-03-05 08:36:48 --> Model "M_tiket" initialized
INFO - 2020-03-05 08:36:48 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 08:36:48 --> Model "M_pesan" initialized
INFO - 2020-03-05 08:36:48 --> Helper loaded: form_helper
INFO - 2020-03-05 08:36:48 --> Form Validation Class Initialized
INFO - 2020-03-05 08:36:49 --> Config Class Initialized
INFO - 2020-03-05 08:36:49 --> Hooks Class Initialized
DEBUG - 2020-03-05 08:36:49 --> UTF-8 Support Enabled
INFO - 2020-03-05 08:36:49 --> Utf8 Class Initialized
INFO - 2020-03-05 08:36:49 --> URI Class Initialized
INFO - 2020-03-05 08:36:49 --> Router Class Initialized
INFO - 2020-03-05 08:36:49 --> Output Class Initialized
INFO - 2020-03-05 08:36:49 --> Security Class Initialized
DEBUG - 2020-03-05 08:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 08:36:49 --> Input Class Initialized
INFO - 2020-03-05 08:36:49 --> Language Class Initialized
INFO - 2020-03-05 08:36:49 --> Loader Class Initialized
INFO - 2020-03-05 08:36:49 --> Helper loaded: url_helper
INFO - 2020-03-05 08:36:49 --> Helper loaded: string_helper
INFO - 2020-03-05 08:36:49 --> Database Driver Class Initialized
DEBUG - 2020-03-05 08:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 08:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 08:36:49 --> Controller Class Initialized
INFO - 2020-03-05 08:36:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 08:36:49 --> Pagination Class Initialized
INFO - 2020-03-05 08:36:49 --> Model "M_show" initialized
INFO - 2020-03-05 08:36:49 --> Helper loaded: form_helper
INFO - 2020-03-05 08:36:49 --> Form Validation Class Initialized
INFO - 2020-03-05 08:36:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 08:36:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 08:36:49 --> Final output sent to browser
DEBUG - 2020-03-05 08:36:49 --> Total execution time: 0.0079
INFO - 2020-03-05 08:36:50 --> Config Class Initialized
INFO - 2020-03-05 08:36:50 --> Hooks Class Initialized
DEBUG - 2020-03-05 08:36:50 --> UTF-8 Support Enabled
INFO - 2020-03-05 08:36:50 --> Utf8 Class Initialized
INFO - 2020-03-05 08:36:50 --> URI Class Initialized
INFO - 2020-03-05 08:36:50 --> Router Class Initialized
INFO - 2020-03-05 08:36:50 --> Output Class Initialized
INFO - 2020-03-05 08:36:50 --> Security Class Initialized
DEBUG - 2020-03-05 08:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 08:36:50 --> Input Class Initialized
INFO - 2020-03-05 08:36:50 --> Language Class Initialized
INFO - 2020-03-05 08:36:50 --> Loader Class Initialized
INFO - 2020-03-05 08:36:50 --> Helper loaded: url_helper
INFO - 2020-03-05 08:36:50 --> Helper loaded: string_helper
INFO - 2020-03-05 08:36:50 --> Database Driver Class Initialized
DEBUG - 2020-03-05 08:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 08:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 08:36:50 --> Controller Class Initialized
INFO - 2020-03-05 08:36:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 08:36:50 --> Pagination Class Initialized
INFO - 2020-03-05 08:36:50 --> Model "M_show" initialized
INFO - 2020-03-05 08:36:50 --> Helper loaded: form_helper
INFO - 2020-03-05 08:36:50 --> Form Validation Class Initialized
INFO - 2020-03-05 08:36:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 08:36:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 08:36:50 --> Final output sent to browser
DEBUG - 2020-03-05 08:36:50 --> Total execution time: 0.0066
INFO - 2020-03-05 08:36:50 --> Config Class Initialized
INFO - 2020-03-05 08:36:50 --> Hooks Class Initialized
DEBUG - 2020-03-05 08:36:50 --> UTF-8 Support Enabled
INFO - 2020-03-05 08:36:50 --> Utf8 Class Initialized
INFO - 2020-03-05 08:36:50 --> URI Class Initialized
INFO - 2020-03-05 08:36:50 --> Router Class Initialized
INFO - 2020-03-05 08:36:50 --> Output Class Initialized
INFO - 2020-03-05 08:36:50 --> Security Class Initialized
DEBUG - 2020-03-05 08:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 08:36:50 --> Input Class Initialized
INFO - 2020-03-05 08:36:50 --> Language Class Initialized
INFO - 2020-03-05 08:36:50 --> Loader Class Initialized
INFO - 2020-03-05 08:36:50 --> Helper loaded: url_helper
INFO - 2020-03-05 08:36:50 --> Helper loaded: string_helper
INFO - 2020-03-05 08:36:50 --> Database Driver Class Initialized
DEBUG - 2020-03-05 08:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 08:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 08:36:50 --> Controller Class Initialized
INFO - 2020-03-05 08:36:50 --> Model "M_tiket" initialized
INFO - 2020-03-05 08:36:50 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 08:36:50 --> Model "M_pesan" initialized
INFO - 2020-03-05 08:36:50 --> Helper loaded: form_helper
INFO - 2020-03-05 08:36:50 --> Form Validation Class Initialized
DEBUG - 2020-03-05 08:36:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-05 08:36:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-05 15:36:50 --> Final output sent to browser
DEBUG - 2020-03-05 15:36:50 --> Total execution time: 0.1334
INFO - 2020-03-05 08:36:53 --> Config Class Initialized
INFO - 2020-03-05 08:36:53 --> Hooks Class Initialized
DEBUG - 2020-03-05 08:36:53 --> UTF-8 Support Enabled
INFO - 2020-03-05 08:36:53 --> Utf8 Class Initialized
INFO - 2020-03-05 08:36:53 --> URI Class Initialized
INFO - 2020-03-05 08:36:53 --> Router Class Initialized
INFO - 2020-03-05 08:36:53 --> Output Class Initialized
INFO - 2020-03-05 08:36:53 --> Security Class Initialized
DEBUG - 2020-03-05 08:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 08:36:53 --> Input Class Initialized
INFO - 2020-03-05 08:36:53 --> Language Class Initialized
INFO - 2020-03-05 08:36:53 --> Loader Class Initialized
INFO - 2020-03-05 08:36:53 --> Helper loaded: url_helper
INFO - 2020-03-05 08:36:53 --> Helper loaded: string_helper
INFO - 2020-03-05 08:36:53 --> Database Driver Class Initialized
DEBUG - 2020-03-05 08:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 08:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 08:36:53 --> Controller Class Initialized
INFO - 2020-03-05 08:36:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 08:36:53 --> Pagination Class Initialized
INFO - 2020-03-05 08:36:53 --> Model "M_show" initialized
INFO - 2020-03-05 08:36:53 --> Helper loaded: form_helper
INFO - 2020-03-05 08:36:53 --> Form Validation Class Initialized
INFO - 2020-03-05 08:36:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 08:36:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 08:36:53 --> Final output sent to browser
DEBUG - 2020-03-05 08:36:53 --> Total execution time: 0.0055
INFO - 2020-03-05 08:36:54 --> Config Class Initialized
INFO - 2020-03-05 08:36:54 --> Hooks Class Initialized
DEBUG - 2020-03-05 08:36:54 --> UTF-8 Support Enabled
INFO - 2020-03-05 08:36:54 --> Utf8 Class Initialized
INFO - 2020-03-05 08:36:54 --> URI Class Initialized
INFO - 2020-03-05 08:36:54 --> Router Class Initialized
INFO - 2020-03-05 08:36:54 --> Output Class Initialized
INFO - 2020-03-05 08:36:54 --> Security Class Initialized
DEBUG - 2020-03-05 08:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 08:36:54 --> Input Class Initialized
INFO - 2020-03-05 08:36:54 --> Language Class Initialized
ERROR - 2020-03-05 08:36:54 --> 404 Page Not Found: Engine0/jquery.js
INFO - 2020-03-05 08:39:05 --> Config Class Initialized
INFO - 2020-03-05 08:39:05 --> Hooks Class Initialized
DEBUG - 2020-03-05 08:39:05 --> UTF-8 Support Enabled
INFO - 2020-03-05 08:39:05 --> Utf8 Class Initialized
INFO - 2020-03-05 08:39:05 --> URI Class Initialized
INFO - 2020-03-05 08:39:05 --> Router Class Initialized
INFO - 2020-03-05 08:39:05 --> Output Class Initialized
INFO - 2020-03-05 08:39:05 --> Security Class Initialized
DEBUG - 2020-03-05 08:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 08:39:05 --> Input Class Initialized
INFO - 2020-03-05 08:39:05 --> Language Class Initialized
INFO - 2020-03-05 08:39:05 --> Loader Class Initialized
INFO - 2020-03-05 08:39:05 --> Helper loaded: url_helper
INFO - 2020-03-05 08:39:05 --> Helper loaded: string_helper
INFO - 2020-03-05 08:39:05 --> Database Driver Class Initialized
DEBUG - 2020-03-05 08:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 08:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 08:39:05 --> Controller Class Initialized
INFO - 2020-03-05 08:39:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 08:39:05 --> Pagination Class Initialized
INFO - 2020-03-05 08:39:05 --> Model "M_show" initialized
INFO - 2020-03-05 08:39:05 --> Helper loaded: form_helper
INFO - 2020-03-05 08:39:05 --> Form Validation Class Initialized
INFO - 2020-03-05 08:39:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 08:39:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/gal.php
INFO - 2020-03-05 08:39:05 --> Final output sent to browser
DEBUG - 2020-03-05 08:39:05 --> Total execution time: 0.0546
INFO - 2020-03-05 08:39:25 --> Config Class Initialized
INFO - 2020-03-05 08:39:25 --> Hooks Class Initialized
DEBUG - 2020-03-05 08:39:25 --> UTF-8 Support Enabled
INFO - 2020-03-05 08:39:25 --> Utf8 Class Initialized
INFO - 2020-03-05 08:39:25 --> URI Class Initialized
INFO - 2020-03-05 08:39:25 --> Router Class Initialized
INFO - 2020-03-05 08:39:25 --> Output Class Initialized
INFO - 2020-03-05 08:39:25 --> Security Class Initialized
DEBUG - 2020-03-05 08:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 08:39:25 --> Input Class Initialized
INFO - 2020-03-05 08:39:25 --> Language Class Initialized
INFO - 2020-03-05 08:39:25 --> Loader Class Initialized
INFO - 2020-03-05 08:39:25 --> Helper loaded: url_helper
INFO - 2020-03-05 08:39:25 --> Helper loaded: string_helper
INFO - 2020-03-05 08:39:25 --> Database Driver Class Initialized
DEBUG - 2020-03-05 08:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 08:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 08:39:25 --> Controller Class Initialized
INFO - 2020-03-05 08:39:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 08:39:25 --> Pagination Class Initialized
INFO - 2020-03-05 08:39:25 --> Model "M_show" initialized
INFO - 2020-03-05 08:39:25 --> Helper loaded: form_helper
INFO - 2020-03-05 08:39:25 --> Form Validation Class Initialized
INFO - 2020-03-05 08:39:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 08:39:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 08:39:25 --> Final output sent to browser
DEBUG - 2020-03-05 08:39:25 --> Total execution time: 0.0058
INFO - 2020-03-05 08:39:51 --> Config Class Initialized
INFO - 2020-03-05 08:39:51 --> Hooks Class Initialized
DEBUG - 2020-03-05 08:39:51 --> UTF-8 Support Enabled
INFO - 2020-03-05 08:39:51 --> Utf8 Class Initialized
INFO - 2020-03-05 08:39:51 --> URI Class Initialized
INFO - 2020-03-05 08:39:51 --> Router Class Initialized
INFO - 2020-03-05 08:39:51 --> Output Class Initialized
INFO - 2020-03-05 08:39:51 --> Security Class Initialized
DEBUG - 2020-03-05 08:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 08:39:51 --> Input Class Initialized
INFO - 2020-03-05 08:39:51 --> Language Class Initialized
INFO - 2020-03-05 08:39:51 --> Loader Class Initialized
INFO - 2020-03-05 08:39:51 --> Helper loaded: url_helper
INFO - 2020-03-05 08:39:51 --> Helper loaded: string_helper
INFO - 2020-03-05 08:39:51 --> Database Driver Class Initialized
DEBUG - 2020-03-05 08:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 08:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 08:39:51 --> Controller Class Initialized
INFO - 2020-03-05 08:39:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 08:39:51 --> Pagination Class Initialized
INFO - 2020-03-05 08:39:51 --> Model "M_show" initialized
INFO - 2020-03-05 08:39:51 --> Helper loaded: form_helper
INFO - 2020-03-05 08:39:51 --> Form Validation Class Initialized
INFO - 2020-03-05 08:39:51 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 08:39:51 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-05 08:39:51 --> Final output sent to browser
DEBUG - 2020-03-05 08:39:51 --> Total execution time: 0.0065
INFO - 2020-03-05 08:40:00 --> Config Class Initialized
INFO - 2020-03-05 08:40:00 --> Hooks Class Initialized
DEBUG - 2020-03-05 08:40:00 --> UTF-8 Support Enabled
INFO - 2020-03-05 08:40:00 --> Utf8 Class Initialized
INFO - 2020-03-05 08:40:00 --> URI Class Initialized
INFO - 2020-03-05 08:40:00 --> Router Class Initialized
INFO - 2020-03-05 08:40:00 --> Output Class Initialized
INFO - 2020-03-05 08:40:00 --> Security Class Initialized
DEBUG - 2020-03-05 08:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 08:40:00 --> Input Class Initialized
INFO - 2020-03-05 08:40:00 --> Language Class Initialized
INFO - 2020-03-05 08:40:00 --> Loader Class Initialized
INFO - 2020-03-05 08:40:00 --> Helper loaded: url_helper
INFO - 2020-03-05 08:40:00 --> Helper loaded: string_helper
INFO - 2020-03-05 08:40:00 --> Database Driver Class Initialized
DEBUG - 2020-03-05 08:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 08:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 08:40:00 --> Controller Class Initialized
INFO - 2020-03-05 08:40:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 08:40:00 --> Pagination Class Initialized
INFO - 2020-03-05 08:40:00 --> Model "M_show" initialized
INFO - 2020-03-05 08:40:00 --> Helper loaded: form_helper
INFO - 2020-03-05 08:40:00 --> Form Validation Class Initialized
INFO - 2020-03-05 08:40:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 08:40:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-05 08:40:00 --> Final output sent to browser
DEBUG - 2020-03-05 08:40:00 --> Total execution time: 0.0132
INFO - 2020-03-05 08:40:28 --> Config Class Initialized
INFO - 2020-03-05 08:40:28 --> Hooks Class Initialized
DEBUG - 2020-03-05 08:40:28 --> UTF-8 Support Enabled
INFO - 2020-03-05 08:40:28 --> Utf8 Class Initialized
INFO - 2020-03-05 08:40:28 --> URI Class Initialized
INFO - 2020-03-05 08:40:28 --> Router Class Initialized
INFO - 2020-03-05 08:40:28 --> Output Class Initialized
INFO - 2020-03-05 08:40:28 --> Security Class Initialized
DEBUG - 2020-03-05 08:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 08:40:28 --> Input Class Initialized
INFO - 2020-03-05 08:40:28 --> Language Class Initialized
INFO - 2020-03-05 08:40:28 --> Loader Class Initialized
INFO - 2020-03-05 08:40:28 --> Helper loaded: url_helper
INFO - 2020-03-05 08:40:28 --> Helper loaded: string_helper
INFO - 2020-03-05 08:40:28 --> Database Driver Class Initialized
DEBUG - 2020-03-05 08:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 08:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 08:40:28 --> Controller Class Initialized
INFO - 2020-03-05 08:40:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 08:40:28 --> Pagination Class Initialized
INFO - 2020-03-05 08:40:28 --> Model "M_show" initialized
INFO - 2020-03-05 08:40:28 --> Helper loaded: form_helper
INFO - 2020-03-05 08:40:28 --> Form Validation Class Initialized
INFO - 2020-03-05 08:40:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 08:40:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-05 08:40:28 --> Final output sent to browser
DEBUG - 2020-03-05 08:40:28 --> Total execution time: 0.0057
INFO - 2020-03-05 08:43:14 --> Config Class Initialized
INFO - 2020-03-05 08:43:14 --> Hooks Class Initialized
DEBUG - 2020-03-05 08:43:14 --> UTF-8 Support Enabled
INFO - 2020-03-05 08:43:14 --> Utf8 Class Initialized
INFO - 2020-03-05 08:43:14 --> URI Class Initialized
DEBUG - 2020-03-05 08:43:14 --> No URI present. Default controller set.
INFO - 2020-03-05 08:43:14 --> Router Class Initialized
INFO - 2020-03-05 08:43:14 --> Output Class Initialized
INFO - 2020-03-05 08:43:14 --> Security Class Initialized
DEBUG - 2020-03-05 08:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 08:43:14 --> Input Class Initialized
INFO - 2020-03-05 08:43:14 --> Language Class Initialized
INFO - 2020-03-05 08:43:14 --> Loader Class Initialized
INFO - 2020-03-05 08:43:14 --> Helper loaded: url_helper
INFO - 2020-03-05 08:43:14 --> Helper loaded: string_helper
INFO - 2020-03-05 08:43:14 --> Database Driver Class Initialized
DEBUG - 2020-03-05 08:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 08:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 08:43:14 --> Controller Class Initialized
INFO - 2020-03-05 08:43:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 08:43:14 --> Pagination Class Initialized
INFO - 2020-03-05 08:43:14 --> Model "M_show" initialized
INFO - 2020-03-05 08:43:14 --> Helper loaded: form_helper
INFO - 2020-03-05 08:43:14 --> Form Validation Class Initialized
INFO - 2020-03-05 08:43:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 08:43:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 08:43:14 --> Final output sent to browser
DEBUG - 2020-03-05 08:43:14 --> Total execution time: 0.0433
INFO - 2020-03-05 08:46:40 --> Config Class Initialized
INFO - 2020-03-05 08:46:40 --> Hooks Class Initialized
DEBUG - 2020-03-05 08:46:40 --> UTF-8 Support Enabled
INFO - 2020-03-05 08:46:40 --> Utf8 Class Initialized
INFO - 2020-03-05 08:46:40 --> URI Class Initialized
INFO - 2020-03-05 08:46:40 --> Router Class Initialized
INFO - 2020-03-05 08:46:40 --> Output Class Initialized
INFO - 2020-03-05 08:46:40 --> Security Class Initialized
DEBUG - 2020-03-05 08:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 08:46:40 --> Input Class Initialized
INFO - 2020-03-05 08:46:40 --> Language Class Initialized
INFO - 2020-03-05 08:46:40 --> Loader Class Initialized
INFO - 2020-03-05 08:46:40 --> Helper loaded: url_helper
INFO - 2020-03-05 08:46:40 --> Helper loaded: string_helper
INFO - 2020-03-05 08:46:40 --> Database Driver Class Initialized
DEBUG - 2020-03-05 08:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 08:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 08:46:40 --> Controller Class Initialized
INFO - 2020-03-05 08:46:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 08:46:40 --> Pagination Class Initialized
INFO - 2020-03-05 08:46:40 --> Model "M_show" initialized
INFO - 2020-03-05 08:46:40 --> Helper loaded: form_helper
INFO - 2020-03-05 08:46:40 --> Form Validation Class Initialized
INFO - 2020-03-05 08:46:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 08:46:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 08:46:40 --> Final output sent to browser
DEBUG - 2020-03-05 08:46:40 --> Total execution time: 0.0328
INFO - 2020-03-05 08:46:45 --> Config Class Initialized
INFO - 2020-03-05 08:46:45 --> Hooks Class Initialized
DEBUG - 2020-03-05 08:46:45 --> UTF-8 Support Enabled
INFO - 2020-03-05 08:46:45 --> Utf8 Class Initialized
INFO - 2020-03-05 08:46:45 --> URI Class Initialized
INFO - 2020-03-05 08:46:45 --> Router Class Initialized
INFO - 2020-03-05 08:46:45 --> Output Class Initialized
INFO - 2020-03-05 08:46:45 --> Security Class Initialized
DEBUG - 2020-03-05 08:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 08:46:45 --> Input Class Initialized
INFO - 2020-03-05 08:46:45 --> Language Class Initialized
INFO - 2020-03-05 08:46:45 --> Loader Class Initialized
INFO - 2020-03-05 08:46:45 --> Helper loaded: url_helper
INFO - 2020-03-05 08:46:45 --> Helper loaded: string_helper
INFO - 2020-03-05 08:46:45 --> Database Driver Class Initialized
DEBUG - 2020-03-05 08:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 08:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 08:46:45 --> Controller Class Initialized
INFO - 2020-03-05 08:46:45 --> Model "M_tiket" initialized
INFO - 2020-03-05 08:46:45 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 08:46:45 --> Model "M_pesan" initialized
INFO - 2020-03-05 08:46:45 --> Helper loaded: form_helper
INFO - 2020-03-05 08:46:45 --> Form Validation Class Initialized
INFO - 2020-03-05 08:46:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-05 08:46:45 --> Final output sent to browser
DEBUG - 2020-03-05 08:46:45 --> Total execution time: 0.2161
INFO - 2020-03-05 08:46:51 --> Config Class Initialized
INFO - 2020-03-05 08:46:51 --> Hooks Class Initialized
DEBUG - 2020-03-05 08:46:51 --> UTF-8 Support Enabled
INFO - 2020-03-05 08:46:51 --> Utf8 Class Initialized
INFO - 2020-03-05 08:46:51 --> URI Class Initialized
INFO - 2020-03-05 08:46:51 --> Router Class Initialized
INFO - 2020-03-05 08:46:51 --> Output Class Initialized
INFO - 2020-03-05 08:46:51 --> Security Class Initialized
DEBUG - 2020-03-05 08:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 08:46:51 --> Input Class Initialized
INFO - 2020-03-05 08:46:51 --> Language Class Initialized
INFO - 2020-03-05 08:46:51 --> Loader Class Initialized
INFO - 2020-03-05 08:46:51 --> Helper loaded: url_helper
INFO - 2020-03-05 08:46:51 --> Helper loaded: string_helper
INFO - 2020-03-05 08:46:51 --> Database Driver Class Initialized
DEBUG - 2020-03-05 08:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 08:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 08:46:52 --> Controller Class Initialized
INFO - 2020-03-05 08:46:52 --> Model "M_tiket" initialized
INFO - 2020-03-05 08:46:52 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 08:46:52 --> Model "M_pesan" initialized
INFO - 2020-03-05 08:46:52 --> Helper loaded: form_helper
INFO - 2020-03-05 08:46:52 --> Form Validation Class Initialized
INFO - 2020-03-05 08:46:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-05 08:46:52 --> Final output sent to browser
DEBUG - 2020-03-05 08:46:52 --> Total execution time: 0.6869
INFO - 2020-03-05 08:47:01 --> Config Class Initialized
INFO - 2020-03-05 08:47:01 --> Hooks Class Initialized
DEBUG - 2020-03-05 08:47:01 --> UTF-8 Support Enabled
INFO - 2020-03-05 08:47:01 --> Utf8 Class Initialized
INFO - 2020-03-05 08:47:01 --> URI Class Initialized
INFO - 2020-03-05 08:47:01 --> Router Class Initialized
INFO - 2020-03-05 08:47:01 --> Output Class Initialized
INFO - 2020-03-05 08:47:01 --> Security Class Initialized
DEBUG - 2020-03-05 08:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 08:47:01 --> Input Class Initialized
INFO - 2020-03-05 08:47:01 --> Language Class Initialized
INFO - 2020-03-05 08:47:01 --> Loader Class Initialized
INFO - 2020-03-05 08:47:01 --> Helper loaded: url_helper
INFO - 2020-03-05 08:47:01 --> Helper loaded: string_helper
INFO - 2020-03-05 08:47:01 --> Database Driver Class Initialized
DEBUG - 2020-03-05 08:47:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 08:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 08:47:01 --> Controller Class Initialized
INFO - 2020-03-05 08:47:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 08:47:01 --> Pagination Class Initialized
INFO - 2020-03-05 08:47:01 --> Model "M_show" initialized
INFO - 2020-03-05 08:47:01 --> Helper loaded: form_helper
INFO - 2020-03-05 08:47:01 --> Form Validation Class Initialized
INFO - 2020-03-05 08:47:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 08:47:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 08:47:01 --> Final output sent to browser
DEBUG - 2020-03-05 08:47:01 --> Total execution time: 0.0131
INFO - 2020-03-05 08:49:04 --> Config Class Initialized
INFO - 2020-03-05 08:49:04 --> Hooks Class Initialized
DEBUG - 2020-03-05 08:49:04 --> UTF-8 Support Enabled
INFO - 2020-03-05 08:49:04 --> Utf8 Class Initialized
INFO - 2020-03-05 08:49:04 --> URI Class Initialized
INFO - 2020-03-05 08:49:04 --> Router Class Initialized
INFO - 2020-03-05 08:49:04 --> Output Class Initialized
INFO - 2020-03-05 08:49:04 --> Security Class Initialized
DEBUG - 2020-03-05 08:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 08:49:04 --> Input Class Initialized
INFO - 2020-03-05 08:49:04 --> Language Class Initialized
INFO - 2020-03-05 08:49:04 --> Loader Class Initialized
INFO - 2020-03-05 08:49:04 --> Helper loaded: url_helper
INFO - 2020-03-05 08:49:04 --> Helper loaded: string_helper
INFO - 2020-03-05 08:49:04 --> Database Driver Class Initialized
DEBUG - 2020-03-05 08:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 08:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 08:49:04 --> Controller Class Initialized
INFO - 2020-03-05 08:49:04 --> Model "M_tiket" initialized
INFO - 2020-03-05 08:49:04 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 08:49:04 --> Model "M_pesan" initialized
INFO - 2020-03-05 08:49:04 --> Helper loaded: form_helper
INFO - 2020-03-05 08:49:04 --> Form Validation Class Initialized
INFO - 2020-03-05 15:49:04 --> Upload Class Initialized
INFO - 2020-03-05 08:49:05 --> Config Class Initialized
INFO - 2020-03-05 08:49:05 --> Hooks Class Initialized
DEBUG - 2020-03-05 08:49:05 --> UTF-8 Support Enabled
INFO - 2020-03-05 08:49:05 --> Utf8 Class Initialized
INFO - 2020-03-05 08:49:05 --> URI Class Initialized
INFO - 2020-03-05 08:49:05 --> Router Class Initialized
INFO - 2020-03-05 08:49:05 --> Output Class Initialized
INFO - 2020-03-05 08:49:05 --> Security Class Initialized
DEBUG - 2020-03-05 08:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 08:49:05 --> Input Class Initialized
INFO - 2020-03-05 08:49:05 --> Language Class Initialized
INFO - 2020-03-05 08:49:05 --> Loader Class Initialized
INFO - 2020-03-05 08:49:05 --> Helper loaded: url_helper
INFO - 2020-03-05 08:49:05 --> Helper loaded: string_helper
INFO - 2020-03-05 08:49:05 --> Database Driver Class Initialized
DEBUG - 2020-03-05 08:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 08:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 08:49:05 --> Controller Class Initialized
INFO - 2020-03-05 08:49:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 08:49:05 --> Pagination Class Initialized
INFO - 2020-03-05 08:49:05 --> Model "M_show" initialized
INFO - 2020-03-05 08:49:05 --> Helper loaded: form_helper
INFO - 2020-03-05 08:49:05 --> Form Validation Class Initialized
INFO - 2020-03-05 08:49:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 08:49:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 08:49:05 --> Final output sent to browser
DEBUG - 2020-03-05 08:49:05 --> Total execution time: 0.3292
INFO - 2020-03-05 08:49:06 --> Config Class Initialized
INFO - 2020-03-05 08:49:06 --> Hooks Class Initialized
DEBUG - 2020-03-05 08:49:06 --> UTF-8 Support Enabled
INFO - 2020-03-05 08:49:06 --> Utf8 Class Initialized
INFO - 2020-03-05 08:49:06 --> URI Class Initialized
INFO - 2020-03-05 08:49:06 --> Router Class Initialized
INFO - 2020-03-05 08:49:06 --> Output Class Initialized
INFO - 2020-03-05 08:49:06 --> Security Class Initialized
DEBUG - 2020-03-05 08:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 08:49:06 --> Input Class Initialized
INFO - 2020-03-05 08:49:06 --> Language Class Initialized
ERROR - 2020-03-05 08:49:06 --> 404 Page Not Found: Engine0/jquery.js
INFO - 2020-03-05 08:57:58 --> Config Class Initialized
INFO - 2020-03-05 08:57:58 --> Hooks Class Initialized
DEBUG - 2020-03-05 08:57:58 --> UTF-8 Support Enabled
INFO - 2020-03-05 08:57:58 --> Utf8 Class Initialized
INFO - 2020-03-05 08:57:58 --> URI Class Initialized
DEBUG - 2020-03-05 08:57:58 --> No URI present. Default controller set.
INFO - 2020-03-05 08:57:58 --> Router Class Initialized
INFO - 2020-03-05 08:57:58 --> Output Class Initialized
INFO - 2020-03-05 08:57:58 --> Security Class Initialized
DEBUG - 2020-03-05 08:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 08:57:58 --> Input Class Initialized
INFO - 2020-03-05 08:57:58 --> Language Class Initialized
INFO - 2020-03-05 08:57:58 --> Loader Class Initialized
INFO - 2020-03-05 08:57:58 --> Helper loaded: url_helper
INFO - 2020-03-05 08:57:58 --> Helper loaded: string_helper
INFO - 2020-03-05 08:57:58 --> Database Driver Class Initialized
DEBUG - 2020-03-05 08:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 08:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 08:57:58 --> Controller Class Initialized
INFO - 2020-03-05 08:57:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 08:57:58 --> Pagination Class Initialized
INFO - 2020-03-05 08:57:58 --> Model "M_show" initialized
INFO - 2020-03-05 08:57:58 --> Helper loaded: form_helper
INFO - 2020-03-05 08:57:58 --> Form Validation Class Initialized
INFO - 2020-03-05 08:57:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 08:57:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 08:57:58 --> Final output sent to browser
DEBUG - 2020-03-05 08:57:58 --> Total execution time: 0.2817
INFO - 2020-03-05 08:58:12 --> Config Class Initialized
INFO - 2020-03-05 08:58:12 --> Hooks Class Initialized
DEBUG - 2020-03-05 08:58:12 --> UTF-8 Support Enabled
INFO - 2020-03-05 08:58:12 --> Utf8 Class Initialized
INFO - 2020-03-05 08:58:12 --> URI Class Initialized
INFO - 2020-03-05 08:58:12 --> Router Class Initialized
INFO - 2020-03-05 08:58:12 --> Output Class Initialized
INFO - 2020-03-05 08:58:12 --> Security Class Initialized
DEBUG - 2020-03-05 08:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 08:58:12 --> Input Class Initialized
INFO - 2020-03-05 08:58:12 --> Language Class Initialized
INFO - 2020-03-05 08:58:12 --> Loader Class Initialized
INFO - 2020-03-05 08:58:12 --> Helper loaded: url_helper
INFO - 2020-03-05 08:58:12 --> Helper loaded: string_helper
INFO - 2020-03-05 08:58:12 --> Database Driver Class Initialized
DEBUG - 2020-03-05 08:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 08:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 08:58:12 --> Controller Class Initialized
INFO - 2020-03-05 08:58:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 08:58:12 --> Pagination Class Initialized
INFO - 2020-03-05 08:58:12 --> Model "M_show" initialized
INFO - 2020-03-05 08:58:12 --> Helper loaded: form_helper
INFO - 2020-03-05 08:58:12 --> Form Validation Class Initialized
INFO - 2020-03-05 08:58:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 08:58:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 08:58:12 --> Final output sent to browser
DEBUG - 2020-03-05 08:58:12 --> Total execution time: 0.0086
INFO - 2020-03-05 08:58:18 --> Config Class Initialized
INFO - 2020-03-05 08:58:18 --> Hooks Class Initialized
DEBUG - 2020-03-05 08:58:18 --> UTF-8 Support Enabled
INFO - 2020-03-05 08:58:18 --> Utf8 Class Initialized
INFO - 2020-03-05 08:58:18 --> URI Class Initialized
INFO - 2020-03-05 08:58:18 --> Router Class Initialized
INFO - 2020-03-05 08:58:18 --> Output Class Initialized
INFO - 2020-03-05 08:58:18 --> Security Class Initialized
DEBUG - 2020-03-05 08:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 08:58:18 --> Input Class Initialized
INFO - 2020-03-05 08:58:18 --> Language Class Initialized
INFO - 2020-03-05 08:58:18 --> Loader Class Initialized
INFO - 2020-03-05 08:58:18 --> Helper loaded: url_helper
INFO - 2020-03-05 08:58:18 --> Helper loaded: string_helper
INFO - 2020-03-05 08:58:18 --> Database Driver Class Initialized
DEBUG - 2020-03-05 08:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 08:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 08:58:18 --> Controller Class Initialized
INFO - 2020-03-05 08:58:18 --> Model "M_tiket" initialized
INFO - 2020-03-05 08:58:18 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 08:58:18 --> Model "M_pesan" initialized
INFO - 2020-03-05 08:58:18 --> Helper loaded: form_helper
INFO - 2020-03-05 08:58:18 --> Form Validation Class Initialized
INFO - 2020-03-05 08:58:18 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 08:58:18 --> Final output sent to browser
DEBUG - 2020-03-05 08:58:18 --> Total execution time: 0.0124
INFO - 2020-03-05 08:58:34 --> Config Class Initialized
INFO - 2020-03-05 08:58:34 --> Hooks Class Initialized
DEBUG - 2020-03-05 08:58:34 --> UTF-8 Support Enabled
INFO - 2020-03-05 08:58:34 --> Utf8 Class Initialized
INFO - 2020-03-05 08:58:34 --> URI Class Initialized
INFO - 2020-03-05 08:58:34 --> Router Class Initialized
INFO - 2020-03-05 08:58:34 --> Output Class Initialized
INFO - 2020-03-05 08:58:34 --> Security Class Initialized
DEBUG - 2020-03-05 08:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 08:58:34 --> Input Class Initialized
INFO - 2020-03-05 08:58:34 --> Language Class Initialized
INFO - 2020-03-05 08:58:34 --> Loader Class Initialized
INFO - 2020-03-05 08:58:34 --> Helper loaded: url_helper
INFO - 2020-03-05 08:58:34 --> Helper loaded: string_helper
INFO - 2020-03-05 08:58:34 --> Database Driver Class Initialized
DEBUG - 2020-03-05 08:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 08:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 08:58:34 --> Controller Class Initialized
INFO - 2020-03-05 08:58:34 --> Model "M_tiket" initialized
INFO - 2020-03-05 08:58:34 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 08:58:34 --> Model "M_pesan" initialized
INFO - 2020-03-05 08:58:34 --> Helper loaded: form_helper
INFO - 2020-03-05 08:58:34 --> Form Validation Class Initialized
INFO - 2020-03-05 08:58:34 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-05 08:58:34 --> Final output sent to browser
DEBUG - 2020-03-05 08:58:34 --> Total execution time: 0.0082
INFO - 2020-03-05 08:58:36 --> Config Class Initialized
INFO - 2020-03-05 08:58:36 --> Hooks Class Initialized
DEBUG - 2020-03-05 08:58:36 --> UTF-8 Support Enabled
INFO - 2020-03-05 08:58:36 --> Utf8 Class Initialized
INFO - 2020-03-05 08:58:36 --> URI Class Initialized
DEBUG - 2020-03-05 08:58:36 --> No URI present. Default controller set.
INFO - 2020-03-05 08:58:36 --> Router Class Initialized
INFO - 2020-03-05 08:58:36 --> Output Class Initialized
INFO - 2020-03-05 08:58:36 --> Security Class Initialized
DEBUG - 2020-03-05 08:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 08:58:36 --> Input Class Initialized
INFO - 2020-03-05 08:58:36 --> Language Class Initialized
INFO - 2020-03-05 08:58:36 --> Loader Class Initialized
INFO - 2020-03-05 08:58:36 --> Helper loaded: url_helper
INFO - 2020-03-05 08:58:36 --> Helper loaded: string_helper
INFO - 2020-03-05 08:58:36 --> Database Driver Class Initialized
DEBUG - 2020-03-05 08:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 08:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 08:58:36 --> Controller Class Initialized
INFO - 2020-03-05 08:58:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 08:58:36 --> Pagination Class Initialized
INFO - 2020-03-05 08:58:36 --> Model "M_show" initialized
INFO - 2020-03-05 08:58:36 --> Helper loaded: form_helper
INFO - 2020-03-05 08:58:36 --> Form Validation Class Initialized
INFO - 2020-03-05 08:58:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 08:58:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 08:58:36 --> Final output sent to browser
DEBUG - 2020-03-05 08:58:36 --> Total execution time: 0.0058
INFO - 2020-03-05 09:00:41 --> Config Class Initialized
INFO - 2020-03-05 09:00:41 --> Hooks Class Initialized
DEBUG - 2020-03-05 09:00:41 --> UTF-8 Support Enabled
INFO - 2020-03-05 09:00:41 --> Utf8 Class Initialized
INFO - 2020-03-05 09:00:41 --> URI Class Initialized
INFO - 2020-03-05 09:00:41 --> Router Class Initialized
INFO - 2020-03-05 09:00:41 --> Output Class Initialized
INFO - 2020-03-05 09:00:41 --> Security Class Initialized
DEBUG - 2020-03-05 09:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 09:00:41 --> Input Class Initialized
INFO - 2020-03-05 09:00:41 --> Language Class Initialized
INFO - 2020-03-05 09:00:41 --> Loader Class Initialized
INFO - 2020-03-05 09:00:41 --> Helper loaded: url_helper
INFO - 2020-03-05 09:00:41 --> Helper loaded: string_helper
INFO - 2020-03-05 09:00:41 --> Database Driver Class Initialized
DEBUG - 2020-03-05 09:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 09:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 09:00:41 --> Controller Class Initialized
INFO - 2020-03-05 09:00:41 --> Model "M_tiket" initialized
INFO - 2020-03-05 09:00:41 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 09:00:41 --> Model "M_pesan" initialized
INFO - 2020-03-05 09:00:41 --> Helper loaded: form_helper
INFO - 2020-03-05 09:00:41 --> Form Validation Class Initialized
DEBUG - 2020-03-05 09:00:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-05 09:00:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-05 16:00:41 --> Final output sent to browser
DEBUG - 2020-03-05 16:00:41 --> Total execution time: 0.1590
INFO - 2020-03-05 09:00:59 --> Config Class Initialized
INFO - 2020-03-05 09:00:59 --> Hooks Class Initialized
DEBUG - 2020-03-05 09:00:59 --> UTF-8 Support Enabled
INFO - 2020-03-05 09:00:59 --> Utf8 Class Initialized
INFO - 2020-03-05 09:00:59 --> URI Class Initialized
INFO - 2020-03-05 09:00:59 --> Router Class Initialized
INFO - 2020-03-05 09:00:59 --> Output Class Initialized
INFO - 2020-03-05 09:00:59 --> Security Class Initialized
DEBUG - 2020-03-05 09:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 09:00:59 --> Input Class Initialized
INFO - 2020-03-05 09:00:59 --> Language Class Initialized
INFO - 2020-03-05 09:00:59 --> Loader Class Initialized
INFO - 2020-03-05 09:00:59 --> Helper loaded: url_helper
INFO - 2020-03-05 09:00:59 --> Helper loaded: string_helper
INFO - 2020-03-05 09:00:59 --> Database Driver Class Initialized
DEBUG - 2020-03-05 09:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 09:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 09:00:59 --> Controller Class Initialized
INFO - 2020-03-05 09:00:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 09:00:59 --> Pagination Class Initialized
INFO - 2020-03-05 09:00:59 --> Model "M_show" initialized
INFO - 2020-03-05 09:00:59 --> Helper loaded: form_helper
INFO - 2020-03-05 09:00:59 --> Form Validation Class Initialized
INFO - 2020-03-05 09:00:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 09:00:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 09:00:59 --> Final output sent to browser
DEBUG - 2020-03-05 09:00:59 --> Total execution time: 0.0083
INFO - 2020-03-05 09:01:04 --> Config Class Initialized
INFO - 2020-03-05 09:01:04 --> Hooks Class Initialized
DEBUG - 2020-03-05 09:01:04 --> UTF-8 Support Enabled
INFO - 2020-03-05 09:01:04 --> Utf8 Class Initialized
INFO - 2020-03-05 09:01:04 --> URI Class Initialized
INFO - 2020-03-05 09:01:04 --> Router Class Initialized
INFO - 2020-03-05 09:01:04 --> Output Class Initialized
INFO - 2020-03-05 09:01:04 --> Security Class Initialized
DEBUG - 2020-03-05 09:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 09:01:04 --> Input Class Initialized
INFO - 2020-03-05 09:01:04 --> Language Class Initialized
INFO - 2020-03-05 09:01:04 --> Loader Class Initialized
INFO - 2020-03-05 09:01:04 --> Helper loaded: url_helper
INFO - 2020-03-05 09:01:04 --> Helper loaded: string_helper
INFO - 2020-03-05 09:01:04 --> Database Driver Class Initialized
DEBUG - 2020-03-05 09:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 09:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 09:01:04 --> Controller Class Initialized
INFO - 2020-03-05 09:01:04 --> Model "M_tiket" initialized
INFO - 2020-03-05 09:01:04 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 09:01:04 --> Model "M_pesan" initialized
INFO - 2020-03-05 09:01:04 --> Helper loaded: form_helper
INFO - 2020-03-05 09:01:04 --> Form Validation Class Initialized
INFO - 2020-03-05 09:01:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-05 09:01:04 --> Final output sent to browser
DEBUG - 2020-03-05 09:01:04 --> Total execution time: 0.0108
INFO - 2020-03-05 09:01:04 --> Config Class Initialized
INFO - 2020-03-05 09:01:04 --> Hooks Class Initialized
DEBUG - 2020-03-05 09:01:04 --> UTF-8 Support Enabled
INFO - 2020-03-05 09:01:04 --> Utf8 Class Initialized
INFO - 2020-03-05 09:01:04 --> URI Class Initialized
INFO - 2020-03-05 09:01:04 --> Router Class Initialized
INFO - 2020-03-05 09:01:04 --> Output Class Initialized
INFO - 2020-03-05 09:01:04 --> Security Class Initialized
DEBUG - 2020-03-05 09:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 09:01:04 --> Input Class Initialized
INFO - 2020-03-05 09:01:04 --> Language Class Initialized
INFO - 2020-03-05 09:01:04 --> Loader Class Initialized
INFO - 2020-03-05 09:01:04 --> Helper loaded: url_helper
INFO - 2020-03-05 09:01:04 --> Helper loaded: string_helper
INFO - 2020-03-05 09:01:04 --> Database Driver Class Initialized
DEBUG - 2020-03-05 09:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 09:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 09:01:04 --> Controller Class Initialized
INFO - 2020-03-05 09:01:04 --> Model "M_tiket" initialized
INFO - 2020-03-05 09:01:04 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 09:01:04 --> Model "M_pesan" initialized
INFO - 2020-03-05 09:01:04 --> Helper loaded: form_helper
INFO - 2020-03-05 09:01:04 --> Form Validation Class Initialized
INFO - 2020-03-05 09:01:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 09:01:04 --> Final output sent to browser
DEBUG - 2020-03-05 09:01:04 --> Total execution time: 0.0095
INFO - 2020-03-05 09:01:04 --> Config Class Initialized
INFO - 2020-03-05 09:01:04 --> Hooks Class Initialized
DEBUG - 2020-03-05 09:01:04 --> UTF-8 Support Enabled
INFO - 2020-03-05 09:01:04 --> Utf8 Class Initialized
INFO - 2020-03-05 09:01:04 --> URI Class Initialized
INFO - 2020-03-05 09:01:04 --> Router Class Initialized
INFO - 2020-03-05 09:01:04 --> Output Class Initialized
INFO - 2020-03-05 09:01:04 --> Security Class Initialized
DEBUG - 2020-03-05 09:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 09:01:04 --> Input Class Initialized
INFO - 2020-03-05 09:01:04 --> Language Class Initialized
INFO - 2020-03-05 09:01:04 --> Loader Class Initialized
INFO - 2020-03-05 09:01:04 --> Helper loaded: url_helper
INFO - 2020-03-05 09:01:04 --> Helper loaded: string_helper
INFO - 2020-03-05 09:01:04 --> Database Driver Class Initialized
DEBUG - 2020-03-05 09:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 09:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 09:01:04 --> Controller Class Initialized
INFO - 2020-03-05 09:01:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 09:01:04 --> Pagination Class Initialized
INFO - 2020-03-05 09:01:04 --> Model "M_show" initialized
INFO - 2020-03-05 09:01:04 --> Helper loaded: form_helper
INFO - 2020-03-05 09:01:04 --> Form Validation Class Initialized
INFO - 2020-03-05 09:01:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 09:01:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 09:01:04 --> Final output sent to browser
DEBUG - 2020-03-05 09:01:04 --> Total execution time: 0.0072
INFO - 2020-03-05 09:01:04 --> Config Class Initialized
INFO - 2020-03-05 09:01:04 --> Hooks Class Initialized
DEBUG - 2020-03-05 09:01:04 --> UTF-8 Support Enabled
INFO - 2020-03-05 09:01:04 --> Utf8 Class Initialized
INFO - 2020-03-05 09:01:04 --> URI Class Initialized
DEBUG - 2020-03-05 09:01:04 --> No URI present. Default controller set.
INFO - 2020-03-05 09:01:04 --> Router Class Initialized
INFO - 2020-03-05 09:01:04 --> Output Class Initialized
INFO - 2020-03-05 09:01:04 --> Security Class Initialized
DEBUG - 2020-03-05 09:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 09:01:04 --> Input Class Initialized
INFO - 2020-03-05 09:01:04 --> Language Class Initialized
INFO - 2020-03-05 09:01:04 --> Loader Class Initialized
INFO - 2020-03-05 09:01:04 --> Helper loaded: url_helper
INFO - 2020-03-05 09:01:04 --> Helper loaded: string_helper
INFO - 2020-03-05 09:01:04 --> Database Driver Class Initialized
DEBUG - 2020-03-05 09:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 09:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 09:01:04 --> Controller Class Initialized
INFO - 2020-03-05 09:01:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 09:01:04 --> Pagination Class Initialized
INFO - 2020-03-05 09:01:04 --> Model "M_show" initialized
INFO - 2020-03-05 09:01:04 --> Helper loaded: form_helper
INFO - 2020-03-05 09:01:04 --> Form Validation Class Initialized
INFO - 2020-03-05 09:01:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 09:01:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 09:01:04 --> Final output sent to browser
DEBUG - 2020-03-05 09:01:04 --> Total execution time: 0.0042
INFO - 2020-03-05 09:38:10 --> Config Class Initialized
INFO - 2020-03-05 09:38:10 --> Hooks Class Initialized
DEBUG - 2020-03-05 09:38:10 --> UTF-8 Support Enabled
INFO - 2020-03-05 09:38:10 --> Utf8 Class Initialized
INFO - 2020-03-05 09:38:10 --> URI Class Initialized
DEBUG - 2020-03-05 09:38:10 --> No URI present. Default controller set.
INFO - 2020-03-05 09:38:10 --> Router Class Initialized
INFO - 2020-03-05 09:38:10 --> Output Class Initialized
INFO - 2020-03-05 09:38:10 --> Security Class Initialized
DEBUG - 2020-03-05 09:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 09:38:10 --> Input Class Initialized
INFO - 2020-03-05 09:38:10 --> Language Class Initialized
INFO - 2020-03-05 09:38:10 --> Loader Class Initialized
INFO - 2020-03-05 09:38:10 --> Helper loaded: url_helper
INFO - 2020-03-05 09:38:10 --> Helper loaded: string_helper
INFO - 2020-03-05 09:38:10 --> Database Driver Class Initialized
DEBUG - 2020-03-05 09:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 09:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 09:38:10 --> Controller Class Initialized
INFO - 2020-03-05 09:38:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 09:38:10 --> Pagination Class Initialized
INFO - 2020-03-05 09:38:10 --> Model "M_show" initialized
INFO - 2020-03-05 09:38:10 --> Helper loaded: form_helper
INFO - 2020-03-05 09:38:10 --> Form Validation Class Initialized
INFO - 2020-03-05 09:38:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 09:38:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 09:38:10 --> Final output sent to browser
DEBUG - 2020-03-05 09:38:10 --> Total execution time: 0.0300
INFO - 2020-03-05 09:38:10 --> Config Class Initialized
INFO - 2020-03-05 09:38:10 --> Hooks Class Initialized
DEBUG - 2020-03-05 09:38:10 --> UTF-8 Support Enabled
INFO - 2020-03-05 09:38:10 --> Utf8 Class Initialized
INFO - 2020-03-05 09:38:10 --> URI Class Initialized
DEBUG - 2020-03-05 09:38:10 --> No URI present. Default controller set.
INFO - 2020-03-05 09:38:10 --> Router Class Initialized
INFO - 2020-03-05 09:38:10 --> Output Class Initialized
INFO - 2020-03-05 09:38:10 --> Security Class Initialized
DEBUG - 2020-03-05 09:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 09:38:10 --> Input Class Initialized
INFO - 2020-03-05 09:38:10 --> Language Class Initialized
INFO - 2020-03-05 09:38:10 --> Loader Class Initialized
INFO - 2020-03-05 09:38:10 --> Helper loaded: url_helper
INFO - 2020-03-05 09:38:10 --> Helper loaded: string_helper
INFO - 2020-03-05 09:38:10 --> Database Driver Class Initialized
DEBUG - 2020-03-05 09:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 09:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 09:38:10 --> Controller Class Initialized
INFO - 2020-03-05 09:38:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 09:38:10 --> Pagination Class Initialized
INFO - 2020-03-05 09:38:10 --> Model "M_show" initialized
INFO - 2020-03-05 09:38:10 --> Helper loaded: form_helper
INFO - 2020-03-05 09:38:10 --> Form Validation Class Initialized
INFO - 2020-03-05 09:38:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 09:38:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 09:38:10 --> Final output sent to browser
DEBUG - 2020-03-05 09:38:10 --> Total execution time: 0.0040
INFO - 2020-03-05 09:46:21 --> Config Class Initialized
INFO - 2020-03-05 09:46:21 --> Hooks Class Initialized
DEBUG - 2020-03-05 09:46:21 --> UTF-8 Support Enabled
INFO - 2020-03-05 09:46:21 --> Utf8 Class Initialized
INFO - 2020-03-05 09:46:21 --> URI Class Initialized
INFO - 2020-03-05 09:46:21 --> Router Class Initialized
INFO - 2020-03-05 09:46:21 --> Output Class Initialized
INFO - 2020-03-05 09:46:21 --> Security Class Initialized
DEBUG - 2020-03-05 09:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 09:46:21 --> Input Class Initialized
INFO - 2020-03-05 09:46:21 --> Language Class Initialized
INFO - 2020-03-05 09:46:21 --> Loader Class Initialized
INFO - 2020-03-05 09:46:21 --> Helper loaded: url_helper
INFO - 2020-03-05 09:46:21 --> Helper loaded: string_helper
INFO - 2020-03-05 09:46:21 --> Database Driver Class Initialized
DEBUG - 2020-03-05 09:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 09:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 09:46:21 --> Controller Class Initialized
INFO - 2020-03-05 09:46:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 09:46:21 --> Pagination Class Initialized
INFO - 2020-03-05 09:46:21 --> Model "M_show" initialized
INFO - 2020-03-05 09:46:21 --> Helper loaded: form_helper
INFO - 2020-03-05 09:46:21 --> Form Validation Class Initialized
INFO - 2020-03-05 09:46:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 09:46:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 09:46:21 --> Final output sent to browser
DEBUG - 2020-03-05 09:46:21 --> Total execution time: 0.0605
INFO - 2020-03-05 09:53:51 --> Config Class Initialized
INFO - 2020-03-05 09:53:51 --> Hooks Class Initialized
DEBUG - 2020-03-05 09:53:51 --> UTF-8 Support Enabled
INFO - 2020-03-05 09:53:51 --> Utf8 Class Initialized
INFO - 2020-03-05 09:53:51 --> URI Class Initialized
INFO - 2020-03-05 09:53:51 --> Router Class Initialized
INFO - 2020-03-05 09:53:51 --> Output Class Initialized
INFO - 2020-03-05 09:53:51 --> Security Class Initialized
DEBUG - 2020-03-05 09:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 09:53:51 --> Input Class Initialized
INFO - 2020-03-05 09:53:51 --> Language Class Initialized
INFO - 2020-03-05 09:53:51 --> Loader Class Initialized
INFO - 2020-03-05 09:53:51 --> Helper loaded: url_helper
INFO - 2020-03-05 09:53:51 --> Helper loaded: string_helper
INFO - 2020-03-05 09:53:51 --> Database Driver Class Initialized
DEBUG - 2020-03-05 09:53:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 09:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 09:53:51 --> Controller Class Initialized
INFO - 2020-03-05 09:53:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 09:53:51 --> Pagination Class Initialized
INFO - 2020-03-05 09:53:51 --> Model "M_show" initialized
INFO - 2020-03-05 09:53:51 --> Helper loaded: form_helper
INFO - 2020-03-05 09:53:51 --> Form Validation Class Initialized
INFO - 2020-03-05 09:53:51 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 09:53:51 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 09:53:51 --> Final output sent to browser
DEBUG - 2020-03-05 09:53:51 --> Total execution time: 0.0325
INFO - 2020-03-05 09:57:20 --> Config Class Initialized
INFO - 2020-03-05 09:57:20 --> Hooks Class Initialized
DEBUG - 2020-03-05 09:57:20 --> UTF-8 Support Enabled
INFO - 2020-03-05 09:57:20 --> Utf8 Class Initialized
INFO - 2020-03-05 09:57:20 --> URI Class Initialized
DEBUG - 2020-03-05 09:57:20 --> No URI present. Default controller set.
INFO - 2020-03-05 09:57:20 --> Router Class Initialized
INFO - 2020-03-05 09:57:20 --> Output Class Initialized
INFO - 2020-03-05 09:57:20 --> Security Class Initialized
DEBUG - 2020-03-05 09:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 09:57:20 --> Input Class Initialized
INFO - 2020-03-05 09:57:20 --> Language Class Initialized
INFO - 2020-03-05 09:57:20 --> Loader Class Initialized
INFO - 2020-03-05 09:57:20 --> Helper loaded: url_helper
INFO - 2020-03-05 09:57:20 --> Helper loaded: string_helper
INFO - 2020-03-05 09:57:20 --> Database Driver Class Initialized
DEBUG - 2020-03-05 09:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 09:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 09:57:20 --> Controller Class Initialized
INFO - 2020-03-05 09:57:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 09:57:20 --> Pagination Class Initialized
INFO - 2020-03-05 09:57:20 --> Model "M_show" initialized
INFO - 2020-03-05 09:57:20 --> Helper loaded: form_helper
INFO - 2020-03-05 09:57:20 --> Form Validation Class Initialized
INFO - 2020-03-05 09:57:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 09:57:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 09:57:20 --> Final output sent to browser
DEBUG - 2020-03-05 09:57:20 --> Total execution time: 0.0464
INFO - 2020-03-05 09:57:29 --> Config Class Initialized
INFO - 2020-03-05 09:57:29 --> Hooks Class Initialized
DEBUG - 2020-03-05 09:57:29 --> UTF-8 Support Enabled
INFO - 2020-03-05 09:57:29 --> Utf8 Class Initialized
INFO - 2020-03-05 09:57:29 --> URI Class Initialized
INFO - 2020-03-05 09:57:29 --> Router Class Initialized
INFO - 2020-03-05 09:57:29 --> Output Class Initialized
INFO - 2020-03-05 09:57:29 --> Security Class Initialized
DEBUG - 2020-03-05 09:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 09:57:29 --> Input Class Initialized
INFO - 2020-03-05 09:57:29 --> Language Class Initialized
INFO - 2020-03-05 09:57:29 --> Loader Class Initialized
INFO - 2020-03-05 09:57:29 --> Helper loaded: url_helper
INFO - 2020-03-05 09:57:29 --> Helper loaded: string_helper
INFO - 2020-03-05 09:57:29 --> Database Driver Class Initialized
DEBUG - 2020-03-05 09:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 09:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 09:57:29 --> Controller Class Initialized
INFO - 2020-03-05 09:57:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 09:57:29 --> Pagination Class Initialized
INFO - 2020-03-05 09:57:29 --> Model "M_show" initialized
INFO - 2020-03-05 09:57:29 --> Helper loaded: form_helper
INFO - 2020-03-05 09:57:29 --> Form Validation Class Initialized
INFO - 2020-03-05 09:57:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 09:57:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 09:57:29 --> Final output sent to browser
DEBUG - 2020-03-05 09:57:29 --> Total execution time: 0.0759
INFO - 2020-03-05 09:57:33 --> Config Class Initialized
INFO - 2020-03-05 09:57:33 --> Hooks Class Initialized
DEBUG - 2020-03-05 09:57:33 --> UTF-8 Support Enabled
INFO - 2020-03-05 09:57:33 --> Utf8 Class Initialized
INFO - 2020-03-05 09:57:33 --> URI Class Initialized
INFO - 2020-03-05 09:57:33 --> Router Class Initialized
INFO - 2020-03-05 09:57:33 --> Output Class Initialized
INFO - 2020-03-05 09:57:33 --> Security Class Initialized
DEBUG - 2020-03-05 09:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 09:57:33 --> Input Class Initialized
INFO - 2020-03-05 09:57:33 --> Language Class Initialized
INFO - 2020-03-05 09:57:33 --> Loader Class Initialized
INFO - 2020-03-05 09:57:33 --> Helper loaded: url_helper
INFO - 2020-03-05 09:57:33 --> Helper loaded: string_helper
INFO - 2020-03-05 09:57:33 --> Database Driver Class Initialized
DEBUG - 2020-03-05 09:57:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 09:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 09:57:33 --> Controller Class Initialized
INFO - 2020-03-05 09:57:33 --> Model "M_tiket" initialized
INFO - 2020-03-05 09:57:33 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 09:57:33 --> Model "M_pesan" initialized
INFO - 2020-03-05 09:57:33 --> Helper loaded: form_helper
INFO - 2020-03-05 09:57:33 --> Form Validation Class Initialized
INFO - 2020-03-05 09:57:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 09:57:33 --> Final output sent to browser
DEBUG - 2020-03-05 09:57:33 --> Total execution time: 0.0437
INFO - 2020-03-05 09:59:56 --> Config Class Initialized
INFO - 2020-03-05 09:59:56 --> Hooks Class Initialized
DEBUG - 2020-03-05 09:59:56 --> UTF-8 Support Enabled
INFO - 2020-03-05 09:59:56 --> Utf8 Class Initialized
INFO - 2020-03-05 09:59:56 --> URI Class Initialized
INFO - 2020-03-05 09:59:56 --> Router Class Initialized
INFO - 2020-03-05 09:59:56 --> Output Class Initialized
INFO - 2020-03-05 09:59:56 --> Security Class Initialized
DEBUG - 2020-03-05 09:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 09:59:56 --> Input Class Initialized
INFO - 2020-03-05 09:59:56 --> Language Class Initialized
INFO - 2020-03-05 09:59:56 --> Loader Class Initialized
INFO - 2020-03-05 09:59:56 --> Helper loaded: url_helper
INFO - 2020-03-05 09:59:56 --> Helper loaded: string_helper
INFO - 2020-03-05 09:59:56 --> Database Driver Class Initialized
DEBUG - 2020-03-05 09:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 09:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 09:59:57 --> Controller Class Initialized
INFO - 2020-03-05 09:59:57 --> Model "M_tiket" initialized
INFO - 2020-03-05 09:59:57 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 09:59:57 --> Model "M_pesan" initialized
INFO - 2020-03-05 09:59:57 --> Helper loaded: form_helper
INFO - 2020-03-05 09:59:57 --> Form Validation Class Initialized
INFO - 2020-03-05 09:59:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-05 09:59:57 --> Final output sent to browser
DEBUG - 2020-03-05 09:59:57 --> Total execution time: 0.1384
INFO - 2020-03-05 10:28:20 --> Config Class Initialized
INFO - 2020-03-05 10:28:20 --> Hooks Class Initialized
DEBUG - 2020-03-05 10:28:20 --> UTF-8 Support Enabled
INFO - 2020-03-05 10:28:20 --> Utf8 Class Initialized
INFO - 2020-03-05 10:28:20 --> URI Class Initialized
DEBUG - 2020-03-05 10:28:20 --> No URI present. Default controller set.
INFO - 2020-03-05 10:28:20 --> Router Class Initialized
INFO - 2020-03-05 10:28:20 --> Output Class Initialized
INFO - 2020-03-05 10:28:20 --> Security Class Initialized
DEBUG - 2020-03-05 10:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 10:28:20 --> Input Class Initialized
INFO - 2020-03-05 10:28:20 --> Language Class Initialized
INFO - 2020-03-05 10:28:20 --> Loader Class Initialized
INFO - 2020-03-05 10:28:20 --> Helper loaded: url_helper
INFO - 2020-03-05 10:28:20 --> Helper loaded: string_helper
INFO - 2020-03-05 10:28:20 --> Database Driver Class Initialized
DEBUG - 2020-03-05 10:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 10:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 10:28:20 --> Controller Class Initialized
INFO - 2020-03-05 10:28:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 10:28:20 --> Pagination Class Initialized
INFO - 2020-03-05 10:28:20 --> Model "M_show" initialized
INFO - 2020-03-05 10:28:20 --> Helper loaded: form_helper
INFO - 2020-03-05 10:28:20 --> Form Validation Class Initialized
INFO - 2020-03-05 10:28:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 10:28:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 10:28:20 --> Final output sent to browser
DEBUG - 2020-03-05 10:28:20 --> Total execution time: 0.0905
INFO - 2020-03-05 10:28:21 --> Config Class Initialized
INFO - 2020-03-05 10:28:21 --> Hooks Class Initialized
DEBUG - 2020-03-05 10:28:21 --> UTF-8 Support Enabled
INFO - 2020-03-05 10:28:21 --> Utf8 Class Initialized
INFO - 2020-03-05 10:28:21 --> URI Class Initialized
DEBUG - 2020-03-05 10:28:21 --> No URI present. Default controller set.
INFO - 2020-03-05 10:28:21 --> Router Class Initialized
INFO - 2020-03-05 10:28:21 --> Output Class Initialized
INFO - 2020-03-05 10:28:21 --> Security Class Initialized
DEBUG - 2020-03-05 10:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 10:28:21 --> Input Class Initialized
INFO - 2020-03-05 10:28:21 --> Language Class Initialized
INFO - 2020-03-05 10:28:21 --> Loader Class Initialized
INFO - 2020-03-05 10:28:21 --> Helper loaded: url_helper
INFO - 2020-03-05 10:28:21 --> Helper loaded: string_helper
INFO - 2020-03-05 10:28:21 --> Database Driver Class Initialized
DEBUG - 2020-03-05 10:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 10:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 10:28:21 --> Controller Class Initialized
INFO - 2020-03-05 10:28:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 10:28:21 --> Pagination Class Initialized
INFO - 2020-03-05 10:28:21 --> Model "M_show" initialized
INFO - 2020-03-05 10:28:21 --> Helper loaded: form_helper
INFO - 2020-03-05 10:28:21 --> Form Validation Class Initialized
INFO - 2020-03-05 10:28:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 10:28:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 10:28:21 --> Final output sent to browser
DEBUG - 2020-03-05 10:28:21 --> Total execution time: 0.0051
INFO - 2020-03-05 10:58:37 --> Config Class Initialized
INFO - 2020-03-05 10:58:37 --> Hooks Class Initialized
DEBUG - 2020-03-05 10:58:37 --> UTF-8 Support Enabled
INFO - 2020-03-05 10:58:37 --> Utf8 Class Initialized
INFO - 2020-03-05 10:58:37 --> URI Class Initialized
INFO - 2020-03-05 10:58:37 --> Router Class Initialized
INFO - 2020-03-05 10:58:37 --> Output Class Initialized
INFO - 2020-03-05 10:58:37 --> Security Class Initialized
DEBUG - 2020-03-05 10:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 10:58:37 --> Input Class Initialized
INFO - 2020-03-05 10:58:37 --> Language Class Initialized
INFO - 2020-03-05 10:58:37 --> Loader Class Initialized
INFO - 2020-03-05 10:58:37 --> Helper loaded: url_helper
INFO - 2020-03-05 10:58:37 --> Helper loaded: string_helper
INFO - 2020-03-05 10:58:37 --> Database Driver Class Initialized
DEBUG - 2020-03-05 10:58:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 10:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 10:58:37 --> Controller Class Initialized
INFO - 2020-03-05 10:58:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 10:58:37 --> Pagination Class Initialized
INFO - 2020-03-05 10:58:37 --> Model "M_show" initialized
INFO - 2020-03-05 10:58:37 --> Helper loaded: form_helper
INFO - 2020-03-05 10:58:37 --> Form Validation Class Initialized
INFO - 2020-03-05 10:58:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 10:58:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 10:58:37 --> Final output sent to browser
DEBUG - 2020-03-05 10:58:37 --> Total execution time: 0.1161
INFO - 2020-03-05 11:31:46 --> Config Class Initialized
INFO - 2020-03-05 11:31:46 --> Hooks Class Initialized
DEBUG - 2020-03-05 11:31:46 --> UTF-8 Support Enabled
INFO - 2020-03-05 11:31:46 --> Utf8 Class Initialized
INFO - 2020-03-05 11:31:46 --> URI Class Initialized
INFO - 2020-03-05 11:31:46 --> Router Class Initialized
INFO - 2020-03-05 11:31:46 --> Output Class Initialized
INFO - 2020-03-05 11:31:46 --> Security Class Initialized
DEBUG - 2020-03-05 11:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 11:31:46 --> Input Class Initialized
INFO - 2020-03-05 11:31:46 --> Language Class Initialized
INFO - 2020-03-05 11:31:46 --> Loader Class Initialized
INFO - 2020-03-05 11:31:46 --> Helper loaded: url_helper
INFO - 2020-03-05 11:31:46 --> Helper loaded: string_helper
INFO - 2020-03-05 11:31:46 --> Database Driver Class Initialized
DEBUG - 2020-03-05 11:31:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 11:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 11:31:46 --> Controller Class Initialized
INFO - 2020-03-05 11:31:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 11:31:46 --> Pagination Class Initialized
INFO - 2020-03-05 11:31:46 --> Model "M_show" initialized
INFO - 2020-03-05 11:31:46 --> Helper loaded: form_helper
INFO - 2020-03-05 11:31:46 --> Form Validation Class Initialized
INFO - 2020-03-05 11:31:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 11:31:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 11:31:46 --> Final output sent to browser
DEBUG - 2020-03-05 11:31:46 --> Total execution time: 0.0527
INFO - 2020-03-05 12:00:23 --> Config Class Initialized
INFO - 2020-03-05 12:00:23 --> Hooks Class Initialized
DEBUG - 2020-03-05 12:00:23 --> UTF-8 Support Enabled
INFO - 2020-03-05 12:00:23 --> Utf8 Class Initialized
INFO - 2020-03-05 12:00:23 --> URI Class Initialized
INFO - 2020-03-05 12:00:23 --> Router Class Initialized
INFO - 2020-03-05 12:00:23 --> Output Class Initialized
INFO - 2020-03-05 12:00:23 --> Security Class Initialized
DEBUG - 2020-03-05 12:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 12:00:23 --> Input Class Initialized
INFO - 2020-03-05 12:00:23 --> Language Class Initialized
INFO - 2020-03-05 12:00:23 --> Loader Class Initialized
INFO - 2020-03-05 12:00:23 --> Helper loaded: url_helper
INFO - 2020-03-05 12:00:23 --> Helper loaded: string_helper
INFO - 2020-03-05 12:00:23 --> Database Driver Class Initialized
DEBUG - 2020-03-05 12:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 12:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 12:00:23 --> Controller Class Initialized
INFO - 2020-03-05 12:00:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 12:00:23 --> Pagination Class Initialized
INFO - 2020-03-05 12:00:23 --> Model "M_show" initialized
INFO - 2020-03-05 12:00:23 --> Helper loaded: form_helper
INFO - 2020-03-05 12:00:23 --> Form Validation Class Initialized
INFO - 2020-03-05 12:00:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 12:00:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 12:00:23 --> Final output sent to browser
DEBUG - 2020-03-05 12:00:23 --> Total execution time: 0.1068
INFO - 2020-03-05 12:17:07 --> Config Class Initialized
INFO - 2020-03-05 12:17:07 --> Hooks Class Initialized
DEBUG - 2020-03-05 12:17:07 --> UTF-8 Support Enabled
INFO - 2020-03-05 12:17:07 --> Utf8 Class Initialized
INFO - 2020-03-05 12:17:07 --> URI Class Initialized
DEBUG - 2020-03-05 12:17:07 --> No URI present. Default controller set.
INFO - 2020-03-05 12:17:07 --> Router Class Initialized
INFO - 2020-03-05 12:17:07 --> Output Class Initialized
INFO - 2020-03-05 12:17:07 --> Security Class Initialized
DEBUG - 2020-03-05 12:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 12:17:07 --> Input Class Initialized
INFO - 2020-03-05 12:17:07 --> Language Class Initialized
INFO - 2020-03-05 12:17:07 --> Loader Class Initialized
INFO - 2020-03-05 12:17:07 --> Helper loaded: url_helper
INFO - 2020-03-05 12:17:07 --> Helper loaded: string_helper
INFO - 2020-03-05 12:17:07 --> Database Driver Class Initialized
DEBUG - 2020-03-05 12:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 12:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 12:17:07 --> Controller Class Initialized
INFO - 2020-03-05 12:17:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 12:17:07 --> Pagination Class Initialized
INFO - 2020-03-05 12:17:07 --> Model "M_show" initialized
INFO - 2020-03-05 12:17:07 --> Helper loaded: form_helper
INFO - 2020-03-05 12:17:07 --> Form Validation Class Initialized
INFO - 2020-03-05 12:17:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 12:17:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 12:17:07 --> Final output sent to browser
DEBUG - 2020-03-05 12:17:07 --> Total execution time: 0.0518
INFO - 2020-03-05 12:20:56 --> Config Class Initialized
INFO - 2020-03-05 12:20:56 --> Hooks Class Initialized
DEBUG - 2020-03-05 12:20:56 --> UTF-8 Support Enabled
INFO - 2020-03-05 12:20:56 --> Utf8 Class Initialized
INFO - 2020-03-05 12:20:56 --> URI Class Initialized
DEBUG - 2020-03-05 12:20:56 --> No URI present. Default controller set.
INFO - 2020-03-05 12:20:56 --> Router Class Initialized
INFO - 2020-03-05 12:20:56 --> Output Class Initialized
INFO - 2020-03-05 12:20:56 --> Security Class Initialized
DEBUG - 2020-03-05 12:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 12:20:56 --> Input Class Initialized
INFO - 2020-03-05 12:20:56 --> Language Class Initialized
INFO - 2020-03-05 12:20:56 --> Loader Class Initialized
INFO - 2020-03-05 12:20:56 --> Helper loaded: url_helper
INFO - 2020-03-05 12:20:56 --> Helper loaded: string_helper
INFO - 2020-03-05 12:20:56 --> Database Driver Class Initialized
DEBUG - 2020-03-05 12:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 12:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 12:20:56 --> Controller Class Initialized
INFO - 2020-03-05 12:20:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 12:20:56 --> Pagination Class Initialized
INFO - 2020-03-05 12:20:56 --> Model "M_show" initialized
INFO - 2020-03-05 12:20:56 --> Helper loaded: form_helper
INFO - 2020-03-05 12:20:56 --> Form Validation Class Initialized
INFO - 2020-03-05 12:20:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 12:20:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 12:20:56 --> Final output sent to browser
DEBUG - 2020-03-05 12:20:56 --> Total execution time: 0.2363
INFO - 2020-03-05 12:21:04 --> Config Class Initialized
INFO - 2020-03-05 12:21:04 --> Hooks Class Initialized
DEBUG - 2020-03-05 12:21:04 --> UTF-8 Support Enabled
INFO - 2020-03-05 12:21:04 --> Utf8 Class Initialized
INFO - 2020-03-05 12:21:04 --> URI Class Initialized
DEBUG - 2020-03-05 12:21:04 --> No URI present. Default controller set.
INFO - 2020-03-05 12:21:04 --> Router Class Initialized
INFO - 2020-03-05 12:21:04 --> Output Class Initialized
INFO - 2020-03-05 12:21:04 --> Security Class Initialized
DEBUG - 2020-03-05 12:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 12:21:04 --> Input Class Initialized
INFO - 2020-03-05 12:21:04 --> Language Class Initialized
INFO - 2020-03-05 12:21:04 --> Loader Class Initialized
INFO - 2020-03-05 12:21:04 --> Helper loaded: url_helper
INFO - 2020-03-05 12:21:04 --> Helper loaded: string_helper
INFO - 2020-03-05 12:21:04 --> Database Driver Class Initialized
DEBUG - 2020-03-05 12:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 12:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 12:21:04 --> Controller Class Initialized
INFO - 2020-03-05 12:21:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 12:21:04 --> Pagination Class Initialized
INFO - 2020-03-05 12:21:04 --> Model "M_show" initialized
INFO - 2020-03-05 12:21:04 --> Helper loaded: form_helper
INFO - 2020-03-05 12:21:04 --> Form Validation Class Initialized
INFO - 2020-03-05 12:21:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 12:21:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 12:21:04 --> Final output sent to browser
DEBUG - 2020-03-05 12:21:04 --> Total execution time: 0.1695
INFO - 2020-03-05 12:24:46 --> Config Class Initialized
INFO - 2020-03-05 12:24:46 --> Hooks Class Initialized
DEBUG - 2020-03-05 12:24:46 --> UTF-8 Support Enabled
INFO - 2020-03-05 12:24:46 --> Utf8 Class Initialized
INFO - 2020-03-05 12:24:46 --> URI Class Initialized
INFO - 2020-03-05 12:24:46 --> Router Class Initialized
INFO - 2020-03-05 12:24:46 --> Output Class Initialized
INFO - 2020-03-05 12:24:46 --> Security Class Initialized
DEBUG - 2020-03-05 12:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 12:24:46 --> Input Class Initialized
INFO - 2020-03-05 12:24:46 --> Language Class Initialized
INFO - 2020-03-05 12:24:46 --> Loader Class Initialized
INFO - 2020-03-05 12:24:46 --> Helper loaded: url_helper
INFO - 2020-03-05 12:24:46 --> Helper loaded: string_helper
INFO - 2020-03-05 12:24:46 --> Database Driver Class Initialized
DEBUG - 2020-03-05 12:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 12:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 12:24:46 --> Controller Class Initialized
INFO - 2020-03-05 12:24:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 12:24:46 --> Pagination Class Initialized
INFO - 2020-03-05 12:24:46 --> Model "M_show" initialized
INFO - 2020-03-05 12:24:46 --> Helper loaded: form_helper
INFO - 2020-03-05 12:24:46 --> Form Validation Class Initialized
INFO - 2020-03-05 12:24:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 12:24:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 12:24:46 --> Final output sent to browser
DEBUG - 2020-03-05 12:24:46 --> Total execution time: 0.0328
INFO - 2020-03-05 12:24:47 --> Config Class Initialized
INFO - 2020-03-05 12:24:47 --> Hooks Class Initialized
DEBUG - 2020-03-05 12:24:47 --> UTF-8 Support Enabled
INFO - 2020-03-05 12:24:47 --> Utf8 Class Initialized
INFO - 2020-03-05 12:24:47 --> URI Class Initialized
INFO - 2020-03-05 12:24:47 --> Router Class Initialized
INFO - 2020-03-05 12:24:47 --> Output Class Initialized
INFO - 2020-03-05 12:24:47 --> Security Class Initialized
DEBUG - 2020-03-05 12:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 12:24:47 --> Input Class Initialized
INFO - 2020-03-05 12:24:47 --> Language Class Initialized
ERROR - 2020-03-05 12:24:47 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-05 12:24:49 --> Config Class Initialized
INFO - 2020-03-05 12:24:49 --> Hooks Class Initialized
DEBUG - 2020-03-05 12:24:49 --> UTF-8 Support Enabled
INFO - 2020-03-05 12:24:49 --> Utf8 Class Initialized
INFO - 2020-03-05 12:24:49 --> URI Class Initialized
INFO - 2020-03-05 12:24:49 --> Router Class Initialized
INFO - 2020-03-05 12:24:49 --> Output Class Initialized
INFO - 2020-03-05 12:24:49 --> Security Class Initialized
DEBUG - 2020-03-05 12:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 12:24:49 --> Input Class Initialized
INFO - 2020-03-05 12:24:49 --> Language Class Initialized
INFO - 2020-03-05 12:24:49 --> Loader Class Initialized
INFO - 2020-03-05 12:24:49 --> Helper loaded: url_helper
INFO - 2020-03-05 12:24:49 --> Helper loaded: string_helper
INFO - 2020-03-05 12:24:49 --> Database Driver Class Initialized
DEBUG - 2020-03-05 12:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 12:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 12:24:49 --> Controller Class Initialized
INFO - 2020-03-05 12:24:49 --> Model "M_tiket" initialized
INFO - 2020-03-05 12:24:49 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 12:24:49 --> Model "M_pesan" initialized
INFO - 2020-03-05 12:24:49 --> Helper loaded: form_helper
INFO - 2020-03-05 12:24:49 --> Form Validation Class Initialized
INFO - 2020-03-05 12:24:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 12:24:49 --> Final output sent to browser
DEBUG - 2020-03-05 12:24:49 --> Total execution time: 0.3331
INFO - 2020-03-05 12:38:43 --> Config Class Initialized
INFO - 2020-03-05 12:38:43 --> Hooks Class Initialized
DEBUG - 2020-03-05 12:38:43 --> UTF-8 Support Enabled
INFO - 2020-03-05 12:38:43 --> Utf8 Class Initialized
INFO - 2020-03-05 12:38:43 --> URI Class Initialized
DEBUG - 2020-03-05 12:38:43 --> No URI present. Default controller set.
INFO - 2020-03-05 12:38:43 --> Router Class Initialized
INFO - 2020-03-05 12:38:43 --> Output Class Initialized
INFO - 2020-03-05 12:38:43 --> Security Class Initialized
DEBUG - 2020-03-05 12:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 12:38:43 --> Input Class Initialized
INFO - 2020-03-05 12:38:43 --> Language Class Initialized
INFO - 2020-03-05 12:38:43 --> Loader Class Initialized
INFO - 2020-03-05 12:38:43 --> Helper loaded: url_helper
INFO - 2020-03-05 12:38:43 --> Helper loaded: string_helper
INFO - 2020-03-05 12:38:43 --> Database Driver Class Initialized
DEBUG - 2020-03-05 12:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 12:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 12:38:43 --> Controller Class Initialized
INFO - 2020-03-05 12:38:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 12:38:43 --> Pagination Class Initialized
INFO - 2020-03-05 12:38:43 --> Model "M_show" initialized
INFO - 2020-03-05 12:38:43 --> Helper loaded: form_helper
INFO - 2020-03-05 12:38:43 --> Form Validation Class Initialized
INFO - 2020-03-05 12:38:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 12:38:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 12:38:43 --> Final output sent to browser
DEBUG - 2020-03-05 12:38:43 --> Total execution time: 0.0839
INFO - 2020-03-05 12:40:12 --> Config Class Initialized
INFO - 2020-03-05 12:40:12 --> Hooks Class Initialized
DEBUG - 2020-03-05 12:40:12 --> UTF-8 Support Enabled
INFO - 2020-03-05 12:40:12 --> Utf8 Class Initialized
INFO - 2020-03-05 12:40:12 --> URI Class Initialized
DEBUG - 2020-03-05 12:40:12 --> No URI present. Default controller set.
INFO - 2020-03-05 12:40:12 --> Router Class Initialized
INFO - 2020-03-05 12:40:12 --> Output Class Initialized
INFO - 2020-03-05 12:40:12 --> Security Class Initialized
DEBUG - 2020-03-05 12:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 12:40:12 --> Input Class Initialized
INFO - 2020-03-05 12:40:12 --> Language Class Initialized
INFO - 2020-03-05 12:40:12 --> Loader Class Initialized
INFO - 2020-03-05 12:40:12 --> Helper loaded: url_helper
INFO - 2020-03-05 12:40:12 --> Helper loaded: string_helper
INFO - 2020-03-05 12:40:12 --> Database Driver Class Initialized
DEBUG - 2020-03-05 12:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 12:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 12:40:12 --> Controller Class Initialized
INFO - 2020-03-05 12:40:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 12:40:12 --> Pagination Class Initialized
INFO - 2020-03-05 12:40:12 --> Model "M_show" initialized
INFO - 2020-03-05 12:40:12 --> Helper loaded: form_helper
INFO - 2020-03-05 12:40:12 --> Form Validation Class Initialized
INFO - 2020-03-05 12:40:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 12:40:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 12:40:12 --> Final output sent to browser
DEBUG - 2020-03-05 12:40:12 --> Total execution time: 0.0436
INFO - 2020-03-05 12:40:36 --> Config Class Initialized
INFO - 2020-03-05 12:40:36 --> Hooks Class Initialized
DEBUG - 2020-03-05 12:40:36 --> UTF-8 Support Enabled
INFO - 2020-03-05 12:40:36 --> Utf8 Class Initialized
INFO - 2020-03-05 12:40:36 --> URI Class Initialized
INFO - 2020-03-05 12:40:36 --> Router Class Initialized
INFO - 2020-03-05 12:40:36 --> Output Class Initialized
INFO - 2020-03-05 12:40:36 --> Security Class Initialized
DEBUG - 2020-03-05 12:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 12:40:36 --> Input Class Initialized
INFO - 2020-03-05 12:40:36 --> Language Class Initialized
INFO - 2020-03-05 12:40:36 --> Loader Class Initialized
INFO - 2020-03-05 12:40:36 --> Helper loaded: url_helper
INFO - 2020-03-05 12:40:36 --> Helper loaded: string_helper
INFO - 2020-03-05 12:40:36 --> Database Driver Class Initialized
DEBUG - 2020-03-05 12:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 12:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 12:40:36 --> Controller Class Initialized
INFO - 2020-03-05 12:40:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 12:40:36 --> Pagination Class Initialized
INFO - 2020-03-05 12:40:36 --> Model "M_show" initialized
INFO - 2020-03-05 12:40:36 --> Helper loaded: form_helper
INFO - 2020-03-05 12:40:36 --> Form Validation Class Initialized
INFO - 2020-03-05 12:40:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 12:40:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 12:40:36 --> Final output sent to browser
DEBUG - 2020-03-05 12:40:36 --> Total execution time: 0.0094
INFO - 2020-03-05 12:40:43 --> Config Class Initialized
INFO - 2020-03-05 12:40:43 --> Hooks Class Initialized
DEBUG - 2020-03-05 12:40:43 --> UTF-8 Support Enabled
INFO - 2020-03-05 12:40:43 --> Utf8 Class Initialized
INFO - 2020-03-05 12:40:43 --> URI Class Initialized
INFO - 2020-03-05 12:40:43 --> Router Class Initialized
INFO - 2020-03-05 12:40:43 --> Output Class Initialized
INFO - 2020-03-05 12:40:43 --> Security Class Initialized
DEBUG - 2020-03-05 12:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 12:40:43 --> Input Class Initialized
INFO - 2020-03-05 12:40:43 --> Language Class Initialized
INFO - 2020-03-05 12:40:43 --> Loader Class Initialized
INFO - 2020-03-05 12:40:43 --> Helper loaded: url_helper
INFO - 2020-03-05 12:40:43 --> Helper loaded: string_helper
INFO - 2020-03-05 12:40:43 --> Database Driver Class Initialized
DEBUG - 2020-03-05 12:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 12:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 12:40:43 --> Controller Class Initialized
INFO - 2020-03-05 12:40:43 --> Model "M_tiket" initialized
INFO - 2020-03-05 12:40:43 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 12:40:43 --> Model "M_pesan" initialized
INFO - 2020-03-05 12:40:43 --> Helper loaded: form_helper
INFO - 2020-03-05 12:40:43 --> Form Validation Class Initialized
INFO - 2020-03-05 12:40:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 12:40:43 --> Final output sent to browser
DEBUG - 2020-03-05 12:40:43 --> Total execution time: 0.0104
INFO - 2020-03-05 12:40:56 --> Config Class Initialized
INFO - 2020-03-05 12:40:56 --> Hooks Class Initialized
DEBUG - 2020-03-05 12:40:56 --> UTF-8 Support Enabled
INFO - 2020-03-05 12:40:56 --> Utf8 Class Initialized
INFO - 2020-03-05 12:40:56 --> URI Class Initialized
INFO - 2020-03-05 12:40:56 --> Router Class Initialized
INFO - 2020-03-05 12:40:56 --> Output Class Initialized
INFO - 2020-03-05 12:40:56 --> Security Class Initialized
DEBUG - 2020-03-05 12:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 12:40:56 --> Input Class Initialized
INFO - 2020-03-05 12:40:56 --> Language Class Initialized
INFO - 2020-03-05 12:40:56 --> Loader Class Initialized
INFO - 2020-03-05 12:40:56 --> Helper loaded: url_helper
INFO - 2020-03-05 12:40:56 --> Helper loaded: string_helper
INFO - 2020-03-05 12:40:56 --> Database Driver Class Initialized
DEBUG - 2020-03-05 12:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 12:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 12:40:56 --> Controller Class Initialized
INFO - 2020-03-05 12:40:56 --> Model "M_tiket" initialized
INFO - 2020-03-05 12:40:56 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 12:40:56 --> Model "M_pesan" initialized
INFO - 2020-03-05 12:40:56 --> Helper loaded: form_helper
INFO - 2020-03-05 12:40:56 --> Form Validation Class Initialized
INFO - 2020-03-05 12:40:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-05 12:40:56 --> Final output sent to browser
DEBUG - 2020-03-05 12:40:56 --> Total execution time: 0.0154
INFO - 2020-03-05 12:42:00 --> Config Class Initialized
INFO - 2020-03-05 12:42:00 --> Hooks Class Initialized
DEBUG - 2020-03-05 12:42:00 --> UTF-8 Support Enabled
INFO - 2020-03-05 12:42:00 --> Utf8 Class Initialized
INFO - 2020-03-05 12:42:00 --> URI Class Initialized
INFO - 2020-03-05 12:42:00 --> Router Class Initialized
INFO - 2020-03-05 12:42:00 --> Output Class Initialized
INFO - 2020-03-05 12:42:00 --> Security Class Initialized
DEBUG - 2020-03-05 12:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 12:42:00 --> Input Class Initialized
INFO - 2020-03-05 12:42:00 --> Language Class Initialized
INFO - 2020-03-05 12:42:00 --> Loader Class Initialized
INFO - 2020-03-05 12:42:00 --> Helper loaded: url_helper
INFO - 2020-03-05 12:42:00 --> Helper loaded: string_helper
INFO - 2020-03-05 12:42:00 --> Database Driver Class Initialized
DEBUG - 2020-03-05 12:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 12:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 12:42:00 --> Controller Class Initialized
INFO - 2020-03-05 12:42:00 --> Model "M_tiket" initialized
INFO - 2020-03-05 12:42:00 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 12:42:00 --> Model "M_pesan" initialized
INFO - 2020-03-05 12:42:00 --> Helper loaded: form_helper
INFO - 2020-03-05 12:42:00 --> Form Validation Class Initialized
INFO - 2020-03-05 12:42:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-05 12:42:00 --> Final output sent to browser
DEBUG - 2020-03-05 12:42:00 --> Total execution time: 0.0120
INFO - 2020-03-05 12:42:03 --> Config Class Initialized
INFO - 2020-03-05 12:42:03 --> Hooks Class Initialized
DEBUG - 2020-03-05 12:42:03 --> UTF-8 Support Enabled
INFO - 2020-03-05 12:42:03 --> Utf8 Class Initialized
INFO - 2020-03-05 12:42:03 --> URI Class Initialized
INFO - 2020-03-05 12:42:03 --> Router Class Initialized
INFO - 2020-03-05 12:42:03 --> Output Class Initialized
INFO - 2020-03-05 12:42:03 --> Security Class Initialized
DEBUG - 2020-03-05 12:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 12:42:03 --> Input Class Initialized
INFO - 2020-03-05 12:42:03 --> Language Class Initialized
INFO - 2020-03-05 12:42:03 --> Loader Class Initialized
INFO - 2020-03-05 12:42:03 --> Helper loaded: url_helper
INFO - 2020-03-05 12:42:03 --> Helper loaded: string_helper
INFO - 2020-03-05 12:42:03 --> Database Driver Class Initialized
DEBUG - 2020-03-05 12:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 12:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 12:42:03 --> Controller Class Initialized
INFO - 2020-03-05 12:42:03 --> Model "M_tiket" initialized
INFO - 2020-03-05 12:42:03 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 12:42:03 --> Model "M_pesan" initialized
INFO - 2020-03-05 12:42:03 --> Helper loaded: form_helper
INFO - 2020-03-05 12:42:03 --> Form Validation Class Initialized
DEBUG - 2020-03-05 12:42:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-05 12:42:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-05 19:42:04 --> Final output sent to browser
DEBUG - 2020-03-05 19:42:04 --> Total execution time: 0.3598
INFO - 2020-03-05 12:42:08 --> Config Class Initialized
INFO - 2020-03-05 12:42:08 --> Hooks Class Initialized
DEBUG - 2020-03-05 12:42:08 --> UTF-8 Support Enabled
INFO - 2020-03-05 12:42:08 --> Utf8 Class Initialized
INFO - 2020-03-05 12:42:08 --> URI Class Initialized
INFO - 2020-03-05 12:42:08 --> Router Class Initialized
INFO - 2020-03-05 12:42:08 --> Output Class Initialized
INFO - 2020-03-05 12:42:08 --> Security Class Initialized
DEBUG - 2020-03-05 12:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 12:42:08 --> Input Class Initialized
INFO - 2020-03-05 12:42:08 --> Language Class Initialized
INFO - 2020-03-05 12:42:08 --> Loader Class Initialized
INFO - 2020-03-05 12:42:08 --> Helper loaded: url_helper
INFO - 2020-03-05 12:42:08 --> Helper loaded: string_helper
INFO - 2020-03-05 12:42:08 --> Database Driver Class Initialized
DEBUG - 2020-03-05 12:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 12:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 12:42:08 --> Controller Class Initialized
INFO - 2020-03-05 12:42:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 12:42:08 --> Pagination Class Initialized
INFO - 2020-03-05 12:42:08 --> Model "M_show" initialized
INFO - 2020-03-05 12:42:08 --> Helper loaded: form_helper
INFO - 2020-03-05 12:42:08 --> Form Validation Class Initialized
INFO - 2020-03-05 12:42:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 12:42:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 12:42:08 --> Final output sent to browser
DEBUG - 2020-03-05 12:42:08 --> Total execution time: 0.0894
INFO - 2020-03-05 12:46:27 --> Config Class Initialized
INFO - 2020-03-05 12:46:27 --> Hooks Class Initialized
DEBUG - 2020-03-05 12:46:27 --> UTF-8 Support Enabled
INFO - 2020-03-05 12:46:27 --> Utf8 Class Initialized
INFO - 2020-03-05 12:46:27 --> URI Class Initialized
DEBUG - 2020-03-05 12:46:27 --> No URI present. Default controller set.
INFO - 2020-03-05 12:46:27 --> Router Class Initialized
INFO - 2020-03-05 12:46:27 --> Output Class Initialized
INFO - 2020-03-05 12:46:27 --> Security Class Initialized
DEBUG - 2020-03-05 12:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 12:46:27 --> Input Class Initialized
INFO - 2020-03-05 12:46:27 --> Language Class Initialized
INFO - 2020-03-05 12:46:28 --> Loader Class Initialized
INFO - 2020-03-05 12:46:28 --> Helper loaded: url_helper
INFO - 2020-03-05 12:46:28 --> Helper loaded: string_helper
INFO - 2020-03-05 12:46:28 --> Database Driver Class Initialized
DEBUG - 2020-03-05 12:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 12:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 12:46:28 --> Controller Class Initialized
INFO - 2020-03-05 12:46:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 12:46:28 --> Pagination Class Initialized
INFO - 2020-03-05 12:46:28 --> Model "M_show" initialized
INFO - 2020-03-05 12:46:28 --> Helper loaded: form_helper
INFO - 2020-03-05 12:46:28 --> Form Validation Class Initialized
INFO - 2020-03-05 12:46:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 12:46:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 12:46:28 --> Final output sent to browser
DEBUG - 2020-03-05 12:46:28 --> Total execution time: 0.0521
INFO - 2020-03-05 12:46:42 --> Config Class Initialized
INFO - 2020-03-05 12:46:42 --> Hooks Class Initialized
DEBUG - 2020-03-05 12:46:42 --> UTF-8 Support Enabled
INFO - 2020-03-05 12:46:42 --> Utf8 Class Initialized
INFO - 2020-03-05 12:46:42 --> URI Class Initialized
INFO - 2020-03-05 12:46:42 --> Router Class Initialized
INFO - 2020-03-05 12:46:42 --> Output Class Initialized
INFO - 2020-03-05 12:46:42 --> Security Class Initialized
DEBUG - 2020-03-05 12:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 12:46:42 --> Input Class Initialized
INFO - 2020-03-05 12:46:42 --> Language Class Initialized
INFO - 2020-03-05 12:46:42 --> Loader Class Initialized
INFO - 2020-03-05 12:46:42 --> Helper loaded: url_helper
INFO - 2020-03-05 12:46:42 --> Helper loaded: string_helper
INFO - 2020-03-05 12:46:42 --> Database Driver Class Initialized
DEBUG - 2020-03-05 12:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 12:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 12:46:42 --> Controller Class Initialized
INFO - 2020-03-05 12:46:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 12:46:42 --> Pagination Class Initialized
INFO - 2020-03-05 12:46:42 --> Model "M_show" initialized
INFO - 2020-03-05 12:46:42 --> Helper loaded: form_helper
INFO - 2020-03-05 12:46:42 --> Form Validation Class Initialized
INFO - 2020-03-05 12:46:42 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 12:46:42 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 12:46:42 --> Final output sent to browser
DEBUG - 2020-03-05 12:46:42 --> Total execution time: 0.0092
INFO - 2020-03-05 12:46:47 --> Config Class Initialized
INFO - 2020-03-05 12:46:47 --> Hooks Class Initialized
DEBUG - 2020-03-05 12:46:47 --> UTF-8 Support Enabled
INFO - 2020-03-05 12:46:47 --> Utf8 Class Initialized
INFO - 2020-03-05 12:46:47 --> URI Class Initialized
INFO - 2020-03-05 12:46:47 --> Router Class Initialized
INFO - 2020-03-05 12:46:47 --> Output Class Initialized
INFO - 2020-03-05 12:46:47 --> Security Class Initialized
DEBUG - 2020-03-05 12:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 12:46:47 --> Input Class Initialized
INFO - 2020-03-05 12:46:47 --> Language Class Initialized
INFO - 2020-03-05 12:46:47 --> Loader Class Initialized
INFO - 2020-03-05 12:46:47 --> Helper loaded: url_helper
INFO - 2020-03-05 12:46:47 --> Helper loaded: string_helper
INFO - 2020-03-05 12:46:47 --> Database Driver Class Initialized
DEBUG - 2020-03-05 12:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 12:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 12:46:47 --> Controller Class Initialized
INFO - 2020-03-05 12:46:47 --> Model "M_tiket" initialized
INFO - 2020-03-05 12:46:47 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 12:46:47 --> Model "M_pesan" initialized
INFO - 2020-03-05 12:46:47 --> Helper loaded: form_helper
INFO - 2020-03-05 12:46:47 --> Form Validation Class Initialized
INFO - 2020-03-05 12:46:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 12:46:47 --> Final output sent to browser
DEBUG - 2020-03-05 12:46:47 --> Total execution time: 0.0113
INFO - 2020-03-05 12:57:43 --> Config Class Initialized
INFO - 2020-03-05 12:57:43 --> Hooks Class Initialized
DEBUG - 2020-03-05 12:57:43 --> UTF-8 Support Enabled
INFO - 2020-03-05 12:57:43 --> Utf8 Class Initialized
INFO - 2020-03-05 12:57:43 --> URI Class Initialized
INFO - 2020-03-05 12:57:43 --> Router Class Initialized
INFO - 2020-03-05 12:57:43 --> Output Class Initialized
INFO - 2020-03-05 12:57:43 --> Security Class Initialized
DEBUG - 2020-03-05 12:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 12:57:43 --> Input Class Initialized
INFO - 2020-03-05 12:57:43 --> Language Class Initialized
INFO - 2020-03-05 12:57:43 --> Loader Class Initialized
INFO - 2020-03-05 12:57:43 --> Helper loaded: url_helper
INFO - 2020-03-05 12:57:43 --> Helper loaded: string_helper
INFO - 2020-03-05 12:57:43 --> Database Driver Class Initialized
DEBUG - 2020-03-05 12:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 12:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 12:57:43 --> Controller Class Initialized
INFO - 2020-03-05 12:57:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 12:57:43 --> Pagination Class Initialized
INFO - 2020-03-05 12:57:43 --> Model "M_show" initialized
INFO - 2020-03-05 12:57:43 --> Helper loaded: form_helper
INFO - 2020-03-05 12:57:43 --> Form Validation Class Initialized
INFO - 2020-03-05 12:57:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 12:57:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 12:57:43 --> Final output sent to browser
DEBUG - 2020-03-05 12:57:43 --> Total execution time: 0.0316
INFO - 2020-03-05 12:57:47 --> Config Class Initialized
INFO - 2020-03-05 12:57:47 --> Hooks Class Initialized
DEBUG - 2020-03-05 12:57:47 --> UTF-8 Support Enabled
INFO - 2020-03-05 12:57:47 --> Utf8 Class Initialized
INFO - 2020-03-05 12:57:47 --> URI Class Initialized
INFO - 2020-03-05 12:57:47 --> Router Class Initialized
INFO - 2020-03-05 12:57:47 --> Output Class Initialized
INFO - 2020-03-05 12:57:47 --> Security Class Initialized
DEBUG - 2020-03-05 12:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 12:57:47 --> Input Class Initialized
INFO - 2020-03-05 12:57:47 --> Language Class Initialized
ERROR - 2020-03-05 12:57:47 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-05 13:24:42 --> Config Class Initialized
INFO - 2020-03-05 13:24:42 --> Hooks Class Initialized
DEBUG - 2020-03-05 13:24:42 --> UTF-8 Support Enabled
INFO - 2020-03-05 13:24:42 --> Utf8 Class Initialized
INFO - 2020-03-05 13:24:42 --> URI Class Initialized
INFO - 2020-03-05 13:24:42 --> Router Class Initialized
INFO - 2020-03-05 13:24:42 --> Output Class Initialized
INFO - 2020-03-05 13:24:42 --> Security Class Initialized
DEBUG - 2020-03-05 13:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 13:24:42 --> Input Class Initialized
INFO - 2020-03-05 13:24:42 --> Language Class Initialized
INFO - 2020-03-05 13:24:42 --> Loader Class Initialized
INFO - 2020-03-05 13:24:42 --> Helper loaded: url_helper
INFO - 2020-03-05 13:24:42 --> Helper loaded: string_helper
INFO - 2020-03-05 13:24:43 --> Database Driver Class Initialized
DEBUG - 2020-03-05 13:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 13:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 13:24:43 --> Controller Class Initialized
INFO - 2020-03-05 13:24:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 13:24:43 --> Pagination Class Initialized
INFO - 2020-03-05 13:24:43 --> Model "M_show" initialized
INFO - 2020-03-05 13:24:43 --> Helper loaded: form_helper
INFO - 2020-03-05 13:24:43 --> Form Validation Class Initialized
INFO - 2020-03-05 13:24:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 13:24:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 13:24:43 --> Final output sent to browser
DEBUG - 2020-03-05 13:24:43 --> Total execution time: 0.0545
INFO - 2020-03-05 13:25:00 --> Config Class Initialized
INFO - 2020-03-05 13:25:00 --> Hooks Class Initialized
DEBUG - 2020-03-05 13:25:00 --> UTF-8 Support Enabled
INFO - 2020-03-05 13:25:00 --> Utf8 Class Initialized
INFO - 2020-03-05 13:25:00 --> URI Class Initialized
INFO - 2020-03-05 13:25:00 --> Router Class Initialized
INFO - 2020-03-05 13:25:00 --> Output Class Initialized
INFO - 2020-03-05 13:25:00 --> Security Class Initialized
DEBUG - 2020-03-05 13:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 13:25:00 --> Input Class Initialized
INFO - 2020-03-05 13:25:00 --> Language Class Initialized
INFO - 2020-03-05 13:25:00 --> Loader Class Initialized
INFO - 2020-03-05 13:25:00 --> Helper loaded: url_helper
INFO - 2020-03-05 13:25:00 --> Helper loaded: string_helper
INFO - 2020-03-05 13:25:00 --> Database Driver Class Initialized
DEBUG - 2020-03-05 13:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 13:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 13:25:00 --> Controller Class Initialized
INFO - 2020-03-05 13:25:00 --> Model "M_tiket" initialized
INFO - 2020-03-05 13:25:00 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 13:25:00 --> Model "M_pesan" initialized
INFO - 2020-03-05 13:25:00 --> Helper loaded: form_helper
INFO - 2020-03-05 13:25:00 --> Form Validation Class Initialized
INFO - 2020-03-05 13:25:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-05 13:25:00 --> Final output sent to browser
DEBUG - 2020-03-05 13:25:00 --> Total execution time: 0.0880
INFO - 2020-03-05 13:26:11 --> Config Class Initialized
INFO - 2020-03-05 13:26:11 --> Hooks Class Initialized
DEBUG - 2020-03-05 13:26:11 --> UTF-8 Support Enabled
INFO - 2020-03-05 13:26:11 --> Utf8 Class Initialized
INFO - 2020-03-05 13:26:11 --> URI Class Initialized
INFO - 2020-03-05 13:26:11 --> Router Class Initialized
INFO - 2020-03-05 13:26:11 --> Output Class Initialized
INFO - 2020-03-05 13:26:11 --> Security Class Initialized
DEBUG - 2020-03-05 13:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 13:26:11 --> Input Class Initialized
INFO - 2020-03-05 13:26:11 --> Language Class Initialized
INFO - 2020-03-05 13:26:11 --> Loader Class Initialized
INFO - 2020-03-05 13:26:11 --> Helper loaded: url_helper
INFO - 2020-03-05 13:26:11 --> Helper loaded: string_helper
INFO - 2020-03-05 13:26:11 --> Database Driver Class Initialized
DEBUG - 2020-03-05 13:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 13:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 13:26:11 --> Controller Class Initialized
INFO - 2020-03-05 13:26:11 --> Model "M_tiket" initialized
INFO - 2020-03-05 13:26:11 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 13:26:11 --> Model "M_pesan" initialized
INFO - 2020-03-05 13:26:11 --> Helper loaded: form_helper
INFO - 2020-03-05 13:26:11 --> Form Validation Class Initialized
INFO - 2020-03-05 13:26:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-05 13:26:11 --> Final output sent to browser
DEBUG - 2020-03-05 13:26:11 --> Total execution time: 0.1097
INFO - 2020-03-05 13:26:35 --> Config Class Initialized
INFO - 2020-03-05 13:26:35 --> Hooks Class Initialized
DEBUG - 2020-03-05 13:26:35 --> UTF-8 Support Enabled
INFO - 2020-03-05 13:26:35 --> Utf8 Class Initialized
INFO - 2020-03-05 13:26:35 --> URI Class Initialized
INFO - 2020-03-05 13:26:35 --> Router Class Initialized
INFO - 2020-03-05 13:26:35 --> Output Class Initialized
INFO - 2020-03-05 13:26:35 --> Security Class Initialized
DEBUG - 2020-03-05 13:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 13:26:35 --> Input Class Initialized
INFO - 2020-03-05 13:26:35 --> Language Class Initialized
INFO - 2020-03-05 13:26:35 --> Loader Class Initialized
INFO - 2020-03-05 13:26:35 --> Helper loaded: url_helper
INFO - 2020-03-05 13:26:35 --> Helper loaded: string_helper
INFO - 2020-03-05 13:26:35 --> Database Driver Class Initialized
DEBUG - 2020-03-05 13:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 13:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 13:26:35 --> Controller Class Initialized
INFO - 2020-03-05 13:26:35 --> Model "M_tiket" initialized
INFO - 2020-03-05 13:26:35 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 13:26:35 --> Model "M_pesan" initialized
INFO - 2020-03-05 13:26:35 --> Helper loaded: form_helper
INFO - 2020-03-05 13:26:35 --> Form Validation Class Initialized
INFO - 2020-03-05 20:26:35 --> Upload Class Initialized
INFO - 2020-03-05 13:26:36 --> Config Class Initialized
INFO - 2020-03-05 13:26:36 --> Hooks Class Initialized
DEBUG - 2020-03-05 13:26:36 --> UTF-8 Support Enabled
INFO - 2020-03-05 13:26:36 --> Utf8 Class Initialized
INFO - 2020-03-05 13:26:36 --> URI Class Initialized
INFO - 2020-03-05 13:26:36 --> Router Class Initialized
INFO - 2020-03-05 13:26:36 --> Output Class Initialized
INFO - 2020-03-05 13:26:36 --> Security Class Initialized
DEBUG - 2020-03-05 13:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 13:26:36 --> Input Class Initialized
INFO - 2020-03-05 13:26:36 --> Language Class Initialized
INFO - 2020-03-05 13:26:36 --> Loader Class Initialized
INFO - 2020-03-05 13:26:36 --> Helper loaded: url_helper
INFO - 2020-03-05 13:26:36 --> Helper loaded: string_helper
INFO - 2020-03-05 13:26:36 --> Database Driver Class Initialized
DEBUG - 2020-03-05 13:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 13:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 13:26:36 --> Controller Class Initialized
INFO - 2020-03-05 13:26:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 13:26:36 --> Pagination Class Initialized
INFO - 2020-03-05 13:26:36 --> Model "M_show" initialized
INFO - 2020-03-05 13:26:36 --> Helper loaded: form_helper
INFO - 2020-03-05 13:26:36 --> Form Validation Class Initialized
INFO - 2020-03-05 13:26:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 13:26:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 13:26:36 --> Final output sent to browser
DEBUG - 2020-03-05 13:26:36 --> Total execution time: 0.0072
INFO - 2020-03-05 13:27:29 --> Config Class Initialized
INFO - 2020-03-05 13:27:29 --> Hooks Class Initialized
DEBUG - 2020-03-05 13:27:29 --> UTF-8 Support Enabled
INFO - 2020-03-05 13:27:29 --> Utf8 Class Initialized
INFO - 2020-03-05 13:27:29 --> URI Class Initialized
INFO - 2020-03-05 13:27:29 --> Router Class Initialized
INFO - 2020-03-05 13:27:29 --> Output Class Initialized
INFO - 2020-03-05 13:27:29 --> Security Class Initialized
DEBUG - 2020-03-05 13:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 13:27:29 --> Input Class Initialized
INFO - 2020-03-05 13:27:29 --> Language Class Initialized
INFO - 2020-03-05 13:27:29 --> Loader Class Initialized
INFO - 2020-03-05 13:27:29 --> Helper loaded: url_helper
INFO - 2020-03-05 13:27:29 --> Helper loaded: string_helper
INFO - 2020-03-05 13:27:29 --> Database Driver Class Initialized
DEBUG - 2020-03-05 13:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 13:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 13:27:29 --> Controller Class Initialized
INFO - 2020-03-05 13:27:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 13:27:29 --> Pagination Class Initialized
INFO - 2020-03-05 13:27:29 --> Model "M_show" initialized
INFO - 2020-03-05 13:27:29 --> Helper loaded: form_helper
INFO - 2020-03-05 13:27:29 --> Form Validation Class Initialized
INFO - 2020-03-05 13:27:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 13:27:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 13:27:29 --> Final output sent to browser
DEBUG - 2020-03-05 13:27:29 --> Total execution time: 0.0061
INFO - 2020-03-05 13:27:30 --> Config Class Initialized
INFO - 2020-03-05 13:27:30 --> Hooks Class Initialized
DEBUG - 2020-03-05 13:27:30 --> UTF-8 Support Enabled
INFO - 2020-03-05 13:27:30 --> Utf8 Class Initialized
INFO - 2020-03-05 13:27:30 --> URI Class Initialized
INFO - 2020-03-05 13:27:30 --> Router Class Initialized
INFO - 2020-03-05 13:27:30 --> Output Class Initialized
INFO - 2020-03-05 13:27:30 --> Security Class Initialized
DEBUG - 2020-03-05 13:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 13:27:30 --> Input Class Initialized
INFO - 2020-03-05 13:27:30 --> Language Class Initialized
ERROR - 2020-03-05 13:27:30 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-05 14:29:01 --> Config Class Initialized
INFO - 2020-03-05 14:29:01 --> Hooks Class Initialized
DEBUG - 2020-03-05 14:29:01 --> UTF-8 Support Enabled
INFO - 2020-03-05 14:29:01 --> Utf8 Class Initialized
INFO - 2020-03-05 14:29:01 --> URI Class Initialized
INFO - 2020-03-05 14:29:01 --> Router Class Initialized
INFO - 2020-03-05 14:29:01 --> Output Class Initialized
INFO - 2020-03-05 14:29:01 --> Security Class Initialized
DEBUG - 2020-03-05 14:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 14:29:01 --> Input Class Initialized
INFO - 2020-03-05 14:29:01 --> Language Class Initialized
INFO - 2020-03-05 14:29:01 --> Loader Class Initialized
INFO - 2020-03-05 14:29:01 --> Helper loaded: url_helper
INFO - 2020-03-05 14:29:01 --> Helper loaded: string_helper
INFO - 2020-03-05 14:29:01 --> Database Driver Class Initialized
DEBUG - 2020-03-05 14:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 14:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 14:29:01 --> Controller Class Initialized
INFO - 2020-03-05 14:29:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 14:29:01 --> Pagination Class Initialized
INFO - 2020-03-05 14:29:01 --> Model "M_show" initialized
INFO - 2020-03-05 14:29:01 --> Helper loaded: form_helper
INFO - 2020-03-05 14:29:01 --> Form Validation Class Initialized
INFO - 2020-03-05 14:29:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 14:29:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 14:29:01 --> Final output sent to browser
DEBUG - 2020-03-05 14:29:01 --> Total execution time: 0.0948
INFO - 2020-03-05 14:29:01 --> Config Class Initialized
INFO - 2020-03-05 14:29:01 --> Hooks Class Initialized
DEBUG - 2020-03-05 14:29:01 --> UTF-8 Support Enabled
INFO - 2020-03-05 14:29:01 --> Utf8 Class Initialized
INFO - 2020-03-05 14:29:01 --> URI Class Initialized
INFO - 2020-03-05 14:29:01 --> Router Class Initialized
INFO - 2020-03-05 14:29:01 --> Output Class Initialized
INFO - 2020-03-05 14:29:01 --> Security Class Initialized
DEBUG - 2020-03-05 14:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 14:29:01 --> Input Class Initialized
INFO - 2020-03-05 14:29:01 --> Language Class Initialized
INFO - 2020-03-05 14:29:01 --> Loader Class Initialized
INFO - 2020-03-05 14:29:01 --> Helper loaded: url_helper
INFO - 2020-03-05 14:29:01 --> Helper loaded: string_helper
INFO - 2020-03-05 14:29:01 --> Database Driver Class Initialized
DEBUG - 2020-03-05 14:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 14:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 14:29:01 --> Controller Class Initialized
INFO - 2020-03-05 14:29:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 14:29:01 --> Pagination Class Initialized
INFO - 2020-03-05 14:29:01 --> Model "M_show" initialized
INFO - 2020-03-05 14:29:01 --> Helper loaded: form_helper
INFO - 2020-03-05 14:29:01 --> Form Validation Class Initialized
INFO - 2020-03-05 14:29:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 14:29:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 14:29:01 --> Final output sent to browser
DEBUG - 2020-03-05 14:29:01 --> Total execution time: 0.0177
INFO - 2020-03-05 14:29:03 --> Config Class Initialized
INFO - 2020-03-05 14:29:03 --> Hooks Class Initialized
DEBUG - 2020-03-05 14:29:03 --> UTF-8 Support Enabled
INFO - 2020-03-05 14:29:03 --> Utf8 Class Initialized
INFO - 2020-03-05 14:29:03 --> URI Class Initialized
INFO - 2020-03-05 14:29:03 --> Router Class Initialized
INFO - 2020-03-05 14:29:03 --> Output Class Initialized
INFO - 2020-03-05 14:29:03 --> Security Class Initialized
DEBUG - 2020-03-05 14:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 14:29:03 --> Input Class Initialized
INFO - 2020-03-05 14:29:03 --> Language Class Initialized
INFO - 2020-03-05 14:29:03 --> Loader Class Initialized
INFO - 2020-03-05 14:29:03 --> Helper loaded: url_helper
INFO - 2020-03-05 14:29:03 --> Helper loaded: string_helper
INFO - 2020-03-05 14:29:03 --> Database Driver Class Initialized
DEBUG - 2020-03-05 14:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 14:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 14:29:03 --> Controller Class Initialized
INFO - 2020-03-05 14:29:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 14:29:03 --> Pagination Class Initialized
INFO - 2020-03-05 14:29:03 --> Model "M_show" initialized
INFO - 2020-03-05 14:29:03 --> Helper loaded: form_helper
INFO - 2020-03-05 14:29:03 --> Form Validation Class Initialized
INFO - 2020-03-05 14:29:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 14:29:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 14:29:03 --> Final output sent to browser
DEBUG - 2020-03-05 14:29:03 --> Total execution time: 0.0074
INFO - 2020-03-05 14:29:04 --> Config Class Initialized
INFO - 2020-03-05 14:29:04 --> Hooks Class Initialized
DEBUG - 2020-03-05 14:29:04 --> UTF-8 Support Enabled
INFO - 2020-03-05 14:29:04 --> Utf8 Class Initialized
INFO - 2020-03-05 14:29:04 --> URI Class Initialized
INFO - 2020-03-05 14:29:04 --> Router Class Initialized
INFO - 2020-03-05 14:29:04 --> Output Class Initialized
INFO - 2020-03-05 14:29:04 --> Security Class Initialized
DEBUG - 2020-03-05 14:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 14:29:04 --> Input Class Initialized
INFO - 2020-03-05 14:29:04 --> Language Class Initialized
INFO - 2020-03-05 14:29:04 --> Loader Class Initialized
INFO - 2020-03-05 14:29:04 --> Helper loaded: url_helper
INFO - 2020-03-05 14:29:04 --> Helper loaded: string_helper
INFO - 2020-03-05 14:29:04 --> Database Driver Class Initialized
DEBUG - 2020-03-05 14:29:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 14:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 14:29:04 --> Controller Class Initialized
INFO - 2020-03-05 14:29:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 14:29:04 --> Pagination Class Initialized
INFO - 2020-03-05 14:29:04 --> Model "M_show" initialized
INFO - 2020-03-05 14:29:04 --> Helper loaded: form_helper
INFO - 2020-03-05 14:29:04 --> Form Validation Class Initialized
INFO - 2020-03-05 14:29:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 14:29:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 14:29:04 --> Final output sent to browser
DEBUG - 2020-03-05 14:29:04 --> Total execution time: 0.0114
INFO - 2020-03-05 14:38:32 --> Config Class Initialized
INFO - 2020-03-05 14:38:32 --> Hooks Class Initialized
DEBUG - 2020-03-05 14:38:32 --> UTF-8 Support Enabled
INFO - 2020-03-05 14:38:32 --> Utf8 Class Initialized
INFO - 2020-03-05 14:38:32 --> URI Class Initialized
DEBUG - 2020-03-05 14:38:32 --> No URI present. Default controller set.
INFO - 2020-03-05 14:38:32 --> Router Class Initialized
INFO - 2020-03-05 14:38:32 --> Output Class Initialized
INFO - 2020-03-05 14:38:32 --> Security Class Initialized
DEBUG - 2020-03-05 14:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 14:38:32 --> Input Class Initialized
INFO - 2020-03-05 14:38:32 --> Language Class Initialized
INFO - 2020-03-05 14:38:32 --> Loader Class Initialized
INFO - 2020-03-05 14:38:32 --> Helper loaded: url_helper
INFO - 2020-03-05 14:38:32 --> Helper loaded: string_helper
INFO - 2020-03-05 14:38:32 --> Database Driver Class Initialized
DEBUG - 2020-03-05 14:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 14:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 14:38:32 --> Controller Class Initialized
INFO - 2020-03-05 14:38:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 14:38:32 --> Pagination Class Initialized
INFO - 2020-03-05 14:38:32 --> Model "M_show" initialized
INFO - 2020-03-05 14:38:32 --> Helper loaded: form_helper
INFO - 2020-03-05 14:38:32 --> Form Validation Class Initialized
INFO - 2020-03-05 14:38:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 14:38:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 14:38:32 --> Final output sent to browser
DEBUG - 2020-03-05 14:38:32 --> Total execution time: 0.1025
INFO - 2020-03-05 14:38:45 --> Config Class Initialized
INFO - 2020-03-05 14:38:45 --> Hooks Class Initialized
DEBUG - 2020-03-05 14:38:45 --> UTF-8 Support Enabled
INFO - 2020-03-05 14:38:45 --> Utf8 Class Initialized
INFO - 2020-03-05 14:38:45 --> URI Class Initialized
INFO - 2020-03-05 14:38:45 --> Router Class Initialized
INFO - 2020-03-05 14:38:45 --> Output Class Initialized
INFO - 2020-03-05 14:38:45 --> Security Class Initialized
DEBUG - 2020-03-05 14:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 14:38:45 --> Input Class Initialized
INFO - 2020-03-05 14:38:45 --> Language Class Initialized
INFO - 2020-03-05 14:38:45 --> Loader Class Initialized
INFO - 2020-03-05 14:38:45 --> Helper loaded: url_helper
INFO - 2020-03-05 14:38:45 --> Helper loaded: string_helper
INFO - 2020-03-05 14:38:45 --> Database Driver Class Initialized
DEBUG - 2020-03-05 14:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 14:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 14:38:46 --> Controller Class Initialized
INFO - 2020-03-05 14:38:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 14:38:46 --> Pagination Class Initialized
INFO - 2020-03-05 14:38:46 --> Model "M_show" initialized
INFO - 2020-03-05 14:38:46 --> Helper loaded: form_helper
INFO - 2020-03-05 14:38:46 --> Form Validation Class Initialized
INFO - 2020-03-05 14:38:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 14:38:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 14:38:46 --> Final output sent to browser
DEBUG - 2020-03-05 14:38:46 --> Total execution time: 0.1294
INFO - 2020-03-05 14:38:50 --> Config Class Initialized
INFO - 2020-03-05 14:38:50 --> Hooks Class Initialized
DEBUG - 2020-03-05 14:38:50 --> UTF-8 Support Enabled
INFO - 2020-03-05 14:38:50 --> Utf8 Class Initialized
INFO - 2020-03-05 14:38:50 --> URI Class Initialized
INFO - 2020-03-05 14:38:50 --> Router Class Initialized
INFO - 2020-03-05 14:38:50 --> Output Class Initialized
INFO - 2020-03-05 14:38:50 --> Security Class Initialized
DEBUG - 2020-03-05 14:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 14:38:50 --> Input Class Initialized
INFO - 2020-03-05 14:38:50 --> Language Class Initialized
INFO - 2020-03-05 14:38:50 --> Loader Class Initialized
INFO - 2020-03-05 14:38:50 --> Helper loaded: url_helper
INFO - 2020-03-05 14:38:50 --> Helper loaded: string_helper
INFO - 2020-03-05 14:38:50 --> Database Driver Class Initialized
DEBUG - 2020-03-05 14:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 14:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 14:38:50 --> Controller Class Initialized
INFO - 2020-03-05 14:38:50 --> Model "M_tiket" initialized
INFO - 2020-03-05 14:38:50 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 14:38:50 --> Model "M_pesan" initialized
INFO - 2020-03-05 14:38:50 --> Helper loaded: form_helper
INFO - 2020-03-05 14:38:50 --> Form Validation Class Initialized
INFO - 2020-03-05 14:38:51 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 14:38:51 --> Final output sent to browser
DEBUG - 2020-03-05 14:38:51 --> Total execution time: 0.2679
INFO - 2020-03-05 14:38:56 --> Config Class Initialized
INFO - 2020-03-05 14:38:56 --> Hooks Class Initialized
DEBUG - 2020-03-05 14:38:56 --> UTF-8 Support Enabled
INFO - 2020-03-05 14:38:56 --> Utf8 Class Initialized
INFO - 2020-03-05 14:38:56 --> URI Class Initialized
INFO - 2020-03-05 14:38:56 --> Router Class Initialized
INFO - 2020-03-05 14:38:56 --> Output Class Initialized
INFO - 2020-03-05 14:38:56 --> Security Class Initialized
DEBUG - 2020-03-05 14:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 14:38:56 --> Input Class Initialized
INFO - 2020-03-05 14:38:56 --> Language Class Initialized
INFO - 2020-03-05 14:38:56 --> Loader Class Initialized
INFO - 2020-03-05 14:38:56 --> Helper loaded: url_helper
INFO - 2020-03-05 14:38:56 --> Helper loaded: string_helper
INFO - 2020-03-05 14:38:56 --> Database Driver Class Initialized
DEBUG - 2020-03-05 14:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 14:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 14:38:56 --> Controller Class Initialized
INFO - 2020-03-05 14:38:56 --> Model "M_tiket" initialized
INFO - 2020-03-05 14:38:56 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 14:38:56 --> Model "M_pesan" initialized
INFO - 2020-03-05 14:38:56 --> Helper loaded: form_helper
INFO - 2020-03-05 14:38:56 --> Form Validation Class Initialized
INFO - 2020-03-05 14:38:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-05 14:38:56 --> Final output sent to browser
DEBUG - 2020-03-05 14:38:56 --> Total execution time: 0.0461
INFO - 2020-03-05 14:39:26 --> Config Class Initialized
INFO - 2020-03-05 14:39:26 --> Hooks Class Initialized
DEBUG - 2020-03-05 14:39:26 --> UTF-8 Support Enabled
INFO - 2020-03-05 14:39:26 --> Utf8 Class Initialized
INFO - 2020-03-05 14:39:26 --> URI Class Initialized
DEBUG - 2020-03-05 14:39:26 --> No URI present. Default controller set.
INFO - 2020-03-05 14:39:26 --> Router Class Initialized
INFO - 2020-03-05 14:39:26 --> Output Class Initialized
INFO - 2020-03-05 14:39:26 --> Security Class Initialized
DEBUG - 2020-03-05 14:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 14:39:26 --> Input Class Initialized
INFO - 2020-03-05 14:39:26 --> Language Class Initialized
INFO - 2020-03-05 14:39:26 --> Loader Class Initialized
INFO - 2020-03-05 14:39:26 --> Helper loaded: url_helper
INFO - 2020-03-05 14:39:26 --> Helper loaded: string_helper
INFO - 2020-03-05 14:39:26 --> Database Driver Class Initialized
DEBUG - 2020-03-05 14:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 14:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 14:39:26 --> Controller Class Initialized
INFO - 2020-03-05 14:39:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 14:39:26 --> Pagination Class Initialized
INFO - 2020-03-05 14:39:26 --> Model "M_show" initialized
INFO - 2020-03-05 14:39:26 --> Helper loaded: form_helper
INFO - 2020-03-05 14:39:26 --> Form Validation Class Initialized
INFO - 2020-03-05 14:39:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 14:39:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 14:39:26 --> Final output sent to browser
DEBUG - 2020-03-05 14:39:26 --> Total execution time: 0.0055
INFO - 2020-03-05 14:49:06 --> Config Class Initialized
INFO - 2020-03-05 14:49:06 --> Hooks Class Initialized
DEBUG - 2020-03-05 14:49:06 --> UTF-8 Support Enabled
INFO - 2020-03-05 14:49:06 --> Utf8 Class Initialized
INFO - 2020-03-05 14:49:06 --> URI Class Initialized
DEBUG - 2020-03-05 14:49:06 --> No URI present. Default controller set.
INFO - 2020-03-05 14:49:06 --> Router Class Initialized
INFO - 2020-03-05 14:49:06 --> Output Class Initialized
INFO - 2020-03-05 14:49:06 --> Security Class Initialized
DEBUG - 2020-03-05 14:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 14:49:06 --> Input Class Initialized
INFO - 2020-03-05 14:49:06 --> Language Class Initialized
INFO - 2020-03-05 14:49:06 --> Loader Class Initialized
INFO - 2020-03-05 14:49:06 --> Helper loaded: url_helper
INFO - 2020-03-05 14:49:06 --> Helper loaded: string_helper
INFO - 2020-03-05 14:49:06 --> Database Driver Class Initialized
DEBUG - 2020-03-05 14:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 14:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 14:49:06 --> Controller Class Initialized
INFO - 2020-03-05 14:49:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 14:49:06 --> Pagination Class Initialized
INFO - 2020-03-05 14:49:06 --> Model "M_show" initialized
INFO - 2020-03-05 14:49:06 --> Helper loaded: form_helper
INFO - 2020-03-05 14:49:06 --> Form Validation Class Initialized
INFO - 2020-03-05 14:49:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 14:49:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 14:49:06 --> Final output sent to browser
DEBUG - 2020-03-05 14:49:06 --> Total execution time: 0.0555
INFO - 2020-03-05 14:49:10 --> Config Class Initialized
INFO - 2020-03-05 14:49:10 --> Hooks Class Initialized
DEBUG - 2020-03-05 14:49:10 --> UTF-8 Support Enabled
INFO - 2020-03-05 14:49:10 --> Utf8 Class Initialized
INFO - 2020-03-05 14:49:10 --> URI Class Initialized
INFO - 2020-03-05 14:49:10 --> Router Class Initialized
INFO - 2020-03-05 14:49:10 --> Output Class Initialized
INFO - 2020-03-05 14:49:10 --> Security Class Initialized
DEBUG - 2020-03-05 14:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 14:49:10 --> Input Class Initialized
INFO - 2020-03-05 14:49:10 --> Language Class Initialized
INFO - 2020-03-05 14:49:10 --> Loader Class Initialized
INFO - 2020-03-05 14:49:10 --> Helper loaded: url_helper
INFO - 2020-03-05 14:49:10 --> Helper loaded: string_helper
INFO - 2020-03-05 14:49:10 --> Database Driver Class Initialized
DEBUG - 2020-03-05 14:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 14:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 14:49:10 --> Controller Class Initialized
INFO - 2020-03-05 14:49:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 14:49:10 --> Pagination Class Initialized
INFO - 2020-03-05 14:49:10 --> Model "M_show" initialized
INFO - 2020-03-05 14:49:10 --> Helper loaded: form_helper
INFO - 2020-03-05 14:49:10 --> Form Validation Class Initialized
INFO - 2020-03-05 14:49:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 14:49:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 14:49:10 --> Final output sent to browser
DEBUG - 2020-03-05 14:49:10 --> Total execution time: 0.0106
INFO - 2020-03-05 14:49:13 --> Config Class Initialized
INFO - 2020-03-05 14:49:13 --> Hooks Class Initialized
DEBUG - 2020-03-05 14:49:13 --> UTF-8 Support Enabled
INFO - 2020-03-05 14:49:13 --> Utf8 Class Initialized
INFO - 2020-03-05 14:49:13 --> URI Class Initialized
INFO - 2020-03-05 14:49:13 --> Router Class Initialized
INFO - 2020-03-05 14:49:13 --> Output Class Initialized
INFO - 2020-03-05 14:49:13 --> Security Class Initialized
DEBUG - 2020-03-05 14:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 14:49:13 --> Input Class Initialized
INFO - 2020-03-05 14:49:13 --> Language Class Initialized
INFO - 2020-03-05 14:49:13 --> Loader Class Initialized
INFO - 2020-03-05 14:49:13 --> Helper loaded: url_helper
INFO - 2020-03-05 14:49:13 --> Helper loaded: string_helper
INFO - 2020-03-05 14:49:13 --> Database Driver Class Initialized
DEBUG - 2020-03-05 14:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 14:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 14:49:13 --> Controller Class Initialized
INFO - 2020-03-05 14:49:13 --> Model "M_tiket" initialized
INFO - 2020-03-05 14:49:13 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 14:49:13 --> Model "M_pesan" initialized
INFO - 2020-03-05 14:49:13 --> Helper loaded: form_helper
INFO - 2020-03-05 14:49:13 --> Form Validation Class Initialized
INFO - 2020-03-05 14:49:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 14:49:13 --> Final output sent to browser
DEBUG - 2020-03-05 14:49:13 --> Total execution time: 0.0515
INFO - 2020-03-05 14:49:39 --> Config Class Initialized
INFO - 2020-03-05 14:49:39 --> Hooks Class Initialized
DEBUG - 2020-03-05 14:49:39 --> UTF-8 Support Enabled
INFO - 2020-03-05 14:49:39 --> Utf8 Class Initialized
INFO - 2020-03-05 14:49:39 --> URI Class Initialized
INFO - 2020-03-05 14:49:39 --> Router Class Initialized
INFO - 2020-03-05 14:49:39 --> Output Class Initialized
INFO - 2020-03-05 14:49:39 --> Security Class Initialized
DEBUG - 2020-03-05 14:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 14:49:39 --> Input Class Initialized
INFO - 2020-03-05 14:49:39 --> Language Class Initialized
INFO - 2020-03-05 14:49:39 --> Loader Class Initialized
INFO - 2020-03-05 14:49:39 --> Helper loaded: url_helper
INFO - 2020-03-05 14:49:39 --> Helper loaded: string_helper
INFO - 2020-03-05 14:49:39 --> Database Driver Class Initialized
DEBUG - 2020-03-05 14:49:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 14:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 14:49:39 --> Controller Class Initialized
INFO - 2020-03-05 14:49:39 --> Model "M_tiket" initialized
INFO - 2020-03-05 14:49:39 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 14:49:39 --> Model "M_pesan" initialized
INFO - 2020-03-05 14:49:39 --> Helper loaded: form_helper
INFO - 2020-03-05 14:49:39 --> Form Validation Class Initialized
INFO - 2020-03-05 14:49:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 14:49:39 --> Final output sent to browser
DEBUG - 2020-03-05 14:49:39 --> Total execution time: 0.0094
INFO - 2020-03-05 14:49:39 --> Config Class Initialized
INFO - 2020-03-05 14:49:39 --> Hooks Class Initialized
DEBUG - 2020-03-05 14:49:39 --> UTF-8 Support Enabled
INFO - 2020-03-05 14:49:39 --> Utf8 Class Initialized
INFO - 2020-03-05 14:49:39 --> URI Class Initialized
INFO - 2020-03-05 14:49:39 --> Router Class Initialized
INFO - 2020-03-05 14:49:39 --> Output Class Initialized
INFO - 2020-03-05 14:49:39 --> Security Class Initialized
DEBUG - 2020-03-05 14:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 14:49:39 --> Input Class Initialized
INFO - 2020-03-05 14:49:39 --> Language Class Initialized
INFO - 2020-03-05 14:49:39 --> Loader Class Initialized
INFO - 2020-03-05 14:49:39 --> Helper loaded: url_helper
INFO - 2020-03-05 14:49:39 --> Helper loaded: string_helper
INFO - 2020-03-05 14:49:39 --> Database Driver Class Initialized
DEBUG - 2020-03-05 14:49:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 14:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 14:49:39 --> Controller Class Initialized
INFO - 2020-03-05 14:49:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 14:49:39 --> Pagination Class Initialized
INFO - 2020-03-05 14:49:39 --> Model "M_show" initialized
INFO - 2020-03-05 14:49:39 --> Helper loaded: form_helper
INFO - 2020-03-05 14:49:39 --> Form Validation Class Initialized
INFO - 2020-03-05 14:49:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 14:49:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 14:49:39 --> Final output sent to browser
DEBUG - 2020-03-05 14:49:39 --> Total execution time: 0.0039
INFO - 2020-03-05 14:49:40 --> Config Class Initialized
INFO - 2020-03-05 14:49:40 --> Hooks Class Initialized
DEBUG - 2020-03-05 14:49:40 --> UTF-8 Support Enabled
INFO - 2020-03-05 14:49:40 --> Utf8 Class Initialized
INFO - 2020-03-05 14:49:40 --> URI Class Initialized
DEBUG - 2020-03-05 14:49:40 --> No URI present. Default controller set.
INFO - 2020-03-05 14:49:40 --> Router Class Initialized
INFO - 2020-03-05 14:49:40 --> Output Class Initialized
INFO - 2020-03-05 14:49:40 --> Security Class Initialized
DEBUG - 2020-03-05 14:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 14:49:40 --> Input Class Initialized
INFO - 2020-03-05 14:49:40 --> Language Class Initialized
INFO - 2020-03-05 14:49:40 --> Loader Class Initialized
INFO - 2020-03-05 14:49:40 --> Helper loaded: url_helper
INFO - 2020-03-05 14:49:40 --> Helper loaded: string_helper
INFO - 2020-03-05 14:49:40 --> Database Driver Class Initialized
DEBUG - 2020-03-05 14:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 14:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 14:49:40 --> Controller Class Initialized
INFO - 2020-03-05 14:49:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 14:49:40 --> Pagination Class Initialized
INFO - 2020-03-05 14:49:40 --> Model "M_show" initialized
INFO - 2020-03-05 14:49:40 --> Helper loaded: form_helper
INFO - 2020-03-05 14:49:40 --> Form Validation Class Initialized
INFO - 2020-03-05 14:49:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 14:49:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 14:49:40 --> Final output sent to browser
DEBUG - 2020-03-05 14:49:40 --> Total execution time: 0.0053
INFO - 2020-03-05 14:49:52 --> Config Class Initialized
INFO - 2020-03-05 14:49:52 --> Hooks Class Initialized
DEBUG - 2020-03-05 14:49:52 --> UTF-8 Support Enabled
INFO - 2020-03-05 14:49:52 --> Utf8 Class Initialized
INFO - 2020-03-05 14:49:52 --> URI Class Initialized
INFO - 2020-03-05 14:49:52 --> Router Class Initialized
INFO - 2020-03-05 14:49:52 --> Output Class Initialized
INFO - 2020-03-05 14:49:52 --> Security Class Initialized
DEBUG - 2020-03-05 14:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 14:49:52 --> Input Class Initialized
INFO - 2020-03-05 14:49:52 --> Language Class Initialized
INFO - 2020-03-05 14:49:52 --> Loader Class Initialized
INFO - 2020-03-05 14:49:52 --> Helper loaded: url_helper
INFO - 2020-03-05 14:49:52 --> Helper loaded: string_helper
INFO - 2020-03-05 14:49:52 --> Database Driver Class Initialized
DEBUG - 2020-03-05 14:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 14:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 14:49:52 --> Controller Class Initialized
INFO - 2020-03-05 14:49:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 14:49:52 --> Pagination Class Initialized
INFO - 2020-03-05 14:49:52 --> Model "M_show" initialized
INFO - 2020-03-05 14:49:52 --> Helper loaded: form_helper
INFO - 2020-03-05 14:49:52 --> Form Validation Class Initialized
INFO - 2020-03-05 14:49:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 14:49:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 14:49:52 --> Final output sent to browser
DEBUG - 2020-03-05 14:49:52 --> Total execution time: 0.0388
INFO - 2020-03-05 14:49:55 --> Config Class Initialized
INFO - 2020-03-05 14:49:55 --> Hooks Class Initialized
DEBUG - 2020-03-05 14:49:55 --> UTF-8 Support Enabled
INFO - 2020-03-05 14:49:55 --> Utf8 Class Initialized
INFO - 2020-03-05 14:49:55 --> URI Class Initialized
DEBUG - 2020-03-05 14:49:55 --> No URI present. Default controller set.
INFO - 2020-03-05 14:49:55 --> Router Class Initialized
INFO - 2020-03-05 14:49:55 --> Output Class Initialized
INFO - 2020-03-05 14:49:55 --> Security Class Initialized
DEBUG - 2020-03-05 14:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 14:49:55 --> Input Class Initialized
INFO - 2020-03-05 14:49:55 --> Language Class Initialized
INFO - 2020-03-05 14:49:55 --> Loader Class Initialized
INFO - 2020-03-05 14:49:55 --> Helper loaded: url_helper
INFO - 2020-03-05 14:49:55 --> Helper loaded: string_helper
INFO - 2020-03-05 14:49:55 --> Database Driver Class Initialized
DEBUG - 2020-03-05 14:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 14:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 14:49:55 --> Controller Class Initialized
INFO - 2020-03-05 14:49:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 14:49:55 --> Pagination Class Initialized
INFO - 2020-03-05 14:49:55 --> Model "M_show" initialized
INFO - 2020-03-05 14:49:55 --> Helper loaded: form_helper
INFO - 2020-03-05 14:49:55 --> Form Validation Class Initialized
INFO - 2020-03-05 14:49:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 14:49:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 14:49:55 --> Final output sent to browser
DEBUG - 2020-03-05 14:49:55 --> Total execution time: 0.0789
INFO - 2020-03-05 14:50:47 --> Config Class Initialized
INFO - 2020-03-05 14:50:47 --> Hooks Class Initialized
DEBUG - 2020-03-05 14:50:47 --> UTF-8 Support Enabled
INFO - 2020-03-05 14:50:47 --> Utf8 Class Initialized
INFO - 2020-03-05 14:50:47 --> URI Class Initialized
DEBUG - 2020-03-05 14:50:47 --> No URI present. Default controller set.
INFO - 2020-03-05 14:50:47 --> Router Class Initialized
INFO - 2020-03-05 14:50:47 --> Output Class Initialized
INFO - 2020-03-05 14:50:47 --> Security Class Initialized
DEBUG - 2020-03-05 14:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 14:50:47 --> Input Class Initialized
INFO - 2020-03-05 14:50:47 --> Language Class Initialized
INFO - 2020-03-05 14:50:47 --> Loader Class Initialized
INFO - 2020-03-05 14:50:47 --> Helper loaded: url_helper
INFO - 2020-03-05 14:50:47 --> Helper loaded: string_helper
INFO - 2020-03-05 14:50:47 --> Database Driver Class Initialized
DEBUG - 2020-03-05 14:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 14:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 14:50:47 --> Controller Class Initialized
INFO - 2020-03-05 14:50:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 14:50:47 --> Pagination Class Initialized
INFO - 2020-03-05 14:50:47 --> Model "M_show" initialized
INFO - 2020-03-05 14:50:47 --> Helper loaded: form_helper
INFO - 2020-03-05 14:50:47 --> Form Validation Class Initialized
INFO - 2020-03-05 14:50:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 14:50:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 14:50:47 --> Final output sent to browser
DEBUG - 2020-03-05 14:50:47 --> Total execution time: 0.0058
INFO - 2020-03-05 15:09:59 --> Config Class Initialized
INFO - 2020-03-05 15:09:59 --> Hooks Class Initialized
DEBUG - 2020-03-05 15:09:59 --> UTF-8 Support Enabled
INFO - 2020-03-05 15:09:59 --> Utf8 Class Initialized
INFO - 2020-03-05 15:09:59 --> URI Class Initialized
DEBUG - 2020-03-05 15:09:59 --> No URI present. Default controller set.
INFO - 2020-03-05 15:09:59 --> Router Class Initialized
INFO - 2020-03-05 15:09:59 --> Output Class Initialized
INFO - 2020-03-05 15:09:59 --> Security Class Initialized
DEBUG - 2020-03-05 15:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 15:09:59 --> Input Class Initialized
INFO - 2020-03-05 15:09:59 --> Language Class Initialized
INFO - 2020-03-05 15:09:59 --> Loader Class Initialized
INFO - 2020-03-05 15:09:59 --> Helper loaded: url_helper
INFO - 2020-03-05 15:09:59 --> Helper loaded: string_helper
INFO - 2020-03-05 15:09:59 --> Database Driver Class Initialized
DEBUG - 2020-03-05 15:09:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 15:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 15:09:59 --> Controller Class Initialized
INFO - 2020-03-05 15:09:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 15:09:59 --> Pagination Class Initialized
INFO - 2020-03-05 15:09:59 --> Model "M_show" initialized
INFO - 2020-03-05 15:09:59 --> Helper loaded: form_helper
INFO - 2020-03-05 15:09:59 --> Form Validation Class Initialized
INFO - 2020-03-05 15:09:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 15:09:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 15:09:59 --> Final output sent to browser
DEBUG - 2020-03-05 15:09:59 --> Total execution time: 0.0338
INFO - 2020-03-05 15:10:15 --> Config Class Initialized
INFO - 2020-03-05 15:10:15 --> Hooks Class Initialized
DEBUG - 2020-03-05 15:10:15 --> UTF-8 Support Enabled
INFO - 2020-03-05 15:10:15 --> Utf8 Class Initialized
INFO - 2020-03-05 15:10:15 --> URI Class Initialized
INFO - 2020-03-05 15:10:15 --> Router Class Initialized
INFO - 2020-03-05 15:10:15 --> Output Class Initialized
INFO - 2020-03-05 15:10:15 --> Security Class Initialized
DEBUG - 2020-03-05 15:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 15:10:15 --> Input Class Initialized
INFO - 2020-03-05 15:10:15 --> Language Class Initialized
INFO - 2020-03-05 15:10:15 --> Loader Class Initialized
INFO - 2020-03-05 15:10:15 --> Helper loaded: url_helper
INFO - 2020-03-05 15:10:15 --> Helper loaded: string_helper
INFO - 2020-03-05 15:10:15 --> Database Driver Class Initialized
DEBUG - 2020-03-05 15:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 15:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 15:10:15 --> Controller Class Initialized
INFO - 2020-03-05 15:10:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 15:10:15 --> Pagination Class Initialized
INFO - 2020-03-05 15:10:15 --> Model "M_show" initialized
INFO - 2020-03-05 15:10:15 --> Helper loaded: form_helper
INFO - 2020-03-05 15:10:15 --> Form Validation Class Initialized
INFO - 2020-03-05 15:10:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 15:10:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 15:10:15 --> Final output sent to browser
DEBUG - 2020-03-05 15:10:15 --> Total execution time: 0.0056
INFO - 2020-03-05 15:10:25 --> Config Class Initialized
INFO - 2020-03-05 15:10:25 --> Hooks Class Initialized
DEBUG - 2020-03-05 15:10:25 --> UTF-8 Support Enabled
INFO - 2020-03-05 15:10:25 --> Utf8 Class Initialized
INFO - 2020-03-05 15:10:25 --> URI Class Initialized
INFO - 2020-03-05 15:10:25 --> Router Class Initialized
INFO - 2020-03-05 15:10:25 --> Output Class Initialized
INFO - 2020-03-05 15:10:25 --> Security Class Initialized
DEBUG - 2020-03-05 15:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 15:10:25 --> Input Class Initialized
INFO - 2020-03-05 15:10:25 --> Language Class Initialized
INFO - 2020-03-05 15:10:25 --> Loader Class Initialized
INFO - 2020-03-05 15:10:25 --> Helper loaded: url_helper
INFO - 2020-03-05 15:10:25 --> Helper loaded: string_helper
INFO - 2020-03-05 15:10:25 --> Database Driver Class Initialized
DEBUG - 2020-03-05 15:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 15:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 15:10:25 --> Controller Class Initialized
INFO - 2020-03-05 15:10:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 15:10:25 --> Pagination Class Initialized
INFO - 2020-03-05 15:10:25 --> Model "M_show" initialized
INFO - 2020-03-05 15:10:25 --> Helper loaded: form_helper
INFO - 2020-03-05 15:10:25 --> Form Validation Class Initialized
INFO - 2020-03-05 15:10:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 15:10:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 15:10:25 --> Final output sent to browser
DEBUG - 2020-03-05 15:10:25 --> Total execution time: 0.0131
INFO - 2020-03-05 15:10:29 --> Config Class Initialized
INFO - 2020-03-05 15:10:29 --> Hooks Class Initialized
DEBUG - 2020-03-05 15:10:29 --> UTF-8 Support Enabled
INFO - 2020-03-05 15:10:29 --> Utf8 Class Initialized
INFO - 2020-03-05 15:10:29 --> URI Class Initialized
INFO - 2020-03-05 15:10:29 --> Router Class Initialized
INFO - 2020-03-05 15:10:29 --> Output Class Initialized
INFO - 2020-03-05 15:10:29 --> Security Class Initialized
DEBUG - 2020-03-05 15:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 15:10:29 --> Input Class Initialized
INFO - 2020-03-05 15:10:29 --> Language Class Initialized
INFO - 2020-03-05 15:10:29 --> Loader Class Initialized
INFO - 2020-03-05 15:10:29 --> Helper loaded: url_helper
INFO - 2020-03-05 15:10:29 --> Helper loaded: string_helper
INFO - 2020-03-05 15:10:29 --> Database Driver Class Initialized
DEBUG - 2020-03-05 15:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 15:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 15:10:29 --> Controller Class Initialized
INFO - 2020-03-05 15:10:29 --> Model "M_tiket" initialized
INFO - 2020-03-05 15:10:29 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 15:10:29 --> Model "M_pesan" initialized
INFO - 2020-03-05 15:10:29 --> Helper loaded: form_helper
INFO - 2020-03-05 15:10:29 --> Form Validation Class Initialized
INFO - 2020-03-05 15:10:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 15:10:29 --> Final output sent to browser
DEBUG - 2020-03-05 15:10:29 --> Total execution time: 0.0120
INFO - 2020-03-05 15:10:56 --> Config Class Initialized
INFO - 2020-03-05 15:10:56 --> Hooks Class Initialized
DEBUG - 2020-03-05 15:10:56 --> UTF-8 Support Enabled
INFO - 2020-03-05 15:10:56 --> Utf8 Class Initialized
INFO - 2020-03-05 15:10:56 --> URI Class Initialized
INFO - 2020-03-05 15:10:56 --> Router Class Initialized
INFO - 2020-03-05 15:10:56 --> Output Class Initialized
INFO - 2020-03-05 15:10:56 --> Security Class Initialized
DEBUG - 2020-03-05 15:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 15:10:56 --> Input Class Initialized
INFO - 2020-03-05 15:10:56 --> Language Class Initialized
INFO - 2020-03-05 15:10:56 --> Loader Class Initialized
INFO - 2020-03-05 15:10:56 --> Helper loaded: url_helper
INFO - 2020-03-05 15:10:56 --> Helper loaded: string_helper
INFO - 2020-03-05 15:10:56 --> Database Driver Class Initialized
DEBUG - 2020-03-05 15:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 15:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 15:10:56 --> Controller Class Initialized
INFO - 2020-03-05 15:10:56 --> Model "M_tiket" initialized
INFO - 2020-03-05 15:10:56 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 15:10:56 --> Model "M_pesan" initialized
INFO - 2020-03-05 15:10:56 --> Helper loaded: form_helper
INFO - 2020-03-05 15:10:56 --> Form Validation Class Initialized
INFO - 2020-03-05 15:10:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-05 15:10:56 --> Final output sent to browser
DEBUG - 2020-03-05 15:10:56 --> Total execution time: 0.0078
INFO - 2020-03-05 15:34:30 --> Config Class Initialized
INFO - 2020-03-05 15:34:30 --> Hooks Class Initialized
DEBUG - 2020-03-05 15:34:30 --> UTF-8 Support Enabled
INFO - 2020-03-05 15:34:30 --> Utf8 Class Initialized
INFO - 2020-03-05 15:34:30 --> URI Class Initialized
INFO - 2020-03-05 15:34:30 --> Router Class Initialized
INFO - 2020-03-05 15:34:30 --> Output Class Initialized
INFO - 2020-03-05 15:34:30 --> Security Class Initialized
DEBUG - 2020-03-05 15:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 15:34:30 --> Input Class Initialized
INFO - 2020-03-05 15:34:30 --> Language Class Initialized
INFO - 2020-03-05 15:34:30 --> Loader Class Initialized
INFO - 2020-03-05 15:34:30 --> Helper loaded: url_helper
INFO - 2020-03-05 15:34:30 --> Helper loaded: string_helper
INFO - 2020-03-05 15:34:30 --> Database Driver Class Initialized
DEBUG - 2020-03-05 15:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 15:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 15:34:30 --> Controller Class Initialized
INFO - 2020-03-05 15:34:30 --> Model "M_tiket" initialized
INFO - 2020-03-05 15:34:30 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 15:34:30 --> Model "M_pesan" initialized
INFO - 2020-03-05 15:34:30 --> Helper loaded: form_helper
INFO - 2020-03-05 15:34:30 --> Form Validation Class Initialized
INFO - 2020-03-05 15:34:30 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 15:34:30 --> Final output sent to browser
DEBUG - 2020-03-05 15:34:30 --> Total execution time: 0.0352
INFO - 2020-03-05 15:34:31 --> Config Class Initialized
INFO - 2020-03-05 15:34:31 --> Hooks Class Initialized
DEBUG - 2020-03-05 15:34:31 --> UTF-8 Support Enabled
INFO - 2020-03-05 15:34:31 --> Utf8 Class Initialized
INFO - 2020-03-05 15:34:31 --> URI Class Initialized
INFO - 2020-03-05 15:34:31 --> Router Class Initialized
INFO - 2020-03-05 15:34:31 --> Output Class Initialized
INFO - 2020-03-05 15:34:31 --> Security Class Initialized
DEBUG - 2020-03-05 15:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 15:34:31 --> Input Class Initialized
INFO - 2020-03-05 15:34:31 --> Language Class Initialized
INFO - 2020-03-05 15:34:31 --> Loader Class Initialized
INFO - 2020-03-05 15:34:31 --> Helper loaded: url_helper
INFO - 2020-03-05 15:34:31 --> Helper loaded: string_helper
INFO - 2020-03-05 15:34:31 --> Database Driver Class Initialized
DEBUG - 2020-03-05 15:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 15:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 15:34:31 --> Controller Class Initialized
INFO - 2020-03-05 15:34:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 15:34:31 --> Pagination Class Initialized
INFO - 2020-03-05 15:34:31 --> Model "M_show" initialized
INFO - 2020-03-05 15:34:31 --> Helper loaded: form_helper
INFO - 2020-03-05 15:34:31 --> Form Validation Class Initialized
INFO - 2020-03-05 15:34:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 15:34:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 15:34:31 --> Final output sent to browser
DEBUG - 2020-03-05 15:34:31 --> Total execution time: 0.0122
INFO - 2020-03-05 15:34:31 --> Config Class Initialized
INFO - 2020-03-05 15:34:31 --> Hooks Class Initialized
DEBUG - 2020-03-05 15:34:31 --> UTF-8 Support Enabled
INFO - 2020-03-05 15:34:31 --> Utf8 Class Initialized
INFO - 2020-03-05 15:34:31 --> URI Class Initialized
INFO - 2020-03-05 15:34:31 --> Router Class Initialized
INFO - 2020-03-05 15:34:31 --> Output Class Initialized
INFO - 2020-03-05 15:34:31 --> Security Class Initialized
DEBUG - 2020-03-05 15:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 15:34:31 --> Input Class Initialized
INFO - 2020-03-05 15:34:31 --> Language Class Initialized
INFO - 2020-03-05 15:34:31 --> Loader Class Initialized
INFO - 2020-03-05 15:34:31 --> Helper loaded: url_helper
INFO - 2020-03-05 15:34:31 --> Helper loaded: string_helper
INFO - 2020-03-05 15:34:31 --> Database Driver Class Initialized
DEBUG - 2020-03-05 15:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 15:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 15:34:31 --> Controller Class Initialized
INFO - 2020-03-05 15:34:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 15:34:31 --> Pagination Class Initialized
INFO - 2020-03-05 15:34:31 --> Model "M_show" initialized
INFO - 2020-03-05 15:34:31 --> Helper loaded: form_helper
INFO - 2020-03-05 15:34:31 --> Form Validation Class Initialized
INFO - 2020-03-05 15:34:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 15:34:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 15:34:31 --> Final output sent to browser
DEBUG - 2020-03-05 15:34:31 --> Total execution time: 0.0060
INFO - 2020-03-05 15:34:32 --> Config Class Initialized
INFO - 2020-03-05 15:34:32 --> Hooks Class Initialized
DEBUG - 2020-03-05 15:34:32 --> UTF-8 Support Enabled
INFO - 2020-03-05 15:34:32 --> Utf8 Class Initialized
INFO - 2020-03-05 15:34:32 --> URI Class Initialized
DEBUG - 2020-03-05 15:34:32 --> No URI present. Default controller set.
INFO - 2020-03-05 15:34:32 --> Router Class Initialized
INFO - 2020-03-05 15:34:32 --> Output Class Initialized
INFO - 2020-03-05 15:34:32 --> Security Class Initialized
DEBUG - 2020-03-05 15:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 15:34:32 --> Input Class Initialized
INFO - 2020-03-05 15:34:32 --> Language Class Initialized
INFO - 2020-03-05 15:34:32 --> Loader Class Initialized
INFO - 2020-03-05 15:34:32 --> Helper loaded: url_helper
INFO - 2020-03-05 15:34:32 --> Helper loaded: string_helper
INFO - 2020-03-05 15:34:32 --> Database Driver Class Initialized
DEBUG - 2020-03-05 15:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 15:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 15:34:32 --> Controller Class Initialized
INFO - 2020-03-05 15:34:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 15:34:32 --> Pagination Class Initialized
INFO - 2020-03-05 15:34:32 --> Model "M_show" initialized
INFO - 2020-03-05 15:34:32 --> Helper loaded: form_helper
INFO - 2020-03-05 15:34:32 --> Form Validation Class Initialized
INFO - 2020-03-05 15:34:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 15:34:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 15:34:32 --> Final output sent to browser
DEBUG - 2020-03-05 15:34:32 --> Total execution time: 0.0068
INFO - 2020-03-05 16:32:22 --> Config Class Initialized
INFO - 2020-03-05 16:32:22 --> Hooks Class Initialized
DEBUG - 2020-03-05 16:32:22 --> UTF-8 Support Enabled
INFO - 2020-03-05 16:32:22 --> Utf8 Class Initialized
INFO - 2020-03-05 16:32:22 --> URI Class Initialized
DEBUG - 2020-03-05 16:32:22 --> No URI present. Default controller set.
INFO - 2020-03-05 16:32:22 --> Router Class Initialized
INFO - 2020-03-05 16:32:22 --> Output Class Initialized
INFO - 2020-03-05 16:32:22 --> Security Class Initialized
DEBUG - 2020-03-05 16:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 16:32:22 --> Input Class Initialized
INFO - 2020-03-05 16:32:22 --> Language Class Initialized
INFO - 2020-03-05 16:32:22 --> Loader Class Initialized
INFO - 2020-03-05 16:32:22 --> Helper loaded: url_helper
INFO - 2020-03-05 16:32:22 --> Helper loaded: string_helper
INFO - 2020-03-05 16:32:22 --> Database Driver Class Initialized
DEBUG - 2020-03-05 16:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 16:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 16:32:22 --> Controller Class Initialized
INFO - 2020-03-05 16:32:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 16:32:22 --> Pagination Class Initialized
INFO - 2020-03-05 16:32:22 --> Model "M_show" initialized
INFO - 2020-03-05 16:32:22 --> Helper loaded: form_helper
INFO - 2020-03-05 16:32:22 --> Form Validation Class Initialized
INFO - 2020-03-05 16:32:22 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 16:32:22 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 16:32:22 --> Final output sent to browser
DEBUG - 2020-03-05 16:32:22 --> Total execution time: 0.0332
INFO - 2020-03-05 16:33:15 --> Config Class Initialized
INFO - 2020-03-05 16:33:15 --> Hooks Class Initialized
DEBUG - 2020-03-05 16:33:15 --> UTF-8 Support Enabled
INFO - 2020-03-05 16:33:15 --> Utf8 Class Initialized
INFO - 2020-03-05 16:33:15 --> URI Class Initialized
INFO - 2020-03-05 16:33:15 --> Router Class Initialized
INFO - 2020-03-05 16:33:15 --> Output Class Initialized
INFO - 2020-03-05 16:33:15 --> Security Class Initialized
DEBUG - 2020-03-05 16:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 16:33:15 --> Input Class Initialized
INFO - 2020-03-05 16:33:15 --> Language Class Initialized
INFO - 2020-03-05 16:33:15 --> Loader Class Initialized
INFO - 2020-03-05 16:33:15 --> Helper loaded: url_helper
INFO - 2020-03-05 16:33:15 --> Helper loaded: string_helper
INFO - 2020-03-05 16:33:15 --> Database Driver Class Initialized
DEBUG - 2020-03-05 16:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 16:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 16:33:15 --> Controller Class Initialized
INFO - 2020-03-05 16:33:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 16:33:15 --> Pagination Class Initialized
INFO - 2020-03-05 16:33:15 --> Model "M_show" initialized
INFO - 2020-03-05 16:33:15 --> Helper loaded: form_helper
INFO - 2020-03-05 16:33:15 --> Form Validation Class Initialized
INFO - 2020-03-05 16:33:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 16:33:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 16:33:15 --> Final output sent to browser
DEBUG - 2020-03-05 16:33:15 --> Total execution time: 0.0088
INFO - 2020-03-05 16:54:08 --> Config Class Initialized
INFO - 2020-03-05 16:54:08 --> Hooks Class Initialized
DEBUG - 2020-03-05 16:54:08 --> UTF-8 Support Enabled
INFO - 2020-03-05 16:54:08 --> Utf8 Class Initialized
INFO - 2020-03-05 16:54:08 --> URI Class Initialized
INFO - 2020-03-05 16:54:08 --> Router Class Initialized
INFO - 2020-03-05 16:54:08 --> Output Class Initialized
INFO - 2020-03-05 16:54:08 --> Security Class Initialized
DEBUG - 2020-03-05 16:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 16:54:08 --> Input Class Initialized
INFO - 2020-03-05 16:54:08 --> Language Class Initialized
INFO - 2020-03-05 16:54:08 --> Loader Class Initialized
INFO - 2020-03-05 16:54:08 --> Helper loaded: url_helper
INFO - 2020-03-05 16:54:08 --> Helper loaded: string_helper
INFO - 2020-03-05 16:54:08 --> Database Driver Class Initialized
DEBUG - 2020-03-05 16:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 16:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 16:54:08 --> Controller Class Initialized
INFO - 2020-03-05 16:54:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 16:54:08 --> Pagination Class Initialized
INFO - 2020-03-05 16:54:08 --> Model "M_show" initialized
INFO - 2020-03-05 16:54:08 --> Helper loaded: form_helper
INFO - 2020-03-05 16:54:08 --> Form Validation Class Initialized
INFO - 2020-03-05 16:54:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 16:54:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 16:54:08 --> Final output sent to browser
DEBUG - 2020-03-05 16:54:08 --> Total execution time: 0.0808
INFO - 2020-03-05 16:54:09 --> Config Class Initialized
INFO - 2020-03-05 16:54:09 --> Hooks Class Initialized
DEBUG - 2020-03-05 16:54:09 --> UTF-8 Support Enabled
INFO - 2020-03-05 16:54:09 --> Utf8 Class Initialized
INFO - 2020-03-05 16:54:09 --> URI Class Initialized
INFO - 2020-03-05 16:54:09 --> Router Class Initialized
INFO - 2020-03-05 16:54:09 --> Output Class Initialized
INFO - 2020-03-05 16:54:09 --> Security Class Initialized
DEBUG - 2020-03-05 16:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 16:54:09 --> Input Class Initialized
INFO - 2020-03-05 16:54:09 --> Language Class Initialized
ERROR - 2020-03-05 16:54:09 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-05 17:17:08 --> Config Class Initialized
INFO - 2020-03-05 17:17:08 --> Hooks Class Initialized
DEBUG - 2020-03-05 17:17:08 --> UTF-8 Support Enabled
INFO - 2020-03-05 17:17:08 --> Utf8 Class Initialized
INFO - 2020-03-05 17:17:08 --> URI Class Initialized
DEBUG - 2020-03-05 17:17:08 --> No URI present. Default controller set.
INFO - 2020-03-05 17:17:08 --> Router Class Initialized
INFO - 2020-03-05 17:17:08 --> Output Class Initialized
INFO - 2020-03-05 17:17:08 --> Security Class Initialized
DEBUG - 2020-03-05 17:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 17:17:08 --> Input Class Initialized
INFO - 2020-03-05 17:17:08 --> Language Class Initialized
INFO - 2020-03-05 17:17:08 --> Loader Class Initialized
INFO - 2020-03-05 17:17:08 --> Helper loaded: url_helper
INFO - 2020-03-05 17:17:08 --> Helper loaded: string_helper
INFO - 2020-03-05 17:17:08 --> Database Driver Class Initialized
DEBUG - 2020-03-05 17:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 17:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 17:17:08 --> Controller Class Initialized
INFO - 2020-03-05 17:17:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 17:17:08 --> Pagination Class Initialized
INFO - 2020-03-05 17:17:08 --> Model "M_show" initialized
INFO - 2020-03-05 17:17:08 --> Helper loaded: form_helper
INFO - 2020-03-05 17:17:08 --> Form Validation Class Initialized
INFO - 2020-03-05 17:17:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 17:17:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 17:17:08 --> Final output sent to browser
DEBUG - 2020-03-05 17:17:08 --> Total execution time: 0.2731
INFO - 2020-03-05 17:17:14 --> Config Class Initialized
INFO - 2020-03-05 17:17:14 --> Hooks Class Initialized
DEBUG - 2020-03-05 17:17:14 --> UTF-8 Support Enabled
INFO - 2020-03-05 17:17:14 --> Utf8 Class Initialized
INFO - 2020-03-05 17:17:14 --> URI Class Initialized
DEBUG - 2020-03-05 17:17:14 --> No URI present. Default controller set.
INFO - 2020-03-05 17:17:14 --> Router Class Initialized
INFO - 2020-03-05 17:17:14 --> Output Class Initialized
INFO - 2020-03-05 17:17:14 --> Security Class Initialized
DEBUG - 2020-03-05 17:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 17:17:14 --> Input Class Initialized
INFO - 2020-03-05 17:17:14 --> Language Class Initialized
INFO - 2020-03-05 17:17:14 --> Loader Class Initialized
INFO - 2020-03-05 17:17:14 --> Helper loaded: url_helper
INFO - 2020-03-05 17:17:14 --> Helper loaded: string_helper
INFO - 2020-03-05 17:17:14 --> Database Driver Class Initialized
DEBUG - 2020-03-05 17:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 17:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 17:17:14 --> Controller Class Initialized
INFO - 2020-03-05 17:17:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 17:17:14 --> Pagination Class Initialized
INFO - 2020-03-05 17:17:14 --> Model "M_show" initialized
INFO - 2020-03-05 17:17:14 --> Helper loaded: form_helper
INFO - 2020-03-05 17:17:14 --> Form Validation Class Initialized
INFO - 2020-03-05 17:17:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 17:17:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 17:17:14 --> Final output sent to browser
DEBUG - 2020-03-05 17:17:14 --> Total execution time: 0.0162
INFO - 2020-03-05 17:17:15 --> Config Class Initialized
INFO - 2020-03-05 17:17:15 --> Hooks Class Initialized
DEBUG - 2020-03-05 17:17:15 --> UTF-8 Support Enabled
INFO - 2020-03-05 17:17:15 --> Utf8 Class Initialized
INFO - 2020-03-05 17:17:15 --> URI Class Initialized
DEBUG - 2020-03-05 17:17:15 --> No URI present. Default controller set.
INFO - 2020-03-05 17:17:15 --> Router Class Initialized
INFO - 2020-03-05 17:17:15 --> Output Class Initialized
INFO - 2020-03-05 17:17:15 --> Security Class Initialized
DEBUG - 2020-03-05 17:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 17:17:15 --> Input Class Initialized
INFO - 2020-03-05 17:17:15 --> Language Class Initialized
INFO - 2020-03-05 17:17:15 --> Loader Class Initialized
INFO - 2020-03-05 17:17:15 --> Helper loaded: url_helper
INFO - 2020-03-05 17:17:15 --> Helper loaded: string_helper
INFO - 2020-03-05 17:17:15 --> Database Driver Class Initialized
DEBUG - 2020-03-05 17:17:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 17:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 17:17:15 --> Controller Class Initialized
INFO - 2020-03-05 17:17:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 17:17:15 --> Pagination Class Initialized
INFO - 2020-03-05 17:17:15 --> Model "M_show" initialized
INFO - 2020-03-05 17:17:15 --> Helper loaded: form_helper
INFO - 2020-03-05 17:17:15 --> Form Validation Class Initialized
INFO - 2020-03-05 17:17:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 17:17:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 17:17:15 --> Final output sent to browser
DEBUG - 2020-03-05 17:17:15 --> Total execution time: 0.0052
INFO - 2020-03-05 17:17:36 --> Config Class Initialized
INFO - 2020-03-05 17:17:36 --> Hooks Class Initialized
DEBUG - 2020-03-05 17:17:36 --> UTF-8 Support Enabled
INFO - 2020-03-05 17:17:36 --> Utf8 Class Initialized
INFO - 2020-03-05 17:17:36 --> URI Class Initialized
INFO - 2020-03-05 17:17:36 --> Router Class Initialized
INFO - 2020-03-05 17:17:36 --> Output Class Initialized
INFO - 2020-03-05 17:17:36 --> Security Class Initialized
DEBUG - 2020-03-05 17:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 17:17:36 --> Input Class Initialized
INFO - 2020-03-05 17:17:36 --> Language Class Initialized
INFO - 2020-03-05 17:17:36 --> Loader Class Initialized
INFO - 2020-03-05 17:17:36 --> Helper loaded: url_helper
INFO - 2020-03-05 17:17:36 --> Helper loaded: string_helper
INFO - 2020-03-05 17:17:36 --> Database Driver Class Initialized
DEBUG - 2020-03-05 17:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 17:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 17:17:36 --> Controller Class Initialized
INFO - 2020-03-05 17:17:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 17:17:36 --> Pagination Class Initialized
INFO - 2020-03-05 17:17:36 --> Model "M_show" initialized
INFO - 2020-03-05 17:17:36 --> Helper loaded: form_helper
INFO - 2020-03-05 17:17:36 --> Form Validation Class Initialized
INFO - 2020-03-05 17:17:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 17:17:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 17:17:36 --> Final output sent to browser
DEBUG - 2020-03-05 17:17:36 --> Total execution time: 0.0093
INFO - 2020-03-05 17:17:40 --> Config Class Initialized
INFO - 2020-03-05 17:17:40 --> Hooks Class Initialized
DEBUG - 2020-03-05 17:17:40 --> UTF-8 Support Enabled
INFO - 2020-03-05 17:17:40 --> Utf8 Class Initialized
INFO - 2020-03-05 17:17:40 --> URI Class Initialized
INFO - 2020-03-05 17:17:40 --> Router Class Initialized
INFO - 2020-03-05 17:17:40 --> Output Class Initialized
INFO - 2020-03-05 17:17:40 --> Security Class Initialized
DEBUG - 2020-03-05 17:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 17:17:40 --> Input Class Initialized
INFO - 2020-03-05 17:17:40 --> Language Class Initialized
INFO - 2020-03-05 17:17:40 --> Loader Class Initialized
INFO - 2020-03-05 17:17:40 --> Helper loaded: url_helper
INFO - 2020-03-05 17:17:40 --> Helper loaded: string_helper
INFO - 2020-03-05 17:17:40 --> Database Driver Class Initialized
DEBUG - 2020-03-05 17:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 17:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 17:17:40 --> Controller Class Initialized
INFO - 2020-03-05 17:17:40 --> Model "M_tiket" initialized
INFO - 2020-03-05 17:17:40 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 17:17:40 --> Model "M_pesan" initialized
INFO - 2020-03-05 17:17:40 --> Helper loaded: form_helper
INFO - 2020-03-05 17:17:40 --> Form Validation Class Initialized
INFO - 2020-03-05 17:17:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 17:17:40 --> Final output sent to browser
DEBUG - 2020-03-05 17:17:40 --> Total execution time: 0.0382
INFO - 2020-03-05 17:17:45 --> Config Class Initialized
INFO - 2020-03-05 17:17:45 --> Hooks Class Initialized
DEBUG - 2020-03-05 17:17:45 --> UTF-8 Support Enabled
INFO - 2020-03-05 17:17:45 --> Utf8 Class Initialized
INFO - 2020-03-05 17:17:45 --> URI Class Initialized
DEBUG - 2020-03-05 17:17:45 --> No URI present. Default controller set.
INFO - 2020-03-05 17:17:45 --> Router Class Initialized
INFO - 2020-03-05 17:17:45 --> Output Class Initialized
INFO - 2020-03-05 17:17:45 --> Security Class Initialized
DEBUG - 2020-03-05 17:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 17:17:45 --> Input Class Initialized
INFO - 2020-03-05 17:17:45 --> Language Class Initialized
INFO - 2020-03-05 17:17:45 --> Loader Class Initialized
INFO - 2020-03-05 17:17:45 --> Helper loaded: url_helper
INFO - 2020-03-05 17:17:45 --> Helper loaded: string_helper
INFO - 2020-03-05 17:17:45 --> Database Driver Class Initialized
DEBUG - 2020-03-05 17:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 17:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 17:17:45 --> Controller Class Initialized
INFO - 2020-03-05 17:17:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 17:17:45 --> Pagination Class Initialized
INFO - 2020-03-05 17:17:45 --> Model "M_show" initialized
INFO - 2020-03-05 17:17:45 --> Helper loaded: form_helper
INFO - 2020-03-05 17:17:45 --> Form Validation Class Initialized
INFO - 2020-03-05 17:17:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 17:17:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 17:17:45 --> Final output sent to browser
DEBUG - 2020-03-05 17:17:45 --> Total execution time: 0.0086
INFO - 2020-03-05 17:18:13 --> Config Class Initialized
INFO - 2020-03-05 17:18:13 --> Hooks Class Initialized
DEBUG - 2020-03-05 17:18:13 --> UTF-8 Support Enabled
INFO - 2020-03-05 17:18:13 --> Utf8 Class Initialized
INFO - 2020-03-05 17:18:13 --> URI Class Initialized
INFO - 2020-03-05 17:18:13 --> Router Class Initialized
INFO - 2020-03-05 17:18:13 --> Output Class Initialized
INFO - 2020-03-05 17:18:13 --> Security Class Initialized
DEBUG - 2020-03-05 17:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 17:18:13 --> Input Class Initialized
INFO - 2020-03-05 17:18:13 --> Language Class Initialized
INFO - 2020-03-05 17:18:13 --> Loader Class Initialized
INFO - 2020-03-05 17:18:13 --> Helper loaded: url_helper
INFO - 2020-03-05 17:18:13 --> Helper loaded: string_helper
INFO - 2020-03-05 17:18:13 --> Database Driver Class Initialized
DEBUG - 2020-03-05 17:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 17:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 17:18:13 --> Controller Class Initialized
INFO - 2020-03-05 17:18:13 --> Model "M_tiket" initialized
INFO - 2020-03-05 17:18:13 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 17:18:13 --> Model "M_pesan" initialized
INFO - 2020-03-05 17:18:13 --> Helper loaded: form_helper
INFO - 2020-03-05 17:18:13 --> Form Validation Class Initialized
INFO - 2020-03-05 17:18:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-05 17:18:13 --> Final output sent to browser
DEBUG - 2020-03-05 17:18:13 --> Total execution time: 0.0213
INFO - 2020-03-05 17:19:36 --> Config Class Initialized
INFO - 2020-03-05 17:19:36 --> Hooks Class Initialized
DEBUG - 2020-03-05 17:19:36 --> UTF-8 Support Enabled
INFO - 2020-03-05 17:19:36 --> Utf8 Class Initialized
INFO - 2020-03-05 17:19:36 --> URI Class Initialized
INFO - 2020-03-05 17:19:36 --> Router Class Initialized
INFO - 2020-03-05 17:19:36 --> Output Class Initialized
INFO - 2020-03-05 17:19:36 --> Security Class Initialized
DEBUG - 2020-03-05 17:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 17:19:36 --> Input Class Initialized
INFO - 2020-03-05 17:19:36 --> Language Class Initialized
INFO - 2020-03-05 17:19:36 --> Loader Class Initialized
INFO - 2020-03-05 17:19:36 --> Helper loaded: url_helper
INFO - 2020-03-05 17:19:36 --> Helper loaded: string_helper
INFO - 2020-03-05 17:19:36 --> Database Driver Class Initialized
DEBUG - 2020-03-05 17:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 17:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 17:19:36 --> Controller Class Initialized
INFO - 2020-03-05 17:19:36 --> Model "M_tiket" initialized
INFO - 2020-03-05 17:19:36 --> Model "M_pengunjung" initialized
INFO - 2020-03-05 17:19:36 --> Model "M_pesan" initialized
INFO - 2020-03-05 17:19:36 --> Helper loaded: form_helper
INFO - 2020-03-05 17:19:36 --> Form Validation Class Initialized
INFO - 2020-03-05 17:19:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-05 17:19:36 --> Final output sent to browser
DEBUG - 2020-03-05 17:19:36 --> Total execution time: 0.0348
INFO - 2020-03-05 17:19:37 --> Config Class Initialized
INFO - 2020-03-05 17:19:37 --> Hooks Class Initialized
DEBUG - 2020-03-05 17:19:37 --> UTF-8 Support Enabled
INFO - 2020-03-05 17:19:37 --> Utf8 Class Initialized
INFO - 2020-03-05 17:19:37 --> URI Class Initialized
INFO - 2020-03-05 17:19:37 --> Router Class Initialized
INFO - 2020-03-05 17:19:37 --> Output Class Initialized
INFO - 2020-03-05 17:19:37 --> Security Class Initialized
DEBUG - 2020-03-05 17:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 17:19:37 --> Input Class Initialized
INFO - 2020-03-05 17:19:37 --> Language Class Initialized
INFO - 2020-03-05 17:19:37 --> Loader Class Initialized
INFO - 2020-03-05 17:19:37 --> Helper loaded: url_helper
INFO - 2020-03-05 17:19:37 --> Helper loaded: string_helper
INFO - 2020-03-05 17:19:37 --> Database Driver Class Initialized
DEBUG - 2020-03-05 17:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 17:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 17:19:37 --> Controller Class Initialized
INFO - 2020-03-05 17:19:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 17:19:37 --> Pagination Class Initialized
INFO - 2020-03-05 17:19:37 --> Model "M_show" initialized
INFO - 2020-03-05 17:19:37 --> Helper loaded: form_helper
INFO - 2020-03-05 17:19:37 --> Form Validation Class Initialized
INFO - 2020-03-05 17:19:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 17:19:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-05 17:19:37 --> Final output sent to browser
DEBUG - 2020-03-05 17:19:37 --> Total execution time: 0.0115
INFO - 2020-03-05 17:19:39 --> Config Class Initialized
INFO - 2020-03-05 17:19:39 --> Hooks Class Initialized
DEBUG - 2020-03-05 17:19:39 --> UTF-8 Support Enabled
INFO - 2020-03-05 17:19:39 --> Utf8 Class Initialized
INFO - 2020-03-05 17:19:39 --> URI Class Initialized
DEBUG - 2020-03-05 17:19:39 --> No URI present. Default controller set.
INFO - 2020-03-05 17:19:39 --> Router Class Initialized
INFO - 2020-03-05 17:19:39 --> Output Class Initialized
INFO - 2020-03-05 17:19:39 --> Security Class Initialized
DEBUG - 2020-03-05 17:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 17:19:39 --> Input Class Initialized
INFO - 2020-03-05 17:19:39 --> Language Class Initialized
INFO - 2020-03-05 17:19:39 --> Loader Class Initialized
INFO - 2020-03-05 17:19:39 --> Helper loaded: url_helper
INFO - 2020-03-05 17:19:39 --> Helper loaded: string_helper
INFO - 2020-03-05 17:19:39 --> Database Driver Class Initialized
DEBUG - 2020-03-05 17:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 17:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 17:19:39 --> Controller Class Initialized
INFO - 2020-03-05 17:19:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 17:19:39 --> Pagination Class Initialized
INFO - 2020-03-05 17:19:39 --> Model "M_show" initialized
INFO - 2020-03-05 17:19:39 --> Helper loaded: form_helper
INFO - 2020-03-05 17:19:39 --> Form Validation Class Initialized
INFO - 2020-03-05 17:19:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 17:19:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 17:19:39 --> Final output sent to browser
DEBUG - 2020-03-05 17:19:39 --> Total execution time: 0.0057
INFO - 2020-03-05 17:19:39 --> Config Class Initialized
INFO - 2020-03-05 17:19:39 --> Hooks Class Initialized
DEBUG - 2020-03-05 17:19:39 --> UTF-8 Support Enabled
INFO - 2020-03-05 17:19:39 --> Utf8 Class Initialized
INFO - 2020-03-05 17:19:39 --> URI Class Initialized
DEBUG - 2020-03-05 17:19:39 --> No URI present. Default controller set.
INFO - 2020-03-05 17:19:39 --> Router Class Initialized
INFO - 2020-03-05 17:19:39 --> Output Class Initialized
INFO - 2020-03-05 17:19:39 --> Security Class Initialized
DEBUG - 2020-03-05 17:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 17:19:39 --> Input Class Initialized
INFO - 2020-03-05 17:19:39 --> Language Class Initialized
INFO - 2020-03-05 17:19:39 --> Loader Class Initialized
INFO - 2020-03-05 17:19:39 --> Helper loaded: url_helper
INFO - 2020-03-05 17:19:39 --> Helper loaded: string_helper
INFO - 2020-03-05 17:19:39 --> Database Driver Class Initialized
DEBUG - 2020-03-05 17:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 17:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 17:19:39 --> Controller Class Initialized
INFO - 2020-03-05 17:19:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 17:19:39 --> Pagination Class Initialized
INFO - 2020-03-05 17:19:39 --> Model "M_show" initialized
INFO - 2020-03-05 17:19:39 --> Helper loaded: form_helper
INFO - 2020-03-05 17:19:39 --> Form Validation Class Initialized
INFO - 2020-03-05 17:19:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 17:19:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 17:19:39 --> Final output sent to browser
DEBUG - 2020-03-05 17:19:39 --> Total execution time: 0.0038
INFO - 2020-03-05 18:40:32 --> Config Class Initialized
INFO - 2020-03-05 18:40:32 --> Hooks Class Initialized
DEBUG - 2020-03-05 18:40:32 --> UTF-8 Support Enabled
INFO - 2020-03-05 18:40:32 --> Utf8 Class Initialized
INFO - 2020-03-05 18:40:32 --> URI Class Initialized
DEBUG - 2020-03-05 18:40:32 --> No URI present. Default controller set.
INFO - 2020-03-05 18:40:32 --> Router Class Initialized
INFO - 2020-03-05 18:40:32 --> Output Class Initialized
INFO - 2020-03-05 18:40:32 --> Security Class Initialized
DEBUG - 2020-03-05 18:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 18:40:32 --> Input Class Initialized
INFO - 2020-03-05 18:40:32 --> Language Class Initialized
INFO - 2020-03-05 18:40:32 --> Loader Class Initialized
INFO - 2020-03-05 18:40:32 --> Helper loaded: url_helper
INFO - 2020-03-05 18:40:32 --> Helper loaded: string_helper
INFO - 2020-03-05 18:40:32 --> Database Driver Class Initialized
DEBUG - 2020-03-05 18:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 18:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 18:40:32 --> Controller Class Initialized
INFO - 2020-03-05 18:40:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 18:40:32 --> Pagination Class Initialized
INFO - 2020-03-05 18:40:32 --> Model "M_show" initialized
INFO - 2020-03-05 18:40:32 --> Helper loaded: form_helper
INFO - 2020-03-05 18:40:32 --> Form Validation Class Initialized
INFO - 2020-03-05 18:40:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 18:40:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 18:40:32 --> Final output sent to browser
DEBUG - 2020-03-05 18:40:32 --> Total execution time: 0.0464
INFO - 2020-03-05 21:53:55 --> Config Class Initialized
INFO - 2020-03-05 21:53:55 --> Hooks Class Initialized
DEBUG - 2020-03-05 21:53:55 --> UTF-8 Support Enabled
INFO - 2020-03-05 21:53:55 --> Utf8 Class Initialized
INFO - 2020-03-05 21:53:55 --> URI Class Initialized
DEBUG - 2020-03-05 21:53:55 --> No URI present. Default controller set.
INFO - 2020-03-05 21:53:55 --> Router Class Initialized
INFO - 2020-03-05 21:53:55 --> Output Class Initialized
INFO - 2020-03-05 21:53:55 --> Security Class Initialized
DEBUG - 2020-03-05 21:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 21:53:55 --> Input Class Initialized
INFO - 2020-03-05 21:53:55 --> Language Class Initialized
INFO - 2020-03-05 21:53:55 --> Loader Class Initialized
INFO - 2020-03-05 21:53:55 --> Helper loaded: url_helper
INFO - 2020-03-05 21:53:55 --> Helper loaded: string_helper
INFO - 2020-03-05 21:53:55 --> Database Driver Class Initialized
DEBUG - 2020-03-05 21:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 21:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 21:53:55 --> Controller Class Initialized
INFO - 2020-03-05 21:53:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 21:53:55 --> Pagination Class Initialized
INFO - 2020-03-05 21:53:55 --> Model "M_show" initialized
INFO - 2020-03-05 21:53:55 --> Helper loaded: form_helper
INFO - 2020-03-05 21:53:55 --> Form Validation Class Initialized
INFO - 2020-03-05 21:53:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 21:53:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 21:53:55 --> Final output sent to browser
DEBUG - 2020-03-05 21:53:55 --> Total execution time: 0.1643
INFO - 2020-03-05 23:06:47 --> Config Class Initialized
INFO - 2020-03-05 23:06:47 --> Hooks Class Initialized
DEBUG - 2020-03-05 23:06:47 --> UTF-8 Support Enabled
INFO - 2020-03-05 23:06:47 --> Utf8 Class Initialized
INFO - 2020-03-05 23:06:47 --> URI Class Initialized
DEBUG - 2020-03-05 23:06:47 --> No URI present. Default controller set.
INFO - 2020-03-05 23:06:47 --> Router Class Initialized
INFO - 2020-03-05 23:06:47 --> Output Class Initialized
INFO - 2020-03-05 23:06:47 --> Security Class Initialized
DEBUG - 2020-03-05 23:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 23:06:47 --> Input Class Initialized
INFO - 2020-03-05 23:06:47 --> Language Class Initialized
INFO - 2020-03-05 23:06:47 --> Loader Class Initialized
INFO - 2020-03-05 23:06:47 --> Helper loaded: url_helper
INFO - 2020-03-05 23:06:47 --> Helper loaded: string_helper
INFO - 2020-03-05 23:06:47 --> Database Driver Class Initialized
DEBUG - 2020-03-05 23:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 23:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 23:06:47 --> Controller Class Initialized
INFO - 2020-03-05 23:06:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-05 23:06:47 --> Pagination Class Initialized
INFO - 2020-03-05 23:06:47 --> Model "M_show" initialized
INFO - 2020-03-05 23:06:47 --> Helper loaded: form_helper
INFO - 2020-03-05 23:06:47 --> Form Validation Class Initialized
INFO - 2020-03-05 23:06:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-05 23:06:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-05 23:06:47 --> Final output sent to browser
DEBUG - 2020-03-05 23:06:47 --> Total execution time: 0.0466
