<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-01-28 18:16:11 --> Config Class Initialized
INFO - 2020-01-28 18:16:11 --> Hooks Class Initialized
DEBUG - 2020-01-28 18:16:12 --> UTF-8 Support Enabled
INFO - 2020-01-28 18:16:12 --> Utf8 Class Initialized
INFO - 2020-01-28 18:16:12 --> URI Class Initialized
DEBUG - 2020-01-28 18:16:12 --> No URI present. Default controller set.
INFO - 2020-01-28 18:16:12 --> Router Class Initialized
INFO - 2020-01-28 18:16:13 --> Output Class Initialized
INFO - 2020-01-28 18:16:13 --> Security Class Initialized
DEBUG - 2020-01-28 18:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-28 18:16:13 --> Input Class Initialized
INFO - 2020-01-28 18:16:13 --> Language Class Initialized
INFO - 2020-01-28 18:16:13 --> Loader Class Initialized
INFO - 2020-01-28 18:16:14 --> Helper loaded: url_helper
INFO - 2020-01-28 18:16:14 --> Database Driver Class Initialized
DEBUG - 2020-01-28 18:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-28 18:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-28 18:16:14 --> Controller Class Initialized
INFO - 2020-01-28 18:16:15 --> Model "M_login" initialized
INFO - 2020-01-28 18:16:15 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/login.php
INFO - 2020-01-28 18:16:15 --> Final output sent to browser
DEBUG - 2020-01-28 18:16:15 --> Total execution time: 4.0902
INFO - 2020-01-28 18:16:23 --> Config Class Initialized
INFO - 2020-01-28 18:16:24 --> Hooks Class Initialized
DEBUG - 2020-01-28 18:16:24 --> UTF-8 Support Enabled
INFO - 2020-01-28 18:16:24 --> Utf8 Class Initialized
INFO - 2020-01-28 18:16:24 --> URI Class Initialized
INFO - 2020-01-28 18:16:24 --> Router Class Initialized
INFO - 2020-01-28 18:16:24 --> Output Class Initialized
INFO - 2020-01-28 18:16:24 --> Security Class Initialized
DEBUG - 2020-01-28 18:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-28 18:16:24 --> Input Class Initialized
INFO - 2020-01-28 18:16:24 --> Language Class Initialized
INFO - 2020-01-28 18:16:24 --> Loader Class Initialized
INFO - 2020-01-28 18:16:24 --> Helper loaded: url_helper
INFO - 2020-01-28 18:16:24 --> Database Driver Class Initialized
DEBUG - 2020-01-28 18:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-28 18:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-28 18:16:24 --> Controller Class Initialized
INFO - 2020-01-28 18:16:24 --> Model "M_login" initialized
INFO - 2020-01-28 18:16:24 --> Config Class Initialized
INFO - 2020-01-28 18:16:24 --> Hooks Class Initialized
DEBUG - 2020-01-28 18:16:24 --> UTF-8 Support Enabled
INFO - 2020-01-28 18:16:24 --> Utf8 Class Initialized
INFO - 2020-01-28 18:16:24 --> URI Class Initialized
INFO - 2020-01-28 18:16:24 --> Router Class Initialized
INFO - 2020-01-28 18:16:24 --> Output Class Initialized
INFO - 2020-01-28 18:16:24 --> Security Class Initialized
DEBUG - 2020-01-28 18:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-28 18:16:24 --> Input Class Initialized
INFO - 2020-01-28 18:16:24 --> Language Class Initialized
INFO - 2020-01-28 18:16:25 --> Loader Class Initialized
INFO - 2020-01-28 18:16:25 --> Helper loaded: url_helper
INFO - 2020-01-28 18:16:25 --> Database Driver Class Initialized
DEBUG - 2020-01-28 18:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-28 18:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-28 18:16:25 --> Controller Class Initialized
INFO - 2020-01-28 18:16:25 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-28 18:16:25 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/beranda.php
INFO - 2020-01-28 18:16:25 --> Final output sent to browser
DEBUG - 2020-01-28 18:16:26 --> Total execution time: 1.5553
INFO - 2020-01-28 18:16:26 --> Config Class Initialized
INFO - 2020-01-28 18:16:26 --> Config Class Initialized
INFO - 2020-01-28 18:16:26 --> Hooks Class Initialized
INFO - 2020-01-28 18:16:26 --> Hooks Class Initialized
DEBUG - 2020-01-28 18:16:26 --> UTF-8 Support Enabled
DEBUG - 2020-01-28 18:16:26 --> UTF-8 Support Enabled
INFO - 2020-01-28 18:16:26 --> Utf8 Class Initialized
INFO - 2020-01-28 18:16:26 --> Utf8 Class Initialized
INFO - 2020-01-28 18:16:26 --> URI Class Initialized
INFO - 2020-01-28 18:16:26 --> URI Class Initialized
INFO - 2020-01-28 18:16:26 --> Router Class Initialized
INFO - 2020-01-28 18:16:26 --> Router Class Initialized
INFO - 2020-01-28 18:16:26 --> Output Class Initialized
INFO - 2020-01-28 18:16:26 --> Output Class Initialized
INFO - 2020-01-28 18:16:26 --> Security Class Initialized
INFO - 2020-01-28 18:16:26 --> Security Class Initialized
DEBUG - 2020-01-28 18:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-28 18:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-28 18:16:26 --> Input Class Initialized
INFO - 2020-01-28 18:16:26 --> Input Class Initialized
INFO - 2020-01-28 18:16:26 --> Language Class Initialized
INFO - 2020-01-28 18:16:26 --> Language Class Initialized
ERROR - 2020-01-28 18:16:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-28 18:16:26 --> 404 Page Not Found: Assets/js
INFO - 2020-01-28 18:16:26 --> Config Class Initialized
INFO - 2020-01-28 18:16:26 --> Hooks Class Initialized
DEBUG - 2020-01-28 18:16:26 --> UTF-8 Support Enabled
INFO - 2020-01-28 18:16:26 --> Utf8 Class Initialized
INFO - 2020-01-28 18:16:26 --> URI Class Initialized
INFO - 2020-01-28 18:16:26 --> Router Class Initialized
INFO - 2020-01-28 18:16:26 --> Output Class Initialized
INFO - 2020-01-28 18:16:27 --> Security Class Initialized
DEBUG - 2020-01-28 18:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-28 18:16:27 --> Input Class Initialized
INFO - 2020-01-28 18:16:27 --> Language Class Initialized
ERROR - 2020-01-28 18:16:27 --> 404 Page Not Found: Assets/js
INFO - 2020-01-28 18:16:29 --> Config Class Initialized
INFO - 2020-01-28 18:16:29 --> Hooks Class Initialized
DEBUG - 2020-01-28 18:16:29 --> UTF-8 Support Enabled
INFO - 2020-01-28 18:16:29 --> Utf8 Class Initialized
INFO - 2020-01-28 18:16:29 --> URI Class Initialized
INFO - 2020-01-28 18:16:30 --> Router Class Initialized
INFO - 2020-01-28 18:16:30 --> Output Class Initialized
INFO - 2020-01-28 18:16:30 --> Security Class Initialized
DEBUG - 2020-01-28 18:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-28 18:16:30 --> Input Class Initialized
INFO - 2020-01-28 18:16:30 --> Language Class Initialized
INFO - 2020-01-28 18:16:30 --> Loader Class Initialized
INFO - 2020-01-28 18:16:30 --> Helper loaded: url_helper
INFO - 2020-01-28 18:16:30 --> Database Driver Class Initialized
DEBUG - 2020-01-28 18:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-28 18:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-28 18:16:30 --> Controller Class Initialized
INFO - 2020-01-28 18:16:30 --> Model "M_login" initialized
INFO - 2020-01-28 18:16:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-28 18:16:30 --> Pagination Class Initialized
INFO - 2020-01-28 18:16:30 --> Model "M_show" initialized
INFO - 2020-01-28 18:16:31 --> Helper loaded: form_helper
INFO - 2020-01-28 18:16:31 --> Form Validation Class Initialized
INFO - 2020-01-28 18:16:31 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-28 18:16:31 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/show/lihat_show.php
INFO - 2020-01-28 18:16:31 --> Final output sent to browser
DEBUG - 2020-01-28 18:16:31 --> Total execution time: 1.8349
INFO - 2020-01-28 18:16:31 --> Config Class Initialized
INFO - 2020-01-28 18:16:31 --> Config Class Initialized
INFO - 2020-01-28 18:16:31 --> Hooks Class Initialized
INFO - 2020-01-28 18:16:31 --> Hooks Class Initialized
DEBUG - 2020-01-28 18:16:31 --> UTF-8 Support Enabled
DEBUG - 2020-01-28 18:16:31 --> UTF-8 Support Enabled
INFO - 2020-01-28 18:16:31 --> Utf8 Class Initialized
INFO - 2020-01-28 18:16:31 --> Utf8 Class Initialized
INFO - 2020-01-28 18:16:31 --> URI Class Initialized
INFO - 2020-01-28 18:16:31 --> URI Class Initialized
INFO - 2020-01-28 18:16:31 --> Router Class Initialized
INFO - 2020-01-28 18:16:31 --> Router Class Initialized
INFO - 2020-01-28 18:16:31 --> Output Class Initialized
INFO - 2020-01-28 18:16:31 --> Output Class Initialized
INFO - 2020-01-28 18:16:31 --> Security Class Initialized
INFO - 2020-01-28 18:16:31 --> Security Class Initialized
DEBUG - 2020-01-28 18:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-28 18:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-28 18:16:31 --> Input Class Initialized
INFO - 2020-01-28 18:16:31 --> Input Class Initialized
INFO - 2020-01-28 18:16:32 --> Language Class Initialized
INFO - 2020-01-28 18:16:32 --> Language Class Initialized
ERROR - 2020-01-28 18:16:32 --> 404 Page Not Found: Show/assets
ERROR - 2020-01-28 18:16:32 --> 404 Page Not Found: Show/assets
INFO - 2020-01-28 18:16:32 --> Config Class Initialized
INFO - 2020-01-28 18:16:32 --> Hooks Class Initialized
DEBUG - 2020-01-28 18:16:32 --> UTF-8 Support Enabled
INFO - 2020-01-28 18:16:32 --> Utf8 Class Initialized
INFO - 2020-01-28 18:16:32 --> URI Class Initialized
INFO - 2020-01-28 18:16:32 --> Router Class Initialized
INFO - 2020-01-28 18:16:32 --> Output Class Initialized
INFO - 2020-01-28 18:16:32 --> Security Class Initialized
DEBUG - 2020-01-28 18:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-28 18:16:32 --> Input Class Initialized
INFO - 2020-01-28 18:16:32 --> Language Class Initialized
ERROR - 2020-01-28 18:16:32 --> 404 Page Not Found: Show/assets
INFO - 2020-01-28 18:16:39 --> Config Class Initialized
INFO - 2020-01-28 18:16:39 --> Hooks Class Initialized
DEBUG - 2020-01-28 18:16:39 --> UTF-8 Support Enabled
INFO - 2020-01-28 18:16:39 --> Utf8 Class Initialized
INFO - 2020-01-28 18:16:39 --> URI Class Initialized
INFO - 2020-01-28 18:16:40 --> Router Class Initialized
INFO - 2020-01-28 18:16:40 --> Output Class Initialized
INFO - 2020-01-28 18:16:40 --> Security Class Initialized
DEBUG - 2020-01-28 18:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-28 18:16:40 --> Input Class Initialized
INFO - 2020-01-28 18:16:40 --> Language Class Initialized
INFO - 2020-01-28 18:16:40 --> Loader Class Initialized
INFO - 2020-01-28 18:16:40 --> Helper loaded: url_helper
INFO - 2020-01-28 18:16:40 --> Database Driver Class Initialized
DEBUG - 2020-01-28 18:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-28 18:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-28 18:16:40 --> Controller Class Initialized
INFO - 2020-01-28 18:16:40 --> Model "M_login" initialized
INFO - 2020-01-28 18:16:40 --> Model "M_tiket" initialized
INFO - 2020-01-28 18:16:40 --> Helper loaded: form_helper
INFO - 2020-01-28 18:16:40 --> Form Validation Class Initialized
INFO - 2020-01-28 18:16:40 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-28 18:16:40 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-28 18:16:41 --> Final output sent to browser
DEBUG - 2020-01-28 18:16:41 --> Total execution time: 1.1809
INFO - 2020-01-28 18:16:41 --> Config Class Initialized
INFO - 2020-01-28 18:16:41 --> Config Class Initialized
INFO - 2020-01-28 18:16:41 --> Hooks Class Initialized
INFO - 2020-01-28 18:16:41 --> Hooks Class Initialized
INFO - 2020-01-28 18:16:41 --> Config Class Initialized
INFO - 2020-01-28 18:16:41 --> Config Class Initialized
INFO - 2020-01-28 18:16:41 --> Config Class Initialized
INFO - 2020-01-28 18:16:41 --> Config Class Initialized
INFO - 2020-01-28 18:16:41 --> Hooks Class Initialized
INFO - 2020-01-28 18:16:41 --> Hooks Class Initialized
INFO - 2020-01-28 18:16:41 --> Hooks Class Initialized
INFO - 2020-01-28 18:16:41 --> Hooks Class Initialized
DEBUG - 2020-01-28 18:16:41 --> UTF-8 Support Enabled
DEBUG - 2020-01-28 18:16:41 --> UTF-8 Support Enabled
INFO - 2020-01-28 18:16:41 --> Utf8 Class Initialized
INFO - 2020-01-28 18:16:41 --> Utf8 Class Initialized
DEBUG - 2020-01-28 18:16:41 --> UTF-8 Support Enabled
DEBUG - 2020-01-28 18:16:41 --> UTF-8 Support Enabled
DEBUG - 2020-01-28 18:16:41 --> UTF-8 Support Enabled
DEBUG - 2020-01-28 18:16:41 --> UTF-8 Support Enabled
INFO - 2020-01-28 18:16:41 --> Utf8 Class Initialized
INFO - 2020-01-28 18:16:41 --> Utf8 Class Initialized
INFO - 2020-01-28 18:16:41 --> Utf8 Class Initialized
INFO - 2020-01-28 18:16:41 --> Utf8 Class Initialized
INFO - 2020-01-28 18:16:41 --> URI Class Initialized
INFO - 2020-01-28 18:16:41 --> URI Class Initialized
INFO - 2020-01-28 18:16:41 --> URI Class Initialized
INFO - 2020-01-28 18:16:41 --> URI Class Initialized
INFO - 2020-01-28 18:16:41 --> Router Class Initialized
INFO - 2020-01-28 18:16:41 --> URI Class Initialized
INFO - 2020-01-28 18:16:41 --> URI Class Initialized
INFO - 2020-01-28 18:16:41 --> Router Class Initialized
INFO - 2020-01-28 18:16:41 --> Router Class Initialized
INFO - 2020-01-28 18:16:41 --> Router Class Initialized
INFO - 2020-01-28 18:16:41 --> Output Class Initialized
INFO - 2020-01-28 18:16:41 --> Router Class Initialized
INFO - 2020-01-28 18:16:41 --> Router Class Initialized
INFO - 2020-01-28 18:16:41 --> Output Class Initialized
INFO - 2020-01-28 18:16:41 --> Output Class Initialized
INFO - 2020-01-28 18:16:41 --> Output Class Initialized
INFO - 2020-01-28 18:16:41 --> Security Class Initialized
INFO - 2020-01-28 18:16:41 --> Security Class Initialized
INFO - 2020-01-28 18:16:41 --> Output Class Initialized
INFO - 2020-01-28 18:16:41 --> Output Class Initialized
DEBUG - 2020-01-28 18:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-28 18:16:41 --> Security Class Initialized
INFO - 2020-01-28 18:16:41 --> Security Class Initialized
DEBUG - 2020-01-28 18:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-28 18:16:41 --> Security Class Initialized
INFO - 2020-01-28 18:16:41 --> Security Class Initialized
INFO - 2020-01-28 18:16:41 --> Input Class Initialized
INFO - 2020-01-28 18:16:41 --> Input Class Initialized
DEBUG - 2020-01-28 18:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-28 18:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-28 18:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-28 18:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-28 18:16:41 --> Input Class Initialized
INFO - 2020-01-28 18:16:41 --> Input Class Initialized
INFO - 2020-01-28 18:16:41 --> Input Class Initialized
INFO - 2020-01-28 18:16:41 --> Input Class Initialized
INFO - 2020-01-28 18:16:41 --> Language Class Initialized
INFO - 2020-01-28 18:16:41 --> Language Class Initialized
INFO - 2020-01-28 18:16:41 --> Language Class Initialized
ERROR - 2020-01-28 18:16:41 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-01-28 18:16:41 --> Language Class Initialized
ERROR - 2020-01-28 18:16:41 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-01-28 18:16:41 --> Language Class Initialized
INFO - 2020-01-28 18:16:41 --> Language Class Initialized
ERROR - 2020-01-28 18:16:41 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-01-28 18:16:41 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-01-28 18:16:41 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-01-28 18:16:41 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-01-28 18:16:41 --> Config Class Initialized
INFO - 2020-01-28 18:16:41 --> Config Class Initialized
INFO - 2020-01-28 18:16:41 --> Hooks Class Initialized
INFO - 2020-01-28 18:16:41 --> Hooks Class Initialized
DEBUG - 2020-01-28 18:16:41 --> UTF-8 Support Enabled
DEBUG - 2020-01-28 18:16:41 --> UTF-8 Support Enabled
INFO - 2020-01-28 18:16:41 --> Config Class Initialized
INFO - 2020-01-28 18:16:41 --> Config Class Initialized
INFO - 2020-01-28 18:16:41 --> Hooks Class Initialized
INFO - 2020-01-28 18:16:41 --> Hooks Class Initialized
INFO - 2020-01-28 18:16:41 --> Config Class Initialized
INFO - 2020-01-28 18:16:41 --> Config Class Initialized
INFO - 2020-01-28 18:16:41 --> Utf8 Class Initialized
INFO - 2020-01-28 18:16:41 --> Utf8 Class Initialized
INFO - 2020-01-28 18:16:41 --> Hooks Class Initialized
INFO - 2020-01-28 18:16:41 --> Hooks Class Initialized
INFO - 2020-01-28 18:16:41 --> URI Class Initialized
DEBUG - 2020-01-28 18:16:41 --> UTF-8 Support Enabled
DEBUG - 2020-01-28 18:16:41 --> UTF-8 Support Enabled
INFO - 2020-01-28 18:16:41 --> URI Class Initialized
INFO - 2020-01-28 18:16:41 --> Utf8 Class Initialized
INFO - 2020-01-28 18:16:41 --> Utf8 Class Initialized
INFO - 2020-01-28 18:16:41 --> Router Class Initialized
INFO - 2020-01-28 18:16:41 --> Router Class Initialized
DEBUG - 2020-01-28 18:16:41 --> UTF-8 Support Enabled
DEBUG - 2020-01-28 18:16:41 --> UTF-8 Support Enabled
INFO - 2020-01-28 18:16:41 --> Utf8 Class Initialized
INFO - 2020-01-28 18:16:41 --> URI Class Initialized
INFO - 2020-01-28 18:16:41 --> URI Class Initialized
INFO - 2020-01-28 18:16:41 --> Utf8 Class Initialized
INFO - 2020-01-28 18:16:41 --> Output Class Initialized
INFO - 2020-01-28 18:16:41 --> Output Class Initialized
INFO - 2020-01-28 18:16:41 --> Router Class Initialized
INFO - 2020-01-28 18:16:41 --> Router Class Initialized
INFO - 2020-01-28 18:16:41 --> Security Class Initialized
INFO - 2020-01-28 18:16:41 --> Security Class Initialized
INFO - 2020-01-28 18:16:41 --> URI Class Initialized
INFO - 2020-01-28 18:16:41 --> URI Class Initialized
INFO - 2020-01-28 18:16:41 --> Output Class Initialized
INFO - 2020-01-28 18:16:41 --> Output Class Initialized
DEBUG - 2020-01-28 18:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-28 18:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-28 18:16:41 --> Router Class Initialized
INFO - 2020-01-28 18:16:41 --> Router Class Initialized
INFO - 2020-01-28 18:16:41 --> Security Class Initialized
INFO - 2020-01-28 18:16:41 --> Security Class Initialized
INFO - 2020-01-28 18:16:41 --> Input Class Initialized
INFO - 2020-01-28 18:16:41 --> Input Class Initialized
INFO - 2020-01-28 18:16:41 --> Output Class Initialized
INFO - 2020-01-28 18:16:41 --> Output Class Initialized
DEBUG - 2020-01-28 18:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-28 18:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-28 18:16:41 --> Language Class Initialized
INFO - 2020-01-28 18:16:41 --> Security Class Initialized
INFO - 2020-01-28 18:16:41 --> Security Class Initialized
INFO - 2020-01-28 18:16:41 --> Language Class Initialized
INFO - 2020-01-28 18:16:41 --> Input Class Initialized
INFO - 2020-01-28 18:16:41 --> Input Class Initialized
ERROR - 2020-01-28 18:16:41 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-01-28 18:16:41 --> 404 Page Not Found: Bower_components/modernizr
DEBUG - 2020-01-28 18:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-28 18:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-28 18:16:41 --> Input Class Initialized
INFO - 2020-01-28 18:16:41 --> Language Class Initialized
INFO - 2020-01-28 18:16:41 --> Input Class Initialized
INFO - 2020-01-28 18:16:41 --> Language Class Initialized
INFO - 2020-01-28 18:16:41 --> Config Class Initialized
INFO - 2020-01-28 18:16:41 --> Hooks Class Initialized
INFO - 2020-01-28 18:16:41 --> Language Class Initialized
ERROR - 2020-01-28 18:16:41 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-01-28 18:16:41 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-01-28 18:16:41 --> Language Class Initialized
INFO - 2020-01-28 18:16:41 --> Config Class Initialized
INFO - 2020-01-28 18:16:41 --> Hooks Class Initialized
ERROR - 2020-01-28 18:16:41 --> 404 Page Not Found: Bower_components/jquery-i18next
DEBUG - 2020-01-28 18:16:41 --> UTF-8 Support Enabled
INFO - 2020-01-28 18:16:41 --> Loader Class Initialized
INFO - 2020-01-28 18:16:41 --> Utf8 Class Initialized
INFO - 2020-01-28 18:16:41 --> Helper loaded: url_helper
DEBUG - 2020-01-28 18:16:41 --> UTF-8 Support Enabled
INFO - 2020-01-28 18:16:41 --> Utf8 Class Initialized
INFO - 2020-01-28 18:16:41 --> URI Class Initialized
INFO - 2020-01-28 18:16:41 --> Database Driver Class Initialized
INFO - 2020-01-28 18:16:41 --> URI Class Initialized
INFO - 2020-01-28 18:16:41 --> Router Class Initialized
DEBUG - 2020-01-28 18:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-28 18:16:41 --> Router Class Initialized
INFO - 2020-01-28 18:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-28 18:16:41 --> Output Class Initialized
INFO - 2020-01-28 18:16:41 --> Controller Class Initialized
INFO - 2020-01-28 18:16:41 --> Output Class Initialized
INFO - 2020-01-28 18:16:41 --> Security Class Initialized
INFO - 2020-01-28 18:16:41 --> Model "M_login" initialized
INFO - 2020-01-28 18:16:41 --> Security Class Initialized
DEBUG - 2020-01-28 18:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-28 18:16:41 --> Input Class Initialized
INFO - 2020-01-28 18:16:41 --> Model "M_tiket" initialized
DEBUG - 2020-01-28 18:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-28 18:16:41 --> Input Class Initialized
INFO - 2020-01-28 18:16:41 --> Language Class Initialized
INFO - 2020-01-28 18:16:41 --> Helper loaded: form_helper
INFO - 2020-01-28 18:16:41 --> Form Validation Class Initialized
INFO - 2020-01-28 18:16:41 --> Language Class Initialized
ERROR - 2020-01-28 18:16:41 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-01-28 18:16:41 --> Loader Class Initialized
INFO - 2020-01-28 18:16:41 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-28 18:16:41 --> Config Class Initialized
INFO - 2020-01-28 18:16:41 --> Hooks Class Initialized
ERROR - 2020-01-28 18:16:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
INFO - 2020-01-28 18:16:41 --> Helper loaded: url_helper
DEBUG - 2020-01-28 18:16:42 --> UTF-8 Support Enabled
INFO - 2020-01-28 18:16:42 --> Database Driver Class Initialized
INFO - 2020-01-28 18:16:42 --> Utf8 Class Initialized
DEBUG - 2020-01-28 18:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2020-01-28 18:16:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
ERROR - 2020-01-28 18:16:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 60
INFO - 2020-01-28 18:16:42 --> URI Class Initialized
INFO - 2020-01-28 18:16:42 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-28 18:16:42 --> Router Class Initialized
INFO - 2020-01-28 18:16:42 --> Final output sent to browser
INFO - 2020-01-28 18:16:42 --> Output Class Initialized
DEBUG - 2020-01-28 18:16:42 --> Total execution time: 0.5722
INFO - 2020-01-28 18:16:42 --> Security Class Initialized
INFO - 2020-01-28 18:16:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-01-28 18:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-28 18:16:42 --> Input Class Initialized
INFO - 2020-01-28 18:16:42 --> Controller Class Initialized
INFO - 2020-01-28 18:16:42 --> Language Class Initialized
INFO - 2020-01-28 18:16:42 --> Model "M_login" initialized
INFO - 2020-01-28 18:16:42 --> Model "M_tiket" initialized
ERROR - 2020-01-28 18:16:42 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-01-28 18:16:42 --> Helper loaded: form_helper
INFO - 2020-01-28 18:16:42 --> Form Validation Class Initialized
INFO - 2020-01-28 18:16:42 --> Config Class Initialized
INFO - 2020-01-28 18:16:42 --> Hooks Class Initialized
INFO - 2020-01-28 18:16:42 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
ERROR - 2020-01-28 18:16:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 58
DEBUG - 2020-01-28 18:16:42 --> UTF-8 Support Enabled
INFO - 2020-01-28 18:16:42 --> Utf8 Class Initialized
ERROR - 2020-01-28 18:16:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 59
ERROR - 2020-01-28 18:16:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Musikologi-1\application\views\admin\tiket\lihat_jenis.php 60
INFO - 2020-01-28 18:16:42 --> URI Class Initialized
INFO - 2020-01-28 18:16:42 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/tiket/lihat_jenis.php
INFO - 2020-01-28 18:16:42 --> Router Class Initialized
INFO - 2020-01-28 18:16:42 --> Final output sent to browser
INFO - 2020-01-28 18:16:42 --> Output Class Initialized
DEBUG - 2020-01-28 18:16:42 --> Total execution time: 0.5914
INFO - 2020-01-28 18:16:42 --> Security Class Initialized
DEBUG - 2020-01-28 18:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-28 18:16:42 --> Input Class Initialized
INFO - 2020-01-28 18:16:42 --> Language Class Initialized
ERROR - 2020-01-28 18:16:42 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-01-28 18:16:42 --> Config Class Initialized
INFO - 2020-01-28 18:16:42 --> Hooks Class Initialized
DEBUG - 2020-01-28 18:16:42 --> UTF-8 Support Enabled
INFO - 2020-01-28 18:16:42 --> Utf8 Class Initialized
INFO - 2020-01-28 18:16:42 --> URI Class Initialized
INFO - 2020-01-28 18:16:42 --> Router Class Initialized
INFO - 2020-01-28 18:16:42 --> Output Class Initialized
INFO - 2020-01-28 18:16:42 --> Security Class Initialized
DEBUG - 2020-01-28 18:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-28 18:16:42 --> Input Class Initialized
INFO - 2020-01-28 18:16:42 --> Language Class Initialized
ERROR - 2020-01-28 18:16:42 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-01-28 18:16:42 --> Config Class Initialized
INFO - 2020-01-28 18:16:42 --> Hooks Class Initialized
DEBUG - 2020-01-28 18:16:42 --> UTF-8 Support Enabled
INFO - 2020-01-28 18:16:42 --> Utf8 Class Initialized
INFO - 2020-01-28 18:16:42 --> URI Class Initialized
INFO - 2020-01-28 18:16:42 --> Router Class Initialized
INFO - 2020-01-28 18:16:42 --> Output Class Initialized
INFO - 2020-01-28 18:16:42 --> Security Class Initialized
DEBUG - 2020-01-28 18:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-28 18:16:42 --> Input Class Initialized
INFO - 2020-01-28 18:16:42 --> Language Class Initialized
ERROR - 2020-01-28 18:16:42 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-01-28 18:16:43 --> Config Class Initialized
INFO - 2020-01-28 18:16:43 --> Hooks Class Initialized
DEBUG - 2020-01-28 18:16:43 --> UTF-8 Support Enabled
INFO - 2020-01-28 18:16:43 --> Utf8 Class Initialized
INFO - 2020-01-28 18:16:43 --> URI Class Initialized
INFO - 2020-01-28 18:16:43 --> Router Class Initialized
INFO - 2020-01-28 18:16:43 --> Output Class Initialized
INFO - 2020-01-28 18:16:43 --> Security Class Initialized
DEBUG - 2020-01-28 18:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-28 18:16:43 --> Input Class Initialized
INFO - 2020-01-28 18:16:43 --> Language Class Initialized
ERROR - 2020-01-28 18:16:43 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-01-28 18:16:43 --> Config Class Initialized
INFO - 2020-01-28 18:16:43 --> Hooks Class Initialized
DEBUG - 2020-01-28 18:16:43 --> UTF-8 Support Enabled
INFO - 2020-01-28 18:16:43 --> Utf8 Class Initialized
INFO - 2020-01-28 18:16:43 --> URI Class Initialized
INFO - 2020-01-28 18:16:43 --> Router Class Initialized
INFO - 2020-01-28 18:16:43 --> Output Class Initialized
INFO - 2020-01-28 18:16:43 --> Security Class Initialized
DEBUG - 2020-01-28 18:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-28 18:16:43 --> Input Class Initialized
INFO - 2020-01-28 18:16:43 --> Language Class Initialized
ERROR - 2020-01-28 18:16:43 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-01-28 18:31:40 --> Config Class Initialized
INFO - 2020-01-28 18:31:40 --> Hooks Class Initialized
DEBUG - 2020-01-28 18:31:40 --> UTF-8 Support Enabled
INFO - 2020-01-28 18:31:40 --> Utf8 Class Initialized
INFO - 2020-01-28 18:31:40 --> URI Class Initialized
INFO - 2020-01-28 18:31:40 --> Router Class Initialized
INFO - 2020-01-28 18:31:40 --> Output Class Initialized
INFO - 2020-01-28 18:31:40 --> Security Class Initialized
DEBUG - 2020-01-28 18:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-28 18:31:40 --> Input Class Initialized
INFO - 2020-01-28 18:31:41 --> Language Class Initialized
INFO - 2020-01-28 18:31:41 --> Loader Class Initialized
INFO - 2020-01-28 18:31:41 --> Helper loaded: url_helper
INFO - 2020-01-28 18:31:41 --> Database Driver Class Initialized
DEBUG - 2020-01-28 18:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-28 18:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-28 18:31:41 --> Controller Class Initialized
INFO - 2020-01-28 18:31:41 --> Model "M_login" initialized
INFO - 2020-01-28 18:31:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-01-28 18:31:41 --> Pagination Class Initialized
INFO - 2020-01-28 18:31:41 --> Model "M_show" initialized
INFO - 2020-01-28 18:31:41 --> Helper loaded: form_helper
INFO - 2020-01-28 18:31:41 --> Form Validation Class Initialized
INFO - 2020-01-28 18:31:41 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\component/menu.php
INFO - 2020-01-28 18:31:41 --> File loaded: C:\xampp\htdocs\Musikologi-1\application\views\admin/show/lihat_show.php
INFO - 2020-01-28 18:31:41 --> Final output sent to browser
DEBUG - 2020-01-28 18:31:41 --> Total execution time: 0.3871
INFO - 2020-01-28 18:31:41 --> Config Class Initialized
INFO - 2020-01-28 18:31:41 --> Config Class Initialized
INFO - 2020-01-28 18:31:41 --> Hooks Class Initialized
INFO - 2020-01-28 18:31:41 --> Hooks Class Initialized
DEBUG - 2020-01-28 18:31:41 --> UTF-8 Support Enabled
DEBUG - 2020-01-28 18:31:41 --> UTF-8 Support Enabled
INFO - 2020-01-28 18:31:41 --> Utf8 Class Initialized
INFO - 2020-01-28 18:31:41 --> Utf8 Class Initialized
INFO - 2020-01-28 18:31:41 --> URI Class Initialized
INFO - 2020-01-28 18:31:41 --> URI Class Initialized
INFO - 2020-01-28 18:31:41 --> Router Class Initialized
INFO - 2020-01-28 18:31:41 --> Router Class Initialized
INFO - 2020-01-28 18:31:41 --> Output Class Initialized
INFO - 2020-01-28 18:31:41 --> Output Class Initialized
INFO - 2020-01-28 18:31:41 --> Security Class Initialized
INFO - 2020-01-28 18:31:41 --> Security Class Initialized
DEBUG - 2020-01-28 18:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-28 18:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-28 18:31:41 --> Input Class Initialized
INFO - 2020-01-28 18:31:41 --> Input Class Initialized
INFO - 2020-01-28 18:31:41 --> Language Class Initialized
INFO - 2020-01-28 18:31:41 --> Language Class Initialized
ERROR - 2020-01-28 18:31:41 --> 404 Page Not Found: Show/assets
ERROR - 2020-01-28 18:31:41 --> 404 Page Not Found: Show/assets
INFO - 2020-01-28 18:31:41 --> Config Class Initialized
INFO - 2020-01-28 18:31:41 --> Hooks Class Initialized
DEBUG - 2020-01-28 18:31:41 --> UTF-8 Support Enabled
INFO - 2020-01-28 18:31:41 --> Utf8 Class Initialized
INFO - 2020-01-28 18:31:41 --> URI Class Initialized
INFO - 2020-01-28 18:31:41 --> Router Class Initialized
INFO - 2020-01-28 18:31:41 --> Output Class Initialized
INFO - 2020-01-28 18:31:41 --> Security Class Initialized
DEBUG - 2020-01-28 18:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-28 18:31:41 --> Input Class Initialized
INFO - 2020-01-28 18:31:41 --> Language Class Initialized
ERROR - 2020-01-28 18:31:41 --> 404 Page Not Found: Show/assets
