<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-03-07 00:04:48 --> Config Class Initialized
INFO - 2020-03-07 00:04:48 --> Hooks Class Initialized
DEBUG - 2020-03-07 00:04:48 --> UTF-8 Support Enabled
INFO - 2020-03-07 00:04:48 --> Utf8 Class Initialized
INFO - 2020-03-07 00:04:48 --> URI Class Initialized
DEBUG - 2020-03-07 00:04:48 --> No URI present. Default controller set.
INFO - 2020-03-07 00:04:48 --> Router Class Initialized
INFO - 2020-03-07 00:04:48 --> Output Class Initialized
INFO - 2020-03-07 00:04:48 --> Security Class Initialized
DEBUG - 2020-03-07 00:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 00:04:48 --> Input Class Initialized
INFO - 2020-03-07 00:04:48 --> Language Class Initialized
INFO - 2020-03-07 00:04:48 --> Loader Class Initialized
INFO - 2020-03-07 00:04:48 --> Helper loaded: url_helper
INFO - 2020-03-07 00:04:48 --> Helper loaded: string_helper
INFO - 2020-03-07 00:04:48 --> Database Driver Class Initialized
DEBUG - 2020-03-07 00:04:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 00:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 00:04:48 --> Controller Class Initialized
INFO - 2020-03-07 00:04:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 00:04:48 --> Pagination Class Initialized
INFO - 2020-03-07 00:04:48 --> Model "M_show" initialized
INFO - 2020-03-07 00:04:48 --> Helper loaded: form_helper
INFO - 2020-03-07 00:04:48 --> Form Validation Class Initialized
INFO - 2020-03-07 00:04:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 00:04:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 00:04:48 --> Final output sent to browser
DEBUG - 2020-03-07 00:04:48 --> Total execution time: 0.0371
INFO - 2020-03-07 00:04:57 --> Config Class Initialized
INFO - 2020-03-07 00:04:57 --> Hooks Class Initialized
DEBUG - 2020-03-07 00:04:57 --> UTF-8 Support Enabled
INFO - 2020-03-07 00:04:57 --> Utf8 Class Initialized
INFO - 2020-03-07 00:04:57 --> URI Class Initialized
INFO - 2020-03-07 00:04:57 --> Router Class Initialized
INFO - 2020-03-07 00:04:57 --> Output Class Initialized
INFO - 2020-03-07 00:04:57 --> Security Class Initialized
DEBUG - 2020-03-07 00:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 00:04:57 --> Input Class Initialized
INFO - 2020-03-07 00:04:57 --> Language Class Initialized
INFO - 2020-03-07 00:04:57 --> Loader Class Initialized
INFO - 2020-03-07 00:04:57 --> Helper loaded: url_helper
INFO - 2020-03-07 00:04:57 --> Helper loaded: string_helper
INFO - 2020-03-07 00:04:57 --> Database Driver Class Initialized
DEBUG - 2020-03-07 00:04:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 00:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 00:04:57 --> Controller Class Initialized
INFO - 2020-03-07 00:04:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 00:04:57 --> Pagination Class Initialized
INFO - 2020-03-07 00:04:57 --> Model "M_show" initialized
INFO - 2020-03-07 00:04:57 --> Helper loaded: form_helper
INFO - 2020-03-07 00:04:57 --> Form Validation Class Initialized
INFO - 2020-03-07 00:04:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 00:04:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 00:04:57 --> Final output sent to browser
DEBUG - 2020-03-07 00:04:57 --> Total execution time: 0.0081
INFO - 2020-03-07 00:05:01 --> Config Class Initialized
INFO - 2020-03-07 00:05:01 --> Hooks Class Initialized
DEBUG - 2020-03-07 00:05:01 --> UTF-8 Support Enabled
INFO - 2020-03-07 00:05:01 --> Utf8 Class Initialized
INFO - 2020-03-07 00:05:01 --> URI Class Initialized
INFO - 2020-03-07 00:05:01 --> Router Class Initialized
INFO - 2020-03-07 00:05:01 --> Output Class Initialized
INFO - 2020-03-07 00:05:01 --> Security Class Initialized
DEBUG - 2020-03-07 00:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 00:05:01 --> Input Class Initialized
INFO - 2020-03-07 00:05:01 --> Language Class Initialized
INFO - 2020-03-07 00:05:01 --> Loader Class Initialized
INFO - 2020-03-07 00:05:01 --> Helper loaded: url_helper
INFO - 2020-03-07 00:05:01 --> Helper loaded: string_helper
INFO - 2020-03-07 00:05:01 --> Database Driver Class Initialized
DEBUG - 2020-03-07 00:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 00:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 00:05:01 --> Controller Class Initialized
INFO - 2020-03-07 00:05:01 --> Model "M_tiket" initialized
INFO - 2020-03-07 00:05:01 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 00:05:01 --> Model "M_pesan" initialized
INFO - 2020-03-07 00:05:01 --> Helper loaded: form_helper
INFO - 2020-03-07 00:05:01 --> Form Validation Class Initialized
INFO - 2020-03-07 00:05:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 00:05:01 --> Final output sent to browser
DEBUG - 2020-03-07 00:05:01 --> Total execution time: 0.0102
INFO - 2020-03-07 00:05:20 --> Config Class Initialized
INFO - 2020-03-07 00:05:20 --> Hooks Class Initialized
DEBUG - 2020-03-07 00:05:20 --> UTF-8 Support Enabled
INFO - 2020-03-07 00:05:20 --> Utf8 Class Initialized
INFO - 2020-03-07 00:05:20 --> URI Class Initialized
INFO - 2020-03-07 00:05:20 --> Router Class Initialized
INFO - 2020-03-07 00:05:20 --> Output Class Initialized
INFO - 2020-03-07 00:05:20 --> Security Class Initialized
DEBUG - 2020-03-07 00:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 00:05:20 --> Input Class Initialized
INFO - 2020-03-07 00:05:20 --> Language Class Initialized
INFO - 2020-03-07 00:05:20 --> Loader Class Initialized
INFO - 2020-03-07 00:05:20 --> Helper loaded: url_helper
INFO - 2020-03-07 00:05:20 --> Helper loaded: string_helper
INFO - 2020-03-07 00:05:20 --> Database Driver Class Initialized
DEBUG - 2020-03-07 00:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 00:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 00:05:20 --> Controller Class Initialized
INFO - 2020-03-07 00:05:20 --> Model "M_tiket" initialized
INFO - 2020-03-07 00:05:20 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 00:05:20 --> Model "M_pesan" initialized
INFO - 2020-03-07 00:05:20 --> Helper loaded: form_helper
INFO - 2020-03-07 00:05:20 --> Form Validation Class Initialized
INFO - 2020-03-07 00:05:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 00:05:20 --> Final output sent to browser
DEBUG - 2020-03-07 00:05:20 --> Total execution time: 0.0080
INFO - 2020-03-07 00:05:33 --> Config Class Initialized
INFO - 2020-03-07 00:05:33 --> Hooks Class Initialized
DEBUG - 2020-03-07 00:05:33 --> UTF-8 Support Enabled
INFO - 2020-03-07 00:05:33 --> Utf8 Class Initialized
INFO - 2020-03-07 00:05:33 --> URI Class Initialized
INFO - 2020-03-07 00:05:33 --> Router Class Initialized
INFO - 2020-03-07 00:05:33 --> Output Class Initialized
INFO - 2020-03-07 00:05:33 --> Security Class Initialized
DEBUG - 2020-03-07 00:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 00:05:33 --> Input Class Initialized
INFO - 2020-03-07 00:05:33 --> Language Class Initialized
INFO - 2020-03-07 00:05:33 --> Loader Class Initialized
INFO - 2020-03-07 00:05:33 --> Helper loaded: url_helper
INFO - 2020-03-07 00:05:33 --> Helper loaded: string_helper
INFO - 2020-03-07 00:05:33 --> Database Driver Class Initialized
DEBUG - 2020-03-07 00:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 00:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 00:05:33 --> Controller Class Initialized
INFO - 2020-03-07 00:05:33 --> Model "M_tiket" initialized
INFO - 2020-03-07 00:05:33 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 00:05:33 --> Model "M_pesan" initialized
INFO - 2020-03-07 00:05:33 --> Helper loaded: form_helper
INFO - 2020-03-07 00:05:33 --> Form Validation Class Initialized
INFO - 2020-03-07 00:05:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 00:05:33 --> Final output sent to browser
DEBUG - 2020-03-07 00:05:33 --> Total execution time: 0.0090
INFO - 2020-03-07 00:18:02 --> Config Class Initialized
INFO - 2020-03-07 00:18:02 --> Hooks Class Initialized
DEBUG - 2020-03-07 00:18:02 --> UTF-8 Support Enabled
INFO - 2020-03-07 00:18:02 --> Utf8 Class Initialized
INFO - 2020-03-07 00:18:02 --> URI Class Initialized
DEBUG - 2020-03-07 00:18:02 --> No URI present. Default controller set.
INFO - 2020-03-07 00:18:02 --> Router Class Initialized
INFO - 2020-03-07 00:18:02 --> Output Class Initialized
INFO - 2020-03-07 00:18:02 --> Security Class Initialized
DEBUG - 2020-03-07 00:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 00:18:02 --> Input Class Initialized
INFO - 2020-03-07 00:18:02 --> Language Class Initialized
INFO - 2020-03-07 00:18:02 --> Loader Class Initialized
INFO - 2020-03-07 00:18:02 --> Helper loaded: url_helper
INFO - 2020-03-07 00:18:02 --> Helper loaded: string_helper
INFO - 2020-03-07 00:18:02 --> Database Driver Class Initialized
DEBUG - 2020-03-07 00:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 00:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 00:18:02 --> Controller Class Initialized
INFO - 2020-03-07 00:18:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 00:18:02 --> Pagination Class Initialized
INFO - 2020-03-07 00:18:02 --> Model "M_show" initialized
INFO - 2020-03-07 00:18:02 --> Helper loaded: form_helper
INFO - 2020-03-07 00:18:02 --> Form Validation Class Initialized
INFO - 2020-03-07 00:18:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 00:18:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 00:18:02 --> Final output sent to browser
DEBUG - 2020-03-07 00:18:02 --> Total execution time: 0.0416
INFO - 2020-03-07 00:18:15 --> Config Class Initialized
INFO - 2020-03-07 00:18:15 --> Hooks Class Initialized
DEBUG - 2020-03-07 00:18:15 --> UTF-8 Support Enabled
INFO - 2020-03-07 00:18:15 --> Utf8 Class Initialized
INFO - 2020-03-07 00:18:15 --> URI Class Initialized
INFO - 2020-03-07 00:18:15 --> Router Class Initialized
INFO - 2020-03-07 00:18:15 --> Output Class Initialized
INFO - 2020-03-07 00:18:15 --> Security Class Initialized
DEBUG - 2020-03-07 00:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 00:18:15 --> Input Class Initialized
INFO - 2020-03-07 00:18:15 --> Language Class Initialized
INFO - 2020-03-07 00:18:15 --> Loader Class Initialized
INFO - 2020-03-07 00:18:15 --> Helper loaded: url_helper
INFO - 2020-03-07 00:18:15 --> Helper loaded: string_helper
INFO - 2020-03-07 00:18:15 --> Database Driver Class Initialized
DEBUG - 2020-03-07 00:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 00:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 00:18:15 --> Controller Class Initialized
INFO - 2020-03-07 00:18:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 00:18:15 --> Pagination Class Initialized
INFO - 2020-03-07 00:18:15 --> Model "M_show" initialized
INFO - 2020-03-07 00:18:15 --> Helper loaded: form_helper
INFO - 2020-03-07 00:18:15 --> Form Validation Class Initialized
INFO - 2020-03-07 00:18:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 00:18:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 00:18:15 --> Final output sent to browser
DEBUG - 2020-03-07 00:18:15 --> Total execution time: 0.0085
INFO - 2020-03-07 00:18:20 --> Config Class Initialized
INFO - 2020-03-07 00:18:20 --> Hooks Class Initialized
DEBUG - 2020-03-07 00:18:20 --> UTF-8 Support Enabled
INFO - 2020-03-07 00:18:20 --> Utf8 Class Initialized
INFO - 2020-03-07 00:18:20 --> URI Class Initialized
INFO - 2020-03-07 00:18:20 --> Router Class Initialized
INFO - 2020-03-07 00:18:20 --> Output Class Initialized
INFO - 2020-03-07 00:18:20 --> Security Class Initialized
DEBUG - 2020-03-07 00:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 00:18:20 --> Input Class Initialized
INFO - 2020-03-07 00:18:20 --> Language Class Initialized
INFO - 2020-03-07 00:18:20 --> Loader Class Initialized
INFO - 2020-03-07 00:18:20 --> Helper loaded: url_helper
INFO - 2020-03-07 00:18:20 --> Helper loaded: string_helper
INFO - 2020-03-07 00:18:20 --> Database Driver Class Initialized
DEBUG - 2020-03-07 00:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 00:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 00:18:20 --> Controller Class Initialized
INFO - 2020-03-07 00:18:20 --> Model "M_tiket" initialized
INFO - 2020-03-07 00:18:20 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 00:18:20 --> Model "M_pesan" initialized
INFO - 2020-03-07 00:18:20 --> Helper loaded: form_helper
INFO - 2020-03-07 00:18:20 --> Form Validation Class Initialized
INFO - 2020-03-07 00:18:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 00:18:20 --> Final output sent to browser
DEBUG - 2020-03-07 00:18:20 --> Total execution time: 0.0109
INFO - 2020-03-07 00:18:36 --> Config Class Initialized
INFO - 2020-03-07 00:18:36 --> Hooks Class Initialized
DEBUG - 2020-03-07 00:18:36 --> UTF-8 Support Enabled
INFO - 2020-03-07 00:18:36 --> Utf8 Class Initialized
INFO - 2020-03-07 00:18:36 --> URI Class Initialized
INFO - 2020-03-07 00:18:36 --> Router Class Initialized
INFO - 2020-03-07 00:18:36 --> Output Class Initialized
INFO - 2020-03-07 00:18:36 --> Security Class Initialized
DEBUG - 2020-03-07 00:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 00:18:36 --> Input Class Initialized
INFO - 2020-03-07 00:18:36 --> Language Class Initialized
INFO - 2020-03-07 00:18:36 --> Loader Class Initialized
INFO - 2020-03-07 00:18:36 --> Helper loaded: url_helper
INFO - 2020-03-07 00:18:36 --> Helper loaded: string_helper
INFO - 2020-03-07 00:18:36 --> Database Driver Class Initialized
DEBUG - 2020-03-07 00:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 00:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 00:18:36 --> Controller Class Initialized
INFO - 2020-03-07 00:18:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 00:18:36 --> Pagination Class Initialized
INFO - 2020-03-07 00:18:36 --> Model "M_show" initialized
INFO - 2020-03-07 00:18:36 --> Helper loaded: form_helper
INFO - 2020-03-07 00:18:36 --> Form Validation Class Initialized
INFO - 2020-03-07 00:18:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 00:18:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 00:18:36 --> Final output sent to browser
DEBUG - 2020-03-07 00:18:36 --> Total execution time: 0.0074
INFO - 2020-03-07 00:25:02 --> Config Class Initialized
INFO - 2020-03-07 00:25:02 --> Hooks Class Initialized
DEBUG - 2020-03-07 00:25:02 --> UTF-8 Support Enabled
INFO - 2020-03-07 00:25:02 --> Utf8 Class Initialized
INFO - 2020-03-07 00:25:02 --> URI Class Initialized
DEBUG - 2020-03-07 00:25:02 --> No URI present. Default controller set.
INFO - 2020-03-07 00:25:02 --> Router Class Initialized
INFO - 2020-03-07 00:25:02 --> Output Class Initialized
INFO - 2020-03-07 00:25:02 --> Security Class Initialized
DEBUG - 2020-03-07 00:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 00:25:02 --> Input Class Initialized
INFO - 2020-03-07 00:25:02 --> Language Class Initialized
INFO - 2020-03-07 00:25:02 --> Loader Class Initialized
INFO - 2020-03-07 00:25:02 --> Helper loaded: url_helper
INFO - 2020-03-07 00:25:02 --> Helper loaded: string_helper
INFO - 2020-03-07 00:25:02 --> Database Driver Class Initialized
DEBUG - 2020-03-07 00:25:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 00:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 00:25:02 --> Controller Class Initialized
INFO - 2020-03-07 00:25:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 00:25:02 --> Pagination Class Initialized
INFO - 2020-03-07 00:25:02 --> Model "M_show" initialized
INFO - 2020-03-07 00:25:02 --> Helper loaded: form_helper
INFO - 2020-03-07 00:25:02 --> Form Validation Class Initialized
INFO - 2020-03-07 00:25:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 00:25:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 00:25:02 --> Final output sent to browser
DEBUG - 2020-03-07 00:25:02 --> Total execution time: 0.0479
INFO - 2020-03-07 00:25:36 --> Config Class Initialized
INFO - 2020-03-07 00:25:36 --> Hooks Class Initialized
DEBUG - 2020-03-07 00:25:36 --> UTF-8 Support Enabled
INFO - 2020-03-07 00:25:36 --> Utf8 Class Initialized
INFO - 2020-03-07 00:25:36 --> URI Class Initialized
DEBUG - 2020-03-07 00:25:36 --> No URI present. Default controller set.
INFO - 2020-03-07 00:25:36 --> Router Class Initialized
INFO - 2020-03-07 00:25:36 --> Output Class Initialized
INFO - 2020-03-07 00:25:36 --> Security Class Initialized
DEBUG - 2020-03-07 00:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 00:25:36 --> Input Class Initialized
INFO - 2020-03-07 00:25:36 --> Language Class Initialized
INFO - 2020-03-07 00:25:36 --> Loader Class Initialized
INFO - 2020-03-07 00:25:36 --> Helper loaded: url_helper
INFO - 2020-03-07 00:25:36 --> Helper loaded: string_helper
INFO - 2020-03-07 00:25:36 --> Database Driver Class Initialized
DEBUG - 2020-03-07 00:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 00:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 00:25:36 --> Controller Class Initialized
INFO - 2020-03-07 00:25:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 00:25:36 --> Pagination Class Initialized
INFO - 2020-03-07 00:25:36 --> Model "M_show" initialized
INFO - 2020-03-07 00:25:36 --> Helper loaded: form_helper
INFO - 2020-03-07 00:25:36 --> Form Validation Class Initialized
INFO - 2020-03-07 00:25:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 00:25:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 00:25:36 --> Final output sent to browser
DEBUG - 2020-03-07 00:25:36 --> Total execution time: 0.0315
INFO - 2020-03-07 00:25:49 --> Config Class Initialized
INFO - 2020-03-07 00:25:49 --> Hooks Class Initialized
DEBUG - 2020-03-07 00:25:49 --> UTF-8 Support Enabled
INFO - 2020-03-07 00:25:49 --> Utf8 Class Initialized
INFO - 2020-03-07 00:25:49 --> URI Class Initialized
INFO - 2020-03-07 00:25:49 --> Router Class Initialized
INFO - 2020-03-07 00:25:49 --> Output Class Initialized
INFO - 2020-03-07 00:25:49 --> Security Class Initialized
DEBUG - 2020-03-07 00:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 00:25:49 --> Input Class Initialized
INFO - 2020-03-07 00:25:49 --> Language Class Initialized
INFO - 2020-03-07 00:25:49 --> Loader Class Initialized
INFO - 2020-03-07 00:25:49 --> Helper loaded: url_helper
INFO - 2020-03-07 00:25:49 --> Helper loaded: string_helper
INFO - 2020-03-07 00:25:49 --> Database Driver Class Initialized
DEBUG - 2020-03-07 00:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 00:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 00:25:49 --> Controller Class Initialized
INFO - 2020-03-07 00:25:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 00:25:49 --> Pagination Class Initialized
INFO - 2020-03-07 00:25:49 --> Model "M_show" initialized
INFO - 2020-03-07 00:25:49 --> Helper loaded: form_helper
INFO - 2020-03-07 00:25:49 --> Form Validation Class Initialized
INFO - 2020-03-07 00:25:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 00:25:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-07 00:25:49 --> Final output sent to browser
DEBUG - 2020-03-07 00:25:49 --> Total execution time: 0.0162
INFO - 2020-03-07 00:25:53 --> Config Class Initialized
INFO - 2020-03-07 00:25:53 --> Hooks Class Initialized
DEBUG - 2020-03-07 00:25:53 --> UTF-8 Support Enabled
INFO - 2020-03-07 00:25:53 --> Utf8 Class Initialized
INFO - 2020-03-07 00:25:53 --> URI Class Initialized
INFO - 2020-03-07 00:25:53 --> Router Class Initialized
INFO - 2020-03-07 00:25:53 --> Output Class Initialized
INFO - 2020-03-07 00:25:53 --> Security Class Initialized
DEBUG - 2020-03-07 00:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 00:25:53 --> Input Class Initialized
INFO - 2020-03-07 00:25:53 --> Language Class Initialized
INFO - 2020-03-07 00:25:53 --> Loader Class Initialized
INFO - 2020-03-07 00:25:53 --> Helper loaded: url_helper
INFO - 2020-03-07 00:25:53 --> Helper loaded: string_helper
INFO - 2020-03-07 00:25:53 --> Database Driver Class Initialized
DEBUG - 2020-03-07 00:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 00:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 00:25:53 --> Controller Class Initialized
INFO - 2020-03-07 00:25:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 00:25:53 --> Pagination Class Initialized
INFO - 2020-03-07 00:25:53 --> Model "M_show" initialized
INFO - 2020-03-07 00:25:53 --> Helper loaded: form_helper
INFO - 2020-03-07 00:25:53 --> Form Validation Class Initialized
INFO - 2020-03-07 00:25:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 00:25:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 00:25:53 --> Final output sent to browser
DEBUG - 2020-03-07 00:25:53 --> Total execution time: 0.0081
INFO - 2020-03-07 00:25:57 --> Config Class Initialized
INFO - 2020-03-07 00:25:57 --> Hooks Class Initialized
DEBUG - 2020-03-07 00:25:57 --> UTF-8 Support Enabled
INFO - 2020-03-07 00:25:57 --> Utf8 Class Initialized
INFO - 2020-03-07 00:25:57 --> URI Class Initialized
INFO - 2020-03-07 00:25:57 --> Router Class Initialized
INFO - 2020-03-07 00:25:57 --> Output Class Initialized
INFO - 2020-03-07 00:25:57 --> Security Class Initialized
DEBUG - 2020-03-07 00:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 00:25:57 --> Input Class Initialized
INFO - 2020-03-07 00:25:57 --> Language Class Initialized
INFO - 2020-03-07 00:25:57 --> Loader Class Initialized
INFO - 2020-03-07 00:25:57 --> Helper loaded: url_helper
INFO - 2020-03-07 00:25:57 --> Helper loaded: string_helper
INFO - 2020-03-07 00:25:57 --> Database Driver Class Initialized
DEBUG - 2020-03-07 00:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 00:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 00:25:57 --> Controller Class Initialized
INFO - 2020-03-07 00:25:57 --> Model "M_tiket" initialized
INFO - 2020-03-07 00:25:57 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 00:25:57 --> Model "M_pesan" initialized
INFO - 2020-03-07 00:25:57 --> Helper loaded: form_helper
INFO - 2020-03-07 00:25:57 --> Form Validation Class Initialized
INFO - 2020-03-07 00:25:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 00:25:57 --> Final output sent to browser
DEBUG - 2020-03-07 00:25:57 --> Total execution time: 0.0097
INFO - 2020-03-07 00:27:29 --> Config Class Initialized
INFO - 2020-03-07 00:27:29 --> Hooks Class Initialized
DEBUG - 2020-03-07 00:27:29 --> UTF-8 Support Enabled
INFO - 2020-03-07 00:27:29 --> Utf8 Class Initialized
INFO - 2020-03-07 00:27:29 --> URI Class Initialized
DEBUG - 2020-03-07 00:27:29 --> No URI present. Default controller set.
INFO - 2020-03-07 00:27:29 --> Router Class Initialized
INFO - 2020-03-07 00:27:29 --> Output Class Initialized
INFO - 2020-03-07 00:27:29 --> Security Class Initialized
DEBUG - 2020-03-07 00:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 00:27:29 --> Input Class Initialized
INFO - 2020-03-07 00:27:29 --> Language Class Initialized
INFO - 2020-03-07 00:27:29 --> Loader Class Initialized
INFO - 2020-03-07 00:27:29 --> Helper loaded: url_helper
INFO - 2020-03-07 00:27:29 --> Helper loaded: string_helper
INFO - 2020-03-07 00:27:29 --> Database Driver Class Initialized
DEBUG - 2020-03-07 00:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 00:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 00:27:29 --> Controller Class Initialized
INFO - 2020-03-07 00:27:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 00:27:29 --> Pagination Class Initialized
INFO - 2020-03-07 00:27:29 --> Model "M_show" initialized
INFO - 2020-03-07 00:27:29 --> Helper loaded: form_helper
INFO - 2020-03-07 00:27:29 --> Form Validation Class Initialized
INFO - 2020-03-07 00:27:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 00:27:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 00:27:29 --> Final output sent to browser
DEBUG - 2020-03-07 00:27:29 --> Total execution time: 0.0369
INFO - 2020-03-07 00:27:32 --> Config Class Initialized
INFO - 2020-03-07 00:27:32 --> Hooks Class Initialized
DEBUG - 2020-03-07 00:27:32 --> UTF-8 Support Enabled
INFO - 2020-03-07 00:27:32 --> Utf8 Class Initialized
INFO - 2020-03-07 00:27:32 --> URI Class Initialized
INFO - 2020-03-07 00:27:32 --> Router Class Initialized
INFO - 2020-03-07 00:27:32 --> Output Class Initialized
INFO - 2020-03-07 00:27:32 --> Security Class Initialized
DEBUG - 2020-03-07 00:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 00:27:32 --> Input Class Initialized
INFO - 2020-03-07 00:27:32 --> Language Class Initialized
INFO - 2020-03-07 00:27:32 --> Loader Class Initialized
INFO - 2020-03-07 00:27:32 --> Helper loaded: url_helper
INFO - 2020-03-07 00:27:32 --> Helper loaded: string_helper
INFO - 2020-03-07 00:27:32 --> Database Driver Class Initialized
DEBUG - 2020-03-07 00:27:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 00:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 00:27:32 --> Controller Class Initialized
INFO - 2020-03-07 00:27:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 00:27:32 --> Pagination Class Initialized
INFO - 2020-03-07 00:27:32 --> Model "M_show" initialized
INFO - 2020-03-07 00:27:32 --> Helper loaded: form_helper
INFO - 2020-03-07 00:27:32 --> Form Validation Class Initialized
INFO - 2020-03-07 00:27:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 00:27:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 00:27:32 --> Final output sent to browser
DEBUG - 2020-03-07 00:27:32 --> Total execution time: 0.0085
INFO - 2020-03-07 00:27:36 --> Config Class Initialized
INFO - 2020-03-07 00:27:36 --> Hooks Class Initialized
DEBUG - 2020-03-07 00:27:36 --> UTF-8 Support Enabled
INFO - 2020-03-07 00:27:36 --> Utf8 Class Initialized
INFO - 2020-03-07 00:27:36 --> URI Class Initialized
INFO - 2020-03-07 00:27:36 --> Router Class Initialized
INFO - 2020-03-07 00:27:36 --> Output Class Initialized
INFO - 2020-03-07 00:27:36 --> Security Class Initialized
DEBUG - 2020-03-07 00:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 00:27:36 --> Input Class Initialized
INFO - 2020-03-07 00:27:36 --> Language Class Initialized
INFO - 2020-03-07 00:27:36 --> Loader Class Initialized
INFO - 2020-03-07 00:27:36 --> Helper loaded: url_helper
INFO - 2020-03-07 00:27:36 --> Helper loaded: string_helper
INFO - 2020-03-07 00:27:36 --> Database Driver Class Initialized
DEBUG - 2020-03-07 00:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 00:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 00:27:36 --> Controller Class Initialized
INFO - 2020-03-07 00:27:36 --> Model "M_tiket" initialized
INFO - 2020-03-07 00:27:36 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 00:27:36 --> Model "M_pesan" initialized
INFO - 2020-03-07 00:27:36 --> Helper loaded: form_helper
INFO - 2020-03-07 00:27:36 --> Form Validation Class Initialized
INFO - 2020-03-07 00:27:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 00:27:36 --> Final output sent to browser
DEBUG - 2020-03-07 00:27:36 --> Total execution time: 0.0118
INFO - 2020-03-07 00:27:51 --> Config Class Initialized
INFO - 2020-03-07 00:27:51 --> Hooks Class Initialized
DEBUG - 2020-03-07 00:27:51 --> UTF-8 Support Enabled
INFO - 2020-03-07 00:27:51 --> Utf8 Class Initialized
INFO - 2020-03-07 00:27:51 --> URI Class Initialized
INFO - 2020-03-07 00:27:51 --> Router Class Initialized
INFO - 2020-03-07 00:27:51 --> Output Class Initialized
INFO - 2020-03-07 00:27:51 --> Security Class Initialized
DEBUG - 2020-03-07 00:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 00:27:51 --> Input Class Initialized
INFO - 2020-03-07 00:27:51 --> Language Class Initialized
INFO - 2020-03-07 00:27:51 --> Loader Class Initialized
INFO - 2020-03-07 00:27:51 --> Helper loaded: url_helper
INFO - 2020-03-07 00:27:51 --> Helper loaded: string_helper
INFO - 2020-03-07 00:27:51 --> Database Driver Class Initialized
DEBUG - 2020-03-07 00:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 00:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 00:27:51 --> Controller Class Initialized
INFO - 2020-03-07 00:27:51 --> Model "M_tiket" initialized
INFO - 2020-03-07 00:27:51 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 00:27:51 --> Model "M_pesan" initialized
INFO - 2020-03-07 00:27:51 --> Helper loaded: form_helper
INFO - 2020-03-07 00:27:51 --> Form Validation Class Initialized
INFO - 2020-03-07 00:27:51 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 00:27:51 --> Final output sent to browser
DEBUG - 2020-03-07 00:27:51 --> Total execution time: 0.0075
INFO - 2020-03-07 00:41:05 --> Config Class Initialized
INFO - 2020-03-07 00:41:05 --> Hooks Class Initialized
DEBUG - 2020-03-07 00:41:05 --> UTF-8 Support Enabled
INFO - 2020-03-07 00:41:05 --> Utf8 Class Initialized
INFO - 2020-03-07 00:41:05 --> URI Class Initialized
DEBUG - 2020-03-07 00:41:05 --> No URI present. Default controller set.
INFO - 2020-03-07 00:41:05 --> Router Class Initialized
INFO - 2020-03-07 00:41:05 --> Output Class Initialized
INFO - 2020-03-07 00:41:05 --> Security Class Initialized
DEBUG - 2020-03-07 00:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 00:41:05 --> Input Class Initialized
INFO - 2020-03-07 00:41:05 --> Language Class Initialized
INFO - 2020-03-07 00:41:05 --> Loader Class Initialized
INFO - 2020-03-07 00:41:05 --> Helper loaded: url_helper
INFO - 2020-03-07 00:41:05 --> Helper loaded: string_helper
INFO - 2020-03-07 00:41:05 --> Database Driver Class Initialized
DEBUG - 2020-03-07 00:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 00:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 00:41:05 --> Controller Class Initialized
INFO - 2020-03-07 00:41:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 00:41:05 --> Pagination Class Initialized
INFO - 2020-03-07 00:41:05 --> Model "M_show" initialized
INFO - 2020-03-07 00:41:05 --> Helper loaded: form_helper
INFO - 2020-03-07 00:41:05 --> Form Validation Class Initialized
INFO - 2020-03-07 00:41:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 00:41:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 00:41:05 --> Final output sent to browser
DEBUG - 2020-03-07 00:41:05 --> Total execution time: 0.0639
INFO - 2020-03-07 00:41:24 --> Config Class Initialized
INFO - 2020-03-07 00:41:24 --> Hooks Class Initialized
DEBUG - 2020-03-07 00:41:24 --> UTF-8 Support Enabled
INFO - 2020-03-07 00:41:24 --> Utf8 Class Initialized
INFO - 2020-03-07 00:41:24 --> URI Class Initialized
INFO - 2020-03-07 00:41:24 --> Router Class Initialized
INFO - 2020-03-07 00:41:24 --> Output Class Initialized
INFO - 2020-03-07 00:41:24 --> Security Class Initialized
DEBUG - 2020-03-07 00:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 00:41:24 --> Input Class Initialized
INFO - 2020-03-07 00:41:24 --> Language Class Initialized
INFO - 2020-03-07 00:41:24 --> Loader Class Initialized
INFO - 2020-03-07 00:41:24 --> Helper loaded: url_helper
INFO - 2020-03-07 00:41:24 --> Helper loaded: string_helper
INFO - 2020-03-07 00:41:24 --> Database Driver Class Initialized
DEBUG - 2020-03-07 00:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 00:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 00:41:24 --> Controller Class Initialized
INFO - 2020-03-07 00:41:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 00:41:24 --> Pagination Class Initialized
INFO - 2020-03-07 00:41:24 --> Model "M_show" initialized
INFO - 2020-03-07 00:41:24 --> Helper loaded: form_helper
INFO - 2020-03-07 00:41:24 --> Form Validation Class Initialized
INFO - 2020-03-07 00:41:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 00:41:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 00:41:24 --> Final output sent to browser
DEBUG - 2020-03-07 00:41:24 --> Total execution time: 0.0056
INFO - 2020-03-07 00:41:28 --> Config Class Initialized
INFO - 2020-03-07 00:41:28 --> Hooks Class Initialized
DEBUG - 2020-03-07 00:41:28 --> UTF-8 Support Enabled
INFO - 2020-03-07 00:41:28 --> Utf8 Class Initialized
INFO - 2020-03-07 00:41:28 --> URI Class Initialized
INFO - 2020-03-07 00:41:28 --> Router Class Initialized
INFO - 2020-03-07 00:41:28 --> Output Class Initialized
INFO - 2020-03-07 00:41:28 --> Security Class Initialized
DEBUG - 2020-03-07 00:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 00:41:28 --> Input Class Initialized
INFO - 2020-03-07 00:41:28 --> Language Class Initialized
INFO - 2020-03-07 00:41:28 --> Loader Class Initialized
INFO - 2020-03-07 00:41:28 --> Helper loaded: url_helper
INFO - 2020-03-07 00:41:28 --> Helper loaded: string_helper
INFO - 2020-03-07 00:41:28 --> Database Driver Class Initialized
DEBUG - 2020-03-07 00:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 00:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 00:41:28 --> Controller Class Initialized
INFO - 2020-03-07 00:41:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 00:41:28 --> Pagination Class Initialized
INFO - 2020-03-07 00:41:28 --> Model "M_show" initialized
INFO - 2020-03-07 00:41:28 --> Helper loaded: form_helper
INFO - 2020-03-07 00:41:28 --> Form Validation Class Initialized
INFO - 2020-03-07 00:41:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 00:41:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 00:41:28 --> Final output sent to browser
DEBUG - 2020-03-07 00:41:28 --> Total execution time: 0.0087
INFO - 2020-03-07 00:41:32 --> Config Class Initialized
INFO - 2020-03-07 00:41:32 --> Hooks Class Initialized
DEBUG - 2020-03-07 00:41:32 --> UTF-8 Support Enabled
INFO - 2020-03-07 00:41:32 --> Utf8 Class Initialized
INFO - 2020-03-07 00:41:32 --> URI Class Initialized
INFO - 2020-03-07 00:41:32 --> Router Class Initialized
INFO - 2020-03-07 00:41:32 --> Output Class Initialized
INFO - 2020-03-07 00:41:32 --> Security Class Initialized
DEBUG - 2020-03-07 00:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 00:41:32 --> Input Class Initialized
INFO - 2020-03-07 00:41:32 --> Language Class Initialized
INFO - 2020-03-07 00:41:32 --> Loader Class Initialized
INFO - 2020-03-07 00:41:32 --> Helper loaded: url_helper
INFO - 2020-03-07 00:41:32 --> Helper loaded: string_helper
INFO - 2020-03-07 00:41:32 --> Database Driver Class Initialized
DEBUG - 2020-03-07 00:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 00:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 00:41:32 --> Controller Class Initialized
INFO - 2020-03-07 00:41:32 --> Model "M_tiket" initialized
INFO - 2020-03-07 00:41:32 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 00:41:32 --> Model "M_pesan" initialized
INFO - 2020-03-07 00:41:32 --> Helper loaded: form_helper
INFO - 2020-03-07 00:41:32 --> Form Validation Class Initialized
INFO - 2020-03-07 00:41:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 00:41:32 --> Final output sent to browser
DEBUG - 2020-03-07 00:41:32 --> Total execution time: 0.0099
INFO - 2020-03-07 00:51:10 --> Config Class Initialized
INFO - 2020-03-07 00:51:10 --> Hooks Class Initialized
DEBUG - 2020-03-07 00:51:10 --> UTF-8 Support Enabled
INFO - 2020-03-07 00:51:10 --> Utf8 Class Initialized
INFO - 2020-03-07 00:51:10 --> URI Class Initialized
INFO - 2020-03-07 00:51:10 --> Router Class Initialized
INFO - 2020-03-07 00:51:10 --> Output Class Initialized
INFO - 2020-03-07 00:51:10 --> Security Class Initialized
DEBUG - 2020-03-07 00:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 00:51:10 --> Input Class Initialized
INFO - 2020-03-07 00:51:10 --> Language Class Initialized
INFO - 2020-03-07 00:51:10 --> Loader Class Initialized
INFO - 2020-03-07 00:51:10 --> Helper loaded: url_helper
INFO - 2020-03-07 00:51:10 --> Helper loaded: string_helper
INFO - 2020-03-07 00:51:10 --> Database Driver Class Initialized
DEBUG - 2020-03-07 00:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 00:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 00:51:10 --> Controller Class Initialized
INFO - 2020-03-07 00:51:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 00:51:10 --> Pagination Class Initialized
INFO - 2020-03-07 00:51:10 --> Model "M_show" initialized
INFO - 2020-03-07 00:51:10 --> Helper loaded: form_helper
INFO - 2020-03-07 00:51:10 --> Form Validation Class Initialized
INFO - 2020-03-07 00:51:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 00:51:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 00:51:10 --> Final output sent to browser
DEBUG - 2020-03-07 00:51:10 --> Total execution time: 0.0372
INFO - 2020-03-07 01:22:51 --> Config Class Initialized
INFO - 2020-03-07 01:22:51 --> Hooks Class Initialized
DEBUG - 2020-03-07 01:22:51 --> UTF-8 Support Enabled
INFO - 2020-03-07 01:22:51 --> Utf8 Class Initialized
INFO - 2020-03-07 01:22:51 --> URI Class Initialized
DEBUG - 2020-03-07 01:22:51 --> No URI present. Default controller set.
INFO - 2020-03-07 01:22:51 --> Router Class Initialized
INFO - 2020-03-07 01:22:51 --> Output Class Initialized
INFO - 2020-03-07 01:22:51 --> Security Class Initialized
DEBUG - 2020-03-07 01:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 01:22:51 --> Input Class Initialized
INFO - 2020-03-07 01:22:51 --> Language Class Initialized
INFO - 2020-03-07 01:22:51 --> Loader Class Initialized
INFO - 2020-03-07 01:22:51 --> Helper loaded: url_helper
INFO - 2020-03-07 01:22:51 --> Helper loaded: string_helper
INFO - 2020-03-07 01:22:51 --> Database Driver Class Initialized
DEBUG - 2020-03-07 01:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 01:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 01:22:51 --> Controller Class Initialized
INFO - 2020-03-07 01:22:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 01:22:51 --> Pagination Class Initialized
INFO - 2020-03-07 01:22:51 --> Model "M_show" initialized
INFO - 2020-03-07 01:22:51 --> Helper loaded: form_helper
INFO - 2020-03-07 01:22:51 --> Form Validation Class Initialized
INFO - 2020-03-07 01:22:51 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 01:22:51 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 01:22:51 --> Final output sent to browser
DEBUG - 2020-03-07 01:22:51 --> Total execution time: 0.2733
INFO - 2020-03-07 01:23:06 --> Config Class Initialized
INFO - 2020-03-07 01:23:06 --> Hooks Class Initialized
DEBUG - 2020-03-07 01:23:06 --> UTF-8 Support Enabled
INFO - 2020-03-07 01:23:06 --> Utf8 Class Initialized
INFO - 2020-03-07 01:23:06 --> URI Class Initialized
INFO - 2020-03-07 01:23:06 --> Router Class Initialized
INFO - 2020-03-07 01:23:06 --> Output Class Initialized
INFO - 2020-03-07 01:23:06 --> Security Class Initialized
DEBUG - 2020-03-07 01:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 01:23:06 --> Input Class Initialized
INFO - 2020-03-07 01:23:06 --> Language Class Initialized
INFO - 2020-03-07 01:23:06 --> Loader Class Initialized
INFO - 2020-03-07 01:23:06 --> Helper loaded: url_helper
INFO - 2020-03-07 01:23:06 --> Helper loaded: string_helper
INFO - 2020-03-07 01:23:06 --> Database Driver Class Initialized
DEBUG - 2020-03-07 01:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 01:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 01:23:06 --> Controller Class Initialized
INFO - 2020-03-07 01:23:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 01:23:06 --> Pagination Class Initialized
INFO - 2020-03-07 01:23:06 --> Model "M_show" initialized
INFO - 2020-03-07 01:23:06 --> Helper loaded: form_helper
INFO - 2020-03-07 01:23:06 --> Form Validation Class Initialized
INFO - 2020-03-07 01:23:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 01:23:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 01:23:06 --> Final output sent to browser
DEBUG - 2020-03-07 01:23:06 --> Total execution time: 0.0091
INFO - 2020-03-07 01:23:06 --> Config Class Initialized
INFO - 2020-03-07 01:23:06 --> Hooks Class Initialized
DEBUG - 2020-03-07 01:23:06 --> UTF-8 Support Enabled
INFO - 2020-03-07 01:23:06 --> Utf8 Class Initialized
INFO - 2020-03-07 01:23:06 --> URI Class Initialized
INFO - 2020-03-07 01:23:06 --> Router Class Initialized
INFO - 2020-03-07 01:23:06 --> Output Class Initialized
INFO - 2020-03-07 01:23:06 --> Security Class Initialized
DEBUG - 2020-03-07 01:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 01:23:06 --> Input Class Initialized
INFO - 2020-03-07 01:23:06 --> Language Class Initialized
ERROR - 2020-03-07 01:23:06 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-07 01:23:10 --> Config Class Initialized
INFO - 2020-03-07 01:23:10 --> Hooks Class Initialized
DEBUG - 2020-03-07 01:23:10 --> UTF-8 Support Enabled
INFO - 2020-03-07 01:23:10 --> Utf8 Class Initialized
INFO - 2020-03-07 01:23:10 --> URI Class Initialized
INFO - 2020-03-07 01:23:10 --> Router Class Initialized
INFO - 2020-03-07 01:23:10 --> Output Class Initialized
INFO - 2020-03-07 01:23:10 --> Security Class Initialized
DEBUG - 2020-03-07 01:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 01:23:10 --> Input Class Initialized
INFO - 2020-03-07 01:23:10 --> Language Class Initialized
INFO - 2020-03-07 01:23:10 --> Loader Class Initialized
INFO - 2020-03-07 01:23:10 --> Helper loaded: url_helper
INFO - 2020-03-07 01:23:10 --> Helper loaded: string_helper
INFO - 2020-03-07 01:23:10 --> Database Driver Class Initialized
DEBUG - 2020-03-07 01:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 01:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 01:23:10 --> Controller Class Initialized
INFO - 2020-03-07 01:23:10 --> Model "M_tiket" initialized
INFO - 2020-03-07 01:23:10 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 01:23:10 --> Model "M_pesan" initialized
INFO - 2020-03-07 01:23:10 --> Helper loaded: form_helper
INFO - 2020-03-07 01:23:10 --> Form Validation Class Initialized
INFO - 2020-03-07 01:23:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 01:23:10 --> Final output sent to browser
DEBUG - 2020-03-07 01:23:10 --> Total execution time: 0.0120
INFO - 2020-03-07 01:57:40 --> Config Class Initialized
INFO - 2020-03-07 01:57:40 --> Hooks Class Initialized
DEBUG - 2020-03-07 01:57:40 --> UTF-8 Support Enabled
INFO - 2020-03-07 01:57:40 --> Utf8 Class Initialized
INFO - 2020-03-07 01:57:40 --> URI Class Initialized
DEBUG - 2020-03-07 01:57:40 --> No URI present. Default controller set.
INFO - 2020-03-07 01:57:40 --> Router Class Initialized
INFO - 2020-03-07 01:57:40 --> Output Class Initialized
INFO - 2020-03-07 01:57:40 --> Security Class Initialized
DEBUG - 2020-03-07 01:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 01:57:40 --> Input Class Initialized
INFO - 2020-03-07 01:57:40 --> Language Class Initialized
INFO - 2020-03-07 01:57:40 --> Loader Class Initialized
INFO - 2020-03-07 01:57:40 --> Helper loaded: url_helper
INFO - 2020-03-07 01:57:40 --> Helper loaded: string_helper
INFO - 2020-03-07 01:57:40 --> Database Driver Class Initialized
DEBUG - 2020-03-07 01:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 01:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 01:57:40 --> Controller Class Initialized
INFO - 2020-03-07 01:57:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 01:57:40 --> Pagination Class Initialized
INFO - 2020-03-07 01:57:40 --> Model "M_show" initialized
INFO - 2020-03-07 01:57:40 --> Helper loaded: form_helper
INFO - 2020-03-07 01:57:40 --> Form Validation Class Initialized
INFO - 2020-03-07 01:57:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 01:57:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 01:57:40 --> Final output sent to browser
DEBUG - 2020-03-07 01:57:40 --> Total execution time: 0.0491
INFO - 2020-03-07 01:57:59 --> Config Class Initialized
INFO - 2020-03-07 01:57:59 --> Hooks Class Initialized
DEBUG - 2020-03-07 01:57:59 --> UTF-8 Support Enabled
INFO - 2020-03-07 01:57:59 --> Utf8 Class Initialized
INFO - 2020-03-07 01:57:59 --> URI Class Initialized
INFO - 2020-03-07 01:57:59 --> Router Class Initialized
INFO - 2020-03-07 01:57:59 --> Output Class Initialized
INFO - 2020-03-07 01:57:59 --> Security Class Initialized
DEBUG - 2020-03-07 01:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 01:57:59 --> Input Class Initialized
INFO - 2020-03-07 01:57:59 --> Language Class Initialized
INFO - 2020-03-07 01:57:59 --> Loader Class Initialized
INFO - 2020-03-07 01:57:59 --> Helper loaded: url_helper
INFO - 2020-03-07 01:57:59 --> Helper loaded: string_helper
INFO - 2020-03-07 01:57:59 --> Database Driver Class Initialized
DEBUG - 2020-03-07 01:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 01:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 01:57:59 --> Controller Class Initialized
INFO - 2020-03-07 01:57:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 01:57:59 --> Pagination Class Initialized
INFO - 2020-03-07 01:57:59 --> Model "M_show" initialized
INFO - 2020-03-07 01:57:59 --> Helper loaded: form_helper
INFO - 2020-03-07 01:57:59 --> Form Validation Class Initialized
INFO - 2020-03-07 01:57:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 01:57:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 01:57:59 --> Final output sent to browser
DEBUG - 2020-03-07 01:57:59 --> Total execution time: 0.0080
INFO - 2020-03-07 01:58:00 --> Config Class Initialized
INFO - 2020-03-07 01:58:00 --> Hooks Class Initialized
DEBUG - 2020-03-07 01:58:00 --> UTF-8 Support Enabled
INFO - 2020-03-07 01:58:00 --> Utf8 Class Initialized
INFO - 2020-03-07 01:58:00 --> URI Class Initialized
INFO - 2020-03-07 01:58:00 --> Router Class Initialized
INFO - 2020-03-07 01:58:00 --> Output Class Initialized
INFO - 2020-03-07 01:58:00 --> Security Class Initialized
DEBUG - 2020-03-07 01:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 01:58:00 --> Input Class Initialized
INFO - 2020-03-07 01:58:00 --> Language Class Initialized
ERROR - 2020-03-07 01:58:00 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-07 01:58:03 --> Config Class Initialized
INFO - 2020-03-07 01:58:03 --> Hooks Class Initialized
DEBUG - 2020-03-07 01:58:03 --> UTF-8 Support Enabled
INFO - 2020-03-07 01:58:03 --> Utf8 Class Initialized
INFO - 2020-03-07 01:58:03 --> URI Class Initialized
INFO - 2020-03-07 01:58:03 --> Router Class Initialized
INFO - 2020-03-07 01:58:03 --> Output Class Initialized
INFO - 2020-03-07 01:58:03 --> Security Class Initialized
DEBUG - 2020-03-07 01:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 01:58:03 --> Input Class Initialized
INFO - 2020-03-07 01:58:03 --> Language Class Initialized
INFO - 2020-03-07 01:58:03 --> Loader Class Initialized
INFO - 2020-03-07 01:58:03 --> Helper loaded: url_helper
INFO - 2020-03-07 01:58:03 --> Helper loaded: string_helper
INFO - 2020-03-07 01:58:03 --> Database Driver Class Initialized
DEBUG - 2020-03-07 01:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 01:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 01:58:03 --> Controller Class Initialized
INFO - 2020-03-07 01:58:03 --> Model "M_tiket" initialized
INFO - 2020-03-07 01:58:03 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 01:58:03 --> Model "M_pesan" initialized
INFO - 2020-03-07 01:58:03 --> Helper loaded: form_helper
INFO - 2020-03-07 01:58:03 --> Form Validation Class Initialized
INFO - 2020-03-07 01:58:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 01:58:03 --> Final output sent to browser
DEBUG - 2020-03-07 01:58:03 --> Total execution time: 0.0119
INFO - 2020-03-07 01:59:12 --> Config Class Initialized
INFO - 2020-03-07 01:59:12 --> Hooks Class Initialized
DEBUG - 2020-03-07 01:59:12 --> UTF-8 Support Enabled
INFO - 2020-03-07 01:59:12 --> Utf8 Class Initialized
INFO - 2020-03-07 01:59:12 --> URI Class Initialized
DEBUG - 2020-03-07 01:59:12 --> No URI present. Default controller set.
INFO - 2020-03-07 01:59:12 --> Router Class Initialized
INFO - 2020-03-07 01:59:12 --> Output Class Initialized
INFO - 2020-03-07 01:59:12 --> Security Class Initialized
DEBUG - 2020-03-07 01:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 01:59:12 --> Input Class Initialized
INFO - 2020-03-07 01:59:12 --> Language Class Initialized
INFO - 2020-03-07 01:59:12 --> Loader Class Initialized
INFO - 2020-03-07 01:59:12 --> Helper loaded: url_helper
INFO - 2020-03-07 01:59:12 --> Helper loaded: string_helper
INFO - 2020-03-07 01:59:12 --> Database Driver Class Initialized
DEBUG - 2020-03-07 01:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 01:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 01:59:12 --> Controller Class Initialized
INFO - 2020-03-07 01:59:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 01:59:12 --> Pagination Class Initialized
INFO - 2020-03-07 01:59:12 --> Model "M_show" initialized
INFO - 2020-03-07 01:59:12 --> Helper loaded: form_helper
INFO - 2020-03-07 01:59:12 --> Form Validation Class Initialized
INFO - 2020-03-07 01:59:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 01:59:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 01:59:12 --> Final output sent to browser
DEBUG - 2020-03-07 01:59:12 --> Total execution time: 0.0053
INFO - 2020-03-07 02:09:27 --> Config Class Initialized
INFO - 2020-03-07 02:09:27 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:09:27 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:09:27 --> Utf8 Class Initialized
INFO - 2020-03-07 02:09:27 --> URI Class Initialized
INFO - 2020-03-07 02:09:27 --> Router Class Initialized
INFO - 2020-03-07 02:09:27 --> Output Class Initialized
INFO - 2020-03-07 02:09:27 --> Security Class Initialized
DEBUG - 2020-03-07 02:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:09:27 --> Input Class Initialized
INFO - 2020-03-07 02:09:27 --> Language Class Initialized
INFO - 2020-03-07 02:09:27 --> Loader Class Initialized
INFO - 2020-03-07 02:09:27 --> Helper loaded: url_helper
INFO - 2020-03-07 02:09:27 --> Helper loaded: string_helper
INFO - 2020-03-07 02:09:27 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:09:27 --> Controller Class Initialized
INFO - 2020-03-07 02:09:27 --> Model "M_tiket" initialized
INFO - 2020-03-07 02:09:27 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 02:09:27 --> Model "M_pesan" initialized
INFO - 2020-03-07 02:09:27 --> Helper loaded: form_helper
INFO - 2020-03-07 02:09:27 --> Form Validation Class Initialized
INFO - 2020-03-07 02:09:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-07 02:09:27 --> Final output sent to browser
DEBUG - 2020-03-07 02:09:27 --> Total execution time: 0.2922
INFO - 2020-03-07 02:09:32 --> Config Class Initialized
INFO - 2020-03-07 02:09:32 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:09:32 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:09:32 --> Utf8 Class Initialized
INFO - 2020-03-07 02:09:32 --> URI Class Initialized
INFO - 2020-03-07 02:09:32 --> Router Class Initialized
INFO - 2020-03-07 02:09:32 --> Output Class Initialized
INFO - 2020-03-07 02:09:32 --> Security Class Initialized
DEBUG - 2020-03-07 02:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:09:32 --> Input Class Initialized
INFO - 2020-03-07 02:09:32 --> Language Class Initialized
INFO - 2020-03-07 02:09:32 --> Loader Class Initialized
INFO - 2020-03-07 02:09:32 --> Helper loaded: url_helper
INFO - 2020-03-07 02:09:32 --> Helper loaded: string_helper
INFO - 2020-03-07 02:09:32 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:09:32 --> Controller Class Initialized
INFO - 2020-03-07 02:09:32 --> Model "M_tiket" initialized
INFO - 2020-03-07 02:09:32 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 02:09:32 --> Model "M_pesan" initialized
INFO - 2020-03-07 02:09:32 --> Helper loaded: form_helper
INFO - 2020-03-07 02:09:32 --> Form Validation Class Initialized
INFO - 2020-03-07 02:09:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-07 02:09:32 --> Final output sent to browser
DEBUG - 2020-03-07 02:09:32 --> Total execution time: 0.0096
INFO - 2020-03-07 02:13:17 --> Config Class Initialized
INFO - 2020-03-07 02:13:17 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:13:17 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:13:17 --> Utf8 Class Initialized
INFO - 2020-03-07 02:13:17 --> URI Class Initialized
INFO - 2020-03-07 02:13:17 --> Router Class Initialized
INFO - 2020-03-07 02:13:17 --> Output Class Initialized
INFO - 2020-03-07 02:13:17 --> Security Class Initialized
DEBUG - 2020-03-07 02:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:13:17 --> Input Class Initialized
INFO - 2020-03-07 02:13:17 --> Language Class Initialized
INFO - 2020-03-07 02:13:17 --> Loader Class Initialized
INFO - 2020-03-07 02:13:17 --> Helper loaded: url_helper
INFO - 2020-03-07 02:13:17 --> Helper loaded: string_helper
INFO - 2020-03-07 02:13:17 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:13:17 --> Controller Class Initialized
INFO - 2020-03-07 02:13:17 --> Model "M_tiket" initialized
INFO - 2020-03-07 02:13:17 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 02:13:17 --> Model "M_pesan" initialized
INFO - 2020-03-07 02:13:17 --> Helper loaded: form_helper
INFO - 2020-03-07 02:13:17 --> Form Validation Class Initialized
INFO - 2020-03-07 09:13:17 --> Upload Class Initialized
INFO - 2020-03-07 09:13:17 --> Language file loaded: language/english/upload_lang.php
INFO - 2020-03-07 09:13:17 --> The file you are attempting to upload is larger than the permitted size.
INFO - 2020-03-07 02:13:17 --> Config Class Initialized
INFO - 2020-03-07 02:13:17 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:13:17 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:13:17 --> Utf8 Class Initialized
INFO - 2020-03-07 02:13:17 --> URI Class Initialized
INFO - 2020-03-07 02:13:17 --> Router Class Initialized
INFO - 2020-03-07 02:13:17 --> Output Class Initialized
INFO - 2020-03-07 02:13:17 --> Security Class Initialized
DEBUG - 2020-03-07 02:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:13:17 --> Input Class Initialized
INFO - 2020-03-07 02:13:17 --> Language Class Initialized
INFO - 2020-03-07 02:13:17 --> Loader Class Initialized
INFO - 2020-03-07 02:13:17 --> Helper loaded: url_helper
INFO - 2020-03-07 02:13:17 --> Helper loaded: string_helper
INFO - 2020-03-07 02:13:17 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:13:17 --> Controller Class Initialized
INFO - 2020-03-07 02:13:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 02:13:17 --> Pagination Class Initialized
INFO - 2020-03-07 02:13:17 --> Model "M_show" initialized
INFO - 2020-03-07 02:13:17 --> Helper loaded: form_helper
INFO - 2020-03-07 02:13:17 --> Form Validation Class Initialized
INFO - 2020-03-07 02:13:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 02:13:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 02:13:17 --> Final output sent to browser
DEBUG - 2020-03-07 02:13:17 --> Total execution time: 0.0095
INFO - 2020-03-07 02:19:14 --> Config Class Initialized
INFO - 2020-03-07 02:19:14 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:19:14 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:19:14 --> Utf8 Class Initialized
INFO - 2020-03-07 02:19:14 --> URI Class Initialized
INFO - 2020-03-07 02:19:14 --> Router Class Initialized
INFO - 2020-03-07 02:19:14 --> Output Class Initialized
INFO - 2020-03-07 02:19:14 --> Security Class Initialized
DEBUG - 2020-03-07 02:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:19:14 --> Input Class Initialized
INFO - 2020-03-07 02:19:14 --> Language Class Initialized
INFO - 2020-03-07 02:19:14 --> Loader Class Initialized
INFO - 2020-03-07 02:19:14 --> Helper loaded: url_helper
INFO - 2020-03-07 02:19:14 --> Helper loaded: string_helper
INFO - 2020-03-07 02:19:14 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:19:14 --> Controller Class Initialized
INFO - 2020-03-07 02:19:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 02:19:14 --> Pagination Class Initialized
INFO - 2020-03-07 02:19:14 --> Model "M_show" initialized
INFO - 2020-03-07 02:19:14 --> Helper loaded: form_helper
INFO - 2020-03-07 02:19:14 --> Form Validation Class Initialized
INFO - 2020-03-07 02:19:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 02:19:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 02:19:14 --> Final output sent to browser
DEBUG - 2020-03-07 02:19:14 --> Total execution time: 0.0540
INFO - 2020-03-07 02:19:23 --> Config Class Initialized
INFO - 2020-03-07 02:19:23 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:19:23 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:19:23 --> Utf8 Class Initialized
INFO - 2020-03-07 02:19:23 --> URI Class Initialized
INFO - 2020-03-07 02:19:23 --> Router Class Initialized
INFO - 2020-03-07 02:19:23 --> Output Class Initialized
INFO - 2020-03-07 02:19:23 --> Security Class Initialized
DEBUG - 2020-03-07 02:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:19:23 --> Input Class Initialized
INFO - 2020-03-07 02:19:23 --> Language Class Initialized
INFO - 2020-03-07 02:19:23 --> Loader Class Initialized
INFO - 2020-03-07 02:19:23 --> Helper loaded: url_helper
INFO - 2020-03-07 02:19:23 --> Helper loaded: string_helper
INFO - 2020-03-07 02:19:23 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:19:23 --> Controller Class Initialized
INFO - 2020-03-07 02:19:23 --> Model "M_tiket" initialized
INFO - 2020-03-07 02:19:23 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 02:19:23 --> Model "M_pesan" initialized
INFO - 2020-03-07 02:19:23 --> Helper loaded: form_helper
INFO - 2020-03-07 02:19:23 --> Form Validation Class Initialized
INFO - 2020-03-07 02:19:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 02:19:23 --> Final output sent to browser
DEBUG - 2020-03-07 02:19:23 --> Total execution time: 0.0098
INFO - 2020-03-07 02:19:35 --> Config Class Initialized
INFO - 2020-03-07 02:19:35 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:19:35 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:19:35 --> Utf8 Class Initialized
INFO - 2020-03-07 02:19:35 --> URI Class Initialized
INFO - 2020-03-07 02:19:35 --> Router Class Initialized
INFO - 2020-03-07 02:19:35 --> Output Class Initialized
INFO - 2020-03-07 02:19:35 --> Security Class Initialized
DEBUG - 2020-03-07 02:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:19:35 --> Input Class Initialized
INFO - 2020-03-07 02:19:35 --> Language Class Initialized
INFO - 2020-03-07 02:19:35 --> Loader Class Initialized
INFO - 2020-03-07 02:19:35 --> Helper loaded: url_helper
INFO - 2020-03-07 02:19:35 --> Helper loaded: string_helper
INFO - 2020-03-07 02:19:35 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:19:35 --> Controller Class Initialized
INFO - 2020-03-07 02:19:35 --> Model "M_tiket" initialized
INFO - 2020-03-07 02:19:35 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 02:19:35 --> Model "M_pesan" initialized
INFO - 2020-03-07 02:19:35 --> Helper loaded: form_helper
INFO - 2020-03-07 02:19:35 --> Form Validation Class Initialized
INFO - 2020-03-07 02:19:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 02:19:35 --> Final output sent to browser
DEBUG - 2020-03-07 02:19:35 --> Total execution time: 0.0078
INFO - 2020-03-07 02:20:36 --> Config Class Initialized
INFO - 2020-03-07 02:20:36 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:20:36 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:20:36 --> Utf8 Class Initialized
INFO - 2020-03-07 02:20:36 --> URI Class Initialized
INFO - 2020-03-07 02:20:36 --> Router Class Initialized
INFO - 2020-03-07 02:20:36 --> Output Class Initialized
INFO - 2020-03-07 02:20:36 --> Security Class Initialized
DEBUG - 2020-03-07 02:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:20:36 --> Input Class Initialized
INFO - 2020-03-07 02:20:36 --> Language Class Initialized
INFO - 2020-03-07 02:20:36 --> Loader Class Initialized
INFO - 2020-03-07 02:20:36 --> Helper loaded: url_helper
INFO - 2020-03-07 02:20:36 --> Helper loaded: string_helper
INFO - 2020-03-07 02:20:36 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:20:36 --> Controller Class Initialized
INFO - 2020-03-07 02:20:36 --> Model "M_tiket" initialized
INFO - 2020-03-07 02:20:36 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 02:20:36 --> Model "M_pesan" initialized
INFO - 2020-03-07 02:20:36 --> Helper loaded: form_helper
INFO - 2020-03-07 02:20:36 --> Form Validation Class Initialized
DEBUG - 2020-03-07 02:20:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-07 02:20:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-07 02:20:36 --> Final output sent to browser
DEBUG - 2020-03-07 02:20:36 --> Total execution time: 0.0132
INFO - 2020-03-07 02:20:40 --> Config Class Initialized
INFO - 2020-03-07 02:20:40 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:20:40 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:20:40 --> Utf8 Class Initialized
INFO - 2020-03-07 02:20:40 --> URI Class Initialized
INFO - 2020-03-07 02:20:40 --> Router Class Initialized
INFO - 2020-03-07 02:20:40 --> Output Class Initialized
INFO - 2020-03-07 02:20:40 --> Security Class Initialized
DEBUG - 2020-03-07 02:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:20:40 --> Input Class Initialized
INFO - 2020-03-07 02:20:40 --> Language Class Initialized
INFO - 2020-03-07 02:20:40 --> Loader Class Initialized
INFO - 2020-03-07 02:20:40 --> Helper loaded: url_helper
INFO - 2020-03-07 02:20:40 --> Helper loaded: string_helper
INFO - 2020-03-07 02:20:40 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:20:40 --> Controller Class Initialized
INFO - 2020-03-07 02:20:40 --> Model "M_tiket" initialized
INFO - 2020-03-07 02:20:40 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 02:20:40 --> Model "M_pesan" initialized
INFO - 2020-03-07 02:20:40 --> Helper loaded: form_helper
INFO - 2020-03-07 02:20:40 --> Form Validation Class Initialized
INFO - 2020-03-07 02:20:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 02:20:40 --> Final output sent to browser
DEBUG - 2020-03-07 02:20:40 --> Total execution time: 0.0065
INFO - 2020-03-07 02:20:45 --> Config Class Initialized
INFO - 2020-03-07 02:20:45 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:20:45 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:20:45 --> Utf8 Class Initialized
INFO - 2020-03-07 02:20:45 --> URI Class Initialized
INFO - 2020-03-07 02:20:45 --> Router Class Initialized
INFO - 2020-03-07 02:20:45 --> Output Class Initialized
INFO - 2020-03-07 02:20:45 --> Security Class Initialized
DEBUG - 2020-03-07 02:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:20:45 --> Input Class Initialized
INFO - 2020-03-07 02:20:45 --> Language Class Initialized
INFO - 2020-03-07 02:20:45 --> Loader Class Initialized
INFO - 2020-03-07 02:20:45 --> Helper loaded: url_helper
INFO - 2020-03-07 02:20:45 --> Helper loaded: string_helper
INFO - 2020-03-07 02:20:45 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:20:45 --> Controller Class Initialized
INFO - 2020-03-07 02:20:45 --> Model "M_tiket" initialized
INFO - 2020-03-07 02:20:45 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 02:20:45 --> Model "M_pesan" initialized
INFO - 2020-03-07 02:20:45 --> Helper loaded: form_helper
INFO - 2020-03-07 02:20:45 --> Form Validation Class Initialized
DEBUG - 2020-03-07 02:20:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-07 02:20:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-07 02:20:45 --> Final output sent to browser
DEBUG - 2020-03-07 02:20:45 --> Total execution time: 0.0076
INFO - 2020-03-07 02:20:59 --> Config Class Initialized
INFO - 2020-03-07 02:20:59 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:20:59 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:20:59 --> Utf8 Class Initialized
INFO - 2020-03-07 02:20:59 --> URI Class Initialized
INFO - 2020-03-07 02:20:59 --> Router Class Initialized
INFO - 2020-03-07 02:20:59 --> Output Class Initialized
INFO - 2020-03-07 02:20:59 --> Security Class Initialized
DEBUG - 2020-03-07 02:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:20:59 --> Input Class Initialized
INFO - 2020-03-07 02:20:59 --> Language Class Initialized
INFO - 2020-03-07 02:20:59 --> Loader Class Initialized
INFO - 2020-03-07 02:20:59 --> Helper loaded: url_helper
INFO - 2020-03-07 02:20:59 --> Helper loaded: string_helper
INFO - 2020-03-07 02:20:59 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:20:59 --> Controller Class Initialized
INFO - 2020-03-07 02:20:59 --> Model "M_tiket" initialized
INFO - 2020-03-07 02:20:59 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 02:20:59 --> Model "M_pesan" initialized
INFO - 2020-03-07 02:20:59 --> Helper loaded: form_helper
INFO - 2020-03-07 02:20:59 --> Form Validation Class Initialized
INFO - 2020-03-07 02:20:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 02:20:59 --> Final output sent to browser
DEBUG - 2020-03-07 02:20:59 --> Total execution time: 0.0065
INFO - 2020-03-07 02:21:07 --> Config Class Initialized
INFO - 2020-03-07 02:21:07 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:21:07 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:21:07 --> Utf8 Class Initialized
INFO - 2020-03-07 02:21:07 --> URI Class Initialized
INFO - 2020-03-07 02:21:07 --> Router Class Initialized
INFO - 2020-03-07 02:21:07 --> Output Class Initialized
INFO - 2020-03-07 02:21:07 --> Security Class Initialized
DEBUG - 2020-03-07 02:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:21:07 --> Input Class Initialized
INFO - 2020-03-07 02:21:07 --> Language Class Initialized
INFO - 2020-03-07 02:21:07 --> Loader Class Initialized
INFO - 2020-03-07 02:21:07 --> Helper loaded: url_helper
INFO - 2020-03-07 02:21:07 --> Helper loaded: string_helper
INFO - 2020-03-07 02:21:07 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:21:07 --> Controller Class Initialized
INFO - 2020-03-07 02:21:07 --> Model "M_tiket" initialized
INFO - 2020-03-07 02:21:07 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 02:21:07 --> Model "M_pesan" initialized
INFO - 2020-03-07 02:21:07 --> Helper loaded: form_helper
INFO - 2020-03-07 02:21:07 --> Form Validation Class Initialized
DEBUG - 2020-03-07 02:21:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-07 02:21:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-07 02:21:07 --> Final output sent to browser
DEBUG - 2020-03-07 02:21:07 --> Total execution time: 0.0071
INFO - 2020-03-07 02:21:10 --> Config Class Initialized
INFO - 2020-03-07 02:21:10 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:21:10 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:21:10 --> Utf8 Class Initialized
INFO - 2020-03-07 02:21:10 --> URI Class Initialized
INFO - 2020-03-07 02:21:10 --> Router Class Initialized
INFO - 2020-03-07 02:21:10 --> Output Class Initialized
INFO - 2020-03-07 02:21:10 --> Security Class Initialized
DEBUG - 2020-03-07 02:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:21:10 --> Input Class Initialized
INFO - 2020-03-07 02:21:10 --> Language Class Initialized
INFO - 2020-03-07 02:21:10 --> Loader Class Initialized
INFO - 2020-03-07 02:21:10 --> Helper loaded: url_helper
INFO - 2020-03-07 02:21:10 --> Helper loaded: string_helper
INFO - 2020-03-07 02:21:10 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:21:10 --> Controller Class Initialized
INFO - 2020-03-07 02:21:10 --> Model "M_tiket" initialized
INFO - 2020-03-07 02:21:10 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 02:21:10 --> Model "M_pesan" initialized
INFO - 2020-03-07 02:21:10 --> Helper loaded: form_helper
INFO - 2020-03-07 02:21:10 --> Form Validation Class Initialized
INFO - 2020-03-07 02:21:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 02:21:10 --> Final output sent to browser
DEBUG - 2020-03-07 02:21:10 --> Total execution time: 0.0068
INFO - 2020-03-07 02:28:39 --> Config Class Initialized
INFO - 2020-03-07 02:28:39 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:28:39 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:28:39 --> Utf8 Class Initialized
INFO - 2020-03-07 02:28:39 --> URI Class Initialized
DEBUG - 2020-03-07 02:28:39 --> No URI present. Default controller set.
INFO - 2020-03-07 02:28:39 --> Router Class Initialized
INFO - 2020-03-07 02:28:39 --> Output Class Initialized
INFO - 2020-03-07 02:28:39 --> Security Class Initialized
DEBUG - 2020-03-07 02:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:28:39 --> Input Class Initialized
INFO - 2020-03-07 02:28:39 --> Language Class Initialized
INFO - 2020-03-07 02:28:39 --> Loader Class Initialized
INFO - 2020-03-07 02:28:39 --> Helper loaded: url_helper
INFO - 2020-03-07 02:28:39 --> Helper loaded: string_helper
INFO - 2020-03-07 02:28:39 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:28:39 --> Controller Class Initialized
INFO - 2020-03-07 02:28:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 02:28:39 --> Pagination Class Initialized
INFO - 2020-03-07 02:28:39 --> Model "M_show" initialized
INFO - 2020-03-07 02:28:39 --> Helper loaded: form_helper
INFO - 2020-03-07 02:28:39 --> Form Validation Class Initialized
INFO - 2020-03-07 02:28:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 02:28:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 02:28:39 --> Final output sent to browser
DEBUG - 2020-03-07 02:28:39 --> Total execution time: 0.0493
INFO - 2020-03-07 02:29:05 --> Config Class Initialized
INFO - 2020-03-07 02:29:05 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:29:05 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:29:05 --> Utf8 Class Initialized
INFO - 2020-03-07 02:29:05 --> URI Class Initialized
INFO - 2020-03-07 02:29:05 --> Router Class Initialized
INFO - 2020-03-07 02:29:05 --> Output Class Initialized
INFO - 2020-03-07 02:29:05 --> Security Class Initialized
DEBUG - 2020-03-07 02:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:29:05 --> Input Class Initialized
INFO - 2020-03-07 02:29:05 --> Language Class Initialized
INFO - 2020-03-07 02:29:05 --> Loader Class Initialized
INFO - 2020-03-07 02:29:05 --> Helper loaded: url_helper
INFO - 2020-03-07 02:29:05 --> Helper loaded: string_helper
INFO - 2020-03-07 02:29:05 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:29:05 --> Controller Class Initialized
INFO - 2020-03-07 02:29:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 02:29:05 --> Pagination Class Initialized
INFO - 2020-03-07 02:29:05 --> Model "M_show" initialized
INFO - 2020-03-07 02:29:05 --> Helper loaded: form_helper
INFO - 2020-03-07 02:29:05 --> Form Validation Class Initialized
INFO - 2020-03-07 02:29:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 02:29:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-07 02:29:05 --> Final output sent to browser
DEBUG - 2020-03-07 02:29:05 --> Total execution time: 0.0128
INFO - 2020-03-07 02:30:02 --> Config Class Initialized
INFO - 2020-03-07 02:30:02 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:30:02 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:30:02 --> Utf8 Class Initialized
INFO - 2020-03-07 02:30:02 --> URI Class Initialized
DEBUG - 2020-03-07 02:30:02 --> No URI present. Default controller set.
INFO - 2020-03-07 02:30:02 --> Router Class Initialized
INFO - 2020-03-07 02:30:02 --> Output Class Initialized
INFO - 2020-03-07 02:30:02 --> Security Class Initialized
DEBUG - 2020-03-07 02:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:30:02 --> Input Class Initialized
INFO - 2020-03-07 02:30:02 --> Language Class Initialized
INFO - 2020-03-07 02:30:02 --> Loader Class Initialized
INFO - 2020-03-07 02:30:02 --> Helper loaded: url_helper
INFO - 2020-03-07 02:30:02 --> Helper loaded: string_helper
INFO - 2020-03-07 02:30:02 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:30:02 --> Controller Class Initialized
INFO - 2020-03-07 02:30:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 02:30:02 --> Pagination Class Initialized
INFO - 2020-03-07 02:30:02 --> Model "M_show" initialized
INFO - 2020-03-07 02:30:02 --> Helper loaded: form_helper
INFO - 2020-03-07 02:30:02 --> Form Validation Class Initialized
INFO - 2020-03-07 02:30:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 02:30:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 02:30:02 --> Final output sent to browser
DEBUG - 2020-03-07 02:30:02 --> Total execution time: 0.0083
INFO - 2020-03-07 02:30:06 --> Config Class Initialized
INFO - 2020-03-07 02:30:06 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:30:06 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:30:06 --> Utf8 Class Initialized
INFO - 2020-03-07 02:30:06 --> URI Class Initialized
DEBUG - 2020-03-07 02:30:06 --> No URI present. Default controller set.
INFO - 2020-03-07 02:30:06 --> Router Class Initialized
INFO - 2020-03-07 02:30:06 --> Output Class Initialized
INFO - 2020-03-07 02:30:06 --> Security Class Initialized
DEBUG - 2020-03-07 02:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:30:06 --> Input Class Initialized
INFO - 2020-03-07 02:30:06 --> Language Class Initialized
INFO - 2020-03-07 02:30:06 --> Loader Class Initialized
INFO - 2020-03-07 02:30:06 --> Helper loaded: url_helper
INFO - 2020-03-07 02:30:06 --> Helper loaded: string_helper
INFO - 2020-03-07 02:30:06 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:30:06 --> Controller Class Initialized
INFO - 2020-03-07 02:30:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 02:30:06 --> Pagination Class Initialized
INFO - 2020-03-07 02:30:06 --> Model "M_show" initialized
INFO - 2020-03-07 02:30:06 --> Helper loaded: form_helper
INFO - 2020-03-07 02:30:06 --> Form Validation Class Initialized
INFO - 2020-03-07 02:30:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 02:30:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 02:30:06 --> Final output sent to browser
DEBUG - 2020-03-07 02:30:06 --> Total execution time: 0.0171
INFO - 2020-03-07 02:31:55 --> Config Class Initialized
INFO - 2020-03-07 02:31:55 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:31:55 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:31:55 --> Utf8 Class Initialized
INFO - 2020-03-07 02:31:55 --> URI Class Initialized
DEBUG - 2020-03-07 02:31:55 --> No URI present. Default controller set.
INFO - 2020-03-07 02:31:55 --> Router Class Initialized
INFO - 2020-03-07 02:31:55 --> Output Class Initialized
INFO - 2020-03-07 02:31:55 --> Security Class Initialized
DEBUG - 2020-03-07 02:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:31:55 --> Input Class Initialized
INFO - 2020-03-07 02:31:55 --> Language Class Initialized
INFO - 2020-03-07 02:31:55 --> Loader Class Initialized
INFO - 2020-03-07 02:31:55 --> Helper loaded: url_helper
INFO - 2020-03-07 02:31:55 --> Helper loaded: string_helper
INFO - 2020-03-07 02:31:55 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:31:55 --> Controller Class Initialized
INFO - 2020-03-07 02:31:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 02:31:55 --> Pagination Class Initialized
INFO - 2020-03-07 02:31:55 --> Model "M_show" initialized
INFO - 2020-03-07 02:31:55 --> Helper loaded: form_helper
INFO - 2020-03-07 02:31:55 --> Form Validation Class Initialized
INFO - 2020-03-07 02:31:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 02:31:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 02:31:55 --> Final output sent to browser
DEBUG - 2020-03-07 02:31:55 --> Total execution time: 0.0399
INFO - 2020-03-07 02:31:55 --> Config Class Initialized
INFO - 2020-03-07 02:31:55 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:31:55 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:31:55 --> Utf8 Class Initialized
INFO - 2020-03-07 02:31:55 --> URI Class Initialized
INFO - 2020-03-07 02:31:55 --> Router Class Initialized
INFO - 2020-03-07 02:31:55 --> Output Class Initialized
INFO - 2020-03-07 02:31:55 --> Security Class Initialized
DEBUG - 2020-03-07 02:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:31:55 --> Input Class Initialized
INFO - 2020-03-07 02:31:55 --> Language Class Initialized
INFO - 2020-03-07 02:31:55 --> Loader Class Initialized
INFO - 2020-03-07 02:31:55 --> Helper loaded: url_helper
INFO - 2020-03-07 02:31:55 --> Helper loaded: string_helper
INFO - 2020-03-07 02:31:55 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:31:55 --> Controller Class Initialized
INFO - 2020-03-07 02:31:55 --> Model "M_tiket" initialized
INFO - 2020-03-07 02:31:55 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 02:31:55 --> Model "M_pesan" initialized
INFO - 2020-03-07 02:31:55 --> Helper loaded: form_helper
INFO - 2020-03-07 02:31:55 --> Form Validation Class Initialized
INFO - 2020-03-07 02:31:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 02:31:55 --> Final output sent to browser
DEBUG - 2020-03-07 02:31:55 --> Total execution time: 0.0108
INFO - 2020-03-07 02:31:58 --> Config Class Initialized
INFO - 2020-03-07 02:31:58 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:31:58 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:31:58 --> Utf8 Class Initialized
INFO - 2020-03-07 02:31:58 --> URI Class Initialized
INFO - 2020-03-07 02:31:58 --> Router Class Initialized
INFO - 2020-03-07 02:31:58 --> Output Class Initialized
INFO - 2020-03-07 02:31:58 --> Security Class Initialized
DEBUG - 2020-03-07 02:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:31:58 --> Input Class Initialized
INFO - 2020-03-07 02:31:58 --> Language Class Initialized
INFO - 2020-03-07 02:31:58 --> Loader Class Initialized
INFO - 2020-03-07 02:31:58 --> Helper loaded: url_helper
INFO - 2020-03-07 02:31:58 --> Helper loaded: string_helper
INFO - 2020-03-07 02:31:58 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:31:58 --> Controller Class Initialized
INFO - 2020-03-07 02:31:58 --> Model "M_tiket" initialized
INFO - 2020-03-07 02:31:58 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 02:31:58 --> Model "M_pesan" initialized
INFO - 2020-03-07 02:31:58 --> Helper loaded: form_helper
INFO - 2020-03-07 02:31:58 --> Form Validation Class Initialized
INFO - 2020-03-07 02:31:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 02:31:58 --> Final output sent to browser
DEBUG - 2020-03-07 02:31:58 --> Total execution time: 0.0072
INFO - 2020-03-07 02:32:04 --> Config Class Initialized
INFO - 2020-03-07 02:32:04 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:32:04 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:32:04 --> Utf8 Class Initialized
INFO - 2020-03-07 02:32:04 --> URI Class Initialized
INFO - 2020-03-07 02:32:04 --> Router Class Initialized
INFO - 2020-03-07 02:32:04 --> Output Class Initialized
INFO - 2020-03-07 02:32:04 --> Security Class Initialized
DEBUG - 2020-03-07 02:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:32:04 --> Input Class Initialized
INFO - 2020-03-07 02:32:04 --> Language Class Initialized
INFO - 2020-03-07 02:32:04 --> Loader Class Initialized
INFO - 2020-03-07 02:32:04 --> Helper loaded: url_helper
INFO - 2020-03-07 02:32:04 --> Helper loaded: string_helper
INFO - 2020-03-07 02:32:04 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:32:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:32:04 --> Controller Class Initialized
INFO - 2020-03-07 02:32:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 02:32:04 --> Pagination Class Initialized
INFO - 2020-03-07 02:32:04 --> Model "M_show" initialized
INFO - 2020-03-07 02:32:04 --> Helper loaded: form_helper
INFO - 2020-03-07 02:32:04 --> Form Validation Class Initialized
INFO - 2020-03-07 02:32:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 02:32:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 02:32:04 --> Final output sent to browser
DEBUG - 2020-03-07 02:32:04 --> Total execution time: 0.0086
INFO - 2020-03-07 02:32:11 --> Config Class Initialized
INFO - 2020-03-07 02:32:11 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:32:11 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:32:11 --> Utf8 Class Initialized
INFO - 2020-03-07 02:32:11 --> URI Class Initialized
INFO - 2020-03-07 02:32:11 --> Router Class Initialized
INFO - 2020-03-07 02:32:11 --> Output Class Initialized
INFO - 2020-03-07 02:32:11 --> Security Class Initialized
DEBUG - 2020-03-07 02:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:32:11 --> Input Class Initialized
INFO - 2020-03-07 02:32:11 --> Language Class Initialized
INFO - 2020-03-07 02:32:11 --> Loader Class Initialized
INFO - 2020-03-07 02:32:11 --> Helper loaded: url_helper
INFO - 2020-03-07 02:32:11 --> Helper loaded: string_helper
INFO - 2020-03-07 02:32:11 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:32:11 --> Controller Class Initialized
INFO - 2020-03-07 02:32:11 --> Model "M_tiket" initialized
INFO - 2020-03-07 02:32:11 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 02:32:11 --> Model "M_pesan" initialized
INFO - 2020-03-07 02:32:11 --> Helper loaded: form_helper
INFO - 2020-03-07 02:32:11 --> Form Validation Class Initialized
INFO - 2020-03-07 02:32:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 02:32:11 --> Final output sent to browser
DEBUG - 2020-03-07 02:32:11 --> Total execution time: 0.0067
INFO - 2020-03-07 02:32:17 --> Config Class Initialized
INFO - 2020-03-07 02:32:17 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:32:17 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:32:17 --> Utf8 Class Initialized
INFO - 2020-03-07 02:32:17 --> URI Class Initialized
INFO - 2020-03-07 02:32:17 --> Router Class Initialized
INFO - 2020-03-07 02:32:17 --> Output Class Initialized
INFO - 2020-03-07 02:32:17 --> Security Class Initialized
DEBUG - 2020-03-07 02:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:32:17 --> Input Class Initialized
INFO - 2020-03-07 02:32:17 --> Language Class Initialized
INFO - 2020-03-07 02:32:17 --> Loader Class Initialized
INFO - 2020-03-07 02:32:17 --> Helper loaded: url_helper
INFO - 2020-03-07 02:32:17 --> Helper loaded: string_helper
INFO - 2020-03-07 02:32:17 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:32:17 --> Controller Class Initialized
INFO - 2020-03-07 02:32:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 02:32:17 --> Pagination Class Initialized
INFO - 2020-03-07 02:32:17 --> Model "M_show" initialized
INFO - 2020-03-07 02:32:17 --> Helper loaded: form_helper
INFO - 2020-03-07 02:32:17 --> Form Validation Class Initialized
INFO - 2020-03-07 02:32:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 02:32:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 02:32:17 --> Final output sent to browser
DEBUG - 2020-03-07 02:32:17 --> Total execution time: 0.0073
INFO - 2020-03-07 02:32:20 --> Config Class Initialized
INFO - 2020-03-07 02:32:20 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:32:20 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:32:20 --> Utf8 Class Initialized
INFO - 2020-03-07 02:32:20 --> URI Class Initialized
DEBUG - 2020-03-07 02:32:20 --> No URI present. Default controller set.
INFO - 2020-03-07 02:32:20 --> Router Class Initialized
INFO - 2020-03-07 02:32:20 --> Output Class Initialized
INFO - 2020-03-07 02:32:20 --> Security Class Initialized
DEBUG - 2020-03-07 02:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:32:20 --> Input Class Initialized
INFO - 2020-03-07 02:32:20 --> Language Class Initialized
INFO - 2020-03-07 02:32:20 --> Loader Class Initialized
INFO - 2020-03-07 02:32:20 --> Helper loaded: url_helper
INFO - 2020-03-07 02:32:20 --> Helper loaded: string_helper
INFO - 2020-03-07 02:32:20 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:32:20 --> Controller Class Initialized
INFO - 2020-03-07 02:32:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 02:32:20 --> Pagination Class Initialized
INFO - 2020-03-07 02:32:20 --> Model "M_show" initialized
INFO - 2020-03-07 02:32:20 --> Helper loaded: form_helper
INFO - 2020-03-07 02:32:20 --> Form Validation Class Initialized
INFO - 2020-03-07 02:32:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 02:32:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 02:32:20 --> Final output sent to browser
DEBUG - 2020-03-07 02:32:20 --> Total execution time: 0.0058
INFO - 2020-03-07 02:32:21 --> Config Class Initialized
INFO - 2020-03-07 02:32:21 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:32:21 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:32:21 --> Utf8 Class Initialized
INFO - 2020-03-07 02:32:21 --> URI Class Initialized
INFO - 2020-03-07 02:32:21 --> Router Class Initialized
INFO - 2020-03-07 02:32:21 --> Output Class Initialized
INFO - 2020-03-07 02:32:21 --> Security Class Initialized
DEBUG - 2020-03-07 02:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:32:21 --> Input Class Initialized
INFO - 2020-03-07 02:32:21 --> Language Class Initialized
INFO - 2020-03-07 02:32:21 --> Loader Class Initialized
INFO - 2020-03-07 02:32:21 --> Helper loaded: url_helper
INFO - 2020-03-07 02:32:21 --> Helper loaded: string_helper
INFO - 2020-03-07 02:32:21 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:32:21 --> Controller Class Initialized
INFO - 2020-03-07 02:32:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 02:32:21 --> Pagination Class Initialized
INFO - 2020-03-07 02:32:21 --> Model "M_show" initialized
INFO - 2020-03-07 02:32:21 --> Helper loaded: form_helper
INFO - 2020-03-07 02:32:21 --> Form Validation Class Initialized
INFO - 2020-03-07 02:32:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 02:32:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/hub.php
INFO - 2020-03-07 02:32:21 --> Final output sent to browser
DEBUG - 2020-03-07 02:32:21 --> Total execution time: 0.0148
INFO - 2020-03-07 02:53:19 --> Config Class Initialized
INFO - 2020-03-07 02:53:19 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:53:19 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:53:19 --> Utf8 Class Initialized
INFO - 2020-03-07 02:53:19 --> URI Class Initialized
DEBUG - 2020-03-07 02:53:19 --> No URI present. Default controller set.
INFO - 2020-03-07 02:53:19 --> Router Class Initialized
INFO - 2020-03-07 02:53:19 --> Output Class Initialized
INFO - 2020-03-07 02:53:19 --> Security Class Initialized
DEBUG - 2020-03-07 02:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:53:19 --> Input Class Initialized
INFO - 2020-03-07 02:53:19 --> Language Class Initialized
INFO - 2020-03-07 02:53:19 --> Loader Class Initialized
INFO - 2020-03-07 02:53:19 --> Helper loaded: url_helper
INFO - 2020-03-07 02:53:19 --> Helper loaded: string_helper
INFO - 2020-03-07 02:53:19 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:53:19 --> Controller Class Initialized
INFO - 2020-03-07 02:53:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 02:53:19 --> Pagination Class Initialized
INFO - 2020-03-07 02:53:19 --> Model "M_show" initialized
INFO - 2020-03-07 02:53:19 --> Helper loaded: form_helper
INFO - 2020-03-07 02:53:19 --> Form Validation Class Initialized
INFO - 2020-03-07 02:53:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 02:53:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 02:53:19 --> Final output sent to browser
DEBUG - 2020-03-07 02:53:19 --> Total execution time: 0.1477
INFO - 2020-03-07 02:53:28 --> Config Class Initialized
INFO - 2020-03-07 02:53:28 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:53:28 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:53:28 --> Utf8 Class Initialized
INFO - 2020-03-07 02:53:28 --> URI Class Initialized
INFO - 2020-03-07 02:53:28 --> Router Class Initialized
INFO - 2020-03-07 02:53:28 --> Output Class Initialized
INFO - 2020-03-07 02:53:28 --> Security Class Initialized
DEBUG - 2020-03-07 02:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:53:28 --> Input Class Initialized
INFO - 2020-03-07 02:53:28 --> Language Class Initialized
INFO - 2020-03-07 02:53:28 --> Loader Class Initialized
INFO - 2020-03-07 02:53:28 --> Helper loaded: url_helper
INFO - 2020-03-07 02:53:28 --> Helper loaded: string_helper
INFO - 2020-03-07 02:53:28 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:53:28 --> Controller Class Initialized
INFO - 2020-03-07 02:53:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 02:53:28 --> Pagination Class Initialized
INFO - 2020-03-07 02:53:28 --> Model "M_show" initialized
INFO - 2020-03-07 02:53:28 --> Helper loaded: form_helper
INFO - 2020-03-07 02:53:28 --> Form Validation Class Initialized
INFO - 2020-03-07 02:53:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 02:53:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 02:53:28 --> Final output sent to browser
DEBUG - 2020-03-07 02:53:28 --> Total execution time: 0.0079
INFO - 2020-03-07 02:53:31 --> Config Class Initialized
INFO - 2020-03-07 02:53:31 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:53:31 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:53:31 --> Utf8 Class Initialized
INFO - 2020-03-07 02:53:31 --> URI Class Initialized
INFO - 2020-03-07 02:53:31 --> Router Class Initialized
INFO - 2020-03-07 02:53:31 --> Output Class Initialized
INFO - 2020-03-07 02:53:31 --> Security Class Initialized
DEBUG - 2020-03-07 02:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:53:31 --> Input Class Initialized
INFO - 2020-03-07 02:53:31 --> Language Class Initialized
INFO - 2020-03-07 02:53:31 --> Loader Class Initialized
INFO - 2020-03-07 02:53:31 --> Helper loaded: url_helper
INFO - 2020-03-07 02:53:31 --> Helper loaded: string_helper
INFO - 2020-03-07 02:53:31 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:53:31 --> Controller Class Initialized
INFO - 2020-03-07 02:53:31 --> Model "M_tiket" initialized
INFO - 2020-03-07 02:53:31 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 02:53:31 --> Model "M_pesan" initialized
INFO - 2020-03-07 02:53:31 --> Helper loaded: form_helper
INFO - 2020-03-07 02:53:31 --> Form Validation Class Initialized
INFO - 2020-03-07 02:53:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 02:53:31 --> Final output sent to browser
DEBUG - 2020-03-07 02:53:31 --> Total execution time: 0.0097
INFO - 2020-03-07 02:53:39 --> Config Class Initialized
INFO - 2020-03-07 02:53:39 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:53:39 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:53:39 --> Utf8 Class Initialized
INFO - 2020-03-07 02:53:39 --> URI Class Initialized
INFO - 2020-03-07 02:53:39 --> Router Class Initialized
INFO - 2020-03-07 02:53:39 --> Output Class Initialized
INFO - 2020-03-07 02:53:39 --> Security Class Initialized
DEBUG - 2020-03-07 02:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:53:39 --> Input Class Initialized
INFO - 2020-03-07 02:53:39 --> Language Class Initialized
INFO - 2020-03-07 02:53:39 --> Loader Class Initialized
INFO - 2020-03-07 02:53:39 --> Helper loaded: url_helper
INFO - 2020-03-07 02:53:39 --> Helper loaded: string_helper
INFO - 2020-03-07 02:53:39 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:53:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:53:39 --> Controller Class Initialized
INFO - 2020-03-07 02:53:39 --> Model "M_tiket" initialized
INFO - 2020-03-07 02:53:39 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 02:53:39 --> Model "M_pesan" initialized
INFO - 2020-03-07 02:53:39 --> Helper loaded: form_helper
INFO - 2020-03-07 02:53:39 --> Form Validation Class Initialized
INFO - 2020-03-07 02:53:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 02:53:39 --> Final output sent to browser
DEBUG - 2020-03-07 02:53:39 --> Total execution time: 0.0070
INFO - 2020-03-07 02:55:16 --> Config Class Initialized
INFO - 2020-03-07 02:55:16 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:55:16 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:55:16 --> Utf8 Class Initialized
INFO - 2020-03-07 02:55:16 --> URI Class Initialized
INFO - 2020-03-07 02:55:16 --> Router Class Initialized
INFO - 2020-03-07 02:55:16 --> Output Class Initialized
INFO - 2020-03-07 02:55:16 --> Security Class Initialized
DEBUG - 2020-03-07 02:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:55:16 --> Input Class Initialized
INFO - 2020-03-07 02:55:16 --> Language Class Initialized
INFO - 2020-03-07 02:55:16 --> Loader Class Initialized
INFO - 2020-03-07 02:55:16 --> Helper loaded: url_helper
INFO - 2020-03-07 02:55:16 --> Helper loaded: string_helper
INFO - 2020-03-07 02:55:16 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:55:16 --> Controller Class Initialized
INFO - 2020-03-07 02:55:16 --> Model "M_tiket" initialized
INFO - 2020-03-07 02:55:16 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 02:55:16 --> Model "M_pesan" initialized
INFO - 2020-03-07 02:55:16 --> Helper loaded: form_helper
INFO - 2020-03-07 02:55:16 --> Form Validation Class Initialized
DEBUG - 2020-03-07 02:55:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-07 02:55:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-07 09:55:17 --> Final output sent to browser
DEBUG - 2020-03-07 09:55:17 --> Total execution time: 0.6300
INFO - 2020-03-07 02:55:22 --> Config Class Initialized
INFO - 2020-03-07 02:55:22 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:55:22 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:55:22 --> Utf8 Class Initialized
INFO - 2020-03-07 02:55:22 --> URI Class Initialized
INFO - 2020-03-07 02:55:22 --> Router Class Initialized
INFO - 2020-03-07 02:55:22 --> Output Class Initialized
INFO - 2020-03-07 02:55:22 --> Security Class Initialized
DEBUG - 2020-03-07 02:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:55:22 --> Input Class Initialized
INFO - 2020-03-07 02:55:22 --> Language Class Initialized
INFO - 2020-03-07 02:55:22 --> Loader Class Initialized
INFO - 2020-03-07 02:55:22 --> Helper loaded: url_helper
INFO - 2020-03-07 02:55:22 --> Helper loaded: string_helper
INFO - 2020-03-07 02:55:22 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:55:22 --> Controller Class Initialized
INFO - 2020-03-07 02:55:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 02:55:22 --> Pagination Class Initialized
INFO - 2020-03-07 02:55:22 --> Model "M_show" initialized
INFO - 2020-03-07 02:55:22 --> Helper loaded: form_helper
INFO - 2020-03-07 02:55:22 --> Form Validation Class Initialized
INFO - 2020-03-07 02:55:22 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 02:55:22 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 02:55:22 --> Final output sent to browser
DEBUG - 2020-03-07 02:55:22 --> Total execution time: 0.0896
INFO - 2020-03-07 02:56:10 --> Config Class Initialized
INFO - 2020-03-07 02:56:10 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:56:10 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:56:10 --> Utf8 Class Initialized
INFO - 2020-03-07 02:56:10 --> URI Class Initialized
INFO - 2020-03-07 02:56:10 --> Router Class Initialized
INFO - 2020-03-07 02:56:10 --> Output Class Initialized
INFO - 2020-03-07 02:56:10 --> Security Class Initialized
DEBUG - 2020-03-07 02:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:56:10 --> Input Class Initialized
INFO - 2020-03-07 02:56:10 --> Language Class Initialized
INFO - 2020-03-07 02:56:10 --> Loader Class Initialized
INFO - 2020-03-07 02:56:10 --> Helper loaded: url_helper
INFO - 2020-03-07 02:56:10 --> Helper loaded: string_helper
INFO - 2020-03-07 02:56:10 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:56:10 --> Controller Class Initialized
INFO - 2020-03-07 02:56:10 --> Model "M_tiket" initialized
INFO - 2020-03-07 02:56:10 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 02:56:10 --> Model "M_pesan" initialized
INFO - 2020-03-07 02:56:10 --> Helper loaded: form_helper
INFO - 2020-03-07 02:56:10 --> Form Validation Class Initialized
INFO - 2020-03-07 02:56:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-07 02:56:10 --> Final output sent to browser
DEBUG - 2020-03-07 02:56:10 --> Total execution time: 0.3701
INFO - 2020-03-07 02:56:13 --> Config Class Initialized
INFO - 2020-03-07 02:56:13 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:56:13 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:56:13 --> Utf8 Class Initialized
INFO - 2020-03-07 02:56:13 --> URI Class Initialized
INFO - 2020-03-07 02:56:13 --> Router Class Initialized
INFO - 2020-03-07 02:56:13 --> Output Class Initialized
INFO - 2020-03-07 02:56:13 --> Security Class Initialized
DEBUG - 2020-03-07 02:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:56:13 --> Input Class Initialized
INFO - 2020-03-07 02:56:13 --> Language Class Initialized
INFO - 2020-03-07 02:56:13 --> Loader Class Initialized
INFO - 2020-03-07 02:56:13 --> Helper loaded: url_helper
INFO - 2020-03-07 02:56:13 --> Helper loaded: string_helper
INFO - 2020-03-07 02:56:13 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:56:13 --> Controller Class Initialized
INFO - 2020-03-07 02:56:13 --> Model "M_tiket" initialized
INFO - 2020-03-07 02:56:13 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 02:56:13 --> Model "M_pesan" initialized
INFO - 2020-03-07 02:56:13 --> Helper loaded: form_helper
INFO - 2020-03-07 02:56:13 --> Form Validation Class Initialized
INFO - 2020-03-07 02:56:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-07 02:56:13 --> Final output sent to browser
DEBUG - 2020-03-07 02:56:13 --> Total execution time: 0.0249
INFO - 2020-03-07 02:56:25 --> Config Class Initialized
INFO - 2020-03-07 02:56:25 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:56:25 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:56:25 --> Utf8 Class Initialized
INFO - 2020-03-07 02:56:25 --> URI Class Initialized
INFO - 2020-03-07 02:56:25 --> Router Class Initialized
INFO - 2020-03-07 02:56:25 --> Output Class Initialized
INFO - 2020-03-07 02:56:25 --> Security Class Initialized
DEBUG - 2020-03-07 02:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:56:25 --> Input Class Initialized
INFO - 2020-03-07 02:56:25 --> Language Class Initialized
INFO - 2020-03-07 02:56:25 --> Loader Class Initialized
INFO - 2020-03-07 02:56:25 --> Helper loaded: url_helper
INFO - 2020-03-07 02:56:25 --> Helper loaded: string_helper
INFO - 2020-03-07 02:56:25 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:56:25 --> Controller Class Initialized
INFO - 2020-03-07 02:56:25 --> Model "M_tiket" initialized
INFO - 2020-03-07 02:56:25 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 02:56:25 --> Model "M_pesan" initialized
INFO - 2020-03-07 02:56:25 --> Helper loaded: form_helper
INFO - 2020-03-07 02:56:25 --> Form Validation Class Initialized
INFO - 2020-03-07 02:56:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-07 02:56:25 --> Final output sent to browser
DEBUG - 2020-03-07 02:56:25 --> Total execution time: 0.0956
INFO - 2020-03-07 02:56:33 --> Config Class Initialized
INFO - 2020-03-07 02:56:33 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:56:33 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:56:33 --> Utf8 Class Initialized
INFO - 2020-03-07 02:56:33 --> URI Class Initialized
INFO - 2020-03-07 02:56:33 --> Router Class Initialized
INFO - 2020-03-07 02:56:33 --> Output Class Initialized
INFO - 2020-03-07 02:56:33 --> Security Class Initialized
DEBUG - 2020-03-07 02:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:56:33 --> Input Class Initialized
INFO - 2020-03-07 02:56:33 --> Language Class Initialized
INFO - 2020-03-07 02:56:33 --> Loader Class Initialized
INFO - 2020-03-07 02:56:33 --> Helper loaded: url_helper
INFO - 2020-03-07 02:56:33 --> Helper loaded: string_helper
INFO - 2020-03-07 02:56:33 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:56:33 --> Controller Class Initialized
INFO - 2020-03-07 02:56:33 --> Model "M_tiket" initialized
INFO - 2020-03-07 02:56:33 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 02:56:33 --> Model "M_pesan" initialized
INFO - 2020-03-07 02:56:33 --> Helper loaded: form_helper
INFO - 2020-03-07 02:56:33 --> Form Validation Class Initialized
INFO - 2020-03-07 02:56:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-07 02:56:33 --> Final output sent to browser
DEBUG - 2020-03-07 02:56:33 --> Total execution time: 0.0190
INFO - 2020-03-07 02:57:25 --> Config Class Initialized
INFO - 2020-03-07 02:57:25 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:57:25 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:57:25 --> Utf8 Class Initialized
INFO - 2020-03-07 02:57:25 --> URI Class Initialized
DEBUG - 2020-03-07 02:57:25 --> No URI present. Default controller set.
INFO - 2020-03-07 02:57:25 --> Router Class Initialized
INFO - 2020-03-07 02:57:25 --> Output Class Initialized
INFO - 2020-03-07 02:57:25 --> Security Class Initialized
DEBUG - 2020-03-07 02:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:57:25 --> Input Class Initialized
INFO - 2020-03-07 02:57:25 --> Language Class Initialized
INFO - 2020-03-07 02:57:25 --> Loader Class Initialized
INFO - 2020-03-07 02:57:25 --> Helper loaded: url_helper
INFO - 2020-03-07 02:57:25 --> Helper loaded: string_helper
INFO - 2020-03-07 02:57:25 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:57:26 --> Controller Class Initialized
INFO - 2020-03-07 02:57:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 02:57:26 --> Pagination Class Initialized
INFO - 2020-03-07 02:57:26 --> Model "M_show" initialized
INFO - 2020-03-07 02:57:26 --> Helper loaded: form_helper
INFO - 2020-03-07 02:57:26 --> Form Validation Class Initialized
INFO - 2020-03-07 02:57:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 02:57:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 02:57:26 --> Final output sent to browser
DEBUG - 2020-03-07 02:57:26 --> Total execution time: 0.1946
INFO - 2020-03-07 02:57:29 --> Config Class Initialized
INFO - 2020-03-07 02:57:29 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:57:29 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:57:29 --> Utf8 Class Initialized
INFO - 2020-03-07 02:57:29 --> URI Class Initialized
DEBUG - 2020-03-07 02:57:29 --> No URI present. Default controller set.
INFO - 2020-03-07 02:57:29 --> Router Class Initialized
INFO - 2020-03-07 02:57:29 --> Output Class Initialized
INFO - 2020-03-07 02:57:29 --> Security Class Initialized
DEBUG - 2020-03-07 02:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:57:29 --> Input Class Initialized
INFO - 2020-03-07 02:57:29 --> Language Class Initialized
INFO - 2020-03-07 02:57:29 --> Loader Class Initialized
INFO - 2020-03-07 02:57:29 --> Helper loaded: url_helper
INFO - 2020-03-07 02:57:29 --> Helper loaded: string_helper
INFO - 2020-03-07 02:57:29 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:57:29 --> Controller Class Initialized
INFO - 2020-03-07 02:57:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 02:57:29 --> Pagination Class Initialized
INFO - 2020-03-07 02:57:29 --> Model "M_show" initialized
INFO - 2020-03-07 02:57:29 --> Helper loaded: form_helper
INFO - 2020-03-07 02:57:29 --> Form Validation Class Initialized
INFO - 2020-03-07 02:57:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 02:57:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 02:57:29 --> Final output sent to browser
DEBUG - 2020-03-07 02:57:29 --> Total execution time: 0.0230
INFO - 2020-03-07 02:57:34 --> Config Class Initialized
INFO - 2020-03-07 02:57:34 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:57:34 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:57:34 --> Utf8 Class Initialized
INFO - 2020-03-07 02:57:34 --> URI Class Initialized
INFO - 2020-03-07 02:57:34 --> Router Class Initialized
INFO - 2020-03-07 02:57:34 --> Output Class Initialized
INFO - 2020-03-07 02:57:34 --> Security Class Initialized
DEBUG - 2020-03-07 02:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:57:34 --> Input Class Initialized
INFO - 2020-03-07 02:57:34 --> Language Class Initialized
INFO - 2020-03-07 02:57:34 --> Loader Class Initialized
INFO - 2020-03-07 02:57:34 --> Helper loaded: url_helper
INFO - 2020-03-07 02:57:34 --> Helper loaded: string_helper
INFO - 2020-03-07 02:57:34 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:57:34 --> Controller Class Initialized
INFO - 2020-03-07 02:57:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 02:57:34 --> Pagination Class Initialized
INFO - 2020-03-07 02:57:34 --> Model "M_show" initialized
INFO - 2020-03-07 02:57:34 --> Helper loaded: form_helper
INFO - 2020-03-07 02:57:34 --> Form Validation Class Initialized
INFO - 2020-03-07 02:57:34 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 02:57:34 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 02:57:34 --> Final output sent to browser
DEBUG - 2020-03-07 02:57:34 --> Total execution time: 0.2214
INFO - 2020-03-07 02:57:37 --> Config Class Initialized
INFO - 2020-03-07 02:57:37 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:57:37 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:57:37 --> Utf8 Class Initialized
INFO - 2020-03-07 02:57:37 --> URI Class Initialized
INFO - 2020-03-07 02:57:37 --> Router Class Initialized
INFO - 2020-03-07 02:57:37 --> Output Class Initialized
INFO - 2020-03-07 02:57:37 --> Security Class Initialized
DEBUG - 2020-03-07 02:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:57:37 --> Input Class Initialized
INFO - 2020-03-07 02:57:37 --> Language Class Initialized
INFO - 2020-03-07 02:57:37 --> Loader Class Initialized
INFO - 2020-03-07 02:57:37 --> Helper loaded: url_helper
INFO - 2020-03-07 02:57:37 --> Helper loaded: string_helper
INFO - 2020-03-07 02:57:37 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:57:37 --> Controller Class Initialized
INFO - 2020-03-07 02:57:37 --> Model "M_tiket" initialized
INFO - 2020-03-07 02:57:37 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 02:57:37 --> Model "M_pesan" initialized
INFO - 2020-03-07 02:57:37 --> Helper loaded: form_helper
INFO - 2020-03-07 02:57:37 --> Form Validation Class Initialized
INFO - 2020-03-07 02:57:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 02:57:37 --> Final output sent to browser
DEBUG - 2020-03-07 02:57:37 --> Total execution time: 0.4234
INFO - 2020-03-07 02:57:44 --> Config Class Initialized
INFO - 2020-03-07 02:57:44 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:57:44 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:57:44 --> Utf8 Class Initialized
INFO - 2020-03-07 02:57:44 --> URI Class Initialized
INFO - 2020-03-07 02:57:44 --> Router Class Initialized
INFO - 2020-03-07 02:57:44 --> Output Class Initialized
INFO - 2020-03-07 02:57:44 --> Security Class Initialized
DEBUG - 2020-03-07 02:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:57:44 --> Input Class Initialized
INFO - 2020-03-07 02:57:44 --> Language Class Initialized
INFO - 2020-03-07 02:57:44 --> Loader Class Initialized
INFO - 2020-03-07 02:57:44 --> Helper loaded: url_helper
INFO - 2020-03-07 02:57:44 --> Helper loaded: string_helper
INFO - 2020-03-07 02:57:44 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:57:44 --> Controller Class Initialized
INFO - 2020-03-07 02:57:44 --> Model "M_tiket" initialized
INFO - 2020-03-07 02:57:44 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 02:57:44 --> Model "M_pesan" initialized
INFO - 2020-03-07 02:57:44 --> Helper loaded: form_helper
INFO - 2020-03-07 02:57:44 --> Form Validation Class Initialized
INFO - 2020-03-07 02:57:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 02:57:44 --> Final output sent to browser
DEBUG - 2020-03-07 02:57:44 --> Total execution time: 0.1677
INFO - 2020-03-07 02:59:49 --> Config Class Initialized
INFO - 2020-03-07 02:59:49 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:59:49 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:59:49 --> Utf8 Class Initialized
INFO - 2020-03-07 02:59:49 --> URI Class Initialized
INFO - 2020-03-07 02:59:49 --> Router Class Initialized
INFO - 2020-03-07 02:59:49 --> Output Class Initialized
INFO - 2020-03-07 02:59:49 --> Security Class Initialized
DEBUG - 2020-03-07 02:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:59:49 --> Input Class Initialized
INFO - 2020-03-07 02:59:49 --> Language Class Initialized
INFO - 2020-03-07 02:59:49 --> Loader Class Initialized
INFO - 2020-03-07 02:59:49 --> Helper loaded: url_helper
INFO - 2020-03-07 02:59:49 --> Helper loaded: string_helper
INFO - 2020-03-07 02:59:49 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:59:49 --> Controller Class Initialized
INFO - 2020-03-07 02:59:49 --> Model "M_tiket" initialized
INFO - 2020-03-07 02:59:49 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 02:59:49 --> Model "M_pesan" initialized
INFO - 2020-03-07 02:59:49 --> Helper loaded: form_helper
INFO - 2020-03-07 02:59:49 --> Form Validation Class Initialized
DEBUG - 2020-03-07 02:59:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-07 02:59:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-07 09:59:49 --> Final output sent to browser
DEBUG - 2020-03-07 09:59:49 --> Total execution time: 0.2729
INFO - 2020-03-07 02:59:55 --> Config Class Initialized
INFO - 2020-03-07 02:59:55 --> Hooks Class Initialized
DEBUG - 2020-03-07 02:59:55 --> UTF-8 Support Enabled
INFO - 2020-03-07 02:59:55 --> Utf8 Class Initialized
INFO - 2020-03-07 02:59:55 --> URI Class Initialized
INFO - 2020-03-07 02:59:55 --> Router Class Initialized
INFO - 2020-03-07 02:59:55 --> Output Class Initialized
INFO - 2020-03-07 02:59:55 --> Security Class Initialized
DEBUG - 2020-03-07 02:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 02:59:55 --> Input Class Initialized
INFO - 2020-03-07 02:59:55 --> Language Class Initialized
INFO - 2020-03-07 02:59:55 --> Loader Class Initialized
INFO - 2020-03-07 02:59:55 --> Helper loaded: url_helper
INFO - 2020-03-07 02:59:55 --> Helper loaded: string_helper
INFO - 2020-03-07 02:59:55 --> Database Driver Class Initialized
DEBUG - 2020-03-07 02:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 02:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 02:59:55 --> Controller Class Initialized
INFO - 2020-03-07 02:59:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 02:59:55 --> Pagination Class Initialized
INFO - 2020-03-07 02:59:55 --> Model "M_show" initialized
INFO - 2020-03-07 02:59:55 --> Helper loaded: form_helper
INFO - 2020-03-07 02:59:55 --> Form Validation Class Initialized
INFO - 2020-03-07 02:59:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 02:59:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 02:59:55 --> Final output sent to browser
DEBUG - 2020-03-07 02:59:55 --> Total execution time: 0.0337
INFO - 2020-03-07 03:16:47 --> Config Class Initialized
INFO - 2020-03-07 03:16:47 --> Hooks Class Initialized
DEBUG - 2020-03-07 03:16:47 --> UTF-8 Support Enabled
INFO - 2020-03-07 03:16:47 --> Utf8 Class Initialized
INFO - 2020-03-07 03:16:47 --> URI Class Initialized
INFO - 2020-03-07 03:16:47 --> Router Class Initialized
INFO - 2020-03-07 03:16:47 --> Output Class Initialized
INFO - 2020-03-07 03:16:47 --> Security Class Initialized
DEBUG - 2020-03-07 03:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 03:16:47 --> Input Class Initialized
INFO - 2020-03-07 03:16:47 --> Language Class Initialized
INFO - 2020-03-07 03:16:47 --> Loader Class Initialized
INFO - 2020-03-07 03:16:47 --> Helper loaded: url_helper
INFO - 2020-03-07 03:16:47 --> Helper loaded: string_helper
INFO - 2020-03-07 03:16:47 --> Database Driver Class Initialized
DEBUG - 2020-03-07 03:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 03:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 03:16:47 --> Controller Class Initialized
INFO - 2020-03-07 03:16:47 --> Model "M_tiket" initialized
INFO - 2020-03-07 03:16:47 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 03:16:47 --> Model "M_pesan" initialized
INFO - 2020-03-07 03:16:47 --> Helper loaded: form_helper
INFO - 2020-03-07 03:16:47 --> Form Validation Class Initialized
INFO - 2020-03-07 03:16:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-07 03:16:47 --> Final output sent to browser
DEBUG - 2020-03-07 03:16:47 --> Total execution time: 0.0973
INFO - 2020-03-07 03:18:44 --> Config Class Initialized
INFO - 2020-03-07 03:18:44 --> Hooks Class Initialized
DEBUG - 2020-03-07 03:18:44 --> UTF-8 Support Enabled
INFO - 2020-03-07 03:18:44 --> Utf8 Class Initialized
INFO - 2020-03-07 03:18:44 --> URI Class Initialized
INFO - 2020-03-07 03:18:44 --> Router Class Initialized
INFO - 2020-03-07 03:18:44 --> Output Class Initialized
INFO - 2020-03-07 03:18:44 --> Security Class Initialized
DEBUG - 2020-03-07 03:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 03:18:44 --> Input Class Initialized
INFO - 2020-03-07 03:18:44 --> Language Class Initialized
INFO - 2020-03-07 03:18:44 --> Loader Class Initialized
INFO - 2020-03-07 03:18:44 --> Helper loaded: url_helper
INFO - 2020-03-07 03:18:44 --> Helper loaded: string_helper
INFO - 2020-03-07 03:18:44 --> Database Driver Class Initialized
DEBUG - 2020-03-07 03:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 03:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 03:18:44 --> Controller Class Initialized
INFO - 2020-03-07 03:18:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 03:18:44 --> Pagination Class Initialized
INFO - 2020-03-07 03:18:44 --> Model "M_show" initialized
INFO - 2020-03-07 03:18:44 --> Helper loaded: form_helper
INFO - 2020-03-07 03:18:44 --> Form Validation Class Initialized
INFO - 2020-03-07 03:18:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 03:18:44 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 03:18:44 --> Final output sent to browser
DEBUG - 2020-03-07 03:18:44 --> Total execution time: 0.0746
INFO - 2020-03-07 03:18:53 --> Config Class Initialized
INFO - 2020-03-07 03:18:53 --> Hooks Class Initialized
DEBUG - 2020-03-07 03:18:53 --> UTF-8 Support Enabled
INFO - 2020-03-07 03:18:53 --> Utf8 Class Initialized
INFO - 2020-03-07 03:18:53 --> URI Class Initialized
INFO - 2020-03-07 03:18:53 --> Router Class Initialized
INFO - 2020-03-07 03:18:53 --> Output Class Initialized
INFO - 2020-03-07 03:18:53 --> Security Class Initialized
DEBUG - 2020-03-07 03:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 03:18:53 --> Input Class Initialized
INFO - 2020-03-07 03:18:53 --> Language Class Initialized
ERROR - 2020-03-07 03:18:53 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-07 03:22:55 --> Config Class Initialized
INFO - 2020-03-07 03:22:55 --> Hooks Class Initialized
DEBUG - 2020-03-07 03:22:55 --> UTF-8 Support Enabled
INFO - 2020-03-07 03:22:55 --> Utf8 Class Initialized
INFO - 2020-03-07 03:22:55 --> URI Class Initialized
DEBUG - 2020-03-07 03:22:55 --> No URI present. Default controller set.
INFO - 2020-03-07 03:22:55 --> Router Class Initialized
INFO - 2020-03-07 03:22:55 --> Output Class Initialized
INFO - 2020-03-07 03:22:55 --> Security Class Initialized
DEBUG - 2020-03-07 03:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 03:22:55 --> Input Class Initialized
INFO - 2020-03-07 03:22:55 --> Language Class Initialized
INFO - 2020-03-07 03:22:55 --> Loader Class Initialized
INFO - 2020-03-07 03:22:55 --> Helper loaded: url_helper
INFO - 2020-03-07 03:22:55 --> Helper loaded: string_helper
INFO - 2020-03-07 03:22:55 --> Database Driver Class Initialized
DEBUG - 2020-03-07 03:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 03:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 03:22:55 --> Controller Class Initialized
INFO - 2020-03-07 03:22:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 03:22:56 --> Pagination Class Initialized
INFO - 2020-03-07 03:22:56 --> Model "M_show" initialized
INFO - 2020-03-07 03:22:56 --> Helper loaded: form_helper
INFO - 2020-03-07 03:22:56 --> Form Validation Class Initialized
INFO - 2020-03-07 03:22:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 03:22:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 03:22:56 --> Final output sent to browser
DEBUG - 2020-03-07 03:22:56 --> Total execution time: 0.1640
INFO - 2020-03-07 03:34:56 --> Config Class Initialized
INFO - 2020-03-07 03:34:56 --> Hooks Class Initialized
DEBUG - 2020-03-07 03:34:56 --> UTF-8 Support Enabled
INFO - 2020-03-07 03:34:56 --> Utf8 Class Initialized
INFO - 2020-03-07 03:34:56 --> URI Class Initialized
DEBUG - 2020-03-07 03:34:56 --> No URI present. Default controller set.
INFO - 2020-03-07 03:34:56 --> Router Class Initialized
INFO - 2020-03-07 03:34:56 --> Output Class Initialized
INFO - 2020-03-07 03:34:56 --> Security Class Initialized
DEBUG - 2020-03-07 03:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 03:34:56 --> Input Class Initialized
INFO - 2020-03-07 03:34:56 --> Language Class Initialized
INFO - 2020-03-07 03:34:56 --> Loader Class Initialized
INFO - 2020-03-07 03:34:56 --> Helper loaded: url_helper
INFO - 2020-03-07 03:34:56 --> Helper loaded: string_helper
INFO - 2020-03-07 03:34:56 --> Database Driver Class Initialized
DEBUG - 2020-03-07 03:34:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 03:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 03:34:56 --> Controller Class Initialized
INFO - 2020-03-07 03:34:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 03:34:56 --> Pagination Class Initialized
INFO - 2020-03-07 03:34:56 --> Model "M_show" initialized
INFO - 2020-03-07 03:34:56 --> Helper loaded: form_helper
INFO - 2020-03-07 03:34:56 --> Form Validation Class Initialized
INFO - 2020-03-07 03:34:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 03:34:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 03:34:56 --> Final output sent to browser
DEBUG - 2020-03-07 03:34:56 --> Total execution time: 0.0522
INFO - 2020-03-07 03:49:28 --> Config Class Initialized
INFO - 2020-03-07 03:49:28 --> Hooks Class Initialized
DEBUG - 2020-03-07 03:49:28 --> UTF-8 Support Enabled
INFO - 2020-03-07 03:49:28 --> Utf8 Class Initialized
INFO - 2020-03-07 03:49:28 --> URI Class Initialized
INFO - 2020-03-07 03:49:28 --> Router Class Initialized
INFO - 2020-03-07 03:49:28 --> Output Class Initialized
INFO - 2020-03-07 03:49:28 --> Security Class Initialized
DEBUG - 2020-03-07 03:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 03:49:28 --> Input Class Initialized
INFO - 2020-03-07 03:49:28 --> Language Class Initialized
INFO - 2020-03-07 03:49:28 --> Loader Class Initialized
INFO - 2020-03-07 03:49:28 --> Helper loaded: url_helper
INFO - 2020-03-07 03:49:28 --> Helper loaded: string_helper
INFO - 2020-03-07 03:49:28 --> Database Driver Class Initialized
DEBUG - 2020-03-07 03:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 03:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 03:49:28 --> Controller Class Initialized
INFO - 2020-03-07 03:49:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 03:49:28 --> Pagination Class Initialized
INFO - 2020-03-07 03:49:28 --> Model "M_show" initialized
INFO - 2020-03-07 03:49:28 --> Helper loaded: form_helper
INFO - 2020-03-07 03:49:28 --> Form Validation Class Initialized
INFO - 2020-03-07 03:49:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 03:49:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 03:49:28 --> Final output sent to browser
DEBUG - 2020-03-07 03:49:28 --> Total execution time: 0.0738
INFO - 2020-03-07 03:49:37 --> Config Class Initialized
INFO - 2020-03-07 03:49:37 --> Hooks Class Initialized
DEBUG - 2020-03-07 03:49:37 --> UTF-8 Support Enabled
INFO - 2020-03-07 03:49:37 --> Utf8 Class Initialized
INFO - 2020-03-07 03:49:37 --> URI Class Initialized
INFO - 2020-03-07 03:49:37 --> Router Class Initialized
INFO - 2020-03-07 03:49:37 --> Output Class Initialized
INFO - 2020-03-07 03:49:37 --> Security Class Initialized
DEBUG - 2020-03-07 03:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 03:49:37 --> Input Class Initialized
INFO - 2020-03-07 03:49:37 --> Language Class Initialized
ERROR - 2020-03-07 03:49:37 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-07 04:08:00 --> Config Class Initialized
INFO - 2020-03-07 04:08:00 --> Hooks Class Initialized
DEBUG - 2020-03-07 04:08:00 --> UTF-8 Support Enabled
INFO - 2020-03-07 04:08:00 --> Utf8 Class Initialized
INFO - 2020-03-07 04:08:00 --> URI Class Initialized
INFO - 2020-03-07 04:08:00 --> Router Class Initialized
INFO - 2020-03-07 04:08:00 --> Output Class Initialized
INFO - 2020-03-07 04:08:00 --> Security Class Initialized
DEBUG - 2020-03-07 04:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 04:08:00 --> Input Class Initialized
INFO - 2020-03-07 04:08:00 --> Language Class Initialized
INFO - 2020-03-07 04:08:00 --> Loader Class Initialized
INFO - 2020-03-07 04:08:00 --> Helper loaded: url_helper
INFO - 2020-03-07 04:08:00 --> Helper loaded: string_helper
INFO - 2020-03-07 04:08:00 --> Database Driver Class Initialized
DEBUG - 2020-03-07 04:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 04:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 04:08:01 --> Controller Class Initialized
INFO - 2020-03-07 04:08:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 04:08:01 --> Pagination Class Initialized
INFO - 2020-03-07 04:08:01 --> Model "M_show" initialized
INFO - 2020-03-07 04:08:01 --> Helper loaded: form_helper
INFO - 2020-03-07 04:08:01 --> Form Validation Class Initialized
INFO - 2020-03-07 04:08:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 04:08:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 04:08:01 --> Final output sent to browser
DEBUG - 2020-03-07 04:08:01 --> Total execution time: 0.6592
INFO - 2020-03-07 04:46:05 --> Config Class Initialized
INFO - 2020-03-07 04:46:05 --> Hooks Class Initialized
DEBUG - 2020-03-07 04:46:05 --> UTF-8 Support Enabled
INFO - 2020-03-07 04:46:05 --> Utf8 Class Initialized
INFO - 2020-03-07 04:46:05 --> URI Class Initialized
DEBUG - 2020-03-07 04:46:05 --> No URI present. Default controller set.
INFO - 2020-03-07 04:46:05 --> Router Class Initialized
INFO - 2020-03-07 04:46:05 --> Output Class Initialized
INFO - 2020-03-07 04:46:05 --> Security Class Initialized
DEBUG - 2020-03-07 04:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 04:46:05 --> Input Class Initialized
INFO - 2020-03-07 04:46:05 --> Language Class Initialized
INFO - 2020-03-07 04:46:05 --> Loader Class Initialized
INFO - 2020-03-07 04:46:05 --> Helper loaded: url_helper
INFO - 2020-03-07 04:46:05 --> Helper loaded: string_helper
INFO - 2020-03-07 04:46:05 --> Database Driver Class Initialized
DEBUG - 2020-03-07 04:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 04:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 04:46:05 --> Controller Class Initialized
INFO - 2020-03-07 04:46:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 04:46:05 --> Pagination Class Initialized
INFO - 2020-03-07 04:46:05 --> Model "M_show" initialized
INFO - 2020-03-07 04:46:05 --> Helper loaded: form_helper
INFO - 2020-03-07 04:46:05 --> Form Validation Class Initialized
INFO - 2020-03-07 04:46:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 04:46:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 04:46:05 --> Final output sent to browser
DEBUG - 2020-03-07 04:46:05 --> Total execution time: 0.1676
INFO - 2020-03-07 04:46:22 --> Config Class Initialized
INFO - 2020-03-07 04:46:22 --> Hooks Class Initialized
DEBUG - 2020-03-07 04:46:22 --> UTF-8 Support Enabled
INFO - 2020-03-07 04:46:22 --> Utf8 Class Initialized
INFO - 2020-03-07 04:46:22 --> URI Class Initialized
INFO - 2020-03-07 04:46:22 --> Router Class Initialized
INFO - 2020-03-07 04:46:22 --> Output Class Initialized
INFO - 2020-03-07 04:46:22 --> Security Class Initialized
DEBUG - 2020-03-07 04:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 04:46:22 --> Input Class Initialized
INFO - 2020-03-07 04:46:22 --> Language Class Initialized
INFO - 2020-03-07 04:46:22 --> Loader Class Initialized
INFO - 2020-03-07 04:46:22 --> Helper loaded: url_helper
INFO - 2020-03-07 04:46:22 --> Helper loaded: string_helper
INFO - 2020-03-07 04:46:22 --> Database Driver Class Initialized
DEBUG - 2020-03-07 04:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 04:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 04:46:22 --> Controller Class Initialized
INFO - 2020-03-07 04:46:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 04:46:22 --> Pagination Class Initialized
INFO - 2020-03-07 04:46:22 --> Model "M_show" initialized
INFO - 2020-03-07 04:46:22 --> Helper loaded: form_helper
INFO - 2020-03-07 04:46:22 --> Form Validation Class Initialized
INFO - 2020-03-07 04:46:22 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 04:46:22 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 04:46:22 --> Final output sent to browser
DEBUG - 2020-03-07 04:46:22 --> Total execution time: 0.0481
INFO - 2020-03-07 04:46:27 --> Config Class Initialized
INFO - 2020-03-07 04:46:27 --> Hooks Class Initialized
DEBUG - 2020-03-07 04:46:27 --> UTF-8 Support Enabled
INFO - 2020-03-07 04:46:27 --> Utf8 Class Initialized
INFO - 2020-03-07 04:46:27 --> URI Class Initialized
INFO - 2020-03-07 04:46:27 --> Router Class Initialized
INFO - 2020-03-07 04:46:27 --> Output Class Initialized
INFO - 2020-03-07 04:46:27 --> Security Class Initialized
DEBUG - 2020-03-07 04:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 04:46:27 --> Input Class Initialized
INFO - 2020-03-07 04:46:27 --> Language Class Initialized
INFO - 2020-03-07 04:46:27 --> Loader Class Initialized
INFO - 2020-03-07 04:46:27 --> Helper loaded: url_helper
INFO - 2020-03-07 04:46:27 --> Helper loaded: string_helper
INFO - 2020-03-07 04:46:27 --> Database Driver Class Initialized
DEBUG - 2020-03-07 04:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 04:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 04:46:27 --> Controller Class Initialized
INFO - 2020-03-07 04:46:27 --> Model "M_tiket" initialized
INFO - 2020-03-07 04:46:27 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 04:46:27 --> Model "M_pesan" initialized
INFO - 2020-03-07 04:46:27 --> Helper loaded: form_helper
INFO - 2020-03-07 04:46:27 --> Form Validation Class Initialized
INFO - 2020-03-07 04:46:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 04:46:27 --> Final output sent to browser
DEBUG - 2020-03-07 04:46:27 --> Total execution time: 0.0287
INFO - 2020-03-07 04:46:39 --> Config Class Initialized
INFO - 2020-03-07 04:46:39 --> Hooks Class Initialized
DEBUG - 2020-03-07 04:46:39 --> UTF-8 Support Enabled
INFO - 2020-03-07 04:46:39 --> Utf8 Class Initialized
INFO - 2020-03-07 04:46:39 --> URI Class Initialized
DEBUG - 2020-03-07 04:46:39 --> No URI present. Default controller set.
INFO - 2020-03-07 04:46:39 --> Router Class Initialized
INFO - 2020-03-07 04:46:39 --> Output Class Initialized
INFO - 2020-03-07 04:46:39 --> Security Class Initialized
DEBUG - 2020-03-07 04:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 04:46:39 --> Input Class Initialized
INFO - 2020-03-07 04:46:39 --> Language Class Initialized
INFO - 2020-03-07 04:46:39 --> Loader Class Initialized
INFO - 2020-03-07 04:46:39 --> Helper loaded: url_helper
INFO - 2020-03-07 04:46:39 --> Helper loaded: string_helper
INFO - 2020-03-07 04:46:39 --> Database Driver Class Initialized
DEBUG - 2020-03-07 04:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 04:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 04:46:39 --> Controller Class Initialized
INFO - 2020-03-07 04:46:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 04:46:39 --> Pagination Class Initialized
INFO - 2020-03-07 04:46:39 --> Model "M_show" initialized
INFO - 2020-03-07 04:46:39 --> Helper loaded: form_helper
INFO - 2020-03-07 04:46:39 --> Form Validation Class Initialized
INFO - 2020-03-07 04:46:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 04:46:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 04:46:39 --> Final output sent to browser
DEBUG - 2020-03-07 04:46:39 --> Total execution time: 0.0099
INFO - 2020-03-07 04:46:47 --> Config Class Initialized
INFO - 2020-03-07 04:46:47 --> Hooks Class Initialized
DEBUG - 2020-03-07 04:46:47 --> UTF-8 Support Enabled
INFO - 2020-03-07 04:46:47 --> Utf8 Class Initialized
INFO - 2020-03-07 04:46:47 --> URI Class Initialized
INFO - 2020-03-07 04:46:47 --> Router Class Initialized
INFO - 2020-03-07 04:46:47 --> Output Class Initialized
INFO - 2020-03-07 04:46:47 --> Security Class Initialized
DEBUG - 2020-03-07 04:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 04:46:47 --> Input Class Initialized
INFO - 2020-03-07 04:46:47 --> Language Class Initialized
INFO - 2020-03-07 04:46:47 --> Loader Class Initialized
INFO - 2020-03-07 04:46:47 --> Helper loaded: url_helper
INFO - 2020-03-07 04:46:47 --> Helper loaded: string_helper
INFO - 2020-03-07 04:46:47 --> Database Driver Class Initialized
DEBUG - 2020-03-07 04:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 04:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 04:46:47 --> Controller Class Initialized
INFO - 2020-03-07 04:46:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 04:46:47 --> Pagination Class Initialized
INFO - 2020-03-07 04:46:47 --> Model "M_show" initialized
INFO - 2020-03-07 04:46:47 --> Helper loaded: form_helper
INFO - 2020-03-07 04:46:47 --> Form Validation Class Initialized
INFO - 2020-03-07 04:46:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 04:46:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 04:46:47 --> Final output sent to browser
DEBUG - 2020-03-07 04:46:47 --> Total execution time: 0.0062
INFO - 2020-03-07 04:46:47 --> Config Class Initialized
INFO - 2020-03-07 04:46:47 --> Hooks Class Initialized
DEBUG - 2020-03-07 04:46:47 --> UTF-8 Support Enabled
INFO - 2020-03-07 04:46:47 --> Utf8 Class Initialized
INFO - 2020-03-07 04:46:47 --> URI Class Initialized
INFO - 2020-03-07 04:46:47 --> Router Class Initialized
INFO - 2020-03-07 04:46:47 --> Output Class Initialized
INFO - 2020-03-07 04:46:47 --> Security Class Initialized
DEBUG - 2020-03-07 04:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 04:46:47 --> Input Class Initialized
INFO - 2020-03-07 04:46:47 --> Language Class Initialized
ERROR - 2020-03-07 04:46:47 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-07 04:46:56 --> Config Class Initialized
INFO - 2020-03-07 04:46:56 --> Hooks Class Initialized
DEBUG - 2020-03-07 04:46:56 --> UTF-8 Support Enabled
INFO - 2020-03-07 04:46:56 --> Utf8 Class Initialized
INFO - 2020-03-07 04:46:56 --> URI Class Initialized
INFO - 2020-03-07 04:46:56 --> Router Class Initialized
INFO - 2020-03-07 04:46:56 --> Output Class Initialized
INFO - 2020-03-07 04:46:56 --> Security Class Initialized
DEBUG - 2020-03-07 04:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 04:46:56 --> Input Class Initialized
INFO - 2020-03-07 04:46:56 --> Language Class Initialized
INFO - 2020-03-07 04:46:56 --> Loader Class Initialized
INFO - 2020-03-07 04:46:56 --> Helper loaded: url_helper
INFO - 2020-03-07 04:46:56 --> Helper loaded: string_helper
INFO - 2020-03-07 04:46:56 --> Database Driver Class Initialized
DEBUG - 2020-03-07 04:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 04:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 04:46:56 --> Controller Class Initialized
INFO - 2020-03-07 04:46:56 --> Model "M_tiket" initialized
INFO - 2020-03-07 04:46:56 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 04:46:56 --> Model "M_pesan" initialized
INFO - 2020-03-07 04:46:56 --> Helper loaded: form_helper
INFO - 2020-03-07 04:46:56 --> Form Validation Class Initialized
INFO - 2020-03-07 04:46:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 04:46:56 --> Final output sent to browser
DEBUG - 2020-03-07 04:46:56 --> Total execution time: 0.0724
INFO - 2020-03-07 04:47:05 --> Config Class Initialized
INFO - 2020-03-07 04:47:05 --> Hooks Class Initialized
DEBUG - 2020-03-07 04:47:05 --> UTF-8 Support Enabled
INFO - 2020-03-07 04:47:05 --> Utf8 Class Initialized
INFO - 2020-03-07 04:47:05 --> URI Class Initialized
DEBUG - 2020-03-07 04:47:05 --> No URI present. Default controller set.
INFO - 2020-03-07 04:47:05 --> Router Class Initialized
INFO - 2020-03-07 04:47:05 --> Output Class Initialized
INFO - 2020-03-07 04:47:05 --> Security Class Initialized
DEBUG - 2020-03-07 04:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 04:47:05 --> Input Class Initialized
INFO - 2020-03-07 04:47:05 --> Language Class Initialized
INFO - 2020-03-07 04:47:05 --> Loader Class Initialized
INFO - 2020-03-07 04:47:05 --> Helper loaded: url_helper
INFO - 2020-03-07 04:47:05 --> Helper loaded: string_helper
INFO - 2020-03-07 04:47:05 --> Database Driver Class Initialized
DEBUG - 2020-03-07 04:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 04:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 04:47:05 --> Controller Class Initialized
INFO - 2020-03-07 04:47:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 04:47:05 --> Pagination Class Initialized
INFO - 2020-03-07 04:47:05 --> Model "M_show" initialized
INFO - 2020-03-07 04:47:05 --> Helper loaded: form_helper
INFO - 2020-03-07 04:47:05 --> Form Validation Class Initialized
INFO - 2020-03-07 04:47:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 04:47:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 04:47:05 --> Final output sent to browser
DEBUG - 2020-03-07 04:47:05 --> Total execution time: 0.1253
INFO - 2020-03-07 04:47:11 --> Config Class Initialized
INFO - 2020-03-07 04:47:11 --> Hooks Class Initialized
DEBUG - 2020-03-07 04:47:11 --> UTF-8 Support Enabled
INFO - 2020-03-07 04:47:11 --> Utf8 Class Initialized
INFO - 2020-03-07 04:47:11 --> URI Class Initialized
INFO - 2020-03-07 04:47:11 --> Router Class Initialized
INFO - 2020-03-07 04:47:11 --> Output Class Initialized
INFO - 2020-03-07 04:47:11 --> Security Class Initialized
DEBUG - 2020-03-07 04:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 04:47:11 --> Input Class Initialized
INFO - 2020-03-07 04:47:11 --> Language Class Initialized
INFO - 2020-03-07 04:47:11 --> Loader Class Initialized
INFO - 2020-03-07 04:47:11 --> Helper loaded: url_helper
INFO - 2020-03-07 04:47:11 --> Helper loaded: string_helper
INFO - 2020-03-07 04:47:11 --> Database Driver Class Initialized
DEBUG - 2020-03-07 04:47:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 04:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 04:47:11 --> Controller Class Initialized
INFO - 2020-03-07 04:47:11 --> Model "M_tiket" initialized
INFO - 2020-03-07 04:47:11 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 04:47:11 --> Model "M_pesan" initialized
INFO - 2020-03-07 04:47:11 --> Helper loaded: form_helper
INFO - 2020-03-07 04:47:11 --> Form Validation Class Initialized
INFO - 2020-03-07 04:47:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 04:47:11 --> Final output sent to browser
DEBUG - 2020-03-07 04:47:11 --> Total execution time: 0.0121
INFO - 2020-03-07 04:47:25 --> Config Class Initialized
INFO - 2020-03-07 04:47:25 --> Hooks Class Initialized
DEBUG - 2020-03-07 04:47:25 --> UTF-8 Support Enabled
INFO - 2020-03-07 04:47:25 --> Utf8 Class Initialized
INFO - 2020-03-07 04:47:25 --> URI Class Initialized
INFO - 2020-03-07 04:47:25 --> Router Class Initialized
INFO - 2020-03-07 04:47:25 --> Output Class Initialized
INFO - 2020-03-07 04:47:25 --> Security Class Initialized
DEBUG - 2020-03-07 04:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 04:47:25 --> Input Class Initialized
INFO - 2020-03-07 04:47:25 --> Language Class Initialized
INFO - 2020-03-07 04:47:25 --> Loader Class Initialized
INFO - 2020-03-07 04:47:25 --> Helper loaded: url_helper
INFO - 2020-03-07 04:47:25 --> Helper loaded: string_helper
INFO - 2020-03-07 04:47:25 --> Database Driver Class Initialized
DEBUG - 2020-03-07 04:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 04:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 04:47:25 --> Controller Class Initialized
INFO - 2020-03-07 04:47:25 --> Model "M_tiket" initialized
INFO - 2020-03-07 04:47:25 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 04:47:25 --> Model "M_pesan" initialized
INFO - 2020-03-07 04:47:25 --> Helper loaded: form_helper
INFO - 2020-03-07 04:47:25 --> Form Validation Class Initialized
INFO - 2020-03-07 04:47:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 04:47:25 --> Final output sent to browser
DEBUG - 2020-03-07 04:47:25 --> Total execution time: 0.4400
INFO - 2020-03-07 04:54:16 --> Config Class Initialized
INFO - 2020-03-07 04:54:16 --> Hooks Class Initialized
DEBUG - 2020-03-07 04:54:16 --> UTF-8 Support Enabled
INFO - 2020-03-07 04:54:16 --> Utf8 Class Initialized
INFO - 2020-03-07 04:54:16 --> URI Class Initialized
DEBUG - 2020-03-07 04:54:16 --> No URI present. Default controller set.
INFO - 2020-03-07 04:54:16 --> Router Class Initialized
INFO - 2020-03-07 04:54:16 --> Output Class Initialized
INFO - 2020-03-07 04:54:16 --> Security Class Initialized
DEBUG - 2020-03-07 04:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 04:54:16 --> Input Class Initialized
INFO - 2020-03-07 04:54:16 --> Language Class Initialized
INFO - 2020-03-07 04:54:16 --> Loader Class Initialized
INFO - 2020-03-07 04:54:16 --> Helper loaded: url_helper
INFO - 2020-03-07 04:54:16 --> Helper loaded: string_helper
INFO - 2020-03-07 04:54:16 --> Database Driver Class Initialized
DEBUG - 2020-03-07 04:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 04:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 04:54:16 --> Controller Class Initialized
INFO - 2020-03-07 04:54:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 04:54:16 --> Pagination Class Initialized
INFO - 2020-03-07 04:54:16 --> Model "M_show" initialized
INFO - 2020-03-07 04:54:16 --> Helper loaded: form_helper
INFO - 2020-03-07 04:54:16 --> Form Validation Class Initialized
INFO - 2020-03-07 04:54:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 04:54:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 04:54:16 --> Final output sent to browser
DEBUG - 2020-03-07 04:54:16 --> Total execution time: 0.0942
INFO - 2020-03-07 04:54:45 --> Config Class Initialized
INFO - 2020-03-07 04:54:45 --> Hooks Class Initialized
DEBUG - 2020-03-07 04:54:45 --> UTF-8 Support Enabled
INFO - 2020-03-07 04:54:45 --> Utf8 Class Initialized
INFO - 2020-03-07 04:54:45 --> URI Class Initialized
INFO - 2020-03-07 04:54:45 --> Router Class Initialized
INFO - 2020-03-07 04:54:45 --> Output Class Initialized
INFO - 2020-03-07 04:54:45 --> Security Class Initialized
DEBUG - 2020-03-07 04:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 04:54:45 --> Input Class Initialized
INFO - 2020-03-07 04:54:45 --> Language Class Initialized
INFO - 2020-03-07 04:54:45 --> Loader Class Initialized
INFO - 2020-03-07 04:54:45 --> Helper loaded: url_helper
INFO - 2020-03-07 04:54:45 --> Helper loaded: string_helper
INFO - 2020-03-07 04:54:45 --> Database Driver Class Initialized
DEBUG - 2020-03-07 04:54:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 04:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 04:54:45 --> Controller Class Initialized
INFO - 2020-03-07 04:54:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 04:54:45 --> Pagination Class Initialized
INFO - 2020-03-07 04:54:45 --> Model "M_show" initialized
INFO - 2020-03-07 04:54:45 --> Helper loaded: form_helper
INFO - 2020-03-07 04:54:45 --> Form Validation Class Initialized
INFO - 2020-03-07 04:54:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 04:54:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 04:54:45 --> Final output sent to browser
DEBUG - 2020-03-07 04:54:45 --> Total execution time: 0.0833
INFO - 2020-03-07 04:54:46 --> Config Class Initialized
INFO - 2020-03-07 04:54:46 --> Hooks Class Initialized
DEBUG - 2020-03-07 04:54:46 --> UTF-8 Support Enabled
INFO - 2020-03-07 04:54:46 --> Utf8 Class Initialized
INFO - 2020-03-07 04:54:46 --> URI Class Initialized
INFO - 2020-03-07 04:54:46 --> Router Class Initialized
INFO - 2020-03-07 04:54:46 --> Output Class Initialized
INFO - 2020-03-07 04:54:46 --> Security Class Initialized
DEBUG - 2020-03-07 04:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 04:54:46 --> Input Class Initialized
INFO - 2020-03-07 04:54:46 --> Language Class Initialized
INFO - 2020-03-07 04:54:46 --> Loader Class Initialized
INFO - 2020-03-07 04:54:46 --> Helper loaded: url_helper
INFO - 2020-03-07 04:54:46 --> Helper loaded: string_helper
INFO - 2020-03-07 04:54:46 --> Database Driver Class Initialized
DEBUG - 2020-03-07 04:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 04:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 04:54:46 --> Controller Class Initialized
INFO - 2020-03-07 04:54:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 04:54:46 --> Pagination Class Initialized
INFO - 2020-03-07 04:54:46 --> Model "M_show" initialized
INFO - 2020-03-07 04:54:46 --> Helper loaded: form_helper
INFO - 2020-03-07 04:54:46 --> Form Validation Class Initialized
INFO - 2020-03-07 04:54:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 04:54:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 04:54:46 --> Final output sent to browser
DEBUG - 2020-03-07 04:54:46 --> Total execution time: 0.0139
INFO - 2020-03-07 04:54:47 --> Config Class Initialized
INFO - 2020-03-07 04:54:47 --> Hooks Class Initialized
DEBUG - 2020-03-07 04:54:47 --> UTF-8 Support Enabled
INFO - 2020-03-07 04:54:47 --> Utf8 Class Initialized
INFO - 2020-03-07 04:54:47 --> URI Class Initialized
INFO - 2020-03-07 04:54:47 --> Router Class Initialized
INFO - 2020-03-07 04:54:47 --> Output Class Initialized
INFO - 2020-03-07 04:54:47 --> Security Class Initialized
DEBUG - 2020-03-07 04:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 04:54:47 --> Input Class Initialized
INFO - 2020-03-07 04:54:47 --> Language Class Initialized
INFO - 2020-03-07 04:54:47 --> Loader Class Initialized
INFO - 2020-03-07 04:54:47 --> Helper loaded: url_helper
INFO - 2020-03-07 04:54:47 --> Helper loaded: string_helper
INFO - 2020-03-07 04:54:47 --> Database Driver Class Initialized
DEBUG - 2020-03-07 04:54:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 04:54:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 04:54:47 --> Controller Class Initialized
INFO - 2020-03-07 04:54:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 04:54:47 --> Pagination Class Initialized
INFO - 2020-03-07 04:54:47 --> Model "M_show" initialized
INFO - 2020-03-07 04:54:47 --> Helper loaded: form_helper
INFO - 2020-03-07 04:54:47 --> Form Validation Class Initialized
INFO - 2020-03-07 04:54:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 04:54:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 04:54:47 --> Final output sent to browser
DEBUG - 2020-03-07 04:54:47 --> Total execution time: 0.0568
INFO - 2020-03-07 04:54:48 --> Config Class Initialized
INFO - 2020-03-07 04:54:48 --> Hooks Class Initialized
DEBUG - 2020-03-07 04:54:48 --> UTF-8 Support Enabled
INFO - 2020-03-07 04:54:48 --> Utf8 Class Initialized
INFO - 2020-03-07 04:54:48 --> URI Class Initialized
INFO - 2020-03-07 04:54:48 --> Router Class Initialized
INFO - 2020-03-07 04:54:48 --> Output Class Initialized
INFO - 2020-03-07 04:54:48 --> Security Class Initialized
DEBUG - 2020-03-07 04:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 04:54:48 --> Input Class Initialized
INFO - 2020-03-07 04:54:48 --> Language Class Initialized
ERROR - 2020-03-07 04:54:48 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-07 04:54:52 --> Config Class Initialized
INFO - 2020-03-07 04:54:52 --> Hooks Class Initialized
DEBUG - 2020-03-07 04:54:52 --> UTF-8 Support Enabled
INFO - 2020-03-07 04:54:52 --> Utf8 Class Initialized
INFO - 2020-03-07 04:54:52 --> URI Class Initialized
INFO - 2020-03-07 04:54:52 --> Router Class Initialized
INFO - 2020-03-07 04:54:52 --> Output Class Initialized
INFO - 2020-03-07 04:54:52 --> Security Class Initialized
DEBUG - 2020-03-07 04:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 04:54:52 --> Input Class Initialized
INFO - 2020-03-07 04:54:52 --> Language Class Initialized
INFO - 2020-03-07 04:54:52 --> Loader Class Initialized
INFO - 2020-03-07 04:54:52 --> Helper loaded: url_helper
INFO - 2020-03-07 04:54:52 --> Helper loaded: string_helper
INFO - 2020-03-07 04:54:52 --> Database Driver Class Initialized
DEBUG - 2020-03-07 04:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 04:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 04:54:52 --> Controller Class Initialized
INFO - 2020-03-07 04:54:52 --> Model "M_tiket" initialized
INFO - 2020-03-07 04:54:52 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 04:54:52 --> Model "M_pesan" initialized
INFO - 2020-03-07 04:54:52 --> Helper loaded: form_helper
INFO - 2020-03-07 04:54:52 --> Form Validation Class Initialized
INFO - 2020-03-07 04:54:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 04:54:52 --> Final output sent to browser
DEBUG - 2020-03-07 04:54:52 --> Total execution time: 0.0099
INFO - 2020-03-07 04:55:04 --> Config Class Initialized
INFO - 2020-03-07 04:55:04 --> Hooks Class Initialized
DEBUG - 2020-03-07 04:55:04 --> UTF-8 Support Enabled
INFO - 2020-03-07 04:55:04 --> Utf8 Class Initialized
INFO - 2020-03-07 04:55:04 --> URI Class Initialized
DEBUG - 2020-03-07 04:55:04 --> No URI present. Default controller set.
INFO - 2020-03-07 04:55:04 --> Router Class Initialized
INFO - 2020-03-07 04:55:04 --> Output Class Initialized
INFO - 2020-03-07 04:55:04 --> Security Class Initialized
DEBUG - 2020-03-07 04:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 04:55:04 --> Input Class Initialized
INFO - 2020-03-07 04:55:04 --> Language Class Initialized
INFO - 2020-03-07 04:55:04 --> Loader Class Initialized
INFO - 2020-03-07 04:55:04 --> Helper loaded: url_helper
INFO - 2020-03-07 04:55:04 --> Helper loaded: string_helper
INFO - 2020-03-07 04:55:04 --> Database Driver Class Initialized
DEBUG - 2020-03-07 04:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 04:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 04:55:04 --> Controller Class Initialized
INFO - 2020-03-07 04:55:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 04:55:04 --> Pagination Class Initialized
INFO - 2020-03-07 04:55:04 --> Model "M_show" initialized
INFO - 2020-03-07 04:55:04 --> Helper loaded: form_helper
INFO - 2020-03-07 04:55:04 --> Form Validation Class Initialized
INFO - 2020-03-07 04:55:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 04:55:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 04:55:04 --> Final output sent to browser
DEBUG - 2020-03-07 04:55:04 --> Total execution time: 0.0054
INFO - 2020-03-07 04:57:32 --> Config Class Initialized
INFO - 2020-03-07 04:57:32 --> Hooks Class Initialized
DEBUG - 2020-03-07 04:57:32 --> UTF-8 Support Enabled
INFO - 2020-03-07 04:57:32 --> Utf8 Class Initialized
INFO - 2020-03-07 04:57:32 --> URI Class Initialized
DEBUG - 2020-03-07 04:57:32 --> No URI present. Default controller set.
INFO - 2020-03-07 04:57:32 --> Router Class Initialized
INFO - 2020-03-07 04:57:32 --> Output Class Initialized
INFO - 2020-03-07 04:57:32 --> Security Class Initialized
DEBUG - 2020-03-07 04:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 04:57:32 --> Input Class Initialized
INFO - 2020-03-07 04:57:32 --> Language Class Initialized
INFO - 2020-03-07 04:57:32 --> Loader Class Initialized
INFO - 2020-03-07 04:57:32 --> Helper loaded: url_helper
INFO - 2020-03-07 04:57:32 --> Helper loaded: string_helper
INFO - 2020-03-07 04:57:32 --> Database Driver Class Initialized
DEBUG - 2020-03-07 04:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 04:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 04:57:32 --> Controller Class Initialized
INFO - 2020-03-07 04:57:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 04:57:32 --> Pagination Class Initialized
INFO - 2020-03-07 04:57:32 --> Model "M_show" initialized
INFO - 2020-03-07 04:57:32 --> Helper loaded: form_helper
INFO - 2020-03-07 04:57:32 --> Form Validation Class Initialized
INFO - 2020-03-07 04:57:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 04:57:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 04:57:32 --> Final output sent to browser
DEBUG - 2020-03-07 04:57:32 --> Total execution time: 0.1451
INFO - 2020-03-07 04:57:41 --> Config Class Initialized
INFO - 2020-03-07 04:57:41 --> Hooks Class Initialized
DEBUG - 2020-03-07 04:57:41 --> UTF-8 Support Enabled
INFO - 2020-03-07 04:57:41 --> Utf8 Class Initialized
INFO - 2020-03-07 04:57:41 --> URI Class Initialized
INFO - 2020-03-07 04:57:41 --> Router Class Initialized
INFO - 2020-03-07 04:57:41 --> Output Class Initialized
INFO - 2020-03-07 04:57:41 --> Security Class Initialized
DEBUG - 2020-03-07 04:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 04:57:41 --> Input Class Initialized
INFO - 2020-03-07 04:57:41 --> Language Class Initialized
INFO - 2020-03-07 04:57:41 --> Loader Class Initialized
INFO - 2020-03-07 04:57:41 --> Helper loaded: url_helper
INFO - 2020-03-07 04:57:41 --> Helper loaded: string_helper
INFO - 2020-03-07 04:57:41 --> Database Driver Class Initialized
DEBUG - 2020-03-07 04:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 04:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 04:57:41 --> Controller Class Initialized
INFO - 2020-03-07 04:57:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 04:57:41 --> Pagination Class Initialized
INFO - 2020-03-07 04:57:41 --> Model "M_show" initialized
INFO - 2020-03-07 04:57:41 --> Helper loaded: form_helper
INFO - 2020-03-07 04:57:41 --> Form Validation Class Initialized
INFO - 2020-03-07 04:57:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 04:57:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 04:57:41 --> Final output sent to browser
DEBUG - 2020-03-07 04:57:41 --> Total execution time: 0.1997
INFO - 2020-03-07 04:57:46 --> Config Class Initialized
INFO - 2020-03-07 04:57:46 --> Hooks Class Initialized
DEBUG - 2020-03-07 04:57:46 --> UTF-8 Support Enabled
INFO - 2020-03-07 04:57:46 --> Utf8 Class Initialized
INFO - 2020-03-07 04:57:46 --> URI Class Initialized
INFO - 2020-03-07 04:57:46 --> Router Class Initialized
INFO - 2020-03-07 04:57:46 --> Output Class Initialized
INFO - 2020-03-07 04:57:46 --> Security Class Initialized
DEBUG - 2020-03-07 04:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 04:57:46 --> Input Class Initialized
INFO - 2020-03-07 04:57:46 --> Language Class Initialized
INFO - 2020-03-07 04:57:46 --> Loader Class Initialized
INFO - 2020-03-07 04:57:46 --> Helper loaded: url_helper
INFO - 2020-03-07 04:57:46 --> Helper loaded: string_helper
INFO - 2020-03-07 04:57:46 --> Database Driver Class Initialized
DEBUG - 2020-03-07 04:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 04:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 04:57:46 --> Controller Class Initialized
INFO - 2020-03-07 04:57:46 --> Model "M_tiket" initialized
INFO - 2020-03-07 04:57:46 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 04:57:46 --> Model "M_pesan" initialized
INFO - 2020-03-07 04:57:46 --> Helper loaded: form_helper
INFO - 2020-03-07 04:57:46 --> Form Validation Class Initialized
INFO - 2020-03-07 04:57:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 04:57:46 --> Final output sent to browser
DEBUG - 2020-03-07 04:57:46 --> Total execution time: 0.2022
INFO - 2020-03-07 04:57:59 --> Config Class Initialized
INFO - 2020-03-07 04:57:59 --> Hooks Class Initialized
DEBUG - 2020-03-07 04:57:59 --> UTF-8 Support Enabled
INFO - 2020-03-07 04:57:59 --> Utf8 Class Initialized
INFO - 2020-03-07 04:57:59 --> URI Class Initialized
DEBUG - 2020-03-07 04:57:59 --> No URI present. Default controller set.
INFO - 2020-03-07 04:57:59 --> Router Class Initialized
INFO - 2020-03-07 04:57:59 --> Output Class Initialized
INFO - 2020-03-07 04:57:59 --> Security Class Initialized
DEBUG - 2020-03-07 04:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 04:57:59 --> Input Class Initialized
INFO - 2020-03-07 04:57:59 --> Language Class Initialized
INFO - 2020-03-07 04:57:59 --> Loader Class Initialized
INFO - 2020-03-07 04:57:59 --> Helper loaded: url_helper
INFO - 2020-03-07 04:57:59 --> Helper loaded: string_helper
INFO - 2020-03-07 04:57:59 --> Database Driver Class Initialized
DEBUG - 2020-03-07 04:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 04:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 04:57:59 --> Controller Class Initialized
INFO - 2020-03-07 04:57:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 04:57:59 --> Pagination Class Initialized
INFO - 2020-03-07 04:57:59 --> Model "M_show" initialized
INFO - 2020-03-07 04:57:59 --> Helper loaded: form_helper
INFO - 2020-03-07 04:57:59 --> Form Validation Class Initialized
INFO - 2020-03-07 04:57:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 04:57:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 04:57:59 --> Final output sent to browser
DEBUG - 2020-03-07 04:57:59 --> Total execution time: 0.1002
INFO - 2020-03-07 04:58:22 --> Config Class Initialized
INFO - 2020-03-07 04:58:22 --> Hooks Class Initialized
DEBUG - 2020-03-07 04:58:22 --> UTF-8 Support Enabled
INFO - 2020-03-07 04:58:22 --> Utf8 Class Initialized
INFO - 2020-03-07 04:58:22 --> URI Class Initialized
INFO - 2020-03-07 04:58:22 --> Router Class Initialized
INFO - 2020-03-07 04:58:22 --> Output Class Initialized
INFO - 2020-03-07 04:58:22 --> Security Class Initialized
DEBUG - 2020-03-07 04:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 04:58:22 --> Input Class Initialized
INFO - 2020-03-07 04:58:22 --> Language Class Initialized
INFO - 2020-03-07 04:58:22 --> Loader Class Initialized
INFO - 2020-03-07 04:58:22 --> Helper loaded: url_helper
INFO - 2020-03-07 04:58:22 --> Helper loaded: string_helper
INFO - 2020-03-07 04:58:22 --> Database Driver Class Initialized
DEBUG - 2020-03-07 04:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 04:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 04:58:22 --> Controller Class Initialized
INFO - 2020-03-07 04:58:22 --> Model "M_tiket" initialized
INFO - 2020-03-07 04:58:22 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 04:58:22 --> Model "M_pesan" initialized
INFO - 2020-03-07 04:58:22 --> Helper loaded: form_helper
INFO - 2020-03-07 04:58:22 --> Form Validation Class Initialized
INFO - 2020-03-07 04:58:22 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 04:58:22 --> Final output sent to browser
DEBUG - 2020-03-07 04:58:22 --> Total execution time: 0.1627
INFO - 2020-03-07 04:58:33 --> Config Class Initialized
INFO - 2020-03-07 04:58:33 --> Hooks Class Initialized
DEBUG - 2020-03-07 04:58:33 --> UTF-8 Support Enabled
INFO - 2020-03-07 04:58:33 --> Utf8 Class Initialized
INFO - 2020-03-07 04:58:33 --> URI Class Initialized
INFO - 2020-03-07 04:58:33 --> Router Class Initialized
INFO - 2020-03-07 04:58:33 --> Output Class Initialized
INFO - 2020-03-07 04:58:33 --> Security Class Initialized
DEBUG - 2020-03-07 04:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 04:58:33 --> Input Class Initialized
INFO - 2020-03-07 04:58:33 --> Language Class Initialized
INFO - 2020-03-07 04:58:33 --> Loader Class Initialized
INFO - 2020-03-07 04:58:33 --> Helper loaded: url_helper
INFO - 2020-03-07 04:58:33 --> Helper loaded: string_helper
INFO - 2020-03-07 04:58:33 --> Database Driver Class Initialized
DEBUG - 2020-03-07 04:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 04:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 04:58:33 --> Controller Class Initialized
INFO - 2020-03-07 04:58:33 --> Model "M_tiket" initialized
INFO - 2020-03-07 04:58:33 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 04:58:33 --> Model "M_pesan" initialized
INFO - 2020-03-07 04:58:33 --> Helper loaded: form_helper
INFO - 2020-03-07 04:58:33 --> Form Validation Class Initialized
INFO - 2020-03-07 04:58:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 04:58:33 --> Final output sent to browser
DEBUG - 2020-03-07 04:58:33 --> Total execution time: 0.0099
INFO - 2020-03-07 04:59:27 --> Config Class Initialized
INFO - 2020-03-07 04:59:27 --> Hooks Class Initialized
DEBUG - 2020-03-07 04:59:27 --> UTF-8 Support Enabled
INFO - 2020-03-07 04:59:27 --> Utf8 Class Initialized
INFO - 2020-03-07 04:59:27 --> URI Class Initialized
INFO - 2020-03-07 04:59:27 --> Router Class Initialized
INFO - 2020-03-07 04:59:27 --> Output Class Initialized
INFO - 2020-03-07 04:59:27 --> Security Class Initialized
DEBUG - 2020-03-07 04:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 04:59:27 --> Input Class Initialized
INFO - 2020-03-07 04:59:27 --> Language Class Initialized
INFO - 2020-03-07 04:59:27 --> Loader Class Initialized
INFO - 2020-03-07 04:59:27 --> Helper loaded: url_helper
INFO - 2020-03-07 04:59:27 --> Helper loaded: string_helper
INFO - 2020-03-07 04:59:27 --> Database Driver Class Initialized
DEBUG - 2020-03-07 04:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 04:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 04:59:27 --> Controller Class Initialized
INFO - 2020-03-07 04:59:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 04:59:27 --> Pagination Class Initialized
INFO - 2020-03-07 04:59:27 --> Model "M_show" initialized
INFO - 2020-03-07 04:59:27 --> Helper loaded: form_helper
INFO - 2020-03-07 04:59:27 --> Form Validation Class Initialized
INFO - 2020-03-07 04:59:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 04:59:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 04:59:27 --> Final output sent to browser
DEBUG - 2020-03-07 04:59:27 --> Total execution time: 0.0085
INFO - 2020-03-07 05:42:06 --> Config Class Initialized
INFO - 2020-03-07 05:42:06 --> Hooks Class Initialized
DEBUG - 2020-03-07 05:42:06 --> UTF-8 Support Enabled
INFO - 2020-03-07 05:42:06 --> Utf8 Class Initialized
INFO - 2020-03-07 05:42:06 --> URI Class Initialized
INFO - 2020-03-07 05:42:06 --> Router Class Initialized
INFO - 2020-03-07 05:42:06 --> Output Class Initialized
INFO - 2020-03-07 05:42:06 --> Security Class Initialized
DEBUG - 2020-03-07 05:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 05:42:06 --> Input Class Initialized
INFO - 2020-03-07 05:42:06 --> Language Class Initialized
INFO - 2020-03-07 05:42:06 --> Loader Class Initialized
INFO - 2020-03-07 05:42:06 --> Helper loaded: url_helper
INFO - 2020-03-07 05:42:06 --> Helper loaded: string_helper
INFO - 2020-03-07 05:42:06 --> Database Driver Class Initialized
DEBUG - 2020-03-07 05:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 05:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 05:42:06 --> Controller Class Initialized
INFO - 2020-03-07 05:42:06 --> Model "M_tiket" initialized
INFO - 2020-03-07 05:42:06 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 05:42:06 --> Model "M_pesan" initialized
INFO - 2020-03-07 05:42:06 --> Helper loaded: form_helper
INFO - 2020-03-07 05:42:06 --> Form Validation Class Initialized
INFO - 2020-03-07 05:42:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-07 05:42:06 --> Final output sent to browser
DEBUG - 2020-03-07 05:42:06 --> Total execution time: 0.2131
INFO - 2020-03-07 05:42:09 --> Config Class Initialized
INFO - 2020-03-07 05:42:09 --> Hooks Class Initialized
DEBUG - 2020-03-07 05:42:09 --> UTF-8 Support Enabled
INFO - 2020-03-07 05:42:09 --> Utf8 Class Initialized
INFO - 2020-03-07 05:42:09 --> URI Class Initialized
INFO - 2020-03-07 05:42:09 --> Router Class Initialized
INFO - 2020-03-07 05:42:09 --> Output Class Initialized
INFO - 2020-03-07 05:42:09 --> Security Class Initialized
DEBUG - 2020-03-07 05:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 05:42:09 --> Input Class Initialized
INFO - 2020-03-07 05:42:09 --> Language Class Initialized
INFO - 2020-03-07 05:42:09 --> Loader Class Initialized
INFO - 2020-03-07 05:42:09 --> Helper loaded: url_helper
INFO - 2020-03-07 05:42:09 --> Helper loaded: string_helper
INFO - 2020-03-07 05:42:09 --> Database Driver Class Initialized
DEBUG - 2020-03-07 05:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 05:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 05:42:09 --> Controller Class Initialized
INFO - 2020-03-07 05:42:09 --> Model "M_tiket" initialized
INFO - 2020-03-07 05:42:09 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 05:42:09 --> Model "M_pesan" initialized
INFO - 2020-03-07 05:42:09 --> Helper loaded: form_helper
INFO - 2020-03-07 05:42:09 --> Form Validation Class Initialized
INFO - 2020-03-07 05:42:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-07 05:42:09 --> Final output sent to browser
DEBUG - 2020-03-07 05:42:09 --> Total execution time: 0.0079
INFO - 2020-03-07 05:43:08 --> Config Class Initialized
INFO - 2020-03-07 05:43:08 --> Hooks Class Initialized
DEBUG - 2020-03-07 05:43:08 --> UTF-8 Support Enabled
INFO - 2020-03-07 05:43:08 --> Utf8 Class Initialized
INFO - 2020-03-07 05:43:08 --> URI Class Initialized
INFO - 2020-03-07 05:43:08 --> Router Class Initialized
INFO - 2020-03-07 05:43:08 --> Output Class Initialized
INFO - 2020-03-07 05:43:08 --> Security Class Initialized
DEBUG - 2020-03-07 05:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 05:43:08 --> Input Class Initialized
INFO - 2020-03-07 05:43:08 --> Language Class Initialized
INFO - 2020-03-07 05:43:08 --> Loader Class Initialized
INFO - 2020-03-07 05:43:08 --> Helper loaded: url_helper
INFO - 2020-03-07 05:43:08 --> Helper loaded: string_helper
INFO - 2020-03-07 05:43:08 --> Database Driver Class Initialized
DEBUG - 2020-03-07 05:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 05:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 05:43:08 --> Controller Class Initialized
INFO - 2020-03-07 05:43:08 --> Model "M_tiket" initialized
INFO - 2020-03-07 05:43:08 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 05:43:08 --> Model "M_pesan" initialized
INFO - 2020-03-07 05:43:08 --> Helper loaded: form_helper
INFO - 2020-03-07 05:43:08 --> Form Validation Class Initialized
INFO - 2020-03-07 12:43:09 --> Upload Class Initialized
INFO - 2020-03-07 05:43:09 --> Config Class Initialized
INFO - 2020-03-07 05:43:09 --> Hooks Class Initialized
DEBUG - 2020-03-07 05:43:09 --> UTF-8 Support Enabled
INFO - 2020-03-07 05:43:09 --> Utf8 Class Initialized
INFO - 2020-03-07 05:43:09 --> URI Class Initialized
INFO - 2020-03-07 05:43:09 --> Router Class Initialized
INFO - 2020-03-07 05:43:09 --> Output Class Initialized
INFO - 2020-03-07 05:43:09 --> Security Class Initialized
DEBUG - 2020-03-07 05:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 05:43:09 --> Input Class Initialized
INFO - 2020-03-07 05:43:09 --> Language Class Initialized
INFO - 2020-03-07 05:43:09 --> Loader Class Initialized
INFO - 2020-03-07 05:43:09 --> Helper loaded: url_helper
INFO - 2020-03-07 05:43:09 --> Helper loaded: string_helper
INFO - 2020-03-07 05:43:09 --> Database Driver Class Initialized
DEBUG - 2020-03-07 05:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 05:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 05:43:09 --> Controller Class Initialized
INFO - 2020-03-07 05:43:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 05:43:09 --> Pagination Class Initialized
INFO - 2020-03-07 05:43:09 --> Model "M_show" initialized
INFO - 2020-03-07 05:43:09 --> Helper loaded: form_helper
INFO - 2020-03-07 05:43:09 --> Form Validation Class Initialized
INFO - 2020-03-07 05:43:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 05:43:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 05:43:09 --> Final output sent to browser
DEBUG - 2020-03-07 05:43:09 --> Total execution time: 0.0068
INFO - 2020-03-07 05:43:30 --> Config Class Initialized
INFO - 2020-03-07 05:43:30 --> Hooks Class Initialized
DEBUG - 2020-03-07 05:43:30 --> UTF-8 Support Enabled
INFO - 2020-03-07 05:43:30 --> Utf8 Class Initialized
INFO - 2020-03-07 05:43:30 --> URI Class Initialized
INFO - 2020-03-07 05:43:30 --> Router Class Initialized
INFO - 2020-03-07 05:43:30 --> Output Class Initialized
INFO - 2020-03-07 05:43:30 --> Security Class Initialized
DEBUG - 2020-03-07 05:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 05:43:30 --> Input Class Initialized
INFO - 2020-03-07 05:43:30 --> Language Class Initialized
INFO - 2020-03-07 05:43:30 --> Loader Class Initialized
INFO - 2020-03-07 05:43:30 --> Helper loaded: url_helper
INFO - 2020-03-07 05:43:30 --> Helper loaded: string_helper
INFO - 2020-03-07 05:43:30 --> Database Driver Class Initialized
DEBUG - 2020-03-07 05:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 05:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 05:43:30 --> Controller Class Initialized
INFO - 2020-03-07 05:43:30 --> Model "M_tiket" initialized
INFO - 2020-03-07 05:43:30 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 05:43:30 --> Model "M_pesan" initialized
INFO - 2020-03-07 05:43:30 --> Helper loaded: form_helper
INFO - 2020-03-07 05:43:30 --> Form Validation Class Initialized
INFO - 2020-03-07 05:43:30 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-07 05:43:30 --> Final output sent to browser
DEBUG - 2020-03-07 05:43:30 --> Total execution time: 0.0082
INFO - 2020-03-07 05:44:23 --> Config Class Initialized
INFO - 2020-03-07 05:44:23 --> Hooks Class Initialized
DEBUG - 2020-03-07 05:44:23 --> UTF-8 Support Enabled
INFO - 2020-03-07 05:44:23 --> Utf8 Class Initialized
INFO - 2020-03-07 05:44:23 --> URI Class Initialized
DEBUG - 2020-03-07 05:44:23 --> No URI present. Default controller set.
INFO - 2020-03-07 05:44:23 --> Router Class Initialized
INFO - 2020-03-07 05:44:23 --> Output Class Initialized
INFO - 2020-03-07 05:44:23 --> Security Class Initialized
DEBUG - 2020-03-07 05:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 05:44:23 --> Input Class Initialized
INFO - 2020-03-07 05:44:23 --> Language Class Initialized
INFO - 2020-03-07 05:44:23 --> Loader Class Initialized
INFO - 2020-03-07 05:44:23 --> Helper loaded: url_helper
INFO - 2020-03-07 05:44:23 --> Helper loaded: string_helper
INFO - 2020-03-07 05:44:23 --> Database Driver Class Initialized
DEBUG - 2020-03-07 05:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 05:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 05:44:23 --> Controller Class Initialized
INFO - 2020-03-07 05:44:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 05:44:23 --> Pagination Class Initialized
INFO - 2020-03-07 05:44:23 --> Model "M_show" initialized
INFO - 2020-03-07 05:44:23 --> Helper loaded: form_helper
INFO - 2020-03-07 05:44:23 --> Form Validation Class Initialized
INFO - 2020-03-07 05:44:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 05:44:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 05:44:23 --> Final output sent to browser
DEBUG - 2020-03-07 05:44:23 --> Total execution time: 0.0060
INFO - 2020-03-07 05:44:29 --> Config Class Initialized
INFO - 2020-03-07 05:44:29 --> Hooks Class Initialized
DEBUG - 2020-03-07 05:44:29 --> UTF-8 Support Enabled
INFO - 2020-03-07 05:44:29 --> Utf8 Class Initialized
INFO - 2020-03-07 05:44:29 --> URI Class Initialized
INFO - 2020-03-07 05:44:29 --> Router Class Initialized
INFO - 2020-03-07 05:44:29 --> Output Class Initialized
INFO - 2020-03-07 05:44:29 --> Security Class Initialized
DEBUG - 2020-03-07 05:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 05:44:29 --> Input Class Initialized
INFO - 2020-03-07 05:44:29 --> Language Class Initialized
INFO - 2020-03-07 05:44:29 --> Loader Class Initialized
INFO - 2020-03-07 05:44:29 --> Helper loaded: url_helper
INFO - 2020-03-07 05:44:29 --> Helper loaded: string_helper
INFO - 2020-03-07 05:44:29 --> Database Driver Class Initialized
DEBUG - 2020-03-07 05:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 05:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 05:44:30 --> Controller Class Initialized
INFO - 2020-03-07 05:44:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 05:44:30 --> Pagination Class Initialized
INFO - 2020-03-07 05:44:30 --> Model "M_show" initialized
INFO - 2020-03-07 05:44:30 --> Helper loaded: form_helper
INFO - 2020-03-07 05:44:30 --> Form Validation Class Initialized
INFO - 2020-03-07 05:44:30 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 05:44:30 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 05:44:30 --> Final output sent to browser
DEBUG - 2020-03-07 05:44:30 --> Total execution time: 0.5708
INFO - 2020-03-07 05:44:35 --> Config Class Initialized
INFO - 2020-03-07 05:44:35 --> Hooks Class Initialized
DEBUG - 2020-03-07 05:44:35 --> UTF-8 Support Enabled
INFO - 2020-03-07 05:44:35 --> Utf8 Class Initialized
INFO - 2020-03-07 05:44:35 --> URI Class Initialized
INFO - 2020-03-07 05:44:35 --> Router Class Initialized
INFO - 2020-03-07 05:44:35 --> Output Class Initialized
INFO - 2020-03-07 05:44:35 --> Security Class Initialized
DEBUG - 2020-03-07 05:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 05:44:35 --> Input Class Initialized
INFO - 2020-03-07 05:44:35 --> Language Class Initialized
INFO - 2020-03-07 05:44:35 --> Loader Class Initialized
INFO - 2020-03-07 05:44:35 --> Helper loaded: url_helper
INFO - 2020-03-07 05:44:35 --> Helper loaded: string_helper
INFO - 2020-03-07 05:44:35 --> Database Driver Class Initialized
DEBUG - 2020-03-07 05:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 05:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 05:44:35 --> Controller Class Initialized
INFO - 2020-03-07 05:44:35 --> Model "M_tiket" initialized
INFO - 2020-03-07 05:44:35 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 05:44:35 --> Model "M_pesan" initialized
INFO - 2020-03-07 05:44:35 --> Helper loaded: form_helper
INFO - 2020-03-07 05:44:35 --> Form Validation Class Initialized
INFO - 2020-03-07 05:44:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 05:44:35 --> Final output sent to browser
DEBUG - 2020-03-07 05:44:35 --> Total execution time: 0.0135
INFO - 2020-03-07 05:44:45 --> Config Class Initialized
INFO - 2020-03-07 05:44:45 --> Hooks Class Initialized
DEBUG - 2020-03-07 05:44:45 --> UTF-8 Support Enabled
INFO - 2020-03-07 05:44:45 --> Utf8 Class Initialized
INFO - 2020-03-07 05:44:45 --> URI Class Initialized
INFO - 2020-03-07 05:44:45 --> Router Class Initialized
INFO - 2020-03-07 05:44:45 --> Output Class Initialized
INFO - 2020-03-07 05:44:45 --> Security Class Initialized
DEBUG - 2020-03-07 05:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 05:44:45 --> Input Class Initialized
INFO - 2020-03-07 05:44:45 --> Language Class Initialized
INFO - 2020-03-07 05:44:45 --> Loader Class Initialized
INFO - 2020-03-07 05:44:45 --> Helper loaded: url_helper
INFO - 2020-03-07 05:44:45 --> Helper loaded: string_helper
INFO - 2020-03-07 05:44:45 --> Database Driver Class Initialized
DEBUG - 2020-03-07 05:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 05:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 05:44:45 --> Controller Class Initialized
INFO - 2020-03-07 05:44:45 --> Model "M_tiket" initialized
INFO - 2020-03-07 05:44:45 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 05:44:45 --> Model "M_pesan" initialized
INFO - 2020-03-07 05:44:45 --> Helper loaded: form_helper
INFO - 2020-03-07 05:44:45 --> Form Validation Class Initialized
INFO - 2020-03-07 05:44:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 05:44:45 --> Final output sent to browser
DEBUG - 2020-03-07 05:44:45 --> Total execution time: 0.0101
INFO - 2020-03-07 05:48:27 --> Config Class Initialized
INFO - 2020-03-07 05:48:27 --> Hooks Class Initialized
DEBUG - 2020-03-07 05:48:27 --> UTF-8 Support Enabled
INFO - 2020-03-07 05:48:27 --> Utf8 Class Initialized
INFO - 2020-03-07 05:48:27 --> URI Class Initialized
INFO - 2020-03-07 05:48:27 --> Router Class Initialized
INFO - 2020-03-07 05:48:27 --> Output Class Initialized
INFO - 2020-03-07 05:48:27 --> Security Class Initialized
DEBUG - 2020-03-07 05:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 05:48:27 --> Input Class Initialized
INFO - 2020-03-07 05:48:27 --> Language Class Initialized
INFO - 2020-03-07 05:48:27 --> Loader Class Initialized
INFO - 2020-03-07 05:48:27 --> Helper loaded: url_helper
INFO - 2020-03-07 05:48:27 --> Helper loaded: string_helper
INFO - 2020-03-07 05:48:27 --> Database Driver Class Initialized
DEBUG - 2020-03-07 05:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 05:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 05:48:27 --> Controller Class Initialized
INFO - 2020-03-07 05:48:27 --> Model "M_tiket" initialized
INFO - 2020-03-07 05:48:27 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 05:48:27 --> Model "M_pesan" initialized
INFO - 2020-03-07 05:48:27 --> Helper loaded: form_helper
INFO - 2020-03-07 05:48:27 --> Form Validation Class Initialized
INFO - 2020-03-07 05:48:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-07 05:48:27 --> Final output sent to browser
DEBUG - 2020-03-07 05:48:27 --> Total execution time: 0.0344
INFO - 2020-03-07 05:48:31 --> Config Class Initialized
INFO - 2020-03-07 05:48:31 --> Hooks Class Initialized
DEBUG - 2020-03-07 05:48:31 --> UTF-8 Support Enabled
INFO - 2020-03-07 05:48:31 --> Utf8 Class Initialized
INFO - 2020-03-07 05:48:31 --> URI Class Initialized
DEBUG - 2020-03-07 05:48:31 --> No URI present. Default controller set.
INFO - 2020-03-07 05:48:31 --> Router Class Initialized
INFO - 2020-03-07 05:48:31 --> Output Class Initialized
INFO - 2020-03-07 05:48:31 --> Security Class Initialized
DEBUG - 2020-03-07 05:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 05:48:31 --> Input Class Initialized
INFO - 2020-03-07 05:48:31 --> Language Class Initialized
INFO - 2020-03-07 05:48:31 --> Loader Class Initialized
INFO - 2020-03-07 05:48:31 --> Helper loaded: url_helper
INFO - 2020-03-07 05:48:31 --> Helper loaded: string_helper
INFO - 2020-03-07 05:48:31 --> Database Driver Class Initialized
DEBUG - 2020-03-07 05:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 05:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 05:48:31 --> Controller Class Initialized
INFO - 2020-03-07 05:48:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 05:48:31 --> Pagination Class Initialized
INFO - 2020-03-07 05:48:31 --> Model "M_show" initialized
INFO - 2020-03-07 05:48:31 --> Helper loaded: form_helper
INFO - 2020-03-07 05:48:31 --> Form Validation Class Initialized
INFO - 2020-03-07 05:48:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 05:48:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 05:48:31 --> Final output sent to browser
DEBUG - 2020-03-07 05:48:31 --> Total execution time: 0.0086
INFO - 2020-03-07 05:48:34 --> Config Class Initialized
INFO - 2020-03-07 05:48:34 --> Hooks Class Initialized
DEBUG - 2020-03-07 05:48:34 --> UTF-8 Support Enabled
INFO - 2020-03-07 05:48:34 --> Utf8 Class Initialized
INFO - 2020-03-07 05:48:34 --> URI Class Initialized
INFO - 2020-03-07 05:48:34 --> Router Class Initialized
INFO - 2020-03-07 05:48:34 --> Output Class Initialized
INFO - 2020-03-07 05:48:34 --> Security Class Initialized
DEBUG - 2020-03-07 05:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 05:48:34 --> Input Class Initialized
INFO - 2020-03-07 05:48:34 --> Language Class Initialized
INFO - 2020-03-07 05:48:34 --> Loader Class Initialized
INFO - 2020-03-07 05:48:34 --> Helper loaded: url_helper
INFO - 2020-03-07 05:48:34 --> Helper loaded: string_helper
INFO - 2020-03-07 05:48:34 --> Database Driver Class Initialized
DEBUG - 2020-03-07 05:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 05:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 05:48:34 --> Controller Class Initialized
INFO - 2020-03-07 05:48:34 --> Model "M_tiket" initialized
INFO - 2020-03-07 05:48:34 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 05:48:34 --> Model "M_pesan" initialized
INFO - 2020-03-07 05:48:34 --> Helper loaded: form_helper
INFO - 2020-03-07 05:48:34 --> Form Validation Class Initialized
INFO - 2020-03-07 05:48:34 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-07 05:48:34 --> Final output sent to browser
DEBUG - 2020-03-07 05:48:34 --> Total execution time: 0.0128
INFO - 2020-03-07 05:49:32 --> Config Class Initialized
INFO - 2020-03-07 05:49:32 --> Hooks Class Initialized
DEBUG - 2020-03-07 05:49:32 --> UTF-8 Support Enabled
INFO - 2020-03-07 05:49:32 --> Utf8 Class Initialized
INFO - 2020-03-07 05:49:32 --> URI Class Initialized
INFO - 2020-03-07 05:49:32 --> Router Class Initialized
INFO - 2020-03-07 05:49:32 --> Output Class Initialized
INFO - 2020-03-07 05:49:32 --> Security Class Initialized
DEBUG - 2020-03-07 05:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 05:49:32 --> Input Class Initialized
INFO - 2020-03-07 05:49:32 --> Language Class Initialized
INFO - 2020-03-07 05:49:32 --> Loader Class Initialized
INFO - 2020-03-07 05:49:32 --> Helper loaded: url_helper
INFO - 2020-03-07 05:49:32 --> Helper loaded: string_helper
INFO - 2020-03-07 05:49:32 --> Database Driver Class Initialized
DEBUG - 2020-03-07 05:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 05:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 05:49:32 --> Controller Class Initialized
INFO - 2020-03-07 05:49:32 --> Model "M_tiket" initialized
INFO - 2020-03-07 05:49:32 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 05:49:32 --> Model "M_pesan" initialized
INFO - 2020-03-07 05:49:32 --> Helper loaded: form_helper
INFO - 2020-03-07 05:49:32 --> Form Validation Class Initialized
INFO - 2020-03-07 12:49:32 --> Upload Class Initialized
INFO - 2020-03-07 05:49:33 --> Config Class Initialized
INFO - 2020-03-07 05:49:33 --> Hooks Class Initialized
DEBUG - 2020-03-07 05:49:33 --> UTF-8 Support Enabled
INFO - 2020-03-07 05:49:33 --> Utf8 Class Initialized
INFO - 2020-03-07 05:49:33 --> URI Class Initialized
INFO - 2020-03-07 05:49:33 --> Router Class Initialized
INFO - 2020-03-07 05:49:33 --> Output Class Initialized
INFO - 2020-03-07 05:49:33 --> Security Class Initialized
DEBUG - 2020-03-07 05:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 05:49:33 --> Input Class Initialized
INFO - 2020-03-07 05:49:33 --> Language Class Initialized
INFO - 2020-03-07 05:49:33 --> Loader Class Initialized
INFO - 2020-03-07 05:49:33 --> Helper loaded: url_helper
INFO - 2020-03-07 05:49:33 --> Helper loaded: string_helper
INFO - 2020-03-07 05:49:33 --> Database Driver Class Initialized
DEBUG - 2020-03-07 05:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 05:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 05:49:33 --> Controller Class Initialized
INFO - 2020-03-07 05:49:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 05:49:33 --> Pagination Class Initialized
INFO - 2020-03-07 05:49:33 --> Model "M_show" initialized
INFO - 2020-03-07 05:49:33 --> Helper loaded: form_helper
INFO - 2020-03-07 05:49:33 --> Form Validation Class Initialized
INFO - 2020-03-07 05:49:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 05:49:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 05:49:33 --> Final output sent to browser
DEBUG - 2020-03-07 05:49:33 --> Total execution time: 0.0059
INFO - 2020-03-07 05:56:57 --> Config Class Initialized
INFO - 2020-03-07 05:56:57 --> Hooks Class Initialized
DEBUG - 2020-03-07 05:56:57 --> UTF-8 Support Enabled
INFO - 2020-03-07 05:56:57 --> Utf8 Class Initialized
INFO - 2020-03-07 05:56:57 --> URI Class Initialized
INFO - 2020-03-07 05:56:57 --> Router Class Initialized
INFO - 2020-03-07 05:56:57 --> Output Class Initialized
INFO - 2020-03-07 05:56:57 --> Security Class Initialized
DEBUG - 2020-03-07 05:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 05:56:57 --> Input Class Initialized
INFO - 2020-03-07 05:56:57 --> Language Class Initialized
INFO - 2020-03-07 05:56:57 --> Loader Class Initialized
INFO - 2020-03-07 05:56:57 --> Helper loaded: url_helper
INFO - 2020-03-07 05:56:57 --> Helper loaded: string_helper
INFO - 2020-03-07 05:56:57 --> Database Driver Class Initialized
DEBUG - 2020-03-07 05:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 05:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 05:56:57 --> Controller Class Initialized
INFO - 2020-03-07 05:56:57 --> Model "M_tiket" initialized
INFO - 2020-03-07 05:56:57 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 05:56:57 --> Model "M_pesan" initialized
INFO - 2020-03-07 05:56:57 --> Helper loaded: form_helper
INFO - 2020-03-07 05:56:57 --> Form Validation Class Initialized
INFO - 2020-03-07 05:56:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-07 05:56:57 --> Final output sent to browser
DEBUG - 2020-03-07 05:56:57 --> Total execution time: 0.0405
INFO - 2020-03-07 06:14:42 --> Config Class Initialized
INFO - 2020-03-07 06:14:42 --> Hooks Class Initialized
DEBUG - 2020-03-07 06:14:42 --> UTF-8 Support Enabled
INFO - 2020-03-07 06:14:42 --> Utf8 Class Initialized
INFO - 2020-03-07 06:14:42 --> URI Class Initialized
DEBUG - 2020-03-07 06:14:42 --> No URI present. Default controller set.
INFO - 2020-03-07 06:14:42 --> Router Class Initialized
INFO - 2020-03-07 06:14:42 --> Output Class Initialized
INFO - 2020-03-07 06:14:42 --> Security Class Initialized
DEBUG - 2020-03-07 06:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 06:14:42 --> Input Class Initialized
INFO - 2020-03-07 06:14:42 --> Language Class Initialized
INFO - 2020-03-07 06:14:42 --> Loader Class Initialized
INFO - 2020-03-07 06:14:42 --> Helper loaded: url_helper
INFO - 2020-03-07 06:14:42 --> Helper loaded: string_helper
INFO - 2020-03-07 06:14:42 --> Database Driver Class Initialized
DEBUG - 2020-03-07 06:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 06:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 06:14:42 --> Controller Class Initialized
INFO - 2020-03-07 06:14:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 06:14:42 --> Pagination Class Initialized
INFO - 2020-03-07 06:14:42 --> Model "M_show" initialized
INFO - 2020-03-07 06:14:42 --> Helper loaded: form_helper
INFO - 2020-03-07 06:14:42 --> Form Validation Class Initialized
INFO - 2020-03-07 06:14:42 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 06:14:42 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 06:14:42 --> Final output sent to browser
DEBUG - 2020-03-07 06:14:42 --> Total execution time: 0.0847
INFO - 2020-03-07 06:26:03 --> Config Class Initialized
INFO - 2020-03-07 06:26:03 --> Hooks Class Initialized
DEBUG - 2020-03-07 06:26:03 --> UTF-8 Support Enabled
INFO - 2020-03-07 06:26:03 --> Utf8 Class Initialized
INFO - 2020-03-07 06:26:03 --> URI Class Initialized
DEBUG - 2020-03-07 06:26:03 --> No URI present. Default controller set.
INFO - 2020-03-07 06:26:03 --> Router Class Initialized
INFO - 2020-03-07 06:26:03 --> Output Class Initialized
INFO - 2020-03-07 06:26:03 --> Security Class Initialized
DEBUG - 2020-03-07 06:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 06:26:03 --> Input Class Initialized
INFO - 2020-03-07 06:26:03 --> Language Class Initialized
INFO - 2020-03-07 06:26:03 --> Loader Class Initialized
INFO - 2020-03-07 06:26:03 --> Helper loaded: url_helper
INFO - 2020-03-07 06:26:03 --> Helper loaded: string_helper
INFO - 2020-03-07 06:26:03 --> Database Driver Class Initialized
DEBUG - 2020-03-07 06:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 06:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 06:26:03 --> Controller Class Initialized
INFO - 2020-03-07 06:26:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 06:26:03 --> Pagination Class Initialized
INFO - 2020-03-07 06:26:03 --> Model "M_show" initialized
INFO - 2020-03-07 06:26:03 --> Helper loaded: form_helper
INFO - 2020-03-07 06:26:03 --> Form Validation Class Initialized
INFO - 2020-03-07 06:26:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 06:26:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 06:26:03 --> Final output sent to browser
DEBUG - 2020-03-07 06:26:03 --> Total execution time: 0.0432
INFO - 2020-03-07 06:26:23 --> Config Class Initialized
INFO - 2020-03-07 06:26:23 --> Hooks Class Initialized
DEBUG - 2020-03-07 06:26:23 --> UTF-8 Support Enabled
INFO - 2020-03-07 06:26:23 --> Utf8 Class Initialized
INFO - 2020-03-07 06:26:23 --> URI Class Initialized
DEBUG - 2020-03-07 06:26:23 --> No URI present. Default controller set.
INFO - 2020-03-07 06:26:23 --> Router Class Initialized
INFO - 2020-03-07 06:26:23 --> Output Class Initialized
INFO - 2020-03-07 06:26:23 --> Security Class Initialized
DEBUG - 2020-03-07 06:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 06:26:23 --> Input Class Initialized
INFO - 2020-03-07 06:26:23 --> Language Class Initialized
INFO - 2020-03-07 06:26:23 --> Loader Class Initialized
INFO - 2020-03-07 06:26:23 --> Helper loaded: url_helper
INFO - 2020-03-07 06:26:23 --> Helper loaded: string_helper
INFO - 2020-03-07 06:26:23 --> Database Driver Class Initialized
DEBUG - 2020-03-07 06:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 06:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 06:26:23 --> Controller Class Initialized
INFO - 2020-03-07 06:26:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 06:26:23 --> Pagination Class Initialized
INFO - 2020-03-07 06:26:23 --> Model "M_show" initialized
INFO - 2020-03-07 06:26:23 --> Helper loaded: form_helper
INFO - 2020-03-07 06:26:23 --> Form Validation Class Initialized
INFO - 2020-03-07 06:26:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 06:26:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 06:26:23 --> Final output sent to browser
DEBUG - 2020-03-07 06:26:23 --> Total execution time: 0.0081
INFO - 2020-03-07 06:26:25 --> Config Class Initialized
INFO - 2020-03-07 06:26:25 --> Hooks Class Initialized
DEBUG - 2020-03-07 06:26:25 --> UTF-8 Support Enabled
INFO - 2020-03-07 06:26:25 --> Utf8 Class Initialized
INFO - 2020-03-07 06:26:25 --> URI Class Initialized
INFO - 2020-03-07 06:26:25 --> Router Class Initialized
INFO - 2020-03-07 06:26:25 --> Output Class Initialized
INFO - 2020-03-07 06:26:25 --> Security Class Initialized
DEBUG - 2020-03-07 06:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 06:26:25 --> Input Class Initialized
INFO - 2020-03-07 06:26:25 --> Language Class Initialized
INFO - 2020-03-07 06:26:25 --> Loader Class Initialized
INFO - 2020-03-07 06:26:25 --> Helper loaded: url_helper
INFO - 2020-03-07 06:26:25 --> Helper loaded: string_helper
INFO - 2020-03-07 06:26:25 --> Database Driver Class Initialized
DEBUG - 2020-03-07 06:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 06:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 06:26:25 --> Controller Class Initialized
INFO - 2020-03-07 06:26:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 06:26:25 --> Pagination Class Initialized
INFO - 2020-03-07 06:26:25 --> Model "M_show" initialized
INFO - 2020-03-07 06:26:25 --> Helper loaded: form_helper
INFO - 2020-03-07 06:26:25 --> Form Validation Class Initialized
INFO - 2020-03-07 06:26:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 06:26:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 06:26:25 --> Final output sent to browser
DEBUG - 2020-03-07 06:26:25 --> Total execution time: 0.0095
INFO - 2020-03-07 06:26:25 --> Config Class Initialized
INFO - 2020-03-07 06:26:25 --> Hooks Class Initialized
DEBUG - 2020-03-07 06:26:25 --> UTF-8 Support Enabled
INFO - 2020-03-07 06:26:25 --> Utf8 Class Initialized
INFO - 2020-03-07 06:26:25 --> URI Class Initialized
INFO - 2020-03-07 06:26:25 --> Router Class Initialized
INFO - 2020-03-07 06:26:25 --> Output Class Initialized
INFO - 2020-03-07 06:26:25 --> Security Class Initialized
DEBUG - 2020-03-07 06:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 06:26:25 --> Input Class Initialized
INFO - 2020-03-07 06:26:25 --> Language Class Initialized
ERROR - 2020-03-07 06:26:25 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-07 06:26:31 --> Config Class Initialized
INFO - 2020-03-07 06:26:31 --> Hooks Class Initialized
DEBUG - 2020-03-07 06:26:31 --> UTF-8 Support Enabled
INFO - 2020-03-07 06:26:31 --> Utf8 Class Initialized
INFO - 2020-03-07 06:26:31 --> URI Class Initialized
INFO - 2020-03-07 06:26:31 --> Router Class Initialized
INFO - 2020-03-07 06:26:31 --> Output Class Initialized
INFO - 2020-03-07 06:26:31 --> Security Class Initialized
DEBUG - 2020-03-07 06:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 06:26:31 --> Input Class Initialized
INFO - 2020-03-07 06:26:31 --> Language Class Initialized
INFO - 2020-03-07 06:26:31 --> Loader Class Initialized
INFO - 2020-03-07 06:26:31 --> Helper loaded: url_helper
INFO - 2020-03-07 06:26:31 --> Helper loaded: string_helper
INFO - 2020-03-07 06:26:31 --> Database Driver Class Initialized
DEBUG - 2020-03-07 06:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 06:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 06:26:31 --> Controller Class Initialized
INFO - 2020-03-07 06:26:31 --> Model "M_tiket" initialized
INFO - 2020-03-07 06:26:31 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 06:26:31 --> Model "M_pesan" initialized
INFO - 2020-03-07 06:26:31 --> Helper loaded: form_helper
INFO - 2020-03-07 06:26:31 --> Form Validation Class Initialized
INFO - 2020-03-07 06:26:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 06:26:31 --> Final output sent to browser
DEBUG - 2020-03-07 06:26:31 --> Total execution time: 0.0095
INFO - 2020-03-07 06:26:54 --> Config Class Initialized
INFO - 2020-03-07 06:26:54 --> Hooks Class Initialized
DEBUG - 2020-03-07 06:26:54 --> UTF-8 Support Enabled
INFO - 2020-03-07 06:26:54 --> Utf8 Class Initialized
INFO - 2020-03-07 06:26:54 --> URI Class Initialized
INFO - 2020-03-07 06:26:54 --> Router Class Initialized
INFO - 2020-03-07 06:26:54 --> Output Class Initialized
INFO - 2020-03-07 06:26:54 --> Security Class Initialized
DEBUG - 2020-03-07 06:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 06:26:54 --> Input Class Initialized
INFO - 2020-03-07 06:26:54 --> Language Class Initialized
INFO - 2020-03-07 06:26:54 --> Loader Class Initialized
INFO - 2020-03-07 06:26:54 --> Helper loaded: url_helper
INFO - 2020-03-07 06:26:54 --> Helper loaded: string_helper
INFO - 2020-03-07 06:26:54 --> Database Driver Class Initialized
DEBUG - 2020-03-07 06:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 06:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 06:26:54 --> Controller Class Initialized
INFO - 2020-03-07 06:26:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 06:26:54 --> Pagination Class Initialized
INFO - 2020-03-07 06:26:54 --> Model "M_show" initialized
INFO - 2020-03-07 06:26:54 --> Helper loaded: form_helper
INFO - 2020-03-07 06:26:54 --> Form Validation Class Initialized
INFO - 2020-03-07 06:26:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 06:26:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 06:26:54 --> Final output sent to browser
DEBUG - 2020-03-07 06:26:54 --> Total execution time: 0.0062
INFO - 2020-03-07 06:26:55 --> Config Class Initialized
INFO - 2020-03-07 06:26:55 --> Hooks Class Initialized
DEBUG - 2020-03-07 06:26:55 --> UTF-8 Support Enabled
INFO - 2020-03-07 06:26:55 --> Utf8 Class Initialized
INFO - 2020-03-07 06:26:55 --> URI Class Initialized
DEBUG - 2020-03-07 06:26:55 --> No URI present. Default controller set.
INFO - 2020-03-07 06:26:55 --> Router Class Initialized
INFO - 2020-03-07 06:26:55 --> Output Class Initialized
INFO - 2020-03-07 06:26:55 --> Security Class Initialized
DEBUG - 2020-03-07 06:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 06:26:55 --> Input Class Initialized
INFO - 2020-03-07 06:26:55 --> Language Class Initialized
INFO - 2020-03-07 06:26:55 --> Loader Class Initialized
INFO - 2020-03-07 06:26:55 --> Helper loaded: url_helper
INFO - 2020-03-07 06:26:55 --> Helper loaded: string_helper
INFO - 2020-03-07 06:26:55 --> Database Driver Class Initialized
DEBUG - 2020-03-07 06:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 06:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 06:26:55 --> Controller Class Initialized
INFO - 2020-03-07 06:26:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 06:26:55 --> Pagination Class Initialized
INFO - 2020-03-07 06:26:55 --> Model "M_show" initialized
INFO - 2020-03-07 06:26:55 --> Helper loaded: form_helper
INFO - 2020-03-07 06:26:55 --> Form Validation Class Initialized
INFO - 2020-03-07 06:26:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 06:26:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 06:26:55 --> Final output sent to browser
DEBUG - 2020-03-07 06:26:55 --> Total execution time: 0.0061
INFO - 2020-03-07 06:54:12 --> Config Class Initialized
INFO - 2020-03-07 06:54:12 --> Hooks Class Initialized
DEBUG - 2020-03-07 06:54:12 --> UTF-8 Support Enabled
INFO - 2020-03-07 06:54:12 --> Utf8 Class Initialized
INFO - 2020-03-07 06:54:12 --> URI Class Initialized
DEBUG - 2020-03-07 06:54:12 --> No URI present. Default controller set.
INFO - 2020-03-07 06:54:12 --> Router Class Initialized
INFO - 2020-03-07 06:54:12 --> Output Class Initialized
INFO - 2020-03-07 06:54:12 --> Security Class Initialized
DEBUG - 2020-03-07 06:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 06:54:12 --> Input Class Initialized
INFO - 2020-03-07 06:54:12 --> Language Class Initialized
INFO - 2020-03-07 06:54:12 --> Loader Class Initialized
INFO - 2020-03-07 06:54:12 --> Helper loaded: url_helper
INFO - 2020-03-07 06:54:12 --> Helper loaded: string_helper
INFO - 2020-03-07 06:54:12 --> Database Driver Class Initialized
DEBUG - 2020-03-07 06:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 06:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 06:54:12 --> Controller Class Initialized
INFO - 2020-03-07 06:54:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 06:54:12 --> Pagination Class Initialized
INFO - 2020-03-07 06:54:12 --> Model "M_show" initialized
INFO - 2020-03-07 06:54:12 --> Helper loaded: form_helper
INFO - 2020-03-07 06:54:12 --> Form Validation Class Initialized
INFO - 2020-03-07 06:54:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 06:54:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 06:54:12 --> Final output sent to browser
DEBUG - 2020-03-07 06:54:12 --> Total execution time: 0.0350
INFO - 2020-03-07 06:54:17 --> Config Class Initialized
INFO - 2020-03-07 06:54:17 --> Hooks Class Initialized
DEBUG - 2020-03-07 06:54:17 --> UTF-8 Support Enabled
INFO - 2020-03-07 06:54:17 --> Utf8 Class Initialized
INFO - 2020-03-07 06:54:17 --> URI Class Initialized
INFO - 2020-03-07 06:54:17 --> Router Class Initialized
INFO - 2020-03-07 06:54:17 --> Output Class Initialized
INFO - 2020-03-07 06:54:17 --> Security Class Initialized
DEBUG - 2020-03-07 06:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 06:54:17 --> Input Class Initialized
INFO - 2020-03-07 06:54:17 --> Language Class Initialized
INFO - 2020-03-07 06:54:17 --> Loader Class Initialized
INFO - 2020-03-07 06:54:17 --> Helper loaded: url_helper
INFO - 2020-03-07 06:54:17 --> Helper loaded: string_helper
INFO - 2020-03-07 06:54:17 --> Database Driver Class Initialized
DEBUG - 2020-03-07 06:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 06:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 06:54:17 --> Controller Class Initialized
INFO - 2020-03-07 06:54:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 06:54:17 --> Pagination Class Initialized
INFO - 2020-03-07 06:54:17 --> Model "M_show" initialized
INFO - 2020-03-07 06:54:17 --> Helper loaded: form_helper
INFO - 2020-03-07 06:54:17 --> Form Validation Class Initialized
INFO - 2020-03-07 06:54:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 06:54:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 06:54:17 --> Final output sent to browser
DEBUG - 2020-03-07 06:54:17 --> Total execution time: 0.0075
INFO - 2020-03-07 06:54:27 --> Config Class Initialized
INFO - 2020-03-07 06:54:27 --> Hooks Class Initialized
DEBUG - 2020-03-07 06:54:27 --> UTF-8 Support Enabled
INFO - 2020-03-07 06:54:27 --> Utf8 Class Initialized
INFO - 2020-03-07 06:54:27 --> URI Class Initialized
INFO - 2020-03-07 06:54:27 --> Router Class Initialized
INFO - 2020-03-07 06:54:27 --> Output Class Initialized
INFO - 2020-03-07 06:54:27 --> Security Class Initialized
DEBUG - 2020-03-07 06:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 06:54:27 --> Input Class Initialized
INFO - 2020-03-07 06:54:27 --> Language Class Initialized
INFO - 2020-03-07 06:54:27 --> Loader Class Initialized
INFO - 2020-03-07 06:54:27 --> Helper loaded: url_helper
INFO - 2020-03-07 06:54:27 --> Helper loaded: string_helper
INFO - 2020-03-07 06:54:27 --> Database Driver Class Initialized
DEBUG - 2020-03-07 06:54:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 06:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 06:54:27 --> Controller Class Initialized
INFO - 2020-03-07 06:54:27 --> Model "M_tiket" initialized
INFO - 2020-03-07 06:54:27 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 06:54:27 --> Model "M_pesan" initialized
INFO - 2020-03-07 06:54:27 --> Helper loaded: form_helper
INFO - 2020-03-07 06:54:27 --> Form Validation Class Initialized
INFO - 2020-03-07 06:54:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 06:54:27 --> Final output sent to browser
DEBUG - 2020-03-07 06:54:27 --> Total execution time: 0.0107
INFO - 2020-03-07 06:54:30 --> Config Class Initialized
INFO - 2020-03-07 06:54:30 --> Hooks Class Initialized
DEBUG - 2020-03-07 06:54:30 --> UTF-8 Support Enabled
INFO - 2020-03-07 06:54:30 --> Utf8 Class Initialized
INFO - 2020-03-07 06:54:30 --> URI Class Initialized
INFO - 2020-03-07 06:54:30 --> Router Class Initialized
INFO - 2020-03-07 06:54:30 --> Output Class Initialized
INFO - 2020-03-07 06:54:30 --> Security Class Initialized
DEBUG - 2020-03-07 06:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 06:54:30 --> Input Class Initialized
INFO - 2020-03-07 06:54:30 --> Language Class Initialized
INFO - 2020-03-07 06:54:30 --> Loader Class Initialized
INFO - 2020-03-07 06:54:30 --> Helper loaded: url_helper
INFO - 2020-03-07 06:54:30 --> Helper loaded: string_helper
INFO - 2020-03-07 06:54:30 --> Database Driver Class Initialized
DEBUG - 2020-03-07 06:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 06:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 06:54:30 --> Controller Class Initialized
INFO - 2020-03-07 06:54:30 --> Model "M_tiket" initialized
INFO - 2020-03-07 06:54:30 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 06:54:30 --> Model "M_pesan" initialized
INFO - 2020-03-07 06:54:30 --> Helper loaded: form_helper
INFO - 2020-03-07 06:54:30 --> Form Validation Class Initialized
INFO - 2020-03-07 06:54:30 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 06:54:30 --> Final output sent to browser
DEBUG - 2020-03-07 06:54:30 --> Total execution time: 0.0084
INFO - 2020-03-07 07:00:25 --> Config Class Initialized
INFO - 2020-03-07 07:00:25 --> Hooks Class Initialized
DEBUG - 2020-03-07 07:00:25 --> UTF-8 Support Enabled
INFO - 2020-03-07 07:00:25 --> Utf8 Class Initialized
INFO - 2020-03-07 07:00:25 --> URI Class Initialized
INFO - 2020-03-07 07:00:25 --> Router Class Initialized
INFO - 2020-03-07 07:00:25 --> Output Class Initialized
INFO - 2020-03-07 07:00:25 --> Security Class Initialized
DEBUG - 2020-03-07 07:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 07:00:25 --> Input Class Initialized
INFO - 2020-03-07 07:00:25 --> Language Class Initialized
INFO - 2020-03-07 07:00:25 --> Loader Class Initialized
INFO - 2020-03-07 07:00:25 --> Helper loaded: url_helper
INFO - 2020-03-07 07:00:25 --> Helper loaded: string_helper
INFO - 2020-03-07 07:00:25 --> Database Driver Class Initialized
DEBUG - 2020-03-07 07:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 07:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 07:00:25 --> Controller Class Initialized
INFO - 2020-03-07 07:00:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 07:00:25 --> Pagination Class Initialized
INFO - 2020-03-07 07:00:25 --> Model "M_show" initialized
INFO - 2020-03-07 07:00:25 --> Helper loaded: form_helper
INFO - 2020-03-07 07:00:25 --> Form Validation Class Initialized
INFO - 2020-03-07 07:00:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 07:00:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 07:00:25 --> Final output sent to browser
DEBUG - 2020-03-07 07:00:25 --> Total execution time: 0.0359
INFO - 2020-03-07 07:07:30 --> Config Class Initialized
INFO - 2020-03-07 07:07:30 --> Hooks Class Initialized
DEBUG - 2020-03-07 07:07:31 --> UTF-8 Support Enabled
INFO - 2020-03-07 07:07:31 --> Utf8 Class Initialized
INFO - 2020-03-07 07:07:31 --> URI Class Initialized
INFO - 2020-03-07 07:07:31 --> Router Class Initialized
INFO - 2020-03-07 07:07:31 --> Output Class Initialized
INFO - 2020-03-07 07:07:31 --> Security Class Initialized
DEBUG - 2020-03-07 07:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 07:07:31 --> Input Class Initialized
INFO - 2020-03-07 07:07:31 --> Language Class Initialized
INFO - 2020-03-07 07:07:31 --> Loader Class Initialized
INFO - 2020-03-07 07:07:31 --> Helper loaded: url_helper
INFO - 2020-03-07 07:07:31 --> Helper loaded: string_helper
INFO - 2020-03-07 07:07:31 --> Database Driver Class Initialized
DEBUG - 2020-03-07 07:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 07:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 07:07:31 --> Controller Class Initialized
INFO - 2020-03-07 07:07:31 --> Model "M_tiket" initialized
INFO - 2020-03-07 07:07:31 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 07:07:31 --> Model "M_pesan" initialized
INFO - 2020-03-07 07:07:31 --> Helper loaded: form_helper
INFO - 2020-03-07 07:07:31 --> Form Validation Class Initialized
INFO - 2020-03-07 07:07:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 07:07:31 --> Final output sent to browser
DEBUG - 2020-03-07 07:07:31 --> Total execution time: 0.0782
INFO - 2020-03-07 07:08:48 --> Config Class Initialized
INFO - 2020-03-07 07:08:48 --> Hooks Class Initialized
DEBUG - 2020-03-07 07:08:48 --> UTF-8 Support Enabled
INFO - 2020-03-07 07:08:48 --> Utf8 Class Initialized
INFO - 2020-03-07 07:08:48 --> URI Class Initialized
INFO - 2020-03-07 07:08:48 --> Router Class Initialized
INFO - 2020-03-07 07:08:48 --> Output Class Initialized
INFO - 2020-03-07 07:08:48 --> Security Class Initialized
DEBUG - 2020-03-07 07:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 07:08:48 --> Input Class Initialized
INFO - 2020-03-07 07:08:48 --> Language Class Initialized
INFO - 2020-03-07 07:08:48 --> Loader Class Initialized
INFO - 2020-03-07 07:08:48 --> Helper loaded: url_helper
INFO - 2020-03-07 07:08:48 --> Helper loaded: string_helper
INFO - 2020-03-07 07:08:48 --> Database Driver Class Initialized
DEBUG - 2020-03-07 07:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 07:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 07:08:48 --> Controller Class Initialized
INFO - 2020-03-07 07:08:48 --> Model "M_tiket" initialized
INFO - 2020-03-07 07:08:48 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 07:08:48 --> Model "M_pesan" initialized
INFO - 2020-03-07 07:08:48 --> Helper loaded: form_helper
INFO - 2020-03-07 07:08:48 --> Form Validation Class Initialized
INFO - 2020-03-07 07:08:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 07:08:48 --> Final output sent to browser
DEBUG - 2020-03-07 07:08:48 --> Total execution time: 0.0651
INFO - 2020-03-07 07:10:40 --> Config Class Initialized
INFO - 2020-03-07 07:10:40 --> Hooks Class Initialized
DEBUG - 2020-03-07 07:10:40 --> UTF-8 Support Enabled
INFO - 2020-03-07 07:10:40 --> Utf8 Class Initialized
INFO - 2020-03-07 07:10:40 --> URI Class Initialized
INFO - 2020-03-07 07:10:40 --> Router Class Initialized
INFO - 2020-03-07 07:10:40 --> Output Class Initialized
INFO - 2020-03-07 07:10:40 --> Security Class Initialized
DEBUG - 2020-03-07 07:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 07:10:40 --> Input Class Initialized
INFO - 2020-03-07 07:10:40 --> Language Class Initialized
INFO - 2020-03-07 07:10:40 --> Loader Class Initialized
INFO - 2020-03-07 07:10:40 --> Helper loaded: url_helper
INFO - 2020-03-07 07:10:40 --> Helper loaded: string_helper
INFO - 2020-03-07 07:10:40 --> Database Driver Class Initialized
DEBUG - 2020-03-07 07:10:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 07:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 07:10:40 --> Controller Class Initialized
INFO - 2020-03-07 07:10:40 --> Model "M_tiket" initialized
INFO - 2020-03-07 07:10:40 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 07:10:40 --> Model "M_pesan" initialized
INFO - 2020-03-07 07:10:40 --> Helper loaded: form_helper
INFO - 2020-03-07 07:10:40 --> Form Validation Class Initialized
INFO - 2020-03-07 07:10:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 07:10:40 --> Final output sent to browser
DEBUG - 2020-03-07 07:10:40 --> Total execution time: 0.0347
INFO - 2020-03-07 07:10:46 --> Config Class Initialized
INFO - 2020-03-07 07:10:46 --> Hooks Class Initialized
DEBUG - 2020-03-07 07:10:46 --> UTF-8 Support Enabled
INFO - 2020-03-07 07:10:46 --> Utf8 Class Initialized
INFO - 2020-03-07 07:10:46 --> URI Class Initialized
INFO - 2020-03-07 07:10:46 --> Router Class Initialized
INFO - 2020-03-07 07:10:46 --> Output Class Initialized
INFO - 2020-03-07 07:10:46 --> Security Class Initialized
DEBUG - 2020-03-07 07:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 07:10:46 --> Input Class Initialized
INFO - 2020-03-07 07:10:46 --> Language Class Initialized
INFO - 2020-03-07 07:10:46 --> Loader Class Initialized
INFO - 2020-03-07 07:10:46 --> Helper loaded: url_helper
INFO - 2020-03-07 07:10:46 --> Helper loaded: string_helper
INFO - 2020-03-07 07:10:46 --> Database Driver Class Initialized
DEBUG - 2020-03-07 07:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 07:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 07:10:46 --> Controller Class Initialized
INFO - 2020-03-07 07:10:46 --> Model "M_tiket" initialized
INFO - 2020-03-07 07:10:46 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 07:10:46 --> Model "M_pesan" initialized
INFO - 2020-03-07 07:10:46 --> Helper loaded: form_helper
INFO - 2020-03-07 07:10:46 --> Form Validation Class Initialized
INFO - 2020-03-07 07:10:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 07:10:46 --> Final output sent to browser
DEBUG - 2020-03-07 07:10:46 --> Total execution time: 0.0067
INFO - 2020-03-07 07:10:48 --> Config Class Initialized
INFO - 2020-03-07 07:10:48 --> Hooks Class Initialized
DEBUG - 2020-03-07 07:10:48 --> UTF-8 Support Enabled
INFO - 2020-03-07 07:10:48 --> Utf8 Class Initialized
INFO - 2020-03-07 07:10:48 --> URI Class Initialized
INFO - 2020-03-07 07:10:48 --> Router Class Initialized
INFO - 2020-03-07 07:10:48 --> Output Class Initialized
INFO - 2020-03-07 07:10:48 --> Security Class Initialized
DEBUG - 2020-03-07 07:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 07:10:48 --> Input Class Initialized
INFO - 2020-03-07 07:10:48 --> Language Class Initialized
INFO - 2020-03-07 07:10:48 --> Loader Class Initialized
INFO - 2020-03-07 07:10:48 --> Helper loaded: url_helper
INFO - 2020-03-07 07:10:48 --> Helper loaded: string_helper
INFO - 2020-03-07 07:10:48 --> Database Driver Class Initialized
DEBUG - 2020-03-07 07:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 07:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 07:10:48 --> Controller Class Initialized
INFO - 2020-03-07 07:10:48 --> Model "M_tiket" initialized
INFO - 2020-03-07 07:10:48 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 07:10:48 --> Model "M_pesan" initialized
INFO - 2020-03-07 07:10:48 --> Helper loaded: form_helper
INFO - 2020-03-07 07:10:48 --> Form Validation Class Initialized
INFO - 2020-03-07 07:10:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 07:10:48 --> Final output sent to browser
DEBUG - 2020-03-07 07:10:48 --> Total execution time: 0.0228
INFO - 2020-03-07 07:12:40 --> Config Class Initialized
INFO - 2020-03-07 07:12:40 --> Hooks Class Initialized
DEBUG - 2020-03-07 07:12:40 --> UTF-8 Support Enabled
INFO - 2020-03-07 07:12:40 --> Utf8 Class Initialized
INFO - 2020-03-07 07:12:40 --> URI Class Initialized
INFO - 2020-03-07 07:12:40 --> Router Class Initialized
INFO - 2020-03-07 07:12:40 --> Output Class Initialized
INFO - 2020-03-07 07:12:40 --> Security Class Initialized
DEBUG - 2020-03-07 07:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 07:12:40 --> Input Class Initialized
INFO - 2020-03-07 07:12:40 --> Language Class Initialized
INFO - 2020-03-07 07:12:40 --> Loader Class Initialized
INFO - 2020-03-07 07:12:40 --> Helper loaded: url_helper
INFO - 2020-03-07 07:12:40 --> Helper loaded: string_helper
INFO - 2020-03-07 07:12:40 --> Database Driver Class Initialized
DEBUG - 2020-03-07 07:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 07:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 07:12:40 --> Controller Class Initialized
INFO - 2020-03-07 07:12:40 --> Model "M_tiket" initialized
INFO - 2020-03-07 07:12:40 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 07:12:40 --> Model "M_pesan" initialized
INFO - 2020-03-07 07:12:40 --> Helper loaded: form_helper
INFO - 2020-03-07 07:12:40 --> Form Validation Class Initialized
INFO - 2020-03-07 07:12:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 07:12:40 --> Final output sent to browser
DEBUG - 2020-03-07 07:12:40 --> Total execution time: 0.0458
INFO - 2020-03-07 07:13:05 --> Config Class Initialized
INFO - 2020-03-07 07:13:05 --> Hooks Class Initialized
DEBUG - 2020-03-07 07:13:05 --> UTF-8 Support Enabled
INFO - 2020-03-07 07:13:05 --> Utf8 Class Initialized
INFO - 2020-03-07 07:13:05 --> URI Class Initialized
INFO - 2020-03-07 07:13:05 --> Router Class Initialized
INFO - 2020-03-07 07:13:05 --> Output Class Initialized
INFO - 2020-03-07 07:13:05 --> Security Class Initialized
DEBUG - 2020-03-07 07:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 07:13:05 --> Input Class Initialized
INFO - 2020-03-07 07:13:05 --> Language Class Initialized
INFO - 2020-03-07 07:13:05 --> Loader Class Initialized
INFO - 2020-03-07 07:13:05 --> Helper loaded: url_helper
INFO - 2020-03-07 07:13:05 --> Helper loaded: string_helper
INFO - 2020-03-07 07:13:05 --> Database Driver Class Initialized
DEBUG - 2020-03-07 07:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 07:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 07:13:05 --> Controller Class Initialized
INFO - 2020-03-07 07:13:05 --> Model "M_tiket" initialized
INFO - 2020-03-07 07:13:05 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 07:13:05 --> Model "M_pesan" initialized
INFO - 2020-03-07 07:13:05 --> Helper loaded: form_helper
INFO - 2020-03-07 07:13:05 --> Form Validation Class Initialized
INFO - 2020-03-07 07:13:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 07:13:05 --> Final output sent to browser
DEBUG - 2020-03-07 07:13:05 --> Total execution time: 0.0118
INFO - 2020-03-07 07:13:33 --> Config Class Initialized
INFO - 2020-03-07 07:13:33 --> Hooks Class Initialized
DEBUG - 2020-03-07 07:13:33 --> UTF-8 Support Enabled
INFO - 2020-03-07 07:13:33 --> Utf8 Class Initialized
INFO - 2020-03-07 07:13:33 --> URI Class Initialized
INFO - 2020-03-07 07:13:33 --> Router Class Initialized
INFO - 2020-03-07 07:13:33 --> Output Class Initialized
INFO - 2020-03-07 07:13:33 --> Security Class Initialized
DEBUG - 2020-03-07 07:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 07:13:33 --> Input Class Initialized
INFO - 2020-03-07 07:13:33 --> Language Class Initialized
INFO - 2020-03-07 07:13:33 --> Loader Class Initialized
INFO - 2020-03-07 07:13:33 --> Helper loaded: url_helper
INFO - 2020-03-07 07:13:33 --> Helper loaded: string_helper
INFO - 2020-03-07 07:13:33 --> Database Driver Class Initialized
DEBUG - 2020-03-07 07:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 07:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 07:13:33 --> Controller Class Initialized
INFO - 2020-03-07 07:13:33 --> Model "M_tiket" initialized
INFO - 2020-03-07 07:13:33 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 07:13:33 --> Model "M_pesan" initialized
INFO - 2020-03-07 07:13:33 --> Helper loaded: form_helper
INFO - 2020-03-07 07:13:33 --> Form Validation Class Initialized
INFO - 2020-03-07 07:13:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 07:13:33 --> Final output sent to browser
DEBUG - 2020-03-07 07:13:33 --> Total execution time: 0.0082
INFO - 2020-03-07 07:13:55 --> Config Class Initialized
INFO - 2020-03-07 07:13:55 --> Hooks Class Initialized
DEBUG - 2020-03-07 07:13:55 --> UTF-8 Support Enabled
INFO - 2020-03-07 07:13:55 --> Utf8 Class Initialized
INFO - 2020-03-07 07:13:55 --> URI Class Initialized
INFO - 2020-03-07 07:13:55 --> Router Class Initialized
INFO - 2020-03-07 07:13:55 --> Output Class Initialized
INFO - 2020-03-07 07:13:55 --> Security Class Initialized
DEBUG - 2020-03-07 07:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 07:13:55 --> Input Class Initialized
INFO - 2020-03-07 07:13:55 --> Language Class Initialized
INFO - 2020-03-07 07:13:55 --> Loader Class Initialized
INFO - 2020-03-07 07:13:55 --> Helper loaded: url_helper
INFO - 2020-03-07 07:13:55 --> Helper loaded: string_helper
INFO - 2020-03-07 07:13:55 --> Database Driver Class Initialized
DEBUG - 2020-03-07 07:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 07:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 07:13:55 --> Controller Class Initialized
INFO - 2020-03-07 07:13:55 --> Model "M_tiket" initialized
INFO - 2020-03-07 07:13:55 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 07:13:55 --> Model "M_pesan" initialized
INFO - 2020-03-07 07:13:55 --> Helper loaded: form_helper
INFO - 2020-03-07 07:13:55 --> Form Validation Class Initialized
INFO - 2020-03-07 07:13:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 07:13:55 --> Final output sent to browser
DEBUG - 2020-03-07 07:13:55 --> Total execution time: 0.0087
INFO - 2020-03-07 07:14:01 --> Config Class Initialized
INFO - 2020-03-07 07:14:01 --> Hooks Class Initialized
DEBUG - 2020-03-07 07:14:01 --> UTF-8 Support Enabled
INFO - 2020-03-07 07:14:01 --> Utf8 Class Initialized
INFO - 2020-03-07 07:14:01 --> URI Class Initialized
INFO - 2020-03-07 07:14:01 --> Router Class Initialized
INFO - 2020-03-07 07:14:01 --> Output Class Initialized
INFO - 2020-03-07 07:14:01 --> Security Class Initialized
DEBUG - 2020-03-07 07:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 07:14:01 --> Input Class Initialized
INFO - 2020-03-07 07:14:01 --> Language Class Initialized
INFO - 2020-03-07 07:14:01 --> Loader Class Initialized
INFO - 2020-03-07 07:14:01 --> Helper loaded: url_helper
INFO - 2020-03-07 07:14:01 --> Helper loaded: string_helper
INFO - 2020-03-07 07:14:01 --> Database Driver Class Initialized
DEBUG - 2020-03-07 07:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 07:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 07:14:01 --> Controller Class Initialized
INFO - 2020-03-07 07:14:01 --> Model "M_tiket" initialized
INFO - 2020-03-07 07:14:01 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 07:14:01 --> Model "M_pesan" initialized
INFO - 2020-03-07 07:14:01 --> Helper loaded: form_helper
INFO - 2020-03-07 07:14:01 --> Form Validation Class Initialized
INFO - 2020-03-07 07:14:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 07:14:01 --> Final output sent to browser
DEBUG - 2020-03-07 07:14:01 --> Total execution time: 0.0072
INFO - 2020-03-07 07:14:10 --> Config Class Initialized
INFO - 2020-03-07 07:14:10 --> Hooks Class Initialized
DEBUG - 2020-03-07 07:14:10 --> UTF-8 Support Enabled
INFO - 2020-03-07 07:14:10 --> Utf8 Class Initialized
INFO - 2020-03-07 07:14:10 --> URI Class Initialized
INFO - 2020-03-07 07:14:10 --> Router Class Initialized
INFO - 2020-03-07 07:14:10 --> Output Class Initialized
INFO - 2020-03-07 07:14:10 --> Security Class Initialized
DEBUG - 2020-03-07 07:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 07:14:10 --> Input Class Initialized
INFO - 2020-03-07 07:14:10 --> Language Class Initialized
INFO - 2020-03-07 07:14:10 --> Loader Class Initialized
INFO - 2020-03-07 07:14:10 --> Helper loaded: url_helper
INFO - 2020-03-07 07:14:10 --> Helper loaded: string_helper
INFO - 2020-03-07 07:14:10 --> Database Driver Class Initialized
DEBUG - 2020-03-07 07:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 07:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 07:14:10 --> Controller Class Initialized
INFO - 2020-03-07 07:14:10 --> Model "M_tiket" initialized
INFO - 2020-03-07 07:14:10 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 07:14:10 --> Model "M_pesan" initialized
INFO - 2020-03-07 07:14:10 --> Helper loaded: form_helper
INFO - 2020-03-07 07:14:10 --> Form Validation Class Initialized
INFO - 2020-03-07 07:14:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 07:14:10 --> Final output sent to browser
DEBUG - 2020-03-07 07:14:10 --> Total execution time: 0.0107
INFO - 2020-03-07 07:14:21 --> Config Class Initialized
INFO - 2020-03-07 07:14:21 --> Hooks Class Initialized
DEBUG - 2020-03-07 07:14:21 --> UTF-8 Support Enabled
INFO - 2020-03-07 07:14:21 --> Utf8 Class Initialized
INFO - 2020-03-07 07:14:21 --> URI Class Initialized
INFO - 2020-03-07 07:14:21 --> Router Class Initialized
INFO - 2020-03-07 07:14:21 --> Output Class Initialized
INFO - 2020-03-07 07:14:21 --> Security Class Initialized
DEBUG - 2020-03-07 07:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 07:14:21 --> Input Class Initialized
INFO - 2020-03-07 07:14:21 --> Language Class Initialized
INFO - 2020-03-07 07:14:21 --> Loader Class Initialized
INFO - 2020-03-07 07:14:21 --> Helper loaded: url_helper
INFO - 2020-03-07 07:14:21 --> Helper loaded: string_helper
INFO - 2020-03-07 07:14:21 --> Database Driver Class Initialized
DEBUG - 2020-03-07 07:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 07:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 07:14:21 --> Controller Class Initialized
INFO - 2020-03-07 07:14:21 --> Model "M_tiket" initialized
INFO - 2020-03-07 07:14:21 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 07:14:21 --> Model "M_pesan" initialized
INFO - 2020-03-07 07:14:21 --> Helper loaded: form_helper
INFO - 2020-03-07 07:14:21 --> Form Validation Class Initialized
INFO - 2020-03-07 07:14:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 07:14:21 --> Final output sent to browser
DEBUG - 2020-03-07 07:14:21 --> Total execution time: 0.0127
INFO - 2020-03-07 07:14:24 --> Config Class Initialized
INFO - 2020-03-07 07:14:24 --> Hooks Class Initialized
DEBUG - 2020-03-07 07:14:24 --> UTF-8 Support Enabled
INFO - 2020-03-07 07:14:24 --> Utf8 Class Initialized
INFO - 2020-03-07 07:14:24 --> URI Class Initialized
INFO - 2020-03-07 07:14:24 --> Router Class Initialized
INFO - 2020-03-07 07:14:24 --> Output Class Initialized
INFO - 2020-03-07 07:14:24 --> Security Class Initialized
DEBUG - 2020-03-07 07:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 07:14:24 --> Input Class Initialized
INFO - 2020-03-07 07:14:24 --> Language Class Initialized
INFO - 2020-03-07 07:14:24 --> Loader Class Initialized
INFO - 2020-03-07 07:14:24 --> Helper loaded: url_helper
INFO - 2020-03-07 07:14:24 --> Helper loaded: string_helper
INFO - 2020-03-07 07:14:24 --> Database Driver Class Initialized
DEBUG - 2020-03-07 07:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 07:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 07:14:24 --> Controller Class Initialized
INFO - 2020-03-07 07:14:24 --> Model "M_tiket" initialized
INFO - 2020-03-07 07:14:24 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 07:14:24 --> Model "M_pesan" initialized
INFO - 2020-03-07 07:14:24 --> Helper loaded: form_helper
INFO - 2020-03-07 07:14:24 --> Form Validation Class Initialized
INFO - 2020-03-07 07:14:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 07:14:24 --> Final output sent to browser
DEBUG - 2020-03-07 07:14:24 --> Total execution time: 0.0109
INFO - 2020-03-07 07:14:26 --> Config Class Initialized
INFO - 2020-03-07 07:14:26 --> Hooks Class Initialized
DEBUG - 2020-03-07 07:14:26 --> UTF-8 Support Enabled
INFO - 2020-03-07 07:14:26 --> Utf8 Class Initialized
INFO - 2020-03-07 07:14:26 --> URI Class Initialized
INFO - 2020-03-07 07:14:26 --> Router Class Initialized
INFO - 2020-03-07 07:14:26 --> Output Class Initialized
INFO - 2020-03-07 07:14:26 --> Security Class Initialized
DEBUG - 2020-03-07 07:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 07:14:26 --> Input Class Initialized
INFO - 2020-03-07 07:14:26 --> Language Class Initialized
INFO - 2020-03-07 07:14:26 --> Loader Class Initialized
INFO - 2020-03-07 07:14:26 --> Helper loaded: url_helper
INFO - 2020-03-07 07:14:26 --> Helper loaded: string_helper
INFO - 2020-03-07 07:14:26 --> Database Driver Class Initialized
DEBUG - 2020-03-07 07:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 07:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 07:14:26 --> Controller Class Initialized
INFO - 2020-03-07 07:14:26 --> Model "M_tiket" initialized
INFO - 2020-03-07 07:14:26 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 07:14:26 --> Model "M_pesan" initialized
INFO - 2020-03-07 07:14:26 --> Helper loaded: form_helper
INFO - 2020-03-07 07:14:26 --> Form Validation Class Initialized
INFO - 2020-03-07 07:14:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 07:14:26 --> Final output sent to browser
DEBUG - 2020-03-07 07:14:26 --> Total execution time: 0.0069
INFO - 2020-03-07 07:14:28 --> Config Class Initialized
INFO - 2020-03-07 07:14:28 --> Hooks Class Initialized
DEBUG - 2020-03-07 07:14:28 --> UTF-8 Support Enabled
INFO - 2020-03-07 07:14:28 --> Utf8 Class Initialized
INFO - 2020-03-07 07:14:28 --> URI Class Initialized
INFO - 2020-03-07 07:14:28 --> Router Class Initialized
INFO - 2020-03-07 07:14:28 --> Output Class Initialized
INFO - 2020-03-07 07:14:28 --> Security Class Initialized
DEBUG - 2020-03-07 07:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 07:14:28 --> Input Class Initialized
INFO - 2020-03-07 07:14:28 --> Language Class Initialized
INFO - 2020-03-07 07:14:28 --> Loader Class Initialized
INFO - 2020-03-07 07:14:28 --> Helper loaded: url_helper
INFO - 2020-03-07 07:14:28 --> Helper loaded: string_helper
INFO - 2020-03-07 07:14:28 --> Database Driver Class Initialized
DEBUG - 2020-03-07 07:14:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 07:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 07:14:28 --> Controller Class Initialized
INFO - 2020-03-07 07:14:28 --> Model "M_tiket" initialized
INFO - 2020-03-07 07:14:28 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 07:14:28 --> Model "M_pesan" initialized
INFO - 2020-03-07 07:14:28 --> Helper loaded: form_helper
INFO - 2020-03-07 07:14:28 --> Form Validation Class Initialized
INFO - 2020-03-07 07:14:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 07:14:28 --> Final output sent to browser
DEBUG - 2020-03-07 07:14:28 --> Total execution time: 0.0069
INFO - 2020-03-07 07:14:31 --> Config Class Initialized
INFO - 2020-03-07 07:14:31 --> Hooks Class Initialized
DEBUG - 2020-03-07 07:14:31 --> UTF-8 Support Enabled
INFO - 2020-03-07 07:14:31 --> Utf8 Class Initialized
INFO - 2020-03-07 07:14:31 --> URI Class Initialized
INFO - 2020-03-07 07:14:31 --> Router Class Initialized
INFO - 2020-03-07 07:14:31 --> Output Class Initialized
INFO - 2020-03-07 07:14:31 --> Security Class Initialized
DEBUG - 2020-03-07 07:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 07:14:31 --> Input Class Initialized
INFO - 2020-03-07 07:14:31 --> Language Class Initialized
INFO - 2020-03-07 07:14:31 --> Loader Class Initialized
INFO - 2020-03-07 07:14:31 --> Helper loaded: url_helper
INFO - 2020-03-07 07:14:31 --> Helper loaded: string_helper
INFO - 2020-03-07 07:14:31 --> Database Driver Class Initialized
DEBUG - 2020-03-07 07:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 07:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 07:14:31 --> Controller Class Initialized
INFO - 2020-03-07 07:14:31 --> Model "M_tiket" initialized
INFO - 2020-03-07 07:14:31 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 07:14:31 --> Model "M_pesan" initialized
INFO - 2020-03-07 07:14:31 --> Helper loaded: form_helper
INFO - 2020-03-07 07:14:31 --> Form Validation Class Initialized
INFO - 2020-03-07 07:14:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 07:14:31 --> Final output sent to browser
DEBUG - 2020-03-07 07:14:31 --> Total execution time: 0.0069
INFO - 2020-03-07 07:14:36 --> Config Class Initialized
INFO - 2020-03-07 07:14:36 --> Hooks Class Initialized
DEBUG - 2020-03-07 07:14:36 --> UTF-8 Support Enabled
INFO - 2020-03-07 07:14:36 --> Utf8 Class Initialized
INFO - 2020-03-07 07:14:36 --> URI Class Initialized
INFO - 2020-03-07 07:14:36 --> Router Class Initialized
INFO - 2020-03-07 07:14:36 --> Output Class Initialized
INFO - 2020-03-07 07:14:36 --> Security Class Initialized
DEBUG - 2020-03-07 07:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 07:14:36 --> Input Class Initialized
INFO - 2020-03-07 07:14:36 --> Language Class Initialized
INFO - 2020-03-07 07:14:36 --> Loader Class Initialized
INFO - 2020-03-07 07:14:36 --> Helper loaded: url_helper
INFO - 2020-03-07 07:14:36 --> Helper loaded: string_helper
INFO - 2020-03-07 07:14:36 --> Database Driver Class Initialized
DEBUG - 2020-03-07 07:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 07:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 07:14:36 --> Controller Class Initialized
INFO - 2020-03-07 07:14:36 --> Model "M_tiket" initialized
INFO - 2020-03-07 07:14:36 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 07:14:36 --> Model "M_pesan" initialized
INFO - 2020-03-07 07:14:36 --> Helper loaded: form_helper
INFO - 2020-03-07 07:14:36 --> Form Validation Class Initialized
INFO - 2020-03-07 07:14:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 07:14:36 --> Final output sent to browser
DEBUG - 2020-03-07 07:14:36 --> Total execution time: 0.0068
INFO - 2020-03-07 07:14:40 --> Config Class Initialized
INFO - 2020-03-07 07:14:40 --> Hooks Class Initialized
DEBUG - 2020-03-07 07:14:40 --> UTF-8 Support Enabled
INFO - 2020-03-07 07:14:40 --> Utf8 Class Initialized
INFO - 2020-03-07 07:14:40 --> URI Class Initialized
INFO - 2020-03-07 07:14:40 --> Router Class Initialized
INFO - 2020-03-07 07:14:40 --> Output Class Initialized
INFO - 2020-03-07 07:14:40 --> Security Class Initialized
DEBUG - 2020-03-07 07:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 07:14:40 --> Input Class Initialized
INFO - 2020-03-07 07:14:40 --> Language Class Initialized
INFO - 2020-03-07 07:14:40 --> Loader Class Initialized
INFO - 2020-03-07 07:14:40 --> Helper loaded: url_helper
INFO - 2020-03-07 07:14:40 --> Helper loaded: string_helper
INFO - 2020-03-07 07:14:40 --> Database Driver Class Initialized
DEBUG - 2020-03-07 07:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 07:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 07:14:40 --> Controller Class Initialized
INFO - 2020-03-07 07:14:40 --> Model "M_tiket" initialized
INFO - 2020-03-07 07:14:40 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 07:14:40 --> Model "M_pesan" initialized
INFO - 2020-03-07 07:14:40 --> Helper loaded: form_helper
INFO - 2020-03-07 07:14:40 --> Form Validation Class Initialized
INFO - 2020-03-07 07:14:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 07:14:40 --> Final output sent to browser
DEBUG - 2020-03-07 07:14:40 --> Total execution time: 0.0084
INFO - 2020-03-07 07:15:16 --> Config Class Initialized
INFO - 2020-03-07 07:15:16 --> Hooks Class Initialized
DEBUG - 2020-03-07 07:15:16 --> UTF-8 Support Enabled
INFO - 2020-03-07 07:15:16 --> Utf8 Class Initialized
INFO - 2020-03-07 07:15:16 --> URI Class Initialized
INFO - 2020-03-07 07:15:16 --> Router Class Initialized
INFO - 2020-03-07 07:15:16 --> Output Class Initialized
INFO - 2020-03-07 07:15:16 --> Security Class Initialized
DEBUG - 2020-03-07 07:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 07:15:16 --> Input Class Initialized
INFO - 2020-03-07 07:15:16 --> Language Class Initialized
INFO - 2020-03-07 07:15:16 --> Loader Class Initialized
INFO - 2020-03-07 07:15:16 --> Helper loaded: url_helper
INFO - 2020-03-07 07:15:16 --> Helper loaded: string_helper
INFO - 2020-03-07 07:15:16 --> Database Driver Class Initialized
DEBUG - 2020-03-07 07:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 07:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 07:15:16 --> Controller Class Initialized
INFO - 2020-03-07 07:15:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 07:15:16 --> Pagination Class Initialized
INFO - 2020-03-07 07:15:16 --> Model "M_show" initialized
INFO - 2020-03-07 07:15:16 --> Helper loaded: form_helper
INFO - 2020-03-07 07:15:16 --> Form Validation Class Initialized
INFO - 2020-03-07 07:15:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 07:15:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 07:15:16 --> Final output sent to browser
DEBUG - 2020-03-07 07:15:16 --> Total execution time: 0.0473
INFO - 2020-03-07 07:25:04 --> Config Class Initialized
INFO - 2020-03-07 07:25:04 --> Hooks Class Initialized
DEBUG - 2020-03-07 07:25:04 --> UTF-8 Support Enabled
INFO - 2020-03-07 07:25:04 --> Utf8 Class Initialized
INFO - 2020-03-07 07:25:04 --> URI Class Initialized
DEBUG - 2020-03-07 07:25:04 --> No URI present. Default controller set.
INFO - 2020-03-07 07:25:04 --> Router Class Initialized
INFO - 2020-03-07 07:25:04 --> Output Class Initialized
INFO - 2020-03-07 07:25:04 --> Security Class Initialized
DEBUG - 2020-03-07 07:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 07:25:04 --> Input Class Initialized
INFO - 2020-03-07 07:25:04 --> Language Class Initialized
INFO - 2020-03-07 07:25:04 --> Loader Class Initialized
INFO - 2020-03-07 07:25:04 --> Helper loaded: url_helper
INFO - 2020-03-07 07:25:04 --> Helper loaded: string_helper
INFO - 2020-03-07 07:25:04 --> Database Driver Class Initialized
DEBUG - 2020-03-07 07:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 07:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 07:25:04 --> Controller Class Initialized
INFO - 2020-03-07 07:25:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 07:25:04 --> Pagination Class Initialized
INFO - 2020-03-07 07:25:04 --> Model "M_show" initialized
INFO - 2020-03-07 07:25:04 --> Helper loaded: form_helper
INFO - 2020-03-07 07:25:04 --> Form Validation Class Initialized
INFO - 2020-03-07 07:25:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 07:25:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 07:25:04 --> Final output sent to browser
DEBUG - 2020-03-07 07:25:04 --> Total execution time: 0.0321
INFO - 2020-03-07 07:26:36 --> Config Class Initialized
INFO - 2020-03-07 07:26:36 --> Hooks Class Initialized
DEBUG - 2020-03-07 07:26:36 --> UTF-8 Support Enabled
INFO - 2020-03-07 07:26:36 --> Utf8 Class Initialized
INFO - 2020-03-07 07:26:36 --> URI Class Initialized
DEBUG - 2020-03-07 07:26:36 --> No URI present. Default controller set.
INFO - 2020-03-07 07:26:36 --> Router Class Initialized
INFO - 2020-03-07 07:26:36 --> Output Class Initialized
INFO - 2020-03-07 07:26:36 --> Security Class Initialized
DEBUG - 2020-03-07 07:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 07:26:36 --> Input Class Initialized
INFO - 2020-03-07 07:26:36 --> Language Class Initialized
INFO - 2020-03-07 07:26:36 --> Loader Class Initialized
INFO - 2020-03-07 07:26:36 --> Helper loaded: url_helper
INFO - 2020-03-07 07:26:36 --> Helper loaded: string_helper
INFO - 2020-03-07 07:26:36 --> Database Driver Class Initialized
DEBUG - 2020-03-07 07:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 07:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 07:26:36 --> Controller Class Initialized
INFO - 2020-03-07 07:26:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 07:26:36 --> Pagination Class Initialized
INFO - 2020-03-07 07:26:36 --> Model "M_show" initialized
INFO - 2020-03-07 07:26:36 --> Helper loaded: form_helper
INFO - 2020-03-07 07:26:36 --> Form Validation Class Initialized
INFO - 2020-03-07 07:26:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 07:26:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 07:26:36 --> Final output sent to browser
DEBUG - 2020-03-07 07:26:36 --> Total execution time: 0.0552
INFO - 2020-03-07 07:35:16 --> Config Class Initialized
INFO - 2020-03-07 07:35:16 --> Hooks Class Initialized
DEBUG - 2020-03-07 07:35:16 --> UTF-8 Support Enabled
INFO - 2020-03-07 07:35:16 --> Utf8 Class Initialized
INFO - 2020-03-07 07:35:16 --> URI Class Initialized
INFO - 2020-03-07 07:35:16 --> Router Class Initialized
INFO - 2020-03-07 07:35:16 --> Output Class Initialized
INFO - 2020-03-07 07:35:16 --> Security Class Initialized
DEBUG - 2020-03-07 07:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 07:35:16 --> Input Class Initialized
INFO - 2020-03-07 07:35:16 --> Language Class Initialized
INFO - 2020-03-07 07:35:16 --> Loader Class Initialized
INFO - 2020-03-07 07:35:16 --> Helper loaded: url_helper
INFO - 2020-03-07 07:35:16 --> Helper loaded: string_helper
INFO - 2020-03-07 07:35:16 --> Database Driver Class Initialized
DEBUG - 2020-03-07 07:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 07:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 07:35:16 --> Controller Class Initialized
INFO - 2020-03-07 07:35:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 07:35:16 --> Pagination Class Initialized
INFO - 2020-03-07 07:35:16 --> Model "M_show" initialized
INFO - 2020-03-07 07:35:16 --> Helper loaded: form_helper
INFO - 2020-03-07 07:35:16 --> Form Validation Class Initialized
INFO - 2020-03-07 07:35:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 07:35:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/gal.php
INFO - 2020-03-07 07:35:16 --> Final output sent to browser
DEBUG - 2020-03-07 07:35:16 --> Total execution time: 0.2245
INFO - 2020-03-07 07:45:26 --> Config Class Initialized
INFO - 2020-03-07 07:45:26 --> Hooks Class Initialized
DEBUG - 2020-03-07 07:45:26 --> UTF-8 Support Enabled
INFO - 2020-03-07 07:45:26 --> Utf8 Class Initialized
INFO - 2020-03-07 07:45:26 --> URI Class Initialized
INFO - 2020-03-07 07:45:26 --> Router Class Initialized
INFO - 2020-03-07 07:45:26 --> Output Class Initialized
INFO - 2020-03-07 07:45:26 --> Security Class Initialized
DEBUG - 2020-03-07 07:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 07:45:26 --> Input Class Initialized
INFO - 2020-03-07 07:45:26 --> Language Class Initialized
INFO - 2020-03-07 07:45:26 --> Loader Class Initialized
INFO - 2020-03-07 07:45:26 --> Helper loaded: url_helper
INFO - 2020-03-07 07:45:26 --> Helper loaded: string_helper
INFO - 2020-03-07 07:45:26 --> Database Driver Class Initialized
DEBUG - 2020-03-07 07:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 07:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 07:45:26 --> Controller Class Initialized
INFO - 2020-03-07 07:45:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 07:45:26 --> Pagination Class Initialized
INFO - 2020-03-07 07:45:26 --> Model "M_show" initialized
INFO - 2020-03-07 07:45:26 --> Helper loaded: form_helper
INFO - 2020-03-07 07:45:26 --> Form Validation Class Initialized
INFO - 2020-03-07 07:45:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 07:45:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-07 07:45:26 --> Final output sent to browser
DEBUG - 2020-03-07 07:45:26 --> Total execution time: 0.0393
INFO - 2020-03-07 08:24:46 --> Config Class Initialized
INFO - 2020-03-07 08:24:46 --> Hooks Class Initialized
DEBUG - 2020-03-07 08:24:46 --> UTF-8 Support Enabled
INFO - 2020-03-07 08:24:46 --> Utf8 Class Initialized
INFO - 2020-03-07 08:24:46 --> URI Class Initialized
DEBUG - 2020-03-07 08:24:46 --> No URI present. Default controller set.
INFO - 2020-03-07 08:24:46 --> Router Class Initialized
INFO - 2020-03-07 08:24:46 --> Output Class Initialized
INFO - 2020-03-07 08:24:46 --> Security Class Initialized
DEBUG - 2020-03-07 08:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 08:24:46 --> Input Class Initialized
INFO - 2020-03-07 08:24:46 --> Language Class Initialized
INFO - 2020-03-07 08:24:46 --> Loader Class Initialized
INFO - 2020-03-07 08:24:46 --> Helper loaded: url_helper
INFO - 2020-03-07 08:24:46 --> Helper loaded: string_helper
INFO - 2020-03-07 08:24:46 --> Database Driver Class Initialized
DEBUG - 2020-03-07 08:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 08:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 08:24:46 --> Controller Class Initialized
INFO - 2020-03-07 08:24:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 08:24:46 --> Pagination Class Initialized
INFO - 2020-03-07 08:24:46 --> Model "M_show" initialized
INFO - 2020-03-07 08:24:46 --> Helper loaded: form_helper
INFO - 2020-03-07 08:24:46 --> Form Validation Class Initialized
INFO - 2020-03-07 08:24:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 08:24:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 08:24:46 --> Final output sent to browser
DEBUG - 2020-03-07 08:24:46 --> Total execution time: 0.0362
INFO - 2020-03-07 08:25:56 --> Config Class Initialized
INFO - 2020-03-07 08:25:56 --> Hooks Class Initialized
DEBUG - 2020-03-07 08:25:56 --> UTF-8 Support Enabled
INFO - 2020-03-07 08:25:56 --> Utf8 Class Initialized
INFO - 2020-03-07 08:25:56 --> URI Class Initialized
INFO - 2020-03-07 08:25:56 --> Router Class Initialized
INFO - 2020-03-07 08:25:56 --> Output Class Initialized
INFO - 2020-03-07 08:25:56 --> Security Class Initialized
DEBUG - 2020-03-07 08:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 08:25:56 --> Input Class Initialized
INFO - 2020-03-07 08:25:56 --> Language Class Initialized
INFO - 2020-03-07 08:25:56 --> Loader Class Initialized
INFO - 2020-03-07 08:25:56 --> Helper loaded: url_helper
INFO - 2020-03-07 08:25:56 --> Helper loaded: string_helper
INFO - 2020-03-07 08:25:56 --> Database Driver Class Initialized
DEBUG - 2020-03-07 08:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 08:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 08:25:56 --> Controller Class Initialized
INFO - 2020-03-07 08:25:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 08:25:56 --> Pagination Class Initialized
INFO - 2020-03-07 08:25:56 --> Model "M_show" initialized
INFO - 2020-03-07 08:25:56 --> Helper loaded: form_helper
INFO - 2020-03-07 08:25:56 --> Form Validation Class Initialized
INFO - 2020-03-07 08:25:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 08:25:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-07 08:25:56 --> Final output sent to browser
DEBUG - 2020-03-07 08:25:56 --> Total execution time: 0.0215
INFO - 2020-03-07 08:35:52 --> Config Class Initialized
INFO - 2020-03-07 08:35:52 --> Hooks Class Initialized
DEBUG - 2020-03-07 08:35:52 --> UTF-8 Support Enabled
INFO - 2020-03-07 08:35:52 --> Utf8 Class Initialized
INFO - 2020-03-07 08:35:52 --> URI Class Initialized
INFO - 2020-03-07 08:35:52 --> Router Class Initialized
INFO - 2020-03-07 08:35:52 --> Output Class Initialized
INFO - 2020-03-07 08:35:52 --> Security Class Initialized
DEBUG - 2020-03-07 08:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 08:35:52 --> Input Class Initialized
INFO - 2020-03-07 08:35:52 --> Language Class Initialized
INFO - 2020-03-07 08:35:52 --> Loader Class Initialized
INFO - 2020-03-07 08:35:52 --> Helper loaded: url_helper
INFO - 2020-03-07 08:35:52 --> Helper loaded: string_helper
INFO - 2020-03-07 08:35:52 --> Database Driver Class Initialized
DEBUG - 2020-03-07 08:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 08:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 08:35:52 --> Controller Class Initialized
INFO - 2020-03-07 08:35:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 08:35:52 --> Pagination Class Initialized
INFO - 2020-03-07 08:35:52 --> Model "M_show" initialized
INFO - 2020-03-07 08:35:53 --> Helper loaded: form_helper
INFO - 2020-03-07 08:35:53 --> Form Validation Class Initialized
INFO - 2020-03-07 08:35:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 08:35:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-07 08:35:53 --> Final output sent to browser
DEBUG - 2020-03-07 08:35:53 --> Total execution time: 0.0296
INFO - 2020-03-07 08:45:58 --> Config Class Initialized
INFO - 2020-03-07 08:45:58 --> Hooks Class Initialized
DEBUG - 2020-03-07 08:45:58 --> UTF-8 Support Enabled
INFO - 2020-03-07 08:45:58 --> Utf8 Class Initialized
INFO - 2020-03-07 08:45:58 --> URI Class Initialized
DEBUG - 2020-03-07 08:45:58 --> No URI present. Default controller set.
INFO - 2020-03-07 08:45:58 --> Router Class Initialized
INFO - 2020-03-07 08:45:58 --> Output Class Initialized
INFO - 2020-03-07 08:45:58 --> Security Class Initialized
DEBUG - 2020-03-07 08:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 08:45:58 --> Input Class Initialized
INFO - 2020-03-07 08:45:58 --> Language Class Initialized
INFO - 2020-03-07 08:45:58 --> Loader Class Initialized
INFO - 2020-03-07 08:45:58 --> Helper loaded: url_helper
INFO - 2020-03-07 08:45:58 --> Helper loaded: string_helper
INFO - 2020-03-07 08:45:58 --> Database Driver Class Initialized
DEBUG - 2020-03-07 08:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 08:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 08:45:58 --> Controller Class Initialized
INFO - 2020-03-07 08:45:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 08:45:58 --> Pagination Class Initialized
INFO - 2020-03-07 08:45:58 --> Model "M_show" initialized
INFO - 2020-03-07 08:45:58 --> Helper loaded: form_helper
INFO - 2020-03-07 08:45:58 --> Form Validation Class Initialized
INFO - 2020-03-07 08:45:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 08:45:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 08:45:58 --> Final output sent to browser
DEBUG - 2020-03-07 08:45:58 --> Total execution time: 0.0507
INFO - 2020-03-07 08:50:21 --> Config Class Initialized
INFO - 2020-03-07 08:50:21 --> Hooks Class Initialized
DEBUG - 2020-03-07 08:50:21 --> UTF-8 Support Enabled
INFO - 2020-03-07 08:50:21 --> Utf8 Class Initialized
INFO - 2020-03-07 08:50:21 --> URI Class Initialized
DEBUG - 2020-03-07 08:50:21 --> No URI present. Default controller set.
INFO - 2020-03-07 08:50:21 --> Router Class Initialized
INFO - 2020-03-07 08:50:21 --> Output Class Initialized
INFO - 2020-03-07 08:50:21 --> Security Class Initialized
DEBUG - 2020-03-07 08:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 08:50:21 --> Input Class Initialized
INFO - 2020-03-07 08:50:21 --> Language Class Initialized
INFO - 2020-03-07 08:50:21 --> Loader Class Initialized
INFO - 2020-03-07 08:50:21 --> Helper loaded: url_helper
INFO - 2020-03-07 08:50:21 --> Helper loaded: string_helper
INFO - 2020-03-07 08:50:21 --> Database Driver Class Initialized
DEBUG - 2020-03-07 08:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 08:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 08:50:21 --> Controller Class Initialized
INFO - 2020-03-07 08:50:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 08:50:21 --> Pagination Class Initialized
INFO - 2020-03-07 08:50:21 --> Model "M_show" initialized
INFO - 2020-03-07 08:50:21 --> Helper loaded: form_helper
INFO - 2020-03-07 08:50:21 --> Form Validation Class Initialized
INFO - 2020-03-07 08:50:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 08:50:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 08:50:21 --> Final output sent to browser
DEBUG - 2020-03-07 08:50:21 --> Total execution time: 0.0300
INFO - 2020-03-07 08:50:40 --> Config Class Initialized
INFO - 2020-03-07 08:50:40 --> Hooks Class Initialized
DEBUG - 2020-03-07 08:50:40 --> UTF-8 Support Enabled
INFO - 2020-03-07 08:50:40 --> Utf8 Class Initialized
INFO - 2020-03-07 08:50:40 --> URI Class Initialized
INFO - 2020-03-07 08:50:40 --> Router Class Initialized
INFO - 2020-03-07 08:50:40 --> Output Class Initialized
INFO - 2020-03-07 08:50:40 --> Security Class Initialized
DEBUG - 2020-03-07 08:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 08:50:40 --> Input Class Initialized
INFO - 2020-03-07 08:50:40 --> Language Class Initialized
INFO - 2020-03-07 08:50:40 --> Loader Class Initialized
INFO - 2020-03-07 08:50:40 --> Helper loaded: url_helper
INFO - 2020-03-07 08:50:40 --> Helper loaded: string_helper
INFO - 2020-03-07 08:50:40 --> Database Driver Class Initialized
DEBUG - 2020-03-07 08:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 08:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 08:50:40 --> Controller Class Initialized
INFO - 2020-03-07 08:50:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 08:50:40 --> Pagination Class Initialized
INFO - 2020-03-07 08:50:40 --> Model "M_show" initialized
INFO - 2020-03-07 08:50:40 --> Helper loaded: form_helper
INFO - 2020-03-07 08:50:40 --> Form Validation Class Initialized
INFO - 2020-03-07 08:50:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 08:50:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 08:50:40 --> Final output sent to browser
DEBUG - 2020-03-07 08:50:40 --> Total execution time: 0.0428
INFO - 2020-03-07 08:50:41 --> Config Class Initialized
INFO - 2020-03-07 08:50:41 --> Hooks Class Initialized
DEBUG - 2020-03-07 08:50:41 --> UTF-8 Support Enabled
INFO - 2020-03-07 08:50:41 --> Utf8 Class Initialized
INFO - 2020-03-07 08:50:41 --> URI Class Initialized
INFO - 2020-03-07 08:50:41 --> Router Class Initialized
INFO - 2020-03-07 08:50:41 --> Output Class Initialized
INFO - 2020-03-07 08:50:41 --> Security Class Initialized
DEBUG - 2020-03-07 08:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 08:50:41 --> Input Class Initialized
INFO - 2020-03-07 08:50:41 --> Language Class Initialized
INFO - 2020-03-07 08:50:41 --> Loader Class Initialized
INFO - 2020-03-07 08:50:41 --> Helper loaded: url_helper
INFO - 2020-03-07 08:50:41 --> Helper loaded: string_helper
INFO - 2020-03-07 08:50:41 --> Database Driver Class Initialized
DEBUG - 2020-03-07 08:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 08:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 08:50:41 --> Controller Class Initialized
INFO - 2020-03-07 08:50:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 08:50:41 --> Pagination Class Initialized
INFO - 2020-03-07 08:50:41 --> Model "M_show" initialized
INFO - 2020-03-07 08:50:41 --> Helper loaded: form_helper
INFO - 2020-03-07 08:50:41 --> Form Validation Class Initialized
INFO - 2020-03-07 08:50:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 08:50:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 08:50:41 --> Final output sent to browser
DEBUG - 2020-03-07 08:50:41 --> Total execution time: 0.0077
INFO - 2020-03-07 08:50:41 --> Config Class Initialized
INFO - 2020-03-07 08:50:41 --> Hooks Class Initialized
DEBUG - 2020-03-07 08:50:41 --> UTF-8 Support Enabled
INFO - 2020-03-07 08:50:41 --> Utf8 Class Initialized
INFO - 2020-03-07 08:50:41 --> URI Class Initialized
INFO - 2020-03-07 08:50:41 --> Router Class Initialized
INFO - 2020-03-07 08:50:41 --> Output Class Initialized
INFO - 2020-03-07 08:50:41 --> Security Class Initialized
DEBUG - 2020-03-07 08:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 08:50:41 --> Input Class Initialized
INFO - 2020-03-07 08:50:41 --> Language Class Initialized
INFO - 2020-03-07 08:50:41 --> Loader Class Initialized
INFO - 2020-03-07 08:50:41 --> Helper loaded: url_helper
INFO - 2020-03-07 08:50:41 --> Helper loaded: string_helper
INFO - 2020-03-07 08:50:41 --> Database Driver Class Initialized
DEBUG - 2020-03-07 08:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 08:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 08:50:41 --> Controller Class Initialized
INFO - 2020-03-07 08:50:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 08:50:41 --> Pagination Class Initialized
INFO - 2020-03-07 08:50:41 --> Model "M_show" initialized
INFO - 2020-03-07 08:50:41 --> Helper loaded: form_helper
INFO - 2020-03-07 08:50:41 --> Form Validation Class Initialized
INFO - 2020-03-07 08:50:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 08:50:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 08:50:41 --> Final output sent to browser
DEBUG - 2020-03-07 08:50:41 --> Total execution time: 0.0074
INFO - 2020-03-07 08:50:43 --> Config Class Initialized
INFO - 2020-03-07 08:50:43 --> Hooks Class Initialized
DEBUG - 2020-03-07 08:50:43 --> UTF-8 Support Enabled
INFO - 2020-03-07 08:50:43 --> Utf8 Class Initialized
INFO - 2020-03-07 08:50:43 --> URI Class Initialized
INFO - 2020-03-07 08:50:43 --> Router Class Initialized
INFO - 2020-03-07 08:50:43 --> Output Class Initialized
INFO - 2020-03-07 08:50:43 --> Security Class Initialized
DEBUG - 2020-03-07 08:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 08:50:43 --> Input Class Initialized
INFO - 2020-03-07 08:50:43 --> Language Class Initialized
ERROR - 2020-03-07 08:50:43 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-07 08:50:48 --> Config Class Initialized
INFO - 2020-03-07 08:50:48 --> Hooks Class Initialized
DEBUG - 2020-03-07 08:50:48 --> UTF-8 Support Enabled
INFO - 2020-03-07 08:50:48 --> Utf8 Class Initialized
INFO - 2020-03-07 08:50:48 --> URI Class Initialized
INFO - 2020-03-07 08:50:48 --> Router Class Initialized
INFO - 2020-03-07 08:50:48 --> Output Class Initialized
INFO - 2020-03-07 08:50:48 --> Security Class Initialized
DEBUG - 2020-03-07 08:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 08:50:48 --> Input Class Initialized
INFO - 2020-03-07 08:50:48 --> Language Class Initialized
INFO - 2020-03-07 08:50:48 --> Loader Class Initialized
INFO - 2020-03-07 08:50:48 --> Helper loaded: url_helper
INFO - 2020-03-07 08:50:48 --> Helper loaded: string_helper
INFO - 2020-03-07 08:50:48 --> Database Driver Class Initialized
DEBUG - 2020-03-07 08:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 08:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 08:50:48 --> Controller Class Initialized
INFO - 2020-03-07 08:50:48 --> Model "M_tiket" initialized
INFO - 2020-03-07 08:50:48 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 08:50:48 --> Model "M_pesan" initialized
INFO - 2020-03-07 08:50:48 --> Helper loaded: form_helper
INFO - 2020-03-07 08:50:48 --> Form Validation Class Initialized
INFO - 2020-03-07 08:50:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 08:50:48 --> Final output sent to browser
DEBUG - 2020-03-07 08:50:48 --> Total execution time: 0.0975
INFO - 2020-03-07 08:52:15 --> Config Class Initialized
INFO - 2020-03-07 08:52:15 --> Hooks Class Initialized
DEBUG - 2020-03-07 08:52:15 --> UTF-8 Support Enabled
INFO - 2020-03-07 08:52:15 --> Utf8 Class Initialized
INFO - 2020-03-07 08:52:15 --> URI Class Initialized
DEBUG - 2020-03-07 08:52:15 --> No URI present. Default controller set.
INFO - 2020-03-07 08:52:15 --> Router Class Initialized
INFO - 2020-03-07 08:52:15 --> Output Class Initialized
INFO - 2020-03-07 08:52:15 --> Security Class Initialized
DEBUG - 2020-03-07 08:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 08:52:15 --> Input Class Initialized
INFO - 2020-03-07 08:52:15 --> Language Class Initialized
INFO - 2020-03-07 08:52:15 --> Loader Class Initialized
INFO - 2020-03-07 08:52:15 --> Helper loaded: url_helper
INFO - 2020-03-07 08:52:15 --> Helper loaded: string_helper
INFO - 2020-03-07 08:52:15 --> Database Driver Class Initialized
DEBUG - 2020-03-07 08:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 08:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 08:52:15 --> Controller Class Initialized
INFO - 2020-03-07 08:52:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 08:52:15 --> Pagination Class Initialized
INFO - 2020-03-07 08:52:15 --> Model "M_show" initialized
INFO - 2020-03-07 08:52:15 --> Helper loaded: form_helper
INFO - 2020-03-07 08:52:15 --> Form Validation Class Initialized
INFO - 2020-03-07 08:52:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 08:52:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 08:52:15 --> Final output sent to browser
DEBUG - 2020-03-07 08:52:15 --> Total execution time: 0.0419
INFO - 2020-03-07 09:51:49 --> Config Class Initialized
INFO - 2020-03-07 09:51:49 --> Hooks Class Initialized
DEBUG - 2020-03-07 09:51:49 --> UTF-8 Support Enabled
INFO - 2020-03-07 09:51:49 --> Utf8 Class Initialized
INFO - 2020-03-07 09:51:49 --> URI Class Initialized
DEBUG - 2020-03-07 09:51:49 --> No URI present. Default controller set.
INFO - 2020-03-07 09:51:49 --> Router Class Initialized
INFO - 2020-03-07 09:51:49 --> Output Class Initialized
INFO - 2020-03-07 09:51:49 --> Security Class Initialized
DEBUG - 2020-03-07 09:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 09:51:49 --> Input Class Initialized
INFO - 2020-03-07 09:51:49 --> Language Class Initialized
INFO - 2020-03-07 09:51:49 --> Loader Class Initialized
INFO - 2020-03-07 09:51:49 --> Helper loaded: url_helper
INFO - 2020-03-07 09:51:49 --> Helper loaded: string_helper
INFO - 2020-03-07 09:51:49 --> Database Driver Class Initialized
DEBUG - 2020-03-07 09:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 09:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 09:51:49 --> Controller Class Initialized
INFO - 2020-03-07 09:51:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 09:51:49 --> Pagination Class Initialized
INFO - 2020-03-07 09:51:49 --> Model "M_show" initialized
INFO - 2020-03-07 09:51:49 --> Helper loaded: form_helper
INFO - 2020-03-07 09:51:49 --> Form Validation Class Initialized
INFO - 2020-03-07 09:51:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 09:51:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 09:51:49 --> Final output sent to browser
DEBUG - 2020-03-07 09:51:49 --> Total execution time: 0.1650
INFO - 2020-03-07 09:54:38 --> Config Class Initialized
INFO - 2020-03-07 09:54:38 --> Hooks Class Initialized
DEBUG - 2020-03-07 09:54:38 --> UTF-8 Support Enabled
INFO - 2020-03-07 09:54:38 --> Utf8 Class Initialized
INFO - 2020-03-07 09:54:38 --> URI Class Initialized
DEBUG - 2020-03-07 09:54:38 --> No URI present. Default controller set.
INFO - 2020-03-07 09:54:38 --> Router Class Initialized
INFO - 2020-03-07 09:54:38 --> Output Class Initialized
INFO - 2020-03-07 09:54:38 --> Security Class Initialized
DEBUG - 2020-03-07 09:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 09:54:38 --> Input Class Initialized
INFO - 2020-03-07 09:54:38 --> Language Class Initialized
INFO - 2020-03-07 09:54:38 --> Loader Class Initialized
INFO - 2020-03-07 09:54:38 --> Helper loaded: url_helper
INFO - 2020-03-07 09:54:38 --> Helper loaded: string_helper
INFO - 2020-03-07 09:54:38 --> Database Driver Class Initialized
DEBUG - 2020-03-07 09:54:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 09:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 09:54:38 --> Controller Class Initialized
INFO - 2020-03-07 09:54:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 09:54:38 --> Pagination Class Initialized
INFO - 2020-03-07 09:54:38 --> Model "M_show" initialized
INFO - 2020-03-07 09:54:38 --> Helper loaded: form_helper
INFO - 2020-03-07 09:54:38 --> Form Validation Class Initialized
INFO - 2020-03-07 09:54:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 09:54:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 09:54:38 --> Final output sent to browser
DEBUG - 2020-03-07 09:54:38 --> Total execution time: 0.0341
INFO - 2020-03-07 11:32:24 --> Config Class Initialized
INFO - 2020-03-07 11:32:24 --> Hooks Class Initialized
DEBUG - 2020-03-07 11:32:24 --> UTF-8 Support Enabled
INFO - 2020-03-07 11:32:24 --> Utf8 Class Initialized
INFO - 2020-03-07 11:32:24 --> URI Class Initialized
DEBUG - 2020-03-07 11:32:24 --> No URI present. Default controller set.
INFO - 2020-03-07 11:32:24 --> Router Class Initialized
INFO - 2020-03-07 11:32:24 --> Output Class Initialized
INFO - 2020-03-07 11:32:24 --> Security Class Initialized
DEBUG - 2020-03-07 11:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 11:32:24 --> Input Class Initialized
INFO - 2020-03-07 11:32:24 --> Language Class Initialized
INFO - 2020-03-07 11:32:24 --> Loader Class Initialized
INFO - 2020-03-07 11:32:24 --> Helper loaded: url_helper
INFO - 2020-03-07 11:32:24 --> Helper loaded: string_helper
INFO - 2020-03-07 11:32:24 --> Database Driver Class Initialized
DEBUG - 2020-03-07 11:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 11:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 11:32:24 --> Controller Class Initialized
INFO - 2020-03-07 11:32:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 11:32:24 --> Pagination Class Initialized
INFO - 2020-03-07 11:32:24 --> Model "M_show" initialized
INFO - 2020-03-07 11:32:24 --> Helper loaded: form_helper
INFO - 2020-03-07 11:32:24 --> Form Validation Class Initialized
INFO - 2020-03-07 11:32:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 11:32:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 11:32:24 --> Final output sent to browser
DEBUG - 2020-03-07 11:32:24 --> Total execution time: 0.1174
INFO - 2020-03-07 11:32:38 --> Config Class Initialized
INFO - 2020-03-07 11:32:38 --> Hooks Class Initialized
DEBUG - 2020-03-07 11:32:38 --> UTF-8 Support Enabled
INFO - 2020-03-07 11:32:38 --> Utf8 Class Initialized
INFO - 2020-03-07 11:32:38 --> URI Class Initialized
DEBUG - 2020-03-07 11:32:38 --> No URI present. Default controller set.
INFO - 2020-03-07 11:32:38 --> Router Class Initialized
INFO - 2020-03-07 11:32:38 --> Output Class Initialized
INFO - 2020-03-07 11:32:38 --> Security Class Initialized
DEBUG - 2020-03-07 11:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 11:32:38 --> Input Class Initialized
INFO - 2020-03-07 11:32:38 --> Language Class Initialized
INFO - 2020-03-07 11:32:38 --> Loader Class Initialized
INFO - 2020-03-07 11:32:38 --> Helper loaded: url_helper
INFO - 2020-03-07 11:32:38 --> Helper loaded: string_helper
INFO - 2020-03-07 11:32:38 --> Database Driver Class Initialized
DEBUG - 2020-03-07 11:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 11:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 11:32:38 --> Controller Class Initialized
INFO - 2020-03-07 11:32:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 11:32:38 --> Pagination Class Initialized
INFO - 2020-03-07 11:32:38 --> Model "M_show" initialized
INFO - 2020-03-07 11:32:38 --> Helper loaded: form_helper
INFO - 2020-03-07 11:32:38 --> Form Validation Class Initialized
INFO - 2020-03-07 11:32:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 11:32:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 11:32:38 --> Final output sent to browser
DEBUG - 2020-03-07 11:32:38 --> Total execution time: 0.0055
INFO - 2020-03-07 11:32:42 --> Config Class Initialized
INFO - 2020-03-07 11:32:42 --> Hooks Class Initialized
DEBUG - 2020-03-07 11:32:42 --> UTF-8 Support Enabled
INFO - 2020-03-07 11:32:42 --> Utf8 Class Initialized
INFO - 2020-03-07 11:32:42 --> URI Class Initialized
DEBUG - 2020-03-07 11:32:42 --> No URI present. Default controller set.
INFO - 2020-03-07 11:32:42 --> Router Class Initialized
INFO - 2020-03-07 11:32:42 --> Output Class Initialized
INFO - 2020-03-07 11:32:42 --> Security Class Initialized
DEBUG - 2020-03-07 11:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 11:32:42 --> Input Class Initialized
INFO - 2020-03-07 11:32:42 --> Language Class Initialized
INFO - 2020-03-07 11:32:42 --> Loader Class Initialized
INFO - 2020-03-07 11:32:42 --> Helper loaded: url_helper
INFO - 2020-03-07 11:32:42 --> Helper loaded: string_helper
INFO - 2020-03-07 11:32:42 --> Database Driver Class Initialized
DEBUG - 2020-03-07 11:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 11:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 11:32:42 --> Controller Class Initialized
INFO - 2020-03-07 11:32:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 11:32:42 --> Pagination Class Initialized
INFO - 2020-03-07 11:32:42 --> Model "M_show" initialized
INFO - 2020-03-07 11:32:42 --> Helper loaded: form_helper
INFO - 2020-03-07 11:32:42 --> Form Validation Class Initialized
INFO - 2020-03-07 11:32:42 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 11:32:42 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 11:32:42 --> Final output sent to browser
DEBUG - 2020-03-07 11:32:42 --> Total execution time: 0.0055
INFO - 2020-03-07 11:32:43 --> Config Class Initialized
INFO - 2020-03-07 11:32:43 --> Hooks Class Initialized
DEBUG - 2020-03-07 11:32:43 --> UTF-8 Support Enabled
INFO - 2020-03-07 11:32:43 --> Utf8 Class Initialized
INFO - 2020-03-07 11:32:43 --> URI Class Initialized
DEBUG - 2020-03-07 11:32:43 --> No URI present. Default controller set.
INFO - 2020-03-07 11:32:43 --> Router Class Initialized
INFO - 2020-03-07 11:32:43 --> Output Class Initialized
INFO - 2020-03-07 11:32:43 --> Security Class Initialized
DEBUG - 2020-03-07 11:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 11:32:43 --> Input Class Initialized
INFO - 2020-03-07 11:32:43 --> Language Class Initialized
INFO - 2020-03-07 11:32:43 --> Loader Class Initialized
INFO - 2020-03-07 11:32:43 --> Helper loaded: url_helper
INFO - 2020-03-07 11:32:43 --> Helper loaded: string_helper
INFO - 2020-03-07 11:32:43 --> Database Driver Class Initialized
DEBUG - 2020-03-07 11:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 11:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 11:32:43 --> Controller Class Initialized
INFO - 2020-03-07 11:32:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 11:32:43 --> Pagination Class Initialized
INFO - 2020-03-07 11:32:43 --> Model "M_show" initialized
INFO - 2020-03-07 11:32:43 --> Helper loaded: form_helper
INFO - 2020-03-07 11:32:43 --> Form Validation Class Initialized
INFO - 2020-03-07 11:32:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 11:32:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 11:32:43 --> Final output sent to browser
DEBUG - 2020-03-07 11:32:43 --> Total execution time: 0.0067
INFO - 2020-03-07 11:32:43 --> Config Class Initialized
INFO - 2020-03-07 11:32:43 --> Hooks Class Initialized
DEBUG - 2020-03-07 11:32:43 --> UTF-8 Support Enabled
INFO - 2020-03-07 11:32:43 --> Utf8 Class Initialized
INFO - 2020-03-07 11:32:43 --> URI Class Initialized
DEBUG - 2020-03-07 11:32:43 --> No URI present. Default controller set.
INFO - 2020-03-07 11:32:43 --> Router Class Initialized
INFO - 2020-03-07 11:32:43 --> Output Class Initialized
INFO - 2020-03-07 11:32:43 --> Security Class Initialized
DEBUG - 2020-03-07 11:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 11:32:43 --> Input Class Initialized
INFO - 2020-03-07 11:32:43 --> Language Class Initialized
INFO - 2020-03-07 11:32:43 --> Loader Class Initialized
INFO - 2020-03-07 11:32:43 --> Helper loaded: url_helper
INFO - 2020-03-07 11:32:43 --> Helper loaded: string_helper
INFO - 2020-03-07 11:32:43 --> Database Driver Class Initialized
DEBUG - 2020-03-07 11:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 11:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 11:32:43 --> Controller Class Initialized
INFO - 2020-03-07 11:32:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 11:32:43 --> Pagination Class Initialized
INFO - 2020-03-07 11:32:43 --> Model "M_show" initialized
INFO - 2020-03-07 11:32:43 --> Helper loaded: form_helper
INFO - 2020-03-07 11:32:43 --> Form Validation Class Initialized
INFO - 2020-03-07 11:32:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 11:32:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 11:32:43 --> Final output sent to browser
DEBUG - 2020-03-07 11:32:43 --> Total execution time: 0.0043
INFO - 2020-03-07 11:32:48 --> Config Class Initialized
INFO - 2020-03-07 11:32:48 --> Hooks Class Initialized
DEBUG - 2020-03-07 11:32:48 --> UTF-8 Support Enabled
INFO - 2020-03-07 11:32:48 --> Utf8 Class Initialized
INFO - 2020-03-07 11:32:48 --> URI Class Initialized
DEBUG - 2020-03-07 11:32:48 --> No URI present. Default controller set.
INFO - 2020-03-07 11:32:48 --> Router Class Initialized
INFO - 2020-03-07 11:32:48 --> Output Class Initialized
INFO - 2020-03-07 11:32:48 --> Security Class Initialized
DEBUG - 2020-03-07 11:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 11:32:48 --> Input Class Initialized
INFO - 2020-03-07 11:32:48 --> Language Class Initialized
INFO - 2020-03-07 11:32:48 --> Loader Class Initialized
INFO - 2020-03-07 11:32:48 --> Helper loaded: url_helper
INFO - 2020-03-07 11:32:48 --> Helper loaded: string_helper
INFO - 2020-03-07 11:32:48 --> Database Driver Class Initialized
DEBUG - 2020-03-07 11:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 11:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 11:32:48 --> Controller Class Initialized
INFO - 2020-03-07 11:32:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 11:32:48 --> Pagination Class Initialized
INFO - 2020-03-07 11:32:48 --> Model "M_show" initialized
INFO - 2020-03-07 11:32:48 --> Helper loaded: form_helper
INFO - 2020-03-07 11:32:48 --> Form Validation Class Initialized
INFO - 2020-03-07 11:32:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 11:32:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 11:32:48 --> Final output sent to browser
DEBUG - 2020-03-07 11:32:48 --> Total execution time: 0.4101
INFO - 2020-03-07 11:32:56 --> Config Class Initialized
INFO - 2020-03-07 11:32:56 --> Hooks Class Initialized
DEBUG - 2020-03-07 11:32:56 --> UTF-8 Support Enabled
INFO - 2020-03-07 11:32:56 --> Utf8 Class Initialized
INFO - 2020-03-07 11:32:56 --> URI Class Initialized
INFO - 2020-03-07 11:32:56 --> Router Class Initialized
INFO - 2020-03-07 11:32:56 --> Output Class Initialized
INFO - 2020-03-07 11:32:56 --> Security Class Initialized
DEBUG - 2020-03-07 11:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 11:32:56 --> Input Class Initialized
INFO - 2020-03-07 11:32:56 --> Language Class Initialized
INFO - 2020-03-07 11:32:56 --> Loader Class Initialized
INFO - 2020-03-07 11:32:56 --> Helper loaded: url_helper
INFO - 2020-03-07 11:32:56 --> Helper loaded: string_helper
INFO - 2020-03-07 11:32:56 --> Database Driver Class Initialized
DEBUG - 2020-03-07 11:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 11:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 11:32:56 --> Controller Class Initialized
INFO - 2020-03-07 11:32:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 11:32:56 --> Pagination Class Initialized
INFO - 2020-03-07 11:32:56 --> Model "M_show" initialized
INFO - 2020-03-07 11:32:56 --> Helper loaded: form_helper
INFO - 2020-03-07 11:32:56 --> Form Validation Class Initialized
INFO - 2020-03-07 11:32:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 11:32:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 11:32:56 --> Final output sent to browser
DEBUG - 2020-03-07 11:32:56 --> Total execution time: 0.0339
INFO - 2020-03-07 11:33:00 --> Config Class Initialized
INFO - 2020-03-07 11:33:00 --> Hooks Class Initialized
DEBUG - 2020-03-07 11:33:00 --> UTF-8 Support Enabled
INFO - 2020-03-07 11:33:00 --> Utf8 Class Initialized
INFO - 2020-03-07 11:33:00 --> URI Class Initialized
INFO - 2020-03-07 11:33:00 --> Router Class Initialized
INFO - 2020-03-07 11:33:00 --> Output Class Initialized
INFO - 2020-03-07 11:33:00 --> Security Class Initialized
DEBUG - 2020-03-07 11:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 11:33:00 --> Input Class Initialized
INFO - 2020-03-07 11:33:00 --> Language Class Initialized
INFO - 2020-03-07 11:33:00 --> Loader Class Initialized
INFO - 2020-03-07 11:33:00 --> Helper loaded: url_helper
INFO - 2020-03-07 11:33:00 --> Helper loaded: string_helper
INFO - 2020-03-07 11:33:00 --> Database Driver Class Initialized
DEBUG - 2020-03-07 11:33:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 11:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 11:33:00 --> Controller Class Initialized
INFO - 2020-03-07 11:33:00 --> Model "M_tiket" initialized
INFO - 2020-03-07 11:33:00 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 11:33:00 --> Model "M_pesan" initialized
INFO - 2020-03-07 11:33:00 --> Helper loaded: form_helper
INFO - 2020-03-07 11:33:00 --> Form Validation Class Initialized
INFO - 2020-03-07 11:33:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 11:33:00 --> Final output sent to browser
DEBUG - 2020-03-07 11:33:00 --> Total execution time: 0.2204
INFO - 2020-03-07 11:33:07 --> Config Class Initialized
INFO - 2020-03-07 11:33:07 --> Hooks Class Initialized
DEBUG - 2020-03-07 11:33:07 --> UTF-8 Support Enabled
INFO - 2020-03-07 11:33:07 --> Utf8 Class Initialized
INFO - 2020-03-07 11:33:07 --> URI Class Initialized
INFO - 2020-03-07 11:33:07 --> Router Class Initialized
INFO - 2020-03-07 11:33:07 --> Output Class Initialized
INFO - 2020-03-07 11:33:07 --> Security Class Initialized
DEBUG - 2020-03-07 11:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 11:33:07 --> Input Class Initialized
INFO - 2020-03-07 11:33:07 --> Language Class Initialized
INFO - 2020-03-07 11:33:07 --> Loader Class Initialized
INFO - 2020-03-07 11:33:07 --> Helper loaded: url_helper
INFO - 2020-03-07 11:33:07 --> Helper loaded: string_helper
INFO - 2020-03-07 11:33:07 --> Database Driver Class Initialized
DEBUG - 2020-03-07 11:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 11:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 11:33:07 --> Controller Class Initialized
INFO - 2020-03-07 11:33:07 --> Model "M_tiket" initialized
INFO - 2020-03-07 11:33:07 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 11:33:07 --> Model "M_pesan" initialized
INFO - 2020-03-07 11:33:07 --> Helper loaded: form_helper
INFO - 2020-03-07 11:33:07 --> Form Validation Class Initialized
INFO - 2020-03-07 11:33:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 11:33:07 --> Final output sent to browser
DEBUG - 2020-03-07 11:33:07 --> Total execution time: 0.1499
INFO - 2020-03-07 11:41:37 --> Config Class Initialized
INFO - 2020-03-07 11:41:37 --> Hooks Class Initialized
DEBUG - 2020-03-07 11:41:37 --> UTF-8 Support Enabled
INFO - 2020-03-07 11:41:37 --> Utf8 Class Initialized
INFO - 2020-03-07 11:41:37 --> URI Class Initialized
INFO - 2020-03-07 11:41:37 --> Router Class Initialized
INFO - 2020-03-07 11:41:37 --> Output Class Initialized
INFO - 2020-03-07 11:41:37 --> Security Class Initialized
DEBUG - 2020-03-07 11:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 11:41:37 --> Input Class Initialized
INFO - 2020-03-07 11:41:37 --> Language Class Initialized
INFO - 2020-03-07 11:41:37 --> Loader Class Initialized
INFO - 2020-03-07 11:41:37 --> Helper loaded: url_helper
INFO - 2020-03-07 11:41:37 --> Helper loaded: string_helper
INFO - 2020-03-07 11:41:37 --> Database Driver Class Initialized
DEBUG - 2020-03-07 11:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 11:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 11:41:37 --> Controller Class Initialized
INFO - 2020-03-07 11:41:37 --> Model "M_tiket" initialized
INFO - 2020-03-07 11:41:37 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 11:41:37 --> Model "M_pesan" initialized
INFO - 2020-03-07 11:41:37 --> Helper loaded: form_helper
INFO - 2020-03-07 11:41:37 --> Form Validation Class Initialized
INFO - 2020-03-07 11:41:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 11:41:37 --> Final output sent to browser
DEBUG - 2020-03-07 11:41:37 --> Total execution time: 0.0520
INFO - 2020-03-07 12:17:40 --> Config Class Initialized
INFO - 2020-03-07 12:17:40 --> Hooks Class Initialized
INFO - 2020-03-07 12:17:40 --> Config Class Initialized
INFO - 2020-03-07 12:17:40 --> Hooks Class Initialized
DEBUG - 2020-03-07 12:17:40 --> UTF-8 Support Enabled
INFO - 2020-03-07 12:17:40 --> Utf8 Class Initialized
DEBUG - 2020-03-07 12:17:40 --> UTF-8 Support Enabled
INFO - 2020-03-07 12:17:40 --> Utf8 Class Initialized
INFO - 2020-03-07 12:17:40 --> URI Class Initialized
INFO - 2020-03-07 12:17:40 --> URI Class Initialized
INFO - 2020-03-07 12:17:40 --> Router Class Initialized
INFO - 2020-03-07 12:17:40 --> Router Class Initialized
INFO - 2020-03-07 12:17:40 --> Output Class Initialized
INFO - 2020-03-07 12:17:40 --> Output Class Initialized
INFO - 2020-03-07 12:17:40 --> Security Class Initialized
DEBUG - 2020-03-07 12:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 12:17:40 --> Input Class Initialized
INFO - 2020-03-07 12:17:40 --> Security Class Initialized
DEBUG - 2020-03-07 12:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 12:17:40 --> Input Class Initialized
INFO - 2020-03-07 12:17:40 --> Language Class Initialized
INFO - 2020-03-07 12:17:40 --> Language Class Initialized
INFO - 2020-03-07 12:17:40 --> Loader Class Initialized
INFO - 2020-03-07 12:17:40 --> Helper loaded: url_helper
INFO - 2020-03-07 12:17:40 --> Helper loaded: string_helper
INFO - 2020-03-07 12:17:40 --> Loader Class Initialized
INFO - 2020-03-07 12:17:40 --> Helper loaded: url_helper
INFO - 2020-03-07 12:17:40 --> Helper loaded: string_helper
INFO - 2020-03-07 12:17:40 --> Database Driver Class Initialized
INFO - 2020-03-07 12:17:40 --> Database Driver Class Initialized
DEBUG - 2020-03-07 12:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-03-07 12:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 12:17:40 --> Config Class Initialized
INFO - 2020-03-07 12:17:40 --> Hooks Class Initialized
DEBUG - 2020-03-07 12:17:40 --> UTF-8 Support Enabled
INFO - 2020-03-07 12:17:40 --> Utf8 Class Initialized
INFO - 2020-03-07 12:17:40 --> URI Class Initialized
INFO - 2020-03-07 12:17:40 --> Router Class Initialized
INFO - 2020-03-07 12:17:40 --> Output Class Initialized
INFO - 2020-03-07 12:17:40 --> Security Class Initialized
DEBUG - 2020-03-07 12:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 12:17:40 --> Input Class Initialized
INFO - 2020-03-07 12:17:40 --> Language Class Initialized
INFO - 2020-03-07 12:17:40 --> Loader Class Initialized
INFO - 2020-03-07 12:17:40 --> Helper loaded: url_helper
INFO - 2020-03-07 12:17:40 --> Helper loaded: string_helper
INFO - 2020-03-07 12:17:40 --> Database Driver Class Initialized
DEBUG - 2020-03-07 12:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 12:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 12:17:40 --> Controller Class Initialized
INFO - 2020-03-07 12:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 12:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 12:17:40 --> Controller Class Initialized
INFO - 2020-03-07 12:17:40 --> Controller Class Initialized
INFO - 2020-03-07 12:17:40 --> Model "M_tiket" initialized
INFO - 2020-03-07 12:17:40 --> Model "M_tiket" initialized
INFO - 2020-03-07 12:17:40 --> Model "M_tiket" initialized
INFO - 2020-03-07 12:17:40 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 12:17:40 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 12:17:40 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 12:17:40 --> Model "M_pesan" initialized
INFO - 2020-03-07 12:17:40 --> Model "M_pesan" initialized
INFO - 2020-03-07 12:17:40 --> Model "M_pesan" initialized
INFO - 2020-03-07 12:17:40 --> Helper loaded: form_helper
INFO - 2020-03-07 12:17:40 --> Form Validation Class Initialized
INFO - 2020-03-07 12:17:40 --> Helper loaded: form_helper
INFO - 2020-03-07 12:17:40 --> Form Validation Class Initialized
INFO - 2020-03-07 12:17:40 --> Helper loaded: form_helper
INFO - 2020-03-07 12:17:40 --> Form Validation Class Initialized
INFO - 2020-03-07 12:17:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 12:17:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 12:17:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 12:17:40 --> Final output sent to browser
DEBUG - 2020-03-07 12:17:40 --> Total execution time: 0.0912
INFO - 2020-03-07 12:17:40 --> Final output sent to browser
INFO - 2020-03-07 12:17:40 --> Final output sent to browser
DEBUG - 2020-03-07 12:17:40 --> Total execution time: 0.0290
DEBUG - 2020-03-07 12:17:40 --> Total execution time: 0.0910
INFO - 2020-03-07 12:46:57 --> Config Class Initialized
INFO - 2020-03-07 12:46:57 --> Hooks Class Initialized
DEBUG - 2020-03-07 12:46:57 --> UTF-8 Support Enabled
INFO - 2020-03-07 12:46:57 --> Utf8 Class Initialized
INFO - 2020-03-07 12:46:57 --> URI Class Initialized
DEBUG - 2020-03-07 12:46:57 --> No URI present. Default controller set.
INFO - 2020-03-07 12:46:57 --> Router Class Initialized
INFO - 2020-03-07 12:46:57 --> Output Class Initialized
INFO - 2020-03-07 12:46:57 --> Security Class Initialized
DEBUG - 2020-03-07 12:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 12:46:57 --> Input Class Initialized
INFO - 2020-03-07 12:46:57 --> Language Class Initialized
INFO - 2020-03-07 12:46:57 --> Loader Class Initialized
INFO - 2020-03-07 12:46:57 --> Helper loaded: url_helper
INFO - 2020-03-07 12:46:57 --> Helper loaded: string_helper
INFO - 2020-03-07 12:46:57 --> Database Driver Class Initialized
DEBUG - 2020-03-07 12:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 12:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 12:46:57 --> Controller Class Initialized
INFO - 2020-03-07 12:46:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 12:46:57 --> Pagination Class Initialized
INFO - 2020-03-07 12:46:57 --> Model "M_show" initialized
INFO - 2020-03-07 12:46:57 --> Helper loaded: form_helper
INFO - 2020-03-07 12:46:57 --> Form Validation Class Initialized
INFO - 2020-03-07 12:46:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 12:46:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 12:46:57 --> Final output sent to browser
DEBUG - 2020-03-07 12:46:57 --> Total execution time: 0.0408
INFO - 2020-03-07 12:47:21 --> Config Class Initialized
INFO - 2020-03-07 12:47:21 --> Hooks Class Initialized
DEBUG - 2020-03-07 12:47:21 --> UTF-8 Support Enabled
INFO - 2020-03-07 12:47:21 --> Utf8 Class Initialized
INFO - 2020-03-07 12:47:21 --> URI Class Initialized
INFO - 2020-03-07 12:47:21 --> Router Class Initialized
INFO - 2020-03-07 12:47:21 --> Output Class Initialized
INFO - 2020-03-07 12:47:21 --> Security Class Initialized
DEBUG - 2020-03-07 12:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 12:47:21 --> Input Class Initialized
INFO - 2020-03-07 12:47:21 --> Language Class Initialized
INFO - 2020-03-07 12:47:21 --> Loader Class Initialized
INFO - 2020-03-07 12:47:21 --> Helper loaded: url_helper
INFO - 2020-03-07 12:47:21 --> Helper loaded: string_helper
INFO - 2020-03-07 12:47:21 --> Database Driver Class Initialized
DEBUG - 2020-03-07 12:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 12:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 12:47:21 --> Controller Class Initialized
INFO - 2020-03-07 12:47:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 12:47:21 --> Pagination Class Initialized
INFO - 2020-03-07 12:47:21 --> Model "M_show" initialized
INFO - 2020-03-07 12:47:21 --> Helper loaded: form_helper
INFO - 2020-03-07 12:47:21 --> Form Validation Class Initialized
INFO - 2020-03-07 12:47:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 12:47:22 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 12:47:22 --> Final output sent to browser
DEBUG - 2020-03-07 12:47:22 --> Total execution time: 0.0414
INFO - 2020-03-07 12:47:27 --> Config Class Initialized
INFO - 2020-03-07 12:47:27 --> Hooks Class Initialized
DEBUG - 2020-03-07 12:47:27 --> UTF-8 Support Enabled
INFO - 2020-03-07 12:47:27 --> Utf8 Class Initialized
INFO - 2020-03-07 12:47:27 --> URI Class Initialized
INFO - 2020-03-07 12:47:27 --> Router Class Initialized
INFO - 2020-03-07 12:47:27 --> Output Class Initialized
INFO - 2020-03-07 12:47:27 --> Security Class Initialized
DEBUG - 2020-03-07 12:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 12:47:27 --> Input Class Initialized
INFO - 2020-03-07 12:47:27 --> Language Class Initialized
INFO - 2020-03-07 12:47:27 --> Loader Class Initialized
INFO - 2020-03-07 12:47:27 --> Helper loaded: url_helper
INFO - 2020-03-07 12:47:27 --> Helper loaded: string_helper
INFO - 2020-03-07 12:47:27 --> Database Driver Class Initialized
DEBUG - 2020-03-07 12:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 12:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 12:47:27 --> Controller Class Initialized
INFO - 2020-03-07 12:47:27 --> Model "M_tiket" initialized
INFO - 2020-03-07 12:47:27 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 12:47:27 --> Model "M_pesan" initialized
INFO - 2020-03-07 12:47:27 --> Helper loaded: form_helper
INFO - 2020-03-07 12:47:27 --> Form Validation Class Initialized
INFO - 2020-03-07 12:47:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 12:47:27 --> Final output sent to browser
DEBUG - 2020-03-07 12:47:27 --> Total execution time: 0.0116
INFO - 2020-03-07 12:48:05 --> Config Class Initialized
INFO - 2020-03-07 12:48:05 --> Hooks Class Initialized
DEBUG - 2020-03-07 12:48:05 --> UTF-8 Support Enabled
INFO - 2020-03-07 12:48:05 --> Utf8 Class Initialized
INFO - 2020-03-07 12:48:05 --> URI Class Initialized
INFO - 2020-03-07 12:48:05 --> Router Class Initialized
INFO - 2020-03-07 12:48:05 --> Output Class Initialized
INFO - 2020-03-07 12:48:05 --> Security Class Initialized
DEBUG - 2020-03-07 12:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 12:48:05 --> Input Class Initialized
INFO - 2020-03-07 12:48:05 --> Language Class Initialized
INFO - 2020-03-07 12:48:05 --> Loader Class Initialized
INFO - 2020-03-07 12:48:05 --> Helper loaded: url_helper
INFO - 2020-03-07 12:48:05 --> Helper loaded: string_helper
INFO - 2020-03-07 12:48:05 --> Database Driver Class Initialized
DEBUG - 2020-03-07 12:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 12:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 12:48:05 --> Controller Class Initialized
INFO - 2020-03-07 12:48:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 12:48:05 --> Pagination Class Initialized
INFO - 2020-03-07 12:48:05 --> Model "M_show" initialized
INFO - 2020-03-07 12:48:05 --> Helper loaded: form_helper
INFO - 2020-03-07 12:48:05 --> Form Validation Class Initialized
INFO - 2020-03-07 12:48:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 12:48:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 12:48:05 --> Final output sent to browser
DEBUG - 2020-03-07 12:48:05 --> Total execution time: 0.0068
INFO - 2020-03-07 13:35:52 --> Config Class Initialized
INFO - 2020-03-07 13:35:52 --> Hooks Class Initialized
DEBUG - 2020-03-07 13:35:52 --> UTF-8 Support Enabled
INFO - 2020-03-07 13:35:52 --> Utf8 Class Initialized
INFO - 2020-03-07 13:35:52 --> URI Class Initialized
DEBUG - 2020-03-07 13:35:52 --> No URI present. Default controller set.
INFO - 2020-03-07 13:35:52 --> Router Class Initialized
INFO - 2020-03-07 13:35:52 --> Output Class Initialized
INFO - 2020-03-07 13:35:52 --> Security Class Initialized
DEBUG - 2020-03-07 13:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 13:35:52 --> Input Class Initialized
INFO - 2020-03-07 13:35:52 --> Language Class Initialized
INFO - 2020-03-07 13:35:52 --> Loader Class Initialized
INFO - 2020-03-07 13:35:52 --> Helper loaded: url_helper
INFO - 2020-03-07 13:35:52 --> Helper loaded: string_helper
INFO - 2020-03-07 13:35:52 --> Database Driver Class Initialized
DEBUG - 2020-03-07 13:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 13:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 13:35:52 --> Controller Class Initialized
INFO - 2020-03-07 13:35:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 13:35:52 --> Pagination Class Initialized
INFO - 2020-03-07 13:35:52 --> Model "M_show" initialized
INFO - 2020-03-07 13:35:52 --> Helper loaded: form_helper
INFO - 2020-03-07 13:35:52 --> Form Validation Class Initialized
INFO - 2020-03-07 13:35:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 13:35:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 13:35:52 --> Final output sent to browser
DEBUG - 2020-03-07 13:35:52 --> Total execution time: 0.0297
INFO - 2020-03-07 13:35:52 --> Config Class Initialized
INFO - 2020-03-07 13:35:52 --> Hooks Class Initialized
DEBUG - 2020-03-07 13:35:52 --> UTF-8 Support Enabled
INFO - 2020-03-07 13:35:52 --> Utf8 Class Initialized
INFO - 2020-03-07 13:35:52 --> URI Class Initialized
DEBUG - 2020-03-07 13:35:52 --> No URI present. Default controller set.
INFO - 2020-03-07 13:35:52 --> Router Class Initialized
INFO - 2020-03-07 13:35:52 --> Output Class Initialized
INFO - 2020-03-07 13:35:52 --> Security Class Initialized
DEBUG - 2020-03-07 13:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 13:35:52 --> Input Class Initialized
INFO - 2020-03-07 13:35:52 --> Language Class Initialized
INFO - 2020-03-07 13:35:52 --> Loader Class Initialized
INFO - 2020-03-07 13:35:52 --> Helper loaded: url_helper
INFO - 2020-03-07 13:35:52 --> Helper loaded: string_helper
INFO - 2020-03-07 13:35:52 --> Database Driver Class Initialized
DEBUG - 2020-03-07 13:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 13:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 13:35:52 --> Controller Class Initialized
INFO - 2020-03-07 13:35:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 13:35:52 --> Pagination Class Initialized
INFO - 2020-03-07 13:35:52 --> Model "M_show" initialized
INFO - 2020-03-07 13:35:52 --> Helper loaded: form_helper
INFO - 2020-03-07 13:35:52 --> Form Validation Class Initialized
INFO - 2020-03-07 13:35:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 13:35:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 13:35:52 --> Final output sent to browser
DEBUG - 2020-03-07 13:35:52 --> Total execution time: 0.0037
INFO - 2020-03-07 14:07:46 --> Config Class Initialized
INFO - 2020-03-07 14:07:46 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:07:46 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:07:46 --> Utf8 Class Initialized
INFO - 2020-03-07 14:07:46 --> URI Class Initialized
DEBUG - 2020-03-07 14:07:46 --> No URI present. Default controller set.
INFO - 2020-03-07 14:07:46 --> Router Class Initialized
INFO - 2020-03-07 14:07:46 --> Output Class Initialized
INFO - 2020-03-07 14:07:46 --> Security Class Initialized
DEBUG - 2020-03-07 14:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:07:46 --> Input Class Initialized
INFO - 2020-03-07 14:07:46 --> Language Class Initialized
INFO - 2020-03-07 14:07:46 --> Loader Class Initialized
INFO - 2020-03-07 14:07:46 --> Helper loaded: url_helper
INFO - 2020-03-07 14:07:46 --> Helper loaded: string_helper
INFO - 2020-03-07 14:07:46 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:07:46 --> Controller Class Initialized
INFO - 2020-03-07 14:07:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:07:46 --> Pagination Class Initialized
INFO - 2020-03-07 14:07:46 --> Model "M_show" initialized
INFO - 2020-03-07 14:07:46 --> Helper loaded: form_helper
INFO - 2020-03-07 14:07:46 --> Form Validation Class Initialized
INFO - 2020-03-07 14:07:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:07:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:07:46 --> Final output sent to browser
DEBUG - 2020-03-07 14:07:46 --> Total execution time: 0.0374
INFO - 2020-03-07 14:08:11 --> Config Class Initialized
INFO - 2020-03-07 14:08:11 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:08:11 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:08:11 --> Utf8 Class Initialized
INFO - 2020-03-07 14:08:11 --> URI Class Initialized
INFO - 2020-03-07 14:08:11 --> Router Class Initialized
INFO - 2020-03-07 14:08:11 --> Output Class Initialized
INFO - 2020-03-07 14:08:11 --> Security Class Initialized
DEBUG - 2020-03-07 14:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:08:11 --> Input Class Initialized
INFO - 2020-03-07 14:08:11 --> Language Class Initialized
INFO - 2020-03-07 14:08:11 --> Loader Class Initialized
INFO - 2020-03-07 14:08:11 --> Helper loaded: url_helper
INFO - 2020-03-07 14:08:11 --> Helper loaded: string_helper
INFO - 2020-03-07 14:08:11 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:08:11 --> Controller Class Initialized
INFO - 2020-03-07 14:08:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:08:11 --> Pagination Class Initialized
INFO - 2020-03-07 14:08:11 --> Model "M_show" initialized
INFO - 2020-03-07 14:08:11 --> Helper loaded: form_helper
INFO - 2020-03-07 14:08:11 --> Form Validation Class Initialized
INFO - 2020-03-07 14:08:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:08:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 14:08:11 --> Final output sent to browser
DEBUG - 2020-03-07 14:08:11 --> Total execution time: 0.1082
INFO - 2020-03-07 14:08:17 --> Config Class Initialized
INFO - 2020-03-07 14:08:17 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:08:17 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:08:17 --> Utf8 Class Initialized
INFO - 2020-03-07 14:08:17 --> URI Class Initialized
INFO - 2020-03-07 14:08:17 --> Router Class Initialized
INFO - 2020-03-07 14:08:17 --> Output Class Initialized
INFO - 2020-03-07 14:08:17 --> Security Class Initialized
DEBUG - 2020-03-07 14:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:08:17 --> Input Class Initialized
INFO - 2020-03-07 14:08:17 --> Language Class Initialized
INFO - 2020-03-07 14:08:17 --> Loader Class Initialized
INFO - 2020-03-07 14:08:17 --> Helper loaded: url_helper
INFO - 2020-03-07 14:08:17 --> Helper loaded: string_helper
INFO - 2020-03-07 14:08:17 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:08:17 --> Controller Class Initialized
INFO - 2020-03-07 14:08:17 --> Model "M_tiket" initialized
INFO - 2020-03-07 14:08:17 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 14:08:17 --> Model "M_pesan" initialized
INFO - 2020-03-07 14:08:17 --> Helper loaded: form_helper
INFO - 2020-03-07 14:08:17 --> Form Validation Class Initialized
INFO - 2020-03-07 14:08:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 14:08:17 --> Final output sent to browser
DEBUG - 2020-03-07 14:08:17 --> Total execution time: 0.0389
INFO - 2020-03-07 14:08:33 --> Config Class Initialized
INFO - 2020-03-07 14:08:33 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:08:33 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:08:33 --> Utf8 Class Initialized
INFO - 2020-03-07 14:08:33 --> URI Class Initialized
INFO - 2020-03-07 14:08:33 --> Router Class Initialized
INFO - 2020-03-07 14:08:33 --> Output Class Initialized
INFO - 2020-03-07 14:08:33 --> Security Class Initialized
DEBUG - 2020-03-07 14:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:08:33 --> Input Class Initialized
INFO - 2020-03-07 14:08:33 --> Language Class Initialized
INFO - 2020-03-07 14:08:33 --> Loader Class Initialized
INFO - 2020-03-07 14:08:33 --> Helper loaded: url_helper
INFO - 2020-03-07 14:08:33 --> Helper loaded: string_helper
INFO - 2020-03-07 14:08:33 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:08:33 --> Controller Class Initialized
INFO - 2020-03-07 14:08:33 --> Model "M_tiket" initialized
INFO - 2020-03-07 14:08:33 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 14:08:33 --> Model "M_pesan" initialized
INFO - 2020-03-07 14:08:33 --> Helper loaded: form_helper
INFO - 2020-03-07 14:08:33 --> Form Validation Class Initialized
INFO - 2020-03-07 14:08:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 14:08:33 --> Final output sent to browser
DEBUG - 2020-03-07 14:08:33 --> Total execution time: 0.0302
INFO - 2020-03-07 14:11:04 --> Config Class Initialized
INFO - 2020-03-07 14:11:04 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:11:04 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:11:04 --> Utf8 Class Initialized
INFO - 2020-03-07 14:11:04 --> URI Class Initialized
DEBUG - 2020-03-07 14:11:04 --> No URI present. Default controller set.
INFO - 2020-03-07 14:11:04 --> Router Class Initialized
INFO - 2020-03-07 14:11:04 --> Output Class Initialized
INFO - 2020-03-07 14:11:04 --> Security Class Initialized
DEBUG - 2020-03-07 14:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:11:04 --> Input Class Initialized
INFO - 2020-03-07 14:11:04 --> Language Class Initialized
INFO - 2020-03-07 14:11:04 --> Loader Class Initialized
INFO - 2020-03-07 14:11:04 --> Helper loaded: url_helper
INFO - 2020-03-07 14:11:04 --> Helper loaded: string_helper
INFO - 2020-03-07 14:11:04 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:11:04 --> Controller Class Initialized
INFO - 2020-03-07 14:11:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:11:04 --> Pagination Class Initialized
INFO - 2020-03-07 14:11:04 --> Model "M_show" initialized
INFO - 2020-03-07 14:11:04 --> Helper loaded: form_helper
INFO - 2020-03-07 14:11:04 --> Form Validation Class Initialized
INFO - 2020-03-07 14:11:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:11:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:11:04 --> Final output sent to browser
DEBUG - 2020-03-07 14:11:04 --> Total execution time: 0.2581
INFO - 2020-03-07 14:11:11 --> Config Class Initialized
INFO - 2020-03-07 14:11:11 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:11:11 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:11:11 --> Utf8 Class Initialized
INFO - 2020-03-07 14:11:11 --> URI Class Initialized
DEBUG - 2020-03-07 14:11:11 --> No URI present. Default controller set.
INFO - 2020-03-07 14:11:11 --> Router Class Initialized
INFO - 2020-03-07 14:11:11 --> Output Class Initialized
INFO - 2020-03-07 14:11:11 --> Security Class Initialized
DEBUG - 2020-03-07 14:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:11:11 --> Input Class Initialized
INFO - 2020-03-07 14:11:11 --> Language Class Initialized
INFO - 2020-03-07 14:11:11 --> Loader Class Initialized
INFO - 2020-03-07 14:11:11 --> Helper loaded: url_helper
INFO - 2020-03-07 14:11:11 --> Helper loaded: string_helper
INFO - 2020-03-07 14:11:11 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:11:11 --> Controller Class Initialized
INFO - 2020-03-07 14:11:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:11:11 --> Pagination Class Initialized
INFO - 2020-03-07 14:11:11 --> Model "M_show" initialized
INFO - 2020-03-07 14:11:11 --> Helper loaded: form_helper
INFO - 2020-03-07 14:11:11 --> Form Validation Class Initialized
INFO - 2020-03-07 14:11:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:11:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:11:11 --> Final output sent to browser
DEBUG - 2020-03-07 14:11:11 --> Total execution time: 0.0231
INFO - 2020-03-07 14:11:15 --> Config Class Initialized
INFO - 2020-03-07 14:11:15 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:11:15 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:11:15 --> Utf8 Class Initialized
INFO - 2020-03-07 14:11:15 --> URI Class Initialized
INFO - 2020-03-07 14:11:15 --> Router Class Initialized
INFO - 2020-03-07 14:11:15 --> Output Class Initialized
INFO - 2020-03-07 14:11:15 --> Security Class Initialized
DEBUG - 2020-03-07 14:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:11:15 --> Input Class Initialized
INFO - 2020-03-07 14:11:15 --> Language Class Initialized
INFO - 2020-03-07 14:11:15 --> Loader Class Initialized
INFO - 2020-03-07 14:11:15 --> Helper loaded: url_helper
INFO - 2020-03-07 14:11:15 --> Helper loaded: string_helper
INFO - 2020-03-07 14:11:15 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:11:15 --> Controller Class Initialized
INFO - 2020-03-07 14:11:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:11:15 --> Pagination Class Initialized
INFO - 2020-03-07 14:11:15 --> Model "M_show" initialized
INFO - 2020-03-07 14:11:15 --> Helper loaded: form_helper
INFO - 2020-03-07 14:11:15 --> Form Validation Class Initialized
INFO - 2020-03-07 14:11:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:11:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 14:11:15 --> Final output sent to browser
DEBUG - 2020-03-07 14:11:15 --> Total execution time: 0.0242
INFO - 2020-03-07 14:11:19 --> Config Class Initialized
INFO - 2020-03-07 14:11:19 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:11:19 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:11:19 --> Utf8 Class Initialized
INFO - 2020-03-07 14:11:19 --> URI Class Initialized
INFO - 2020-03-07 14:11:19 --> Router Class Initialized
INFO - 2020-03-07 14:11:19 --> Output Class Initialized
INFO - 2020-03-07 14:11:19 --> Security Class Initialized
DEBUG - 2020-03-07 14:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:11:19 --> Input Class Initialized
INFO - 2020-03-07 14:11:19 --> Language Class Initialized
INFO - 2020-03-07 14:11:19 --> Loader Class Initialized
INFO - 2020-03-07 14:11:19 --> Helper loaded: url_helper
INFO - 2020-03-07 14:11:19 --> Helper loaded: string_helper
INFO - 2020-03-07 14:11:19 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:11:19 --> Controller Class Initialized
INFO - 2020-03-07 14:11:19 --> Model "M_tiket" initialized
INFO - 2020-03-07 14:11:19 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 14:11:19 --> Model "M_pesan" initialized
INFO - 2020-03-07 14:11:19 --> Helper loaded: form_helper
INFO - 2020-03-07 14:11:19 --> Form Validation Class Initialized
INFO - 2020-03-07 14:11:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 14:11:19 --> Final output sent to browser
DEBUG - 2020-03-07 14:11:19 --> Total execution time: 0.0201
INFO - 2020-03-07 14:11:21 --> Config Class Initialized
INFO - 2020-03-07 14:11:21 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:11:21 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:11:21 --> Utf8 Class Initialized
INFO - 2020-03-07 14:11:21 --> URI Class Initialized
INFO - 2020-03-07 14:11:21 --> Router Class Initialized
INFO - 2020-03-07 14:11:21 --> Output Class Initialized
INFO - 2020-03-07 14:11:21 --> Security Class Initialized
DEBUG - 2020-03-07 14:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:11:21 --> Input Class Initialized
INFO - 2020-03-07 14:11:21 --> Language Class Initialized
INFO - 2020-03-07 14:11:21 --> Loader Class Initialized
INFO - 2020-03-07 14:11:21 --> Helper loaded: url_helper
INFO - 2020-03-07 14:11:21 --> Helper loaded: string_helper
INFO - 2020-03-07 14:11:21 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:11:21 --> Controller Class Initialized
INFO - 2020-03-07 14:11:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:11:21 --> Pagination Class Initialized
INFO - 2020-03-07 14:11:21 --> Model "M_show" initialized
INFO - 2020-03-07 14:11:21 --> Helper loaded: form_helper
INFO - 2020-03-07 14:11:21 --> Form Validation Class Initialized
INFO - 2020-03-07 14:11:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:11:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 14:11:21 --> Final output sent to browser
DEBUG - 2020-03-07 14:11:21 --> Total execution time: 0.0774
INFO - 2020-03-07 14:11:22 --> Config Class Initialized
INFO - 2020-03-07 14:11:22 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:11:22 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:11:22 --> Utf8 Class Initialized
INFO - 2020-03-07 14:11:22 --> URI Class Initialized
INFO - 2020-03-07 14:11:22 --> Router Class Initialized
INFO - 2020-03-07 14:11:22 --> Output Class Initialized
INFO - 2020-03-07 14:11:22 --> Security Class Initialized
DEBUG - 2020-03-07 14:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:11:22 --> Input Class Initialized
INFO - 2020-03-07 14:11:22 --> Language Class Initialized
ERROR - 2020-03-07 14:11:22 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-07 14:11:27 --> Config Class Initialized
INFO - 2020-03-07 14:11:27 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:11:27 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:11:27 --> Utf8 Class Initialized
INFO - 2020-03-07 14:11:27 --> URI Class Initialized
INFO - 2020-03-07 14:11:27 --> Router Class Initialized
INFO - 2020-03-07 14:11:27 --> Output Class Initialized
INFO - 2020-03-07 14:11:27 --> Security Class Initialized
DEBUG - 2020-03-07 14:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:11:27 --> Input Class Initialized
INFO - 2020-03-07 14:11:27 --> Language Class Initialized
INFO - 2020-03-07 14:11:27 --> Loader Class Initialized
INFO - 2020-03-07 14:11:27 --> Helper loaded: url_helper
INFO - 2020-03-07 14:11:27 --> Helper loaded: string_helper
INFO - 2020-03-07 14:11:27 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:11:27 --> Controller Class Initialized
INFO - 2020-03-07 14:11:27 --> Model "M_tiket" initialized
INFO - 2020-03-07 14:11:27 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 14:11:27 --> Model "M_pesan" initialized
INFO - 2020-03-07 14:11:27 --> Helper loaded: form_helper
INFO - 2020-03-07 14:11:27 --> Form Validation Class Initialized
INFO - 2020-03-07 14:11:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 14:11:27 --> Final output sent to browser
DEBUG - 2020-03-07 14:11:27 --> Total execution time: 0.0161
INFO - 2020-03-07 14:11:27 --> Config Class Initialized
INFO - 2020-03-07 14:11:27 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:11:27 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:11:27 --> Utf8 Class Initialized
INFO - 2020-03-07 14:11:27 --> URI Class Initialized
INFO - 2020-03-07 14:11:27 --> Router Class Initialized
INFO - 2020-03-07 14:11:27 --> Output Class Initialized
INFO - 2020-03-07 14:11:27 --> Security Class Initialized
DEBUG - 2020-03-07 14:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:11:27 --> Input Class Initialized
INFO - 2020-03-07 14:11:27 --> Language Class Initialized
INFO - 2020-03-07 14:11:27 --> Loader Class Initialized
INFO - 2020-03-07 14:11:27 --> Helper loaded: url_helper
INFO - 2020-03-07 14:11:27 --> Helper loaded: string_helper
INFO - 2020-03-07 14:11:27 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:11:27 --> Controller Class Initialized
INFO - 2020-03-07 14:11:27 --> Model "M_tiket" initialized
INFO - 2020-03-07 14:11:27 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 14:11:27 --> Model "M_pesan" initialized
INFO - 2020-03-07 14:11:27 --> Helper loaded: form_helper
INFO - 2020-03-07 14:11:27 --> Form Validation Class Initialized
INFO - 2020-03-07 14:11:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 14:11:27 --> Final output sent to browser
DEBUG - 2020-03-07 14:11:27 --> Total execution time: 0.2025
INFO - 2020-03-07 14:11:40 --> Config Class Initialized
INFO - 2020-03-07 14:11:40 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:11:40 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:11:40 --> Utf8 Class Initialized
INFO - 2020-03-07 14:11:40 --> URI Class Initialized
INFO - 2020-03-07 14:11:40 --> Router Class Initialized
INFO - 2020-03-07 14:11:40 --> Output Class Initialized
INFO - 2020-03-07 14:11:40 --> Security Class Initialized
DEBUG - 2020-03-07 14:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:11:40 --> Input Class Initialized
INFO - 2020-03-07 14:11:40 --> Language Class Initialized
INFO - 2020-03-07 14:11:40 --> Loader Class Initialized
INFO - 2020-03-07 14:11:40 --> Helper loaded: url_helper
INFO - 2020-03-07 14:11:40 --> Helper loaded: string_helper
INFO - 2020-03-07 14:11:40 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:11:40 --> Controller Class Initialized
INFO - 2020-03-07 14:11:40 --> Model "M_tiket" initialized
INFO - 2020-03-07 14:11:40 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 14:11:40 --> Model "M_pesan" initialized
INFO - 2020-03-07 14:11:40 --> Helper loaded: form_helper
INFO - 2020-03-07 14:11:40 --> Form Validation Class Initialized
INFO - 2020-03-07 14:11:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 14:11:40 --> Final output sent to browser
DEBUG - 2020-03-07 14:11:40 --> Total execution time: 0.0079
INFO - 2020-03-07 14:15:20 --> Config Class Initialized
INFO - 2020-03-07 14:15:20 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:15:20 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:15:20 --> Utf8 Class Initialized
INFO - 2020-03-07 14:15:20 --> URI Class Initialized
DEBUG - 2020-03-07 14:15:20 --> No URI present. Default controller set.
INFO - 2020-03-07 14:15:20 --> Router Class Initialized
INFO - 2020-03-07 14:15:20 --> Output Class Initialized
INFO - 2020-03-07 14:15:20 --> Security Class Initialized
DEBUG - 2020-03-07 14:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:15:20 --> Input Class Initialized
INFO - 2020-03-07 14:15:20 --> Language Class Initialized
INFO - 2020-03-07 14:15:20 --> Loader Class Initialized
INFO - 2020-03-07 14:15:20 --> Helper loaded: url_helper
INFO - 2020-03-07 14:15:20 --> Helper loaded: string_helper
INFO - 2020-03-07 14:15:20 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:15:20 --> Controller Class Initialized
INFO - 2020-03-07 14:15:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:15:20 --> Pagination Class Initialized
INFO - 2020-03-07 14:15:20 --> Model "M_show" initialized
INFO - 2020-03-07 14:15:20 --> Helper loaded: form_helper
INFO - 2020-03-07 14:15:20 --> Form Validation Class Initialized
INFO - 2020-03-07 14:15:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:15:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:15:20 --> Final output sent to browser
DEBUG - 2020-03-07 14:15:20 --> Total execution time: 0.0434
INFO - 2020-03-07 14:15:36 --> Config Class Initialized
INFO - 2020-03-07 14:15:36 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:15:36 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:15:36 --> Utf8 Class Initialized
INFO - 2020-03-07 14:15:36 --> URI Class Initialized
INFO - 2020-03-07 14:15:36 --> Router Class Initialized
INFO - 2020-03-07 14:15:36 --> Output Class Initialized
INFO - 2020-03-07 14:15:36 --> Security Class Initialized
DEBUG - 2020-03-07 14:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:15:36 --> Input Class Initialized
INFO - 2020-03-07 14:15:36 --> Language Class Initialized
INFO - 2020-03-07 14:15:36 --> Loader Class Initialized
INFO - 2020-03-07 14:15:36 --> Helper loaded: url_helper
INFO - 2020-03-07 14:15:36 --> Helper loaded: string_helper
INFO - 2020-03-07 14:15:36 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:15:36 --> Controller Class Initialized
INFO - 2020-03-07 14:15:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:15:36 --> Pagination Class Initialized
INFO - 2020-03-07 14:15:36 --> Model "M_show" initialized
INFO - 2020-03-07 14:15:36 --> Helper loaded: form_helper
INFO - 2020-03-07 14:15:36 --> Form Validation Class Initialized
INFO - 2020-03-07 14:15:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:15:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-07 14:15:36 --> Final output sent to browser
DEBUG - 2020-03-07 14:15:36 --> Total execution time: 0.1248
INFO - 2020-03-07 14:16:48 --> Config Class Initialized
INFO - 2020-03-07 14:16:48 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:16:48 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:16:48 --> Utf8 Class Initialized
INFO - 2020-03-07 14:16:48 --> URI Class Initialized
DEBUG - 2020-03-07 14:16:48 --> No URI present. Default controller set.
INFO - 2020-03-07 14:16:48 --> Router Class Initialized
INFO - 2020-03-07 14:16:48 --> Output Class Initialized
INFO - 2020-03-07 14:16:48 --> Security Class Initialized
DEBUG - 2020-03-07 14:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:16:48 --> Input Class Initialized
INFO - 2020-03-07 14:16:48 --> Language Class Initialized
INFO - 2020-03-07 14:16:48 --> Loader Class Initialized
INFO - 2020-03-07 14:16:48 --> Helper loaded: url_helper
INFO - 2020-03-07 14:16:48 --> Helper loaded: string_helper
INFO - 2020-03-07 14:16:48 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:16:48 --> Controller Class Initialized
INFO - 2020-03-07 14:16:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:16:48 --> Pagination Class Initialized
INFO - 2020-03-07 14:16:48 --> Model "M_show" initialized
INFO - 2020-03-07 14:16:48 --> Helper loaded: form_helper
INFO - 2020-03-07 14:16:48 --> Form Validation Class Initialized
INFO - 2020-03-07 14:16:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:16:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:16:48 --> Final output sent to browser
DEBUG - 2020-03-07 14:16:48 --> Total execution time: 0.0623
INFO - 2020-03-07 14:16:52 --> Config Class Initialized
INFO - 2020-03-07 14:16:52 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:16:52 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:16:52 --> Utf8 Class Initialized
INFO - 2020-03-07 14:16:52 --> URI Class Initialized
DEBUG - 2020-03-07 14:16:52 --> No URI present. Default controller set.
INFO - 2020-03-07 14:16:52 --> Router Class Initialized
INFO - 2020-03-07 14:16:52 --> Output Class Initialized
INFO - 2020-03-07 14:16:52 --> Security Class Initialized
DEBUG - 2020-03-07 14:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:16:52 --> Input Class Initialized
INFO - 2020-03-07 14:16:52 --> Language Class Initialized
INFO - 2020-03-07 14:16:52 --> Loader Class Initialized
INFO - 2020-03-07 14:16:52 --> Helper loaded: url_helper
INFO - 2020-03-07 14:16:52 --> Helper loaded: string_helper
INFO - 2020-03-07 14:16:52 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:16:52 --> Controller Class Initialized
INFO - 2020-03-07 14:16:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:16:52 --> Pagination Class Initialized
INFO - 2020-03-07 14:16:52 --> Model "M_show" initialized
INFO - 2020-03-07 14:16:52 --> Helper loaded: form_helper
INFO - 2020-03-07 14:16:52 --> Form Validation Class Initialized
INFO - 2020-03-07 14:16:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:16:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:16:52 --> Final output sent to browser
DEBUG - 2020-03-07 14:16:52 --> Total execution time: 0.0069
INFO - 2020-03-07 14:17:11 --> Config Class Initialized
INFO - 2020-03-07 14:17:11 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:17:11 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:17:11 --> Utf8 Class Initialized
INFO - 2020-03-07 14:17:11 --> URI Class Initialized
INFO - 2020-03-07 14:17:11 --> Router Class Initialized
INFO - 2020-03-07 14:17:11 --> Output Class Initialized
INFO - 2020-03-07 14:17:11 --> Security Class Initialized
DEBUG - 2020-03-07 14:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:17:11 --> Input Class Initialized
INFO - 2020-03-07 14:17:11 --> Language Class Initialized
INFO - 2020-03-07 14:17:11 --> Loader Class Initialized
INFO - 2020-03-07 14:17:11 --> Helper loaded: url_helper
INFO - 2020-03-07 14:17:11 --> Helper loaded: string_helper
INFO - 2020-03-07 14:17:11 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:17:11 --> Controller Class Initialized
INFO - 2020-03-07 14:17:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:17:11 --> Pagination Class Initialized
INFO - 2020-03-07 14:17:11 --> Model "M_show" initialized
INFO - 2020-03-07 14:17:11 --> Helper loaded: form_helper
INFO - 2020-03-07 14:17:11 --> Form Validation Class Initialized
INFO - 2020-03-07 14:17:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:17:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 14:17:11 --> Final output sent to browser
DEBUG - 2020-03-07 14:17:11 --> Total execution time: 0.0077
INFO - 2020-03-07 14:17:12 --> Config Class Initialized
INFO - 2020-03-07 14:17:12 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:17:12 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:17:12 --> Utf8 Class Initialized
INFO - 2020-03-07 14:17:12 --> URI Class Initialized
INFO - 2020-03-07 14:17:12 --> Router Class Initialized
INFO - 2020-03-07 14:17:12 --> Output Class Initialized
INFO - 2020-03-07 14:17:12 --> Security Class Initialized
DEBUG - 2020-03-07 14:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:17:12 --> Input Class Initialized
INFO - 2020-03-07 14:17:12 --> Language Class Initialized
ERROR - 2020-03-07 14:17:12 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-07 14:17:16 --> Config Class Initialized
INFO - 2020-03-07 14:17:16 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:17:16 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:17:16 --> Utf8 Class Initialized
INFO - 2020-03-07 14:17:16 --> URI Class Initialized
INFO - 2020-03-07 14:17:16 --> Router Class Initialized
INFO - 2020-03-07 14:17:16 --> Output Class Initialized
INFO - 2020-03-07 14:17:16 --> Security Class Initialized
DEBUG - 2020-03-07 14:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:17:16 --> Input Class Initialized
INFO - 2020-03-07 14:17:16 --> Language Class Initialized
INFO - 2020-03-07 14:17:16 --> Loader Class Initialized
INFO - 2020-03-07 14:17:16 --> Helper loaded: url_helper
INFO - 2020-03-07 14:17:16 --> Helper loaded: string_helper
INFO - 2020-03-07 14:17:16 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:17:16 --> Controller Class Initialized
INFO - 2020-03-07 14:17:16 --> Model "M_tiket" initialized
INFO - 2020-03-07 14:17:16 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 14:17:16 --> Model "M_pesan" initialized
INFO - 2020-03-07 14:17:16 --> Helper loaded: form_helper
INFO - 2020-03-07 14:17:16 --> Form Validation Class Initialized
INFO - 2020-03-07 14:17:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 14:17:16 --> Final output sent to browser
DEBUG - 2020-03-07 14:17:16 --> Total execution time: 0.0105
INFO - 2020-03-07 14:18:12 --> Config Class Initialized
INFO - 2020-03-07 14:18:12 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:18:12 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:18:12 --> Utf8 Class Initialized
INFO - 2020-03-07 14:18:12 --> URI Class Initialized
DEBUG - 2020-03-07 14:18:12 --> No URI present. Default controller set.
INFO - 2020-03-07 14:18:12 --> Router Class Initialized
INFO - 2020-03-07 14:18:12 --> Output Class Initialized
INFO - 2020-03-07 14:18:12 --> Security Class Initialized
DEBUG - 2020-03-07 14:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:18:12 --> Input Class Initialized
INFO - 2020-03-07 14:18:12 --> Language Class Initialized
INFO - 2020-03-07 14:18:12 --> Loader Class Initialized
INFO - 2020-03-07 14:18:12 --> Helper loaded: url_helper
INFO - 2020-03-07 14:18:12 --> Helper loaded: string_helper
INFO - 2020-03-07 14:18:12 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:18:12 --> Controller Class Initialized
INFO - 2020-03-07 14:18:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:18:12 --> Pagination Class Initialized
INFO - 2020-03-07 14:18:12 --> Model "M_show" initialized
INFO - 2020-03-07 14:18:12 --> Helper loaded: form_helper
INFO - 2020-03-07 14:18:12 --> Form Validation Class Initialized
INFO - 2020-03-07 14:18:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:18:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:18:12 --> Final output sent to browser
DEBUG - 2020-03-07 14:18:12 --> Total execution time: 0.0066
INFO - 2020-03-07 14:18:51 --> Config Class Initialized
INFO - 2020-03-07 14:18:51 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:18:51 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:18:51 --> Utf8 Class Initialized
INFO - 2020-03-07 14:18:51 --> URI Class Initialized
INFO - 2020-03-07 14:18:51 --> Router Class Initialized
INFO - 2020-03-07 14:18:51 --> Output Class Initialized
INFO - 2020-03-07 14:18:51 --> Security Class Initialized
DEBUG - 2020-03-07 14:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:18:51 --> Input Class Initialized
INFO - 2020-03-07 14:18:51 --> Language Class Initialized
INFO - 2020-03-07 14:18:51 --> Loader Class Initialized
INFO - 2020-03-07 14:18:51 --> Helper loaded: url_helper
INFO - 2020-03-07 14:18:51 --> Helper loaded: string_helper
INFO - 2020-03-07 14:18:51 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:18:51 --> Controller Class Initialized
INFO - 2020-03-07 14:18:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:18:51 --> Pagination Class Initialized
INFO - 2020-03-07 14:18:51 --> Model "M_show" initialized
INFO - 2020-03-07 14:18:51 --> Helper loaded: form_helper
INFO - 2020-03-07 14:18:51 --> Form Validation Class Initialized
INFO - 2020-03-07 14:18:51 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:18:51 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 14:18:51 --> Final output sent to browser
DEBUG - 2020-03-07 14:18:51 --> Total execution time: 0.0889
INFO - 2020-03-07 14:18:52 --> Config Class Initialized
INFO - 2020-03-07 14:18:52 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:18:52 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:18:52 --> Utf8 Class Initialized
INFO - 2020-03-07 14:18:52 --> URI Class Initialized
INFO - 2020-03-07 14:18:52 --> Router Class Initialized
INFO - 2020-03-07 14:18:52 --> Output Class Initialized
INFO - 2020-03-07 14:18:52 --> Security Class Initialized
DEBUG - 2020-03-07 14:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:18:52 --> Input Class Initialized
INFO - 2020-03-07 14:18:52 --> Language Class Initialized
ERROR - 2020-03-07 14:18:52 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-07 14:18:58 --> Config Class Initialized
INFO - 2020-03-07 14:18:58 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:18:58 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:18:58 --> Utf8 Class Initialized
INFO - 2020-03-07 14:18:58 --> URI Class Initialized
INFO - 2020-03-07 14:18:58 --> Router Class Initialized
INFO - 2020-03-07 14:18:58 --> Output Class Initialized
INFO - 2020-03-07 14:18:58 --> Security Class Initialized
DEBUG - 2020-03-07 14:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:18:58 --> Input Class Initialized
INFO - 2020-03-07 14:18:58 --> Language Class Initialized
INFO - 2020-03-07 14:18:58 --> Loader Class Initialized
INFO - 2020-03-07 14:18:58 --> Helper loaded: url_helper
INFO - 2020-03-07 14:18:58 --> Helper loaded: string_helper
INFO - 2020-03-07 14:18:58 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:18:59 --> Controller Class Initialized
INFO - 2020-03-07 14:18:59 --> Model "M_tiket" initialized
INFO - 2020-03-07 14:18:59 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 14:18:59 --> Model "M_pesan" initialized
INFO - 2020-03-07 14:18:59 --> Helper loaded: form_helper
INFO - 2020-03-07 14:18:59 --> Form Validation Class Initialized
INFO - 2020-03-07 14:18:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 14:18:59 --> Final output sent to browser
DEBUG - 2020-03-07 14:18:59 --> Total execution time: 0.2835
INFO - 2020-03-07 14:20:00 --> Config Class Initialized
INFO - 2020-03-07 14:20:00 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:20:00 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:20:00 --> Utf8 Class Initialized
INFO - 2020-03-07 14:20:00 --> URI Class Initialized
DEBUG - 2020-03-07 14:20:00 --> No URI present. Default controller set.
INFO - 2020-03-07 14:20:00 --> Router Class Initialized
INFO - 2020-03-07 14:20:00 --> Output Class Initialized
INFO - 2020-03-07 14:20:00 --> Security Class Initialized
DEBUG - 2020-03-07 14:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:20:00 --> Input Class Initialized
INFO - 2020-03-07 14:20:00 --> Language Class Initialized
INFO - 2020-03-07 14:20:00 --> Loader Class Initialized
INFO - 2020-03-07 14:20:00 --> Helper loaded: url_helper
INFO - 2020-03-07 14:20:00 --> Helper loaded: string_helper
INFO - 2020-03-07 14:20:00 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:20:00 --> Controller Class Initialized
INFO - 2020-03-07 14:20:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:20:00 --> Pagination Class Initialized
INFO - 2020-03-07 14:20:00 --> Model "M_show" initialized
INFO - 2020-03-07 14:20:00 --> Helper loaded: form_helper
INFO - 2020-03-07 14:20:00 --> Form Validation Class Initialized
INFO - 2020-03-07 14:20:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:20:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:20:00 --> Final output sent to browser
DEBUG - 2020-03-07 14:20:00 --> Total execution time: 0.0078
INFO - 2020-03-07 14:20:05 --> Config Class Initialized
INFO - 2020-03-07 14:20:05 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:20:05 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:20:05 --> Utf8 Class Initialized
INFO - 2020-03-07 14:20:05 --> URI Class Initialized
INFO - 2020-03-07 14:20:05 --> Router Class Initialized
INFO - 2020-03-07 14:20:05 --> Output Class Initialized
INFO - 2020-03-07 14:20:05 --> Security Class Initialized
DEBUG - 2020-03-07 14:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:20:05 --> Input Class Initialized
INFO - 2020-03-07 14:20:05 --> Language Class Initialized
INFO - 2020-03-07 14:20:05 --> Loader Class Initialized
INFO - 2020-03-07 14:20:05 --> Helper loaded: url_helper
INFO - 2020-03-07 14:20:05 --> Helper loaded: string_helper
INFO - 2020-03-07 14:20:05 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:20:05 --> Controller Class Initialized
INFO - 2020-03-07 14:20:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:20:05 --> Pagination Class Initialized
INFO - 2020-03-07 14:20:05 --> Model "M_show" initialized
INFO - 2020-03-07 14:20:05 --> Helper loaded: form_helper
INFO - 2020-03-07 14:20:05 --> Form Validation Class Initialized
INFO - 2020-03-07 14:20:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:20:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:20:05 --> Final output sent to browser
DEBUG - 2020-03-07 14:20:05 --> Total execution time: 0.0080
INFO - 2020-03-07 14:20:10 --> Config Class Initialized
INFO - 2020-03-07 14:20:10 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:20:10 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:20:10 --> Utf8 Class Initialized
INFO - 2020-03-07 14:20:10 --> URI Class Initialized
INFO - 2020-03-07 14:20:10 --> Router Class Initialized
INFO - 2020-03-07 14:20:10 --> Output Class Initialized
INFO - 2020-03-07 14:20:10 --> Security Class Initialized
DEBUG - 2020-03-07 14:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:20:10 --> Input Class Initialized
INFO - 2020-03-07 14:20:10 --> Language Class Initialized
INFO - 2020-03-07 14:20:10 --> Loader Class Initialized
INFO - 2020-03-07 14:20:10 --> Helper loaded: url_helper
INFO - 2020-03-07 14:20:10 --> Helper loaded: string_helper
INFO - 2020-03-07 14:20:10 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:20:10 --> Controller Class Initialized
INFO - 2020-03-07 14:20:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:20:10 --> Pagination Class Initialized
INFO - 2020-03-07 14:20:10 --> Model "M_show" initialized
INFO - 2020-03-07 14:20:10 --> Helper loaded: form_helper
INFO - 2020-03-07 14:20:10 --> Form Validation Class Initialized
INFO - 2020-03-07 14:20:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:20:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:20:10 --> Final output sent to browser
DEBUG - 2020-03-07 14:20:10 --> Total execution time: 0.0191
INFO - 2020-03-07 14:20:11 --> Config Class Initialized
INFO - 2020-03-07 14:20:11 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:20:11 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:20:11 --> Utf8 Class Initialized
INFO - 2020-03-07 14:20:11 --> URI Class Initialized
INFO - 2020-03-07 14:20:11 --> Router Class Initialized
INFO - 2020-03-07 14:20:11 --> Output Class Initialized
INFO - 2020-03-07 14:20:11 --> Security Class Initialized
DEBUG - 2020-03-07 14:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:20:11 --> Input Class Initialized
INFO - 2020-03-07 14:20:11 --> Language Class Initialized
INFO - 2020-03-07 14:20:11 --> Loader Class Initialized
INFO - 2020-03-07 14:20:11 --> Helper loaded: url_helper
INFO - 2020-03-07 14:20:11 --> Helper loaded: string_helper
INFO - 2020-03-07 14:20:11 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:20:11 --> Controller Class Initialized
INFO - 2020-03-07 14:20:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:20:11 --> Pagination Class Initialized
INFO - 2020-03-07 14:20:11 --> Model "M_show" initialized
INFO - 2020-03-07 14:20:11 --> Helper loaded: form_helper
INFO - 2020-03-07 14:20:11 --> Form Validation Class Initialized
INFO - 2020-03-07 14:20:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:20:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 14:20:11 --> Final output sent to browser
DEBUG - 2020-03-07 14:20:11 --> Total execution time: 0.0127
INFO - 2020-03-07 14:20:23 --> Config Class Initialized
INFO - 2020-03-07 14:20:23 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:20:23 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:20:23 --> Utf8 Class Initialized
INFO - 2020-03-07 14:20:23 --> URI Class Initialized
INFO - 2020-03-07 14:20:23 --> Router Class Initialized
INFO - 2020-03-07 14:20:23 --> Output Class Initialized
INFO - 2020-03-07 14:20:23 --> Security Class Initialized
DEBUG - 2020-03-07 14:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:20:23 --> Input Class Initialized
INFO - 2020-03-07 14:20:23 --> Language Class Initialized
INFO - 2020-03-07 14:20:23 --> Loader Class Initialized
INFO - 2020-03-07 14:20:23 --> Helper loaded: url_helper
INFO - 2020-03-07 14:20:23 --> Helper loaded: string_helper
INFO - 2020-03-07 14:20:23 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:20:23 --> Controller Class Initialized
INFO - 2020-03-07 14:20:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:20:23 --> Pagination Class Initialized
INFO - 2020-03-07 14:20:23 --> Model "M_show" initialized
INFO - 2020-03-07 14:20:23 --> Helper loaded: form_helper
INFO - 2020-03-07 14:20:23 --> Form Validation Class Initialized
INFO - 2020-03-07 14:20:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:20:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 14:20:23 --> Final output sent to browser
DEBUG - 2020-03-07 14:20:23 --> Total execution time: 0.0081
INFO - 2020-03-07 14:20:25 --> Config Class Initialized
INFO - 2020-03-07 14:20:25 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:20:25 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:20:25 --> Utf8 Class Initialized
INFO - 2020-03-07 14:20:25 --> URI Class Initialized
DEBUG - 2020-03-07 14:20:25 --> No URI present. Default controller set.
INFO - 2020-03-07 14:20:25 --> Router Class Initialized
INFO - 2020-03-07 14:20:25 --> Output Class Initialized
INFO - 2020-03-07 14:20:25 --> Security Class Initialized
DEBUG - 2020-03-07 14:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:20:25 --> Input Class Initialized
INFO - 2020-03-07 14:20:25 --> Language Class Initialized
INFO - 2020-03-07 14:20:25 --> Loader Class Initialized
INFO - 2020-03-07 14:20:25 --> Helper loaded: url_helper
INFO - 2020-03-07 14:20:25 --> Helper loaded: string_helper
INFO - 2020-03-07 14:20:25 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:20:25 --> Controller Class Initialized
INFO - 2020-03-07 14:20:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:20:25 --> Pagination Class Initialized
INFO - 2020-03-07 14:20:25 --> Model "M_show" initialized
INFO - 2020-03-07 14:20:25 --> Helper loaded: form_helper
INFO - 2020-03-07 14:20:25 --> Form Validation Class Initialized
INFO - 2020-03-07 14:20:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:20:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:20:25 --> Final output sent to browser
DEBUG - 2020-03-07 14:20:25 --> Total execution time: 0.0060
INFO - 2020-03-07 14:21:33 --> Config Class Initialized
INFO - 2020-03-07 14:21:33 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:21:33 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:21:33 --> Utf8 Class Initialized
INFO - 2020-03-07 14:21:33 --> URI Class Initialized
DEBUG - 2020-03-07 14:21:33 --> No URI present. Default controller set.
INFO - 2020-03-07 14:21:33 --> Router Class Initialized
INFO - 2020-03-07 14:21:33 --> Output Class Initialized
INFO - 2020-03-07 14:21:33 --> Security Class Initialized
DEBUG - 2020-03-07 14:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:21:33 --> Input Class Initialized
INFO - 2020-03-07 14:21:33 --> Language Class Initialized
INFO - 2020-03-07 14:21:33 --> Loader Class Initialized
INFO - 2020-03-07 14:21:33 --> Helper loaded: url_helper
INFO - 2020-03-07 14:21:33 --> Helper loaded: string_helper
INFO - 2020-03-07 14:21:33 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:21:33 --> Controller Class Initialized
INFO - 2020-03-07 14:21:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:21:33 --> Pagination Class Initialized
INFO - 2020-03-07 14:21:33 --> Model "M_show" initialized
INFO - 2020-03-07 14:21:33 --> Helper loaded: form_helper
INFO - 2020-03-07 14:21:33 --> Form Validation Class Initialized
INFO - 2020-03-07 14:21:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:21:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:21:33 --> Final output sent to browser
DEBUG - 2020-03-07 14:21:33 --> Total execution time: 0.0054
INFO - 2020-03-07 14:21:47 --> Config Class Initialized
INFO - 2020-03-07 14:21:47 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:21:47 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:21:47 --> Utf8 Class Initialized
INFO - 2020-03-07 14:21:47 --> URI Class Initialized
INFO - 2020-03-07 14:21:47 --> Router Class Initialized
INFO - 2020-03-07 14:21:47 --> Output Class Initialized
INFO - 2020-03-07 14:21:47 --> Security Class Initialized
DEBUG - 2020-03-07 14:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:21:47 --> Input Class Initialized
INFO - 2020-03-07 14:21:47 --> Language Class Initialized
INFO - 2020-03-07 14:21:47 --> Loader Class Initialized
INFO - 2020-03-07 14:21:47 --> Helper loaded: url_helper
INFO - 2020-03-07 14:21:47 --> Helper loaded: string_helper
INFO - 2020-03-07 14:21:47 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:21:47 --> Controller Class Initialized
INFO - 2020-03-07 14:21:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:21:47 --> Pagination Class Initialized
INFO - 2020-03-07 14:21:47 --> Model "M_show" initialized
INFO - 2020-03-07 14:21:47 --> Helper loaded: form_helper
INFO - 2020-03-07 14:21:47 --> Form Validation Class Initialized
INFO - 2020-03-07 14:21:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:21:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 14:21:47 --> Final output sent to browser
DEBUG - 2020-03-07 14:21:47 --> Total execution time: 0.0069
INFO - 2020-03-07 14:21:52 --> Config Class Initialized
INFO - 2020-03-07 14:21:52 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:21:52 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:21:52 --> Utf8 Class Initialized
INFO - 2020-03-07 14:21:52 --> URI Class Initialized
INFO - 2020-03-07 14:21:52 --> Router Class Initialized
INFO - 2020-03-07 14:21:52 --> Output Class Initialized
INFO - 2020-03-07 14:21:52 --> Security Class Initialized
DEBUG - 2020-03-07 14:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:21:52 --> Input Class Initialized
INFO - 2020-03-07 14:21:52 --> Language Class Initialized
INFO - 2020-03-07 14:21:52 --> Loader Class Initialized
INFO - 2020-03-07 14:21:52 --> Helper loaded: url_helper
INFO - 2020-03-07 14:21:52 --> Helper loaded: string_helper
INFO - 2020-03-07 14:21:52 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:21:52 --> Controller Class Initialized
INFO - 2020-03-07 14:21:52 --> Model "M_tiket" initialized
INFO - 2020-03-07 14:21:52 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 14:21:52 --> Model "M_pesan" initialized
INFO - 2020-03-07 14:21:52 --> Helper loaded: form_helper
INFO - 2020-03-07 14:21:52 --> Form Validation Class Initialized
INFO - 2020-03-07 14:21:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 14:21:52 --> Final output sent to browser
DEBUG - 2020-03-07 14:21:52 --> Total execution time: 0.0077
INFO - 2020-03-07 14:22:58 --> Config Class Initialized
INFO - 2020-03-07 14:22:58 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:22:58 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:22:58 --> Utf8 Class Initialized
INFO - 2020-03-07 14:22:58 --> URI Class Initialized
DEBUG - 2020-03-07 14:22:58 --> No URI present. Default controller set.
INFO - 2020-03-07 14:22:58 --> Router Class Initialized
INFO - 2020-03-07 14:22:58 --> Output Class Initialized
INFO - 2020-03-07 14:22:58 --> Security Class Initialized
DEBUG - 2020-03-07 14:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:22:58 --> Input Class Initialized
INFO - 2020-03-07 14:22:58 --> Language Class Initialized
INFO - 2020-03-07 14:22:58 --> Loader Class Initialized
INFO - 2020-03-07 14:22:58 --> Helper loaded: url_helper
INFO - 2020-03-07 14:22:58 --> Helper loaded: string_helper
INFO - 2020-03-07 14:22:58 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:22:58 --> Controller Class Initialized
INFO - 2020-03-07 14:22:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:22:58 --> Pagination Class Initialized
INFO - 2020-03-07 14:22:58 --> Model "M_show" initialized
INFO - 2020-03-07 14:22:58 --> Helper loaded: form_helper
INFO - 2020-03-07 14:22:58 --> Form Validation Class Initialized
INFO - 2020-03-07 14:22:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:22:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:22:58 --> Final output sent to browser
DEBUG - 2020-03-07 14:22:58 --> Total execution time: 0.0053
INFO - 2020-03-07 14:23:06 --> Config Class Initialized
INFO - 2020-03-07 14:23:06 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:23:06 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:23:06 --> Utf8 Class Initialized
INFO - 2020-03-07 14:23:06 --> URI Class Initialized
DEBUG - 2020-03-07 14:23:06 --> No URI present. Default controller set.
INFO - 2020-03-07 14:23:06 --> Router Class Initialized
INFO - 2020-03-07 14:23:06 --> Output Class Initialized
INFO - 2020-03-07 14:23:06 --> Security Class Initialized
DEBUG - 2020-03-07 14:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:23:06 --> Input Class Initialized
INFO - 2020-03-07 14:23:06 --> Language Class Initialized
INFO - 2020-03-07 14:23:06 --> Loader Class Initialized
INFO - 2020-03-07 14:23:06 --> Helper loaded: url_helper
INFO - 2020-03-07 14:23:06 --> Helper loaded: string_helper
INFO - 2020-03-07 14:23:06 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:23:06 --> Controller Class Initialized
INFO - 2020-03-07 14:23:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:23:06 --> Pagination Class Initialized
INFO - 2020-03-07 14:23:06 --> Model "M_show" initialized
INFO - 2020-03-07 14:23:06 --> Helper loaded: form_helper
INFO - 2020-03-07 14:23:06 --> Form Validation Class Initialized
INFO - 2020-03-07 14:23:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:23:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:23:06 --> Final output sent to browser
DEBUG - 2020-03-07 14:23:06 --> Total execution time: 0.0065
INFO - 2020-03-07 14:23:21 --> Config Class Initialized
INFO - 2020-03-07 14:23:21 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:23:21 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:23:21 --> Utf8 Class Initialized
INFO - 2020-03-07 14:23:21 --> URI Class Initialized
INFO - 2020-03-07 14:23:21 --> Router Class Initialized
INFO - 2020-03-07 14:23:21 --> Output Class Initialized
INFO - 2020-03-07 14:23:21 --> Security Class Initialized
DEBUG - 2020-03-07 14:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:23:21 --> Input Class Initialized
INFO - 2020-03-07 14:23:21 --> Language Class Initialized
INFO - 2020-03-07 14:23:21 --> Loader Class Initialized
INFO - 2020-03-07 14:23:21 --> Helper loaded: url_helper
INFO - 2020-03-07 14:23:21 --> Helper loaded: string_helper
INFO - 2020-03-07 14:23:21 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:23:21 --> Controller Class Initialized
INFO - 2020-03-07 14:23:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:23:21 --> Pagination Class Initialized
INFO - 2020-03-07 14:23:21 --> Model "M_show" initialized
INFO - 2020-03-07 14:23:21 --> Helper loaded: form_helper
INFO - 2020-03-07 14:23:21 --> Form Validation Class Initialized
INFO - 2020-03-07 14:23:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:23:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 14:23:21 --> Final output sent to browser
DEBUG - 2020-03-07 14:23:21 --> Total execution time: 0.0073
INFO - 2020-03-07 14:23:26 --> Config Class Initialized
INFO - 2020-03-07 14:23:26 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:23:26 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:23:26 --> Utf8 Class Initialized
INFO - 2020-03-07 14:23:26 --> URI Class Initialized
INFO - 2020-03-07 14:23:26 --> Router Class Initialized
INFO - 2020-03-07 14:23:26 --> Output Class Initialized
INFO - 2020-03-07 14:23:26 --> Security Class Initialized
DEBUG - 2020-03-07 14:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:23:26 --> Input Class Initialized
INFO - 2020-03-07 14:23:26 --> Language Class Initialized
INFO - 2020-03-07 14:23:26 --> Loader Class Initialized
INFO - 2020-03-07 14:23:26 --> Helper loaded: url_helper
INFO - 2020-03-07 14:23:26 --> Helper loaded: string_helper
INFO - 2020-03-07 14:23:26 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:23:26 --> Controller Class Initialized
INFO - 2020-03-07 14:23:26 --> Model "M_tiket" initialized
INFO - 2020-03-07 14:23:26 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 14:23:26 --> Model "M_pesan" initialized
INFO - 2020-03-07 14:23:26 --> Helper loaded: form_helper
INFO - 2020-03-07 14:23:26 --> Form Validation Class Initialized
INFO - 2020-03-07 14:23:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 14:23:26 --> Final output sent to browser
DEBUG - 2020-03-07 14:23:26 --> Total execution time: 0.0073
INFO - 2020-03-07 14:23:56 --> Config Class Initialized
INFO - 2020-03-07 14:23:56 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:23:56 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:23:56 --> Utf8 Class Initialized
INFO - 2020-03-07 14:23:56 --> URI Class Initialized
INFO - 2020-03-07 14:23:56 --> Router Class Initialized
INFO - 2020-03-07 14:23:56 --> Output Class Initialized
INFO - 2020-03-07 14:23:56 --> Security Class Initialized
DEBUG - 2020-03-07 14:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:23:56 --> Input Class Initialized
INFO - 2020-03-07 14:23:56 --> Language Class Initialized
INFO - 2020-03-07 14:23:56 --> Loader Class Initialized
INFO - 2020-03-07 14:23:56 --> Helper loaded: url_helper
INFO - 2020-03-07 14:23:56 --> Helper loaded: string_helper
INFO - 2020-03-07 14:23:56 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:23:56 --> Controller Class Initialized
INFO - 2020-03-07 14:23:56 --> Model "M_tiket" initialized
INFO - 2020-03-07 14:23:56 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 14:23:56 --> Model "M_pesan" initialized
INFO - 2020-03-07 14:23:56 --> Helper loaded: form_helper
INFO - 2020-03-07 14:23:56 --> Form Validation Class Initialized
INFO - 2020-03-07 14:23:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 14:23:56 --> Final output sent to browser
DEBUG - 2020-03-07 14:23:56 --> Total execution time: 0.0089
INFO - 2020-03-07 14:24:12 --> Config Class Initialized
INFO - 2020-03-07 14:24:12 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:24:12 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:24:12 --> Utf8 Class Initialized
INFO - 2020-03-07 14:24:12 --> URI Class Initialized
INFO - 2020-03-07 14:24:12 --> Router Class Initialized
INFO - 2020-03-07 14:24:12 --> Output Class Initialized
INFO - 2020-03-07 14:24:12 --> Security Class Initialized
DEBUG - 2020-03-07 14:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:24:12 --> Input Class Initialized
INFO - 2020-03-07 14:24:12 --> Language Class Initialized
INFO - 2020-03-07 14:24:12 --> Loader Class Initialized
INFO - 2020-03-07 14:24:12 --> Helper loaded: url_helper
INFO - 2020-03-07 14:24:12 --> Helper loaded: string_helper
INFO - 2020-03-07 14:24:12 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:24:12 --> Controller Class Initialized
INFO - 2020-03-07 14:24:12 --> Model "M_tiket" initialized
INFO - 2020-03-07 14:24:12 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 14:24:12 --> Model "M_pesan" initialized
INFO - 2020-03-07 14:24:12 --> Helper loaded: form_helper
INFO - 2020-03-07 14:24:12 --> Form Validation Class Initialized
INFO - 2020-03-07 14:24:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 14:24:12 --> Final output sent to browser
DEBUG - 2020-03-07 14:24:12 --> Total execution time: 0.0087
INFO - 2020-03-07 14:24:15 --> Config Class Initialized
INFO - 2020-03-07 14:24:15 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:24:15 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:24:15 --> Utf8 Class Initialized
INFO - 2020-03-07 14:24:15 --> URI Class Initialized
INFO - 2020-03-07 14:24:15 --> Router Class Initialized
INFO - 2020-03-07 14:24:15 --> Output Class Initialized
INFO - 2020-03-07 14:24:15 --> Security Class Initialized
DEBUG - 2020-03-07 14:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:24:15 --> Input Class Initialized
INFO - 2020-03-07 14:24:15 --> Language Class Initialized
INFO - 2020-03-07 14:24:15 --> Loader Class Initialized
INFO - 2020-03-07 14:24:15 --> Helper loaded: url_helper
INFO - 2020-03-07 14:24:15 --> Helper loaded: string_helper
INFO - 2020-03-07 14:24:15 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:24:15 --> Controller Class Initialized
INFO - 2020-03-07 14:24:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:24:15 --> Pagination Class Initialized
INFO - 2020-03-07 14:24:15 --> Model "M_show" initialized
INFO - 2020-03-07 14:24:15 --> Helper loaded: form_helper
INFO - 2020-03-07 14:24:15 --> Form Validation Class Initialized
INFO - 2020-03-07 14:24:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:24:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 14:24:15 --> Final output sent to browser
DEBUG - 2020-03-07 14:24:15 --> Total execution time: 0.0072
INFO - 2020-03-07 14:24:19 --> Config Class Initialized
INFO - 2020-03-07 14:24:19 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:24:19 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:24:19 --> Utf8 Class Initialized
INFO - 2020-03-07 14:24:19 --> URI Class Initialized
DEBUG - 2020-03-07 14:24:19 --> No URI present. Default controller set.
INFO - 2020-03-07 14:24:19 --> Router Class Initialized
INFO - 2020-03-07 14:24:19 --> Output Class Initialized
INFO - 2020-03-07 14:24:19 --> Security Class Initialized
DEBUG - 2020-03-07 14:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:24:19 --> Input Class Initialized
INFO - 2020-03-07 14:24:19 --> Language Class Initialized
INFO - 2020-03-07 14:24:19 --> Loader Class Initialized
INFO - 2020-03-07 14:24:19 --> Helper loaded: url_helper
INFO - 2020-03-07 14:24:19 --> Helper loaded: string_helper
INFO - 2020-03-07 14:24:19 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:24:19 --> Controller Class Initialized
INFO - 2020-03-07 14:24:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:24:19 --> Pagination Class Initialized
INFO - 2020-03-07 14:24:19 --> Model "M_show" initialized
INFO - 2020-03-07 14:24:19 --> Helper loaded: form_helper
INFO - 2020-03-07 14:24:19 --> Form Validation Class Initialized
INFO - 2020-03-07 14:24:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:24:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:24:19 --> Final output sent to browser
DEBUG - 2020-03-07 14:24:19 --> Total execution time: 0.0112
INFO - 2020-03-07 14:24:40 --> Config Class Initialized
INFO - 2020-03-07 14:24:40 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:24:40 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:24:40 --> Utf8 Class Initialized
INFO - 2020-03-07 14:24:40 --> URI Class Initialized
DEBUG - 2020-03-07 14:24:40 --> No URI present. Default controller set.
INFO - 2020-03-07 14:24:40 --> Router Class Initialized
INFO - 2020-03-07 14:24:40 --> Output Class Initialized
INFO - 2020-03-07 14:24:40 --> Security Class Initialized
DEBUG - 2020-03-07 14:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:24:40 --> Input Class Initialized
INFO - 2020-03-07 14:24:40 --> Language Class Initialized
INFO - 2020-03-07 14:24:40 --> Loader Class Initialized
INFO - 2020-03-07 14:24:40 --> Helper loaded: url_helper
INFO - 2020-03-07 14:24:40 --> Helper loaded: string_helper
INFO - 2020-03-07 14:24:40 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:24:40 --> Controller Class Initialized
INFO - 2020-03-07 14:24:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:24:40 --> Pagination Class Initialized
INFO - 2020-03-07 14:24:40 --> Model "M_show" initialized
INFO - 2020-03-07 14:24:40 --> Helper loaded: form_helper
INFO - 2020-03-07 14:24:40 --> Form Validation Class Initialized
INFO - 2020-03-07 14:24:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:24:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:24:40 --> Final output sent to browser
DEBUG - 2020-03-07 14:24:40 --> Total execution time: 0.0221
INFO - 2020-03-07 14:28:46 --> Config Class Initialized
INFO - 2020-03-07 14:28:46 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:28:46 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:28:46 --> Utf8 Class Initialized
INFO - 2020-03-07 14:28:46 --> URI Class Initialized
DEBUG - 2020-03-07 14:28:46 --> No URI present. Default controller set.
INFO - 2020-03-07 14:28:46 --> Router Class Initialized
INFO - 2020-03-07 14:28:46 --> Output Class Initialized
INFO - 2020-03-07 14:28:46 --> Security Class Initialized
DEBUG - 2020-03-07 14:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:28:46 --> Input Class Initialized
INFO - 2020-03-07 14:28:46 --> Language Class Initialized
INFO - 2020-03-07 14:28:46 --> Loader Class Initialized
INFO - 2020-03-07 14:28:46 --> Helper loaded: url_helper
INFO - 2020-03-07 14:28:46 --> Helper loaded: string_helper
INFO - 2020-03-07 14:28:46 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:28:46 --> Controller Class Initialized
INFO - 2020-03-07 14:28:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:28:46 --> Pagination Class Initialized
INFO - 2020-03-07 14:28:46 --> Model "M_show" initialized
INFO - 2020-03-07 14:28:46 --> Helper loaded: form_helper
INFO - 2020-03-07 14:28:46 --> Form Validation Class Initialized
INFO - 2020-03-07 14:28:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:28:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:28:46 --> Final output sent to browser
DEBUG - 2020-03-07 14:28:46 --> Total execution time: 0.0476
INFO - 2020-03-07 14:28:55 --> Config Class Initialized
INFO - 2020-03-07 14:28:55 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:28:55 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:28:55 --> Utf8 Class Initialized
INFO - 2020-03-07 14:28:55 --> URI Class Initialized
INFO - 2020-03-07 14:28:55 --> Router Class Initialized
INFO - 2020-03-07 14:28:55 --> Output Class Initialized
INFO - 2020-03-07 14:28:55 --> Security Class Initialized
DEBUG - 2020-03-07 14:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:28:55 --> Input Class Initialized
INFO - 2020-03-07 14:28:55 --> Language Class Initialized
INFO - 2020-03-07 14:28:55 --> Loader Class Initialized
INFO - 2020-03-07 14:28:55 --> Helper loaded: url_helper
INFO - 2020-03-07 14:28:55 --> Helper loaded: string_helper
INFO - 2020-03-07 14:28:55 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:28:55 --> Controller Class Initialized
INFO - 2020-03-07 14:28:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:28:55 --> Pagination Class Initialized
INFO - 2020-03-07 14:28:55 --> Model "M_show" initialized
INFO - 2020-03-07 14:28:55 --> Helper loaded: form_helper
INFO - 2020-03-07 14:28:55 --> Form Validation Class Initialized
INFO - 2020-03-07 14:28:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:28:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 14:28:55 --> Final output sent to browser
DEBUG - 2020-03-07 14:28:55 --> Total execution time: 0.0091
INFO - 2020-03-07 14:28:59 --> Config Class Initialized
INFO - 2020-03-07 14:28:59 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:28:59 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:28:59 --> Utf8 Class Initialized
INFO - 2020-03-07 14:28:59 --> URI Class Initialized
INFO - 2020-03-07 14:28:59 --> Router Class Initialized
INFO - 2020-03-07 14:28:59 --> Output Class Initialized
INFO - 2020-03-07 14:28:59 --> Security Class Initialized
DEBUG - 2020-03-07 14:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:28:59 --> Input Class Initialized
INFO - 2020-03-07 14:28:59 --> Language Class Initialized
INFO - 2020-03-07 14:28:59 --> Loader Class Initialized
INFO - 2020-03-07 14:28:59 --> Helper loaded: url_helper
INFO - 2020-03-07 14:28:59 --> Helper loaded: string_helper
INFO - 2020-03-07 14:28:59 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:28:59 --> Controller Class Initialized
INFO - 2020-03-07 14:28:59 --> Model "M_tiket" initialized
INFO - 2020-03-07 14:28:59 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 14:28:59 --> Model "M_pesan" initialized
INFO - 2020-03-07 14:28:59 --> Helper loaded: form_helper
INFO - 2020-03-07 14:28:59 --> Form Validation Class Initialized
INFO - 2020-03-07 14:28:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 14:28:59 --> Final output sent to browser
DEBUG - 2020-03-07 14:28:59 --> Total execution time: 0.0149
INFO - 2020-03-07 14:29:55 --> Config Class Initialized
INFO - 2020-03-07 14:29:55 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:29:55 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:29:55 --> Utf8 Class Initialized
INFO - 2020-03-07 14:29:55 --> URI Class Initialized
INFO - 2020-03-07 14:29:55 --> Router Class Initialized
INFO - 2020-03-07 14:29:55 --> Output Class Initialized
INFO - 2020-03-07 14:29:55 --> Security Class Initialized
DEBUG - 2020-03-07 14:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:29:55 --> Input Class Initialized
INFO - 2020-03-07 14:29:55 --> Language Class Initialized
INFO - 2020-03-07 14:29:55 --> Loader Class Initialized
INFO - 2020-03-07 14:29:55 --> Helper loaded: url_helper
INFO - 2020-03-07 14:29:55 --> Helper loaded: string_helper
INFO - 2020-03-07 14:29:55 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:29:55 --> Controller Class Initialized
INFO - 2020-03-07 14:29:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:29:55 --> Pagination Class Initialized
INFO - 2020-03-07 14:29:55 --> Model "M_show" initialized
INFO - 2020-03-07 14:29:55 --> Helper loaded: form_helper
INFO - 2020-03-07 14:29:55 --> Form Validation Class Initialized
INFO - 2020-03-07 14:29:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:29:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 14:29:55 --> Final output sent to browser
DEBUG - 2020-03-07 14:29:55 --> Total execution time: 0.0063
INFO - 2020-03-07 14:35:31 --> Config Class Initialized
INFO - 2020-03-07 14:35:31 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:35:31 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:35:31 --> Utf8 Class Initialized
INFO - 2020-03-07 14:35:31 --> URI Class Initialized
DEBUG - 2020-03-07 14:35:31 --> No URI present. Default controller set.
INFO - 2020-03-07 14:35:31 --> Router Class Initialized
INFO - 2020-03-07 14:35:31 --> Output Class Initialized
INFO - 2020-03-07 14:35:31 --> Security Class Initialized
DEBUG - 2020-03-07 14:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:35:31 --> Input Class Initialized
INFO - 2020-03-07 14:35:31 --> Language Class Initialized
INFO - 2020-03-07 14:35:31 --> Loader Class Initialized
INFO - 2020-03-07 14:35:31 --> Helper loaded: url_helper
INFO - 2020-03-07 14:35:31 --> Helper loaded: string_helper
INFO - 2020-03-07 14:35:31 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:35:31 --> Controller Class Initialized
INFO - 2020-03-07 14:35:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:35:31 --> Pagination Class Initialized
INFO - 2020-03-07 14:35:31 --> Model "M_show" initialized
INFO - 2020-03-07 14:35:31 --> Helper loaded: form_helper
INFO - 2020-03-07 14:35:31 --> Form Validation Class Initialized
INFO - 2020-03-07 14:35:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:35:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:35:31 --> Final output sent to browser
DEBUG - 2020-03-07 14:35:31 --> Total execution time: 0.0413
INFO - 2020-03-07 14:35:43 --> Config Class Initialized
INFO - 2020-03-07 14:35:43 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:35:43 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:35:43 --> Utf8 Class Initialized
INFO - 2020-03-07 14:35:43 --> URI Class Initialized
INFO - 2020-03-07 14:35:43 --> Router Class Initialized
INFO - 2020-03-07 14:35:43 --> Output Class Initialized
INFO - 2020-03-07 14:35:43 --> Security Class Initialized
DEBUG - 2020-03-07 14:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:35:43 --> Input Class Initialized
INFO - 2020-03-07 14:35:43 --> Language Class Initialized
INFO - 2020-03-07 14:35:43 --> Loader Class Initialized
INFO - 2020-03-07 14:35:43 --> Helper loaded: url_helper
INFO - 2020-03-07 14:35:43 --> Helper loaded: string_helper
INFO - 2020-03-07 14:35:43 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:35:43 --> Controller Class Initialized
INFO - 2020-03-07 14:35:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:35:43 --> Pagination Class Initialized
INFO - 2020-03-07 14:35:43 --> Model "M_show" initialized
INFO - 2020-03-07 14:35:43 --> Helper loaded: form_helper
INFO - 2020-03-07 14:35:43 --> Form Validation Class Initialized
INFO - 2020-03-07 14:35:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:35:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 14:35:43 --> Final output sent to browser
DEBUG - 2020-03-07 14:35:43 --> Total execution time: 0.0081
INFO - 2020-03-07 14:35:58 --> Config Class Initialized
INFO - 2020-03-07 14:35:58 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:35:58 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:35:58 --> Utf8 Class Initialized
INFO - 2020-03-07 14:35:58 --> URI Class Initialized
INFO - 2020-03-07 14:35:58 --> Router Class Initialized
INFO - 2020-03-07 14:35:58 --> Output Class Initialized
INFO - 2020-03-07 14:35:58 --> Security Class Initialized
DEBUG - 2020-03-07 14:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:35:58 --> Input Class Initialized
INFO - 2020-03-07 14:35:58 --> Language Class Initialized
INFO - 2020-03-07 14:35:58 --> Loader Class Initialized
INFO - 2020-03-07 14:35:58 --> Helper loaded: url_helper
INFO - 2020-03-07 14:35:58 --> Helper loaded: string_helper
INFO - 2020-03-07 14:35:58 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:35:58 --> Controller Class Initialized
INFO - 2020-03-07 14:35:58 --> Model "M_tiket" initialized
INFO - 2020-03-07 14:35:58 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 14:35:58 --> Model "M_pesan" initialized
INFO - 2020-03-07 14:35:58 --> Helper loaded: form_helper
INFO - 2020-03-07 14:35:58 --> Form Validation Class Initialized
INFO - 2020-03-07 14:35:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 14:35:58 --> Final output sent to browser
DEBUG - 2020-03-07 14:35:58 --> Total execution time: 0.0116
INFO - 2020-03-07 14:36:06 --> Config Class Initialized
INFO - 2020-03-07 14:36:06 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:36:06 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:36:06 --> Utf8 Class Initialized
INFO - 2020-03-07 14:36:06 --> URI Class Initialized
INFO - 2020-03-07 14:36:06 --> Router Class Initialized
INFO - 2020-03-07 14:36:06 --> Output Class Initialized
INFO - 2020-03-07 14:36:06 --> Security Class Initialized
DEBUG - 2020-03-07 14:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:36:06 --> Input Class Initialized
INFO - 2020-03-07 14:36:06 --> Language Class Initialized
INFO - 2020-03-07 14:36:06 --> Loader Class Initialized
INFO - 2020-03-07 14:36:06 --> Helper loaded: url_helper
INFO - 2020-03-07 14:36:06 --> Helper loaded: string_helper
INFO - 2020-03-07 14:36:06 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:36:06 --> Controller Class Initialized
INFO - 2020-03-07 14:36:06 --> Model "M_tiket" initialized
INFO - 2020-03-07 14:36:06 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 14:36:06 --> Model "M_pesan" initialized
INFO - 2020-03-07 14:36:06 --> Helper loaded: form_helper
INFO - 2020-03-07 14:36:06 --> Form Validation Class Initialized
INFO - 2020-03-07 14:36:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 14:36:06 --> Final output sent to browser
DEBUG - 2020-03-07 14:36:06 --> Total execution time: 0.0119
INFO - 2020-03-07 14:36:45 --> Config Class Initialized
INFO - 2020-03-07 14:36:45 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:36:45 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:36:45 --> Utf8 Class Initialized
INFO - 2020-03-07 14:36:45 --> URI Class Initialized
INFO - 2020-03-07 14:36:45 --> Router Class Initialized
INFO - 2020-03-07 14:36:45 --> Output Class Initialized
INFO - 2020-03-07 14:36:45 --> Security Class Initialized
DEBUG - 2020-03-07 14:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:36:45 --> Input Class Initialized
INFO - 2020-03-07 14:36:45 --> Language Class Initialized
INFO - 2020-03-07 14:36:45 --> Loader Class Initialized
INFO - 2020-03-07 14:36:45 --> Helper loaded: url_helper
INFO - 2020-03-07 14:36:45 --> Helper loaded: string_helper
INFO - 2020-03-07 14:36:45 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:36:46 --> Controller Class Initialized
INFO - 2020-03-07 14:36:46 --> Model "M_tiket" initialized
INFO - 2020-03-07 14:36:46 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 14:36:46 --> Model "M_pesan" initialized
INFO - 2020-03-07 14:36:46 --> Helper loaded: form_helper
INFO - 2020-03-07 14:36:46 --> Form Validation Class Initialized
DEBUG - 2020-03-07 14:36:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-07 14:36:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-07 14:36:46 --> Final output sent to browser
DEBUG - 2020-03-07 14:36:46 --> Total execution time: 0.1235
INFO - 2020-03-07 14:36:52 --> Config Class Initialized
INFO - 2020-03-07 14:36:52 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:36:52 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:36:52 --> Utf8 Class Initialized
INFO - 2020-03-07 14:36:52 --> URI Class Initialized
INFO - 2020-03-07 14:36:52 --> Router Class Initialized
INFO - 2020-03-07 14:36:52 --> Output Class Initialized
INFO - 2020-03-07 14:36:52 --> Security Class Initialized
DEBUG - 2020-03-07 14:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:36:52 --> Input Class Initialized
INFO - 2020-03-07 14:36:52 --> Language Class Initialized
INFO - 2020-03-07 14:36:52 --> Loader Class Initialized
INFO - 2020-03-07 14:36:52 --> Helper loaded: url_helper
INFO - 2020-03-07 14:36:52 --> Helper loaded: string_helper
INFO - 2020-03-07 14:36:52 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:36:52 --> Controller Class Initialized
INFO - 2020-03-07 14:36:52 --> Model "M_tiket" initialized
INFO - 2020-03-07 14:36:52 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 14:36:52 --> Model "M_pesan" initialized
INFO - 2020-03-07 14:36:52 --> Helper loaded: form_helper
INFO - 2020-03-07 14:36:52 --> Form Validation Class Initialized
INFO - 2020-03-07 14:36:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 14:36:52 --> Final output sent to browser
DEBUG - 2020-03-07 14:36:52 --> Total execution time: 0.0071
INFO - 2020-03-07 14:37:03 --> Config Class Initialized
INFO - 2020-03-07 14:37:03 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:37:03 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:37:03 --> Utf8 Class Initialized
INFO - 2020-03-07 14:37:03 --> URI Class Initialized
INFO - 2020-03-07 14:37:03 --> Router Class Initialized
INFO - 2020-03-07 14:37:03 --> Output Class Initialized
INFO - 2020-03-07 14:37:03 --> Security Class Initialized
DEBUG - 2020-03-07 14:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:37:03 --> Input Class Initialized
INFO - 2020-03-07 14:37:03 --> Language Class Initialized
INFO - 2020-03-07 14:37:03 --> Loader Class Initialized
INFO - 2020-03-07 14:37:03 --> Helper loaded: url_helper
INFO - 2020-03-07 14:37:03 --> Helper loaded: string_helper
INFO - 2020-03-07 14:37:03 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:37:03 --> Controller Class Initialized
INFO - 2020-03-07 14:37:03 --> Model "M_tiket" initialized
INFO - 2020-03-07 14:37:03 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 14:37:03 --> Model "M_pesan" initialized
INFO - 2020-03-07 14:37:03 --> Helper loaded: form_helper
INFO - 2020-03-07 14:37:03 --> Form Validation Class Initialized
DEBUG - 2020-03-07 14:37:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-07 14:37:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-07 21:37:03 --> Final output sent to browser
DEBUG - 2020-03-07 21:37:03 --> Total execution time: 0.1724
INFO - 2020-03-07 14:37:05 --> Config Class Initialized
INFO - 2020-03-07 14:37:05 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:37:05 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:37:05 --> Utf8 Class Initialized
INFO - 2020-03-07 14:37:05 --> URI Class Initialized
INFO - 2020-03-07 14:37:05 --> Router Class Initialized
INFO - 2020-03-07 14:37:05 --> Output Class Initialized
INFO - 2020-03-07 14:37:05 --> Security Class Initialized
DEBUG - 2020-03-07 14:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:37:05 --> Input Class Initialized
INFO - 2020-03-07 14:37:05 --> Language Class Initialized
INFO - 2020-03-07 14:37:05 --> Loader Class Initialized
INFO - 2020-03-07 14:37:05 --> Helper loaded: url_helper
INFO - 2020-03-07 14:37:05 --> Helper loaded: string_helper
INFO - 2020-03-07 14:37:05 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:37:05 --> Controller Class Initialized
INFO - 2020-03-07 14:37:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:37:05 --> Pagination Class Initialized
INFO - 2020-03-07 14:37:05 --> Model "M_show" initialized
INFO - 2020-03-07 14:37:05 --> Helper loaded: form_helper
INFO - 2020-03-07 14:37:05 --> Form Validation Class Initialized
INFO - 2020-03-07 14:37:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:37:05 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:37:05 --> Final output sent to browser
DEBUG - 2020-03-07 14:37:05 --> Total execution time: 0.0057
INFO - 2020-03-07 14:37:06 --> Config Class Initialized
INFO - 2020-03-07 14:37:06 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:37:06 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:37:06 --> Utf8 Class Initialized
INFO - 2020-03-07 14:37:06 --> URI Class Initialized
DEBUG - 2020-03-07 14:37:06 --> No URI present. Default controller set.
INFO - 2020-03-07 14:37:06 --> Router Class Initialized
INFO - 2020-03-07 14:37:06 --> Output Class Initialized
INFO - 2020-03-07 14:37:06 --> Security Class Initialized
DEBUG - 2020-03-07 14:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:37:06 --> Input Class Initialized
INFO - 2020-03-07 14:37:06 --> Language Class Initialized
INFO - 2020-03-07 14:37:06 --> Loader Class Initialized
INFO - 2020-03-07 14:37:06 --> Helper loaded: url_helper
INFO - 2020-03-07 14:37:06 --> Helper loaded: string_helper
INFO - 2020-03-07 14:37:06 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:37:06 --> Controller Class Initialized
INFO - 2020-03-07 14:37:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:37:06 --> Pagination Class Initialized
INFO - 2020-03-07 14:37:06 --> Model "M_show" initialized
INFO - 2020-03-07 14:37:06 --> Helper loaded: form_helper
INFO - 2020-03-07 14:37:06 --> Form Validation Class Initialized
INFO - 2020-03-07 14:37:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:37:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:37:06 --> Final output sent to browser
DEBUG - 2020-03-07 14:37:06 --> Total execution time: 0.0052
INFO - 2020-03-07 14:40:32 --> Config Class Initialized
INFO - 2020-03-07 14:40:32 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:40:32 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:40:32 --> Utf8 Class Initialized
INFO - 2020-03-07 14:40:32 --> URI Class Initialized
DEBUG - 2020-03-07 14:40:32 --> No URI present. Default controller set.
INFO - 2020-03-07 14:40:32 --> Router Class Initialized
INFO - 2020-03-07 14:40:32 --> Output Class Initialized
INFO - 2020-03-07 14:40:32 --> Security Class Initialized
DEBUG - 2020-03-07 14:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:40:32 --> Input Class Initialized
INFO - 2020-03-07 14:40:32 --> Language Class Initialized
INFO - 2020-03-07 14:40:32 --> Loader Class Initialized
INFO - 2020-03-07 14:40:32 --> Helper loaded: url_helper
INFO - 2020-03-07 14:40:32 --> Helper loaded: string_helper
INFO - 2020-03-07 14:40:32 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:40:32 --> Controller Class Initialized
INFO - 2020-03-07 14:40:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:40:32 --> Pagination Class Initialized
INFO - 2020-03-07 14:40:32 --> Model "M_show" initialized
INFO - 2020-03-07 14:40:32 --> Helper loaded: form_helper
INFO - 2020-03-07 14:40:32 --> Form Validation Class Initialized
INFO - 2020-03-07 14:40:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:40:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:40:32 --> Final output sent to browser
DEBUG - 2020-03-07 14:40:32 --> Total execution time: 0.2367
INFO - 2020-03-07 14:40:33 --> Config Class Initialized
INFO - 2020-03-07 14:40:33 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:40:33 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:40:33 --> Utf8 Class Initialized
INFO - 2020-03-07 14:40:33 --> URI Class Initialized
DEBUG - 2020-03-07 14:40:33 --> No URI present. Default controller set.
INFO - 2020-03-07 14:40:33 --> Router Class Initialized
INFO - 2020-03-07 14:40:33 --> Output Class Initialized
INFO - 2020-03-07 14:40:33 --> Security Class Initialized
DEBUG - 2020-03-07 14:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:40:33 --> Input Class Initialized
INFO - 2020-03-07 14:40:33 --> Language Class Initialized
INFO - 2020-03-07 14:40:33 --> Loader Class Initialized
INFO - 2020-03-07 14:40:33 --> Helper loaded: url_helper
INFO - 2020-03-07 14:40:33 --> Helper loaded: string_helper
INFO - 2020-03-07 14:40:33 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:40:33 --> Controller Class Initialized
INFO - 2020-03-07 14:40:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:40:33 --> Pagination Class Initialized
INFO - 2020-03-07 14:40:33 --> Model "M_show" initialized
INFO - 2020-03-07 14:40:33 --> Helper loaded: form_helper
INFO - 2020-03-07 14:40:33 --> Form Validation Class Initialized
INFO - 2020-03-07 14:40:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:40:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:40:33 --> Final output sent to browser
DEBUG - 2020-03-07 14:40:33 --> Total execution time: 0.0054
INFO - 2020-03-07 14:40:51 --> Config Class Initialized
INFO - 2020-03-07 14:40:51 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:40:51 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:40:51 --> Utf8 Class Initialized
INFO - 2020-03-07 14:40:51 --> URI Class Initialized
INFO - 2020-03-07 14:40:51 --> Router Class Initialized
INFO - 2020-03-07 14:40:51 --> Output Class Initialized
INFO - 2020-03-07 14:40:51 --> Security Class Initialized
DEBUG - 2020-03-07 14:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:40:51 --> Input Class Initialized
INFO - 2020-03-07 14:40:51 --> Language Class Initialized
INFO - 2020-03-07 14:40:51 --> Loader Class Initialized
INFO - 2020-03-07 14:40:51 --> Helper loaded: url_helper
INFO - 2020-03-07 14:40:51 --> Helper loaded: string_helper
INFO - 2020-03-07 14:40:51 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:40:51 --> Controller Class Initialized
INFO - 2020-03-07 14:40:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:40:51 --> Pagination Class Initialized
INFO - 2020-03-07 14:40:51 --> Model "M_show" initialized
INFO - 2020-03-07 14:40:51 --> Helper loaded: form_helper
INFO - 2020-03-07 14:40:51 --> Form Validation Class Initialized
INFO - 2020-03-07 14:40:51 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:40:51 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 14:40:51 --> Final output sent to browser
DEBUG - 2020-03-07 14:40:51 --> Total execution time: 0.0080
INFO - 2020-03-07 14:40:56 --> Config Class Initialized
INFO - 2020-03-07 14:40:56 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:40:56 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:40:56 --> Utf8 Class Initialized
INFO - 2020-03-07 14:40:56 --> URI Class Initialized
INFO - 2020-03-07 14:40:56 --> Router Class Initialized
INFO - 2020-03-07 14:40:56 --> Output Class Initialized
INFO - 2020-03-07 14:40:56 --> Security Class Initialized
DEBUG - 2020-03-07 14:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:40:56 --> Input Class Initialized
INFO - 2020-03-07 14:40:56 --> Language Class Initialized
INFO - 2020-03-07 14:40:56 --> Loader Class Initialized
INFO - 2020-03-07 14:40:56 --> Helper loaded: url_helper
INFO - 2020-03-07 14:40:56 --> Helper loaded: string_helper
INFO - 2020-03-07 14:40:56 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:40:56 --> Controller Class Initialized
INFO - 2020-03-07 14:40:56 --> Model "M_tiket" initialized
INFO - 2020-03-07 14:40:56 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 14:40:56 --> Model "M_pesan" initialized
INFO - 2020-03-07 14:40:56 --> Helper loaded: form_helper
INFO - 2020-03-07 14:40:56 --> Form Validation Class Initialized
INFO - 2020-03-07 14:40:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 14:40:56 --> Final output sent to browser
DEBUG - 2020-03-07 14:40:56 --> Total execution time: 0.0117
INFO - 2020-03-07 14:41:11 --> Config Class Initialized
INFO - 2020-03-07 14:41:11 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:41:11 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:41:11 --> Utf8 Class Initialized
INFO - 2020-03-07 14:41:11 --> URI Class Initialized
INFO - 2020-03-07 14:41:11 --> Router Class Initialized
INFO - 2020-03-07 14:41:11 --> Output Class Initialized
INFO - 2020-03-07 14:41:11 --> Security Class Initialized
DEBUG - 2020-03-07 14:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:41:11 --> Input Class Initialized
INFO - 2020-03-07 14:41:11 --> Language Class Initialized
INFO - 2020-03-07 14:41:11 --> Loader Class Initialized
INFO - 2020-03-07 14:41:11 --> Helper loaded: url_helper
INFO - 2020-03-07 14:41:11 --> Helper loaded: string_helper
INFO - 2020-03-07 14:41:11 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:41:11 --> Controller Class Initialized
INFO - 2020-03-07 14:41:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:41:11 --> Pagination Class Initialized
INFO - 2020-03-07 14:41:11 --> Model "M_show" initialized
INFO - 2020-03-07 14:41:11 --> Helper loaded: form_helper
INFO - 2020-03-07 14:41:11 --> Form Validation Class Initialized
INFO - 2020-03-07 14:41:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:41:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 14:41:11 --> Final output sent to browser
DEBUG - 2020-03-07 14:41:11 --> Total execution time: 0.0062
INFO - 2020-03-07 14:41:13 --> Config Class Initialized
INFO - 2020-03-07 14:41:13 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:41:13 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:41:13 --> Utf8 Class Initialized
INFO - 2020-03-07 14:41:13 --> URI Class Initialized
DEBUG - 2020-03-07 14:41:13 --> No URI present. Default controller set.
INFO - 2020-03-07 14:41:13 --> Router Class Initialized
INFO - 2020-03-07 14:41:13 --> Output Class Initialized
INFO - 2020-03-07 14:41:13 --> Security Class Initialized
DEBUG - 2020-03-07 14:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:41:13 --> Input Class Initialized
INFO - 2020-03-07 14:41:13 --> Language Class Initialized
INFO - 2020-03-07 14:41:13 --> Loader Class Initialized
INFO - 2020-03-07 14:41:13 --> Helper loaded: url_helper
INFO - 2020-03-07 14:41:13 --> Helper loaded: string_helper
INFO - 2020-03-07 14:41:13 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:41:13 --> Controller Class Initialized
INFO - 2020-03-07 14:41:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:41:13 --> Pagination Class Initialized
INFO - 2020-03-07 14:41:13 --> Model "M_show" initialized
INFO - 2020-03-07 14:41:13 --> Helper loaded: form_helper
INFO - 2020-03-07 14:41:13 --> Form Validation Class Initialized
INFO - 2020-03-07 14:41:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:41:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:41:13 --> Final output sent to browser
DEBUG - 2020-03-07 14:41:13 --> Total execution time: 0.0053
INFO - 2020-03-07 14:41:13 --> Config Class Initialized
INFO - 2020-03-07 14:41:13 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:41:13 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:41:13 --> Utf8 Class Initialized
INFO - 2020-03-07 14:41:13 --> URI Class Initialized
DEBUG - 2020-03-07 14:41:13 --> No URI present. Default controller set.
INFO - 2020-03-07 14:41:13 --> Router Class Initialized
INFO - 2020-03-07 14:41:13 --> Output Class Initialized
INFO - 2020-03-07 14:41:13 --> Security Class Initialized
DEBUG - 2020-03-07 14:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:41:13 --> Input Class Initialized
INFO - 2020-03-07 14:41:13 --> Language Class Initialized
INFO - 2020-03-07 14:41:13 --> Loader Class Initialized
INFO - 2020-03-07 14:41:13 --> Helper loaded: url_helper
INFO - 2020-03-07 14:41:13 --> Helper loaded: string_helper
INFO - 2020-03-07 14:41:13 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:41:13 --> Controller Class Initialized
INFO - 2020-03-07 14:41:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:41:13 --> Pagination Class Initialized
INFO - 2020-03-07 14:41:13 --> Model "M_show" initialized
INFO - 2020-03-07 14:41:13 --> Helper loaded: form_helper
INFO - 2020-03-07 14:41:13 --> Form Validation Class Initialized
INFO - 2020-03-07 14:41:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:41:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:41:13 --> Final output sent to browser
DEBUG - 2020-03-07 14:41:13 --> Total execution time: 0.0057
INFO - 2020-03-07 14:41:16 --> Config Class Initialized
INFO - 2020-03-07 14:41:16 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:41:16 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:41:16 --> Utf8 Class Initialized
INFO - 2020-03-07 14:41:16 --> URI Class Initialized
INFO - 2020-03-07 14:41:16 --> Router Class Initialized
INFO - 2020-03-07 14:41:16 --> Output Class Initialized
INFO - 2020-03-07 14:41:16 --> Security Class Initialized
DEBUG - 2020-03-07 14:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:41:16 --> Input Class Initialized
INFO - 2020-03-07 14:41:16 --> Language Class Initialized
INFO - 2020-03-07 14:41:16 --> Loader Class Initialized
INFO - 2020-03-07 14:41:16 --> Helper loaded: url_helper
INFO - 2020-03-07 14:41:16 --> Helper loaded: string_helper
INFO - 2020-03-07 14:41:16 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:41:16 --> Controller Class Initialized
INFO - 2020-03-07 14:41:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:41:16 --> Pagination Class Initialized
INFO - 2020-03-07 14:41:16 --> Model "M_show" initialized
INFO - 2020-03-07 14:41:16 --> Helper loaded: form_helper
INFO - 2020-03-07 14:41:16 --> Form Validation Class Initialized
INFO - 2020-03-07 14:41:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:41:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/gal.php
INFO - 2020-03-07 14:41:16 --> Final output sent to browser
DEBUG - 2020-03-07 14:41:16 --> Total execution time: 0.0204
INFO - 2020-03-07 14:41:26 --> Config Class Initialized
INFO - 2020-03-07 14:41:26 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:41:26 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:41:26 --> Utf8 Class Initialized
INFO - 2020-03-07 14:41:26 --> URI Class Initialized
INFO - 2020-03-07 14:41:26 --> Router Class Initialized
INFO - 2020-03-07 14:41:26 --> Output Class Initialized
INFO - 2020-03-07 14:41:26 --> Security Class Initialized
DEBUG - 2020-03-07 14:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:41:26 --> Input Class Initialized
INFO - 2020-03-07 14:41:26 --> Language Class Initialized
INFO - 2020-03-07 14:41:26 --> Loader Class Initialized
INFO - 2020-03-07 14:41:26 --> Helper loaded: url_helper
INFO - 2020-03-07 14:41:26 --> Helper loaded: string_helper
INFO - 2020-03-07 14:41:26 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:41:26 --> Controller Class Initialized
INFO - 2020-03-07 14:41:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:41:26 --> Pagination Class Initialized
INFO - 2020-03-07 14:41:26 --> Model "M_show" initialized
INFO - 2020-03-07 14:41:26 --> Helper loaded: form_helper
INFO - 2020-03-07 14:41:26 --> Form Validation Class Initialized
INFO - 2020-03-07 14:41:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:41:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-07 14:41:26 --> Final output sent to browser
DEBUG - 2020-03-07 14:41:26 --> Total execution time: 0.0076
INFO - 2020-03-07 14:41:40 --> Config Class Initialized
INFO - 2020-03-07 14:41:40 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:41:40 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:41:40 --> Utf8 Class Initialized
INFO - 2020-03-07 14:41:40 --> URI Class Initialized
INFO - 2020-03-07 14:41:40 --> Router Class Initialized
INFO - 2020-03-07 14:41:40 --> Output Class Initialized
INFO - 2020-03-07 14:41:40 --> Security Class Initialized
DEBUG - 2020-03-07 14:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:41:40 --> Input Class Initialized
INFO - 2020-03-07 14:41:40 --> Language Class Initialized
INFO - 2020-03-07 14:41:40 --> Loader Class Initialized
INFO - 2020-03-07 14:41:40 --> Helper loaded: url_helper
INFO - 2020-03-07 14:41:40 --> Helper loaded: string_helper
INFO - 2020-03-07 14:41:40 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:41:40 --> Controller Class Initialized
INFO - 2020-03-07 14:41:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:41:40 --> Pagination Class Initialized
INFO - 2020-03-07 14:41:40 --> Model "M_show" initialized
INFO - 2020-03-07 14:41:40 --> Helper loaded: form_helper
INFO - 2020-03-07 14:41:40 --> Form Validation Class Initialized
INFO - 2020-03-07 14:41:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:41:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tentang.php
INFO - 2020-03-07 14:41:40 --> Final output sent to browser
DEBUG - 2020-03-07 14:41:40 --> Total execution time: 0.0426
INFO - 2020-03-07 14:41:47 --> Config Class Initialized
INFO - 2020-03-07 14:41:47 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:41:47 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:41:47 --> Utf8 Class Initialized
INFO - 2020-03-07 14:41:47 --> URI Class Initialized
INFO - 2020-03-07 14:41:47 --> Router Class Initialized
INFO - 2020-03-07 14:41:47 --> Output Class Initialized
INFO - 2020-03-07 14:41:47 --> Security Class Initialized
DEBUG - 2020-03-07 14:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:41:47 --> Input Class Initialized
INFO - 2020-03-07 14:41:47 --> Language Class Initialized
INFO - 2020-03-07 14:41:47 --> Loader Class Initialized
INFO - 2020-03-07 14:41:47 --> Helper loaded: url_helper
INFO - 2020-03-07 14:41:47 --> Helper loaded: string_helper
INFO - 2020-03-07 14:41:47 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:41:47 --> Controller Class Initialized
INFO - 2020-03-07 14:41:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:41:47 --> Pagination Class Initialized
INFO - 2020-03-07 14:41:47 --> Model "M_show" initialized
INFO - 2020-03-07 14:41:47 --> Helper loaded: form_helper
INFO - 2020-03-07 14:41:47 --> Form Validation Class Initialized
INFO - 2020-03-07 14:41:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:41:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-07 14:41:47 --> Final output sent to browser
DEBUG - 2020-03-07 14:41:47 --> Total execution time: 0.0055
INFO - 2020-03-07 14:41:48 --> Config Class Initialized
INFO - 2020-03-07 14:41:48 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:41:48 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:41:48 --> Utf8 Class Initialized
INFO - 2020-03-07 14:41:48 --> URI Class Initialized
INFO - 2020-03-07 14:41:48 --> Router Class Initialized
INFO - 2020-03-07 14:41:48 --> Output Class Initialized
INFO - 2020-03-07 14:41:48 --> Security Class Initialized
DEBUG - 2020-03-07 14:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:41:48 --> Input Class Initialized
INFO - 2020-03-07 14:41:48 --> Language Class Initialized
INFO - 2020-03-07 14:41:48 --> Loader Class Initialized
INFO - 2020-03-07 14:41:48 --> Helper loaded: url_helper
INFO - 2020-03-07 14:41:48 --> Helper loaded: string_helper
INFO - 2020-03-07 14:41:48 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:41:48 --> Controller Class Initialized
INFO - 2020-03-07 14:41:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:41:48 --> Pagination Class Initialized
INFO - 2020-03-07 14:41:48 --> Model "M_show" initialized
INFO - 2020-03-07 14:41:48 --> Helper loaded: form_helper
INFO - 2020-03-07 14:41:48 --> Form Validation Class Initialized
INFO - 2020-03-07 14:41:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:41:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/gal.php
INFO - 2020-03-07 14:41:48 --> Final output sent to browser
DEBUG - 2020-03-07 14:41:48 --> Total execution time: 0.0060
INFO - 2020-03-07 14:41:50 --> Config Class Initialized
INFO - 2020-03-07 14:41:50 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:41:50 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:41:50 --> Utf8 Class Initialized
INFO - 2020-03-07 14:41:50 --> URI Class Initialized
DEBUG - 2020-03-07 14:41:50 --> No URI present. Default controller set.
INFO - 2020-03-07 14:41:50 --> Router Class Initialized
INFO - 2020-03-07 14:41:50 --> Output Class Initialized
INFO - 2020-03-07 14:41:50 --> Security Class Initialized
DEBUG - 2020-03-07 14:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:41:50 --> Input Class Initialized
INFO - 2020-03-07 14:41:50 --> Language Class Initialized
INFO - 2020-03-07 14:41:50 --> Loader Class Initialized
INFO - 2020-03-07 14:41:50 --> Helper loaded: url_helper
INFO - 2020-03-07 14:41:50 --> Helper loaded: string_helper
INFO - 2020-03-07 14:41:50 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:41:50 --> Controller Class Initialized
INFO - 2020-03-07 14:41:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:41:50 --> Pagination Class Initialized
INFO - 2020-03-07 14:41:50 --> Model "M_show" initialized
INFO - 2020-03-07 14:41:50 --> Helper loaded: form_helper
INFO - 2020-03-07 14:41:50 --> Form Validation Class Initialized
INFO - 2020-03-07 14:41:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:41:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:41:50 --> Final output sent to browser
DEBUG - 2020-03-07 14:41:50 --> Total execution time: 0.0056
INFO - 2020-03-07 14:41:50 --> Config Class Initialized
INFO - 2020-03-07 14:41:50 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:41:50 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:41:50 --> Utf8 Class Initialized
INFO - 2020-03-07 14:41:50 --> URI Class Initialized
DEBUG - 2020-03-07 14:41:50 --> No URI present. Default controller set.
INFO - 2020-03-07 14:41:50 --> Router Class Initialized
INFO - 2020-03-07 14:41:50 --> Output Class Initialized
INFO - 2020-03-07 14:41:50 --> Security Class Initialized
DEBUG - 2020-03-07 14:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:41:50 --> Input Class Initialized
INFO - 2020-03-07 14:41:50 --> Language Class Initialized
INFO - 2020-03-07 14:41:50 --> Loader Class Initialized
INFO - 2020-03-07 14:41:50 --> Helper loaded: url_helper
INFO - 2020-03-07 14:41:50 --> Helper loaded: string_helper
INFO - 2020-03-07 14:41:50 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:41:50 --> Controller Class Initialized
INFO - 2020-03-07 14:41:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:41:50 --> Pagination Class Initialized
INFO - 2020-03-07 14:41:50 --> Model "M_show" initialized
INFO - 2020-03-07 14:41:50 --> Helper loaded: form_helper
INFO - 2020-03-07 14:41:50 --> Form Validation Class Initialized
INFO - 2020-03-07 14:41:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:41:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:41:50 --> Final output sent to browser
DEBUG - 2020-03-07 14:41:50 --> Total execution time: 0.0036
INFO - 2020-03-07 14:42:52 --> Config Class Initialized
INFO - 2020-03-07 14:42:52 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:42:52 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:42:52 --> Utf8 Class Initialized
INFO - 2020-03-07 14:42:52 --> URI Class Initialized
DEBUG - 2020-03-07 14:42:52 --> No URI present. Default controller set.
INFO - 2020-03-07 14:42:52 --> Router Class Initialized
INFO - 2020-03-07 14:42:52 --> Output Class Initialized
INFO - 2020-03-07 14:42:52 --> Security Class Initialized
DEBUG - 2020-03-07 14:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:42:52 --> Input Class Initialized
INFO - 2020-03-07 14:42:52 --> Language Class Initialized
INFO - 2020-03-07 14:42:52 --> Loader Class Initialized
INFO - 2020-03-07 14:42:52 --> Helper loaded: url_helper
INFO - 2020-03-07 14:42:52 --> Helper loaded: string_helper
INFO - 2020-03-07 14:42:52 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:42:52 --> Controller Class Initialized
INFO - 2020-03-07 14:42:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:42:52 --> Pagination Class Initialized
INFO - 2020-03-07 14:42:52 --> Model "M_show" initialized
INFO - 2020-03-07 14:42:52 --> Helper loaded: form_helper
INFO - 2020-03-07 14:42:52 --> Form Validation Class Initialized
INFO - 2020-03-07 14:42:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:42:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:42:52 --> Final output sent to browser
DEBUG - 2020-03-07 14:42:52 --> Total execution time: 0.0136
INFO - 2020-03-07 14:43:07 --> Config Class Initialized
INFO - 2020-03-07 14:43:07 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:43:07 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:43:07 --> Utf8 Class Initialized
INFO - 2020-03-07 14:43:07 --> URI Class Initialized
INFO - 2020-03-07 14:43:07 --> Router Class Initialized
INFO - 2020-03-07 14:43:07 --> Output Class Initialized
INFO - 2020-03-07 14:43:07 --> Security Class Initialized
DEBUG - 2020-03-07 14:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:43:07 --> Input Class Initialized
INFO - 2020-03-07 14:43:07 --> Language Class Initialized
INFO - 2020-03-07 14:43:07 --> Loader Class Initialized
INFO - 2020-03-07 14:43:07 --> Helper loaded: url_helper
INFO - 2020-03-07 14:43:07 --> Helper loaded: string_helper
INFO - 2020-03-07 14:43:07 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:43:07 --> Controller Class Initialized
INFO - 2020-03-07 14:43:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:43:07 --> Pagination Class Initialized
INFO - 2020-03-07 14:43:07 --> Model "M_show" initialized
INFO - 2020-03-07 14:43:07 --> Helper loaded: form_helper
INFO - 2020-03-07 14:43:07 --> Form Validation Class Initialized
INFO - 2020-03-07 14:43:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:43:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:43:07 --> Final output sent to browser
DEBUG - 2020-03-07 14:43:07 --> Total execution time: 0.0067
INFO - 2020-03-07 14:43:34 --> Config Class Initialized
INFO - 2020-03-07 14:43:34 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:43:34 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:43:34 --> Utf8 Class Initialized
INFO - 2020-03-07 14:43:34 --> URI Class Initialized
DEBUG - 2020-03-07 14:43:34 --> No URI present. Default controller set.
INFO - 2020-03-07 14:43:34 --> Router Class Initialized
INFO - 2020-03-07 14:43:34 --> Output Class Initialized
INFO - 2020-03-07 14:43:34 --> Security Class Initialized
DEBUG - 2020-03-07 14:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:43:34 --> Input Class Initialized
INFO - 2020-03-07 14:43:34 --> Language Class Initialized
INFO - 2020-03-07 14:43:34 --> Loader Class Initialized
INFO - 2020-03-07 14:43:34 --> Helper loaded: url_helper
INFO - 2020-03-07 14:43:34 --> Helper loaded: string_helper
INFO - 2020-03-07 14:43:34 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:43:34 --> Controller Class Initialized
INFO - 2020-03-07 14:43:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:43:34 --> Pagination Class Initialized
INFO - 2020-03-07 14:43:34 --> Model "M_show" initialized
INFO - 2020-03-07 14:43:34 --> Helper loaded: form_helper
INFO - 2020-03-07 14:43:34 --> Form Validation Class Initialized
INFO - 2020-03-07 14:43:34 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:43:34 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:43:34 --> Final output sent to browser
DEBUG - 2020-03-07 14:43:34 --> Total execution time: 0.0074
INFO - 2020-03-07 14:44:02 --> Config Class Initialized
INFO - 2020-03-07 14:44:02 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:44:02 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:44:02 --> Utf8 Class Initialized
INFO - 2020-03-07 14:44:02 --> URI Class Initialized
DEBUG - 2020-03-07 14:44:02 --> No URI present. Default controller set.
INFO - 2020-03-07 14:44:02 --> Router Class Initialized
INFO - 2020-03-07 14:44:02 --> Output Class Initialized
INFO - 2020-03-07 14:44:02 --> Security Class Initialized
DEBUG - 2020-03-07 14:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:44:02 --> Input Class Initialized
INFO - 2020-03-07 14:44:02 --> Language Class Initialized
INFO - 2020-03-07 14:44:02 --> Loader Class Initialized
INFO - 2020-03-07 14:44:02 --> Helper loaded: url_helper
INFO - 2020-03-07 14:44:02 --> Helper loaded: string_helper
INFO - 2020-03-07 14:44:02 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:44:02 --> Controller Class Initialized
INFO - 2020-03-07 14:44:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:44:02 --> Pagination Class Initialized
INFO - 2020-03-07 14:44:02 --> Model "M_show" initialized
INFO - 2020-03-07 14:44:02 --> Helper loaded: form_helper
INFO - 2020-03-07 14:44:02 --> Form Validation Class Initialized
INFO - 2020-03-07 14:44:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:44:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:44:02 --> Final output sent to browser
DEBUG - 2020-03-07 14:44:02 --> Total execution time: 0.0076
INFO - 2020-03-07 14:44:06 --> Config Class Initialized
INFO - 2020-03-07 14:44:06 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:44:06 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:44:06 --> Utf8 Class Initialized
INFO - 2020-03-07 14:44:06 --> URI Class Initialized
INFO - 2020-03-07 14:44:06 --> Router Class Initialized
INFO - 2020-03-07 14:44:06 --> Output Class Initialized
INFO - 2020-03-07 14:44:06 --> Security Class Initialized
DEBUG - 2020-03-07 14:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:44:06 --> Input Class Initialized
INFO - 2020-03-07 14:44:06 --> Language Class Initialized
INFO - 2020-03-07 14:44:06 --> Loader Class Initialized
INFO - 2020-03-07 14:44:06 --> Helper loaded: url_helper
INFO - 2020-03-07 14:44:06 --> Helper loaded: string_helper
INFO - 2020-03-07 14:44:06 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:44:06 --> Controller Class Initialized
INFO - 2020-03-07 14:44:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:44:06 --> Pagination Class Initialized
INFO - 2020-03-07 14:44:06 --> Model "M_show" initialized
INFO - 2020-03-07 14:44:06 --> Helper loaded: form_helper
INFO - 2020-03-07 14:44:06 --> Form Validation Class Initialized
INFO - 2020-03-07 14:44:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:44:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-07 14:44:06 --> Final output sent to browser
DEBUG - 2020-03-07 14:44:06 --> Total execution time: 0.0343
INFO - 2020-03-07 14:44:37 --> Config Class Initialized
INFO - 2020-03-07 14:44:37 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:44:37 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:44:37 --> Utf8 Class Initialized
INFO - 2020-03-07 14:44:37 --> URI Class Initialized
INFO - 2020-03-07 14:44:37 --> Router Class Initialized
INFO - 2020-03-07 14:44:37 --> Output Class Initialized
INFO - 2020-03-07 14:44:37 --> Security Class Initialized
DEBUG - 2020-03-07 14:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:44:37 --> Input Class Initialized
INFO - 2020-03-07 14:44:37 --> Language Class Initialized
INFO - 2020-03-07 14:44:37 --> Loader Class Initialized
INFO - 2020-03-07 14:44:37 --> Helper loaded: url_helper
INFO - 2020-03-07 14:44:37 --> Helper loaded: string_helper
INFO - 2020-03-07 14:44:37 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:44:37 --> Controller Class Initialized
INFO - 2020-03-07 14:44:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:44:37 --> Pagination Class Initialized
INFO - 2020-03-07 14:44:37 --> Model "M_show" initialized
INFO - 2020-03-07 14:44:37 --> Helper loaded: form_helper
INFO - 2020-03-07 14:44:37 --> Form Validation Class Initialized
INFO - 2020-03-07 14:44:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:44:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-07 14:44:37 --> Final output sent to browser
DEBUG - 2020-03-07 14:44:37 --> Total execution time: 0.0228
INFO - 2020-03-07 14:44:47 --> Config Class Initialized
INFO - 2020-03-07 14:44:47 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:44:47 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:44:47 --> Utf8 Class Initialized
INFO - 2020-03-07 14:44:47 --> URI Class Initialized
INFO - 2020-03-07 14:44:47 --> Router Class Initialized
INFO - 2020-03-07 14:44:47 --> Output Class Initialized
INFO - 2020-03-07 14:44:47 --> Security Class Initialized
DEBUG - 2020-03-07 14:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:44:47 --> Input Class Initialized
INFO - 2020-03-07 14:44:47 --> Language Class Initialized
INFO - 2020-03-07 14:44:47 --> Loader Class Initialized
INFO - 2020-03-07 14:44:47 --> Helper loaded: url_helper
INFO - 2020-03-07 14:44:47 --> Helper loaded: string_helper
INFO - 2020-03-07 14:44:47 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:44:47 --> Controller Class Initialized
INFO - 2020-03-07 14:44:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:44:47 --> Pagination Class Initialized
INFO - 2020-03-07 14:44:47 --> Model "M_show" initialized
INFO - 2020-03-07 14:44:47 --> Helper loaded: form_helper
INFO - 2020-03-07 14:44:47 --> Form Validation Class Initialized
INFO - 2020-03-07 14:44:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:44:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:44:47 --> Final output sent to browser
DEBUG - 2020-03-07 14:44:47 --> Total execution time: 0.0058
INFO - 2020-03-07 14:44:51 --> Config Class Initialized
INFO - 2020-03-07 14:44:51 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:44:51 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:44:51 --> Utf8 Class Initialized
INFO - 2020-03-07 14:44:51 --> URI Class Initialized
INFO - 2020-03-07 14:44:51 --> Router Class Initialized
INFO - 2020-03-07 14:44:51 --> Output Class Initialized
INFO - 2020-03-07 14:44:51 --> Security Class Initialized
DEBUG - 2020-03-07 14:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:44:51 --> Input Class Initialized
INFO - 2020-03-07 14:44:51 --> Language Class Initialized
INFO - 2020-03-07 14:44:51 --> Loader Class Initialized
INFO - 2020-03-07 14:44:51 --> Helper loaded: url_helper
INFO - 2020-03-07 14:44:51 --> Helper loaded: string_helper
INFO - 2020-03-07 14:44:51 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:44:51 --> Controller Class Initialized
INFO - 2020-03-07 14:44:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:44:51 --> Pagination Class Initialized
INFO - 2020-03-07 14:44:51 --> Model "M_show" initialized
INFO - 2020-03-07 14:44:51 --> Helper loaded: form_helper
INFO - 2020-03-07 14:44:51 --> Form Validation Class Initialized
INFO - 2020-03-07 14:44:51 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:44:51 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 14:44:51 --> Final output sent to browser
DEBUG - 2020-03-07 14:44:51 --> Total execution time: 0.0062
INFO - 2020-03-07 14:44:56 --> Config Class Initialized
INFO - 2020-03-07 14:44:56 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:44:56 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:44:56 --> Utf8 Class Initialized
INFO - 2020-03-07 14:44:56 --> URI Class Initialized
INFO - 2020-03-07 14:44:56 --> Router Class Initialized
INFO - 2020-03-07 14:44:56 --> Output Class Initialized
INFO - 2020-03-07 14:44:56 --> Security Class Initialized
DEBUG - 2020-03-07 14:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:44:56 --> Input Class Initialized
INFO - 2020-03-07 14:44:56 --> Language Class Initialized
INFO - 2020-03-07 14:44:56 --> Loader Class Initialized
INFO - 2020-03-07 14:44:56 --> Helper loaded: url_helper
INFO - 2020-03-07 14:44:56 --> Helper loaded: string_helper
INFO - 2020-03-07 14:44:56 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:44:56 --> Controller Class Initialized
INFO - 2020-03-07 14:44:56 --> Model "M_tiket" initialized
INFO - 2020-03-07 14:44:56 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 14:44:56 --> Model "M_pesan" initialized
INFO - 2020-03-07 14:44:56 --> Helper loaded: form_helper
INFO - 2020-03-07 14:44:56 --> Form Validation Class Initialized
INFO - 2020-03-07 14:44:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 14:44:56 --> Final output sent to browser
DEBUG - 2020-03-07 14:44:56 --> Total execution time: 0.0087
INFO - 2020-03-07 14:45:07 --> Config Class Initialized
INFO - 2020-03-07 14:45:07 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:45:07 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:45:07 --> Utf8 Class Initialized
INFO - 2020-03-07 14:45:07 --> URI Class Initialized
INFO - 2020-03-07 14:45:07 --> Router Class Initialized
INFO - 2020-03-07 14:45:07 --> Output Class Initialized
INFO - 2020-03-07 14:45:07 --> Security Class Initialized
DEBUG - 2020-03-07 14:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:45:07 --> Input Class Initialized
INFO - 2020-03-07 14:45:07 --> Language Class Initialized
INFO - 2020-03-07 14:45:07 --> Loader Class Initialized
INFO - 2020-03-07 14:45:07 --> Helper loaded: url_helper
INFO - 2020-03-07 14:45:07 --> Helper loaded: string_helper
INFO - 2020-03-07 14:45:07 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:45:07 --> Controller Class Initialized
INFO - 2020-03-07 14:45:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:45:07 --> Pagination Class Initialized
INFO - 2020-03-07 14:45:07 --> Model "M_show" initialized
INFO - 2020-03-07 14:45:07 --> Helper loaded: form_helper
INFO - 2020-03-07 14:45:07 --> Form Validation Class Initialized
INFO - 2020-03-07 14:45:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:45:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 14:45:07 --> Final output sent to browser
DEBUG - 2020-03-07 14:45:07 --> Total execution time: 0.0096
INFO - 2020-03-07 14:45:08 --> Config Class Initialized
INFO - 2020-03-07 14:45:08 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:45:08 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:45:08 --> Utf8 Class Initialized
INFO - 2020-03-07 14:45:08 --> URI Class Initialized
INFO - 2020-03-07 14:45:08 --> Router Class Initialized
INFO - 2020-03-07 14:45:08 --> Output Class Initialized
INFO - 2020-03-07 14:45:08 --> Security Class Initialized
DEBUG - 2020-03-07 14:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:45:08 --> Input Class Initialized
INFO - 2020-03-07 14:45:08 --> Language Class Initialized
INFO - 2020-03-07 14:45:08 --> Loader Class Initialized
INFO - 2020-03-07 14:45:08 --> Helper loaded: url_helper
INFO - 2020-03-07 14:45:08 --> Helper loaded: string_helper
INFO - 2020-03-07 14:45:08 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:45:08 --> Controller Class Initialized
INFO - 2020-03-07 14:45:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:45:08 --> Pagination Class Initialized
INFO - 2020-03-07 14:45:08 --> Model "M_show" initialized
INFO - 2020-03-07 14:45:08 --> Helper loaded: form_helper
INFO - 2020-03-07 14:45:08 --> Form Validation Class Initialized
INFO - 2020-03-07 14:45:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:45:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:45:08 --> Final output sent to browser
DEBUG - 2020-03-07 14:45:08 --> Total execution time: 0.0059
INFO - 2020-03-07 14:45:09 --> Config Class Initialized
INFO - 2020-03-07 14:45:09 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:45:09 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:45:09 --> Utf8 Class Initialized
INFO - 2020-03-07 14:45:09 --> URI Class Initialized
INFO - 2020-03-07 14:45:09 --> Router Class Initialized
INFO - 2020-03-07 14:45:09 --> Output Class Initialized
INFO - 2020-03-07 14:45:09 --> Security Class Initialized
DEBUG - 2020-03-07 14:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:45:09 --> Input Class Initialized
INFO - 2020-03-07 14:45:09 --> Language Class Initialized
INFO - 2020-03-07 14:45:09 --> Loader Class Initialized
INFO - 2020-03-07 14:45:09 --> Helper loaded: url_helper
INFO - 2020-03-07 14:45:09 --> Helper loaded: string_helper
INFO - 2020-03-07 14:45:09 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:45:09 --> Controller Class Initialized
INFO - 2020-03-07 14:45:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:45:09 --> Pagination Class Initialized
INFO - 2020-03-07 14:45:09 --> Model "M_show" initialized
INFO - 2020-03-07 14:45:09 --> Helper loaded: form_helper
INFO - 2020-03-07 14:45:09 --> Form Validation Class Initialized
INFO - 2020-03-07 14:45:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:45:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-07 14:45:09 --> Final output sent to browser
DEBUG - 2020-03-07 14:45:09 --> Total execution time: 0.0055
INFO - 2020-03-07 14:45:11 --> Config Class Initialized
INFO - 2020-03-07 14:45:11 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:45:11 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:45:11 --> Utf8 Class Initialized
INFO - 2020-03-07 14:45:11 --> URI Class Initialized
DEBUG - 2020-03-07 14:45:11 --> No URI present. Default controller set.
INFO - 2020-03-07 14:45:11 --> Router Class Initialized
INFO - 2020-03-07 14:45:11 --> Output Class Initialized
INFO - 2020-03-07 14:45:11 --> Security Class Initialized
DEBUG - 2020-03-07 14:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:45:11 --> Input Class Initialized
INFO - 2020-03-07 14:45:11 --> Language Class Initialized
INFO - 2020-03-07 14:45:11 --> Loader Class Initialized
INFO - 2020-03-07 14:45:11 --> Helper loaded: url_helper
INFO - 2020-03-07 14:45:11 --> Helper loaded: string_helper
INFO - 2020-03-07 14:45:11 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:45:11 --> Controller Class Initialized
INFO - 2020-03-07 14:45:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:45:11 --> Pagination Class Initialized
INFO - 2020-03-07 14:45:11 --> Model "M_show" initialized
INFO - 2020-03-07 14:45:11 --> Helper loaded: form_helper
INFO - 2020-03-07 14:45:11 --> Form Validation Class Initialized
INFO - 2020-03-07 14:45:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:45:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:45:11 --> Final output sent to browser
DEBUG - 2020-03-07 14:45:11 --> Total execution time: 0.0171
INFO - 2020-03-07 14:45:17 --> Config Class Initialized
INFO - 2020-03-07 14:45:17 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:45:17 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:45:17 --> Utf8 Class Initialized
INFO - 2020-03-07 14:45:17 --> URI Class Initialized
INFO - 2020-03-07 14:45:17 --> Router Class Initialized
INFO - 2020-03-07 14:45:17 --> Output Class Initialized
INFO - 2020-03-07 14:45:17 --> Security Class Initialized
DEBUG - 2020-03-07 14:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:45:17 --> Input Class Initialized
INFO - 2020-03-07 14:45:17 --> Language Class Initialized
INFO - 2020-03-07 14:45:17 --> Loader Class Initialized
INFO - 2020-03-07 14:45:17 --> Helper loaded: url_helper
INFO - 2020-03-07 14:45:17 --> Helper loaded: string_helper
INFO - 2020-03-07 14:45:17 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:45:17 --> Controller Class Initialized
INFO - 2020-03-07 14:45:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:45:17 --> Pagination Class Initialized
INFO - 2020-03-07 14:45:17 --> Model "M_show" initialized
INFO - 2020-03-07 14:45:17 --> Helper loaded: form_helper
INFO - 2020-03-07 14:45:17 --> Form Validation Class Initialized
INFO - 2020-03-07 14:45:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:45:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:45:17 --> Final output sent to browser
DEBUG - 2020-03-07 14:45:17 --> Total execution time: 0.0054
INFO - 2020-03-07 14:45:20 --> Config Class Initialized
INFO - 2020-03-07 14:45:20 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:45:20 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:45:20 --> Utf8 Class Initialized
INFO - 2020-03-07 14:45:20 --> URI Class Initialized
DEBUG - 2020-03-07 14:45:20 --> No URI present. Default controller set.
INFO - 2020-03-07 14:45:20 --> Router Class Initialized
INFO - 2020-03-07 14:45:20 --> Output Class Initialized
INFO - 2020-03-07 14:45:20 --> Security Class Initialized
DEBUG - 2020-03-07 14:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:45:20 --> Input Class Initialized
INFO - 2020-03-07 14:45:20 --> Language Class Initialized
INFO - 2020-03-07 14:45:20 --> Loader Class Initialized
INFO - 2020-03-07 14:45:20 --> Helper loaded: url_helper
INFO - 2020-03-07 14:45:20 --> Helper loaded: string_helper
INFO - 2020-03-07 14:45:20 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:45:20 --> Controller Class Initialized
INFO - 2020-03-07 14:45:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:45:20 --> Pagination Class Initialized
INFO - 2020-03-07 14:45:20 --> Model "M_show" initialized
INFO - 2020-03-07 14:45:20 --> Helper loaded: form_helper
INFO - 2020-03-07 14:45:20 --> Form Validation Class Initialized
INFO - 2020-03-07 14:45:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:45:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:45:20 --> Final output sent to browser
DEBUG - 2020-03-07 14:45:20 --> Total execution time: 0.0071
INFO - 2020-03-07 14:45:48 --> Config Class Initialized
INFO - 2020-03-07 14:45:48 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:45:48 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:45:48 --> Utf8 Class Initialized
INFO - 2020-03-07 14:45:48 --> URI Class Initialized
INFO - 2020-03-07 14:45:48 --> Router Class Initialized
INFO - 2020-03-07 14:45:48 --> Output Class Initialized
INFO - 2020-03-07 14:45:48 --> Security Class Initialized
DEBUG - 2020-03-07 14:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:45:48 --> Input Class Initialized
INFO - 2020-03-07 14:45:48 --> Language Class Initialized
INFO - 2020-03-07 14:45:48 --> Loader Class Initialized
INFO - 2020-03-07 14:45:48 --> Helper loaded: url_helper
INFO - 2020-03-07 14:45:48 --> Helper loaded: string_helper
INFO - 2020-03-07 14:45:48 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:45:48 --> Controller Class Initialized
INFO - 2020-03-07 14:45:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:45:48 --> Pagination Class Initialized
INFO - 2020-03-07 14:45:48 --> Model "M_show" initialized
INFO - 2020-03-07 14:45:48 --> Helper loaded: form_helper
INFO - 2020-03-07 14:45:48 --> Form Validation Class Initialized
INFO - 2020-03-07 14:45:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:45:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:45:48 --> Final output sent to browser
DEBUG - 2020-03-07 14:45:48 --> Total execution time: 0.0055
INFO - 2020-03-07 14:45:58 --> Config Class Initialized
INFO - 2020-03-07 14:45:58 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:45:58 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:45:58 --> Utf8 Class Initialized
INFO - 2020-03-07 14:45:58 --> URI Class Initialized
INFO - 2020-03-07 14:45:58 --> Router Class Initialized
INFO - 2020-03-07 14:45:58 --> Output Class Initialized
INFO - 2020-03-07 14:45:58 --> Security Class Initialized
DEBUG - 2020-03-07 14:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:45:58 --> Input Class Initialized
INFO - 2020-03-07 14:45:58 --> Language Class Initialized
INFO - 2020-03-07 14:45:58 --> Loader Class Initialized
INFO - 2020-03-07 14:45:58 --> Helper loaded: url_helper
INFO - 2020-03-07 14:45:58 --> Helper loaded: string_helper
INFO - 2020-03-07 14:45:58 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:45:58 --> Controller Class Initialized
INFO - 2020-03-07 14:45:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:45:58 --> Pagination Class Initialized
INFO - 2020-03-07 14:45:58 --> Model "M_show" initialized
INFO - 2020-03-07 14:45:58 --> Helper loaded: form_helper
INFO - 2020-03-07 14:45:58 --> Form Validation Class Initialized
INFO - 2020-03-07 14:45:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:45:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 14:45:58 --> Final output sent to browser
DEBUG - 2020-03-07 14:45:58 --> Total execution time: 0.0072
INFO - 2020-03-07 14:46:03 --> Config Class Initialized
INFO - 2020-03-07 14:46:03 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:46:03 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:46:03 --> Utf8 Class Initialized
INFO - 2020-03-07 14:46:03 --> URI Class Initialized
INFO - 2020-03-07 14:46:03 --> Router Class Initialized
INFO - 2020-03-07 14:46:03 --> Output Class Initialized
INFO - 2020-03-07 14:46:03 --> Security Class Initialized
DEBUG - 2020-03-07 14:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:46:03 --> Input Class Initialized
INFO - 2020-03-07 14:46:03 --> Language Class Initialized
INFO - 2020-03-07 14:46:03 --> Loader Class Initialized
INFO - 2020-03-07 14:46:03 --> Helper loaded: url_helper
INFO - 2020-03-07 14:46:03 --> Helper loaded: string_helper
INFO - 2020-03-07 14:46:03 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:46:03 --> Controller Class Initialized
INFO - 2020-03-07 14:46:03 --> Model "M_tiket" initialized
INFO - 2020-03-07 14:46:03 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 14:46:03 --> Model "M_pesan" initialized
INFO - 2020-03-07 14:46:03 --> Helper loaded: form_helper
INFO - 2020-03-07 14:46:03 --> Form Validation Class Initialized
INFO - 2020-03-07 14:46:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 14:46:03 --> Final output sent to browser
DEBUG - 2020-03-07 14:46:03 --> Total execution time: 0.0089
INFO - 2020-03-07 14:46:46 --> Config Class Initialized
INFO - 2020-03-07 14:46:46 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:46:46 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:46:46 --> Utf8 Class Initialized
INFO - 2020-03-07 14:46:46 --> URI Class Initialized
INFO - 2020-03-07 14:46:46 --> Router Class Initialized
INFO - 2020-03-07 14:46:46 --> Output Class Initialized
INFO - 2020-03-07 14:46:46 --> Security Class Initialized
DEBUG - 2020-03-07 14:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:46:46 --> Input Class Initialized
INFO - 2020-03-07 14:46:46 --> Language Class Initialized
INFO - 2020-03-07 14:46:46 --> Loader Class Initialized
INFO - 2020-03-07 14:46:46 --> Helper loaded: url_helper
INFO - 2020-03-07 14:46:46 --> Helper loaded: string_helper
INFO - 2020-03-07 14:46:46 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:46:46 --> Controller Class Initialized
INFO - 2020-03-07 14:46:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:46:46 --> Pagination Class Initialized
INFO - 2020-03-07 14:46:46 --> Model "M_show" initialized
INFO - 2020-03-07 14:46:46 --> Helper loaded: form_helper
INFO - 2020-03-07 14:46:46 --> Form Validation Class Initialized
INFO - 2020-03-07 14:46:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:46:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 14:46:46 --> Final output sent to browser
DEBUG - 2020-03-07 14:46:46 --> Total execution time: 0.0062
INFO - 2020-03-07 14:46:48 --> Config Class Initialized
INFO - 2020-03-07 14:46:48 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:46:48 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:46:48 --> Utf8 Class Initialized
INFO - 2020-03-07 14:46:48 --> URI Class Initialized
INFO - 2020-03-07 14:46:48 --> Router Class Initialized
INFO - 2020-03-07 14:46:48 --> Output Class Initialized
INFO - 2020-03-07 14:46:48 --> Security Class Initialized
DEBUG - 2020-03-07 14:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:46:48 --> Input Class Initialized
INFO - 2020-03-07 14:46:48 --> Language Class Initialized
INFO - 2020-03-07 14:46:48 --> Loader Class Initialized
INFO - 2020-03-07 14:46:48 --> Helper loaded: url_helper
INFO - 2020-03-07 14:46:48 --> Helper loaded: string_helper
INFO - 2020-03-07 14:46:48 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:46:48 --> Controller Class Initialized
INFO - 2020-03-07 14:46:48 --> Model "M_tiket" initialized
INFO - 2020-03-07 14:46:48 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 14:46:48 --> Model "M_pesan" initialized
INFO - 2020-03-07 14:46:48 --> Helper loaded: form_helper
INFO - 2020-03-07 14:46:48 --> Form Validation Class Initialized
INFO - 2020-03-07 14:46:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 14:46:48 --> Final output sent to browser
DEBUG - 2020-03-07 14:46:48 --> Total execution time: 0.0092
INFO - 2020-03-07 14:46:52 --> Config Class Initialized
INFO - 2020-03-07 14:46:52 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:46:52 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:46:52 --> Utf8 Class Initialized
INFO - 2020-03-07 14:46:52 --> URI Class Initialized
INFO - 2020-03-07 14:46:52 --> Router Class Initialized
INFO - 2020-03-07 14:46:52 --> Output Class Initialized
INFO - 2020-03-07 14:46:52 --> Security Class Initialized
DEBUG - 2020-03-07 14:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:46:52 --> Input Class Initialized
INFO - 2020-03-07 14:46:52 --> Language Class Initialized
INFO - 2020-03-07 14:46:52 --> Loader Class Initialized
INFO - 2020-03-07 14:46:52 --> Helper loaded: url_helper
INFO - 2020-03-07 14:46:52 --> Helper loaded: string_helper
INFO - 2020-03-07 14:46:52 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:46:52 --> Controller Class Initialized
INFO - 2020-03-07 14:46:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:46:52 --> Pagination Class Initialized
INFO - 2020-03-07 14:46:52 --> Model "M_show" initialized
INFO - 2020-03-07 14:46:52 --> Helper loaded: form_helper
INFO - 2020-03-07 14:46:52 --> Form Validation Class Initialized
INFO - 2020-03-07 14:46:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:46:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 14:46:52 --> Final output sent to browser
DEBUG - 2020-03-07 14:46:52 --> Total execution time: 0.0065
INFO - 2020-03-07 14:46:54 --> Config Class Initialized
INFO - 2020-03-07 14:46:54 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:46:54 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:46:54 --> Utf8 Class Initialized
INFO - 2020-03-07 14:46:54 --> URI Class Initialized
INFO - 2020-03-07 14:46:54 --> Router Class Initialized
INFO - 2020-03-07 14:46:54 --> Output Class Initialized
INFO - 2020-03-07 14:46:54 --> Security Class Initialized
DEBUG - 2020-03-07 14:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:46:54 --> Input Class Initialized
INFO - 2020-03-07 14:46:54 --> Language Class Initialized
INFO - 2020-03-07 14:46:54 --> Loader Class Initialized
INFO - 2020-03-07 14:46:54 --> Helper loaded: url_helper
INFO - 2020-03-07 14:46:54 --> Helper loaded: string_helper
INFO - 2020-03-07 14:46:54 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:46:54 --> Controller Class Initialized
INFO - 2020-03-07 14:46:54 --> Model "M_tiket" initialized
INFO - 2020-03-07 14:46:54 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 14:46:54 --> Model "M_pesan" initialized
INFO - 2020-03-07 14:46:54 --> Helper loaded: form_helper
INFO - 2020-03-07 14:46:54 --> Form Validation Class Initialized
INFO - 2020-03-07 14:46:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 14:46:54 --> Final output sent to browser
DEBUG - 2020-03-07 14:46:54 --> Total execution time: 0.0071
INFO - 2020-03-07 14:46:57 --> Config Class Initialized
INFO - 2020-03-07 14:46:57 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:46:57 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:46:57 --> Utf8 Class Initialized
INFO - 2020-03-07 14:46:57 --> URI Class Initialized
INFO - 2020-03-07 14:46:57 --> Router Class Initialized
INFO - 2020-03-07 14:46:57 --> Output Class Initialized
INFO - 2020-03-07 14:46:57 --> Security Class Initialized
DEBUG - 2020-03-07 14:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:46:57 --> Input Class Initialized
INFO - 2020-03-07 14:46:57 --> Language Class Initialized
INFO - 2020-03-07 14:46:57 --> Loader Class Initialized
INFO - 2020-03-07 14:46:57 --> Helper loaded: url_helper
INFO - 2020-03-07 14:46:57 --> Helper loaded: string_helper
INFO - 2020-03-07 14:46:57 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:46:57 --> Controller Class Initialized
INFO - 2020-03-07 14:46:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:46:57 --> Pagination Class Initialized
INFO - 2020-03-07 14:46:57 --> Model "M_show" initialized
INFO - 2020-03-07 14:46:57 --> Helper loaded: form_helper
INFO - 2020-03-07 14:46:57 --> Form Validation Class Initialized
INFO - 2020-03-07 14:46:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:46:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 14:46:57 --> Final output sent to browser
DEBUG - 2020-03-07 14:46:57 --> Total execution time: 0.0062
INFO - 2020-03-07 14:47:02 --> Config Class Initialized
INFO - 2020-03-07 14:47:02 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:47:02 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:47:02 --> Utf8 Class Initialized
INFO - 2020-03-07 14:47:02 --> URI Class Initialized
INFO - 2020-03-07 14:47:02 --> Router Class Initialized
INFO - 2020-03-07 14:47:02 --> Output Class Initialized
INFO - 2020-03-07 14:47:02 --> Security Class Initialized
DEBUG - 2020-03-07 14:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:47:02 --> Input Class Initialized
INFO - 2020-03-07 14:47:02 --> Language Class Initialized
INFO - 2020-03-07 14:47:02 --> Loader Class Initialized
INFO - 2020-03-07 14:47:02 --> Helper loaded: url_helper
INFO - 2020-03-07 14:47:02 --> Helper loaded: string_helper
INFO - 2020-03-07 14:47:02 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:47:02 --> Controller Class Initialized
INFO - 2020-03-07 14:47:02 --> Model "M_tiket" initialized
INFO - 2020-03-07 14:47:02 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 14:47:02 --> Model "M_pesan" initialized
INFO - 2020-03-07 14:47:02 --> Helper loaded: form_helper
INFO - 2020-03-07 14:47:02 --> Form Validation Class Initialized
INFO - 2020-03-07 14:47:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 14:47:02 --> Final output sent to browser
DEBUG - 2020-03-07 14:47:02 --> Total execution time: 0.0111
INFO - 2020-03-07 14:47:06 --> Config Class Initialized
INFO - 2020-03-07 14:47:06 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:47:06 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:47:06 --> Utf8 Class Initialized
INFO - 2020-03-07 14:47:06 --> URI Class Initialized
INFO - 2020-03-07 14:47:06 --> Router Class Initialized
INFO - 2020-03-07 14:47:06 --> Output Class Initialized
INFO - 2020-03-07 14:47:06 --> Security Class Initialized
DEBUG - 2020-03-07 14:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:47:06 --> Input Class Initialized
INFO - 2020-03-07 14:47:06 --> Language Class Initialized
INFO - 2020-03-07 14:47:06 --> Loader Class Initialized
INFO - 2020-03-07 14:47:06 --> Helper loaded: url_helper
INFO - 2020-03-07 14:47:06 --> Helper loaded: string_helper
INFO - 2020-03-07 14:47:06 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:47:06 --> Controller Class Initialized
INFO - 2020-03-07 14:47:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:47:06 --> Pagination Class Initialized
INFO - 2020-03-07 14:47:06 --> Model "M_show" initialized
INFO - 2020-03-07 14:47:06 --> Helper loaded: form_helper
INFO - 2020-03-07 14:47:06 --> Form Validation Class Initialized
INFO - 2020-03-07 14:47:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:47:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 14:47:06 --> Final output sent to browser
DEBUG - 2020-03-07 14:47:06 --> Total execution time: 0.0108
INFO - 2020-03-07 14:47:09 --> Config Class Initialized
INFO - 2020-03-07 14:47:09 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:47:09 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:47:09 --> Utf8 Class Initialized
INFO - 2020-03-07 14:47:09 --> URI Class Initialized
INFO - 2020-03-07 14:47:09 --> Router Class Initialized
INFO - 2020-03-07 14:47:09 --> Output Class Initialized
INFO - 2020-03-07 14:47:09 --> Security Class Initialized
DEBUG - 2020-03-07 14:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:47:09 --> Input Class Initialized
INFO - 2020-03-07 14:47:09 --> Language Class Initialized
INFO - 2020-03-07 14:47:09 --> Loader Class Initialized
INFO - 2020-03-07 14:47:09 --> Helper loaded: url_helper
INFO - 2020-03-07 14:47:09 --> Helper loaded: string_helper
INFO - 2020-03-07 14:47:09 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:47:09 --> Controller Class Initialized
INFO - 2020-03-07 14:47:09 --> Model "M_tiket" initialized
INFO - 2020-03-07 14:47:09 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 14:47:09 --> Model "M_pesan" initialized
INFO - 2020-03-07 14:47:09 --> Helper loaded: form_helper
INFO - 2020-03-07 14:47:09 --> Form Validation Class Initialized
INFO - 2020-03-07 14:47:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 14:47:09 --> Final output sent to browser
DEBUG - 2020-03-07 14:47:09 --> Total execution time: 0.0081
INFO - 2020-03-07 14:47:17 --> Config Class Initialized
INFO - 2020-03-07 14:47:17 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:47:17 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:47:17 --> Utf8 Class Initialized
INFO - 2020-03-07 14:47:17 --> URI Class Initialized
INFO - 2020-03-07 14:47:17 --> Router Class Initialized
INFO - 2020-03-07 14:47:17 --> Output Class Initialized
INFO - 2020-03-07 14:47:17 --> Security Class Initialized
DEBUG - 2020-03-07 14:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:47:17 --> Input Class Initialized
INFO - 2020-03-07 14:47:17 --> Language Class Initialized
INFO - 2020-03-07 14:47:17 --> Loader Class Initialized
INFO - 2020-03-07 14:47:17 --> Helper loaded: url_helper
INFO - 2020-03-07 14:47:17 --> Helper loaded: string_helper
INFO - 2020-03-07 14:47:17 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:47:17 --> Controller Class Initialized
INFO - 2020-03-07 14:47:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:47:17 --> Pagination Class Initialized
INFO - 2020-03-07 14:47:17 --> Model "M_show" initialized
INFO - 2020-03-07 14:47:17 --> Helper loaded: form_helper
INFO - 2020-03-07 14:47:17 --> Form Validation Class Initialized
INFO - 2020-03-07 14:47:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:47:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 14:47:17 --> Final output sent to browser
DEBUG - 2020-03-07 14:47:17 --> Total execution time: 0.0079
INFO - 2020-03-07 14:47:24 --> Config Class Initialized
INFO - 2020-03-07 14:47:24 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:47:24 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:47:24 --> Utf8 Class Initialized
INFO - 2020-03-07 14:47:24 --> URI Class Initialized
INFO - 2020-03-07 14:47:24 --> Router Class Initialized
INFO - 2020-03-07 14:47:24 --> Output Class Initialized
INFO - 2020-03-07 14:47:24 --> Security Class Initialized
DEBUG - 2020-03-07 14:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:47:24 --> Input Class Initialized
INFO - 2020-03-07 14:47:24 --> Language Class Initialized
INFO - 2020-03-07 14:47:24 --> Loader Class Initialized
INFO - 2020-03-07 14:47:24 --> Helper loaded: url_helper
INFO - 2020-03-07 14:47:24 --> Helper loaded: string_helper
INFO - 2020-03-07 14:47:24 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:47:24 --> Controller Class Initialized
INFO - 2020-03-07 14:47:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:47:24 --> Pagination Class Initialized
INFO - 2020-03-07 14:47:24 --> Model "M_show" initialized
INFO - 2020-03-07 14:47:24 --> Helper loaded: form_helper
INFO - 2020-03-07 14:47:24 --> Form Validation Class Initialized
INFO - 2020-03-07 14:47:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:47:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:47:24 --> Final output sent to browser
DEBUG - 2020-03-07 14:47:24 --> Total execution time: 0.0076
INFO - 2020-03-07 14:47:26 --> Config Class Initialized
INFO - 2020-03-07 14:47:26 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:47:26 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:47:26 --> Utf8 Class Initialized
INFO - 2020-03-07 14:47:26 --> URI Class Initialized
DEBUG - 2020-03-07 14:47:26 --> No URI present. Default controller set.
INFO - 2020-03-07 14:47:26 --> Router Class Initialized
INFO - 2020-03-07 14:47:26 --> Output Class Initialized
INFO - 2020-03-07 14:47:26 --> Security Class Initialized
DEBUG - 2020-03-07 14:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:47:26 --> Input Class Initialized
INFO - 2020-03-07 14:47:26 --> Language Class Initialized
INFO - 2020-03-07 14:47:26 --> Loader Class Initialized
INFO - 2020-03-07 14:47:26 --> Helper loaded: url_helper
INFO - 2020-03-07 14:47:26 --> Helper loaded: string_helper
INFO - 2020-03-07 14:47:26 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:47:26 --> Controller Class Initialized
INFO - 2020-03-07 14:47:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:47:26 --> Pagination Class Initialized
INFO - 2020-03-07 14:47:26 --> Model "M_show" initialized
INFO - 2020-03-07 14:47:26 --> Helper loaded: form_helper
INFO - 2020-03-07 14:47:26 --> Form Validation Class Initialized
INFO - 2020-03-07 14:47:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:47:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:47:26 --> Final output sent to browser
DEBUG - 2020-03-07 14:47:26 --> Total execution time: 0.0066
INFO - 2020-03-07 14:54:15 --> Config Class Initialized
INFO - 2020-03-07 14:54:15 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:54:15 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:54:15 --> Utf8 Class Initialized
INFO - 2020-03-07 14:54:15 --> URI Class Initialized
DEBUG - 2020-03-07 14:54:15 --> No URI present. Default controller set.
INFO - 2020-03-07 14:54:15 --> Router Class Initialized
INFO - 2020-03-07 14:54:15 --> Output Class Initialized
INFO - 2020-03-07 14:54:15 --> Security Class Initialized
DEBUG - 2020-03-07 14:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:54:15 --> Input Class Initialized
INFO - 2020-03-07 14:54:15 --> Language Class Initialized
INFO - 2020-03-07 14:54:15 --> Loader Class Initialized
INFO - 2020-03-07 14:54:15 --> Helper loaded: url_helper
INFO - 2020-03-07 14:54:15 --> Helper loaded: string_helper
INFO - 2020-03-07 14:54:15 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:54:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:54:15 --> Controller Class Initialized
INFO - 2020-03-07 14:54:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:54:15 --> Pagination Class Initialized
INFO - 2020-03-07 14:54:15 --> Model "M_show" initialized
INFO - 2020-03-07 14:54:15 --> Helper loaded: form_helper
INFO - 2020-03-07 14:54:15 --> Form Validation Class Initialized
INFO - 2020-03-07 14:54:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:54:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:54:15 --> Final output sent to browser
DEBUG - 2020-03-07 14:54:15 --> Total execution time: 0.1698
INFO - 2020-03-07 14:54:36 --> Config Class Initialized
INFO - 2020-03-07 14:54:36 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:54:36 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:54:36 --> Utf8 Class Initialized
INFO - 2020-03-07 14:54:36 --> URI Class Initialized
DEBUG - 2020-03-07 14:54:36 --> No URI present. Default controller set.
INFO - 2020-03-07 14:54:36 --> Router Class Initialized
INFO - 2020-03-07 14:54:36 --> Output Class Initialized
INFO - 2020-03-07 14:54:36 --> Security Class Initialized
DEBUG - 2020-03-07 14:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:54:36 --> Input Class Initialized
INFO - 2020-03-07 14:54:36 --> Language Class Initialized
INFO - 2020-03-07 14:54:36 --> Loader Class Initialized
INFO - 2020-03-07 14:54:36 --> Helper loaded: url_helper
INFO - 2020-03-07 14:54:36 --> Helper loaded: string_helper
INFO - 2020-03-07 14:54:36 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:54:36 --> Controller Class Initialized
INFO - 2020-03-07 14:54:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:54:36 --> Pagination Class Initialized
INFO - 2020-03-07 14:54:36 --> Model "M_show" initialized
INFO - 2020-03-07 14:54:36 --> Helper loaded: form_helper
INFO - 2020-03-07 14:54:36 --> Form Validation Class Initialized
INFO - 2020-03-07 14:54:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:54:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:54:36 --> Final output sent to browser
DEBUG - 2020-03-07 14:54:36 --> Total execution time: 0.0217
INFO - 2020-03-07 14:54:37 --> Config Class Initialized
INFO - 2020-03-07 14:54:37 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:54:37 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:54:37 --> Utf8 Class Initialized
INFO - 2020-03-07 14:54:37 --> URI Class Initialized
INFO - 2020-03-07 14:54:37 --> Router Class Initialized
INFO - 2020-03-07 14:54:37 --> Output Class Initialized
INFO - 2020-03-07 14:54:37 --> Security Class Initialized
DEBUG - 2020-03-07 14:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:54:37 --> Input Class Initialized
INFO - 2020-03-07 14:54:37 --> Language Class Initialized
INFO - 2020-03-07 14:54:37 --> Loader Class Initialized
INFO - 2020-03-07 14:54:37 --> Helper loaded: url_helper
INFO - 2020-03-07 14:54:37 --> Helper loaded: string_helper
INFO - 2020-03-07 14:54:37 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:54:37 --> Controller Class Initialized
INFO - 2020-03-07 14:54:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:54:37 --> Pagination Class Initialized
INFO - 2020-03-07 14:54:37 --> Model "M_show" initialized
INFO - 2020-03-07 14:54:37 --> Helper loaded: form_helper
INFO - 2020-03-07 14:54:37 --> Form Validation Class Initialized
INFO - 2020-03-07 14:54:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:54:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 14:54:37 --> Final output sent to browser
DEBUG - 2020-03-07 14:54:37 --> Total execution time: 0.0111
INFO - 2020-03-07 14:54:38 --> Config Class Initialized
INFO - 2020-03-07 14:54:38 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:54:38 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:54:38 --> Utf8 Class Initialized
INFO - 2020-03-07 14:54:38 --> URI Class Initialized
INFO - 2020-03-07 14:54:38 --> Router Class Initialized
INFO - 2020-03-07 14:54:38 --> Output Class Initialized
INFO - 2020-03-07 14:54:38 --> Security Class Initialized
DEBUG - 2020-03-07 14:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:54:38 --> Input Class Initialized
INFO - 2020-03-07 14:54:38 --> Language Class Initialized
ERROR - 2020-03-07 14:54:38 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-07 14:54:43 --> Config Class Initialized
INFO - 2020-03-07 14:54:43 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:54:43 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:54:43 --> Utf8 Class Initialized
INFO - 2020-03-07 14:54:43 --> URI Class Initialized
INFO - 2020-03-07 14:54:43 --> Router Class Initialized
INFO - 2020-03-07 14:54:43 --> Output Class Initialized
INFO - 2020-03-07 14:54:43 --> Security Class Initialized
DEBUG - 2020-03-07 14:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:54:43 --> Input Class Initialized
INFO - 2020-03-07 14:54:43 --> Language Class Initialized
INFO - 2020-03-07 14:54:43 --> Loader Class Initialized
INFO - 2020-03-07 14:54:43 --> Helper loaded: url_helper
INFO - 2020-03-07 14:54:43 --> Helper loaded: string_helper
INFO - 2020-03-07 14:54:43 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:54:43 --> Controller Class Initialized
INFO - 2020-03-07 14:54:43 --> Model "M_tiket" initialized
INFO - 2020-03-07 14:54:43 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 14:54:43 --> Model "M_pesan" initialized
INFO - 2020-03-07 14:54:43 --> Helper loaded: form_helper
INFO - 2020-03-07 14:54:43 --> Form Validation Class Initialized
INFO - 2020-03-07 14:54:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 14:54:43 --> Final output sent to browser
DEBUG - 2020-03-07 14:54:43 --> Total execution time: 0.0110
INFO - 2020-03-07 14:54:46 --> Config Class Initialized
INFO - 2020-03-07 14:54:46 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:54:46 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:54:46 --> Utf8 Class Initialized
INFO - 2020-03-07 14:54:46 --> URI Class Initialized
INFO - 2020-03-07 14:54:46 --> Router Class Initialized
INFO - 2020-03-07 14:54:46 --> Output Class Initialized
INFO - 2020-03-07 14:54:46 --> Security Class Initialized
DEBUG - 2020-03-07 14:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:54:46 --> Input Class Initialized
INFO - 2020-03-07 14:54:46 --> Language Class Initialized
INFO - 2020-03-07 14:54:46 --> Loader Class Initialized
INFO - 2020-03-07 14:54:46 --> Helper loaded: url_helper
INFO - 2020-03-07 14:54:46 --> Helper loaded: string_helper
INFO - 2020-03-07 14:54:46 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:54:46 --> Controller Class Initialized
INFO - 2020-03-07 14:54:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:54:46 --> Pagination Class Initialized
INFO - 2020-03-07 14:54:46 --> Model "M_show" initialized
INFO - 2020-03-07 14:54:46 --> Helper loaded: form_helper
INFO - 2020-03-07 14:54:46 --> Form Validation Class Initialized
INFO - 2020-03-07 14:54:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:54:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:54:46 --> Final output sent to browser
DEBUG - 2020-03-07 14:54:46 --> Total execution time: 0.0059
INFO - 2020-03-07 14:54:50 --> Config Class Initialized
INFO - 2020-03-07 14:54:50 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:54:50 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:54:50 --> Utf8 Class Initialized
INFO - 2020-03-07 14:54:50 --> URI Class Initialized
INFO - 2020-03-07 14:54:50 --> Router Class Initialized
INFO - 2020-03-07 14:54:50 --> Output Class Initialized
INFO - 2020-03-07 14:54:50 --> Security Class Initialized
DEBUG - 2020-03-07 14:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:54:50 --> Input Class Initialized
INFO - 2020-03-07 14:54:50 --> Language Class Initialized
INFO - 2020-03-07 14:54:50 --> Loader Class Initialized
INFO - 2020-03-07 14:54:50 --> Helper loaded: url_helper
INFO - 2020-03-07 14:54:50 --> Helper loaded: string_helper
INFO - 2020-03-07 14:54:50 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:54:50 --> Controller Class Initialized
INFO - 2020-03-07 14:54:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:54:50 --> Pagination Class Initialized
INFO - 2020-03-07 14:54:50 --> Model "M_show" initialized
INFO - 2020-03-07 14:54:50 --> Helper loaded: form_helper
INFO - 2020-03-07 14:54:50 --> Form Validation Class Initialized
INFO - 2020-03-07 14:54:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:54:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 14:54:50 --> Final output sent to browser
DEBUG - 2020-03-07 14:54:50 --> Total execution time: 0.0071
INFO - 2020-03-07 14:54:55 --> Config Class Initialized
INFO - 2020-03-07 14:54:55 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:54:55 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:54:55 --> Utf8 Class Initialized
INFO - 2020-03-07 14:54:55 --> URI Class Initialized
INFO - 2020-03-07 14:54:55 --> Router Class Initialized
INFO - 2020-03-07 14:54:55 --> Output Class Initialized
INFO - 2020-03-07 14:54:55 --> Security Class Initialized
DEBUG - 2020-03-07 14:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:54:55 --> Input Class Initialized
INFO - 2020-03-07 14:54:55 --> Language Class Initialized
INFO - 2020-03-07 14:54:55 --> Loader Class Initialized
INFO - 2020-03-07 14:54:55 --> Helper loaded: url_helper
INFO - 2020-03-07 14:54:55 --> Helper loaded: string_helper
INFO - 2020-03-07 14:54:55 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:54:56 --> Controller Class Initialized
INFO - 2020-03-07 14:54:56 --> Model "M_tiket" initialized
INFO - 2020-03-07 14:54:56 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 14:54:56 --> Model "M_pesan" initialized
INFO - 2020-03-07 14:54:56 --> Helper loaded: form_helper
INFO - 2020-03-07 14:54:56 --> Form Validation Class Initialized
INFO - 2020-03-07 14:54:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 14:54:56 --> Final output sent to browser
DEBUG - 2020-03-07 14:54:56 --> Total execution time: 0.0707
INFO - 2020-03-07 14:55:09 --> Config Class Initialized
INFO - 2020-03-07 14:55:09 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:55:09 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:55:09 --> Utf8 Class Initialized
INFO - 2020-03-07 14:55:09 --> URI Class Initialized
INFO - 2020-03-07 14:55:09 --> Router Class Initialized
INFO - 2020-03-07 14:55:09 --> Output Class Initialized
INFO - 2020-03-07 14:55:09 --> Security Class Initialized
DEBUG - 2020-03-07 14:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:55:09 --> Input Class Initialized
INFO - 2020-03-07 14:55:09 --> Language Class Initialized
INFO - 2020-03-07 14:55:09 --> Loader Class Initialized
INFO - 2020-03-07 14:55:09 --> Helper loaded: url_helper
INFO - 2020-03-07 14:55:09 --> Helper loaded: string_helper
INFO - 2020-03-07 14:55:09 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:55:09 --> Controller Class Initialized
INFO - 2020-03-07 14:55:09 --> Model "M_tiket" initialized
INFO - 2020-03-07 14:55:09 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 14:55:09 --> Model "M_pesan" initialized
INFO - 2020-03-07 14:55:09 --> Helper loaded: form_helper
INFO - 2020-03-07 14:55:09 --> Form Validation Class Initialized
INFO - 2020-03-07 14:55:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 14:55:09 --> Final output sent to browser
DEBUG - 2020-03-07 14:55:09 --> Total execution time: 0.3980
INFO - 2020-03-07 14:55:21 --> Config Class Initialized
INFO - 2020-03-07 14:55:21 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:55:21 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:55:21 --> Utf8 Class Initialized
INFO - 2020-03-07 14:55:21 --> URI Class Initialized
INFO - 2020-03-07 14:55:21 --> Router Class Initialized
INFO - 2020-03-07 14:55:21 --> Output Class Initialized
INFO - 2020-03-07 14:55:21 --> Security Class Initialized
DEBUG - 2020-03-07 14:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:55:21 --> Input Class Initialized
INFO - 2020-03-07 14:55:21 --> Language Class Initialized
INFO - 2020-03-07 14:55:21 --> Loader Class Initialized
INFO - 2020-03-07 14:55:21 --> Helper loaded: url_helper
INFO - 2020-03-07 14:55:21 --> Helper loaded: string_helper
INFO - 2020-03-07 14:55:21 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:55:21 --> Controller Class Initialized
INFO - 2020-03-07 14:55:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:55:21 --> Pagination Class Initialized
INFO - 2020-03-07 14:55:21 --> Model "M_show" initialized
INFO - 2020-03-07 14:55:21 --> Helper loaded: form_helper
INFO - 2020-03-07 14:55:21 --> Form Validation Class Initialized
INFO - 2020-03-07 14:55:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:55:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 14:55:21 --> Final output sent to browser
DEBUG - 2020-03-07 14:55:21 --> Total execution time: 0.0206
INFO - 2020-03-07 14:56:35 --> Config Class Initialized
INFO - 2020-03-07 14:56:35 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:56:35 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:56:35 --> Utf8 Class Initialized
INFO - 2020-03-07 14:56:35 --> URI Class Initialized
DEBUG - 2020-03-07 14:56:35 --> No URI present. Default controller set.
INFO - 2020-03-07 14:56:35 --> Router Class Initialized
INFO - 2020-03-07 14:56:35 --> Output Class Initialized
INFO - 2020-03-07 14:56:35 --> Security Class Initialized
DEBUG - 2020-03-07 14:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:56:35 --> Input Class Initialized
INFO - 2020-03-07 14:56:35 --> Language Class Initialized
INFO - 2020-03-07 14:56:35 --> Loader Class Initialized
INFO - 2020-03-07 14:56:35 --> Helper loaded: url_helper
INFO - 2020-03-07 14:56:35 --> Helper loaded: string_helper
INFO - 2020-03-07 14:56:35 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:56:35 --> Controller Class Initialized
INFO - 2020-03-07 14:56:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:56:35 --> Pagination Class Initialized
INFO - 2020-03-07 14:56:35 --> Model "M_show" initialized
INFO - 2020-03-07 14:56:35 --> Helper loaded: form_helper
INFO - 2020-03-07 14:56:35 --> Form Validation Class Initialized
INFO - 2020-03-07 14:56:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:56:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:56:35 --> Final output sent to browser
DEBUG - 2020-03-07 14:56:35 --> Total execution time: 0.0054
INFO - 2020-03-07 14:56:55 --> Config Class Initialized
INFO - 2020-03-07 14:56:55 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:56:55 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:56:55 --> Utf8 Class Initialized
INFO - 2020-03-07 14:56:55 --> URI Class Initialized
INFO - 2020-03-07 14:56:55 --> Router Class Initialized
INFO - 2020-03-07 14:56:55 --> Output Class Initialized
INFO - 2020-03-07 14:56:55 --> Security Class Initialized
DEBUG - 2020-03-07 14:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:56:55 --> Input Class Initialized
INFO - 2020-03-07 14:56:55 --> Language Class Initialized
INFO - 2020-03-07 14:56:55 --> Loader Class Initialized
INFO - 2020-03-07 14:56:55 --> Helper loaded: url_helper
INFO - 2020-03-07 14:56:55 --> Helper loaded: string_helper
INFO - 2020-03-07 14:56:55 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:56:55 --> Controller Class Initialized
INFO - 2020-03-07 14:56:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:56:55 --> Pagination Class Initialized
INFO - 2020-03-07 14:56:55 --> Model "M_show" initialized
INFO - 2020-03-07 14:56:55 --> Helper loaded: form_helper
INFO - 2020-03-07 14:56:55 --> Form Validation Class Initialized
INFO - 2020-03-07 14:56:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:56:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:56:55 --> Final output sent to browser
DEBUG - 2020-03-07 14:56:55 --> Total execution time: 0.0058
INFO - 2020-03-07 14:56:59 --> Config Class Initialized
INFO - 2020-03-07 14:56:59 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:56:59 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:56:59 --> Utf8 Class Initialized
INFO - 2020-03-07 14:56:59 --> URI Class Initialized
DEBUG - 2020-03-07 14:56:59 --> No URI present. Default controller set.
INFO - 2020-03-07 14:56:59 --> Router Class Initialized
INFO - 2020-03-07 14:56:59 --> Output Class Initialized
INFO - 2020-03-07 14:56:59 --> Security Class Initialized
DEBUG - 2020-03-07 14:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:56:59 --> Input Class Initialized
INFO - 2020-03-07 14:56:59 --> Language Class Initialized
INFO - 2020-03-07 14:56:59 --> Loader Class Initialized
INFO - 2020-03-07 14:56:59 --> Helper loaded: url_helper
INFO - 2020-03-07 14:56:59 --> Helper loaded: string_helper
INFO - 2020-03-07 14:56:59 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:56:59 --> Controller Class Initialized
INFO - 2020-03-07 14:56:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:56:59 --> Pagination Class Initialized
INFO - 2020-03-07 14:56:59 --> Model "M_show" initialized
INFO - 2020-03-07 14:56:59 --> Helper loaded: form_helper
INFO - 2020-03-07 14:56:59 --> Form Validation Class Initialized
INFO - 2020-03-07 14:56:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:56:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:56:59 --> Final output sent to browser
DEBUG - 2020-03-07 14:56:59 --> Total execution time: 0.0321
INFO - 2020-03-07 14:57:02 --> Config Class Initialized
INFO - 2020-03-07 14:57:02 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:57:02 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:57:02 --> Utf8 Class Initialized
INFO - 2020-03-07 14:57:02 --> URI Class Initialized
INFO - 2020-03-07 14:57:02 --> Router Class Initialized
INFO - 2020-03-07 14:57:02 --> Output Class Initialized
INFO - 2020-03-07 14:57:02 --> Security Class Initialized
DEBUG - 2020-03-07 14:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:57:02 --> Input Class Initialized
INFO - 2020-03-07 14:57:02 --> Language Class Initialized
INFO - 2020-03-07 14:57:02 --> Loader Class Initialized
INFO - 2020-03-07 14:57:02 --> Helper loaded: url_helper
INFO - 2020-03-07 14:57:02 --> Helper loaded: string_helper
INFO - 2020-03-07 14:57:02 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:57:02 --> Controller Class Initialized
INFO - 2020-03-07 14:57:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:57:02 --> Pagination Class Initialized
INFO - 2020-03-07 14:57:02 --> Model "M_show" initialized
INFO - 2020-03-07 14:57:02 --> Helper loaded: form_helper
INFO - 2020-03-07 14:57:02 --> Form Validation Class Initialized
INFO - 2020-03-07 14:57:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:57:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 14:57:02 --> Final output sent to browser
DEBUG - 2020-03-07 14:57:02 --> Total execution time: 0.0079
INFO - 2020-03-07 14:57:07 --> Config Class Initialized
INFO - 2020-03-07 14:57:07 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:57:07 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:57:07 --> Utf8 Class Initialized
INFO - 2020-03-07 14:57:07 --> URI Class Initialized
DEBUG - 2020-03-07 14:57:07 --> No URI present. Default controller set.
INFO - 2020-03-07 14:57:07 --> Router Class Initialized
INFO - 2020-03-07 14:57:07 --> Output Class Initialized
INFO - 2020-03-07 14:57:07 --> Security Class Initialized
DEBUG - 2020-03-07 14:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:57:07 --> Input Class Initialized
INFO - 2020-03-07 14:57:07 --> Language Class Initialized
INFO - 2020-03-07 14:57:07 --> Loader Class Initialized
INFO - 2020-03-07 14:57:07 --> Helper loaded: url_helper
INFO - 2020-03-07 14:57:07 --> Helper loaded: string_helper
INFO - 2020-03-07 14:57:07 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:57:07 --> Controller Class Initialized
INFO - 2020-03-07 14:57:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:57:07 --> Pagination Class Initialized
INFO - 2020-03-07 14:57:07 --> Model "M_show" initialized
INFO - 2020-03-07 14:57:07 --> Helper loaded: form_helper
INFO - 2020-03-07 14:57:07 --> Form Validation Class Initialized
INFO - 2020-03-07 14:57:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:57:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:57:07 --> Final output sent to browser
DEBUG - 2020-03-07 14:57:07 --> Total execution time: 0.0059
INFO - 2020-03-07 14:57:09 --> Config Class Initialized
INFO - 2020-03-07 14:57:09 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:57:09 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:57:09 --> Utf8 Class Initialized
INFO - 2020-03-07 14:57:09 --> URI Class Initialized
INFO - 2020-03-07 14:57:09 --> Router Class Initialized
INFO - 2020-03-07 14:57:09 --> Output Class Initialized
INFO - 2020-03-07 14:57:09 --> Security Class Initialized
DEBUG - 2020-03-07 14:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:57:09 --> Input Class Initialized
INFO - 2020-03-07 14:57:09 --> Language Class Initialized
INFO - 2020-03-07 14:57:09 --> Loader Class Initialized
INFO - 2020-03-07 14:57:09 --> Helper loaded: url_helper
INFO - 2020-03-07 14:57:09 --> Helper loaded: string_helper
INFO - 2020-03-07 14:57:09 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:57:09 --> Controller Class Initialized
INFO - 2020-03-07 14:57:09 --> Model "M_tiket" initialized
INFO - 2020-03-07 14:57:09 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 14:57:09 --> Model "M_pesan" initialized
INFO - 2020-03-07 14:57:09 --> Helper loaded: form_helper
INFO - 2020-03-07 14:57:09 --> Form Validation Class Initialized
INFO - 2020-03-07 14:57:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 14:57:09 --> Final output sent to browser
DEBUG - 2020-03-07 14:57:09 --> Total execution time: 0.0081
INFO - 2020-03-07 14:57:35 --> Config Class Initialized
INFO - 2020-03-07 14:57:35 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:57:35 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:57:35 --> Utf8 Class Initialized
INFO - 2020-03-07 14:57:35 --> URI Class Initialized
INFO - 2020-03-07 14:57:35 --> Router Class Initialized
INFO - 2020-03-07 14:57:35 --> Output Class Initialized
INFO - 2020-03-07 14:57:35 --> Security Class Initialized
DEBUG - 2020-03-07 14:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:57:35 --> Input Class Initialized
INFO - 2020-03-07 14:57:35 --> Language Class Initialized
INFO - 2020-03-07 14:57:35 --> Loader Class Initialized
INFO - 2020-03-07 14:57:35 --> Helper loaded: url_helper
INFO - 2020-03-07 14:57:35 --> Helper loaded: string_helper
INFO - 2020-03-07 14:57:35 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:57:35 --> Controller Class Initialized
INFO - 2020-03-07 14:57:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:57:35 --> Pagination Class Initialized
INFO - 2020-03-07 14:57:35 --> Model "M_show" initialized
INFO - 2020-03-07 14:57:35 --> Helper loaded: form_helper
INFO - 2020-03-07 14:57:35 --> Form Validation Class Initialized
INFO - 2020-03-07 14:57:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:57:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 14:57:35 --> Final output sent to browser
DEBUG - 2020-03-07 14:57:35 --> Total execution time: 0.0066
INFO - 2020-03-07 14:57:38 --> Config Class Initialized
INFO - 2020-03-07 14:57:38 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:57:38 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:57:38 --> Utf8 Class Initialized
INFO - 2020-03-07 14:57:38 --> URI Class Initialized
INFO - 2020-03-07 14:57:38 --> Router Class Initialized
INFO - 2020-03-07 14:57:38 --> Output Class Initialized
INFO - 2020-03-07 14:57:38 --> Security Class Initialized
DEBUG - 2020-03-07 14:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:57:38 --> Input Class Initialized
INFO - 2020-03-07 14:57:38 --> Language Class Initialized
INFO - 2020-03-07 14:57:38 --> Loader Class Initialized
INFO - 2020-03-07 14:57:38 --> Helper loaded: url_helper
INFO - 2020-03-07 14:57:38 --> Helper loaded: string_helper
INFO - 2020-03-07 14:57:38 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:57:38 --> Controller Class Initialized
INFO - 2020-03-07 14:57:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:57:38 --> Pagination Class Initialized
INFO - 2020-03-07 14:57:38 --> Model "M_show" initialized
INFO - 2020-03-07 14:57:38 --> Helper loaded: form_helper
INFO - 2020-03-07 14:57:38 --> Form Validation Class Initialized
INFO - 2020-03-07 14:57:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:57:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:57:38 --> Final output sent to browser
DEBUG - 2020-03-07 14:57:38 --> Total execution time: 0.0083
INFO - 2020-03-07 14:57:42 --> Config Class Initialized
INFO - 2020-03-07 14:57:42 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:57:42 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:57:42 --> Utf8 Class Initialized
INFO - 2020-03-07 14:57:42 --> URI Class Initialized
INFO - 2020-03-07 14:57:42 --> Router Class Initialized
INFO - 2020-03-07 14:57:42 --> Output Class Initialized
INFO - 2020-03-07 14:57:42 --> Security Class Initialized
DEBUG - 2020-03-07 14:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:57:42 --> Input Class Initialized
INFO - 2020-03-07 14:57:42 --> Language Class Initialized
INFO - 2020-03-07 14:57:42 --> Loader Class Initialized
INFO - 2020-03-07 14:57:42 --> Helper loaded: url_helper
INFO - 2020-03-07 14:57:42 --> Helper loaded: string_helper
INFO - 2020-03-07 14:57:42 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:57:42 --> Controller Class Initialized
INFO - 2020-03-07 14:57:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:57:42 --> Pagination Class Initialized
INFO - 2020-03-07 14:57:42 --> Model "M_show" initialized
INFO - 2020-03-07 14:57:42 --> Helper loaded: form_helper
INFO - 2020-03-07 14:57:42 --> Form Validation Class Initialized
INFO - 2020-03-07 14:57:42 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:57:42 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-07 14:57:42 --> Final output sent to browser
DEBUG - 2020-03-07 14:57:42 --> Total execution time: 0.1268
INFO - 2020-03-07 14:57:46 --> Config Class Initialized
INFO - 2020-03-07 14:57:46 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:57:46 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:57:46 --> Utf8 Class Initialized
INFO - 2020-03-07 14:57:46 --> URI Class Initialized
INFO - 2020-03-07 14:57:46 --> Router Class Initialized
INFO - 2020-03-07 14:57:46 --> Output Class Initialized
INFO - 2020-03-07 14:57:46 --> Security Class Initialized
DEBUG - 2020-03-07 14:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:57:46 --> Input Class Initialized
INFO - 2020-03-07 14:57:46 --> Language Class Initialized
INFO - 2020-03-07 14:57:46 --> Loader Class Initialized
INFO - 2020-03-07 14:57:46 --> Helper loaded: url_helper
INFO - 2020-03-07 14:57:46 --> Helper loaded: string_helper
INFO - 2020-03-07 14:57:46 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:57:47 --> Controller Class Initialized
INFO - 2020-03-07 14:57:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:57:47 --> Pagination Class Initialized
INFO - 2020-03-07 14:57:47 --> Model "M_show" initialized
INFO - 2020-03-07 14:57:47 --> Helper loaded: form_helper
INFO - 2020-03-07 14:57:47 --> Form Validation Class Initialized
INFO - 2020-03-07 14:57:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:57:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:57:47 --> Final output sent to browser
DEBUG - 2020-03-07 14:57:47 --> Total execution time: 0.1528
INFO - 2020-03-07 14:57:51 --> Config Class Initialized
INFO - 2020-03-07 14:57:51 --> Hooks Class Initialized
DEBUG - 2020-03-07 14:57:51 --> UTF-8 Support Enabled
INFO - 2020-03-07 14:57:51 --> Utf8 Class Initialized
INFO - 2020-03-07 14:57:51 --> URI Class Initialized
DEBUG - 2020-03-07 14:57:51 --> No URI present. Default controller set.
INFO - 2020-03-07 14:57:51 --> Router Class Initialized
INFO - 2020-03-07 14:57:51 --> Output Class Initialized
INFO - 2020-03-07 14:57:51 --> Security Class Initialized
DEBUG - 2020-03-07 14:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 14:57:51 --> Input Class Initialized
INFO - 2020-03-07 14:57:51 --> Language Class Initialized
INFO - 2020-03-07 14:57:51 --> Loader Class Initialized
INFO - 2020-03-07 14:57:51 --> Helper loaded: url_helper
INFO - 2020-03-07 14:57:51 --> Helper loaded: string_helper
INFO - 2020-03-07 14:57:51 --> Database Driver Class Initialized
DEBUG - 2020-03-07 14:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 14:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 14:57:51 --> Controller Class Initialized
INFO - 2020-03-07 14:57:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 14:57:51 --> Pagination Class Initialized
INFO - 2020-03-07 14:57:51 --> Model "M_show" initialized
INFO - 2020-03-07 14:57:51 --> Helper loaded: form_helper
INFO - 2020-03-07 14:57:51 --> Form Validation Class Initialized
INFO - 2020-03-07 14:57:51 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 14:57:51 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 14:57:51 --> Final output sent to browser
DEBUG - 2020-03-07 14:57:51 --> Total execution time: 0.0378
INFO - 2020-03-07 15:00:23 --> Config Class Initialized
INFO - 2020-03-07 15:00:23 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:00:23 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:00:23 --> Utf8 Class Initialized
INFO - 2020-03-07 15:00:23 --> URI Class Initialized
DEBUG - 2020-03-07 15:00:23 --> No URI present. Default controller set.
INFO - 2020-03-07 15:00:23 --> Router Class Initialized
INFO - 2020-03-07 15:00:23 --> Output Class Initialized
INFO - 2020-03-07 15:00:23 --> Security Class Initialized
DEBUG - 2020-03-07 15:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:00:23 --> Input Class Initialized
INFO - 2020-03-07 15:00:23 --> Language Class Initialized
INFO - 2020-03-07 15:00:23 --> Loader Class Initialized
INFO - 2020-03-07 15:00:23 --> Helper loaded: url_helper
INFO - 2020-03-07 15:00:23 --> Helper loaded: string_helper
INFO - 2020-03-07 15:00:23 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:00:23 --> Controller Class Initialized
INFO - 2020-03-07 15:00:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:00:23 --> Pagination Class Initialized
INFO - 2020-03-07 15:00:23 --> Model "M_show" initialized
INFO - 2020-03-07 15:00:23 --> Helper loaded: form_helper
INFO - 2020-03-07 15:00:23 --> Form Validation Class Initialized
INFO - 2020-03-07 15:00:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:00:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 15:00:23 --> Final output sent to browser
DEBUG - 2020-03-07 15:00:23 --> Total execution time: 0.0615
INFO - 2020-03-07 15:00:40 --> Config Class Initialized
INFO - 2020-03-07 15:00:40 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:00:40 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:00:40 --> Utf8 Class Initialized
INFO - 2020-03-07 15:00:40 --> URI Class Initialized
INFO - 2020-03-07 15:00:40 --> Router Class Initialized
INFO - 2020-03-07 15:00:40 --> Output Class Initialized
INFO - 2020-03-07 15:00:40 --> Security Class Initialized
DEBUG - 2020-03-07 15:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:00:40 --> Input Class Initialized
INFO - 2020-03-07 15:00:40 --> Language Class Initialized
INFO - 2020-03-07 15:00:40 --> Loader Class Initialized
INFO - 2020-03-07 15:00:40 --> Helper loaded: url_helper
INFO - 2020-03-07 15:00:40 --> Helper loaded: string_helper
INFO - 2020-03-07 15:00:40 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:00:40 --> Controller Class Initialized
INFO - 2020-03-07 15:00:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:00:40 --> Pagination Class Initialized
INFO - 2020-03-07 15:00:40 --> Model "M_show" initialized
INFO - 2020-03-07 15:00:40 --> Helper loaded: form_helper
INFO - 2020-03-07 15:00:40 --> Form Validation Class Initialized
INFO - 2020-03-07 15:00:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:00:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 15:00:40 --> Final output sent to browser
DEBUG - 2020-03-07 15:00:40 --> Total execution time: 0.0099
INFO - 2020-03-07 15:00:45 --> Config Class Initialized
INFO - 2020-03-07 15:00:45 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:00:45 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:00:45 --> Utf8 Class Initialized
INFO - 2020-03-07 15:00:45 --> URI Class Initialized
INFO - 2020-03-07 15:00:45 --> Router Class Initialized
INFO - 2020-03-07 15:00:45 --> Output Class Initialized
INFO - 2020-03-07 15:00:45 --> Security Class Initialized
DEBUG - 2020-03-07 15:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:00:45 --> Input Class Initialized
INFO - 2020-03-07 15:00:45 --> Language Class Initialized
INFO - 2020-03-07 15:00:45 --> Loader Class Initialized
INFO - 2020-03-07 15:00:45 --> Helper loaded: url_helper
INFO - 2020-03-07 15:00:45 --> Helper loaded: string_helper
INFO - 2020-03-07 15:00:45 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:00:45 --> Controller Class Initialized
INFO - 2020-03-07 15:00:45 --> Model "M_tiket" initialized
INFO - 2020-03-07 15:00:45 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 15:00:45 --> Model "M_pesan" initialized
INFO - 2020-03-07 15:00:45 --> Helper loaded: form_helper
INFO - 2020-03-07 15:00:45 --> Form Validation Class Initialized
INFO - 2020-03-07 15:00:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 15:00:45 --> Final output sent to browser
DEBUG - 2020-03-07 15:00:45 --> Total execution time: 0.0120
INFO - 2020-03-07 15:01:03 --> Config Class Initialized
INFO - 2020-03-07 15:01:03 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:01:03 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:01:03 --> Utf8 Class Initialized
INFO - 2020-03-07 15:01:03 --> URI Class Initialized
INFO - 2020-03-07 15:01:03 --> Router Class Initialized
INFO - 2020-03-07 15:01:03 --> Output Class Initialized
INFO - 2020-03-07 15:01:03 --> Security Class Initialized
DEBUG - 2020-03-07 15:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:01:03 --> Input Class Initialized
INFO - 2020-03-07 15:01:03 --> Language Class Initialized
INFO - 2020-03-07 15:01:03 --> Loader Class Initialized
INFO - 2020-03-07 15:01:03 --> Helper loaded: url_helper
INFO - 2020-03-07 15:01:03 --> Helper loaded: string_helper
INFO - 2020-03-07 15:01:03 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:01:03 --> Controller Class Initialized
INFO - 2020-03-07 15:01:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:01:03 --> Pagination Class Initialized
INFO - 2020-03-07 15:01:03 --> Model "M_show" initialized
INFO - 2020-03-07 15:01:03 --> Helper loaded: form_helper
INFO - 2020-03-07 15:01:03 --> Form Validation Class Initialized
INFO - 2020-03-07 15:01:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:01:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 15:01:03 --> Final output sent to browser
DEBUG - 2020-03-07 15:01:03 --> Total execution time: 0.0080
INFO - 2020-03-07 15:01:04 --> Config Class Initialized
INFO - 2020-03-07 15:01:04 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:01:04 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:01:04 --> Utf8 Class Initialized
INFO - 2020-03-07 15:01:04 --> URI Class Initialized
DEBUG - 2020-03-07 15:01:04 --> No URI present. Default controller set.
INFO - 2020-03-07 15:01:04 --> Router Class Initialized
INFO - 2020-03-07 15:01:04 --> Output Class Initialized
INFO - 2020-03-07 15:01:04 --> Security Class Initialized
DEBUG - 2020-03-07 15:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:01:04 --> Input Class Initialized
INFO - 2020-03-07 15:01:04 --> Language Class Initialized
INFO - 2020-03-07 15:01:04 --> Loader Class Initialized
INFO - 2020-03-07 15:01:04 --> Helper loaded: url_helper
INFO - 2020-03-07 15:01:04 --> Helper loaded: string_helper
INFO - 2020-03-07 15:01:04 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:01:04 --> Controller Class Initialized
INFO - 2020-03-07 15:01:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:01:04 --> Pagination Class Initialized
INFO - 2020-03-07 15:01:04 --> Model "M_show" initialized
INFO - 2020-03-07 15:01:04 --> Helper loaded: form_helper
INFO - 2020-03-07 15:01:04 --> Form Validation Class Initialized
INFO - 2020-03-07 15:01:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:01:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 15:01:04 --> Final output sent to browser
DEBUG - 2020-03-07 15:01:04 --> Total execution time: 0.0067
INFO - 2020-03-07 15:08:26 --> Config Class Initialized
INFO - 2020-03-07 15:08:26 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:08:26 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:08:26 --> Utf8 Class Initialized
INFO - 2020-03-07 15:08:26 --> URI Class Initialized
DEBUG - 2020-03-07 15:08:26 --> No URI present. Default controller set.
INFO - 2020-03-07 15:08:26 --> Router Class Initialized
INFO - 2020-03-07 15:08:26 --> Output Class Initialized
INFO - 2020-03-07 15:08:26 --> Security Class Initialized
DEBUG - 2020-03-07 15:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:08:26 --> Input Class Initialized
INFO - 2020-03-07 15:08:26 --> Language Class Initialized
INFO - 2020-03-07 15:08:26 --> Loader Class Initialized
INFO - 2020-03-07 15:08:26 --> Helper loaded: url_helper
INFO - 2020-03-07 15:08:26 --> Helper loaded: string_helper
INFO - 2020-03-07 15:08:26 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:08:26 --> Controller Class Initialized
INFO - 2020-03-07 15:08:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:08:26 --> Pagination Class Initialized
INFO - 2020-03-07 15:08:26 --> Model "M_show" initialized
INFO - 2020-03-07 15:08:26 --> Helper loaded: form_helper
INFO - 2020-03-07 15:08:26 --> Form Validation Class Initialized
INFO - 2020-03-07 15:08:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:08:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 15:08:26 --> Final output sent to browser
DEBUG - 2020-03-07 15:08:26 --> Total execution time: 0.0626
INFO - 2020-03-07 15:08:38 --> Config Class Initialized
INFO - 2020-03-07 15:08:38 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:08:38 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:08:38 --> Utf8 Class Initialized
INFO - 2020-03-07 15:08:38 --> URI Class Initialized
INFO - 2020-03-07 15:08:38 --> Router Class Initialized
INFO - 2020-03-07 15:08:38 --> Output Class Initialized
INFO - 2020-03-07 15:08:38 --> Security Class Initialized
DEBUG - 2020-03-07 15:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:08:38 --> Input Class Initialized
INFO - 2020-03-07 15:08:38 --> Language Class Initialized
INFO - 2020-03-07 15:08:38 --> Loader Class Initialized
INFO - 2020-03-07 15:08:38 --> Helper loaded: url_helper
INFO - 2020-03-07 15:08:38 --> Helper loaded: string_helper
INFO - 2020-03-07 15:08:38 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:08:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:08:38 --> Controller Class Initialized
INFO - 2020-03-07 15:08:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:08:38 --> Pagination Class Initialized
INFO - 2020-03-07 15:08:38 --> Model "M_show" initialized
INFO - 2020-03-07 15:08:38 --> Helper loaded: form_helper
INFO - 2020-03-07 15:08:38 --> Form Validation Class Initialized
INFO - 2020-03-07 15:08:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:08:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 15:08:38 --> Final output sent to browser
DEBUG - 2020-03-07 15:08:38 --> Total execution time: 0.0387
INFO - 2020-03-07 15:08:43 --> Config Class Initialized
INFO - 2020-03-07 15:08:43 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:08:43 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:08:43 --> Utf8 Class Initialized
INFO - 2020-03-07 15:08:43 --> URI Class Initialized
INFO - 2020-03-07 15:08:43 --> Router Class Initialized
INFO - 2020-03-07 15:08:43 --> Output Class Initialized
INFO - 2020-03-07 15:08:43 --> Security Class Initialized
DEBUG - 2020-03-07 15:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:08:43 --> Input Class Initialized
INFO - 2020-03-07 15:08:43 --> Language Class Initialized
INFO - 2020-03-07 15:08:43 --> Loader Class Initialized
INFO - 2020-03-07 15:08:43 --> Helper loaded: url_helper
INFO - 2020-03-07 15:08:43 --> Helper loaded: string_helper
INFO - 2020-03-07 15:08:43 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:08:43 --> Controller Class Initialized
INFO - 2020-03-07 15:08:43 --> Model "M_tiket" initialized
INFO - 2020-03-07 15:08:43 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 15:08:43 --> Model "M_pesan" initialized
INFO - 2020-03-07 15:08:43 --> Helper loaded: form_helper
INFO - 2020-03-07 15:08:43 --> Form Validation Class Initialized
INFO - 2020-03-07 15:08:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 15:08:43 --> Final output sent to browser
DEBUG - 2020-03-07 15:08:43 --> Total execution time: 0.0124
INFO - 2020-03-07 15:08:55 --> Config Class Initialized
INFO - 2020-03-07 15:08:55 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:08:55 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:08:55 --> Utf8 Class Initialized
INFO - 2020-03-07 15:08:55 --> URI Class Initialized
INFO - 2020-03-07 15:08:55 --> Router Class Initialized
INFO - 2020-03-07 15:08:55 --> Output Class Initialized
INFO - 2020-03-07 15:08:55 --> Security Class Initialized
DEBUG - 2020-03-07 15:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:08:55 --> Input Class Initialized
INFO - 2020-03-07 15:08:55 --> Language Class Initialized
INFO - 2020-03-07 15:08:55 --> Loader Class Initialized
INFO - 2020-03-07 15:08:55 --> Helper loaded: url_helper
INFO - 2020-03-07 15:08:55 --> Helper loaded: string_helper
INFO - 2020-03-07 15:08:55 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:08:55 --> Controller Class Initialized
INFO - 2020-03-07 15:08:55 --> Model "M_tiket" initialized
INFO - 2020-03-07 15:08:55 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 15:08:55 --> Model "M_pesan" initialized
INFO - 2020-03-07 15:08:55 --> Helper loaded: form_helper
INFO - 2020-03-07 15:08:55 --> Form Validation Class Initialized
INFO - 2020-03-07 15:08:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 15:08:55 --> Final output sent to browser
DEBUG - 2020-03-07 15:08:55 --> Total execution time: 0.0109
INFO - 2020-03-07 15:09:40 --> Config Class Initialized
INFO - 2020-03-07 15:09:40 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:09:40 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:09:40 --> Utf8 Class Initialized
INFO - 2020-03-07 15:09:40 --> URI Class Initialized
INFO - 2020-03-07 15:09:40 --> Router Class Initialized
INFO - 2020-03-07 15:09:40 --> Output Class Initialized
INFO - 2020-03-07 15:09:40 --> Security Class Initialized
DEBUG - 2020-03-07 15:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:09:40 --> Input Class Initialized
INFO - 2020-03-07 15:09:40 --> Language Class Initialized
INFO - 2020-03-07 15:09:40 --> Loader Class Initialized
INFO - 2020-03-07 15:09:40 --> Helper loaded: url_helper
INFO - 2020-03-07 15:09:40 --> Helper loaded: string_helper
INFO - 2020-03-07 15:09:40 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:09:40 --> Controller Class Initialized
INFO - 2020-03-07 15:09:40 --> Model "M_tiket" initialized
INFO - 2020-03-07 15:09:40 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 15:09:40 --> Model "M_pesan" initialized
INFO - 2020-03-07 15:09:40 --> Helper loaded: form_helper
INFO - 2020-03-07 15:09:40 --> Form Validation Class Initialized
DEBUG - 2020-03-07 15:09:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-07 15:09:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-07 22:09:40 --> Final output sent to browser
DEBUG - 2020-03-07 22:09:40 --> Total execution time: 0.1688
INFO - 2020-03-07 15:09:41 --> Config Class Initialized
INFO - 2020-03-07 15:09:41 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:09:41 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:09:41 --> Utf8 Class Initialized
INFO - 2020-03-07 15:09:41 --> URI Class Initialized
INFO - 2020-03-07 15:09:41 --> Router Class Initialized
INFO - 2020-03-07 15:09:41 --> Output Class Initialized
INFO - 2020-03-07 15:09:41 --> Security Class Initialized
DEBUG - 2020-03-07 15:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:09:41 --> Input Class Initialized
INFO - 2020-03-07 15:09:41 --> Language Class Initialized
INFO - 2020-03-07 15:09:41 --> Loader Class Initialized
INFO - 2020-03-07 15:09:41 --> Helper loaded: url_helper
INFO - 2020-03-07 15:09:41 --> Helper loaded: string_helper
INFO - 2020-03-07 15:09:41 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:09:41 --> Controller Class Initialized
INFO - 2020-03-07 15:09:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:09:41 --> Pagination Class Initialized
INFO - 2020-03-07 15:09:41 --> Model "M_show" initialized
INFO - 2020-03-07 15:09:41 --> Helper loaded: form_helper
INFO - 2020-03-07 15:09:41 --> Form Validation Class Initialized
INFO - 2020-03-07 15:09:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:09:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 15:09:41 --> Final output sent to browser
DEBUG - 2020-03-07 15:09:41 --> Total execution time: 0.0062
INFO - 2020-03-07 15:10:11 --> Config Class Initialized
INFO - 2020-03-07 15:10:11 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:10:11 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:10:11 --> Utf8 Class Initialized
INFO - 2020-03-07 15:10:11 --> URI Class Initialized
INFO - 2020-03-07 15:10:11 --> Router Class Initialized
INFO - 2020-03-07 15:10:11 --> Output Class Initialized
INFO - 2020-03-07 15:10:11 --> Security Class Initialized
DEBUG - 2020-03-07 15:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:10:11 --> Input Class Initialized
INFO - 2020-03-07 15:10:11 --> Language Class Initialized
INFO - 2020-03-07 15:10:11 --> Loader Class Initialized
INFO - 2020-03-07 15:10:11 --> Helper loaded: url_helper
INFO - 2020-03-07 15:10:11 --> Helper loaded: string_helper
INFO - 2020-03-07 15:10:11 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:10:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:10:11 --> Controller Class Initialized
INFO - 2020-03-07 15:10:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:10:11 --> Pagination Class Initialized
INFO - 2020-03-07 15:10:11 --> Model "M_show" initialized
INFO - 2020-03-07 15:10:11 --> Helper loaded: form_helper
INFO - 2020-03-07 15:10:11 --> Form Validation Class Initialized
INFO - 2020-03-07 15:10:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:10:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 15:10:11 --> Final output sent to browser
DEBUG - 2020-03-07 15:10:11 --> Total execution time: 0.0088
INFO - 2020-03-07 15:10:16 --> Config Class Initialized
INFO - 2020-03-07 15:10:16 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:10:16 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:10:16 --> Utf8 Class Initialized
INFO - 2020-03-07 15:10:16 --> URI Class Initialized
INFO - 2020-03-07 15:10:16 --> Router Class Initialized
INFO - 2020-03-07 15:10:16 --> Output Class Initialized
INFO - 2020-03-07 15:10:16 --> Security Class Initialized
DEBUG - 2020-03-07 15:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:10:16 --> Input Class Initialized
INFO - 2020-03-07 15:10:16 --> Language Class Initialized
INFO - 2020-03-07 15:10:16 --> Loader Class Initialized
INFO - 2020-03-07 15:10:16 --> Helper loaded: url_helper
INFO - 2020-03-07 15:10:16 --> Helper loaded: string_helper
INFO - 2020-03-07 15:10:16 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:10:16 --> Controller Class Initialized
INFO - 2020-03-07 15:10:16 --> Model "M_tiket" initialized
INFO - 2020-03-07 15:10:16 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 15:10:16 --> Model "M_pesan" initialized
INFO - 2020-03-07 15:10:16 --> Helper loaded: form_helper
INFO - 2020-03-07 15:10:16 --> Form Validation Class Initialized
INFO - 2020-03-07 15:10:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 15:10:16 --> Final output sent to browser
DEBUG - 2020-03-07 15:10:16 --> Total execution time: 0.0090
INFO - 2020-03-07 15:10:27 --> Config Class Initialized
INFO - 2020-03-07 15:10:27 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:10:27 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:10:27 --> Utf8 Class Initialized
INFO - 2020-03-07 15:10:27 --> URI Class Initialized
INFO - 2020-03-07 15:10:27 --> Router Class Initialized
INFO - 2020-03-07 15:10:27 --> Output Class Initialized
INFO - 2020-03-07 15:10:27 --> Security Class Initialized
DEBUG - 2020-03-07 15:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:10:27 --> Input Class Initialized
INFO - 2020-03-07 15:10:27 --> Language Class Initialized
INFO - 2020-03-07 15:10:27 --> Loader Class Initialized
INFO - 2020-03-07 15:10:27 --> Helper loaded: url_helper
INFO - 2020-03-07 15:10:27 --> Helper loaded: string_helper
INFO - 2020-03-07 15:10:27 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:10:27 --> Controller Class Initialized
INFO - 2020-03-07 15:10:27 --> Model "M_tiket" initialized
INFO - 2020-03-07 15:10:27 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 15:10:27 --> Model "M_pesan" initialized
INFO - 2020-03-07 15:10:27 --> Helper loaded: form_helper
INFO - 2020-03-07 15:10:27 --> Form Validation Class Initialized
INFO - 2020-03-07 15:10:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 15:10:27 --> Final output sent to browser
DEBUG - 2020-03-07 15:10:27 --> Total execution time: 0.0086
INFO - 2020-03-07 15:12:15 --> Config Class Initialized
INFO - 2020-03-07 15:12:15 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:12:15 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:12:15 --> Utf8 Class Initialized
INFO - 2020-03-07 15:12:15 --> URI Class Initialized
INFO - 2020-03-07 15:12:15 --> Router Class Initialized
INFO - 2020-03-07 15:12:15 --> Output Class Initialized
INFO - 2020-03-07 15:12:15 --> Security Class Initialized
DEBUG - 2020-03-07 15:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:12:15 --> Input Class Initialized
INFO - 2020-03-07 15:12:15 --> Language Class Initialized
INFO - 2020-03-07 15:12:15 --> Loader Class Initialized
INFO - 2020-03-07 15:12:15 --> Helper loaded: url_helper
INFO - 2020-03-07 15:12:15 --> Helper loaded: string_helper
INFO - 2020-03-07 15:12:15 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:12:15 --> Controller Class Initialized
INFO - 2020-03-07 15:12:15 --> Model "M_tiket" initialized
INFO - 2020-03-07 15:12:15 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 15:12:15 --> Model "M_pesan" initialized
INFO - 2020-03-07 15:12:15 --> Helper loaded: form_helper
INFO - 2020-03-07 15:12:15 --> Form Validation Class Initialized
INFO - 2020-03-07 15:12:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 15:12:15 --> Final output sent to browser
DEBUG - 2020-03-07 15:12:15 --> Total execution time: 0.0418
INFO - 2020-03-07 15:13:31 --> Config Class Initialized
INFO - 2020-03-07 15:13:31 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:13:31 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:13:31 --> Utf8 Class Initialized
INFO - 2020-03-07 15:13:31 --> URI Class Initialized
INFO - 2020-03-07 15:13:31 --> Router Class Initialized
INFO - 2020-03-07 15:13:31 --> Output Class Initialized
INFO - 2020-03-07 15:13:31 --> Security Class Initialized
DEBUG - 2020-03-07 15:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:13:31 --> Input Class Initialized
INFO - 2020-03-07 15:13:31 --> Language Class Initialized
INFO - 2020-03-07 15:13:31 --> Loader Class Initialized
INFO - 2020-03-07 15:13:31 --> Helper loaded: url_helper
INFO - 2020-03-07 15:13:31 --> Helper loaded: string_helper
INFO - 2020-03-07 15:13:31 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:13:31 --> Controller Class Initialized
INFO - 2020-03-07 15:13:31 --> Model "M_tiket" initialized
INFO - 2020-03-07 15:13:31 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 15:13:31 --> Model "M_pesan" initialized
INFO - 2020-03-07 15:13:31 --> Helper loaded: form_helper
INFO - 2020-03-07 15:13:31 --> Form Validation Class Initialized
INFO - 2020-03-07 15:13:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 15:13:31 --> Final output sent to browser
DEBUG - 2020-03-07 15:13:31 --> Total execution time: 0.0118
INFO - 2020-03-07 15:24:12 --> Config Class Initialized
INFO - 2020-03-07 15:24:12 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:24:12 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:24:12 --> Utf8 Class Initialized
INFO - 2020-03-07 15:24:12 --> URI Class Initialized
DEBUG - 2020-03-07 15:24:12 --> No URI present. Default controller set.
INFO - 2020-03-07 15:24:12 --> Router Class Initialized
INFO - 2020-03-07 15:24:12 --> Output Class Initialized
INFO - 2020-03-07 15:24:12 --> Security Class Initialized
DEBUG - 2020-03-07 15:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:24:12 --> Input Class Initialized
INFO - 2020-03-07 15:24:12 --> Language Class Initialized
INFO - 2020-03-07 15:24:12 --> Loader Class Initialized
INFO - 2020-03-07 15:24:12 --> Helper loaded: url_helper
INFO - 2020-03-07 15:24:12 --> Helper loaded: string_helper
INFO - 2020-03-07 15:24:12 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:24:12 --> Controller Class Initialized
INFO - 2020-03-07 15:24:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:24:12 --> Pagination Class Initialized
INFO - 2020-03-07 15:24:12 --> Model "M_show" initialized
INFO - 2020-03-07 15:24:12 --> Helper loaded: form_helper
INFO - 2020-03-07 15:24:12 --> Form Validation Class Initialized
INFO - 2020-03-07 15:24:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:24:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 15:24:12 --> Final output sent to browser
DEBUG - 2020-03-07 15:24:12 --> Total execution time: 0.0407
INFO - 2020-03-07 15:24:24 --> Config Class Initialized
INFO - 2020-03-07 15:24:24 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:24:24 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:24:24 --> Utf8 Class Initialized
INFO - 2020-03-07 15:24:24 --> URI Class Initialized
INFO - 2020-03-07 15:24:24 --> Router Class Initialized
INFO - 2020-03-07 15:24:24 --> Output Class Initialized
INFO - 2020-03-07 15:24:24 --> Security Class Initialized
DEBUG - 2020-03-07 15:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:24:24 --> Input Class Initialized
INFO - 2020-03-07 15:24:24 --> Language Class Initialized
INFO - 2020-03-07 15:24:24 --> Loader Class Initialized
INFO - 2020-03-07 15:24:24 --> Helper loaded: url_helper
INFO - 2020-03-07 15:24:24 --> Helper loaded: string_helper
INFO - 2020-03-07 15:24:24 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:24:24 --> Controller Class Initialized
INFO - 2020-03-07 15:24:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:24:24 --> Pagination Class Initialized
INFO - 2020-03-07 15:24:24 --> Model "M_show" initialized
INFO - 2020-03-07 15:24:24 --> Helper loaded: form_helper
INFO - 2020-03-07 15:24:24 --> Form Validation Class Initialized
INFO - 2020-03-07 15:24:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:24:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 15:24:24 --> Final output sent to browser
DEBUG - 2020-03-07 15:24:24 --> Total execution time: 0.0138
INFO - 2020-03-07 15:24:25 --> Config Class Initialized
INFO - 2020-03-07 15:24:25 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:24:25 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:24:25 --> Utf8 Class Initialized
INFO - 2020-03-07 15:24:25 --> URI Class Initialized
INFO - 2020-03-07 15:24:25 --> Router Class Initialized
INFO - 2020-03-07 15:24:25 --> Output Class Initialized
INFO - 2020-03-07 15:24:25 --> Security Class Initialized
DEBUG - 2020-03-07 15:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:24:25 --> Input Class Initialized
INFO - 2020-03-07 15:24:25 --> Language Class Initialized
ERROR - 2020-03-07 15:24:25 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-07 15:24:29 --> Config Class Initialized
INFO - 2020-03-07 15:24:29 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:24:29 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:24:29 --> Utf8 Class Initialized
INFO - 2020-03-07 15:24:29 --> URI Class Initialized
INFO - 2020-03-07 15:24:29 --> Router Class Initialized
INFO - 2020-03-07 15:24:29 --> Output Class Initialized
INFO - 2020-03-07 15:24:29 --> Security Class Initialized
DEBUG - 2020-03-07 15:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:24:29 --> Input Class Initialized
INFO - 2020-03-07 15:24:29 --> Language Class Initialized
INFO - 2020-03-07 15:24:29 --> Loader Class Initialized
INFO - 2020-03-07 15:24:29 --> Helper loaded: url_helper
INFO - 2020-03-07 15:24:29 --> Helper loaded: string_helper
INFO - 2020-03-07 15:24:29 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:24:29 --> Controller Class Initialized
INFO - 2020-03-07 15:24:29 --> Model "M_tiket" initialized
INFO - 2020-03-07 15:24:29 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 15:24:29 --> Model "M_pesan" initialized
INFO - 2020-03-07 15:24:29 --> Helper loaded: form_helper
INFO - 2020-03-07 15:24:29 --> Form Validation Class Initialized
INFO - 2020-03-07 15:24:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 15:24:29 --> Final output sent to browser
DEBUG - 2020-03-07 15:24:29 --> Total execution time: 0.0145
INFO - 2020-03-07 15:24:45 --> Config Class Initialized
INFO - 2020-03-07 15:24:45 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:24:45 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:24:45 --> Utf8 Class Initialized
INFO - 2020-03-07 15:24:45 --> URI Class Initialized
DEBUG - 2020-03-07 15:24:45 --> No URI present. Default controller set.
INFO - 2020-03-07 15:24:45 --> Router Class Initialized
INFO - 2020-03-07 15:24:45 --> Output Class Initialized
INFO - 2020-03-07 15:24:45 --> Security Class Initialized
DEBUG - 2020-03-07 15:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:24:45 --> Input Class Initialized
INFO - 2020-03-07 15:24:45 --> Language Class Initialized
INFO - 2020-03-07 15:24:45 --> Loader Class Initialized
INFO - 2020-03-07 15:24:45 --> Helper loaded: url_helper
INFO - 2020-03-07 15:24:45 --> Helper loaded: string_helper
INFO - 2020-03-07 15:24:45 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:24:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:24:45 --> Controller Class Initialized
INFO - 2020-03-07 15:24:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:24:45 --> Pagination Class Initialized
INFO - 2020-03-07 15:24:45 --> Model "M_show" initialized
INFO - 2020-03-07 15:24:45 --> Helper loaded: form_helper
INFO - 2020-03-07 15:24:45 --> Form Validation Class Initialized
INFO - 2020-03-07 15:24:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:24:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 15:24:45 --> Final output sent to browser
DEBUG - 2020-03-07 15:24:45 --> Total execution time: 0.0142
INFO - 2020-03-07 15:24:45 --> Config Class Initialized
INFO - 2020-03-07 15:24:45 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:24:45 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:24:45 --> Utf8 Class Initialized
INFO - 2020-03-07 15:24:45 --> URI Class Initialized
DEBUG - 2020-03-07 15:24:45 --> No URI present. Default controller set.
INFO - 2020-03-07 15:24:45 --> Router Class Initialized
INFO - 2020-03-07 15:24:45 --> Output Class Initialized
INFO - 2020-03-07 15:24:45 --> Security Class Initialized
DEBUG - 2020-03-07 15:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:24:45 --> Input Class Initialized
INFO - 2020-03-07 15:24:45 --> Language Class Initialized
INFO - 2020-03-07 15:24:45 --> Loader Class Initialized
INFO - 2020-03-07 15:24:45 --> Helper loaded: url_helper
INFO - 2020-03-07 15:24:45 --> Helper loaded: string_helper
INFO - 2020-03-07 15:24:45 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:24:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:24:45 --> Controller Class Initialized
INFO - 2020-03-07 15:24:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:24:45 --> Pagination Class Initialized
INFO - 2020-03-07 15:24:45 --> Model "M_show" initialized
INFO - 2020-03-07 15:24:45 --> Helper loaded: form_helper
INFO - 2020-03-07 15:24:45 --> Form Validation Class Initialized
INFO - 2020-03-07 15:24:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:24:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 15:24:45 --> Final output sent to browser
DEBUG - 2020-03-07 15:24:45 --> Total execution time: 0.0055
INFO - 2020-03-07 15:24:51 --> Config Class Initialized
INFO - 2020-03-07 15:24:51 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:24:51 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:24:51 --> Utf8 Class Initialized
INFO - 2020-03-07 15:24:51 --> URI Class Initialized
INFO - 2020-03-07 15:24:51 --> Router Class Initialized
INFO - 2020-03-07 15:24:51 --> Output Class Initialized
INFO - 2020-03-07 15:24:51 --> Security Class Initialized
DEBUG - 2020-03-07 15:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:24:51 --> Input Class Initialized
INFO - 2020-03-07 15:24:51 --> Language Class Initialized
INFO - 2020-03-07 15:24:51 --> Loader Class Initialized
INFO - 2020-03-07 15:24:51 --> Helper loaded: url_helper
INFO - 2020-03-07 15:24:51 --> Helper loaded: string_helper
INFO - 2020-03-07 15:24:51 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:24:51 --> Controller Class Initialized
INFO - 2020-03-07 15:24:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:24:51 --> Pagination Class Initialized
INFO - 2020-03-07 15:24:51 --> Model "M_show" initialized
INFO - 2020-03-07 15:24:51 --> Helper loaded: form_helper
INFO - 2020-03-07 15:24:51 --> Form Validation Class Initialized
INFO - 2020-03-07 15:24:51 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:24:51 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 15:24:51 --> Final output sent to browser
DEBUG - 2020-03-07 15:24:51 --> Total execution time: 0.0062
INFO - 2020-03-07 15:24:51 --> Config Class Initialized
INFO - 2020-03-07 15:24:51 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:24:51 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:24:51 --> Utf8 Class Initialized
INFO - 2020-03-07 15:24:51 --> URI Class Initialized
INFO - 2020-03-07 15:24:51 --> Router Class Initialized
INFO - 2020-03-07 15:24:51 --> Output Class Initialized
INFO - 2020-03-07 15:24:51 --> Security Class Initialized
DEBUG - 2020-03-07 15:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:24:51 --> Input Class Initialized
INFO - 2020-03-07 15:24:51 --> Language Class Initialized
ERROR - 2020-03-07 15:24:51 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-07 15:24:54 --> Config Class Initialized
INFO - 2020-03-07 15:24:54 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:24:54 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:24:54 --> Utf8 Class Initialized
INFO - 2020-03-07 15:24:54 --> URI Class Initialized
INFO - 2020-03-07 15:24:54 --> Router Class Initialized
INFO - 2020-03-07 15:24:54 --> Output Class Initialized
INFO - 2020-03-07 15:24:54 --> Security Class Initialized
DEBUG - 2020-03-07 15:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:24:54 --> Input Class Initialized
INFO - 2020-03-07 15:24:54 --> Language Class Initialized
INFO - 2020-03-07 15:24:54 --> Loader Class Initialized
INFO - 2020-03-07 15:24:54 --> Helper loaded: url_helper
INFO - 2020-03-07 15:24:54 --> Helper loaded: string_helper
INFO - 2020-03-07 15:24:54 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:24:54 --> Controller Class Initialized
INFO - 2020-03-07 15:24:54 --> Model "M_tiket" initialized
INFO - 2020-03-07 15:24:54 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 15:24:54 --> Model "M_pesan" initialized
INFO - 2020-03-07 15:24:54 --> Helper loaded: form_helper
INFO - 2020-03-07 15:24:54 --> Form Validation Class Initialized
INFO - 2020-03-07 15:24:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 15:24:54 --> Final output sent to browser
DEBUG - 2020-03-07 15:24:54 --> Total execution time: 0.0077
INFO - 2020-03-07 15:25:15 --> Config Class Initialized
INFO - 2020-03-07 15:25:15 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:25:15 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:25:15 --> Utf8 Class Initialized
INFO - 2020-03-07 15:25:15 --> URI Class Initialized
INFO - 2020-03-07 15:25:15 --> Router Class Initialized
INFO - 2020-03-07 15:25:15 --> Output Class Initialized
INFO - 2020-03-07 15:25:15 --> Security Class Initialized
DEBUG - 2020-03-07 15:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:25:15 --> Input Class Initialized
INFO - 2020-03-07 15:25:15 --> Language Class Initialized
INFO - 2020-03-07 15:25:15 --> Loader Class Initialized
INFO - 2020-03-07 15:25:15 --> Helper loaded: url_helper
INFO - 2020-03-07 15:25:15 --> Helper loaded: string_helper
INFO - 2020-03-07 15:25:15 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:25:15 --> Controller Class Initialized
INFO - 2020-03-07 15:25:15 --> Model "M_tiket" initialized
INFO - 2020-03-07 15:25:15 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 15:25:15 --> Model "M_pesan" initialized
INFO - 2020-03-07 15:25:15 --> Helper loaded: form_helper
INFO - 2020-03-07 15:25:15 --> Form Validation Class Initialized
INFO - 2020-03-07 15:25:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 15:25:15 --> Final output sent to browser
DEBUG - 2020-03-07 15:25:15 --> Total execution time: 0.0078
INFO - 2020-03-07 15:27:18 --> Config Class Initialized
INFO - 2020-03-07 15:27:18 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:27:18 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:27:18 --> Utf8 Class Initialized
INFO - 2020-03-07 15:27:18 --> URI Class Initialized
DEBUG - 2020-03-07 15:27:18 --> No URI present. Default controller set.
INFO - 2020-03-07 15:27:18 --> Router Class Initialized
INFO - 2020-03-07 15:27:18 --> Output Class Initialized
INFO - 2020-03-07 15:27:18 --> Security Class Initialized
DEBUG - 2020-03-07 15:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:27:18 --> Input Class Initialized
INFO - 2020-03-07 15:27:18 --> Language Class Initialized
INFO - 2020-03-07 15:27:18 --> Loader Class Initialized
INFO - 2020-03-07 15:27:18 --> Helper loaded: url_helper
INFO - 2020-03-07 15:27:18 --> Helper loaded: string_helper
INFO - 2020-03-07 15:27:18 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:27:18 --> Controller Class Initialized
INFO - 2020-03-07 15:27:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:27:18 --> Pagination Class Initialized
INFO - 2020-03-07 15:27:18 --> Model "M_show" initialized
INFO - 2020-03-07 15:27:18 --> Helper loaded: form_helper
INFO - 2020-03-07 15:27:18 --> Form Validation Class Initialized
INFO - 2020-03-07 15:27:18 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:27:18 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 15:27:18 --> Final output sent to browser
DEBUG - 2020-03-07 15:27:18 --> Total execution time: 0.0439
INFO - 2020-03-07 15:27:37 --> Config Class Initialized
INFO - 2020-03-07 15:27:37 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:27:37 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:27:37 --> Utf8 Class Initialized
INFO - 2020-03-07 15:27:37 --> URI Class Initialized
INFO - 2020-03-07 15:27:37 --> Router Class Initialized
INFO - 2020-03-07 15:27:37 --> Output Class Initialized
INFO - 2020-03-07 15:27:37 --> Security Class Initialized
DEBUG - 2020-03-07 15:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:27:37 --> Input Class Initialized
INFO - 2020-03-07 15:27:37 --> Language Class Initialized
INFO - 2020-03-07 15:27:37 --> Loader Class Initialized
INFO - 2020-03-07 15:27:37 --> Helper loaded: url_helper
INFO - 2020-03-07 15:27:37 --> Helper loaded: string_helper
INFO - 2020-03-07 15:27:37 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:27:37 --> Controller Class Initialized
INFO - 2020-03-07 15:27:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:27:37 --> Pagination Class Initialized
INFO - 2020-03-07 15:27:37 --> Model "M_show" initialized
INFO - 2020-03-07 15:27:37 --> Helper loaded: form_helper
INFO - 2020-03-07 15:27:37 --> Form Validation Class Initialized
INFO - 2020-03-07 15:27:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:27:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 15:27:37 --> Final output sent to browser
DEBUG - 2020-03-07 15:27:37 --> Total execution time: 0.0078
INFO - 2020-03-07 15:27:43 --> Config Class Initialized
INFO - 2020-03-07 15:27:43 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:27:43 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:27:43 --> Utf8 Class Initialized
INFO - 2020-03-07 15:27:43 --> URI Class Initialized
INFO - 2020-03-07 15:27:43 --> Router Class Initialized
INFO - 2020-03-07 15:27:43 --> Output Class Initialized
INFO - 2020-03-07 15:27:43 --> Security Class Initialized
DEBUG - 2020-03-07 15:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:27:43 --> Input Class Initialized
INFO - 2020-03-07 15:27:43 --> Language Class Initialized
INFO - 2020-03-07 15:27:43 --> Loader Class Initialized
INFO - 2020-03-07 15:27:43 --> Helper loaded: url_helper
INFO - 2020-03-07 15:27:43 --> Helper loaded: string_helper
INFO - 2020-03-07 15:27:43 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:27:43 --> Controller Class Initialized
INFO - 2020-03-07 15:27:43 --> Model "M_tiket" initialized
INFO - 2020-03-07 15:27:43 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 15:27:43 --> Model "M_pesan" initialized
INFO - 2020-03-07 15:27:43 --> Helper loaded: form_helper
INFO - 2020-03-07 15:27:43 --> Form Validation Class Initialized
INFO - 2020-03-07 15:27:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 15:27:43 --> Final output sent to browser
DEBUG - 2020-03-07 15:27:43 --> Total execution time: 0.0140
INFO - 2020-03-07 15:28:16 --> Config Class Initialized
INFO - 2020-03-07 15:28:16 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:28:16 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:28:16 --> Utf8 Class Initialized
INFO - 2020-03-07 15:28:16 --> URI Class Initialized
INFO - 2020-03-07 15:28:16 --> Router Class Initialized
INFO - 2020-03-07 15:28:16 --> Output Class Initialized
INFO - 2020-03-07 15:28:16 --> Security Class Initialized
DEBUG - 2020-03-07 15:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:28:16 --> Input Class Initialized
INFO - 2020-03-07 15:28:16 --> Language Class Initialized
INFO - 2020-03-07 15:28:16 --> Loader Class Initialized
INFO - 2020-03-07 15:28:16 --> Helper loaded: url_helper
INFO - 2020-03-07 15:28:16 --> Helper loaded: string_helper
INFO - 2020-03-07 15:28:16 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:28:16 --> Controller Class Initialized
INFO - 2020-03-07 15:28:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:28:16 --> Pagination Class Initialized
INFO - 2020-03-07 15:28:16 --> Model "M_show" initialized
INFO - 2020-03-07 15:28:16 --> Helper loaded: form_helper
INFO - 2020-03-07 15:28:16 --> Form Validation Class Initialized
INFO - 2020-03-07 15:28:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:28:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 15:28:16 --> Final output sent to browser
DEBUG - 2020-03-07 15:28:16 --> Total execution time: 0.0112
INFO - 2020-03-07 15:28:17 --> Config Class Initialized
INFO - 2020-03-07 15:28:17 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:28:17 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:28:17 --> Utf8 Class Initialized
INFO - 2020-03-07 15:28:17 --> URI Class Initialized
DEBUG - 2020-03-07 15:28:17 --> No URI present. Default controller set.
INFO - 2020-03-07 15:28:17 --> Router Class Initialized
INFO - 2020-03-07 15:28:17 --> Output Class Initialized
INFO - 2020-03-07 15:28:17 --> Security Class Initialized
DEBUG - 2020-03-07 15:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:28:17 --> Input Class Initialized
INFO - 2020-03-07 15:28:17 --> Language Class Initialized
INFO - 2020-03-07 15:28:17 --> Loader Class Initialized
INFO - 2020-03-07 15:28:17 --> Helper loaded: url_helper
INFO - 2020-03-07 15:28:17 --> Helper loaded: string_helper
INFO - 2020-03-07 15:28:17 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:28:17 --> Controller Class Initialized
INFO - 2020-03-07 15:28:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:28:17 --> Pagination Class Initialized
INFO - 2020-03-07 15:28:17 --> Model "M_show" initialized
INFO - 2020-03-07 15:28:17 --> Helper loaded: form_helper
INFO - 2020-03-07 15:28:17 --> Form Validation Class Initialized
INFO - 2020-03-07 15:28:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:28:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 15:28:17 --> Final output sent to browser
DEBUG - 2020-03-07 15:28:17 --> Total execution time: 0.0954
INFO - 2020-03-07 15:38:07 --> Config Class Initialized
INFO - 2020-03-07 15:38:07 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:38:07 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:38:07 --> Utf8 Class Initialized
INFO - 2020-03-07 15:38:07 --> URI Class Initialized
DEBUG - 2020-03-07 15:38:07 --> No URI present. Default controller set.
INFO - 2020-03-07 15:38:07 --> Router Class Initialized
INFO - 2020-03-07 15:38:07 --> Output Class Initialized
INFO - 2020-03-07 15:38:07 --> Security Class Initialized
DEBUG - 2020-03-07 15:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:38:08 --> Input Class Initialized
INFO - 2020-03-07 15:38:08 --> Language Class Initialized
INFO - 2020-03-07 15:38:08 --> Loader Class Initialized
INFO - 2020-03-07 15:38:08 --> Helper loaded: url_helper
INFO - 2020-03-07 15:38:08 --> Helper loaded: string_helper
INFO - 2020-03-07 15:38:08 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:38:08 --> Controller Class Initialized
INFO - 2020-03-07 15:38:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:38:08 --> Pagination Class Initialized
INFO - 2020-03-07 15:38:08 --> Model "M_show" initialized
INFO - 2020-03-07 15:38:08 --> Helper loaded: form_helper
INFO - 2020-03-07 15:38:08 --> Form Validation Class Initialized
INFO - 2020-03-07 15:38:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:38:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 15:38:08 --> Final output sent to browser
DEBUG - 2020-03-07 15:38:08 --> Total execution time: 0.0932
INFO - 2020-03-07 15:38:39 --> Config Class Initialized
INFO - 2020-03-07 15:38:39 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:38:39 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:38:39 --> Utf8 Class Initialized
INFO - 2020-03-07 15:38:39 --> URI Class Initialized
INFO - 2020-03-07 15:38:39 --> Router Class Initialized
INFO - 2020-03-07 15:38:39 --> Output Class Initialized
INFO - 2020-03-07 15:38:39 --> Security Class Initialized
DEBUG - 2020-03-07 15:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:38:39 --> Input Class Initialized
INFO - 2020-03-07 15:38:39 --> Language Class Initialized
INFO - 2020-03-07 15:38:39 --> Loader Class Initialized
INFO - 2020-03-07 15:38:39 --> Helper loaded: url_helper
INFO - 2020-03-07 15:38:39 --> Helper loaded: string_helper
INFO - 2020-03-07 15:38:39 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:38:39 --> Controller Class Initialized
INFO - 2020-03-07 15:38:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:38:39 --> Pagination Class Initialized
INFO - 2020-03-07 15:38:39 --> Model "M_show" initialized
INFO - 2020-03-07 15:38:39 --> Helper loaded: form_helper
INFO - 2020-03-07 15:38:39 --> Form Validation Class Initialized
INFO - 2020-03-07 15:38:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:38:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 15:38:39 --> Final output sent to browser
DEBUG - 2020-03-07 15:38:39 --> Total execution time: 0.0077
INFO - 2020-03-07 15:38:40 --> Config Class Initialized
INFO - 2020-03-07 15:38:40 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:38:40 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:38:40 --> Utf8 Class Initialized
INFO - 2020-03-07 15:38:40 --> URI Class Initialized
INFO - 2020-03-07 15:38:40 --> Router Class Initialized
INFO - 2020-03-07 15:38:40 --> Output Class Initialized
INFO - 2020-03-07 15:38:40 --> Security Class Initialized
DEBUG - 2020-03-07 15:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:38:40 --> Input Class Initialized
INFO - 2020-03-07 15:38:40 --> Language Class Initialized
ERROR - 2020-03-07 15:38:40 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-07 15:38:50 --> Config Class Initialized
INFO - 2020-03-07 15:38:50 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:38:50 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:38:50 --> Utf8 Class Initialized
INFO - 2020-03-07 15:38:50 --> URI Class Initialized
INFO - 2020-03-07 15:38:50 --> Router Class Initialized
INFO - 2020-03-07 15:38:50 --> Output Class Initialized
INFO - 2020-03-07 15:38:50 --> Security Class Initialized
DEBUG - 2020-03-07 15:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:38:50 --> Input Class Initialized
INFO - 2020-03-07 15:38:50 --> Language Class Initialized
INFO - 2020-03-07 15:38:50 --> Loader Class Initialized
INFO - 2020-03-07 15:38:50 --> Helper loaded: url_helper
INFO - 2020-03-07 15:38:50 --> Helper loaded: string_helper
INFO - 2020-03-07 15:38:50 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:38:50 --> Controller Class Initialized
INFO - 2020-03-07 15:38:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:38:50 --> Pagination Class Initialized
INFO - 2020-03-07 15:38:50 --> Model "M_show" initialized
INFO - 2020-03-07 15:38:50 --> Helper loaded: form_helper
INFO - 2020-03-07 15:38:50 --> Form Validation Class Initialized
INFO - 2020-03-07 15:38:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:38:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 15:38:50 --> Final output sent to browser
DEBUG - 2020-03-07 15:38:50 --> Total execution time: 0.0088
INFO - 2020-03-07 15:38:58 --> Config Class Initialized
INFO - 2020-03-07 15:38:58 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:38:58 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:38:58 --> Utf8 Class Initialized
INFO - 2020-03-07 15:38:58 --> URI Class Initialized
INFO - 2020-03-07 15:38:58 --> Router Class Initialized
INFO - 2020-03-07 15:38:58 --> Output Class Initialized
INFO - 2020-03-07 15:38:58 --> Security Class Initialized
DEBUG - 2020-03-07 15:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:38:58 --> Input Class Initialized
INFO - 2020-03-07 15:38:58 --> Language Class Initialized
INFO - 2020-03-07 15:38:58 --> Loader Class Initialized
INFO - 2020-03-07 15:38:58 --> Helper loaded: url_helper
INFO - 2020-03-07 15:38:58 --> Helper loaded: string_helper
INFO - 2020-03-07 15:38:58 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:38:58 --> Controller Class Initialized
INFO - 2020-03-07 15:38:58 --> Model "M_tiket" initialized
INFO - 2020-03-07 15:38:58 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 15:38:58 --> Model "M_pesan" initialized
INFO - 2020-03-07 15:38:58 --> Helper loaded: form_helper
INFO - 2020-03-07 15:38:58 --> Form Validation Class Initialized
INFO - 2020-03-07 15:38:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 15:38:58 --> Final output sent to browser
DEBUG - 2020-03-07 15:38:58 --> Total execution time: 0.0105
INFO - 2020-03-07 15:39:18 --> Config Class Initialized
INFO - 2020-03-07 15:39:18 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:39:18 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:39:18 --> Utf8 Class Initialized
INFO - 2020-03-07 15:39:18 --> URI Class Initialized
INFO - 2020-03-07 15:39:18 --> Router Class Initialized
INFO - 2020-03-07 15:39:18 --> Output Class Initialized
INFO - 2020-03-07 15:39:18 --> Security Class Initialized
DEBUG - 2020-03-07 15:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:39:18 --> Input Class Initialized
INFO - 2020-03-07 15:39:18 --> Language Class Initialized
INFO - 2020-03-07 15:39:18 --> Loader Class Initialized
INFO - 2020-03-07 15:39:18 --> Helper loaded: url_helper
INFO - 2020-03-07 15:39:18 --> Helper loaded: string_helper
INFO - 2020-03-07 15:39:18 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:39:18 --> Controller Class Initialized
INFO - 2020-03-07 15:39:18 --> Model "M_tiket" initialized
INFO - 2020-03-07 15:39:18 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 15:39:18 --> Model "M_pesan" initialized
INFO - 2020-03-07 15:39:18 --> Helper loaded: form_helper
INFO - 2020-03-07 15:39:18 --> Form Validation Class Initialized
INFO - 2020-03-07 15:39:18 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 15:39:18 --> Final output sent to browser
DEBUG - 2020-03-07 15:39:18 --> Total execution time: 0.0102
INFO - 2020-03-07 15:39:54 --> Config Class Initialized
INFO - 2020-03-07 15:39:54 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:39:54 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:39:54 --> Utf8 Class Initialized
INFO - 2020-03-07 15:39:54 --> URI Class Initialized
DEBUG - 2020-03-07 15:39:54 --> No URI present. Default controller set.
INFO - 2020-03-07 15:39:54 --> Router Class Initialized
INFO - 2020-03-07 15:39:54 --> Output Class Initialized
INFO - 2020-03-07 15:39:54 --> Security Class Initialized
DEBUG - 2020-03-07 15:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:39:54 --> Input Class Initialized
INFO - 2020-03-07 15:39:54 --> Language Class Initialized
INFO - 2020-03-07 15:39:54 --> Loader Class Initialized
INFO - 2020-03-07 15:39:54 --> Helper loaded: url_helper
INFO - 2020-03-07 15:39:54 --> Helper loaded: string_helper
INFO - 2020-03-07 15:39:54 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:39:54 --> Controller Class Initialized
INFO - 2020-03-07 15:39:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:39:54 --> Pagination Class Initialized
INFO - 2020-03-07 15:39:54 --> Model "M_show" initialized
INFO - 2020-03-07 15:39:54 --> Helper loaded: form_helper
INFO - 2020-03-07 15:39:54 --> Form Validation Class Initialized
INFO - 2020-03-07 15:39:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:39:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 15:39:54 --> Final output sent to browser
DEBUG - 2020-03-07 15:39:54 --> Total execution time: 0.0211
INFO - 2020-03-07 15:40:18 --> Config Class Initialized
INFO - 2020-03-07 15:40:18 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:40:18 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:40:18 --> Utf8 Class Initialized
INFO - 2020-03-07 15:40:18 --> URI Class Initialized
INFO - 2020-03-07 15:40:18 --> Router Class Initialized
INFO - 2020-03-07 15:40:18 --> Output Class Initialized
INFO - 2020-03-07 15:40:18 --> Security Class Initialized
DEBUG - 2020-03-07 15:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:40:18 --> Input Class Initialized
INFO - 2020-03-07 15:40:18 --> Language Class Initialized
INFO - 2020-03-07 15:40:18 --> Loader Class Initialized
INFO - 2020-03-07 15:40:18 --> Helper loaded: url_helper
INFO - 2020-03-07 15:40:18 --> Helper loaded: string_helper
INFO - 2020-03-07 15:40:18 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:40:18 --> Controller Class Initialized
INFO - 2020-03-07 15:40:18 --> Model "M_tiket" initialized
INFO - 2020-03-07 15:40:18 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 15:40:18 --> Model "M_pesan" initialized
INFO - 2020-03-07 15:40:18 --> Helper loaded: form_helper
INFO - 2020-03-07 15:40:18 --> Form Validation Class Initialized
INFO - 2020-03-07 15:40:18 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 15:40:18 --> Final output sent to browser
DEBUG - 2020-03-07 15:40:18 --> Total execution time: 0.0872
INFO - 2020-03-07 15:40:21 --> Config Class Initialized
INFO - 2020-03-07 15:40:21 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:40:21 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:40:21 --> Utf8 Class Initialized
INFO - 2020-03-07 15:40:21 --> URI Class Initialized
INFO - 2020-03-07 15:40:21 --> Router Class Initialized
INFO - 2020-03-07 15:40:21 --> Output Class Initialized
INFO - 2020-03-07 15:40:21 --> Security Class Initialized
DEBUG - 2020-03-07 15:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:40:21 --> Input Class Initialized
INFO - 2020-03-07 15:40:21 --> Language Class Initialized
INFO - 2020-03-07 15:40:21 --> Loader Class Initialized
INFO - 2020-03-07 15:40:21 --> Helper loaded: url_helper
INFO - 2020-03-07 15:40:21 --> Helper loaded: string_helper
INFO - 2020-03-07 15:40:21 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:40:21 --> Controller Class Initialized
INFO - 2020-03-07 15:40:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:40:21 --> Pagination Class Initialized
INFO - 2020-03-07 15:40:21 --> Model "M_show" initialized
INFO - 2020-03-07 15:40:21 --> Helper loaded: form_helper
INFO - 2020-03-07 15:40:21 --> Form Validation Class Initialized
INFO - 2020-03-07 15:40:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:40:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 15:40:21 --> Final output sent to browser
DEBUG - 2020-03-07 15:40:21 --> Total execution time: 0.0071
INFO - 2020-03-07 15:40:25 --> Config Class Initialized
INFO - 2020-03-07 15:40:25 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:40:25 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:40:25 --> Utf8 Class Initialized
INFO - 2020-03-07 15:40:25 --> URI Class Initialized
INFO - 2020-03-07 15:40:25 --> Router Class Initialized
INFO - 2020-03-07 15:40:25 --> Output Class Initialized
INFO - 2020-03-07 15:40:25 --> Security Class Initialized
DEBUG - 2020-03-07 15:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:40:25 --> Input Class Initialized
INFO - 2020-03-07 15:40:25 --> Language Class Initialized
INFO - 2020-03-07 15:40:25 --> Loader Class Initialized
INFO - 2020-03-07 15:40:25 --> Helper loaded: url_helper
INFO - 2020-03-07 15:40:25 --> Helper loaded: string_helper
INFO - 2020-03-07 15:40:25 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:40:25 --> Controller Class Initialized
INFO - 2020-03-07 15:40:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:40:25 --> Pagination Class Initialized
INFO - 2020-03-07 15:40:25 --> Model "M_show" initialized
INFO - 2020-03-07 15:40:25 --> Helper loaded: form_helper
INFO - 2020-03-07 15:40:25 --> Form Validation Class Initialized
INFO - 2020-03-07 15:40:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:40:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 15:40:25 --> Final output sent to browser
DEBUG - 2020-03-07 15:40:25 --> Total execution time: 0.0151
INFO - 2020-03-07 15:40:29 --> Config Class Initialized
INFO - 2020-03-07 15:40:29 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:40:29 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:40:29 --> Utf8 Class Initialized
INFO - 2020-03-07 15:40:29 --> URI Class Initialized
DEBUG - 2020-03-07 15:40:29 --> No URI present. Default controller set.
INFO - 2020-03-07 15:40:29 --> Router Class Initialized
INFO - 2020-03-07 15:40:29 --> Output Class Initialized
INFO - 2020-03-07 15:40:29 --> Security Class Initialized
DEBUG - 2020-03-07 15:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:40:29 --> Input Class Initialized
INFO - 2020-03-07 15:40:29 --> Language Class Initialized
INFO - 2020-03-07 15:40:29 --> Loader Class Initialized
INFO - 2020-03-07 15:40:29 --> Helper loaded: url_helper
INFO - 2020-03-07 15:40:29 --> Helper loaded: string_helper
INFO - 2020-03-07 15:40:29 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:40:29 --> Controller Class Initialized
INFO - 2020-03-07 15:40:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:40:29 --> Pagination Class Initialized
INFO - 2020-03-07 15:40:29 --> Model "M_show" initialized
INFO - 2020-03-07 15:40:29 --> Helper loaded: form_helper
INFO - 2020-03-07 15:40:29 --> Form Validation Class Initialized
INFO - 2020-03-07 15:40:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:40:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 15:40:29 --> Final output sent to browser
DEBUG - 2020-03-07 15:40:29 --> Total execution time: 0.5356
INFO - 2020-03-07 15:41:36 --> Config Class Initialized
INFO - 2020-03-07 15:41:36 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:41:36 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:41:36 --> Utf8 Class Initialized
INFO - 2020-03-07 15:41:36 --> URI Class Initialized
DEBUG - 2020-03-07 15:41:36 --> No URI present. Default controller set.
INFO - 2020-03-07 15:41:36 --> Router Class Initialized
INFO - 2020-03-07 15:41:36 --> Output Class Initialized
INFO - 2020-03-07 15:41:36 --> Security Class Initialized
DEBUG - 2020-03-07 15:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:41:36 --> Input Class Initialized
INFO - 2020-03-07 15:41:36 --> Language Class Initialized
INFO - 2020-03-07 15:41:36 --> Loader Class Initialized
INFO - 2020-03-07 15:41:36 --> Helper loaded: url_helper
INFO - 2020-03-07 15:41:36 --> Helper loaded: string_helper
INFO - 2020-03-07 15:41:36 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:41:36 --> Controller Class Initialized
INFO - 2020-03-07 15:41:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:41:36 --> Pagination Class Initialized
INFO - 2020-03-07 15:41:36 --> Model "M_show" initialized
INFO - 2020-03-07 15:41:36 --> Helper loaded: form_helper
INFO - 2020-03-07 15:41:36 --> Form Validation Class Initialized
INFO - 2020-03-07 15:41:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:41:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 15:41:36 --> Final output sent to browser
DEBUG - 2020-03-07 15:41:36 --> Total execution time: 0.0061
INFO - 2020-03-07 15:41:48 --> Config Class Initialized
INFO - 2020-03-07 15:41:48 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:41:48 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:41:48 --> Utf8 Class Initialized
INFO - 2020-03-07 15:41:48 --> URI Class Initialized
INFO - 2020-03-07 15:41:48 --> Router Class Initialized
INFO - 2020-03-07 15:41:48 --> Output Class Initialized
INFO - 2020-03-07 15:41:48 --> Security Class Initialized
DEBUG - 2020-03-07 15:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:41:48 --> Input Class Initialized
INFO - 2020-03-07 15:41:48 --> Language Class Initialized
INFO - 2020-03-07 15:41:48 --> Loader Class Initialized
INFO - 2020-03-07 15:41:48 --> Helper loaded: url_helper
INFO - 2020-03-07 15:41:48 --> Helper loaded: string_helper
INFO - 2020-03-07 15:41:48 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:41:48 --> Controller Class Initialized
INFO - 2020-03-07 15:41:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:41:48 --> Pagination Class Initialized
INFO - 2020-03-07 15:41:48 --> Model "M_show" initialized
INFO - 2020-03-07 15:41:48 --> Helper loaded: form_helper
INFO - 2020-03-07 15:41:48 --> Form Validation Class Initialized
INFO - 2020-03-07 15:41:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:41:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tentang.php
INFO - 2020-03-07 15:41:48 --> Final output sent to browser
DEBUG - 2020-03-07 15:41:48 --> Total execution time: 0.0095
INFO - 2020-03-07 15:41:59 --> Config Class Initialized
INFO - 2020-03-07 15:41:59 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:41:59 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:41:59 --> Utf8 Class Initialized
INFO - 2020-03-07 15:41:59 --> URI Class Initialized
INFO - 2020-03-07 15:41:59 --> Router Class Initialized
INFO - 2020-03-07 15:41:59 --> Output Class Initialized
INFO - 2020-03-07 15:41:59 --> Security Class Initialized
DEBUG - 2020-03-07 15:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:41:59 --> Input Class Initialized
INFO - 2020-03-07 15:41:59 --> Language Class Initialized
INFO - 2020-03-07 15:41:59 --> Loader Class Initialized
INFO - 2020-03-07 15:41:59 --> Helper loaded: url_helper
INFO - 2020-03-07 15:41:59 --> Helper loaded: string_helper
INFO - 2020-03-07 15:41:59 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:41:59 --> Controller Class Initialized
INFO - 2020-03-07 15:41:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:41:59 --> Pagination Class Initialized
INFO - 2020-03-07 15:41:59 --> Model "M_show" initialized
INFO - 2020-03-07 15:41:59 --> Helper loaded: form_helper
INFO - 2020-03-07 15:41:59 --> Form Validation Class Initialized
INFO - 2020-03-07 15:41:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:41:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 15:41:59 --> Final output sent to browser
DEBUG - 2020-03-07 15:41:59 --> Total execution time: 0.0061
INFO - 2020-03-07 15:42:03 --> Config Class Initialized
INFO - 2020-03-07 15:42:03 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:42:03 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:42:03 --> Utf8 Class Initialized
INFO - 2020-03-07 15:42:03 --> URI Class Initialized
INFO - 2020-03-07 15:42:03 --> Router Class Initialized
INFO - 2020-03-07 15:42:03 --> Output Class Initialized
INFO - 2020-03-07 15:42:03 --> Security Class Initialized
DEBUG - 2020-03-07 15:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:42:03 --> Input Class Initialized
INFO - 2020-03-07 15:42:03 --> Language Class Initialized
INFO - 2020-03-07 15:42:03 --> Loader Class Initialized
INFO - 2020-03-07 15:42:03 --> Helper loaded: url_helper
INFO - 2020-03-07 15:42:03 --> Helper loaded: string_helper
INFO - 2020-03-07 15:42:03 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:42:03 --> Controller Class Initialized
INFO - 2020-03-07 15:42:03 --> Model "M_tiket" initialized
INFO - 2020-03-07 15:42:03 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 15:42:03 --> Model "M_pesan" initialized
INFO - 2020-03-07 15:42:03 --> Helper loaded: form_helper
INFO - 2020-03-07 15:42:03 --> Form Validation Class Initialized
INFO - 2020-03-07 15:42:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 15:42:03 --> Final output sent to browser
DEBUG - 2020-03-07 15:42:03 --> Total execution time: 0.0076
INFO - 2020-03-07 15:42:31 --> Config Class Initialized
INFO - 2020-03-07 15:42:31 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:42:31 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:42:31 --> Utf8 Class Initialized
INFO - 2020-03-07 15:42:31 --> URI Class Initialized
DEBUG - 2020-03-07 15:42:31 --> No URI present. Default controller set.
INFO - 2020-03-07 15:42:31 --> Router Class Initialized
INFO - 2020-03-07 15:42:31 --> Output Class Initialized
INFO - 2020-03-07 15:42:31 --> Security Class Initialized
DEBUG - 2020-03-07 15:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:42:31 --> Input Class Initialized
INFO - 2020-03-07 15:42:31 --> Language Class Initialized
INFO - 2020-03-07 15:42:31 --> Loader Class Initialized
INFO - 2020-03-07 15:42:31 --> Helper loaded: url_helper
INFO - 2020-03-07 15:42:31 --> Helper loaded: string_helper
INFO - 2020-03-07 15:42:31 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:42:31 --> Controller Class Initialized
INFO - 2020-03-07 15:42:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:42:31 --> Pagination Class Initialized
INFO - 2020-03-07 15:42:31 --> Model "M_show" initialized
INFO - 2020-03-07 15:42:31 --> Helper loaded: form_helper
INFO - 2020-03-07 15:42:31 --> Form Validation Class Initialized
INFO - 2020-03-07 15:42:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:42:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 15:42:31 --> Final output sent to browser
DEBUG - 2020-03-07 15:42:31 --> Total execution time: 0.0060
INFO - 2020-03-07 15:42:48 --> Config Class Initialized
INFO - 2020-03-07 15:42:48 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:42:48 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:42:48 --> Utf8 Class Initialized
INFO - 2020-03-07 15:42:48 --> URI Class Initialized
INFO - 2020-03-07 15:42:48 --> Router Class Initialized
INFO - 2020-03-07 15:42:48 --> Output Class Initialized
INFO - 2020-03-07 15:42:48 --> Security Class Initialized
DEBUG - 2020-03-07 15:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:42:48 --> Input Class Initialized
INFO - 2020-03-07 15:42:48 --> Language Class Initialized
INFO - 2020-03-07 15:42:48 --> Loader Class Initialized
INFO - 2020-03-07 15:42:48 --> Helper loaded: url_helper
INFO - 2020-03-07 15:42:48 --> Helper loaded: string_helper
INFO - 2020-03-07 15:42:48 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:42:48 --> Controller Class Initialized
INFO - 2020-03-07 15:42:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:42:48 --> Pagination Class Initialized
INFO - 2020-03-07 15:42:48 --> Model "M_show" initialized
INFO - 2020-03-07 15:42:48 --> Helper loaded: form_helper
INFO - 2020-03-07 15:42:48 --> Form Validation Class Initialized
INFO - 2020-03-07 15:42:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:42:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 15:42:48 --> Final output sent to browser
DEBUG - 2020-03-07 15:42:48 --> Total execution time: 0.0061
INFO - 2020-03-07 15:42:53 --> Config Class Initialized
INFO - 2020-03-07 15:42:53 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:42:53 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:42:53 --> Utf8 Class Initialized
INFO - 2020-03-07 15:42:53 --> URI Class Initialized
INFO - 2020-03-07 15:42:53 --> Router Class Initialized
INFO - 2020-03-07 15:42:53 --> Output Class Initialized
INFO - 2020-03-07 15:42:53 --> Security Class Initialized
DEBUG - 2020-03-07 15:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:42:53 --> Input Class Initialized
INFO - 2020-03-07 15:42:53 --> Language Class Initialized
INFO - 2020-03-07 15:42:53 --> Loader Class Initialized
INFO - 2020-03-07 15:42:53 --> Helper loaded: url_helper
INFO - 2020-03-07 15:42:53 --> Helper loaded: string_helper
INFO - 2020-03-07 15:42:53 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:42:53 --> Controller Class Initialized
INFO - 2020-03-07 15:42:53 --> Model "M_tiket" initialized
INFO - 2020-03-07 15:42:53 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 15:42:53 --> Model "M_pesan" initialized
INFO - 2020-03-07 15:42:53 --> Helper loaded: form_helper
INFO - 2020-03-07 15:42:53 --> Form Validation Class Initialized
INFO - 2020-03-07 15:42:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 15:42:53 --> Final output sent to browser
DEBUG - 2020-03-07 15:42:53 --> Total execution time: 0.0066
INFO - 2020-03-07 15:47:45 --> Config Class Initialized
INFO - 2020-03-07 15:47:45 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:47:45 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:47:45 --> Utf8 Class Initialized
INFO - 2020-03-07 15:47:45 --> URI Class Initialized
DEBUG - 2020-03-07 15:47:45 --> No URI present. Default controller set.
INFO - 2020-03-07 15:47:45 --> Router Class Initialized
INFO - 2020-03-07 15:47:45 --> Output Class Initialized
INFO - 2020-03-07 15:47:45 --> Security Class Initialized
DEBUG - 2020-03-07 15:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:47:45 --> Input Class Initialized
INFO - 2020-03-07 15:47:45 --> Language Class Initialized
INFO - 2020-03-07 15:47:45 --> Loader Class Initialized
INFO - 2020-03-07 15:47:45 --> Helper loaded: url_helper
INFO - 2020-03-07 15:47:45 --> Helper loaded: string_helper
INFO - 2020-03-07 15:47:45 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:47:45 --> Controller Class Initialized
INFO - 2020-03-07 15:47:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:47:45 --> Pagination Class Initialized
INFO - 2020-03-07 15:47:45 --> Model "M_show" initialized
INFO - 2020-03-07 15:47:45 --> Helper loaded: form_helper
INFO - 2020-03-07 15:47:45 --> Form Validation Class Initialized
INFO - 2020-03-07 15:47:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:47:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 15:47:45 --> Final output sent to browser
DEBUG - 2020-03-07 15:47:45 --> Total execution time: 0.0425
INFO - 2020-03-07 15:52:27 --> Config Class Initialized
INFO - 2020-03-07 15:52:27 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:52:27 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:52:27 --> Utf8 Class Initialized
INFO - 2020-03-07 15:52:27 --> URI Class Initialized
DEBUG - 2020-03-07 15:52:27 --> No URI present. Default controller set.
INFO - 2020-03-07 15:52:27 --> Router Class Initialized
INFO - 2020-03-07 15:52:27 --> Output Class Initialized
INFO - 2020-03-07 15:52:27 --> Security Class Initialized
DEBUG - 2020-03-07 15:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:52:27 --> Input Class Initialized
INFO - 2020-03-07 15:52:27 --> Language Class Initialized
INFO - 2020-03-07 15:52:27 --> Loader Class Initialized
INFO - 2020-03-07 15:52:27 --> Helper loaded: url_helper
INFO - 2020-03-07 15:52:27 --> Helper loaded: string_helper
INFO - 2020-03-07 15:52:27 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:52:27 --> Controller Class Initialized
INFO - 2020-03-07 15:52:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:52:27 --> Pagination Class Initialized
INFO - 2020-03-07 15:52:27 --> Model "M_show" initialized
INFO - 2020-03-07 15:52:27 --> Helper loaded: form_helper
INFO - 2020-03-07 15:52:27 --> Form Validation Class Initialized
INFO - 2020-03-07 15:52:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:52:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 15:52:27 --> Final output sent to browser
DEBUG - 2020-03-07 15:52:27 --> Total execution time: 0.0440
INFO - 2020-03-07 15:52:35 --> Config Class Initialized
INFO - 2020-03-07 15:52:35 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:52:35 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:52:35 --> Utf8 Class Initialized
INFO - 2020-03-07 15:52:35 --> URI Class Initialized
INFO - 2020-03-07 15:52:35 --> Router Class Initialized
INFO - 2020-03-07 15:52:35 --> Output Class Initialized
INFO - 2020-03-07 15:52:35 --> Security Class Initialized
DEBUG - 2020-03-07 15:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:52:35 --> Input Class Initialized
INFO - 2020-03-07 15:52:35 --> Language Class Initialized
INFO - 2020-03-07 15:52:35 --> Loader Class Initialized
INFO - 2020-03-07 15:52:35 --> Helper loaded: url_helper
INFO - 2020-03-07 15:52:35 --> Helper loaded: string_helper
INFO - 2020-03-07 15:52:35 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:52:35 --> Controller Class Initialized
INFO - 2020-03-07 15:52:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:52:35 --> Pagination Class Initialized
INFO - 2020-03-07 15:52:35 --> Model "M_show" initialized
INFO - 2020-03-07 15:52:35 --> Helper loaded: form_helper
INFO - 2020-03-07 15:52:35 --> Form Validation Class Initialized
INFO - 2020-03-07 15:52:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:52:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 15:52:35 --> Final output sent to browser
DEBUG - 2020-03-07 15:52:35 --> Total execution time: 0.0103
INFO - 2020-03-07 15:52:36 --> Config Class Initialized
INFO - 2020-03-07 15:52:36 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:52:36 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:52:36 --> Utf8 Class Initialized
INFO - 2020-03-07 15:52:36 --> URI Class Initialized
INFO - 2020-03-07 15:52:36 --> Router Class Initialized
INFO - 2020-03-07 15:52:36 --> Output Class Initialized
INFO - 2020-03-07 15:52:36 --> Security Class Initialized
DEBUG - 2020-03-07 15:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:52:36 --> Input Class Initialized
INFO - 2020-03-07 15:52:36 --> Language Class Initialized
ERROR - 2020-03-07 15:52:36 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-07 15:52:40 --> Config Class Initialized
INFO - 2020-03-07 15:52:40 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:52:40 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:52:40 --> Utf8 Class Initialized
INFO - 2020-03-07 15:52:40 --> URI Class Initialized
INFO - 2020-03-07 15:52:40 --> Router Class Initialized
INFO - 2020-03-07 15:52:40 --> Output Class Initialized
INFO - 2020-03-07 15:52:40 --> Security Class Initialized
DEBUG - 2020-03-07 15:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:52:40 --> Input Class Initialized
INFO - 2020-03-07 15:52:40 --> Language Class Initialized
INFO - 2020-03-07 15:52:40 --> Loader Class Initialized
INFO - 2020-03-07 15:52:40 --> Helper loaded: url_helper
INFO - 2020-03-07 15:52:40 --> Helper loaded: string_helper
INFO - 2020-03-07 15:52:40 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:52:40 --> Controller Class Initialized
INFO - 2020-03-07 15:52:40 --> Model "M_tiket" initialized
INFO - 2020-03-07 15:52:40 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 15:52:40 --> Model "M_pesan" initialized
INFO - 2020-03-07 15:52:40 --> Helper loaded: form_helper
INFO - 2020-03-07 15:52:40 --> Form Validation Class Initialized
INFO - 2020-03-07 15:52:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 15:52:40 --> Final output sent to browser
DEBUG - 2020-03-07 15:52:40 --> Total execution time: 0.0127
INFO - 2020-03-07 15:54:04 --> Config Class Initialized
INFO - 2020-03-07 15:54:04 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:54:04 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:54:04 --> Utf8 Class Initialized
INFO - 2020-03-07 15:54:04 --> URI Class Initialized
DEBUG - 2020-03-07 15:54:04 --> No URI present. Default controller set.
INFO - 2020-03-07 15:54:04 --> Router Class Initialized
INFO - 2020-03-07 15:54:04 --> Output Class Initialized
INFO - 2020-03-07 15:54:04 --> Security Class Initialized
DEBUG - 2020-03-07 15:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:54:04 --> Input Class Initialized
INFO - 2020-03-07 15:54:04 --> Language Class Initialized
INFO - 2020-03-07 15:54:04 --> Loader Class Initialized
INFO - 2020-03-07 15:54:04 --> Helper loaded: url_helper
INFO - 2020-03-07 15:54:04 --> Helper loaded: string_helper
INFO - 2020-03-07 15:54:04 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:54:04 --> Controller Class Initialized
INFO - 2020-03-07 15:54:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:54:04 --> Pagination Class Initialized
INFO - 2020-03-07 15:54:04 --> Model "M_show" initialized
INFO - 2020-03-07 15:54:04 --> Helper loaded: form_helper
INFO - 2020-03-07 15:54:04 --> Form Validation Class Initialized
INFO - 2020-03-07 15:54:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:54:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 15:54:04 --> Final output sent to browser
DEBUG - 2020-03-07 15:54:04 --> Total execution time: 0.0480
INFO - 2020-03-07 15:54:52 --> Config Class Initialized
INFO - 2020-03-07 15:54:52 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:54:52 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:54:52 --> Utf8 Class Initialized
INFO - 2020-03-07 15:54:52 --> URI Class Initialized
DEBUG - 2020-03-07 15:54:52 --> No URI present. Default controller set.
INFO - 2020-03-07 15:54:52 --> Router Class Initialized
INFO - 2020-03-07 15:54:52 --> Output Class Initialized
INFO - 2020-03-07 15:54:52 --> Security Class Initialized
DEBUG - 2020-03-07 15:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:54:52 --> Input Class Initialized
INFO - 2020-03-07 15:54:52 --> Language Class Initialized
INFO - 2020-03-07 15:54:52 --> Loader Class Initialized
INFO - 2020-03-07 15:54:52 --> Helper loaded: url_helper
INFO - 2020-03-07 15:54:52 --> Helper loaded: string_helper
INFO - 2020-03-07 15:54:52 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:54:52 --> Controller Class Initialized
INFO - 2020-03-07 15:54:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:54:52 --> Pagination Class Initialized
INFO - 2020-03-07 15:54:52 --> Model "M_show" initialized
INFO - 2020-03-07 15:54:52 --> Helper loaded: form_helper
INFO - 2020-03-07 15:54:52 --> Form Validation Class Initialized
INFO - 2020-03-07 15:54:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:54:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 15:54:52 --> Final output sent to browser
DEBUG - 2020-03-07 15:54:52 --> Total execution time: 0.0081
INFO - 2020-03-07 15:55:10 --> Config Class Initialized
INFO - 2020-03-07 15:55:10 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:55:10 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:55:10 --> Utf8 Class Initialized
INFO - 2020-03-07 15:55:10 --> URI Class Initialized
DEBUG - 2020-03-07 15:55:10 --> No URI present. Default controller set.
INFO - 2020-03-07 15:55:10 --> Router Class Initialized
INFO - 2020-03-07 15:55:10 --> Output Class Initialized
INFO - 2020-03-07 15:55:10 --> Security Class Initialized
DEBUG - 2020-03-07 15:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:55:10 --> Input Class Initialized
INFO - 2020-03-07 15:55:10 --> Language Class Initialized
INFO - 2020-03-07 15:55:10 --> Loader Class Initialized
INFO - 2020-03-07 15:55:10 --> Helper loaded: url_helper
INFO - 2020-03-07 15:55:10 --> Helper loaded: string_helper
INFO - 2020-03-07 15:55:10 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:55:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:55:10 --> Controller Class Initialized
INFO - 2020-03-07 15:55:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:55:10 --> Pagination Class Initialized
INFO - 2020-03-07 15:55:10 --> Model "M_show" initialized
INFO - 2020-03-07 15:55:10 --> Helper loaded: form_helper
INFO - 2020-03-07 15:55:10 --> Form Validation Class Initialized
INFO - 2020-03-07 15:55:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:55:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 15:55:10 --> Final output sent to browser
DEBUG - 2020-03-07 15:55:10 --> Total execution time: 0.0066
INFO - 2020-03-07 15:55:14 --> Config Class Initialized
INFO - 2020-03-07 15:55:14 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:55:14 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:55:14 --> Utf8 Class Initialized
INFO - 2020-03-07 15:55:14 --> URI Class Initialized
INFO - 2020-03-07 15:55:14 --> Router Class Initialized
INFO - 2020-03-07 15:55:14 --> Output Class Initialized
INFO - 2020-03-07 15:55:14 --> Security Class Initialized
DEBUG - 2020-03-07 15:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:55:14 --> Input Class Initialized
INFO - 2020-03-07 15:55:14 --> Language Class Initialized
INFO - 2020-03-07 15:55:14 --> Loader Class Initialized
INFO - 2020-03-07 15:55:14 --> Helper loaded: url_helper
INFO - 2020-03-07 15:55:14 --> Helper loaded: string_helper
INFO - 2020-03-07 15:55:14 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:55:14 --> Controller Class Initialized
INFO - 2020-03-07 15:55:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:55:14 --> Pagination Class Initialized
INFO - 2020-03-07 15:55:14 --> Model "M_show" initialized
INFO - 2020-03-07 15:55:14 --> Helper loaded: form_helper
INFO - 2020-03-07 15:55:14 --> Form Validation Class Initialized
INFO - 2020-03-07 15:55:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:55:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 15:55:14 --> Final output sent to browser
DEBUG - 2020-03-07 15:55:14 --> Total execution time: 0.0113
INFO - 2020-03-07 15:55:19 --> Config Class Initialized
INFO - 2020-03-07 15:55:19 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:55:19 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:55:19 --> Utf8 Class Initialized
INFO - 2020-03-07 15:55:19 --> URI Class Initialized
INFO - 2020-03-07 15:55:19 --> Router Class Initialized
INFO - 2020-03-07 15:55:19 --> Output Class Initialized
INFO - 2020-03-07 15:55:19 --> Security Class Initialized
DEBUG - 2020-03-07 15:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:55:19 --> Input Class Initialized
INFO - 2020-03-07 15:55:19 --> Language Class Initialized
INFO - 2020-03-07 15:55:19 --> Loader Class Initialized
INFO - 2020-03-07 15:55:19 --> Helper loaded: url_helper
INFO - 2020-03-07 15:55:19 --> Helper loaded: string_helper
INFO - 2020-03-07 15:55:19 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:55:19 --> Controller Class Initialized
INFO - 2020-03-07 15:55:19 --> Model "M_tiket" initialized
INFO - 2020-03-07 15:55:19 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 15:55:19 --> Model "M_pesan" initialized
INFO - 2020-03-07 15:55:19 --> Helper loaded: form_helper
INFO - 2020-03-07 15:55:19 --> Form Validation Class Initialized
INFO - 2020-03-07 15:55:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 15:55:19 --> Final output sent to browser
DEBUG - 2020-03-07 15:55:19 --> Total execution time: 0.0114
INFO - 2020-03-07 15:55:40 --> Config Class Initialized
INFO - 2020-03-07 15:55:40 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:55:40 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:55:40 --> Utf8 Class Initialized
INFO - 2020-03-07 15:55:40 --> URI Class Initialized
INFO - 2020-03-07 15:55:40 --> Router Class Initialized
INFO - 2020-03-07 15:55:40 --> Output Class Initialized
INFO - 2020-03-07 15:55:40 --> Security Class Initialized
DEBUG - 2020-03-07 15:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:55:40 --> Input Class Initialized
INFO - 2020-03-07 15:55:40 --> Language Class Initialized
INFO - 2020-03-07 15:55:40 --> Loader Class Initialized
INFO - 2020-03-07 15:55:40 --> Helper loaded: url_helper
INFO - 2020-03-07 15:55:40 --> Helper loaded: string_helper
INFO - 2020-03-07 15:55:40 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:55:40 --> Controller Class Initialized
INFO - 2020-03-07 15:55:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:55:40 --> Pagination Class Initialized
INFO - 2020-03-07 15:55:40 --> Model "M_show" initialized
INFO - 2020-03-07 15:55:40 --> Helper loaded: form_helper
INFO - 2020-03-07 15:55:40 --> Form Validation Class Initialized
INFO - 2020-03-07 15:55:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:55:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-07 15:55:40 --> Final output sent to browser
DEBUG - 2020-03-07 15:55:40 --> Total execution time: 0.0065
INFO - 2020-03-07 15:55:46 --> Config Class Initialized
INFO - 2020-03-07 15:55:46 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:55:46 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:55:46 --> Utf8 Class Initialized
INFO - 2020-03-07 15:55:46 --> URI Class Initialized
INFO - 2020-03-07 15:55:46 --> Router Class Initialized
INFO - 2020-03-07 15:55:46 --> Output Class Initialized
INFO - 2020-03-07 15:55:46 --> Security Class Initialized
DEBUG - 2020-03-07 15:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:55:46 --> Input Class Initialized
INFO - 2020-03-07 15:55:46 --> Language Class Initialized
INFO - 2020-03-07 15:55:46 --> Loader Class Initialized
INFO - 2020-03-07 15:55:46 --> Helper loaded: url_helper
INFO - 2020-03-07 15:55:46 --> Helper loaded: string_helper
INFO - 2020-03-07 15:55:46 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:55:46 --> Controller Class Initialized
INFO - 2020-03-07 15:55:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:55:46 --> Pagination Class Initialized
INFO - 2020-03-07 15:55:46 --> Model "M_show" initialized
INFO - 2020-03-07 15:55:46 --> Helper loaded: form_helper
INFO - 2020-03-07 15:55:46 --> Form Validation Class Initialized
INFO - 2020-03-07 15:55:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:55:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 15:55:46 --> Final output sent to browser
DEBUG - 2020-03-07 15:55:46 --> Total execution time: 0.0075
INFO - 2020-03-07 15:55:48 --> Config Class Initialized
INFO - 2020-03-07 15:55:48 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:55:48 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:55:48 --> Utf8 Class Initialized
INFO - 2020-03-07 15:55:48 --> URI Class Initialized
DEBUG - 2020-03-07 15:55:48 --> No URI present. Default controller set.
INFO - 2020-03-07 15:55:48 --> Router Class Initialized
INFO - 2020-03-07 15:55:48 --> Output Class Initialized
INFO - 2020-03-07 15:55:48 --> Security Class Initialized
DEBUG - 2020-03-07 15:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:55:48 --> Input Class Initialized
INFO - 2020-03-07 15:55:48 --> Language Class Initialized
INFO - 2020-03-07 15:55:48 --> Loader Class Initialized
INFO - 2020-03-07 15:55:48 --> Helper loaded: url_helper
INFO - 2020-03-07 15:55:48 --> Helper loaded: string_helper
INFO - 2020-03-07 15:55:48 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:55:48 --> Controller Class Initialized
INFO - 2020-03-07 15:55:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:55:48 --> Pagination Class Initialized
INFO - 2020-03-07 15:55:48 --> Model "M_show" initialized
INFO - 2020-03-07 15:55:48 --> Helper loaded: form_helper
INFO - 2020-03-07 15:55:48 --> Form Validation Class Initialized
INFO - 2020-03-07 15:55:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:55:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 15:55:48 --> Final output sent to browser
DEBUG - 2020-03-07 15:55:48 --> Total execution time: 0.0064
INFO - 2020-03-07 15:55:53 --> Config Class Initialized
INFO - 2020-03-07 15:55:53 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:55:53 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:55:53 --> Utf8 Class Initialized
INFO - 2020-03-07 15:55:53 --> URI Class Initialized
INFO - 2020-03-07 15:55:53 --> Router Class Initialized
INFO - 2020-03-07 15:55:53 --> Output Class Initialized
INFO - 2020-03-07 15:55:53 --> Security Class Initialized
DEBUG - 2020-03-07 15:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:55:53 --> Input Class Initialized
INFO - 2020-03-07 15:55:53 --> Language Class Initialized
INFO - 2020-03-07 15:55:53 --> Loader Class Initialized
INFO - 2020-03-07 15:55:53 --> Helper loaded: url_helper
INFO - 2020-03-07 15:55:53 --> Helper loaded: string_helper
INFO - 2020-03-07 15:55:53 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:55:53 --> Controller Class Initialized
INFO - 2020-03-07 15:55:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:55:53 --> Pagination Class Initialized
INFO - 2020-03-07 15:55:53 --> Model "M_show" initialized
INFO - 2020-03-07 15:55:53 --> Helper loaded: form_helper
INFO - 2020-03-07 15:55:53 --> Form Validation Class Initialized
INFO - 2020-03-07 15:55:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:55:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 15:55:53 --> Final output sent to browser
DEBUG - 2020-03-07 15:55:53 --> Total execution time: 0.0060
INFO - 2020-03-07 15:55:58 --> Config Class Initialized
INFO - 2020-03-07 15:55:58 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:55:58 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:55:58 --> Utf8 Class Initialized
INFO - 2020-03-07 15:55:58 --> URI Class Initialized
INFO - 2020-03-07 15:55:58 --> Router Class Initialized
INFO - 2020-03-07 15:55:58 --> Output Class Initialized
INFO - 2020-03-07 15:55:58 --> Security Class Initialized
DEBUG - 2020-03-07 15:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:55:58 --> Input Class Initialized
INFO - 2020-03-07 15:55:58 --> Language Class Initialized
INFO - 2020-03-07 15:55:58 --> Loader Class Initialized
INFO - 2020-03-07 15:55:58 --> Helper loaded: url_helper
INFO - 2020-03-07 15:55:58 --> Helper loaded: string_helper
INFO - 2020-03-07 15:55:58 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:55:58 --> Controller Class Initialized
INFO - 2020-03-07 15:55:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:55:58 --> Pagination Class Initialized
INFO - 2020-03-07 15:55:58 --> Model "M_show" initialized
INFO - 2020-03-07 15:55:58 --> Helper loaded: form_helper
INFO - 2020-03-07 15:55:58 --> Form Validation Class Initialized
INFO - 2020-03-07 15:55:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:55:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 15:55:58 --> Final output sent to browser
DEBUG - 2020-03-07 15:55:58 --> Total execution time: 0.0063
INFO - 2020-03-07 15:56:02 --> Config Class Initialized
INFO - 2020-03-07 15:56:02 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:56:02 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:56:02 --> Utf8 Class Initialized
INFO - 2020-03-07 15:56:02 --> URI Class Initialized
INFO - 2020-03-07 15:56:02 --> Router Class Initialized
INFO - 2020-03-07 15:56:02 --> Output Class Initialized
INFO - 2020-03-07 15:56:02 --> Security Class Initialized
DEBUG - 2020-03-07 15:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:56:02 --> Input Class Initialized
INFO - 2020-03-07 15:56:02 --> Language Class Initialized
INFO - 2020-03-07 15:56:02 --> Loader Class Initialized
INFO - 2020-03-07 15:56:02 --> Helper loaded: url_helper
INFO - 2020-03-07 15:56:02 --> Helper loaded: string_helper
INFO - 2020-03-07 15:56:02 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:56:02 --> Controller Class Initialized
INFO - 2020-03-07 15:56:02 --> Model "M_tiket" initialized
INFO - 2020-03-07 15:56:02 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 15:56:02 --> Model "M_pesan" initialized
INFO - 2020-03-07 15:56:02 --> Helper loaded: form_helper
INFO - 2020-03-07 15:56:02 --> Form Validation Class Initialized
INFO - 2020-03-07 15:56:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 15:56:02 --> Final output sent to browser
DEBUG - 2020-03-07 15:56:02 --> Total execution time: 0.0067
INFO - 2020-03-07 15:58:39 --> Config Class Initialized
INFO - 2020-03-07 15:58:39 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:58:39 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:58:39 --> Utf8 Class Initialized
INFO - 2020-03-07 15:58:39 --> URI Class Initialized
DEBUG - 2020-03-07 15:58:39 --> No URI present. Default controller set.
INFO - 2020-03-07 15:58:39 --> Router Class Initialized
INFO - 2020-03-07 15:58:39 --> Output Class Initialized
INFO - 2020-03-07 15:58:39 --> Security Class Initialized
DEBUG - 2020-03-07 15:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:58:39 --> Input Class Initialized
INFO - 2020-03-07 15:58:39 --> Language Class Initialized
INFO - 2020-03-07 15:58:39 --> Loader Class Initialized
INFO - 2020-03-07 15:58:39 --> Helper loaded: url_helper
INFO - 2020-03-07 15:58:39 --> Helper loaded: string_helper
INFO - 2020-03-07 15:58:39 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:58:39 --> Controller Class Initialized
INFO - 2020-03-07 15:58:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:58:39 --> Pagination Class Initialized
INFO - 2020-03-07 15:58:39 --> Model "M_show" initialized
INFO - 2020-03-07 15:58:39 --> Helper loaded: form_helper
INFO - 2020-03-07 15:58:39 --> Form Validation Class Initialized
INFO - 2020-03-07 15:58:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:58:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 15:58:39 --> Final output sent to browser
DEBUG - 2020-03-07 15:58:39 --> Total execution time: 0.0298
INFO - 2020-03-07 15:58:46 --> Config Class Initialized
INFO - 2020-03-07 15:58:46 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:58:46 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:58:46 --> Utf8 Class Initialized
INFO - 2020-03-07 15:58:46 --> URI Class Initialized
INFO - 2020-03-07 15:58:46 --> Router Class Initialized
INFO - 2020-03-07 15:58:46 --> Output Class Initialized
INFO - 2020-03-07 15:58:46 --> Security Class Initialized
DEBUG - 2020-03-07 15:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:58:46 --> Input Class Initialized
INFO - 2020-03-07 15:58:46 --> Language Class Initialized
INFO - 2020-03-07 15:58:46 --> Loader Class Initialized
INFO - 2020-03-07 15:58:46 --> Helper loaded: url_helper
INFO - 2020-03-07 15:58:46 --> Helper loaded: string_helper
INFO - 2020-03-07 15:58:46 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:58:46 --> Controller Class Initialized
INFO - 2020-03-07 15:58:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 15:58:46 --> Pagination Class Initialized
INFO - 2020-03-07 15:58:46 --> Model "M_show" initialized
INFO - 2020-03-07 15:58:46 --> Helper loaded: form_helper
INFO - 2020-03-07 15:58:46 --> Form Validation Class Initialized
INFO - 2020-03-07 15:58:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 15:58:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 15:58:46 --> Final output sent to browser
DEBUG - 2020-03-07 15:58:46 --> Total execution time: 0.0099
INFO - 2020-03-07 15:58:58 --> Config Class Initialized
INFO - 2020-03-07 15:58:58 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:58:58 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:58:58 --> Utf8 Class Initialized
INFO - 2020-03-07 15:58:58 --> URI Class Initialized
INFO - 2020-03-07 15:58:58 --> Router Class Initialized
INFO - 2020-03-07 15:58:58 --> Output Class Initialized
INFO - 2020-03-07 15:58:58 --> Security Class Initialized
DEBUG - 2020-03-07 15:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:58:58 --> Input Class Initialized
INFO - 2020-03-07 15:58:58 --> Language Class Initialized
INFO - 2020-03-07 15:58:58 --> Loader Class Initialized
INFO - 2020-03-07 15:58:58 --> Helper loaded: url_helper
INFO - 2020-03-07 15:58:58 --> Helper loaded: string_helper
INFO - 2020-03-07 15:58:58 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:58:58 --> Controller Class Initialized
INFO - 2020-03-07 15:58:58 --> Model "M_tiket" initialized
INFO - 2020-03-07 15:58:58 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 15:58:58 --> Model "M_pesan" initialized
INFO - 2020-03-07 15:58:58 --> Helper loaded: form_helper
INFO - 2020-03-07 15:58:58 --> Form Validation Class Initialized
INFO - 2020-03-07 15:58:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 15:58:58 --> Final output sent to browser
DEBUG - 2020-03-07 15:58:58 --> Total execution time: 0.0115
INFO - 2020-03-07 15:59:10 --> Config Class Initialized
INFO - 2020-03-07 15:59:10 --> Hooks Class Initialized
DEBUG - 2020-03-07 15:59:10 --> UTF-8 Support Enabled
INFO - 2020-03-07 15:59:10 --> Utf8 Class Initialized
INFO - 2020-03-07 15:59:10 --> URI Class Initialized
INFO - 2020-03-07 15:59:10 --> Router Class Initialized
INFO - 2020-03-07 15:59:10 --> Output Class Initialized
INFO - 2020-03-07 15:59:10 --> Security Class Initialized
DEBUG - 2020-03-07 15:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 15:59:10 --> Input Class Initialized
INFO - 2020-03-07 15:59:10 --> Language Class Initialized
INFO - 2020-03-07 15:59:10 --> Loader Class Initialized
INFO - 2020-03-07 15:59:10 --> Helper loaded: url_helper
INFO - 2020-03-07 15:59:10 --> Helper loaded: string_helper
INFO - 2020-03-07 15:59:10 --> Database Driver Class Initialized
DEBUG - 2020-03-07 15:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 15:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 15:59:10 --> Controller Class Initialized
INFO - 2020-03-07 15:59:10 --> Model "M_tiket" initialized
INFO - 2020-03-07 15:59:10 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 15:59:10 --> Model "M_pesan" initialized
INFO - 2020-03-07 15:59:10 --> Helper loaded: form_helper
INFO - 2020-03-07 15:59:10 --> Form Validation Class Initialized
INFO - 2020-03-07 15:59:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 15:59:10 --> Final output sent to browser
DEBUG - 2020-03-07 15:59:10 --> Total execution time: 0.0082
INFO - 2020-03-07 16:00:34 --> Config Class Initialized
INFO - 2020-03-07 16:00:34 --> Hooks Class Initialized
DEBUG - 2020-03-07 16:00:34 --> UTF-8 Support Enabled
INFO - 2020-03-07 16:00:34 --> Utf8 Class Initialized
INFO - 2020-03-07 16:00:34 --> URI Class Initialized
INFO - 2020-03-07 16:00:34 --> Router Class Initialized
INFO - 2020-03-07 16:00:34 --> Output Class Initialized
INFO - 2020-03-07 16:00:34 --> Security Class Initialized
DEBUG - 2020-03-07 16:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 16:00:34 --> Input Class Initialized
INFO - 2020-03-07 16:00:34 --> Language Class Initialized
INFO - 2020-03-07 16:00:34 --> Loader Class Initialized
INFO - 2020-03-07 16:00:34 --> Helper loaded: url_helper
INFO - 2020-03-07 16:00:34 --> Helper loaded: string_helper
INFO - 2020-03-07 16:00:34 --> Database Driver Class Initialized
DEBUG - 2020-03-07 16:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 16:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 16:00:34 --> Controller Class Initialized
INFO - 2020-03-07 16:00:34 --> Model "M_tiket" initialized
INFO - 2020-03-07 16:00:34 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 16:00:34 --> Model "M_pesan" initialized
INFO - 2020-03-07 16:00:35 --> Helper loaded: form_helper
INFO - 2020-03-07 16:00:35 --> Form Validation Class Initialized
DEBUG - 2020-03-07 16:00:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-07 16:00:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-07 23:00:35 --> Final output sent to browser
DEBUG - 2020-03-07 23:00:35 --> Total execution time: 0.4476
INFO - 2020-03-07 16:00:41 --> Config Class Initialized
INFO - 2020-03-07 16:00:41 --> Hooks Class Initialized
DEBUG - 2020-03-07 16:00:41 --> UTF-8 Support Enabled
INFO - 2020-03-07 16:00:41 --> Utf8 Class Initialized
INFO - 2020-03-07 16:00:41 --> URI Class Initialized
INFO - 2020-03-07 16:00:41 --> Router Class Initialized
INFO - 2020-03-07 16:00:41 --> Output Class Initialized
INFO - 2020-03-07 16:00:41 --> Security Class Initialized
DEBUG - 2020-03-07 16:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 16:00:41 --> Input Class Initialized
INFO - 2020-03-07 16:00:41 --> Language Class Initialized
INFO - 2020-03-07 16:00:41 --> Loader Class Initialized
INFO - 2020-03-07 16:00:41 --> Helper loaded: url_helper
INFO - 2020-03-07 16:00:41 --> Helper loaded: string_helper
INFO - 2020-03-07 16:00:41 --> Database Driver Class Initialized
DEBUG - 2020-03-07 16:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 16:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 16:00:41 --> Controller Class Initialized
INFO - 2020-03-07 16:00:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 16:00:41 --> Pagination Class Initialized
INFO - 2020-03-07 16:00:41 --> Model "M_show" initialized
INFO - 2020-03-07 16:00:41 --> Helper loaded: form_helper
INFO - 2020-03-07 16:00:41 --> Form Validation Class Initialized
INFO - 2020-03-07 16:00:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 16:00:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 16:00:41 --> Final output sent to browser
DEBUG - 2020-03-07 16:00:41 --> Total execution time: 0.0095
INFO - 2020-03-07 16:03:29 --> Config Class Initialized
INFO - 2020-03-07 16:03:29 --> Hooks Class Initialized
DEBUG - 2020-03-07 16:03:29 --> UTF-8 Support Enabled
INFO - 2020-03-07 16:03:29 --> Utf8 Class Initialized
INFO - 2020-03-07 16:03:29 --> URI Class Initialized
DEBUG - 2020-03-07 16:03:29 --> No URI present. Default controller set.
INFO - 2020-03-07 16:03:29 --> Router Class Initialized
INFO - 2020-03-07 16:03:29 --> Output Class Initialized
INFO - 2020-03-07 16:03:29 --> Security Class Initialized
DEBUG - 2020-03-07 16:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 16:03:29 --> Input Class Initialized
INFO - 2020-03-07 16:03:29 --> Language Class Initialized
INFO - 2020-03-07 16:03:29 --> Loader Class Initialized
INFO - 2020-03-07 16:03:29 --> Helper loaded: url_helper
INFO - 2020-03-07 16:03:29 --> Helper loaded: string_helper
INFO - 2020-03-07 16:03:29 --> Database Driver Class Initialized
DEBUG - 2020-03-07 16:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 16:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 16:03:29 --> Controller Class Initialized
INFO - 2020-03-07 16:03:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 16:03:29 --> Pagination Class Initialized
INFO - 2020-03-07 16:03:29 --> Model "M_show" initialized
INFO - 2020-03-07 16:03:29 --> Helper loaded: form_helper
INFO - 2020-03-07 16:03:29 --> Form Validation Class Initialized
INFO - 2020-03-07 16:03:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 16:03:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 16:03:29 --> Final output sent to browser
DEBUG - 2020-03-07 16:03:29 --> Total execution time: 0.0387
INFO - 2020-03-07 16:03:41 --> Config Class Initialized
INFO - 2020-03-07 16:03:41 --> Hooks Class Initialized
DEBUG - 2020-03-07 16:03:41 --> UTF-8 Support Enabled
INFO - 2020-03-07 16:03:41 --> Utf8 Class Initialized
INFO - 2020-03-07 16:03:41 --> URI Class Initialized
INFO - 2020-03-07 16:03:41 --> Router Class Initialized
INFO - 2020-03-07 16:03:41 --> Output Class Initialized
INFO - 2020-03-07 16:03:41 --> Security Class Initialized
DEBUG - 2020-03-07 16:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 16:03:41 --> Input Class Initialized
INFO - 2020-03-07 16:03:41 --> Language Class Initialized
INFO - 2020-03-07 16:03:41 --> Loader Class Initialized
INFO - 2020-03-07 16:03:41 --> Helper loaded: url_helper
INFO - 2020-03-07 16:03:41 --> Helper loaded: string_helper
INFO - 2020-03-07 16:03:41 --> Database Driver Class Initialized
DEBUG - 2020-03-07 16:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 16:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 16:03:41 --> Controller Class Initialized
INFO - 2020-03-07 16:03:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 16:03:41 --> Pagination Class Initialized
INFO - 2020-03-07 16:03:41 --> Model "M_show" initialized
INFO - 2020-03-07 16:03:41 --> Helper loaded: form_helper
INFO - 2020-03-07 16:03:41 --> Form Validation Class Initialized
INFO - 2020-03-07 16:03:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 16:03:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 16:03:41 --> Final output sent to browser
DEBUG - 2020-03-07 16:03:41 --> Total execution time: 0.0088
INFO - 2020-03-07 16:03:41 --> Config Class Initialized
INFO - 2020-03-07 16:03:41 --> Hooks Class Initialized
DEBUG - 2020-03-07 16:03:41 --> UTF-8 Support Enabled
INFO - 2020-03-07 16:03:41 --> Utf8 Class Initialized
INFO - 2020-03-07 16:03:41 --> URI Class Initialized
INFO - 2020-03-07 16:03:41 --> Router Class Initialized
INFO - 2020-03-07 16:03:41 --> Output Class Initialized
INFO - 2020-03-07 16:03:41 --> Security Class Initialized
DEBUG - 2020-03-07 16:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 16:03:41 --> Input Class Initialized
INFO - 2020-03-07 16:03:41 --> Language Class Initialized
ERROR - 2020-03-07 16:03:41 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-07 16:03:45 --> Config Class Initialized
INFO - 2020-03-07 16:03:45 --> Hooks Class Initialized
DEBUG - 2020-03-07 16:03:45 --> UTF-8 Support Enabled
INFO - 2020-03-07 16:03:45 --> Utf8 Class Initialized
INFO - 2020-03-07 16:03:45 --> URI Class Initialized
INFO - 2020-03-07 16:03:45 --> Router Class Initialized
INFO - 2020-03-07 16:03:45 --> Output Class Initialized
INFO - 2020-03-07 16:03:45 --> Security Class Initialized
DEBUG - 2020-03-07 16:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 16:03:45 --> Input Class Initialized
INFO - 2020-03-07 16:03:45 --> Language Class Initialized
INFO - 2020-03-07 16:03:45 --> Loader Class Initialized
INFO - 2020-03-07 16:03:45 --> Helper loaded: url_helper
INFO - 2020-03-07 16:03:45 --> Helper loaded: string_helper
INFO - 2020-03-07 16:03:45 --> Database Driver Class Initialized
DEBUG - 2020-03-07 16:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 16:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 16:03:45 --> Controller Class Initialized
INFO - 2020-03-07 16:03:45 --> Model "M_tiket" initialized
INFO - 2020-03-07 16:03:45 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 16:03:45 --> Model "M_pesan" initialized
INFO - 2020-03-07 16:03:45 --> Helper loaded: form_helper
INFO - 2020-03-07 16:03:45 --> Form Validation Class Initialized
INFO - 2020-03-07 16:03:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 16:03:45 --> Final output sent to browser
DEBUG - 2020-03-07 16:03:45 --> Total execution time: 0.0111
INFO - 2020-03-07 16:09:37 --> Config Class Initialized
INFO - 2020-03-07 16:09:37 --> Hooks Class Initialized
DEBUG - 2020-03-07 16:09:37 --> UTF-8 Support Enabled
INFO - 2020-03-07 16:09:37 --> Utf8 Class Initialized
INFO - 2020-03-07 16:09:37 --> URI Class Initialized
DEBUG - 2020-03-07 16:09:37 --> No URI present. Default controller set.
INFO - 2020-03-07 16:09:37 --> Router Class Initialized
INFO - 2020-03-07 16:09:37 --> Output Class Initialized
INFO - 2020-03-07 16:09:37 --> Security Class Initialized
DEBUG - 2020-03-07 16:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 16:09:37 --> Input Class Initialized
INFO - 2020-03-07 16:09:37 --> Language Class Initialized
INFO - 2020-03-07 16:09:37 --> Loader Class Initialized
INFO - 2020-03-07 16:09:37 --> Helper loaded: url_helper
INFO - 2020-03-07 16:09:37 --> Helper loaded: string_helper
INFO - 2020-03-07 16:09:37 --> Database Driver Class Initialized
DEBUG - 2020-03-07 16:09:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 16:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 16:09:37 --> Controller Class Initialized
INFO - 2020-03-07 16:09:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 16:09:37 --> Pagination Class Initialized
INFO - 2020-03-07 16:09:37 --> Model "M_show" initialized
INFO - 2020-03-07 16:09:37 --> Helper loaded: form_helper
INFO - 2020-03-07 16:09:37 --> Form Validation Class Initialized
INFO - 2020-03-07 16:09:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 16:09:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 16:09:37 --> Final output sent to browser
DEBUG - 2020-03-07 16:09:37 --> Total execution time: 0.0699
INFO - 2020-03-07 16:09:50 --> Config Class Initialized
INFO - 2020-03-07 16:09:50 --> Hooks Class Initialized
DEBUG - 2020-03-07 16:09:50 --> UTF-8 Support Enabled
INFO - 2020-03-07 16:09:50 --> Utf8 Class Initialized
INFO - 2020-03-07 16:09:50 --> URI Class Initialized
INFO - 2020-03-07 16:09:50 --> Router Class Initialized
INFO - 2020-03-07 16:09:50 --> Output Class Initialized
INFO - 2020-03-07 16:09:50 --> Security Class Initialized
DEBUG - 2020-03-07 16:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 16:09:50 --> Input Class Initialized
INFO - 2020-03-07 16:09:50 --> Language Class Initialized
INFO - 2020-03-07 16:09:50 --> Loader Class Initialized
INFO - 2020-03-07 16:09:50 --> Helper loaded: url_helper
INFO - 2020-03-07 16:09:50 --> Helper loaded: string_helper
INFO - 2020-03-07 16:09:50 --> Database Driver Class Initialized
DEBUG - 2020-03-07 16:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 16:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 16:09:50 --> Controller Class Initialized
INFO - 2020-03-07 16:09:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 16:09:50 --> Pagination Class Initialized
INFO - 2020-03-07 16:09:50 --> Model "M_show" initialized
INFO - 2020-03-07 16:09:50 --> Helper loaded: form_helper
INFO - 2020-03-07 16:09:50 --> Form Validation Class Initialized
INFO - 2020-03-07 16:09:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 16:09:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 16:09:50 --> Final output sent to browser
DEBUG - 2020-03-07 16:09:50 --> Total execution time: 0.0089
INFO - 2020-03-07 16:09:55 --> Config Class Initialized
INFO - 2020-03-07 16:09:55 --> Hooks Class Initialized
DEBUG - 2020-03-07 16:09:55 --> UTF-8 Support Enabled
INFO - 2020-03-07 16:09:55 --> Utf8 Class Initialized
INFO - 2020-03-07 16:09:55 --> URI Class Initialized
INFO - 2020-03-07 16:09:55 --> Router Class Initialized
INFO - 2020-03-07 16:09:55 --> Output Class Initialized
INFO - 2020-03-07 16:09:55 --> Security Class Initialized
DEBUG - 2020-03-07 16:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 16:09:55 --> Input Class Initialized
INFO - 2020-03-07 16:09:55 --> Language Class Initialized
INFO - 2020-03-07 16:09:55 --> Loader Class Initialized
INFO - 2020-03-07 16:09:55 --> Helper loaded: url_helper
INFO - 2020-03-07 16:09:55 --> Helper loaded: string_helper
INFO - 2020-03-07 16:09:55 --> Database Driver Class Initialized
DEBUG - 2020-03-07 16:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 16:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 16:09:55 --> Controller Class Initialized
INFO - 2020-03-07 16:09:55 --> Model "M_tiket" initialized
INFO - 2020-03-07 16:09:55 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 16:09:55 --> Model "M_pesan" initialized
INFO - 2020-03-07 16:09:55 --> Helper loaded: form_helper
INFO - 2020-03-07 16:09:55 --> Form Validation Class Initialized
INFO - 2020-03-07 16:09:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 16:09:55 --> Final output sent to browser
DEBUG - 2020-03-07 16:09:55 --> Total execution time: 0.0122
INFO - 2020-03-07 16:10:12 --> Config Class Initialized
INFO - 2020-03-07 16:10:12 --> Hooks Class Initialized
DEBUG - 2020-03-07 16:10:12 --> UTF-8 Support Enabled
INFO - 2020-03-07 16:10:12 --> Utf8 Class Initialized
INFO - 2020-03-07 16:10:12 --> URI Class Initialized
INFO - 2020-03-07 16:10:12 --> Router Class Initialized
INFO - 2020-03-07 16:10:12 --> Output Class Initialized
INFO - 2020-03-07 16:10:12 --> Security Class Initialized
DEBUG - 2020-03-07 16:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 16:10:12 --> Input Class Initialized
INFO - 2020-03-07 16:10:12 --> Language Class Initialized
INFO - 2020-03-07 16:10:12 --> Loader Class Initialized
INFO - 2020-03-07 16:10:12 --> Helper loaded: url_helper
INFO - 2020-03-07 16:10:12 --> Helper loaded: string_helper
INFO - 2020-03-07 16:10:12 --> Database Driver Class Initialized
DEBUG - 2020-03-07 16:10:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 16:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 16:10:12 --> Controller Class Initialized
INFO - 2020-03-07 16:10:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 16:10:12 --> Pagination Class Initialized
INFO - 2020-03-07 16:10:12 --> Model "M_show" initialized
INFO - 2020-03-07 16:10:12 --> Helper loaded: form_helper
INFO - 2020-03-07 16:10:12 --> Form Validation Class Initialized
INFO - 2020-03-07 16:10:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 16:10:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 16:10:12 --> Final output sent to browser
DEBUG - 2020-03-07 16:10:12 --> Total execution time: 0.0074
INFO - 2020-03-07 16:10:18 --> Config Class Initialized
INFO - 2020-03-07 16:10:18 --> Hooks Class Initialized
DEBUG - 2020-03-07 16:10:18 --> UTF-8 Support Enabled
INFO - 2020-03-07 16:10:18 --> Utf8 Class Initialized
INFO - 2020-03-07 16:10:18 --> URI Class Initialized
INFO - 2020-03-07 16:10:18 --> Router Class Initialized
INFO - 2020-03-07 16:10:18 --> Output Class Initialized
INFO - 2020-03-07 16:10:18 --> Security Class Initialized
DEBUG - 2020-03-07 16:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 16:10:18 --> Input Class Initialized
INFO - 2020-03-07 16:10:18 --> Language Class Initialized
INFO - 2020-03-07 16:10:18 --> Loader Class Initialized
INFO - 2020-03-07 16:10:18 --> Helper loaded: url_helper
INFO - 2020-03-07 16:10:18 --> Helper loaded: string_helper
INFO - 2020-03-07 16:10:18 --> Database Driver Class Initialized
DEBUG - 2020-03-07 16:10:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 16:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 16:10:18 --> Controller Class Initialized
INFO - 2020-03-07 16:10:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 16:10:18 --> Pagination Class Initialized
INFO - 2020-03-07 16:10:18 --> Model "M_show" initialized
INFO - 2020-03-07 16:10:18 --> Helper loaded: form_helper
INFO - 2020-03-07 16:10:18 --> Form Validation Class Initialized
INFO - 2020-03-07 16:10:18 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 16:10:18 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/gal.php
INFO - 2020-03-07 16:10:18 --> Final output sent to browser
DEBUG - 2020-03-07 16:10:18 --> Total execution time: 0.0056
INFO - 2020-03-07 16:10:29 --> Config Class Initialized
INFO - 2020-03-07 16:10:29 --> Hooks Class Initialized
DEBUG - 2020-03-07 16:10:29 --> UTF-8 Support Enabled
INFO - 2020-03-07 16:10:29 --> Utf8 Class Initialized
INFO - 2020-03-07 16:10:29 --> URI Class Initialized
INFO - 2020-03-07 16:10:29 --> Router Class Initialized
INFO - 2020-03-07 16:10:29 --> Output Class Initialized
INFO - 2020-03-07 16:10:29 --> Security Class Initialized
DEBUG - 2020-03-07 16:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 16:10:29 --> Input Class Initialized
INFO - 2020-03-07 16:10:29 --> Language Class Initialized
INFO - 2020-03-07 16:10:29 --> Loader Class Initialized
INFO - 2020-03-07 16:10:29 --> Helper loaded: url_helper
INFO - 2020-03-07 16:10:29 --> Helper loaded: string_helper
INFO - 2020-03-07 16:10:29 --> Database Driver Class Initialized
DEBUG - 2020-03-07 16:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 16:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 16:10:29 --> Controller Class Initialized
INFO - 2020-03-07 16:10:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 16:10:29 --> Pagination Class Initialized
INFO - 2020-03-07 16:10:29 --> Model "M_show" initialized
INFO - 2020-03-07 16:10:29 --> Helper loaded: form_helper
INFO - 2020-03-07 16:10:29 --> Form Validation Class Initialized
INFO - 2020-03-07 16:10:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 16:10:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-07 16:10:29 --> Final output sent to browser
DEBUG - 2020-03-07 16:10:29 --> Total execution time: 0.0076
INFO - 2020-03-07 16:10:49 --> Config Class Initialized
INFO - 2020-03-07 16:10:49 --> Hooks Class Initialized
DEBUG - 2020-03-07 16:10:49 --> UTF-8 Support Enabled
INFO - 2020-03-07 16:10:49 --> Utf8 Class Initialized
INFO - 2020-03-07 16:10:49 --> URI Class Initialized
INFO - 2020-03-07 16:10:49 --> Router Class Initialized
INFO - 2020-03-07 16:10:49 --> Output Class Initialized
INFO - 2020-03-07 16:10:49 --> Security Class Initialized
DEBUG - 2020-03-07 16:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 16:10:49 --> Input Class Initialized
INFO - 2020-03-07 16:10:49 --> Language Class Initialized
INFO - 2020-03-07 16:10:49 --> Loader Class Initialized
INFO - 2020-03-07 16:10:49 --> Helper loaded: url_helper
INFO - 2020-03-07 16:10:49 --> Helper loaded: string_helper
INFO - 2020-03-07 16:10:49 --> Database Driver Class Initialized
DEBUG - 2020-03-07 16:10:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 16:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 16:10:49 --> Controller Class Initialized
INFO - 2020-03-07 16:10:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 16:10:49 --> Pagination Class Initialized
INFO - 2020-03-07 16:10:49 --> Model "M_show" initialized
INFO - 2020-03-07 16:10:49 --> Helper loaded: form_helper
INFO - 2020-03-07 16:10:49 --> Form Validation Class Initialized
INFO - 2020-03-07 16:10:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 16:10:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/gal.php
INFO - 2020-03-07 16:10:49 --> Final output sent to browser
DEBUG - 2020-03-07 16:10:49 --> Total execution time: 0.0057
INFO - 2020-03-07 16:10:53 --> Config Class Initialized
INFO - 2020-03-07 16:10:53 --> Hooks Class Initialized
DEBUG - 2020-03-07 16:10:53 --> UTF-8 Support Enabled
INFO - 2020-03-07 16:10:53 --> Utf8 Class Initialized
INFO - 2020-03-07 16:10:53 --> URI Class Initialized
INFO - 2020-03-07 16:10:53 --> Router Class Initialized
INFO - 2020-03-07 16:10:53 --> Output Class Initialized
INFO - 2020-03-07 16:10:53 --> Security Class Initialized
DEBUG - 2020-03-07 16:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 16:10:53 --> Input Class Initialized
INFO - 2020-03-07 16:10:53 --> Language Class Initialized
INFO - 2020-03-07 16:10:53 --> Loader Class Initialized
INFO - 2020-03-07 16:10:53 --> Helper loaded: url_helper
INFO - 2020-03-07 16:10:53 --> Helper loaded: string_helper
INFO - 2020-03-07 16:10:53 --> Database Driver Class Initialized
DEBUG - 2020-03-07 16:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 16:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 16:10:53 --> Controller Class Initialized
INFO - 2020-03-07 16:10:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 16:10:53 --> Pagination Class Initialized
INFO - 2020-03-07 16:10:53 --> Model "M_show" initialized
INFO - 2020-03-07 16:10:53 --> Helper loaded: form_helper
INFO - 2020-03-07 16:10:53 --> Form Validation Class Initialized
INFO - 2020-03-07 16:10:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 16:10:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-07 16:10:53 --> Final output sent to browser
DEBUG - 2020-03-07 16:10:53 --> Total execution time: 0.0071
INFO - 2020-03-07 16:11:13 --> Config Class Initialized
INFO - 2020-03-07 16:11:13 --> Hooks Class Initialized
DEBUG - 2020-03-07 16:11:13 --> UTF-8 Support Enabled
INFO - 2020-03-07 16:11:13 --> Utf8 Class Initialized
INFO - 2020-03-07 16:11:13 --> URI Class Initialized
INFO - 2020-03-07 16:11:13 --> Router Class Initialized
INFO - 2020-03-07 16:11:13 --> Output Class Initialized
INFO - 2020-03-07 16:11:13 --> Security Class Initialized
DEBUG - 2020-03-07 16:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 16:11:13 --> Input Class Initialized
INFO - 2020-03-07 16:11:13 --> Language Class Initialized
INFO - 2020-03-07 16:11:13 --> Loader Class Initialized
INFO - 2020-03-07 16:11:13 --> Helper loaded: url_helper
INFO - 2020-03-07 16:11:13 --> Helper loaded: string_helper
INFO - 2020-03-07 16:11:13 --> Database Driver Class Initialized
DEBUG - 2020-03-07 16:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 16:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 16:11:14 --> Controller Class Initialized
INFO - 2020-03-07 16:11:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 16:11:14 --> Pagination Class Initialized
INFO - 2020-03-07 16:11:14 --> Model "M_show" initialized
INFO - 2020-03-07 16:11:14 --> Helper loaded: form_helper
INFO - 2020-03-07 16:11:14 --> Form Validation Class Initialized
INFO - 2020-03-07 16:11:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 16:11:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/gal.php
INFO - 2020-03-07 16:11:14 --> Final output sent to browser
DEBUG - 2020-03-07 16:11:14 --> Total execution time: 0.0057
INFO - 2020-03-07 16:11:17 --> Config Class Initialized
INFO - 2020-03-07 16:11:17 --> Hooks Class Initialized
DEBUG - 2020-03-07 16:11:17 --> UTF-8 Support Enabled
INFO - 2020-03-07 16:11:17 --> Utf8 Class Initialized
INFO - 2020-03-07 16:11:17 --> URI Class Initialized
INFO - 2020-03-07 16:11:17 --> Router Class Initialized
INFO - 2020-03-07 16:11:17 --> Output Class Initialized
INFO - 2020-03-07 16:11:17 --> Security Class Initialized
DEBUG - 2020-03-07 16:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 16:11:17 --> Input Class Initialized
INFO - 2020-03-07 16:11:17 --> Language Class Initialized
INFO - 2020-03-07 16:11:17 --> Loader Class Initialized
INFO - 2020-03-07 16:11:17 --> Helper loaded: url_helper
INFO - 2020-03-07 16:11:17 --> Helper loaded: string_helper
INFO - 2020-03-07 16:11:17 --> Database Driver Class Initialized
DEBUG - 2020-03-07 16:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 16:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 16:11:17 --> Controller Class Initialized
INFO - 2020-03-07 16:11:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 16:11:17 --> Pagination Class Initialized
INFO - 2020-03-07 16:11:17 --> Model "M_show" initialized
INFO - 2020-03-07 16:11:17 --> Helper loaded: form_helper
INFO - 2020-03-07 16:11:17 --> Form Validation Class Initialized
INFO - 2020-03-07 16:11:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 16:11:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 16:11:17 --> Final output sent to browser
DEBUG - 2020-03-07 16:11:17 --> Total execution time: 0.0062
INFO - 2020-03-07 16:11:20 --> Config Class Initialized
INFO - 2020-03-07 16:11:20 --> Hooks Class Initialized
DEBUG - 2020-03-07 16:11:20 --> UTF-8 Support Enabled
INFO - 2020-03-07 16:11:20 --> Utf8 Class Initialized
INFO - 2020-03-07 16:11:20 --> URI Class Initialized
DEBUG - 2020-03-07 16:11:20 --> No URI present. Default controller set.
INFO - 2020-03-07 16:11:20 --> Router Class Initialized
INFO - 2020-03-07 16:11:20 --> Output Class Initialized
INFO - 2020-03-07 16:11:20 --> Security Class Initialized
DEBUG - 2020-03-07 16:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 16:11:20 --> Input Class Initialized
INFO - 2020-03-07 16:11:20 --> Language Class Initialized
INFO - 2020-03-07 16:11:20 --> Loader Class Initialized
INFO - 2020-03-07 16:11:20 --> Helper loaded: url_helper
INFO - 2020-03-07 16:11:20 --> Helper loaded: string_helper
INFO - 2020-03-07 16:11:20 --> Database Driver Class Initialized
DEBUG - 2020-03-07 16:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 16:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 16:11:20 --> Controller Class Initialized
INFO - 2020-03-07 16:11:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 16:11:20 --> Pagination Class Initialized
INFO - 2020-03-07 16:11:20 --> Model "M_show" initialized
INFO - 2020-03-07 16:11:20 --> Helper loaded: form_helper
INFO - 2020-03-07 16:11:20 --> Form Validation Class Initialized
INFO - 2020-03-07 16:11:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 16:11:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 16:11:20 --> Final output sent to browser
DEBUG - 2020-03-07 16:11:20 --> Total execution time: 0.0065
INFO - 2020-03-07 16:11:27 --> Config Class Initialized
INFO - 2020-03-07 16:11:27 --> Hooks Class Initialized
DEBUG - 2020-03-07 16:11:27 --> UTF-8 Support Enabled
INFO - 2020-03-07 16:11:27 --> Utf8 Class Initialized
INFO - 2020-03-07 16:11:27 --> URI Class Initialized
INFO - 2020-03-07 16:11:27 --> Router Class Initialized
INFO - 2020-03-07 16:11:27 --> Output Class Initialized
INFO - 2020-03-07 16:11:27 --> Security Class Initialized
DEBUG - 2020-03-07 16:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 16:11:27 --> Input Class Initialized
INFO - 2020-03-07 16:11:27 --> Language Class Initialized
INFO - 2020-03-07 16:11:27 --> Loader Class Initialized
INFO - 2020-03-07 16:11:27 --> Helper loaded: url_helper
INFO - 2020-03-07 16:11:27 --> Helper loaded: string_helper
INFO - 2020-03-07 16:11:27 --> Database Driver Class Initialized
DEBUG - 2020-03-07 16:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 16:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 16:11:27 --> Controller Class Initialized
INFO - 2020-03-07 16:11:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 16:11:27 --> Pagination Class Initialized
INFO - 2020-03-07 16:11:27 --> Model "M_show" initialized
INFO - 2020-03-07 16:11:27 --> Helper loaded: form_helper
INFO - 2020-03-07 16:11:27 --> Form Validation Class Initialized
INFO - 2020-03-07 16:11:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 16:11:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 16:11:27 --> Final output sent to browser
DEBUG - 2020-03-07 16:11:27 --> Total execution time: 0.0054
INFO - 2020-03-07 16:11:39 --> Config Class Initialized
INFO - 2020-03-07 16:11:39 --> Hooks Class Initialized
DEBUG - 2020-03-07 16:11:39 --> UTF-8 Support Enabled
INFO - 2020-03-07 16:11:39 --> Utf8 Class Initialized
INFO - 2020-03-07 16:11:39 --> URI Class Initialized
DEBUG - 2020-03-07 16:11:39 --> No URI present. Default controller set.
INFO - 2020-03-07 16:11:39 --> Router Class Initialized
INFO - 2020-03-07 16:11:39 --> Output Class Initialized
INFO - 2020-03-07 16:11:39 --> Security Class Initialized
DEBUG - 2020-03-07 16:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 16:11:39 --> Input Class Initialized
INFO - 2020-03-07 16:11:39 --> Language Class Initialized
INFO - 2020-03-07 16:11:39 --> Loader Class Initialized
INFO - 2020-03-07 16:11:39 --> Helper loaded: url_helper
INFO - 2020-03-07 16:11:39 --> Helper loaded: string_helper
INFO - 2020-03-07 16:11:39 --> Database Driver Class Initialized
DEBUG - 2020-03-07 16:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 16:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 16:11:39 --> Controller Class Initialized
INFO - 2020-03-07 16:11:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 16:11:39 --> Pagination Class Initialized
INFO - 2020-03-07 16:11:39 --> Model "M_show" initialized
INFO - 2020-03-07 16:11:39 --> Helper loaded: form_helper
INFO - 2020-03-07 16:11:39 --> Form Validation Class Initialized
INFO - 2020-03-07 16:11:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 16:11:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 16:11:39 --> Final output sent to browser
DEBUG - 2020-03-07 16:11:39 --> Total execution time: 0.0073
INFO - 2020-03-07 16:11:59 --> Config Class Initialized
INFO - 2020-03-07 16:11:59 --> Hooks Class Initialized
DEBUG - 2020-03-07 16:11:59 --> UTF-8 Support Enabled
INFO - 2020-03-07 16:11:59 --> Utf8 Class Initialized
INFO - 2020-03-07 16:11:59 --> URI Class Initialized
INFO - 2020-03-07 16:11:59 --> Router Class Initialized
INFO - 2020-03-07 16:11:59 --> Output Class Initialized
INFO - 2020-03-07 16:11:59 --> Security Class Initialized
DEBUG - 2020-03-07 16:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 16:11:59 --> Input Class Initialized
INFO - 2020-03-07 16:11:59 --> Language Class Initialized
INFO - 2020-03-07 16:11:59 --> Loader Class Initialized
INFO - 2020-03-07 16:11:59 --> Helper loaded: url_helper
INFO - 2020-03-07 16:11:59 --> Helper loaded: string_helper
INFO - 2020-03-07 16:11:59 --> Database Driver Class Initialized
DEBUG - 2020-03-07 16:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 16:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 16:11:59 --> Controller Class Initialized
INFO - 2020-03-07 16:11:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 16:11:59 --> Pagination Class Initialized
INFO - 2020-03-07 16:11:59 --> Model "M_show" initialized
INFO - 2020-03-07 16:11:59 --> Helper loaded: form_helper
INFO - 2020-03-07 16:11:59 --> Form Validation Class Initialized
INFO - 2020-03-07 16:11:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 16:11:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 16:11:59 --> Final output sent to browser
DEBUG - 2020-03-07 16:11:59 --> Total execution time: 0.1626
INFO - 2020-03-07 16:12:30 --> Config Class Initialized
INFO - 2020-03-07 16:12:30 --> Hooks Class Initialized
DEBUG - 2020-03-07 16:12:30 --> UTF-8 Support Enabled
INFO - 2020-03-07 16:12:30 --> Utf8 Class Initialized
INFO - 2020-03-07 16:12:30 --> URI Class Initialized
INFO - 2020-03-07 16:12:30 --> Router Class Initialized
INFO - 2020-03-07 16:12:30 --> Output Class Initialized
INFO - 2020-03-07 16:12:30 --> Security Class Initialized
DEBUG - 2020-03-07 16:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 16:12:30 --> Input Class Initialized
INFO - 2020-03-07 16:12:30 --> Language Class Initialized
INFO - 2020-03-07 16:12:30 --> Loader Class Initialized
INFO - 2020-03-07 16:12:30 --> Helper loaded: url_helper
INFO - 2020-03-07 16:12:30 --> Helper loaded: string_helper
INFO - 2020-03-07 16:12:30 --> Database Driver Class Initialized
DEBUG - 2020-03-07 16:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 16:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 16:12:30 --> Controller Class Initialized
INFO - 2020-03-07 16:12:30 --> Model "M_tiket" initialized
INFO - 2020-03-07 16:12:30 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 16:12:30 --> Model "M_pesan" initialized
INFO - 2020-03-07 16:12:30 --> Helper loaded: form_helper
INFO - 2020-03-07 16:12:30 --> Form Validation Class Initialized
INFO - 2020-03-07 16:12:30 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 16:12:30 --> Final output sent to browser
DEBUG - 2020-03-07 16:12:30 --> Total execution time: 0.0077
INFO - 2020-03-07 16:12:52 --> Config Class Initialized
INFO - 2020-03-07 16:12:52 --> Hooks Class Initialized
DEBUG - 2020-03-07 16:12:52 --> UTF-8 Support Enabled
INFO - 2020-03-07 16:12:52 --> Utf8 Class Initialized
INFO - 2020-03-07 16:12:52 --> URI Class Initialized
INFO - 2020-03-07 16:12:52 --> Router Class Initialized
INFO - 2020-03-07 16:12:52 --> Output Class Initialized
INFO - 2020-03-07 16:12:52 --> Security Class Initialized
DEBUG - 2020-03-07 16:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 16:12:52 --> Input Class Initialized
INFO - 2020-03-07 16:12:52 --> Language Class Initialized
INFO - 2020-03-07 16:12:52 --> Loader Class Initialized
INFO - 2020-03-07 16:12:52 --> Helper loaded: url_helper
INFO - 2020-03-07 16:12:52 --> Helper loaded: string_helper
INFO - 2020-03-07 16:12:52 --> Database Driver Class Initialized
DEBUG - 2020-03-07 16:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 16:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 16:12:52 --> Controller Class Initialized
INFO - 2020-03-07 16:12:52 --> Model "M_tiket" initialized
INFO - 2020-03-07 16:12:52 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 16:12:52 --> Model "M_pesan" initialized
INFO - 2020-03-07 16:12:52 --> Helper loaded: form_helper
INFO - 2020-03-07 16:12:52 --> Form Validation Class Initialized
INFO - 2020-03-07 16:12:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 16:12:52 --> Final output sent to browser
DEBUG - 2020-03-07 16:12:52 --> Total execution time: 0.0090
INFO - 2020-03-07 16:48:15 --> Config Class Initialized
INFO - 2020-03-07 16:48:15 --> Hooks Class Initialized
DEBUG - 2020-03-07 16:48:15 --> UTF-8 Support Enabled
INFO - 2020-03-07 16:48:15 --> Utf8 Class Initialized
INFO - 2020-03-07 16:48:15 --> URI Class Initialized
DEBUG - 2020-03-07 16:48:15 --> No URI present. Default controller set.
INFO - 2020-03-07 16:48:15 --> Router Class Initialized
INFO - 2020-03-07 16:48:15 --> Output Class Initialized
INFO - 2020-03-07 16:48:15 --> Security Class Initialized
DEBUG - 2020-03-07 16:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 16:48:15 --> Input Class Initialized
INFO - 2020-03-07 16:48:15 --> Language Class Initialized
INFO - 2020-03-07 16:48:15 --> Loader Class Initialized
INFO - 2020-03-07 16:48:15 --> Helper loaded: url_helper
INFO - 2020-03-07 16:48:15 --> Helper loaded: string_helper
INFO - 2020-03-07 16:48:15 --> Database Driver Class Initialized
DEBUG - 2020-03-07 16:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 16:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 16:48:15 --> Controller Class Initialized
INFO - 2020-03-07 16:48:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 16:48:15 --> Pagination Class Initialized
INFO - 2020-03-07 16:48:15 --> Model "M_show" initialized
INFO - 2020-03-07 16:48:15 --> Helper loaded: form_helper
INFO - 2020-03-07 16:48:15 --> Form Validation Class Initialized
INFO - 2020-03-07 16:48:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 16:48:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 16:48:15 --> Final output sent to browser
DEBUG - 2020-03-07 16:48:15 --> Total execution time: 0.6497
INFO - 2020-03-07 16:50:08 --> Config Class Initialized
INFO - 2020-03-07 16:50:08 --> Hooks Class Initialized
DEBUG - 2020-03-07 16:50:08 --> UTF-8 Support Enabled
INFO - 2020-03-07 16:50:08 --> Utf8 Class Initialized
INFO - 2020-03-07 16:50:08 --> URI Class Initialized
DEBUG - 2020-03-07 16:50:08 --> No URI present. Default controller set.
INFO - 2020-03-07 16:50:08 --> Router Class Initialized
INFO - 2020-03-07 16:50:08 --> Output Class Initialized
INFO - 2020-03-07 16:50:08 --> Security Class Initialized
DEBUG - 2020-03-07 16:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 16:50:08 --> Input Class Initialized
INFO - 2020-03-07 16:50:08 --> Language Class Initialized
INFO - 2020-03-07 16:50:08 --> Loader Class Initialized
INFO - 2020-03-07 16:50:08 --> Helper loaded: url_helper
INFO - 2020-03-07 16:50:08 --> Helper loaded: string_helper
INFO - 2020-03-07 16:50:08 --> Database Driver Class Initialized
DEBUG - 2020-03-07 16:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 16:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 16:50:08 --> Controller Class Initialized
INFO - 2020-03-07 16:50:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 16:50:08 --> Pagination Class Initialized
INFO - 2020-03-07 16:50:08 --> Model "M_show" initialized
INFO - 2020-03-07 16:50:08 --> Helper loaded: form_helper
INFO - 2020-03-07 16:50:08 --> Form Validation Class Initialized
INFO - 2020-03-07 16:50:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 16:50:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 16:50:08 --> Final output sent to browser
DEBUG - 2020-03-07 16:50:08 --> Total execution time: 0.0558
INFO - 2020-03-07 16:50:33 --> Config Class Initialized
INFO - 2020-03-07 16:50:33 --> Hooks Class Initialized
DEBUG - 2020-03-07 16:50:33 --> UTF-8 Support Enabled
INFO - 2020-03-07 16:50:33 --> Utf8 Class Initialized
INFO - 2020-03-07 16:50:33 --> URI Class Initialized
INFO - 2020-03-07 16:50:33 --> Router Class Initialized
INFO - 2020-03-07 16:50:33 --> Output Class Initialized
INFO - 2020-03-07 16:50:33 --> Security Class Initialized
DEBUG - 2020-03-07 16:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 16:50:33 --> Input Class Initialized
INFO - 2020-03-07 16:50:33 --> Language Class Initialized
INFO - 2020-03-07 16:50:33 --> Loader Class Initialized
INFO - 2020-03-07 16:50:33 --> Helper loaded: url_helper
INFO - 2020-03-07 16:50:33 --> Helper loaded: string_helper
INFO - 2020-03-07 16:50:33 --> Database Driver Class Initialized
DEBUG - 2020-03-07 16:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 16:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 16:50:33 --> Controller Class Initialized
INFO - 2020-03-07 16:50:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 16:50:33 --> Pagination Class Initialized
INFO - 2020-03-07 16:50:33 --> Model "M_show" initialized
INFO - 2020-03-07 16:50:33 --> Helper loaded: form_helper
INFO - 2020-03-07 16:50:33 --> Form Validation Class Initialized
INFO - 2020-03-07 16:50:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 16:50:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-07 16:50:33 --> Final output sent to browser
DEBUG - 2020-03-07 16:50:33 --> Total execution time: 0.0055
INFO - 2020-03-07 16:50:45 --> Config Class Initialized
INFO - 2020-03-07 16:50:45 --> Hooks Class Initialized
DEBUG - 2020-03-07 16:50:45 --> UTF-8 Support Enabled
INFO - 2020-03-07 16:50:45 --> Utf8 Class Initialized
INFO - 2020-03-07 16:50:45 --> URI Class Initialized
DEBUG - 2020-03-07 16:50:45 --> No URI present. Default controller set.
INFO - 2020-03-07 16:50:45 --> Router Class Initialized
INFO - 2020-03-07 16:50:45 --> Output Class Initialized
INFO - 2020-03-07 16:50:45 --> Security Class Initialized
DEBUG - 2020-03-07 16:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 16:50:45 --> Input Class Initialized
INFO - 2020-03-07 16:50:45 --> Language Class Initialized
INFO - 2020-03-07 16:50:45 --> Loader Class Initialized
INFO - 2020-03-07 16:50:45 --> Helper loaded: url_helper
INFO - 2020-03-07 16:50:45 --> Helper loaded: string_helper
INFO - 2020-03-07 16:50:45 --> Database Driver Class Initialized
DEBUG - 2020-03-07 16:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 16:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 16:50:45 --> Controller Class Initialized
INFO - 2020-03-07 16:50:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 16:50:45 --> Pagination Class Initialized
INFO - 2020-03-07 16:50:45 --> Model "M_show" initialized
INFO - 2020-03-07 16:50:45 --> Helper loaded: form_helper
INFO - 2020-03-07 16:50:45 --> Form Validation Class Initialized
INFO - 2020-03-07 16:50:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 16:50:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 16:50:45 --> Final output sent to browser
DEBUG - 2020-03-07 16:50:45 --> Total execution time: 0.0061
INFO - 2020-03-07 16:50:49 --> Config Class Initialized
INFO - 2020-03-07 16:50:49 --> Hooks Class Initialized
DEBUG - 2020-03-07 16:50:49 --> UTF-8 Support Enabled
INFO - 2020-03-07 16:50:49 --> Utf8 Class Initialized
INFO - 2020-03-07 16:50:49 --> URI Class Initialized
INFO - 2020-03-07 16:50:49 --> Router Class Initialized
INFO - 2020-03-07 16:50:49 --> Output Class Initialized
INFO - 2020-03-07 16:50:49 --> Security Class Initialized
DEBUG - 2020-03-07 16:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 16:50:49 --> Input Class Initialized
INFO - 2020-03-07 16:50:49 --> Language Class Initialized
INFO - 2020-03-07 16:50:49 --> Loader Class Initialized
INFO - 2020-03-07 16:50:49 --> Helper loaded: url_helper
INFO - 2020-03-07 16:50:49 --> Helper loaded: string_helper
INFO - 2020-03-07 16:50:49 --> Database Driver Class Initialized
DEBUG - 2020-03-07 16:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 16:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 16:50:49 --> Controller Class Initialized
INFO - 2020-03-07 16:50:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 16:50:49 --> Pagination Class Initialized
INFO - 2020-03-07 16:50:49 --> Model "M_show" initialized
INFO - 2020-03-07 16:50:49 --> Helper loaded: form_helper
INFO - 2020-03-07 16:50:49 --> Form Validation Class Initialized
INFO - 2020-03-07 16:50:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 16:50:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/gal.php
INFO - 2020-03-07 16:50:49 --> Final output sent to browser
DEBUG - 2020-03-07 16:50:49 --> Total execution time: 0.0163
INFO - 2020-03-07 16:56:01 --> Config Class Initialized
INFO - 2020-03-07 16:56:01 --> Hooks Class Initialized
DEBUG - 2020-03-07 16:56:01 --> UTF-8 Support Enabled
INFO - 2020-03-07 16:56:01 --> Utf8 Class Initialized
INFO - 2020-03-07 16:56:01 --> URI Class Initialized
DEBUG - 2020-03-07 16:56:01 --> No URI present. Default controller set.
INFO - 2020-03-07 16:56:01 --> Router Class Initialized
INFO - 2020-03-07 16:56:01 --> Output Class Initialized
INFO - 2020-03-07 16:56:01 --> Security Class Initialized
DEBUG - 2020-03-07 16:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 16:56:01 --> Input Class Initialized
INFO - 2020-03-07 16:56:01 --> Language Class Initialized
INFO - 2020-03-07 16:56:01 --> Loader Class Initialized
INFO - 2020-03-07 16:56:01 --> Helper loaded: url_helper
INFO - 2020-03-07 16:56:01 --> Helper loaded: string_helper
INFO - 2020-03-07 16:56:01 --> Database Driver Class Initialized
DEBUG - 2020-03-07 16:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 16:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 16:56:01 --> Controller Class Initialized
INFO - 2020-03-07 16:56:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 16:56:01 --> Pagination Class Initialized
INFO - 2020-03-07 16:56:01 --> Model "M_show" initialized
INFO - 2020-03-07 16:56:01 --> Helper loaded: form_helper
INFO - 2020-03-07 16:56:01 --> Form Validation Class Initialized
INFO - 2020-03-07 16:56:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 16:56:01 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 16:56:01 --> Final output sent to browser
DEBUG - 2020-03-07 16:56:01 --> Total execution time: 0.2851
INFO - 2020-03-07 16:56:26 --> Config Class Initialized
INFO - 2020-03-07 16:56:26 --> Hooks Class Initialized
DEBUG - 2020-03-07 16:56:26 --> UTF-8 Support Enabled
INFO - 2020-03-07 16:56:26 --> Utf8 Class Initialized
INFO - 2020-03-07 16:56:26 --> URI Class Initialized
INFO - 2020-03-07 16:56:26 --> Router Class Initialized
INFO - 2020-03-07 16:56:26 --> Output Class Initialized
INFO - 2020-03-07 16:56:26 --> Security Class Initialized
DEBUG - 2020-03-07 16:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 16:56:26 --> Input Class Initialized
INFO - 2020-03-07 16:56:26 --> Language Class Initialized
INFO - 2020-03-07 16:56:26 --> Loader Class Initialized
INFO - 2020-03-07 16:56:26 --> Helper loaded: url_helper
INFO - 2020-03-07 16:56:26 --> Helper loaded: string_helper
INFO - 2020-03-07 16:56:26 --> Database Driver Class Initialized
DEBUG - 2020-03-07 16:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 16:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 16:56:26 --> Controller Class Initialized
INFO - 2020-03-07 16:56:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 16:56:26 --> Pagination Class Initialized
INFO - 2020-03-07 16:56:26 --> Model "M_show" initialized
INFO - 2020-03-07 16:56:26 --> Helper loaded: form_helper
INFO - 2020-03-07 16:56:26 --> Form Validation Class Initialized
INFO - 2020-03-07 16:56:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 16:56:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 16:56:26 --> Final output sent to browser
DEBUG - 2020-03-07 16:56:26 --> Total execution time: 0.0563
INFO - 2020-03-07 16:56:30 --> Config Class Initialized
INFO - 2020-03-07 16:56:30 --> Hooks Class Initialized
DEBUG - 2020-03-07 16:56:30 --> UTF-8 Support Enabled
INFO - 2020-03-07 16:56:30 --> Utf8 Class Initialized
INFO - 2020-03-07 16:56:30 --> URI Class Initialized
INFO - 2020-03-07 16:56:30 --> Router Class Initialized
INFO - 2020-03-07 16:56:30 --> Output Class Initialized
INFO - 2020-03-07 16:56:30 --> Security Class Initialized
DEBUG - 2020-03-07 16:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 16:56:30 --> Input Class Initialized
INFO - 2020-03-07 16:56:30 --> Language Class Initialized
INFO - 2020-03-07 16:56:30 --> Loader Class Initialized
INFO - 2020-03-07 16:56:30 --> Helper loaded: url_helper
INFO - 2020-03-07 16:56:30 --> Helper loaded: string_helper
INFO - 2020-03-07 16:56:30 --> Database Driver Class Initialized
DEBUG - 2020-03-07 16:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 16:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 16:56:30 --> Controller Class Initialized
INFO - 2020-03-07 16:56:31 --> Model "M_tiket" initialized
INFO - 2020-03-07 16:56:31 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 16:56:31 --> Model "M_pesan" initialized
INFO - 2020-03-07 16:56:31 --> Helper loaded: form_helper
INFO - 2020-03-07 16:56:31 --> Form Validation Class Initialized
INFO - 2020-03-07 16:56:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 16:56:31 --> Final output sent to browser
DEBUG - 2020-03-07 16:56:31 --> Total execution time: 0.0782
INFO - 2020-03-07 16:56:53 --> Config Class Initialized
INFO - 2020-03-07 16:56:53 --> Hooks Class Initialized
DEBUG - 2020-03-07 16:56:53 --> UTF-8 Support Enabled
INFO - 2020-03-07 16:56:53 --> Utf8 Class Initialized
INFO - 2020-03-07 16:56:53 --> URI Class Initialized
INFO - 2020-03-07 16:56:53 --> Router Class Initialized
INFO - 2020-03-07 16:56:53 --> Output Class Initialized
INFO - 2020-03-07 16:56:53 --> Security Class Initialized
DEBUG - 2020-03-07 16:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 16:56:53 --> Input Class Initialized
INFO - 2020-03-07 16:56:53 --> Language Class Initialized
INFO - 2020-03-07 16:56:53 --> Loader Class Initialized
INFO - 2020-03-07 16:56:53 --> Helper loaded: url_helper
INFO - 2020-03-07 16:56:53 --> Helper loaded: string_helper
INFO - 2020-03-07 16:56:53 --> Database Driver Class Initialized
DEBUG - 2020-03-07 16:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 16:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 16:56:53 --> Controller Class Initialized
INFO - 2020-03-07 16:56:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 16:56:53 --> Pagination Class Initialized
INFO - 2020-03-07 16:56:53 --> Model "M_show" initialized
INFO - 2020-03-07 16:56:53 --> Helper loaded: form_helper
INFO - 2020-03-07 16:56:53 --> Form Validation Class Initialized
INFO - 2020-03-07 16:56:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 16:56:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 16:56:53 --> Final output sent to browser
DEBUG - 2020-03-07 16:56:53 --> Total execution time: 0.0062
INFO - 2020-03-07 16:56:54 --> Config Class Initialized
INFO - 2020-03-07 16:56:54 --> Hooks Class Initialized
DEBUG - 2020-03-07 16:56:54 --> UTF-8 Support Enabled
INFO - 2020-03-07 16:56:54 --> Utf8 Class Initialized
INFO - 2020-03-07 16:56:54 --> URI Class Initialized
DEBUG - 2020-03-07 16:56:54 --> No URI present. Default controller set.
INFO - 2020-03-07 16:56:54 --> Router Class Initialized
INFO - 2020-03-07 16:56:54 --> Output Class Initialized
INFO - 2020-03-07 16:56:54 --> Security Class Initialized
DEBUG - 2020-03-07 16:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 16:56:54 --> Input Class Initialized
INFO - 2020-03-07 16:56:54 --> Language Class Initialized
INFO - 2020-03-07 16:56:54 --> Loader Class Initialized
INFO - 2020-03-07 16:56:54 --> Helper loaded: url_helper
INFO - 2020-03-07 16:56:54 --> Helper loaded: string_helper
INFO - 2020-03-07 16:56:54 --> Database Driver Class Initialized
DEBUG - 2020-03-07 16:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 16:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 16:56:54 --> Controller Class Initialized
INFO - 2020-03-07 16:56:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 16:56:54 --> Pagination Class Initialized
INFO - 2020-03-07 16:56:54 --> Model "M_show" initialized
INFO - 2020-03-07 16:56:54 --> Helper loaded: form_helper
INFO - 2020-03-07 16:56:54 --> Form Validation Class Initialized
INFO - 2020-03-07 16:56:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 16:56:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 16:56:54 --> Final output sent to browser
DEBUG - 2020-03-07 16:56:54 --> Total execution time: 0.0056
INFO - 2020-03-07 16:57:25 --> Config Class Initialized
INFO - 2020-03-07 16:57:25 --> Hooks Class Initialized
DEBUG - 2020-03-07 16:57:25 --> UTF-8 Support Enabled
INFO - 2020-03-07 16:57:25 --> Utf8 Class Initialized
INFO - 2020-03-07 16:57:25 --> URI Class Initialized
DEBUG - 2020-03-07 16:57:25 --> No URI present. Default controller set.
INFO - 2020-03-07 16:57:25 --> Router Class Initialized
INFO - 2020-03-07 16:57:25 --> Output Class Initialized
INFO - 2020-03-07 16:57:25 --> Security Class Initialized
DEBUG - 2020-03-07 16:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 16:57:25 --> Input Class Initialized
INFO - 2020-03-07 16:57:25 --> Language Class Initialized
INFO - 2020-03-07 16:57:25 --> Loader Class Initialized
INFO - 2020-03-07 16:57:25 --> Helper loaded: url_helper
INFO - 2020-03-07 16:57:25 --> Helper loaded: string_helper
INFO - 2020-03-07 16:57:25 --> Database Driver Class Initialized
DEBUG - 2020-03-07 16:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 16:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 16:57:25 --> Controller Class Initialized
INFO - 2020-03-07 16:57:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 16:57:25 --> Pagination Class Initialized
INFO - 2020-03-07 16:57:25 --> Model "M_show" initialized
INFO - 2020-03-07 16:57:25 --> Helper loaded: form_helper
INFO - 2020-03-07 16:57:25 --> Form Validation Class Initialized
INFO - 2020-03-07 16:57:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 16:57:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 16:57:25 --> Final output sent to browser
DEBUG - 2020-03-07 16:57:25 --> Total execution time: 0.0179
INFO - 2020-03-07 17:21:11 --> Config Class Initialized
INFO - 2020-03-07 17:21:11 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:21:11 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:21:11 --> Utf8 Class Initialized
INFO - 2020-03-07 17:21:11 --> URI Class Initialized
DEBUG - 2020-03-07 17:21:11 --> No URI present. Default controller set.
INFO - 2020-03-07 17:21:11 --> Router Class Initialized
INFO - 2020-03-07 17:21:11 --> Output Class Initialized
INFO - 2020-03-07 17:21:11 --> Security Class Initialized
DEBUG - 2020-03-07 17:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:21:11 --> Input Class Initialized
INFO - 2020-03-07 17:21:11 --> Language Class Initialized
INFO - 2020-03-07 17:21:11 --> Loader Class Initialized
INFO - 2020-03-07 17:21:11 --> Helper loaded: url_helper
INFO - 2020-03-07 17:21:11 --> Helper loaded: string_helper
INFO - 2020-03-07 17:21:11 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:21:11 --> Controller Class Initialized
INFO - 2020-03-07 17:21:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 17:21:11 --> Pagination Class Initialized
INFO - 2020-03-07 17:21:11 --> Model "M_show" initialized
INFO - 2020-03-07 17:21:11 --> Helper loaded: form_helper
INFO - 2020-03-07 17:21:11 --> Form Validation Class Initialized
INFO - 2020-03-07 17:21:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 17:21:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 17:21:11 --> Final output sent to browser
DEBUG - 2020-03-07 17:21:11 --> Total execution time: 0.0467
INFO - 2020-03-07 17:21:24 --> Config Class Initialized
INFO - 2020-03-07 17:21:24 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:21:24 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:21:24 --> Utf8 Class Initialized
INFO - 2020-03-07 17:21:24 --> URI Class Initialized
INFO - 2020-03-07 17:21:24 --> Router Class Initialized
INFO - 2020-03-07 17:21:24 --> Output Class Initialized
INFO - 2020-03-07 17:21:24 --> Security Class Initialized
DEBUG - 2020-03-07 17:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:21:24 --> Input Class Initialized
INFO - 2020-03-07 17:21:24 --> Language Class Initialized
INFO - 2020-03-07 17:21:24 --> Loader Class Initialized
INFO - 2020-03-07 17:21:24 --> Helper loaded: url_helper
INFO - 2020-03-07 17:21:24 --> Helper loaded: string_helper
INFO - 2020-03-07 17:21:24 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:21:24 --> Controller Class Initialized
INFO - 2020-03-07 17:21:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 17:21:24 --> Pagination Class Initialized
INFO - 2020-03-07 17:21:24 --> Model "M_show" initialized
INFO - 2020-03-07 17:21:24 --> Helper loaded: form_helper
INFO - 2020-03-07 17:21:24 --> Form Validation Class Initialized
INFO - 2020-03-07 17:21:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 17:21:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 17:21:24 --> Final output sent to browser
DEBUG - 2020-03-07 17:21:24 --> Total execution time: 0.0093
INFO - 2020-03-07 17:21:24 --> Config Class Initialized
INFO - 2020-03-07 17:21:24 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:21:24 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:21:24 --> Utf8 Class Initialized
INFO - 2020-03-07 17:21:24 --> URI Class Initialized
INFO - 2020-03-07 17:21:24 --> Router Class Initialized
INFO - 2020-03-07 17:21:24 --> Output Class Initialized
INFO - 2020-03-07 17:21:24 --> Security Class Initialized
DEBUG - 2020-03-07 17:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:21:24 --> Input Class Initialized
INFO - 2020-03-07 17:21:24 --> Language Class Initialized
ERROR - 2020-03-07 17:21:24 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-07 17:21:29 --> Config Class Initialized
INFO - 2020-03-07 17:21:29 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:21:29 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:21:29 --> Utf8 Class Initialized
INFO - 2020-03-07 17:21:29 --> URI Class Initialized
INFO - 2020-03-07 17:21:29 --> Router Class Initialized
INFO - 2020-03-07 17:21:29 --> Output Class Initialized
INFO - 2020-03-07 17:21:29 --> Security Class Initialized
DEBUG - 2020-03-07 17:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:21:29 --> Input Class Initialized
INFO - 2020-03-07 17:21:29 --> Language Class Initialized
INFO - 2020-03-07 17:21:29 --> Loader Class Initialized
INFO - 2020-03-07 17:21:29 --> Helper loaded: url_helper
INFO - 2020-03-07 17:21:29 --> Helper loaded: string_helper
INFO - 2020-03-07 17:21:29 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:21:29 --> Controller Class Initialized
INFO - 2020-03-07 17:21:29 --> Model "M_tiket" initialized
INFO - 2020-03-07 17:21:29 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 17:21:29 --> Model "M_pesan" initialized
INFO - 2020-03-07 17:21:29 --> Helper loaded: form_helper
INFO - 2020-03-07 17:21:29 --> Form Validation Class Initialized
INFO - 2020-03-07 17:21:29 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 17:21:29 --> Final output sent to browser
DEBUG - 2020-03-07 17:21:29 --> Total execution time: 0.0109
INFO - 2020-03-07 17:22:06 --> Config Class Initialized
INFO - 2020-03-07 17:22:06 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:22:06 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:22:06 --> Utf8 Class Initialized
INFO - 2020-03-07 17:22:06 --> URI Class Initialized
INFO - 2020-03-07 17:22:06 --> Router Class Initialized
INFO - 2020-03-07 17:22:06 --> Output Class Initialized
INFO - 2020-03-07 17:22:06 --> Security Class Initialized
DEBUG - 2020-03-07 17:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:22:06 --> Input Class Initialized
INFO - 2020-03-07 17:22:06 --> Language Class Initialized
INFO - 2020-03-07 17:22:06 --> Loader Class Initialized
INFO - 2020-03-07 17:22:06 --> Helper loaded: url_helper
INFO - 2020-03-07 17:22:06 --> Helper loaded: string_helper
INFO - 2020-03-07 17:22:06 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:22:06 --> Controller Class Initialized
INFO - 2020-03-07 17:22:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 17:22:06 --> Pagination Class Initialized
INFO - 2020-03-07 17:22:06 --> Model "M_show" initialized
INFO - 2020-03-07 17:22:06 --> Helper loaded: form_helper
INFO - 2020-03-07 17:22:06 --> Form Validation Class Initialized
INFO - 2020-03-07 17:22:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 17:22:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 17:22:06 --> Final output sent to browser
DEBUG - 2020-03-07 17:22:06 --> Total execution time: 0.0066
INFO - 2020-03-07 17:22:08 --> Config Class Initialized
INFO - 2020-03-07 17:22:08 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:22:08 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:22:08 --> Utf8 Class Initialized
INFO - 2020-03-07 17:22:08 --> URI Class Initialized
DEBUG - 2020-03-07 17:22:08 --> No URI present. Default controller set.
INFO - 2020-03-07 17:22:08 --> Router Class Initialized
INFO - 2020-03-07 17:22:08 --> Output Class Initialized
INFO - 2020-03-07 17:22:08 --> Security Class Initialized
DEBUG - 2020-03-07 17:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:22:08 --> Input Class Initialized
INFO - 2020-03-07 17:22:08 --> Language Class Initialized
INFO - 2020-03-07 17:22:08 --> Loader Class Initialized
INFO - 2020-03-07 17:22:08 --> Helper loaded: url_helper
INFO - 2020-03-07 17:22:08 --> Helper loaded: string_helper
INFO - 2020-03-07 17:22:08 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:22:08 --> Controller Class Initialized
INFO - 2020-03-07 17:22:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 17:22:08 --> Pagination Class Initialized
INFO - 2020-03-07 17:22:08 --> Model "M_show" initialized
INFO - 2020-03-07 17:22:08 --> Helper loaded: form_helper
INFO - 2020-03-07 17:22:08 --> Form Validation Class Initialized
INFO - 2020-03-07 17:22:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 17:22:08 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 17:22:08 --> Final output sent to browser
DEBUG - 2020-03-07 17:22:08 --> Total execution time: 0.0823
INFO - 2020-03-07 17:22:16 --> Config Class Initialized
INFO - 2020-03-07 17:22:16 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:22:16 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:22:16 --> Utf8 Class Initialized
INFO - 2020-03-07 17:22:16 --> URI Class Initialized
INFO - 2020-03-07 17:22:16 --> Router Class Initialized
INFO - 2020-03-07 17:22:16 --> Output Class Initialized
INFO - 2020-03-07 17:22:16 --> Security Class Initialized
DEBUG - 2020-03-07 17:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:22:16 --> Input Class Initialized
INFO - 2020-03-07 17:22:16 --> Language Class Initialized
INFO - 2020-03-07 17:22:16 --> Loader Class Initialized
INFO - 2020-03-07 17:22:16 --> Helper loaded: url_helper
INFO - 2020-03-07 17:22:16 --> Helper loaded: string_helper
INFO - 2020-03-07 17:22:16 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:22:16 --> Controller Class Initialized
INFO - 2020-03-07 17:22:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 17:22:16 --> Pagination Class Initialized
INFO - 2020-03-07 17:22:16 --> Model "M_show" initialized
INFO - 2020-03-07 17:22:16 --> Helper loaded: form_helper
INFO - 2020-03-07 17:22:16 --> Form Validation Class Initialized
INFO - 2020-03-07 17:22:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 17:22:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-07 17:22:16 --> Final output sent to browser
DEBUG - 2020-03-07 17:22:16 --> Total execution time: 0.0061
INFO - 2020-03-07 17:22:42 --> Config Class Initialized
INFO - 2020-03-07 17:22:42 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:22:42 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:22:42 --> Utf8 Class Initialized
INFO - 2020-03-07 17:22:42 --> URI Class Initialized
DEBUG - 2020-03-07 17:22:42 --> No URI present. Default controller set.
INFO - 2020-03-07 17:22:42 --> Router Class Initialized
INFO - 2020-03-07 17:22:42 --> Output Class Initialized
INFO - 2020-03-07 17:22:42 --> Security Class Initialized
DEBUG - 2020-03-07 17:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:22:42 --> Input Class Initialized
INFO - 2020-03-07 17:22:42 --> Language Class Initialized
INFO - 2020-03-07 17:22:42 --> Loader Class Initialized
INFO - 2020-03-07 17:22:42 --> Helper loaded: url_helper
INFO - 2020-03-07 17:22:42 --> Helper loaded: string_helper
INFO - 2020-03-07 17:22:42 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:22:42 --> Controller Class Initialized
INFO - 2020-03-07 17:22:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 17:22:42 --> Pagination Class Initialized
INFO - 2020-03-07 17:22:42 --> Model "M_show" initialized
INFO - 2020-03-07 17:22:42 --> Helper loaded: form_helper
INFO - 2020-03-07 17:22:42 --> Form Validation Class Initialized
INFO - 2020-03-07 17:22:42 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 17:22:42 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 17:22:42 --> Final output sent to browser
DEBUG - 2020-03-07 17:22:42 --> Total execution time: 0.1099
INFO - 2020-03-07 17:22:56 --> Config Class Initialized
INFO - 2020-03-07 17:22:56 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:22:56 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:22:56 --> Utf8 Class Initialized
INFO - 2020-03-07 17:22:56 --> URI Class Initialized
INFO - 2020-03-07 17:22:56 --> Router Class Initialized
INFO - 2020-03-07 17:22:56 --> Output Class Initialized
INFO - 2020-03-07 17:22:56 --> Security Class Initialized
DEBUG - 2020-03-07 17:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:22:56 --> Input Class Initialized
INFO - 2020-03-07 17:22:56 --> Language Class Initialized
INFO - 2020-03-07 17:22:56 --> Loader Class Initialized
INFO - 2020-03-07 17:22:56 --> Helper loaded: url_helper
INFO - 2020-03-07 17:22:56 --> Helper loaded: string_helper
INFO - 2020-03-07 17:22:56 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:22:56 --> Controller Class Initialized
INFO - 2020-03-07 17:22:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 17:22:56 --> Pagination Class Initialized
INFO - 2020-03-07 17:22:56 --> Model "M_show" initialized
INFO - 2020-03-07 17:22:56 --> Helper loaded: form_helper
INFO - 2020-03-07 17:22:56 --> Form Validation Class Initialized
INFO - 2020-03-07 17:22:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 17:22:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 17:22:56 --> Final output sent to browser
DEBUG - 2020-03-07 17:22:56 --> Total execution time: 0.0073
INFO - 2020-03-07 17:23:04 --> Config Class Initialized
INFO - 2020-03-07 17:23:04 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:23:04 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:23:04 --> Utf8 Class Initialized
INFO - 2020-03-07 17:23:04 --> URI Class Initialized
INFO - 2020-03-07 17:23:04 --> Router Class Initialized
INFO - 2020-03-07 17:23:04 --> Output Class Initialized
INFO - 2020-03-07 17:23:04 --> Security Class Initialized
DEBUG - 2020-03-07 17:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:23:04 --> Input Class Initialized
INFO - 2020-03-07 17:23:04 --> Language Class Initialized
INFO - 2020-03-07 17:23:04 --> Loader Class Initialized
INFO - 2020-03-07 17:23:04 --> Helper loaded: url_helper
INFO - 2020-03-07 17:23:04 --> Helper loaded: string_helper
INFO - 2020-03-07 17:23:04 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:23:04 --> Controller Class Initialized
INFO - 2020-03-07 17:23:04 --> Model "M_tiket" initialized
INFO - 2020-03-07 17:23:04 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 17:23:04 --> Model "M_pesan" initialized
INFO - 2020-03-07 17:23:04 --> Helper loaded: form_helper
INFO - 2020-03-07 17:23:04 --> Form Validation Class Initialized
INFO - 2020-03-07 17:23:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 17:23:04 --> Final output sent to browser
DEBUG - 2020-03-07 17:23:04 --> Total execution time: 0.0111
INFO - 2020-03-07 17:23:31 --> Config Class Initialized
INFO - 2020-03-07 17:23:31 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:23:31 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:23:31 --> Utf8 Class Initialized
INFO - 2020-03-07 17:23:31 --> URI Class Initialized
INFO - 2020-03-07 17:23:31 --> Router Class Initialized
INFO - 2020-03-07 17:23:31 --> Output Class Initialized
INFO - 2020-03-07 17:23:31 --> Security Class Initialized
DEBUG - 2020-03-07 17:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:23:31 --> Input Class Initialized
INFO - 2020-03-07 17:23:31 --> Language Class Initialized
INFO - 2020-03-07 17:23:31 --> Loader Class Initialized
INFO - 2020-03-07 17:23:31 --> Helper loaded: url_helper
INFO - 2020-03-07 17:23:31 --> Helper loaded: string_helper
INFO - 2020-03-07 17:23:31 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:23:31 --> Controller Class Initialized
INFO - 2020-03-07 17:23:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 17:23:31 --> Pagination Class Initialized
INFO - 2020-03-07 17:23:31 --> Model "M_show" initialized
INFO - 2020-03-07 17:23:31 --> Helper loaded: form_helper
INFO - 2020-03-07 17:23:31 --> Form Validation Class Initialized
INFO - 2020-03-07 17:23:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 17:23:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 17:23:31 --> Final output sent to browser
DEBUG - 2020-03-07 17:23:31 --> Total execution time: 0.0078
INFO - 2020-03-07 17:23:36 --> Config Class Initialized
INFO - 2020-03-07 17:23:36 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:23:36 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:23:36 --> Utf8 Class Initialized
INFO - 2020-03-07 17:23:36 --> URI Class Initialized
INFO - 2020-03-07 17:23:36 --> Router Class Initialized
INFO - 2020-03-07 17:23:36 --> Output Class Initialized
INFO - 2020-03-07 17:23:36 --> Security Class Initialized
DEBUG - 2020-03-07 17:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:23:36 --> Input Class Initialized
INFO - 2020-03-07 17:23:36 --> Language Class Initialized
INFO - 2020-03-07 17:23:36 --> Loader Class Initialized
INFO - 2020-03-07 17:23:36 --> Helper loaded: url_helper
INFO - 2020-03-07 17:23:36 --> Helper loaded: string_helper
INFO - 2020-03-07 17:23:36 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:23:36 --> Controller Class Initialized
INFO - 2020-03-07 17:23:36 --> Model "M_tiket" initialized
INFO - 2020-03-07 17:23:36 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 17:23:36 --> Model "M_pesan" initialized
INFO - 2020-03-07 17:23:36 --> Helper loaded: form_helper
INFO - 2020-03-07 17:23:36 --> Form Validation Class Initialized
INFO - 2020-03-07 17:23:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 17:23:36 --> Final output sent to browser
DEBUG - 2020-03-07 17:23:36 --> Total execution time: 0.0075
INFO - 2020-03-07 17:23:55 --> Config Class Initialized
INFO - 2020-03-07 17:23:55 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:23:55 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:23:55 --> Utf8 Class Initialized
INFO - 2020-03-07 17:23:55 --> URI Class Initialized
INFO - 2020-03-07 17:23:55 --> Router Class Initialized
INFO - 2020-03-07 17:23:55 --> Output Class Initialized
INFO - 2020-03-07 17:23:55 --> Security Class Initialized
DEBUG - 2020-03-07 17:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:23:55 --> Input Class Initialized
INFO - 2020-03-07 17:23:55 --> Language Class Initialized
INFO - 2020-03-07 17:23:55 --> Loader Class Initialized
INFO - 2020-03-07 17:23:55 --> Helper loaded: url_helper
INFO - 2020-03-07 17:23:55 --> Helper loaded: string_helper
INFO - 2020-03-07 17:23:55 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:23:55 --> Controller Class Initialized
INFO - 2020-03-07 17:23:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 17:23:55 --> Pagination Class Initialized
INFO - 2020-03-07 17:23:55 --> Model "M_show" initialized
INFO - 2020-03-07 17:23:55 --> Helper loaded: form_helper
INFO - 2020-03-07 17:23:55 --> Form Validation Class Initialized
INFO - 2020-03-07 17:23:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 17:23:55 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 17:23:55 --> Final output sent to browser
DEBUG - 2020-03-07 17:23:55 --> Total execution time: 0.0059
INFO - 2020-03-07 17:24:06 --> Config Class Initialized
INFO - 2020-03-07 17:24:06 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:24:06 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:24:06 --> Utf8 Class Initialized
INFO - 2020-03-07 17:24:06 --> URI Class Initialized
INFO - 2020-03-07 17:24:06 --> Router Class Initialized
INFO - 2020-03-07 17:24:06 --> Output Class Initialized
INFO - 2020-03-07 17:24:06 --> Security Class Initialized
DEBUG - 2020-03-07 17:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:24:06 --> Input Class Initialized
INFO - 2020-03-07 17:24:06 --> Language Class Initialized
INFO - 2020-03-07 17:24:06 --> Loader Class Initialized
INFO - 2020-03-07 17:24:06 --> Helper loaded: url_helper
INFO - 2020-03-07 17:24:06 --> Helper loaded: string_helper
INFO - 2020-03-07 17:24:06 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:24:06 --> Controller Class Initialized
INFO - 2020-03-07 17:24:06 --> Model "M_tiket" initialized
INFO - 2020-03-07 17:24:06 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 17:24:06 --> Model "M_pesan" initialized
INFO - 2020-03-07 17:24:06 --> Helper loaded: form_helper
INFO - 2020-03-07 17:24:06 --> Form Validation Class Initialized
INFO - 2020-03-07 17:24:06 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 17:24:06 --> Final output sent to browser
DEBUG - 2020-03-07 17:24:06 --> Total execution time: 0.0070
INFO - 2020-03-07 17:24:10 --> Config Class Initialized
INFO - 2020-03-07 17:24:10 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:24:10 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:24:10 --> Utf8 Class Initialized
INFO - 2020-03-07 17:24:10 --> URI Class Initialized
INFO - 2020-03-07 17:24:10 --> Router Class Initialized
INFO - 2020-03-07 17:24:10 --> Output Class Initialized
INFO - 2020-03-07 17:24:10 --> Security Class Initialized
DEBUG - 2020-03-07 17:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:24:10 --> Input Class Initialized
INFO - 2020-03-07 17:24:10 --> Language Class Initialized
INFO - 2020-03-07 17:24:10 --> Loader Class Initialized
INFO - 2020-03-07 17:24:10 --> Helper loaded: url_helper
INFO - 2020-03-07 17:24:10 --> Helper loaded: string_helper
INFO - 2020-03-07 17:24:10 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:24:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:24:10 --> Controller Class Initialized
INFO - 2020-03-07 17:24:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 17:24:10 --> Pagination Class Initialized
INFO - 2020-03-07 17:24:10 --> Model "M_show" initialized
INFO - 2020-03-07 17:24:10 --> Helper loaded: form_helper
INFO - 2020-03-07 17:24:10 --> Form Validation Class Initialized
INFO - 2020-03-07 17:24:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 17:24:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 17:24:10 --> Final output sent to browser
DEBUG - 2020-03-07 17:24:10 --> Total execution time: 0.0077
INFO - 2020-03-07 17:24:17 --> Config Class Initialized
INFO - 2020-03-07 17:24:17 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:24:17 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:24:17 --> Utf8 Class Initialized
INFO - 2020-03-07 17:24:17 --> URI Class Initialized
INFO - 2020-03-07 17:24:17 --> Router Class Initialized
INFO - 2020-03-07 17:24:17 --> Output Class Initialized
INFO - 2020-03-07 17:24:17 --> Security Class Initialized
DEBUG - 2020-03-07 17:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:24:17 --> Input Class Initialized
INFO - 2020-03-07 17:24:17 --> Language Class Initialized
INFO - 2020-03-07 17:24:17 --> Loader Class Initialized
INFO - 2020-03-07 17:24:17 --> Helper loaded: url_helper
INFO - 2020-03-07 17:24:17 --> Helper loaded: string_helper
INFO - 2020-03-07 17:24:17 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:24:17 --> Controller Class Initialized
INFO - 2020-03-07 17:24:17 --> Model "M_tiket" initialized
INFO - 2020-03-07 17:24:17 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 17:24:17 --> Model "M_pesan" initialized
INFO - 2020-03-07 17:24:17 --> Helper loaded: form_helper
INFO - 2020-03-07 17:24:17 --> Form Validation Class Initialized
INFO - 2020-03-07 17:24:17 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 17:24:17 --> Final output sent to browser
DEBUG - 2020-03-07 17:24:17 --> Total execution time: 0.0090
INFO - 2020-03-07 17:24:30 --> Config Class Initialized
INFO - 2020-03-07 17:24:30 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:24:30 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:24:30 --> Utf8 Class Initialized
INFO - 2020-03-07 17:24:30 --> URI Class Initialized
INFO - 2020-03-07 17:24:30 --> Router Class Initialized
INFO - 2020-03-07 17:24:30 --> Output Class Initialized
INFO - 2020-03-07 17:24:30 --> Security Class Initialized
DEBUG - 2020-03-07 17:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:24:30 --> Input Class Initialized
INFO - 2020-03-07 17:24:30 --> Language Class Initialized
INFO - 2020-03-07 17:24:30 --> Loader Class Initialized
INFO - 2020-03-07 17:24:30 --> Helper loaded: url_helper
INFO - 2020-03-07 17:24:30 --> Helper loaded: string_helper
INFO - 2020-03-07 17:24:30 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:24:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:24:30 --> Controller Class Initialized
INFO - 2020-03-07 17:24:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 17:24:30 --> Pagination Class Initialized
INFO - 2020-03-07 17:24:30 --> Model "M_show" initialized
INFO - 2020-03-07 17:24:30 --> Helper loaded: form_helper
INFO - 2020-03-07 17:24:30 --> Form Validation Class Initialized
INFO - 2020-03-07 17:24:30 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 17:24:30 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 17:24:30 --> Final output sent to browser
DEBUG - 2020-03-07 17:24:30 --> Total execution time: 0.0059
INFO - 2020-03-07 17:24:31 --> Config Class Initialized
INFO - 2020-03-07 17:24:31 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:24:31 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:24:31 --> Utf8 Class Initialized
INFO - 2020-03-07 17:24:31 --> URI Class Initialized
DEBUG - 2020-03-07 17:24:31 --> No URI present. Default controller set.
INFO - 2020-03-07 17:24:31 --> Router Class Initialized
INFO - 2020-03-07 17:24:31 --> Output Class Initialized
INFO - 2020-03-07 17:24:31 --> Security Class Initialized
DEBUG - 2020-03-07 17:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:24:31 --> Input Class Initialized
INFO - 2020-03-07 17:24:31 --> Language Class Initialized
INFO - 2020-03-07 17:24:31 --> Loader Class Initialized
INFO - 2020-03-07 17:24:31 --> Helper loaded: url_helper
INFO - 2020-03-07 17:24:31 --> Helper loaded: string_helper
INFO - 2020-03-07 17:24:31 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:24:31 --> Controller Class Initialized
INFO - 2020-03-07 17:24:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 17:24:31 --> Pagination Class Initialized
INFO - 2020-03-07 17:24:31 --> Model "M_show" initialized
INFO - 2020-03-07 17:24:31 --> Helper loaded: form_helper
INFO - 2020-03-07 17:24:31 --> Form Validation Class Initialized
INFO - 2020-03-07 17:24:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 17:24:31 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 17:24:31 --> Final output sent to browser
DEBUG - 2020-03-07 17:24:31 --> Total execution time: 0.0059
INFO - 2020-03-07 17:28:36 --> Config Class Initialized
INFO - 2020-03-07 17:28:36 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:28:36 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:28:36 --> Utf8 Class Initialized
INFO - 2020-03-07 17:28:36 --> URI Class Initialized
DEBUG - 2020-03-07 17:28:36 --> No URI present. Default controller set.
INFO - 2020-03-07 17:28:36 --> Router Class Initialized
INFO - 2020-03-07 17:28:36 --> Output Class Initialized
INFO - 2020-03-07 17:28:36 --> Security Class Initialized
DEBUG - 2020-03-07 17:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:28:36 --> Input Class Initialized
INFO - 2020-03-07 17:28:36 --> Language Class Initialized
INFO - 2020-03-07 17:28:36 --> Loader Class Initialized
INFO - 2020-03-07 17:28:36 --> Helper loaded: url_helper
INFO - 2020-03-07 17:28:36 --> Helper loaded: string_helper
INFO - 2020-03-07 17:28:37 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:28:37 --> Controller Class Initialized
INFO - 2020-03-07 17:28:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 17:28:37 --> Pagination Class Initialized
INFO - 2020-03-07 17:28:37 --> Model "M_show" initialized
INFO - 2020-03-07 17:28:37 --> Helper loaded: form_helper
INFO - 2020-03-07 17:28:37 --> Form Validation Class Initialized
INFO - 2020-03-07 17:28:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 17:28:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 17:28:37 --> Final output sent to browser
DEBUG - 2020-03-07 17:28:37 --> Total execution time: 0.0568
INFO - 2020-03-07 17:28:54 --> Config Class Initialized
INFO - 2020-03-07 17:28:54 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:28:54 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:28:54 --> Utf8 Class Initialized
INFO - 2020-03-07 17:28:54 --> URI Class Initialized
INFO - 2020-03-07 17:28:54 --> Router Class Initialized
INFO - 2020-03-07 17:28:54 --> Output Class Initialized
INFO - 2020-03-07 17:28:54 --> Security Class Initialized
DEBUG - 2020-03-07 17:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:28:54 --> Input Class Initialized
INFO - 2020-03-07 17:28:54 --> Language Class Initialized
INFO - 2020-03-07 17:28:54 --> Loader Class Initialized
INFO - 2020-03-07 17:28:54 --> Helper loaded: url_helper
INFO - 2020-03-07 17:28:54 --> Helper loaded: string_helper
INFO - 2020-03-07 17:28:54 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:28:54 --> Controller Class Initialized
INFO - 2020-03-07 17:28:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 17:28:54 --> Pagination Class Initialized
INFO - 2020-03-07 17:28:54 --> Model "M_show" initialized
INFO - 2020-03-07 17:28:54 --> Helper loaded: form_helper
INFO - 2020-03-07 17:28:54 --> Form Validation Class Initialized
INFO - 2020-03-07 17:28:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 17:28:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 17:28:54 --> Final output sent to browser
DEBUG - 2020-03-07 17:28:54 --> Total execution time: 0.0063
INFO - 2020-03-07 17:29:03 --> Config Class Initialized
INFO - 2020-03-07 17:29:03 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:29:03 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:29:03 --> Utf8 Class Initialized
INFO - 2020-03-07 17:29:03 --> URI Class Initialized
INFO - 2020-03-07 17:29:03 --> Router Class Initialized
INFO - 2020-03-07 17:29:03 --> Output Class Initialized
INFO - 2020-03-07 17:29:03 --> Security Class Initialized
DEBUG - 2020-03-07 17:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:29:03 --> Input Class Initialized
INFO - 2020-03-07 17:29:03 --> Language Class Initialized
INFO - 2020-03-07 17:29:03 --> Loader Class Initialized
INFO - 2020-03-07 17:29:03 --> Helper loaded: url_helper
INFO - 2020-03-07 17:29:03 --> Helper loaded: string_helper
INFO - 2020-03-07 17:29:03 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:29:03 --> Controller Class Initialized
INFO - 2020-03-07 17:29:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 17:29:03 --> Pagination Class Initialized
INFO - 2020-03-07 17:29:03 --> Model "M_show" initialized
INFO - 2020-03-07 17:29:03 --> Helper loaded: form_helper
INFO - 2020-03-07 17:29:03 --> Form Validation Class Initialized
INFO - 2020-03-07 17:29:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 17:29:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-07 17:29:03 --> Final output sent to browser
DEBUG - 2020-03-07 17:29:03 --> Total execution time: 0.0062
INFO - 2020-03-07 17:29:12 --> Config Class Initialized
INFO - 2020-03-07 17:29:12 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:29:12 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:29:12 --> Utf8 Class Initialized
INFO - 2020-03-07 17:29:12 --> URI Class Initialized
DEBUG - 2020-03-07 17:29:12 --> No URI present. Default controller set.
INFO - 2020-03-07 17:29:12 --> Router Class Initialized
INFO - 2020-03-07 17:29:12 --> Output Class Initialized
INFO - 2020-03-07 17:29:12 --> Security Class Initialized
DEBUG - 2020-03-07 17:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:29:12 --> Input Class Initialized
INFO - 2020-03-07 17:29:12 --> Language Class Initialized
INFO - 2020-03-07 17:29:12 --> Loader Class Initialized
INFO - 2020-03-07 17:29:12 --> Helper loaded: url_helper
INFO - 2020-03-07 17:29:12 --> Helper loaded: string_helper
INFO - 2020-03-07 17:29:12 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:29:12 --> Controller Class Initialized
INFO - 2020-03-07 17:29:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 17:29:12 --> Pagination Class Initialized
INFO - 2020-03-07 17:29:12 --> Model "M_show" initialized
INFO - 2020-03-07 17:29:12 --> Helper loaded: form_helper
INFO - 2020-03-07 17:29:12 --> Form Validation Class Initialized
INFO - 2020-03-07 17:29:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 17:29:12 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 17:29:12 --> Final output sent to browser
DEBUG - 2020-03-07 17:29:12 --> Total execution time: 0.0054
INFO - 2020-03-07 17:29:25 --> Config Class Initialized
INFO - 2020-03-07 17:29:25 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:29:25 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:29:25 --> Utf8 Class Initialized
INFO - 2020-03-07 17:29:25 --> URI Class Initialized
INFO - 2020-03-07 17:29:25 --> Router Class Initialized
INFO - 2020-03-07 17:29:25 --> Output Class Initialized
INFO - 2020-03-07 17:29:25 --> Security Class Initialized
DEBUG - 2020-03-07 17:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:29:25 --> Input Class Initialized
INFO - 2020-03-07 17:29:25 --> Language Class Initialized
INFO - 2020-03-07 17:29:25 --> Loader Class Initialized
INFO - 2020-03-07 17:29:25 --> Helper loaded: url_helper
INFO - 2020-03-07 17:29:25 --> Helper loaded: string_helper
INFO - 2020-03-07 17:29:25 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:29:25 --> Controller Class Initialized
INFO - 2020-03-07 17:29:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 17:29:25 --> Pagination Class Initialized
INFO - 2020-03-07 17:29:25 --> Model "M_show" initialized
INFO - 2020-03-07 17:29:25 --> Helper loaded: form_helper
INFO - 2020-03-07 17:29:25 --> Form Validation Class Initialized
INFO - 2020-03-07 17:29:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 17:29:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-07 17:29:25 --> Final output sent to browser
DEBUG - 2020-03-07 17:29:25 --> Total execution time: 0.0062
INFO - 2020-03-07 17:30:43 --> Config Class Initialized
INFO - 2020-03-07 17:30:43 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:30:43 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:30:43 --> Utf8 Class Initialized
INFO - 2020-03-07 17:30:43 --> URI Class Initialized
DEBUG - 2020-03-07 17:30:43 --> No URI present. Default controller set.
INFO - 2020-03-07 17:30:43 --> Router Class Initialized
INFO - 2020-03-07 17:30:43 --> Output Class Initialized
INFO - 2020-03-07 17:30:43 --> Security Class Initialized
DEBUG - 2020-03-07 17:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:30:43 --> Input Class Initialized
INFO - 2020-03-07 17:30:43 --> Language Class Initialized
INFO - 2020-03-07 17:30:43 --> Loader Class Initialized
INFO - 2020-03-07 17:30:43 --> Helper loaded: url_helper
INFO - 2020-03-07 17:30:43 --> Helper loaded: string_helper
INFO - 2020-03-07 17:30:43 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:30:43 --> Controller Class Initialized
INFO - 2020-03-07 17:30:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 17:30:43 --> Pagination Class Initialized
INFO - 2020-03-07 17:30:43 --> Model "M_show" initialized
INFO - 2020-03-07 17:30:43 --> Helper loaded: form_helper
INFO - 2020-03-07 17:30:43 --> Form Validation Class Initialized
INFO - 2020-03-07 17:30:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 17:30:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 17:30:43 --> Final output sent to browser
DEBUG - 2020-03-07 17:30:43 --> Total execution time: 0.0345
INFO - 2020-03-07 17:30:50 --> Config Class Initialized
INFO - 2020-03-07 17:30:50 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:30:50 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:30:50 --> Utf8 Class Initialized
INFO - 2020-03-07 17:30:50 --> URI Class Initialized
INFO - 2020-03-07 17:30:50 --> Router Class Initialized
INFO - 2020-03-07 17:30:50 --> Output Class Initialized
INFO - 2020-03-07 17:30:50 --> Security Class Initialized
DEBUG - 2020-03-07 17:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:30:50 --> Input Class Initialized
INFO - 2020-03-07 17:30:50 --> Language Class Initialized
INFO - 2020-03-07 17:30:50 --> Loader Class Initialized
INFO - 2020-03-07 17:30:50 --> Helper loaded: url_helper
INFO - 2020-03-07 17:30:50 --> Helper loaded: string_helper
INFO - 2020-03-07 17:30:50 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:30:50 --> Controller Class Initialized
INFO - 2020-03-07 17:30:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 17:30:50 --> Pagination Class Initialized
INFO - 2020-03-07 17:30:50 --> Model "M_show" initialized
INFO - 2020-03-07 17:30:50 --> Helper loaded: form_helper
INFO - 2020-03-07 17:30:50 --> Form Validation Class Initialized
INFO - 2020-03-07 17:30:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 17:30:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-07 17:30:50 --> Final output sent to browser
DEBUG - 2020-03-07 17:30:50 --> Total execution time: 0.0060
INFO - 2020-03-07 17:30:58 --> Config Class Initialized
INFO - 2020-03-07 17:30:58 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:30:58 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:30:58 --> Utf8 Class Initialized
INFO - 2020-03-07 17:30:58 --> URI Class Initialized
INFO - 2020-03-07 17:30:58 --> Router Class Initialized
INFO - 2020-03-07 17:30:58 --> Output Class Initialized
INFO - 2020-03-07 17:30:58 --> Security Class Initialized
DEBUG - 2020-03-07 17:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:30:58 --> Input Class Initialized
INFO - 2020-03-07 17:30:58 --> Language Class Initialized
INFO - 2020-03-07 17:30:58 --> Loader Class Initialized
INFO - 2020-03-07 17:30:58 --> Helper loaded: url_helper
INFO - 2020-03-07 17:30:58 --> Helper loaded: string_helper
INFO - 2020-03-07 17:30:58 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:30:58 --> Controller Class Initialized
INFO - 2020-03-07 17:30:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 17:30:58 --> Pagination Class Initialized
INFO - 2020-03-07 17:30:58 --> Model "M_show" initialized
INFO - 2020-03-07 17:30:58 --> Helper loaded: form_helper
INFO - 2020-03-07 17:30:58 --> Form Validation Class Initialized
INFO - 2020-03-07 17:30:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 17:30:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tentang.php
INFO - 2020-03-07 17:30:58 --> Final output sent to browser
DEBUG - 2020-03-07 17:30:58 --> Total execution time: 0.0178
INFO - 2020-03-07 17:31:09 --> Config Class Initialized
INFO - 2020-03-07 17:31:09 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:31:09 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:31:09 --> Utf8 Class Initialized
INFO - 2020-03-07 17:31:09 --> URI Class Initialized
INFO - 2020-03-07 17:31:09 --> Router Class Initialized
INFO - 2020-03-07 17:31:09 --> Output Class Initialized
INFO - 2020-03-07 17:31:09 --> Security Class Initialized
DEBUG - 2020-03-07 17:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:31:09 --> Input Class Initialized
INFO - 2020-03-07 17:31:09 --> Language Class Initialized
INFO - 2020-03-07 17:31:09 --> Loader Class Initialized
INFO - 2020-03-07 17:31:09 --> Helper loaded: url_helper
INFO - 2020-03-07 17:31:09 --> Helper loaded: string_helper
INFO - 2020-03-07 17:31:09 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:31:09 --> Controller Class Initialized
INFO - 2020-03-07 17:31:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 17:31:09 --> Pagination Class Initialized
INFO - 2020-03-07 17:31:09 --> Model "M_show" initialized
INFO - 2020-03-07 17:31:09 --> Helper loaded: form_helper
INFO - 2020-03-07 17:31:09 --> Form Validation Class Initialized
INFO - 2020-03-07 17:31:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 17:31:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 17:31:09 --> Final output sent to browser
DEBUG - 2020-03-07 17:31:09 --> Total execution time: 0.0076
INFO - 2020-03-07 17:31:13 --> Config Class Initialized
INFO - 2020-03-07 17:31:13 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:31:13 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:31:13 --> Utf8 Class Initialized
INFO - 2020-03-07 17:31:13 --> URI Class Initialized
INFO - 2020-03-07 17:31:13 --> Router Class Initialized
INFO - 2020-03-07 17:31:13 --> Output Class Initialized
INFO - 2020-03-07 17:31:13 --> Security Class Initialized
DEBUG - 2020-03-07 17:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:31:13 --> Input Class Initialized
INFO - 2020-03-07 17:31:13 --> Language Class Initialized
INFO - 2020-03-07 17:31:13 --> Loader Class Initialized
INFO - 2020-03-07 17:31:13 --> Helper loaded: url_helper
INFO - 2020-03-07 17:31:13 --> Helper loaded: string_helper
INFO - 2020-03-07 17:31:13 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:31:13 --> Controller Class Initialized
INFO - 2020-03-07 17:31:13 --> Model "M_tiket" initialized
INFO - 2020-03-07 17:31:13 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 17:31:13 --> Model "M_pesan" initialized
INFO - 2020-03-07 17:31:13 --> Helper loaded: form_helper
INFO - 2020-03-07 17:31:13 --> Form Validation Class Initialized
INFO - 2020-03-07 17:31:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 17:31:13 --> Final output sent to browser
DEBUG - 2020-03-07 17:31:13 --> Total execution time: 0.0114
INFO - 2020-03-07 17:31:45 --> Config Class Initialized
INFO - 2020-03-07 17:31:45 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:31:45 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:31:45 --> Utf8 Class Initialized
INFO - 2020-03-07 17:31:45 --> URI Class Initialized
DEBUG - 2020-03-07 17:31:45 --> No URI present. Default controller set.
INFO - 2020-03-07 17:31:45 --> Router Class Initialized
INFO - 2020-03-07 17:31:45 --> Output Class Initialized
INFO - 2020-03-07 17:31:45 --> Security Class Initialized
DEBUG - 2020-03-07 17:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:31:45 --> Input Class Initialized
INFO - 2020-03-07 17:31:45 --> Language Class Initialized
INFO - 2020-03-07 17:31:45 --> Loader Class Initialized
INFO - 2020-03-07 17:31:45 --> Helper loaded: url_helper
INFO - 2020-03-07 17:31:45 --> Helper loaded: string_helper
INFO - 2020-03-07 17:31:45 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:31:45 --> Controller Class Initialized
INFO - 2020-03-07 17:31:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 17:31:45 --> Pagination Class Initialized
INFO - 2020-03-07 17:31:45 --> Model "M_show" initialized
INFO - 2020-03-07 17:31:45 --> Helper loaded: form_helper
INFO - 2020-03-07 17:31:45 --> Form Validation Class Initialized
INFO - 2020-03-07 17:31:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 17:31:45 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 17:31:45 --> Final output sent to browser
DEBUG - 2020-03-07 17:31:45 --> Total execution time: 0.0055
INFO - 2020-03-07 17:31:59 --> Config Class Initialized
INFO - 2020-03-07 17:31:59 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:31:59 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:31:59 --> Utf8 Class Initialized
INFO - 2020-03-07 17:31:59 --> URI Class Initialized
INFO - 2020-03-07 17:31:59 --> Router Class Initialized
INFO - 2020-03-07 17:31:59 --> Output Class Initialized
INFO - 2020-03-07 17:31:59 --> Security Class Initialized
DEBUG - 2020-03-07 17:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:31:59 --> Input Class Initialized
INFO - 2020-03-07 17:31:59 --> Language Class Initialized
INFO - 2020-03-07 17:31:59 --> Loader Class Initialized
INFO - 2020-03-07 17:31:59 --> Helper loaded: url_helper
INFO - 2020-03-07 17:31:59 --> Helper loaded: string_helper
INFO - 2020-03-07 17:31:59 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:31:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:31:59 --> Controller Class Initialized
INFO - 2020-03-07 17:31:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 17:31:59 --> Pagination Class Initialized
INFO - 2020-03-07 17:31:59 --> Model "M_show" initialized
INFO - 2020-03-07 17:31:59 --> Helper loaded: form_helper
INFO - 2020-03-07 17:31:59 --> Form Validation Class Initialized
INFO - 2020-03-07 17:31:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 17:31:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-07 17:31:59 --> Final output sent to browser
DEBUG - 2020-03-07 17:31:59 --> Total execution time: 0.0077
INFO - 2020-03-07 17:32:13 --> Config Class Initialized
INFO - 2020-03-07 17:32:13 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:32:13 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:32:13 --> Utf8 Class Initialized
INFO - 2020-03-07 17:32:13 --> URI Class Initialized
INFO - 2020-03-07 17:32:13 --> Router Class Initialized
INFO - 2020-03-07 17:32:13 --> Output Class Initialized
INFO - 2020-03-07 17:32:13 --> Security Class Initialized
DEBUG - 2020-03-07 17:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:32:13 --> Input Class Initialized
INFO - 2020-03-07 17:32:13 --> Language Class Initialized
INFO - 2020-03-07 17:32:13 --> Loader Class Initialized
INFO - 2020-03-07 17:32:13 --> Helper loaded: url_helper
INFO - 2020-03-07 17:32:13 --> Helper loaded: string_helper
INFO - 2020-03-07 17:32:13 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:32:13 --> Controller Class Initialized
INFO - 2020-03-07 17:32:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 17:32:13 --> Pagination Class Initialized
INFO - 2020-03-07 17:32:13 --> Model "M_show" initialized
INFO - 2020-03-07 17:32:13 --> Helper loaded: form_helper
INFO - 2020-03-07 17:32:13 --> Form Validation Class Initialized
INFO - 2020-03-07 17:32:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 17:32:13 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 17:32:13 --> Final output sent to browser
DEBUG - 2020-03-07 17:32:13 --> Total execution time: 0.0061
INFO - 2020-03-07 17:32:18 --> Config Class Initialized
INFO - 2020-03-07 17:32:18 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:32:18 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:32:18 --> Utf8 Class Initialized
INFO - 2020-03-07 17:32:18 --> URI Class Initialized
INFO - 2020-03-07 17:32:18 --> Router Class Initialized
INFO - 2020-03-07 17:32:18 --> Output Class Initialized
INFO - 2020-03-07 17:32:18 --> Security Class Initialized
DEBUG - 2020-03-07 17:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:32:18 --> Input Class Initialized
INFO - 2020-03-07 17:32:18 --> Language Class Initialized
INFO - 2020-03-07 17:32:18 --> Loader Class Initialized
INFO - 2020-03-07 17:32:18 --> Helper loaded: url_helper
INFO - 2020-03-07 17:32:18 --> Helper loaded: string_helper
INFO - 2020-03-07 17:32:18 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:32:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:32:18 --> Controller Class Initialized
INFO - 2020-03-07 17:32:18 --> Model "M_tiket" initialized
INFO - 2020-03-07 17:32:18 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 17:32:18 --> Model "M_pesan" initialized
INFO - 2020-03-07 17:32:18 --> Helper loaded: form_helper
INFO - 2020-03-07 17:32:18 --> Form Validation Class Initialized
INFO - 2020-03-07 17:32:18 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 17:32:18 --> Final output sent to browser
DEBUG - 2020-03-07 17:32:18 --> Total execution time: 0.0075
INFO - 2020-03-07 17:32:19 --> Config Class Initialized
INFO - 2020-03-07 17:32:19 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:32:19 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:32:19 --> Utf8 Class Initialized
INFO - 2020-03-07 17:32:19 --> URI Class Initialized
DEBUG - 2020-03-07 17:32:19 --> No URI present. Default controller set.
INFO - 2020-03-07 17:32:19 --> Router Class Initialized
INFO - 2020-03-07 17:32:19 --> Output Class Initialized
INFO - 2020-03-07 17:32:19 --> Security Class Initialized
DEBUG - 2020-03-07 17:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:32:19 --> Input Class Initialized
INFO - 2020-03-07 17:32:19 --> Language Class Initialized
INFO - 2020-03-07 17:32:19 --> Loader Class Initialized
INFO - 2020-03-07 17:32:19 --> Helper loaded: url_helper
INFO - 2020-03-07 17:32:19 --> Helper loaded: string_helper
INFO - 2020-03-07 17:32:19 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:32:19 --> Controller Class Initialized
INFO - 2020-03-07 17:32:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 17:32:19 --> Pagination Class Initialized
INFO - 2020-03-07 17:32:19 --> Model "M_show" initialized
INFO - 2020-03-07 17:32:19 --> Helper loaded: form_helper
INFO - 2020-03-07 17:32:19 --> Form Validation Class Initialized
INFO - 2020-03-07 17:32:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 17:32:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 17:32:19 --> Final output sent to browser
DEBUG - 2020-03-07 17:32:19 --> Total execution time: 0.0052
INFO - 2020-03-07 17:32:24 --> Config Class Initialized
INFO - 2020-03-07 17:32:24 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:32:24 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:32:24 --> Utf8 Class Initialized
INFO - 2020-03-07 17:32:24 --> URI Class Initialized
INFO - 2020-03-07 17:32:24 --> Router Class Initialized
INFO - 2020-03-07 17:32:24 --> Output Class Initialized
INFO - 2020-03-07 17:32:24 --> Security Class Initialized
DEBUG - 2020-03-07 17:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:32:24 --> Input Class Initialized
INFO - 2020-03-07 17:32:24 --> Language Class Initialized
INFO - 2020-03-07 17:32:24 --> Loader Class Initialized
INFO - 2020-03-07 17:32:24 --> Helper loaded: url_helper
INFO - 2020-03-07 17:32:24 --> Helper loaded: string_helper
INFO - 2020-03-07 17:32:24 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:32:24 --> Controller Class Initialized
INFO - 2020-03-07 17:32:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 17:32:24 --> Pagination Class Initialized
INFO - 2020-03-07 17:32:24 --> Model "M_show" initialized
INFO - 2020-03-07 17:32:24 --> Helper loaded: form_helper
INFO - 2020-03-07 17:32:24 --> Form Validation Class Initialized
INFO - 2020-03-07 17:32:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 17:32:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 17:32:24 --> Final output sent to browser
DEBUG - 2020-03-07 17:32:24 --> Total execution time: 0.0069
INFO - 2020-03-07 17:32:27 --> Config Class Initialized
INFO - 2020-03-07 17:32:27 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:32:27 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:32:27 --> Utf8 Class Initialized
INFO - 2020-03-07 17:32:27 --> URI Class Initialized
INFO - 2020-03-07 17:32:27 --> Router Class Initialized
INFO - 2020-03-07 17:32:27 --> Output Class Initialized
INFO - 2020-03-07 17:32:27 --> Security Class Initialized
DEBUG - 2020-03-07 17:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:32:27 --> Input Class Initialized
INFO - 2020-03-07 17:32:27 --> Language Class Initialized
INFO - 2020-03-07 17:32:27 --> Loader Class Initialized
INFO - 2020-03-07 17:32:27 --> Helper loaded: url_helper
INFO - 2020-03-07 17:32:27 --> Helper loaded: string_helper
INFO - 2020-03-07 17:32:27 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:32:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:32:27 --> Controller Class Initialized
INFO - 2020-03-07 17:32:27 --> Model "M_tiket" initialized
INFO - 2020-03-07 17:32:27 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 17:32:27 --> Model "M_pesan" initialized
INFO - 2020-03-07 17:32:27 --> Helper loaded: form_helper
INFO - 2020-03-07 17:32:27 --> Form Validation Class Initialized
INFO - 2020-03-07 17:32:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 17:32:27 --> Final output sent to browser
DEBUG - 2020-03-07 17:32:27 --> Total execution time: 0.0083
INFO - 2020-03-07 17:34:53 --> Config Class Initialized
INFO - 2020-03-07 17:34:53 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:34:53 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:34:53 --> Utf8 Class Initialized
INFO - 2020-03-07 17:34:53 --> URI Class Initialized
DEBUG - 2020-03-07 17:34:53 --> No URI present. Default controller set.
INFO - 2020-03-07 17:34:53 --> Router Class Initialized
INFO - 2020-03-07 17:34:53 --> Output Class Initialized
INFO - 2020-03-07 17:34:53 --> Security Class Initialized
DEBUG - 2020-03-07 17:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:34:53 --> Input Class Initialized
INFO - 2020-03-07 17:34:53 --> Language Class Initialized
INFO - 2020-03-07 17:34:53 --> Loader Class Initialized
INFO - 2020-03-07 17:34:53 --> Helper loaded: url_helper
INFO - 2020-03-07 17:34:53 --> Helper loaded: string_helper
INFO - 2020-03-07 17:34:53 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:34:53 --> Controller Class Initialized
INFO - 2020-03-07 17:34:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 17:34:53 --> Pagination Class Initialized
INFO - 2020-03-07 17:34:53 --> Model "M_show" initialized
INFO - 2020-03-07 17:34:53 --> Helper loaded: form_helper
INFO - 2020-03-07 17:34:53 --> Form Validation Class Initialized
INFO - 2020-03-07 17:34:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 17:34:53 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 17:34:53 --> Final output sent to browser
DEBUG - 2020-03-07 17:34:53 --> Total execution time: 0.0500
INFO - 2020-03-07 17:36:42 --> Config Class Initialized
INFO - 2020-03-07 17:36:42 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:36:42 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:36:42 --> Utf8 Class Initialized
INFO - 2020-03-07 17:36:42 --> URI Class Initialized
DEBUG - 2020-03-07 17:36:42 --> No URI present. Default controller set.
INFO - 2020-03-07 17:36:42 --> Router Class Initialized
INFO - 2020-03-07 17:36:42 --> Output Class Initialized
INFO - 2020-03-07 17:36:42 --> Security Class Initialized
DEBUG - 2020-03-07 17:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:36:42 --> Input Class Initialized
INFO - 2020-03-07 17:36:42 --> Language Class Initialized
INFO - 2020-03-07 17:36:42 --> Loader Class Initialized
INFO - 2020-03-07 17:36:42 --> Helper loaded: url_helper
INFO - 2020-03-07 17:36:42 --> Helper loaded: string_helper
INFO - 2020-03-07 17:36:42 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:36:42 --> Controller Class Initialized
INFO - 2020-03-07 17:36:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 17:36:42 --> Pagination Class Initialized
INFO - 2020-03-07 17:36:42 --> Model "M_show" initialized
INFO - 2020-03-07 17:36:42 --> Helper loaded: form_helper
INFO - 2020-03-07 17:36:42 --> Form Validation Class Initialized
INFO - 2020-03-07 17:36:42 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 17:36:42 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 17:36:42 --> Final output sent to browser
DEBUG - 2020-03-07 17:36:42 --> Total execution time: 0.0329
INFO - 2020-03-07 17:36:59 --> Config Class Initialized
INFO - 2020-03-07 17:36:59 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:36:59 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:36:59 --> Utf8 Class Initialized
INFO - 2020-03-07 17:36:59 --> URI Class Initialized
DEBUG - 2020-03-07 17:36:59 --> No URI present. Default controller set.
INFO - 2020-03-07 17:36:59 --> Router Class Initialized
INFO - 2020-03-07 17:36:59 --> Output Class Initialized
INFO - 2020-03-07 17:36:59 --> Security Class Initialized
DEBUG - 2020-03-07 17:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:36:59 --> Input Class Initialized
INFO - 2020-03-07 17:36:59 --> Language Class Initialized
INFO - 2020-03-07 17:36:59 --> Loader Class Initialized
INFO - 2020-03-07 17:36:59 --> Helper loaded: url_helper
INFO - 2020-03-07 17:36:59 --> Helper loaded: string_helper
INFO - 2020-03-07 17:36:59 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:36:59 --> Controller Class Initialized
INFO - 2020-03-07 17:36:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 17:36:59 --> Pagination Class Initialized
INFO - 2020-03-07 17:36:59 --> Model "M_show" initialized
INFO - 2020-03-07 17:36:59 --> Helper loaded: form_helper
INFO - 2020-03-07 17:36:59 --> Form Validation Class Initialized
INFO - 2020-03-07 17:36:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 17:36:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 17:36:59 --> Final output sent to browser
DEBUG - 2020-03-07 17:36:59 --> Total execution time: 0.0150
INFO - 2020-03-07 17:37:04 --> Config Class Initialized
INFO - 2020-03-07 17:37:04 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:37:04 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:37:04 --> Utf8 Class Initialized
INFO - 2020-03-07 17:37:04 --> URI Class Initialized
INFO - 2020-03-07 17:37:04 --> Router Class Initialized
INFO - 2020-03-07 17:37:04 --> Output Class Initialized
INFO - 2020-03-07 17:37:04 --> Security Class Initialized
DEBUG - 2020-03-07 17:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:37:04 --> Input Class Initialized
INFO - 2020-03-07 17:37:04 --> Language Class Initialized
INFO - 2020-03-07 17:37:04 --> Loader Class Initialized
INFO - 2020-03-07 17:37:04 --> Helper loaded: url_helper
INFO - 2020-03-07 17:37:04 --> Helper loaded: string_helper
INFO - 2020-03-07 17:37:04 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:37:04 --> Controller Class Initialized
INFO - 2020-03-07 17:37:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 17:37:04 --> Pagination Class Initialized
INFO - 2020-03-07 17:37:04 --> Model "M_show" initialized
INFO - 2020-03-07 17:37:04 --> Helper loaded: form_helper
INFO - 2020-03-07 17:37:04 --> Form Validation Class Initialized
INFO - 2020-03-07 17:37:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 17:37:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 17:37:04 --> Final output sent to browser
DEBUG - 2020-03-07 17:37:04 --> Total execution time: 0.0079
INFO - 2020-03-07 17:37:09 --> Config Class Initialized
INFO - 2020-03-07 17:37:09 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:37:09 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:37:09 --> Utf8 Class Initialized
INFO - 2020-03-07 17:37:09 --> URI Class Initialized
INFO - 2020-03-07 17:37:09 --> Router Class Initialized
INFO - 2020-03-07 17:37:09 --> Output Class Initialized
INFO - 2020-03-07 17:37:09 --> Security Class Initialized
DEBUG - 2020-03-07 17:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:37:09 --> Input Class Initialized
INFO - 2020-03-07 17:37:09 --> Language Class Initialized
INFO - 2020-03-07 17:37:09 --> Loader Class Initialized
INFO - 2020-03-07 17:37:09 --> Helper loaded: url_helper
INFO - 2020-03-07 17:37:09 --> Helper loaded: string_helper
INFO - 2020-03-07 17:37:09 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:37:09 --> Controller Class Initialized
INFO - 2020-03-07 17:37:09 --> Model "M_tiket" initialized
INFO - 2020-03-07 17:37:09 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 17:37:09 --> Model "M_pesan" initialized
INFO - 2020-03-07 17:37:09 --> Helper loaded: form_helper
INFO - 2020-03-07 17:37:09 --> Form Validation Class Initialized
INFO - 2020-03-07 17:37:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 17:37:09 --> Final output sent to browser
DEBUG - 2020-03-07 17:37:09 --> Total execution time: 0.0138
INFO - 2020-03-07 17:37:26 --> Config Class Initialized
INFO - 2020-03-07 17:37:26 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:37:26 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:37:26 --> Utf8 Class Initialized
INFO - 2020-03-07 17:37:26 --> URI Class Initialized
DEBUG - 2020-03-07 17:37:26 --> No URI present. Default controller set.
INFO - 2020-03-07 17:37:26 --> Router Class Initialized
INFO - 2020-03-07 17:37:26 --> Output Class Initialized
INFO - 2020-03-07 17:37:26 --> Security Class Initialized
DEBUG - 2020-03-07 17:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:37:26 --> Input Class Initialized
INFO - 2020-03-07 17:37:26 --> Language Class Initialized
INFO - 2020-03-07 17:37:26 --> Loader Class Initialized
INFO - 2020-03-07 17:37:26 --> Helper loaded: url_helper
INFO - 2020-03-07 17:37:26 --> Helper loaded: string_helper
INFO - 2020-03-07 17:37:26 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:37:26 --> Controller Class Initialized
INFO - 2020-03-07 17:37:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 17:37:26 --> Pagination Class Initialized
INFO - 2020-03-07 17:37:26 --> Model "M_show" initialized
INFO - 2020-03-07 17:37:26 --> Helper loaded: form_helper
INFO - 2020-03-07 17:37:26 --> Form Validation Class Initialized
INFO - 2020-03-07 17:37:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 17:37:26 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 17:37:26 --> Final output sent to browser
DEBUG - 2020-03-07 17:37:26 --> Total execution time: 0.0381
INFO - 2020-03-07 17:37:56 --> Config Class Initialized
INFO - 2020-03-07 17:37:56 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:37:56 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:37:56 --> Utf8 Class Initialized
INFO - 2020-03-07 17:37:56 --> URI Class Initialized
INFO - 2020-03-07 17:37:56 --> Router Class Initialized
INFO - 2020-03-07 17:37:56 --> Output Class Initialized
INFO - 2020-03-07 17:37:56 --> Security Class Initialized
DEBUG - 2020-03-07 17:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:37:56 --> Input Class Initialized
INFO - 2020-03-07 17:37:56 --> Language Class Initialized
INFO - 2020-03-07 17:37:56 --> Loader Class Initialized
INFO - 2020-03-07 17:37:56 --> Helper loaded: url_helper
INFO - 2020-03-07 17:37:56 --> Helper loaded: string_helper
INFO - 2020-03-07 17:37:56 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:37:56 --> Controller Class Initialized
INFO - 2020-03-07 17:37:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 17:37:56 --> Pagination Class Initialized
INFO - 2020-03-07 17:37:56 --> Model "M_show" initialized
INFO - 2020-03-07 17:37:56 --> Helper loaded: form_helper
INFO - 2020-03-07 17:37:56 --> Form Validation Class Initialized
INFO - 2020-03-07 17:37:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 17:37:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 17:37:56 --> Final output sent to browser
DEBUG - 2020-03-07 17:37:56 --> Total execution time: 0.0110
INFO - 2020-03-07 17:43:58 --> Config Class Initialized
INFO - 2020-03-07 17:43:58 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:43:58 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:43:58 --> Utf8 Class Initialized
INFO - 2020-03-07 17:43:58 --> URI Class Initialized
INFO - 2020-03-07 17:43:58 --> Router Class Initialized
INFO - 2020-03-07 17:43:58 --> Output Class Initialized
INFO - 2020-03-07 17:43:58 --> Security Class Initialized
DEBUG - 2020-03-07 17:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:43:58 --> Input Class Initialized
INFO - 2020-03-07 17:43:58 --> Language Class Initialized
INFO - 2020-03-07 17:43:58 --> Loader Class Initialized
INFO - 2020-03-07 17:43:58 --> Helper loaded: url_helper
INFO - 2020-03-07 17:43:58 --> Helper loaded: string_helper
INFO - 2020-03-07 17:43:58 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:43:58 --> Controller Class Initialized
INFO - 2020-03-07 17:43:58 --> Model "M_tiket" initialized
INFO - 2020-03-07 17:43:58 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 17:43:58 --> Model "M_pesan" initialized
INFO - 2020-03-07 17:43:58 --> Helper loaded: form_helper
INFO - 2020-03-07 17:43:58 --> Form Validation Class Initialized
INFO - 2020-03-07 17:43:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-07 17:43:58 --> Final output sent to browser
DEBUG - 2020-03-07 17:43:58 --> Total execution time: 0.4124
INFO - 2020-03-07 17:44:00 --> Config Class Initialized
INFO - 2020-03-07 17:44:00 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:44:00 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:44:00 --> Utf8 Class Initialized
INFO - 2020-03-07 17:44:00 --> URI Class Initialized
INFO - 2020-03-07 17:44:00 --> Router Class Initialized
INFO - 2020-03-07 17:44:00 --> Output Class Initialized
INFO - 2020-03-07 17:44:00 --> Security Class Initialized
DEBUG - 2020-03-07 17:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:44:00 --> Input Class Initialized
INFO - 2020-03-07 17:44:00 --> Language Class Initialized
INFO - 2020-03-07 17:44:00 --> Loader Class Initialized
INFO - 2020-03-07 17:44:00 --> Helper loaded: url_helper
INFO - 2020-03-07 17:44:00 --> Helper loaded: string_helper
INFO - 2020-03-07 17:44:00 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:44:00 --> Controller Class Initialized
INFO - 2020-03-07 17:44:00 --> Model "M_tiket" initialized
INFO - 2020-03-07 17:44:00 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 17:44:00 --> Model "M_pesan" initialized
INFO - 2020-03-07 17:44:00 --> Helper loaded: form_helper
INFO - 2020-03-07 17:44:00 --> Form Validation Class Initialized
INFO - 2020-03-07 17:44:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-07 17:44:00 --> Final output sent to browser
DEBUG - 2020-03-07 17:44:00 --> Total execution time: 0.0246
INFO - 2020-03-07 17:45:28 --> Config Class Initialized
INFO - 2020-03-07 17:45:28 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:45:28 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:45:28 --> Utf8 Class Initialized
INFO - 2020-03-07 17:45:28 --> URI Class Initialized
INFO - 2020-03-07 17:45:28 --> Router Class Initialized
INFO - 2020-03-07 17:45:28 --> Output Class Initialized
INFO - 2020-03-07 17:45:28 --> Security Class Initialized
DEBUG - 2020-03-07 17:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:45:28 --> Input Class Initialized
INFO - 2020-03-07 17:45:28 --> Language Class Initialized
INFO - 2020-03-07 17:45:28 --> Loader Class Initialized
INFO - 2020-03-07 17:45:28 --> Helper loaded: url_helper
INFO - 2020-03-07 17:45:28 --> Helper loaded: string_helper
INFO - 2020-03-07 17:45:28 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:45:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:45:28 --> Controller Class Initialized
INFO - 2020-03-07 17:45:28 --> Model "M_tiket" initialized
INFO - 2020-03-07 17:45:28 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 17:45:28 --> Model "M_pesan" initialized
INFO - 2020-03-07 17:45:28 --> Helper loaded: form_helper
INFO - 2020-03-07 17:45:28 --> Form Validation Class Initialized
INFO - 2020-03-07 17:45:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-07 17:45:28 --> Final output sent to browser
DEBUG - 2020-03-07 17:45:28 --> Total execution time: 0.0333
INFO - 2020-03-07 17:46:25 --> Config Class Initialized
INFO - 2020-03-07 17:46:25 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:46:25 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:46:25 --> Utf8 Class Initialized
INFO - 2020-03-07 17:46:25 --> URI Class Initialized
INFO - 2020-03-07 17:46:25 --> Router Class Initialized
INFO - 2020-03-07 17:46:25 --> Output Class Initialized
INFO - 2020-03-07 17:46:25 --> Security Class Initialized
DEBUG - 2020-03-07 17:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:46:25 --> Input Class Initialized
INFO - 2020-03-07 17:46:25 --> Language Class Initialized
INFO - 2020-03-07 17:46:25 --> Loader Class Initialized
INFO - 2020-03-07 17:46:25 --> Helper loaded: url_helper
INFO - 2020-03-07 17:46:25 --> Helper loaded: string_helper
INFO - 2020-03-07 17:46:25 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:46:25 --> Controller Class Initialized
INFO - 2020-03-07 17:46:25 --> Model "M_tiket" initialized
INFO - 2020-03-07 17:46:25 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 17:46:25 --> Model "M_pesan" initialized
INFO - 2020-03-07 17:46:25 --> Helper loaded: form_helper
INFO - 2020-03-07 17:46:25 --> Form Validation Class Initialized
INFO - 2020-03-07 17:46:38 --> Config Class Initialized
INFO - 2020-03-07 17:46:38 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:46:38 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:46:38 --> Utf8 Class Initialized
INFO - 2020-03-07 17:46:38 --> URI Class Initialized
INFO - 2020-03-07 17:46:38 --> Router Class Initialized
INFO - 2020-03-07 17:46:38 --> Output Class Initialized
INFO - 2020-03-07 17:46:38 --> Security Class Initialized
DEBUG - 2020-03-07 17:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:46:38 --> Input Class Initialized
INFO - 2020-03-07 17:46:38 --> Language Class Initialized
INFO - 2020-03-07 17:46:38 --> Loader Class Initialized
INFO - 2020-03-07 17:46:38 --> Helper loaded: url_helper
INFO - 2020-03-07 17:46:38 --> Helper loaded: string_helper
INFO - 2020-03-07 17:46:38 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:46:38 --> Controller Class Initialized
INFO - 2020-03-07 17:46:38 --> Model "M_tiket" initialized
INFO - 2020-03-07 17:46:38 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 17:46:38 --> Model "M_pesan" initialized
INFO - 2020-03-07 17:46:38 --> Helper loaded: form_helper
INFO - 2020-03-07 17:46:38 --> Form Validation Class Initialized
INFO - 2020-03-07 17:46:46 --> Config Class Initialized
INFO - 2020-03-07 17:46:46 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:46:46 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:46:46 --> Utf8 Class Initialized
INFO - 2020-03-07 17:46:46 --> URI Class Initialized
INFO - 2020-03-07 17:46:46 --> Router Class Initialized
INFO - 2020-03-07 17:46:46 --> Output Class Initialized
INFO - 2020-03-07 17:46:46 --> Security Class Initialized
DEBUG - 2020-03-07 17:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:46:46 --> Input Class Initialized
INFO - 2020-03-07 17:46:46 --> Language Class Initialized
INFO - 2020-03-07 17:46:46 --> Loader Class Initialized
INFO - 2020-03-07 17:46:46 --> Helper loaded: url_helper
INFO - 2020-03-07 17:46:46 --> Helper loaded: string_helper
INFO - 2020-03-07 17:46:46 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:46:46 --> Controller Class Initialized
INFO - 2020-03-07 17:46:46 --> Model "M_tiket" initialized
INFO - 2020-03-07 17:46:46 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 17:46:46 --> Model "M_pesan" initialized
INFO - 2020-03-07 17:46:46 --> Helper loaded: form_helper
INFO - 2020-03-07 17:46:46 --> Form Validation Class Initialized
INFO - 2020-03-07 17:46:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-07 17:46:46 --> Final output sent to browser
DEBUG - 2020-03-07 17:46:46 --> Total execution time: 0.0069
INFO - 2020-03-07 17:47:00 --> Config Class Initialized
INFO - 2020-03-07 17:47:00 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:47:00 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:47:00 --> Utf8 Class Initialized
INFO - 2020-03-07 17:47:00 --> URI Class Initialized
INFO - 2020-03-07 17:47:00 --> Router Class Initialized
INFO - 2020-03-07 17:47:00 --> Output Class Initialized
INFO - 2020-03-07 17:47:00 --> Security Class Initialized
DEBUG - 2020-03-07 17:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:47:00 --> Input Class Initialized
INFO - 2020-03-07 17:47:00 --> Language Class Initialized
INFO - 2020-03-07 17:47:00 --> Loader Class Initialized
INFO - 2020-03-07 17:47:00 --> Helper loaded: url_helper
INFO - 2020-03-07 17:47:00 --> Helper loaded: string_helper
INFO - 2020-03-07 17:47:00 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:47:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:47:00 --> Controller Class Initialized
INFO - 2020-03-07 17:47:00 --> Model "M_tiket" initialized
INFO - 2020-03-07 17:47:00 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 17:47:00 --> Model "M_pesan" initialized
INFO - 2020-03-07 17:47:00 --> Helper loaded: form_helper
INFO - 2020-03-07 17:47:00 --> Form Validation Class Initialized
INFO - 2020-03-07 17:47:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/pemesanan/bukti.php
INFO - 2020-03-07 17:47:00 --> Final output sent to browser
DEBUG - 2020-03-07 17:47:00 --> Total execution time: 0.0084
INFO - 2020-03-07 17:47:40 --> Config Class Initialized
INFO - 2020-03-07 17:47:40 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:47:40 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:47:40 --> Utf8 Class Initialized
INFO - 2020-03-07 17:47:40 --> URI Class Initialized
INFO - 2020-03-07 17:47:40 --> Router Class Initialized
INFO - 2020-03-07 17:47:40 --> Output Class Initialized
INFO - 2020-03-07 17:47:40 --> Security Class Initialized
DEBUG - 2020-03-07 17:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:47:40 --> Input Class Initialized
INFO - 2020-03-07 17:47:40 --> Language Class Initialized
INFO - 2020-03-07 17:47:40 --> Loader Class Initialized
INFO - 2020-03-07 17:47:40 --> Helper loaded: url_helper
INFO - 2020-03-07 17:47:40 --> Helper loaded: string_helper
INFO - 2020-03-07 17:47:40 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:47:40 --> Controller Class Initialized
INFO - 2020-03-07 17:47:40 --> Model "M_tiket" initialized
INFO - 2020-03-07 17:47:40 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 17:47:40 --> Model "M_pesan" initialized
INFO - 2020-03-07 17:47:40 --> Helper loaded: form_helper
INFO - 2020-03-07 17:47:40 --> Form Validation Class Initialized
INFO - 2020-03-07 17:57:43 --> Config Class Initialized
INFO - 2020-03-07 17:57:43 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:57:43 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:57:43 --> Utf8 Class Initialized
INFO - 2020-03-07 17:57:43 --> URI Class Initialized
DEBUG - 2020-03-07 17:57:43 --> No URI present. Default controller set.
INFO - 2020-03-07 17:57:43 --> Router Class Initialized
INFO - 2020-03-07 17:57:43 --> Output Class Initialized
INFO - 2020-03-07 17:57:43 --> Security Class Initialized
DEBUG - 2020-03-07 17:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:57:43 --> Input Class Initialized
INFO - 2020-03-07 17:57:43 --> Language Class Initialized
INFO - 2020-03-07 17:57:43 --> Loader Class Initialized
INFO - 2020-03-07 17:57:43 --> Helper loaded: url_helper
INFO - 2020-03-07 17:57:43 --> Helper loaded: string_helper
INFO - 2020-03-07 17:57:43 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:57:43 --> Controller Class Initialized
INFO - 2020-03-07 17:57:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 17:57:43 --> Pagination Class Initialized
INFO - 2020-03-07 17:57:43 --> Model "M_show" initialized
INFO - 2020-03-07 17:57:43 --> Helper loaded: form_helper
INFO - 2020-03-07 17:57:43 --> Form Validation Class Initialized
INFO - 2020-03-07 17:57:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 17:57:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 17:57:43 --> Final output sent to browser
DEBUG - 2020-03-07 17:57:43 --> Total execution time: 0.0295
INFO - 2020-03-07 17:57:52 --> Config Class Initialized
INFO - 2020-03-07 17:57:52 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:57:52 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:57:52 --> Utf8 Class Initialized
INFO - 2020-03-07 17:57:52 --> URI Class Initialized
INFO - 2020-03-07 17:57:52 --> Router Class Initialized
INFO - 2020-03-07 17:57:52 --> Output Class Initialized
INFO - 2020-03-07 17:57:52 --> Security Class Initialized
DEBUG - 2020-03-07 17:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:57:52 --> Input Class Initialized
INFO - 2020-03-07 17:57:52 --> Language Class Initialized
INFO - 2020-03-07 17:57:52 --> Loader Class Initialized
INFO - 2020-03-07 17:57:52 --> Helper loaded: url_helper
INFO - 2020-03-07 17:57:52 --> Helper loaded: string_helper
INFO - 2020-03-07 17:57:52 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:57:52 --> Controller Class Initialized
INFO - 2020-03-07 17:57:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 17:57:52 --> Pagination Class Initialized
INFO - 2020-03-07 17:57:52 --> Model "M_show" initialized
INFO - 2020-03-07 17:57:52 --> Helper loaded: form_helper
INFO - 2020-03-07 17:57:52 --> Form Validation Class Initialized
INFO - 2020-03-07 17:57:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 17:57:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 17:57:52 --> Final output sent to browser
DEBUG - 2020-03-07 17:57:52 --> Total execution time: 0.0079
INFO - 2020-03-07 17:57:56 --> Config Class Initialized
INFO - 2020-03-07 17:57:56 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:57:56 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:57:56 --> Utf8 Class Initialized
INFO - 2020-03-07 17:57:56 --> URI Class Initialized
INFO - 2020-03-07 17:57:56 --> Router Class Initialized
INFO - 2020-03-07 17:57:56 --> Output Class Initialized
INFO - 2020-03-07 17:57:56 --> Security Class Initialized
DEBUG - 2020-03-07 17:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:57:56 --> Input Class Initialized
INFO - 2020-03-07 17:57:56 --> Language Class Initialized
INFO - 2020-03-07 17:57:56 --> Loader Class Initialized
INFO - 2020-03-07 17:57:56 --> Helper loaded: url_helper
INFO - 2020-03-07 17:57:56 --> Helper loaded: string_helper
INFO - 2020-03-07 17:57:56 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:57:56 --> Controller Class Initialized
INFO - 2020-03-07 17:57:56 --> Model "M_tiket" initialized
INFO - 2020-03-07 17:57:56 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 17:57:56 --> Model "M_pesan" initialized
INFO - 2020-03-07 17:57:56 --> Helper loaded: form_helper
INFO - 2020-03-07 17:57:56 --> Form Validation Class Initialized
INFO - 2020-03-07 17:57:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 17:57:56 --> Final output sent to browser
DEBUG - 2020-03-07 17:57:56 --> Total execution time: 0.1520
INFO - 2020-03-07 17:58:03 --> Config Class Initialized
INFO - 2020-03-07 17:58:03 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:58:03 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:58:03 --> Utf8 Class Initialized
INFO - 2020-03-07 17:58:03 --> URI Class Initialized
INFO - 2020-03-07 17:58:03 --> Router Class Initialized
INFO - 2020-03-07 17:58:03 --> Output Class Initialized
INFO - 2020-03-07 17:58:03 --> Security Class Initialized
DEBUG - 2020-03-07 17:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:58:03 --> Input Class Initialized
INFO - 2020-03-07 17:58:03 --> Language Class Initialized
INFO - 2020-03-07 17:58:03 --> Loader Class Initialized
INFO - 2020-03-07 17:58:03 --> Helper loaded: url_helper
INFO - 2020-03-07 17:58:03 --> Helper loaded: string_helper
INFO - 2020-03-07 17:58:03 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:58:03 --> Controller Class Initialized
INFO - 2020-03-07 17:58:03 --> Model "M_tiket" initialized
INFO - 2020-03-07 17:58:03 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 17:58:03 --> Model "M_pesan" initialized
INFO - 2020-03-07 17:58:03 --> Helper loaded: form_helper
INFO - 2020-03-07 17:58:03 --> Form Validation Class Initialized
INFO - 2020-03-07 17:58:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 17:58:03 --> Final output sent to browser
DEBUG - 2020-03-07 17:58:03 --> Total execution time: 0.0134
INFO - 2020-03-07 17:59:00 --> Config Class Initialized
INFO - 2020-03-07 17:59:00 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:59:00 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:59:00 --> Utf8 Class Initialized
INFO - 2020-03-07 17:59:00 --> URI Class Initialized
INFO - 2020-03-07 17:59:00 --> Router Class Initialized
INFO - 2020-03-07 17:59:00 --> Output Class Initialized
INFO - 2020-03-07 17:59:00 --> Security Class Initialized
DEBUG - 2020-03-07 17:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:59:00 --> Input Class Initialized
INFO - 2020-03-07 17:59:00 --> Language Class Initialized
INFO - 2020-03-07 17:59:00 --> Loader Class Initialized
INFO - 2020-03-07 17:59:00 --> Helper loaded: url_helper
INFO - 2020-03-07 17:59:00 --> Helper loaded: string_helper
INFO - 2020-03-07 17:59:00 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:59:00 --> Controller Class Initialized
INFO - 2020-03-07 17:59:00 --> Model "M_tiket" initialized
INFO - 2020-03-07 17:59:00 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 17:59:00 --> Model "M_pesan" initialized
INFO - 2020-03-07 17:59:00 --> Helper loaded: form_helper
INFO - 2020-03-07 17:59:00 --> Form Validation Class Initialized
DEBUG - 2020-03-07 17:59:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-03-07 17:59:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-07 17:59:03 --> Config Class Initialized
INFO - 2020-03-07 17:59:03 --> Hooks Class Initialized
DEBUG - 2020-03-07 17:59:03 --> UTF-8 Support Enabled
INFO - 2020-03-07 17:59:03 --> Utf8 Class Initialized
INFO - 2020-03-07 17:59:03 --> URI Class Initialized
INFO - 2020-03-07 17:59:03 --> Router Class Initialized
INFO - 2020-03-07 17:59:03 --> Output Class Initialized
INFO - 2020-03-07 17:59:03 --> Security Class Initialized
DEBUG - 2020-03-07 17:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 17:59:03 --> Input Class Initialized
INFO - 2020-03-07 17:59:03 --> Language Class Initialized
INFO - 2020-03-07 17:59:03 --> Loader Class Initialized
INFO - 2020-03-07 17:59:03 --> Helper loaded: url_helper
INFO - 2020-03-07 17:59:03 --> Helper loaded: string_helper
INFO - 2020-03-07 17:59:03 --> Database Driver Class Initialized
DEBUG - 2020-03-07 17:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 17:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 17:59:03 --> Controller Class Initialized
INFO - 2020-03-07 17:59:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 17:59:03 --> Pagination Class Initialized
INFO - 2020-03-07 17:59:03 --> Model "M_show" initialized
INFO - 2020-03-07 17:59:03 --> Helper loaded: form_helper
INFO - 2020-03-07 17:59:03 --> Form Validation Class Initialized
INFO - 2020-03-07 17:59:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 17:59:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 17:59:03 --> Final output sent to browser
DEBUG - 2020-03-07 17:59:03 --> Total execution time: 0.0056
INFO - 2020-03-07 18:00:52 --> Config Class Initialized
INFO - 2020-03-07 18:00:52 --> Hooks Class Initialized
DEBUG - 2020-03-07 18:00:52 --> UTF-8 Support Enabled
INFO - 2020-03-07 18:00:52 --> Utf8 Class Initialized
INFO - 2020-03-07 18:00:52 --> URI Class Initialized
INFO - 2020-03-07 18:00:52 --> Router Class Initialized
INFO - 2020-03-07 18:00:52 --> Output Class Initialized
INFO - 2020-03-07 18:00:52 --> Security Class Initialized
DEBUG - 2020-03-07 18:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 18:00:52 --> Input Class Initialized
INFO - 2020-03-07 18:00:52 --> Language Class Initialized
INFO - 2020-03-07 18:00:52 --> Loader Class Initialized
INFO - 2020-03-07 18:00:52 --> Helper loaded: url_helper
INFO - 2020-03-07 18:00:52 --> Helper loaded: string_helper
INFO - 2020-03-07 18:00:52 --> Database Driver Class Initialized
DEBUG - 2020-03-07 18:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 18:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 18:00:52 --> Controller Class Initialized
INFO - 2020-03-07 18:00:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 18:00:52 --> Pagination Class Initialized
INFO - 2020-03-07 18:00:52 --> Model "M_show" initialized
INFO - 2020-03-07 18:00:52 --> Helper loaded: form_helper
INFO - 2020-03-07 18:00:52 --> Form Validation Class Initialized
INFO - 2020-03-07 18:00:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 18:00:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 18:00:52 --> Final output sent to browser
DEBUG - 2020-03-07 18:00:52 --> Total execution time: 0.0371
INFO - 2020-03-07 18:06:39 --> Config Class Initialized
INFO - 2020-03-07 18:06:39 --> Hooks Class Initialized
DEBUG - 2020-03-07 18:06:39 --> UTF-8 Support Enabled
INFO - 2020-03-07 18:06:39 --> Utf8 Class Initialized
INFO - 2020-03-07 18:06:39 --> URI Class Initialized
DEBUG - 2020-03-07 18:06:39 --> No URI present. Default controller set.
INFO - 2020-03-07 18:06:39 --> Router Class Initialized
INFO - 2020-03-07 18:06:39 --> Output Class Initialized
INFO - 2020-03-07 18:06:39 --> Security Class Initialized
DEBUG - 2020-03-07 18:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 18:06:39 --> Input Class Initialized
INFO - 2020-03-07 18:06:39 --> Language Class Initialized
INFO - 2020-03-07 18:06:39 --> Loader Class Initialized
INFO - 2020-03-07 18:06:39 --> Helper loaded: url_helper
INFO - 2020-03-07 18:06:39 --> Helper loaded: string_helper
INFO - 2020-03-07 18:06:39 --> Database Driver Class Initialized
DEBUG - 2020-03-07 18:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 18:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 18:06:39 --> Controller Class Initialized
INFO - 2020-03-07 18:06:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 18:06:39 --> Pagination Class Initialized
INFO - 2020-03-07 18:06:39 --> Model "M_show" initialized
INFO - 2020-03-07 18:06:39 --> Helper loaded: form_helper
INFO - 2020-03-07 18:06:39 --> Form Validation Class Initialized
INFO - 2020-03-07 18:06:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 18:06:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 18:06:39 --> Final output sent to browser
DEBUG - 2020-03-07 18:06:39 --> Total execution time: 0.1587
INFO - 2020-03-07 18:07:30 --> Config Class Initialized
INFO - 2020-03-07 18:07:30 --> Hooks Class Initialized
DEBUG - 2020-03-07 18:07:30 --> UTF-8 Support Enabled
INFO - 2020-03-07 18:07:30 --> Utf8 Class Initialized
INFO - 2020-03-07 18:07:30 --> URI Class Initialized
INFO - 2020-03-07 18:07:30 --> Router Class Initialized
INFO - 2020-03-07 18:07:30 --> Output Class Initialized
INFO - 2020-03-07 18:07:30 --> Security Class Initialized
DEBUG - 2020-03-07 18:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 18:07:30 --> Input Class Initialized
INFO - 2020-03-07 18:07:30 --> Language Class Initialized
INFO - 2020-03-07 18:07:30 --> Loader Class Initialized
INFO - 2020-03-07 18:07:30 --> Helper loaded: url_helper
INFO - 2020-03-07 18:07:30 --> Helper loaded: string_helper
INFO - 2020-03-07 18:07:30 --> Database Driver Class Initialized
DEBUG - 2020-03-07 18:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 18:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 18:07:30 --> Controller Class Initialized
INFO - 2020-03-07 18:07:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 18:07:30 --> Pagination Class Initialized
INFO - 2020-03-07 18:07:30 --> Model "M_show" initialized
INFO - 2020-03-07 18:07:30 --> Helper loaded: form_helper
INFO - 2020-03-07 18:07:30 --> Form Validation Class Initialized
INFO - 2020-03-07 18:07:30 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 18:07:30 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 18:07:30 --> Final output sent to browser
DEBUG - 2020-03-07 18:07:30 --> Total execution time: 0.0081
INFO - 2020-03-07 18:07:37 --> Config Class Initialized
INFO - 2020-03-07 18:07:37 --> Hooks Class Initialized
DEBUG - 2020-03-07 18:07:37 --> UTF-8 Support Enabled
INFO - 2020-03-07 18:07:37 --> Utf8 Class Initialized
INFO - 2020-03-07 18:07:37 --> URI Class Initialized
INFO - 2020-03-07 18:07:37 --> Router Class Initialized
INFO - 2020-03-07 18:07:37 --> Output Class Initialized
INFO - 2020-03-07 18:07:37 --> Security Class Initialized
DEBUG - 2020-03-07 18:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 18:07:37 --> Input Class Initialized
INFO - 2020-03-07 18:07:37 --> Language Class Initialized
INFO - 2020-03-07 18:07:37 --> Loader Class Initialized
INFO - 2020-03-07 18:07:37 --> Helper loaded: url_helper
INFO - 2020-03-07 18:07:37 --> Helper loaded: string_helper
INFO - 2020-03-07 18:07:37 --> Database Driver Class Initialized
DEBUG - 2020-03-07 18:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 18:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 18:07:37 --> Controller Class Initialized
INFO - 2020-03-07 18:07:37 --> Model "M_tiket" initialized
INFO - 2020-03-07 18:07:37 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 18:07:37 --> Model "M_pesan" initialized
INFO - 2020-03-07 18:07:37 --> Helper loaded: form_helper
INFO - 2020-03-07 18:07:37 --> Form Validation Class Initialized
INFO - 2020-03-07 18:07:37 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 18:07:37 --> Final output sent to browser
DEBUG - 2020-03-07 18:07:37 --> Total execution time: 0.0574
INFO - 2020-03-07 18:07:48 --> Config Class Initialized
INFO - 2020-03-07 18:07:48 --> Hooks Class Initialized
DEBUG - 2020-03-07 18:07:48 --> UTF-8 Support Enabled
INFO - 2020-03-07 18:07:48 --> Utf8 Class Initialized
INFO - 2020-03-07 18:07:48 --> URI Class Initialized
DEBUG - 2020-03-07 18:07:48 --> No URI present. Default controller set.
INFO - 2020-03-07 18:07:48 --> Router Class Initialized
INFO - 2020-03-07 18:07:48 --> Output Class Initialized
INFO - 2020-03-07 18:07:48 --> Security Class Initialized
DEBUG - 2020-03-07 18:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 18:07:48 --> Input Class Initialized
INFO - 2020-03-07 18:07:48 --> Language Class Initialized
INFO - 2020-03-07 18:07:48 --> Loader Class Initialized
INFO - 2020-03-07 18:07:48 --> Helper loaded: url_helper
INFO - 2020-03-07 18:07:48 --> Helper loaded: string_helper
INFO - 2020-03-07 18:07:48 --> Database Driver Class Initialized
DEBUG - 2020-03-07 18:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 18:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 18:07:48 --> Controller Class Initialized
INFO - 2020-03-07 18:07:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 18:07:48 --> Pagination Class Initialized
INFO - 2020-03-07 18:07:48 --> Model "M_show" initialized
INFO - 2020-03-07 18:07:48 --> Helper loaded: form_helper
INFO - 2020-03-07 18:07:48 --> Form Validation Class Initialized
INFO - 2020-03-07 18:07:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 18:07:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 18:07:48 --> Final output sent to browser
DEBUG - 2020-03-07 18:07:48 --> Total execution time: 0.0065
INFO - 2020-03-07 18:08:11 --> Config Class Initialized
INFO - 2020-03-07 18:08:11 --> Hooks Class Initialized
DEBUG - 2020-03-07 18:08:11 --> UTF-8 Support Enabled
INFO - 2020-03-07 18:08:11 --> Utf8 Class Initialized
INFO - 2020-03-07 18:08:11 --> URI Class Initialized
INFO - 2020-03-07 18:08:11 --> Router Class Initialized
INFO - 2020-03-07 18:08:11 --> Output Class Initialized
INFO - 2020-03-07 18:08:11 --> Security Class Initialized
DEBUG - 2020-03-07 18:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 18:08:11 --> Input Class Initialized
INFO - 2020-03-07 18:08:11 --> Language Class Initialized
INFO - 2020-03-07 18:08:11 --> Loader Class Initialized
INFO - 2020-03-07 18:08:11 --> Helper loaded: url_helper
INFO - 2020-03-07 18:08:11 --> Helper loaded: string_helper
INFO - 2020-03-07 18:08:11 --> Database Driver Class Initialized
DEBUG - 2020-03-07 18:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 18:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 18:08:11 --> Controller Class Initialized
INFO - 2020-03-07 18:08:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 18:08:11 --> Pagination Class Initialized
INFO - 2020-03-07 18:08:11 --> Model "M_show" initialized
INFO - 2020-03-07 18:08:11 --> Helper loaded: form_helper
INFO - 2020-03-07 18:08:11 --> Form Validation Class Initialized
INFO - 2020-03-07 18:08:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 18:08:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 18:08:11 --> Final output sent to browser
DEBUG - 2020-03-07 18:08:11 --> Total execution time: 0.0072
INFO - 2020-03-07 18:08:20 --> Config Class Initialized
INFO - 2020-03-07 18:08:20 --> Hooks Class Initialized
DEBUG - 2020-03-07 18:08:20 --> UTF-8 Support Enabled
INFO - 2020-03-07 18:08:20 --> Utf8 Class Initialized
INFO - 2020-03-07 18:08:20 --> URI Class Initialized
INFO - 2020-03-07 18:08:20 --> Router Class Initialized
INFO - 2020-03-07 18:08:20 --> Output Class Initialized
INFO - 2020-03-07 18:08:20 --> Security Class Initialized
DEBUG - 2020-03-07 18:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 18:08:20 --> Input Class Initialized
INFO - 2020-03-07 18:08:20 --> Language Class Initialized
INFO - 2020-03-07 18:08:20 --> Loader Class Initialized
INFO - 2020-03-07 18:08:20 --> Helper loaded: url_helper
INFO - 2020-03-07 18:08:20 --> Helper loaded: string_helper
INFO - 2020-03-07 18:08:20 --> Database Driver Class Initialized
DEBUG - 2020-03-07 18:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 18:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 18:08:20 --> Controller Class Initialized
INFO - 2020-03-07 18:08:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 18:08:20 --> Pagination Class Initialized
INFO - 2020-03-07 18:08:20 --> Model "M_show" initialized
INFO - 2020-03-07 18:08:20 --> Helper loaded: form_helper
INFO - 2020-03-07 18:08:20 --> Form Validation Class Initialized
INFO - 2020-03-07 18:08:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 18:08:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tentang.php
INFO - 2020-03-07 18:08:20 --> Final output sent to browser
DEBUG - 2020-03-07 18:08:20 --> Total execution time: 0.0056
INFO - 2020-03-07 18:08:33 --> Config Class Initialized
INFO - 2020-03-07 18:08:33 --> Hooks Class Initialized
DEBUG - 2020-03-07 18:08:33 --> UTF-8 Support Enabled
INFO - 2020-03-07 18:08:33 --> Utf8 Class Initialized
INFO - 2020-03-07 18:08:33 --> URI Class Initialized
INFO - 2020-03-07 18:08:33 --> Router Class Initialized
INFO - 2020-03-07 18:08:33 --> Output Class Initialized
INFO - 2020-03-07 18:08:33 --> Security Class Initialized
DEBUG - 2020-03-07 18:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 18:08:33 --> Input Class Initialized
INFO - 2020-03-07 18:08:33 --> Language Class Initialized
INFO - 2020-03-07 18:08:33 --> Loader Class Initialized
INFO - 2020-03-07 18:08:33 --> Helper loaded: url_helper
INFO - 2020-03-07 18:08:33 --> Helper loaded: string_helper
INFO - 2020-03-07 18:08:33 --> Database Driver Class Initialized
DEBUG - 2020-03-07 18:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 18:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 18:08:33 --> Controller Class Initialized
INFO - 2020-03-07 18:08:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 18:08:33 --> Pagination Class Initialized
INFO - 2020-03-07 18:08:33 --> Model "M_show" initialized
INFO - 2020-03-07 18:08:33 --> Helper loaded: form_helper
INFO - 2020-03-07 18:08:33 --> Form Validation Class Initialized
INFO - 2020-03-07 18:08:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 18:08:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-07 18:08:33 --> Final output sent to browser
DEBUG - 2020-03-07 18:08:33 --> Total execution time: 0.0077
INFO - 2020-03-07 18:13:10 --> Config Class Initialized
INFO - 2020-03-07 18:13:10 --> Hooks Class Initialized
DEBUG - 2020-03-07 18:13:10 --> UTF-8 Support Enabled
INFO - 2020-03-07 18:13:10 --> Utf8 Class Initialized
INFO - 2020-03-07 18:13:10 --> URI Class Initialized
DEBUG - 2020-03-07 18:13:10 --> No URI present. Default controller set.
INFO - 2020-03-07 18:13:10 --> Router Class Initialized
INFO - 2020-03-07 18:13:10 --> Output Class Initialized
INFO - 2020-03-07 18:13:10 --> Security Class Initialized
DEBUG - 2020-03-07 18:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 18:13:10 --> Input Class Initialized
INFO - 2020-03-07 18:13:10 --> Language Class Initialized
INFO - 2020-03-07 18:13:10 --> Loader Class Initialized
INFO - 2020-03-07 18:13:10 --> Helper loaded: url_helper
INFO - 2020-03-07 18:13:10 --> Helper loaded: string_helper
INFO - 2020-03-07 18:13:10 --> Database Driver Class Initialized
DEBUG - 2020-03-07 18:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 18:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 18:13:10 --> Controller Class Initialized
INFO - 2020-03-07 18:13:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 18:13:10 --> Pagination Class Initialized
INFO - 2020-03-07 18:13:10 --> Model "M_show" initialized
INFO - 2020-03-07 18:13:10 --> Helper loaded: form_helper
INFO - 2020-03-07 18:13:10 --> Form Validation Class Initialized
INFO - 2020-03-07 18:13:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 18:13:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 18:13:10 --> Final output sent to browser
DEBUG - 2020-03-07 18:13:10 --> Total execution time: 0.0300
INFO - 2020-03-07 18:13:20 --> Config Class Initialized
INFO - 2020-03-07 18:13:20 --> Hooks Class Initialized
DEBUG - 2020-03-07 18:13:20 --> UTF-8 Support Enabled
INFO - 2020-03-07 18:13:20 --> Utf8 Class Initialized
INFO - 2020-03-07 18:13:20 --> URI Class Initialized
INFO - 2020-03-07 18:13:20 --> Router Class Initialized
INFO - 2020-03-07 18:13:20 --> Output Class Initialized
INFO - 2020-03-07 18:13:20 --> Security Class Initialized
DEBUG - 2020-03-07 18:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 18:13:20 --> Input Class Initialized
INFO - 2020-03-07 18:13:20 --> Language Class Initialized
INFO - 2020-03-07 18:13:20 --> Loader Class Initialized
INFO - 2020-03-07 18:13:20 --> Helper loaded: url_helper
INFO - 2020-03-07 18:13:20 --> Helper loaded: string_helper
INFO - 2020-03-07 18:13:20 --> Database Driver Class Initialized
DEBUG - 2020-03-07 18:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 18:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 18:13:20 --> Controller Class Initialized
INFO - 2020-03-07 18:13:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 18:13:20 --> Pagination Class Initialized
INFO - 2020-03-07 18:13:20 --> Model "M_show" initialized
INFO - 2020-03-07 18:13:20 --> Helper loaded: form_helper
INFO - 2020-03-07 18:13:20 --> Form Validation Class Initialized
INFO - 2020-03-07 18:13:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 18:13:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 18:13:20 --> Final output sent to browser
DEBUG - 2020-03-07 18:13:20 --> Total execution time: 0.0084
INFO - 2020-03-07 18:13:20 --> Config Class Initialized
INFO - 2020-03-07 18:13:20 --> Hooks Class Initialized
DEBUG - 2020-03-07 18:13:20 --> UTF-8 Support Enabled
INFO - 2020-03-07 18:13:20 --> Utf8 Class Initialized
INFO - 2020-03-07 18:13:20 --> URI Class Initialized
INFO - 2020-03-07 18:13:20 --> Router Class Initialized
INFO - 2020-03-07 18:13:20 --> Output Class Initialized
INFO - 2020-03-07 18:13:20 --> Security Class Initialized
DEBUG - 2020-03-07 18:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 18:13:20 --> Input Class Initialized
INFO - 2020-03-07 18:13:20 --> Language Class Initialized
ERROR - 2020-03-07 18:13:20 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-07 18:13:25 --> Config Class Initialized
INFO - 2020-03-07 18:13:25 --> Hooks Class Initialized
DEBUG - 2020-03-07 18:13:25 --> UTF-8 Support Enabled
INFO - 2020-03-07 18:13:25 --> Utf8 Class Initialized
INFO - 2020-03-07 18:13:25 --> URI Class Initialized
INFO - 2020-03-07 18:13:25 --> Router Class Initialized
INFO - 2020-03-07 18:13:25 --> Output Class Initialized
INFO - 2020-03-07 18:13:25 --> Security Class Initialized
DEBUG - 2020-03-07 18:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 18:13:25 --> Input Class Initialized
INFO - 2020-03-07 18:13:25 --> Language Class Initialized
INFO - 2020-03-07 18:13:25 --> Loader Class Initialized
INFO - 2020-03-07 18:13:25 --> Helper loaded: url_helper
INFO - 2020-03-07 18:13:25 --> Helper loaded: string_helper
INFO - 2020-03-07 18:13:25 --> Database Driver Class Initialized
DEBUG - 2020-03-07 18:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 18:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 18:13:25 --> Controller Class Initialized
INFO - 2020-03-07 18:13:25 --> Model "M_tiket" initialized
INFO - 2020-03-07 18:13:25 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 18:13:25 --> Model "M_pesan" initialized
INFO - 2020-03-07 18:13:25 --> Helper loaded: form_helper
INFO - 2020-03-07 18:13:25 --> Form Validation Class Initialized
INFO - 2020-03-07 18:13:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 18:13:25 --> Final output sent to browser
DEBUG - 2020-03-07 18:13:25 --> Total execution time: 0.0112
INFO - 2020-03-07 18:13:41 --> Config Class Initialized
INFO - 2020-03-07 18:13:41 --> Hooks Class Initialized
DEBUG - 2020-03-07 18:13:41 --> UTF-8 Support Enabled
INFO - 2020-03-07 18:13:41 --> Utf8 Class Initialized
INFO - 2020-03-07 18:13:41 --> URI Class Initialized
INFO - 2020-03-07 18:13:41 --> Router Class Initialized
INFO - 2020-03-07 18:13:41 --> Output Class Initialized
INFO - 2020-03-07 18:13:41 --> Security Class Initialized
DEBUG - 2020-03-07 18:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 18:13:41 --> Input Class Initialized
INFO - 2020-03-07 18:13:41 --> Language Class Initialized
INFO - 2020-03-07 18:13:41 --> Loader Class Initialized
INFO - 2020-03-07 18:13:41 --> Helper loaded: url_helper
INFO - 2020-03-07 18:13:41 --> Helper loaded: string_helper
INFO - 2020-03-07 18:13:41 --> Database Driver Class Initialized
DEBUG - 2020-03-07 18:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 18:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 18:13:41 --> Controller Class Initialized
INFO - 2020-03-07 18:13:41 --> Model "M_tiket" initialized
INFO - 2020-03-07 18:13:41 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 18:13:41 --> Model "M_pesan" initialized
INFO - 2020-03-07 18:13:41 --> Helper loaded: form_helper
INFO - 2020-03-07 18:13:41 --> Form Validation Class Initialized
INFO - 2020-03-07 18:13:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 18:13:41 --> Final output sent to browser
DEBUG - 2020-03-07 18:13:41 --> Total execution time: 0.0075
INFO - 2020-03-07 18:13:54 --> Config Class Initialized
INFO - 2020-03-07 18:13:54 --> Hooks Class Initialized
DEBUG - 2020-03-07 18:13:54 --> UTF-8 Support Enabled
INFO - 2020-03-07 18:13:54 --> Utf8 Class Initialized
INFO - 2020-03-07 18:13:54 --> URI Class Initialized
DEBUG - 2020-03-07 18:13:54 --> No URI present. Default controller set.
INFO - 2020-03-07 18:13:54 --> Router Class Initialized
INFO - 2020-03-07 18:13:54 --> Output Class Initialized
INFO - 2020-03-07 18:13:54 --> Security Class Initialized
DEBUG - 2020-03-07 18:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 18:13:54 --> Input Class Initialized
INFO - 2020-03-07 18:13:54 --> Language Class Initialized
INFO - 2020-03-07 18:13:54 --> Loader Class Initialized
INFO - 2020-03-07 18:13:54 --> Helper loaded: url_helper
INFO - 2020-03-07 18:13:54 --> Helper loaded: string_helper
INFO - 2020-03-07 18:13:54 --> Database Driver Class Initialized
DEBUG - 2020-03-07 18:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 18:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 18:13:54 --> Controller Class Initialized
INFO - 2020-03-07 18:13:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 18:13:54 --> Pagination Class Initialized
INFO - 2020-03-07 18:13:54 --> Model "M_show" initialized
INFO - 2020-03-07 18:13:54 --> Helper loaded: form_helper
INFO - 2020-03-07 18:13:54 --> Form Validation Class Initialized
INFO - 2020-03-07 18:13:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 18:13:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 18:13:54 --> Final output sent to browser
DEBUG - 2020-03-07 18:13:54 --> Total execution time: 0.0060
INFO - 2020-03-07 18:27:41 --> Config Class Initialized
INFO - 2020-03-07 18:27:41 --> Hooks Class Initialized
DEBUG - 2020-03-07 18:27:41 --> UTF-8 Support Enabled
INFO - 2020-03-07 18:27:41 --> Utf8 Class Initialized
INFO - 2020-03-07 18:27:41 --> URI Class Initialized
DEBUG - 2020-03-07 18:27:41 --> No URI present. Default controller set.
INFO - 2020-03-07 18:27:41 --> Router Class Initialized
INFO - 2020-03-07 18:27:41 --> Output Class Initialized
INFO - 2020-03-07 18:27:41 --> Security Class Initialized
DEBUG - 2020-03-07 18:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 18:27:41 --> Input Class Initialized
INFO - 2020-03-07 18:27:41 --> Language Class Initialized
INFO - 2020-03-07 18:27:41 --> Loader Class Initialized
INFO - 2020-03-07 18:27:41 --> Helper loaded: url_helper
INFO - 2020-03-07 18:27:41 --> Helper loaded: string_helper
INFO - 2020-03-07 18:27:41 --> Database Driver Class Initialized
DEBUG - 2020-03-07 18:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 18:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 18:27:41 --> Controller Class Initialized
INFO - 2020-03-07 18:27:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 18:27:41 --> Pagination Class Initialized
INFO - 2020-03-07 18:27:41 --> Model "M_show" initialized
INFO - 2020-03-07 18:27:41 --> Helper loaded: form_helper
INFO - 2020-03-07 18:27:41 --> Form Validation Class Initialized
INFO - 2020-03-07 18:27:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 18:27:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 18:27:41 --> Final output sent to browser
DEBUG - 2020-03-07 18:27:41 --> Total execution time: 0.0394
INFO - 2020-03-07 18:27:57 --> Config Class Initialized
INFO - 2020-03-07 18:27:57 --> Hooks Class Initialized
DEBUG - 2020-03-07 18:27:57 --> UTF-8 Support Enabled
INFO - 2020-03-07 18:27:57 --> Utf8 Class Initialized
INFO - 2020-03-07 18:27:57 --> URI Class Initialized
INFO - 2020-03-07 18:27:57 --> Router Class Initialized
INFO - 2020-03-07 18:27:57 --> Output Class Initialized
INFO - 2020-03-07 18:27:57 --> Security Class Initialized
DEBUG - 2020-03-07 18:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 18:27:57 --> Input Class Initialized
INFO - 2020-03-07 18:27:57 --> Language Class Initialized
INFO - 2020-03-07 18:27:57 --> Loader Class Initialized
INFO - 2020-03-07 18:27:57 --> Helper loaded: url_helper
INFO - 2020-03-07 18:27:57 --> Helper loaded: string_helper
INFO - 2020-03-07 18:27:57 --> Database Driver Class Initialized
DEBUG - 2020-03-07 18:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 18:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 18:27:57 --> Controller Class Initialized
INFO - 2020-03-07 18:27:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 18:27:57 --> Pagination Class Initialized
INFO - 2020-03-07 18:27:57 --> Model "M_show" initialized
INFO - 2020-03-07 18:27:57 --> Helper loaded: form_helper
INFO - 2020-03-07 18:27:57 --> Form Validation Class Initialized
INFO - 2020-03-07 18:27:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 18:27:57 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 18:27:57 --> Final output sent to browser
DEBUG - 2020-03-07 18:27:57 --> Total execution time: 0.0081
INFO - 2020-03-07 18:27:57 --> Config Class Initialized
INFO - 2020-03-07 18:27:57 --> Hooks Class Initialized
DEBUG - 2020-03-07 18:27:57 --> UTF-8 Support Enabled
INFO - 2020-03-07 18:27:57 --> Utf8 Class Initialized
INFO - 2020-03-07 18:27:57 --> URI Class Initialized
INFO - 2020-03-07 18:27:57 --> Router Class Initialized
INFO - 2020-03-07 18:27:57 --> Output Class Initialized
INFO - 2020-03-07 18:27:57 --> Security Class Initialized
DEBUG - 2020-03-07 18:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 18:27:57 --> Input Class Initialized
INFO - 2020-03-07 18:27:57 --> Language Class Initialized
ERROR - 2020-03-07 18:27:57 --> 404 Page Not Found: Show/engine0
INFO - 2020-03-07 18:28:03 --> Config Class Initialized
INFO - 2020-03-07 18:28:03 --> Hooks Class Initialized
DEBUG - 2020-03-07 18:28:03 --> UTF-8 Support Enabled
INFO - 2020-03-07 18:28:03 --> Utf8 Class Initialized
INFO - 2020-03-07 18:28:03 --> URI Class Initialized
INFO - 2020-03-07 18:28:03 --> Router Class Initialized
INFO - 2020-03-07 18:28:03 --> Output Class Initialized
INFO - 2020-03-07 18:28:03 --> Security Class Initialized
DEBUG - 2020-03-07 18:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 18:28:03 --> Input Class Initialized
INFO - 2020-03-07 18:28:03 --> Language Class Initialized
INFO - 2020-03-07 18:28:03 --> Loader Class Initialized
INFO - 2020-03-07 18:28:03 --> Helper loaded: url_helper
INFO - 2020-03-07 18:28:03 --> Helper loaded: string_helper
INFO - 2020-03-07 18:28:03 --> Database Driver Class Initialized
DEBUG - 2020-03-07 18:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 18:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 18:28:03 --> Controller Class Initialized
INFO - 2020-03-07 18:28:03 --> Model "M_tiket" initialized
INFO - 2020-03-07 18:28:03 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 18:28:03 --> Model "M_pesan" initialized
INFO - 2020-03-07 18:28:03 --> Helper loaded: form_helper
INFO - 2020-03-07 18:28:03 --> Form Validation Class Initialized
INFO - 2020-03-07 18:28:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 18:28:03 --> Final output sent to browser
DEBUG - 2020-03-07 18:28:03 --> Total execution time: 0.0108
INFO - 2020-03-07 18:28:32 --> Config Class Initialized
INFO - 2020-03-07 18:28:32 --> Hooks Class Initialized
DEBUG - 2020-03-07 18:28:32 --> UTF-8 Support Enabled
INFO - 2020-03-07 18:28:32 --> Utf8 Class Initialized
INFO - 2020-03-07 18:28:32 --> URI Class Initialized
INFO - 2020-03-07 18:28:32 --> Router Class Initialized
INFO - 2020-03-07 18:28:32 --> Output Class Initialized
INFO - 2020-03-07 18:28:32 --> Security Class Initialized
DEBUG - 2020-03-07 18:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 18:28:32 --> Input Class Initialized
INFO - 2020-03-07 18:28:32 --> Language Class Initialized
INFO - 2020-03-07 18:28:32 --> Loader Class Initialized
INFO - 2020-03-07 18:28:32 --> Helper loaded: url_helper
INFO - 2020-03-07 18:28:32 --> Helper loaded: string_helper
INFO - 2020-03-07 18:28:32 --> Database Driver Class Initialized
DEBUG - 2020-03-07 18:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 18:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 18:28:32 --> Controller Class Initialized
INFO - 2020-03-07 18:28:32 --> Model "M_tiket" initialized
INFO - 2020-03-07 18:28:32 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 18:28:32 --> Model "M_pesan" initialized
INFO - 2020-03-07 18:28:32 --> Helper loaded: form_helper
INFO - 2020-03-07 18:28:32 --> Form Validation Class Initialized
INFO - 2020-03-07 18:28:32 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 18:28:32 --> Final output sent to browser
DEBUG - 2020-03-07 18:28:32 --> Total execution time: 0.0067
INFO - 2020-03-07 18:32:03 --> Config Class Initialized
INFO - 2020-03-07 18:32:03 --> Hooks Class Initialized
DEBUG - 2020-03-07 18:32:03 --> UTF-8 Support Enabled
INFO - 2020-03-07 18:32:03 --> Utf8 Class Initialized
INFO - 2020-03-07 18:32:03 --> URI Class Initialized
DEBUG - 2020-03-07 18:32:03 --> No URI present. Default controller set.
INFO - 2020-03-07 18:32:03 --> Router Class Initialized
INFO - 2020-03-07 18:32:03 --> Output Class Initialized
INFO - 2020-03-07 18:32:03 --> Security Class Initialized
DEBUG - 2020-03-07 18:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 18:32:03 --> Input Class Initialized
INFO - 2020-03-07 18:32:03 --> Language Class Initialized
INFO - 2020-03-07 18:32:03 --> Loader Class Initialized
INFO - 2020-03-07 18:32:03 --> Helper loaded: url_helper
INFO - 2020-03-07 18:32:03 --> Helper loaded: string_helper
INFO - 2020-03-07 18:32:03 --> Database Driver Class Initialized
DEBUG - 2020-03-07 18:32:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 18:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 18:32:03 --> Controller Class Initialized
INFO - 2020-03-07 18:32:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 18:32:03 --> Pagination Class Initialized
INFO - 2020-03-07 18:32:03 --> Model "M_show" initialized
INFO - 2020-03-07 18:32:03 --> Helper loaded: form_helper
INFO - 2020-03-07 18:32:03 --> Form Validation Class Initialized
INFO - 2020-03-07 18:32:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 18:32:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 18:32:03 --> Final output sent to browser
DEBUG - 2020-03-07 18:32:03 --> Total execution time: 0.0318
INFO - 2020-03-07 19:00:28 --> Config Class Initialized
INFO - 2020-03-07 19:00:28 --> Hooks Class Initialized
DEBUG - 2020-03-07 19:00:28 --> UTF-8 Support Enabled
INFO - 2020-03-07 19:00:28 --> Utf8 Class Initialized
INFO - 2020-03-07 19:00:28 --> URI Class Initialized
INFO - 2020-03-07 19:00:28 --> Router Class Initialized
INFO - 2020-03-07 19:00:28 --> Output Class Initialized
INFO - 2020-03-07 19:00:28 --> Security Class Initialized
DEBUG - 2020-03-07 19:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 19:00:28 --> Input Class Initialized
INFO - 2020-03-07 19:00:28 --> Language Class Initialized
INFO - 2020-03-07 19:00:28 --> Loader Class Initialized
INFO - 2020-03-07 19:00:28 --> Helper loaded: url_helper
INFO - 2020-03-07 19:00:28 --> Helper loaded: string_helper
INFO - 2020-03-07 19:00:28 --> Database Driver Class Initialized
DEBUG - 2020-03-07 19:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 19:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 19:00:28 --> Controller Class Initialized
INFO - 2020-03-07 19:00:28 --> Model "M_tiket" initialized
INFO - 2020-03-07 19:00:28 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 19:00:28 --> Model "M_pesan" initialized
INFO - 2020-03-07 19:00:28 --> Helper loaded: form_helper
INFO - 2020-03-07 19:00:28 --> Form Validation Class Initialized
INFO - 2020-03-07 19:00:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 19:00:28 --> Final output sent to browser
DEBUG - 2020-03-07 19:00:28 --> Total execution time: 0.0504
INFO - 2020-03-07 19:10:07 --> Config Class Initialized
INFO - 2020-03-07 19:10:07 --> Hooks Class Initialized
DEBUG - 2020-03-07 19:10:07 --> UTF-8 Support Enabled
INFO - 2020-03-07 19:10:07 --> Utf8 Class Initialized
INFO - 2020-03-07 19:10:07 --> URI Class Initialized
DEBUG - 2020-03-07 19:10:07 --> No URI present. Default controller set.
INFO - 2020-03-07 19:10:07 --> Router Class Initialized
INFO - 2020-03-07 19:10:07 --> Output Class Initialized
INFO - 2020-03-07 19:10:07 --> Security Class Initialized
DEBUG - 2020-03-07 19:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 19:10:07 --> Input Class Initialized
INFO - 2020-03-07 19:10:07 --> Language Class Initialized
INFO - 2020-03-07 19:10:07 --> Loader Class Initialized
INFO - 2020-03-07 19:10:07 --> Helper loaded: url_helper
INFO - 2020-03-07 19:10:07 --> Helper loaded: string_helper
INFO - 2020-03-07 19:10:07 --> Database Driver Class Initialized
DEBUG - 2020-03-07 19:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 19:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 19:10:07 --> Controller Class Initialized
INFO - 2020-03-07 19:10:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 19:10:07 --> Pagination Class Initialized
INFO - 2020-03-07 19:10:07 --> Model "M_show" initialized
INFO - 2020-03-07 19:10:07 --> Helper loaded: form_helper
INFO - 2020-03-07 19:10:07 --> Form Validation Class Initialized
INFO - 2020-03-07 19:10:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 19:10:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 19:10:07 --> Final output sent to browser
DEBUG - 2020-03-07 19:10:07 --> Total execution time: 0.0526
INFO - 2020-03-07 19:11:16 --> Config Class Initialized
INFO - 2020-03-07 19:11:16 --> Hooks Class Initialized
DEBUG - 2020-03-07 19:11:16 --> UTF-8 Support Enabled
INFO - 2020-03-07 19:11:16 --> Utf8 Class Initialized
INFO - 2020-03-07 19:11:16 --> URI Class Initialized
INFO - 2020-03-07 19:11:16 --> Router Class Initialized
INFO - 2020-03-07 19:11:16 --> Output Class Initialized
INFO - 2020-03-07 19:11:16 --> Security Class Initialized
DEBUG - 2020-03-07 19:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 19:11:16 --> Input Class Initialized
INFO - 2020-03-07 19:11:16 --> Language Class Initialized
INFO - 2020-03-07 19:11:16 --> Loader Class Initialized
INFO - 2020-03-07 19:11:16 --> Helper loaded: url_helper
INFO - 2020-03-07 19:11:16 --> Helper loaded: string_helper
INFO - 2020-03-07 19:11:16 --> Database Driver Class Initialized
DEBUG - 2020-03-07 19:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 19:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 19:11:16 --> Controller Class Initialized
INFO - 2020-03-07 19:11:16 --> Model "M_tiket" initialized
INFO - 2020-03-07 19:11:16 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 19:11:16 --> Model "M_pesan" initialized
INFO - 2020-03-07 19:11:16 --> Helper loaded: form_helper
INFO - 2020-03-07 19:11:16 --> Form Validation Class Initialized
INFO - 2020-03-07 19:11:16 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 19:11:16 --> Final output sent to browser
DEBUG - 2020-03-07 19:11:16 --> Total execution time: 0.0126
INFO - 2020-03-07 19:19:07 --> Config Class Initialized
INFO - 2020-03-07 19:19:07 --> Hooks Class Initialized
DEBUG - 2020-03-07 19:19:07 --> UTF-8 Support Enabled
INFO - 2020-03-07 19:19:07 --> Utf8 Class Initialized
INFO - 2020-03-07 19:19:07 --> URI Class Initialized
DEBUG - 2020-03-07 19:19:07 --> No URI present. Default controller set.
INFO - 2020-03-07 19:19:07 --> Router Class Initialized
INFO - 2020-03-07 19:19:07 --> Output Class Initialized
INFO - 2020-03-07 19:19:07 --> Security Class Initialized
DEBUG - 2020-03-07 19:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 19:19:07 --> Input Class Initialized
INFO - 2020-03-07 19:19:07 --> Language Class Initialized
INFO - 2020-03-07 19:19:07 --> Loader Class Initialized
INFO - 2020-03-07 19:19:07 --> Helper loaded: url_helper
INFO - 2020-03-07 19:19:07 --> Helper loaded: string_helper
INFO - 2020-03-07 19:19:07 --> Database Driver Class Initialized
DEBUG - 2020-03-07 19:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 19:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 19:19:07 --> Controller Class Initialized
INFO - 2020-03-07 19:19:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 19:19:07 --> Pagination Class Initialized
INFO - 2020-03-07 19:19:07 --> Model "M_show" initialized
INFO - 2020-03-07 19:19:07 --> Helper loaded: form_helper
INFO - 2020-03-07 19:19:07 --> Form Validation Class Initialized
INFO - 2020-03-07 19:19:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 19:19:07 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 19:19:07 --> Final output sent to browser
DEBUG - 2020-03-07 19:19:07 --> Total execution time: 0.0366
INFO - 2020-03-07 19:19:19 --> Config Class Initialized
INFO - 2020-03-07 19:19:19 --> Hooks Class Initialized
DEBUG - 2020-03-07 19:19:19 --> UTF-8 Support Enabled
INFO - 2020-03-07 19:19:19 --> Utf8 Class Initialized
INFO - 2020-03-07 19:19:19 --> URI Class Initialized
INFO - 2020-03-07 19:19:19 --> Router Class Initialized
INFO - 2020-03-07 19:19:19 --> Output Class Initialized
INFO - 2020-03-07 19:19:19 --> Security Class Initialized
DEBUG - 2020-03-07 19:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 19:19:19 --> Input Class Initialized
INFO - 2020-03-07 19:19:19 --> Language Class Initialized
INFO - 2020-03-07 19:19:19 --> Loader Class Initialized
INFO - 2020-03-07 19:19:19 --> Helper loaded: url_helper
INFO - 2020-03-07 19:19:19 --> Helper loaded: string_helper
INFO - 2020-03-07 19:19:19 --> Database Driver Class Initialized
DEBUG - 2020-03-07 19:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 19:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 19:19:19 --> Controller Class Initialized
INFO - 2020-03-07 19:19:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 19:19:19 --> Pagination Class Initialized
INFO - 2020-03-07 19:19:19 --> Model "M_show" initialized
INFO - 2020-03-07 19:19:19 --> Helper loaded: form_helper
INFO - 2020-03-07 19:19:19 --> Form Validation Class Initialized
INFO - 2020-03-07 19:19:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 19:19:19 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-07 19:19:19 --> Final output sent to browser
DEBUG - 2020-03-07 19:19:19 --> Total execution time: 0.0063
INFO - 2020-03-07 19:19:35 --> Config Class Initialized
INFO - 2020-03-07 19:19:35 --> Hooks Class Initialized
DEBUG - 2020-03-07 19:19:35 --> UTF-8 Support Enabled
INFO - 2020-03-07 19:19:35 --> Utf8 Class Initialized
INFO - 2020-03-07 19:19:35 --> URI Class Initialized
INFO - 2020-03-07 19:19:35 --> Router Class Initialized
INFO - 2020-03-07 19:19:35 --> Output Class Initialized
INFO - 2020-03-07 19:19:35 --> Security Class Initialized
DEBUG - 2020-03-07 19:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 19:19:35 --> Input Class Initialized
INFO - 2020-03-07 19:19:35 --> Language Class Initialized
INFO - 2020-03-07 19:19:35 --> Loader Class Initialized
INFO - 2020-03-07 19:19:35 --> Helper loaded: url_helper
INFO - 2020-03-07 19:19:35 --> Helper loaded: string_helper
INFO - 2020-03-07 19:19:35 --> Database Driver Class Initialized
DEBUG - 2020-03-07 19:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 19:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 19:19:35 --> Controller Class Initialized
INFO - 2020-03-07 19:19:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 19:19:35 --> Pagination Class Initialized
INFO - 2020-03-07 19:19:35 --> Model "M_show" initialized
INFO - 2020-03-07 19:19:35 --> Helper loaded: form_helper
INFO - 2020-03-07 19:19:35 --> Form Validation Class Initialized
INFO - 2020-03-07 19:19:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 19:19:35 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 19:19:35 --> Final output sent to browser
DEBUG - 2020-03-07 19:19:35 --> Total execution time: 0.0076
INFO - 2020-03-07 19:19:41 --> Config Class Initialized
INFO - 2020-03-07 19:19:41 --> Hooks Class Initialized
DEBUG - 2020-03-07 19:19:41 --> UTF-8 Support Enabled
INFO - 2020-03-07 19:19:41 --> Utf8 Class Initialized
INFO - 2020-03-07 19:19:41 --> URI Class Initialized
INFO - 2020-03-07 19:19:41 --> Router Class Initialized
INFO - 2020-03-07 19:19:41 --> Output Class Initialized
INFO - 2020-03-07 19:19:41 --> Security Class Initialized
DEBUG - 2020-03-07 19:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 19:19:41 --> Input Class Initialized
INFO - 2020-03-07 19:19:41 --> Language Class Initialized
INFO - 2020-03-07 19:19:41 --> Loader Class Initialized
INFO - 2020-03-07 19:19:41 --> Helper loaded: url_helper
INFO - 2020-03-07 19:19:41 --> Helper loaded: string_helper
INFO - 2020-03-07 19:19:41 --> Database Driver Class Initialized
DEBUG - 2020-03-07 19:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 19:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 19:19:41 --> Controller Class Initialized
INFO - 2020-03-07 19:19:41 --> Model "M_tiket" initialized
INFO - 2020-03-07 19:19:41 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 19:19:41 --> Model "M_pesan" initialized
INFO - 2020-03-07 19:19:41 --> Helper loaded: form_helper
INFO - 2020-03-07 19:19:41 --> Form Validation Class Initialized
INFO - 2020-03-07 19:19:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 19:19:41 --> Final output sent to browser
DEBUG - 2020-03-07 19:19:41 --> Total execution time: 0.0146
INFO - 2020-03-07 19:20:00 --> Config Class Initialized
INFO - 2020-03-07 19:20:00 --> Hooks Class Initialized
DEBUG - 2020-03-07 19:20:00 --> UTF-8 Support Enabled
INFO - 2020-03-07 19:20:00 --> Utf8 Class Initialized
INFO - 2020-03-07 19:20:00 --> URI Class Initialized
INFO - 2020-03-07 19:20:00 --> Router Class Initialized
INFO - 2020-03-07 19:20:00 --> Output Class Initialized
INFO - 2020-03-07 19:20:00 --> Security Class Initialized
DEBUG - 2020-03-07 19:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 19:20:00 --> Input Class Initialized
INFO - 2020-03-07 19:20:00 --> Language Class Initialized
INFO - 2020-03-07 19:20:00 --> Loader Class Initialized
INFO - 2020-03-07 19:20:00 --> Helper loaded: url_helper
INFO - 2020-03-07 19:20:00 --> Helper loaded: string_helper
INFO - 2020-03-07 19:20:00 --> Database Driver Class Initialized
DEBUG - 2020-03-07 19:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 19:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 19:20:00 --> Controller Class Initialized
INFO - 2020-03-07 19:20:00 --> Model "M_tiket" initialized
INFO - 2020-03-07 19:20:00 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 19:20:00 --> Model "M_pesan" initialized
INFO - 2020-03-07 19:20:00 --> Helper loaded: form_helper
INFO - 2020-03-07 19:20:00 --> Form Validation Class Initialized
INFO - 2020-03-07 19:20:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 19:20:00 --> Final output sent to browser
DEBUG - 2020-03-07 19:20:00 --> Total execution time: 0.0080
INFO - 2020-03-07 19:26:04 --> Config Class Initialized
INFO - 2020-03-07 19:26:04 --> Hooks Class Initialized
DEBUG - 2020-03-07 19:26:04 --> UTF-8 Support Enabled
INFO - 2020-03-07 19:26:04 --> Utf8 Class Initialized
INFO - 2020-03-07 19:26:04 --> URI Class Initialized
INFO - 2020-03-07 19:26:04 --> Router Class Initialized
INFO - 2020-03-07 19:26:04 --> Output Class Initialized
INFO - 2020-03-07 19:26:04 --> Security Class Initialized
DEBUG - 2020-03-07 19:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 19:26:04 --> Input Class Initialized
INFO - 2020-03-07 19:26:04 --> Language Class Initialized
INFO - 2020-03-07 19:26:04 --> Loader Class Initialized
INFO - 2020-03-07 19:26:04 --> Helper loaded: url_helper
INFO - 2020-03-07 19:26:04 --> Helper loaded: string_helper
INFO - 2020-03-07 19:26:04 --> Database Driver Class Initialized
DEBUG - 2020-03-07 19:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 19:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 19:26:04 --> Controller Class Initialized
INFO - 2020-03-07 19:26:04 --> Model "M_tiket" initialized
INFO - 2020-03-07 19:26:04 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 19:26:04 --> Model "M_pesan" initialized
INFO - 2020-03-07 19:26:04 --> Helper loaded: form_helper
INFO - 2020-03-07 19:26:04 --> Form Validation Class Initialized
INFO - 2020-03-07 19:26:04 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 19:26:04 --> Final output sent to browser
DEBUG - 2020-03-07 19:26:04 --> Total execution time: 0.0355
INFO - 2020-03-07 19:34:38 --> Config Class Initialized
INFO - 2020-03-07 19:34:38 --> Hooks Class Initialized
DEBUG - 2020-03-07 19:34:38 --> UTF-8 Support Enabled
INFO - 2020-03-07 19:34:38 --> Utf8 Class Initialized
INFO - 2020-03-07 19:34:38 --> URI Class Initialized
DEBUG - 2020-03-07 19:34:38 --> No URI present. Default controller set.
INFO - 2020-03-07 19:34:38 --> Router Class Initialized
INFO - 2020-03-07 19:34:38 --> Output Class Initialized
INFO - 2020-03-07 19:34:38 --> Security Class Initialized
DEBUG - 2020-03-07 19:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 19:34:38 --> Input Class Initialized
INFO - 2020-03-07 19:34:38 --> Language Class Initialized
INFO - 2020-03-07 19:34:38 --> Loader Class Initialized
INFO - 2020-03-07 19:34:38 --> Helper loaded: url_helper
INFO - 2020-03-07 19:34:38 --> Helper loaded: string_helper
INFO - 2020-03-07 19:34:38 --> Database Driver Class Initialized
DEBUG - 2020-03-07 19:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 19:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 19:34:38 --> Controller Class Initialized
INFO - 2020-03-07 19:34:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 19:34:38 --> Pagination Class Initialized
INFO - 2020-03-07 19:34:38 --> Model "M_show" initialized
INFO - 2020-03-07 19:34:38 --> Helper loaded: form_helper
INFO - 2020-03-07 19:34:38 --> Form Validation Class Initialized
INFO - 2020-03-07 19:34:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 19:34:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 19:34:38 --> Final output sent to browser
DEBUG - 2020-03-07 19:34:38 --> Total execution time: 0.0364
INFO - 2020-03-07 19:34:43 --> Config Class Initialized
INFO - 2020-03-07 19:34:43 --> Hooks Class Initialized
DEBUG - 2020-03-07 19:34:43 --> UTF-8 Support Enabled
INFO - 2020-03-07 19:34:43 --> Utf8 Class Initialized
INFO - 2020-03-07 19:34:43 --> URI Class Initialized
INFO - 2020-03-07 19:34:43 --> Router Class Initialized
INFO - 2020-03-07 19:34:43 --> Output Class Initialized
INFO - 2020-03-07 19:34:43 --> Security Class Initialized
DEBUG - 2020-03-07 19:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 19:34:43 --> Input Class Initialized
INFO - 2020-03-07 19:34:43 --> Language Class Initialized
INFO - 2020-03-07 19:34:43 --> Loader Class Initialized
INFO - 2020-03-07 19:34:43 --> Helper loaded: url_helper
INFO - 2020-03-07 19:34:43 --> Helper loaded: string_helper
INFO - 2020-03-07 19:34:43 --> Database Driver Class Initialized
DEBUG - 2020-03-07 19:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 19:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 19:34:43 --> Controller Class Initialized
INFO - 2020-03-07 19:34:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 19:34:43 --> Pagination Class Initialized
INFO - 2020-03-07 19:34:43 --> Model "M_show" initialized
INFO - 2020-03-07 19:34:43 --> Helper loaded: form_helper
INFO - 2020-03-07 19:34:43 --> Form Validation Class Initialized
INFO - 2020-03-07 19:34:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 19:34:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 19:34:43 --> Final output sent to browser
DEBUG - 2020-03-07 19:34:43 --> Total execution time: 0.0076
INFO - 2020-03-07 19:34:47 --> Config Class Initialized
INFO - 2020-03-07 19:34:47 --> Hooks Class Initialized
DEBUG - 2020-03-07 19:34:47 --> UTF-8 Support Enabled
INFO - 2020-03-07 19:34:47 --> Utf8 Class Initialized
INFO - 2020-03-07 19:34:47 --> URI Class Initialized
INFO - 2020-03-07 19:34:47 --> Router Class Initialized
INFO - 2020-03-07 19:34:47 --> Output Class Initialized
INFO - 2020-03-07 19:34:47 --> Security Class Initialized
DEBUG - 2020-03-07 19:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 19:34:47 --> Input Class Initialized
INFO - 2020-03-07 19:34:47 --> Language Class Initialized
INFO - 2020-03-07 19:34:47 --> Loader Class Initialized
INFO - 2020-03-07 19:34:47 --> Helper loaded: url_helper
INFO - 2020-03-07 19:34:47 --> Helper loaded: string_helper
INFO - 2020-03-07 19:34:47 --> Database Driver Class Initialized
DEBUG - 2020-03-07 19:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 19:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 19:34:47 --> Controller Class Initialized
INFO - 2020-03-07 19:34:47 --> Model "M_tiket" initialized
INFO - 2020-03-07 19:34:47 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 19:34:47 --> Model "M_pesan" initialized
INFO - 2020-03-07 19:34:47 --> Helper loaded: form_helper
INFO - 2020-03-07 19:34:47 --> Form Validation Class Initialized
INFO - 2020-03-07 19:34:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 19:34:47 --> Final output sent to browser
DEBUG - 2020-03-07 19:34:47 --> Total execution time: 0.0099
INFO - 2020-03-07 19:34:51 --> Config Class Initialized
INFO - 2020-03-07 19:34:51 --> Hooks Class Initialized
DEBUG - 2020-03-07 19:34:51 --> UTF-8 Support Enabled
INFO - 2020-03-07 19:34:51 --> Utf8 Class Initialized
INFO - 2020-03-07 19:34:51 --> URI Class Initialized
INFO - 2020-03-07 19:34:51 --> Router Class Initialized
INFO - 2020-03-07 19:34:51 --> Output Class Initialized
INFO - 2020-03-07 19:34:51 --> Security Class Initialized
DEBUG - 2020-03-07 19:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 19:34:51 --> Input Class Initialized
INFO - 2020-03-07 19:34:51 --> Language Class Initialized
INFO - 2020-03-07 19:34:51 --> Loader Class Initialized
INFO - 2020-03-07 19:34:51 --> Helper loaded: url_helper
INFO - 2020-03-07 19:34:51 --> Helper loaded: string_helper
INFO - 2020-03-07 19:34:51 --> Database Driver Class Initialized
DEBUG - 2020-03-07 19:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 19:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 19:34:51 --> Controller Class Initialized
INFO - 2020-03-07 19:34:51 --> Model "M_tiket" initialized
INFO - 2020-03-07 19:34:51 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 19:34:51 --> Model "M_pesan" initialized
INFO - 2020-03-07 19:34:51 --> Helper loaded: form_helper
INFO - 2020-03-07 19:34:51 --> Form Validation Class Initialized
INFO - 2020-03-07 19:34:51 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 19:34:51 --> Final output sent to browser
DEBUG - 2020-03-07 19:34:51 --> Total execution time: 0.0084
INFO - 2020-03-07 19:36:27 --> Config Class Initialized
INFO - 2020-03-07 19:36:27 --> Hooks Class Initialized
DEBUG - 2020-03-07 19:36:27 --> UTF-8 Support Enabled
INFO - 2020-03-07 19:36:27 --> Utf8 Class Initialized
INFO - 2020-03-07 19:36:27 --> URI Class Initialized
DEBUG - 2020-03-07 19:36:27 --> No URI present. Default controller set.
INFO - 2020-03-07 19:36:27 --> Router Class Initialized
INFO - 2020-03-07 19:36:27 --> Output Class Initialized
INFO - 2020-03-07 19:36:27 --> Security Class Initialized
DEBUG - 2020-03-07 19:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 19:36:27 --> Input Class Initialized
INFO - 2020-03-07 19:36:27 --> Language Class Initialized
INFO - 2020-03-07 19:36:27 --> Loader Class Initialized
INFO - 2020-03-07 19:36:27 --> Helper loaded: url_helper
INFO - 2020-03-07 19:36:27 --> Helper loaded: string_helper
INFO - 2020-03-07 19:36:27 --> Database Driver Class Initialized
DEBUG - 2020-03-07 19:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 19:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 19:36:27 --> Controller Class Initialized
INFO - 2020-03-07 19:36:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 19:36:27 --> Pagination Class Initialized
INFO - 2020-03-07 19:36:27 --> Model "M_show" initialized
INFO - 2020-03-07 19:36:27 --> Helper loaded: form_helper
INFO - 2020-03-07 19:36:27 --> Form Validation Class Initialized
INFO - 2020-03-07 19:36:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 19:36:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 19:36:27 --> Final output sent to browser
DEBUG - 2020-03-07 19:36:27 --> Total execution time: 0.0452
INFO - 2020-03-07 19:36:36 --> Config Class Initialized
INFO - 2020-03-07 19:36:36 --> Hooks Class Initialized
DEBUG - 2020-03-07 19:36:36 --> UTF-8 Support Enabled
INFO - 2020-03-07 19:36:36 --> Utf8 Class Initialized
INFO - 2020-03-07 19:36:36 --> URI Class Initialized
INFO - 2020-03-07 19:36:36 --> Router Class Initialized
INFO - 2020-03-07 19:36:36 --> Output Class Initialized
INFO - 2020-03-07 19:36:36 --> Security Class Initialized
DEBUG - 2020-03-07 19:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 19:36:36 --> Input Class Initialized
INFO - 2020-03-07 19:36:36 --> Language Class Initialized
INFO - 2020-03-07 19:36:36 --> Loader Class Initialized
INFO - 2020-03-07 19:36:36 --> Helper loaded: url_helper
INFO - 2020-03-07 19:36:36 --> Helper loaded: string_helper
INFO - 2020-03-07 19:36:36 --> Database Driver Class Initialized
DEBUG - 2020-03-07 19:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 19:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 19:36:36 --> Controller Class Initialized
INFO - 2020-03-07 19:36:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 19:36:36 --> Pagination Class Initialized
INFO - 2020-03-07 19:36:36 --> Model "M_show" initialized
INFO - 2020-03-07 19:36:36 --> Helper loaded: form_helper
INFO - 2020-03-07 19:36:36 --> Form Validation Class Initialized
INFO - 2020-03-07 19:36:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 19:36:36 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 19:36:36 --> Final output sent to browser
DEBUG - 2020-03-07 19:36:36 --> Total execution time: 0.0086
INFO - 2020-03-07 19:36:40 --> Config Class Initialized
INFO - 2020-03-07 19:36:40 --> Hooks Class Initialized
DEBUG - 2020-03-07 19:36:40 --> UTF-8 Support Enabled
INFO - 2020-03-07 19:36:40 --> Utf8 Class Initialized
INFO - 2020-03-07 19:36:40 --> URI Class Initialized
INFO - 2020-03-07 19:36:40 --> Router Class Initialized
INFO - 2020-03-07 19:36:40 --> Output Class Initialized
INFO - 2020-03-07 19:36:40 --> Security Class Initialized
DEBUG - 2020-03-07 19:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 19:36:40 --> Input Class Initialized
INFO - 2020-03-07 19:36:40 --> Language Class Initialized
INFO - 2020-03-07 19:36:40 --> Loader Class Initialized
INFO - 2020-03-07 19:36:40 --> Helper loaded: url_helper
INFO - 2020-03-07 19:36:40 --> Helper loaded: string_helper
INFO - 2020-03-07 19:36:40 --> Database Driver Class Initialized
DEBUG - 2020-03-07 19:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 19:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 19:36:40 --> Controller Class Initialized
INFO - 2020-03-07 19:36:40 --> Model "M_tiket" initialized
INFO - 2020-03-07 19:36:40 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 19:36:40 --> Model "M_pesan" initialized
INFO - 2020-03-07 19:36:40 --> Helper loaded: form_helper
INFO - 2020-03-07 19:36:40 --> Form Validation Class Initialized
INFO - 2020-03-07 19:36:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 19:36:40 --> Final output sent to browser
DEBUG - 2020-03-07 19:36:40 --> Total execution time: 0.0107
INFO - 2020-03-07 19:36:52 --> Config Class Initialized
INFO - 2020-03-07 19:36:52 --> Hooks Class Initialized
DEBUG - 2020-03-07 19:36:52 --> UTF-8 Support Enabled
INFO - 2020-03-07 19:36:52 --> Utf8 Class Initialized
INFO - 2020-03-07 19:36:52 --> URI Class Initialized
INFO - 2020-03-07 19:36:52 --> Router Class Initialized
INFO - 2020-03-07 19:36:52 --> Output Class Initialized
INFO - 2020-03-07 19:36:52 --> Security Class Initialized
DEBUG - 2020-03-07 19:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 19:36:52 --> Input Class Initialized
INFO - 2020-03-07 19:36:52 --> Language Class Initialized
INFO - 2020-03-07 19:36:52 --> Loader Class Initialized
INFO - 2020-03-07 19:36:52 --> Helper loaded: url_helper
INFO - 2020-03-07 19:36:52 --> Helper loaded: string_helper
INFO - 2020-03-07 19:36:52 --> Database Driver Class Initialized
DEBUG - 2020-03-07 19:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 19:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 19:36:52 --> Controller Class Initialized
INFO - 2020-03-07 19:36:52 --> Model "M_tiket" initialized
INFO - 2020-03-07 19:36:52 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 19:36:52 --> Model "M_pesan" initialized
INFO - 2020-03-07 19:36:52 --> Helper loaded: form_helper
INFO - 2020-03-07 19:36:52 --> Form Validation Class Initialized
INFO - 2020-03-07 19:36:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 19:36:52 --> Final output sent to browser
DEBUG - 2020-03-07 19:36:52 --> Total execution time: 0.0078
INFO - 2020-03-07 19:42:41 --> Config Class Initialized
INFO - 2020-03-07 19:42:41 --> Hooks Class Initialized
DEBUG - 2020-03-07 19:42:41 --> UTF-8 Support Enabled
INFO - 2020-03-07 19:42:41 --> Utf8 Class Initialized
INFO - 2020-03-07 19:42:41 --> URI Class Initialized
DEBUG - 2020-03-07 19:42:41 --> No URI present. Default controller set.
INFO - 2020-03-07 19:42:41 --> Router Class Initialized
INFO - 2020-03-07 19:42:41 --> Output Class Initialized
INFO - 2020-03-07 19:42:41 --> Security Class Initialized
DEBUG - 2020-03-07 19:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 19:42:41 --> Input Class Initialized
INFO - 2020-03-07 19:42:41 --> Language Class Initialized
INFO - 2020-03-07 19:42:41 --> Loader Class Initialized
INFO - 2020-03-07 19:42:41 --> Helper loaded: url_helper
INFO - 2020-03-07 19:42:41 --> Helper loaded: string_helper
INFO - 2020-03-07 19:42:41 --> Database Driver Class Initialized
DEBUG - 2020-03-07 19:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 19:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 19:42:41 --> Controller Class Initialized
INFO - 2020-03-07 19:42:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 19:42:41 --> Pagination Class Initialized
INFO - 2020-03-07 19:42:41 --> Model "M_show" initialized
INFO - 2020-03-07 19:42:41 --> Helper loaded: form_helper
INFO - 2020-03-07 19:42:41 --> Form Validation Class Initialized
INFO - 2020-03-07 19:42:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 19:42:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 19:42:41 --> Final output sent to browser
DEBUG - 2020-03-07 19:42:41 --> Total execution time: 0.0295
INFO - 2020-03-07 19:42:46 --> Config Class Initialized
INFO - 2020-03-07 19:42:46 --> Hooks Class Initialized
DEBUG - 2020-03-07 19:42:46 --> UTF-8 Support Enabled
INFO - 2020-03-07 19:42:46 --> Utf8 Class Initialized
INFO - 2020-03-07 19:42:46 --> URI Class Initialized
INFO - 2020-03-07 19:42:46 --> Router Class Initialized
INFO - 2020-03-07 19:42:46 --> Output Class Initialized
INFO - 2020-03-07 19:42:46 --> Security Class Initialized
DEBUG - 2020-03-07 19:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 19:42:46 --> Input Class Initialized
INFO - 2020-03-07 19:42:46 --> Language Class Initialized
INFO - 2020-03-07 19:42:46 --> Loader Class Initialized
INFO - 2020-03-07 19:42:46 --> Helper loaded: url_helper
INFO - 2020-03-07 19:42:46 --> Helper loaded: string_helper
INFO - 2020-03-07 19:42:46 --> Database Driver Class Initialized
DEBUG - 2020-03-07 19:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 19:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 19:42:47 --> Controller Class Initialized
INFO - 2020-03-07 19:42:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 19:42:47 --> Pagination Class Initialized
INFO - 2020-03-07 19:42:47 --> Model "M_show" initialized
INFO - 2020-03-07 19:42:47 --> Helper loaded: form_helper
INFO - 2020-03-07 19:42:47 --> Form Validation Class Initialized
INFO - 2020-03-07 19:42:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 19:42:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 19:42:47 --> Final output sent to browser
DEBUG - 2020-03-07 19:42:47 --> Total execution time: 0.0449
INFO - 2020-03-07 19:42:49 --> Config Class Initialized
INFO - 2020-03-07 19:42:49 --> Hooks Class Initialized
DEBUG - 2020-03-07 19:42:49 --> UTF-8 Support Enabled
INFO - 2020-03-07 19:42:49 --> Utf8 Class Initialized
INFO - 2020-03-07 19:42:49 --> URI Class Initialized
INFO - 2020-03-07 19:42:49 --> Router Class Initialized
INFO - 2020-03-07 19:42:49 --> Output Class Initialized
INFO - 2020-03-07 19:42:49 --> Security Class Initialized
DEBUG - 2020-03-07 19:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 19:42:49 --> Input Class Initialized
INFO - 2020-03-07 19:42:49 --> Language Class Initialized
INFO - 2020-03-07 19:42:49 --> Loader Class Initialized
INFO - 2020-03-07 19:42:49 --> Helper loaded: url_helper
INFO - 2020-03-07 19:42:49 --> Helper loaded: string_helper
INFO - 2020-03-07 19:42:49 --> Database Driver Class Initialized
DEBUG - 2020-03-07 19:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 19:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 19:42:49 --> Controller Class Initialized
INFO - 2020-03-07 19:42:49 --> Model "M_tiket" initialized
INFO - 2020-03-07 19:42:49 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 19:42:49 --> Model "M_pesan" initialized
INFO - 2020-03-07 19:42:49 --> Helper loaded: form_helper
INFO - 2020-03-07 19:42:49 --> Form Validation Class Initialized
INFO - 2020-03-07 19:42:49 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 19:42:49 --> Final output sent to browser
DEBUG - 2020-03-07 19:42:49 --> Total execution time: 0.0389
INFO - 2020-03-07 19:43:02 --> Config Class Initialized
INFO - 2020-03-07 19:43:02 --> Hooks Class Initialized
DEBUG - 2020-03-07 19:43:02 --> UTF-8 Support Enabled
INFO - 2020-03-07 19:43:02 --> Utf8 Class Initialized
INFO - 2020-03-07 19:43:02 --> URI Class Initialized
INFO - 2020-03-07 19:43:02 --> Router Class Initialized
INFO - 2020-03-07 19:43:02 --> Output Class Initialized
INFO - 2020-03-07 19:43:02 --> Security Class Initialized
DEBUG - 2020-03-07 19:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 19:43:02 --> Input Class Initialized
INFO - 2020-03-07 19:43:02 --> Language Class Initialized
INFO - 2020-03-07 19:43:02 --> Loader Class Initialized
INFO - 2020-03-07 19:43:02 --> Helper loaded: url_helper
INFO - 2020-03-07 19:43:02 --> Helper loaded: string_helper
INFO - 2020-03-07 19:43:02 --> Database Driver Class Initialized
DEBUG - 2020-03-07 19:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 19:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 19:43:02 --> Controller Class Initialized
INFO - 2020-03-07 19:43:02 --> Model "M_tiket" initialized
INFO - 2020-03-07 19:43:02 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 19:43:02 --> Model "M_pesan" initialized
INFO - 2020-03-07 19:43:02 --> Helper loaded: form_helper
INFO - 2020-03-07 19:43:02 --> Form Validation Class Initialized
INFO - 2020-03-07 19:43:02 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 19:43:02 --> Final output sent to browser
DEBUG - 2020-03-07 19:43:02 --> Total execution time: 0.0689
INFO - 2020-03-07 20:00:03 --> Config Class Initialized
INFO - 2020-03-07 20:00:03 --> Hooks Class Initialized
DEBUG - 2020-03-07 20:00:03 --> UTF-8 Support Enabled
INFO - 2020-03-07 20:00:03 --> Utf8 Class Initialized
INFO - 2020-03-07 20:00:03 --> URI Class Initialized
DEBUG - 2020-03-07 20:00:03 --> No URI present. Default controller set.
INFO - 2020-03-07 20:00:03 --> Router Class Initialized
INFO - 2020-03-07 20:00:03 --> Output Class Initialized
INFO - 2020-03-07 20:00:03 --> Security Class Initialized
DEBUG - 2020-03-07 20:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 20:00:03 --> Input Class Initialized
INFO - 2020-03-07 20:00:03 --> Language Class Initialized
INFO - 2020-03-07 20:00:03 --> Loader Class Initialized
INFO - 2020-03-07 20:00:03 --> Helper loaded: url_helper
INFO - 2020-03-07 20:00:03 --> Helper loaded: string_helper
INFO - 2020-03-07 20:00:03 --> Database Driver Class Initialized
DEBUG - 2020-03-07 20:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 20:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 20:00:03 --> Controller Class Initialized
INFO - 2020-03-07 20:00:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 20:00:03 --> Pagination Class Initialized
INFO - 2020-03-07 20:00:03 --> Model "M_show" initialized
INFO - 2020-03-07 20:00:03 --> Helper loaded: form_helper
INFO - 2020-03-07 20:00:03 --> Form Validation Class Initialized
INFO - 2020-03-07 20:00:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 20:00:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 20:00:03 --> Final output sent to browser
DEBUG - 2020-03-07 20:00:03 --> Total execution time: 0.6721
INFO - 2020-03-07 20:00:09 --> Config Class Initialized
INFO - 2020-03-07 20:00:09 --> Hooks Class Initialized
DEBUG - 2020-03-07 20:00:09 --> UTF-8 Support Enabled
INFO - 2020-03-07 20:00:09 --> Utf8 Class Initialized
INFO - 2020-03-07 20:00:09 --> URI Class Initialized
DEBUG - 2020-03-07 20:00:09 --> No URI present. Default controller set.
INFO - 2020-03-07 20:00:09 --> Router Class Initialized
INFO - 2020-03-07 20:00:09 --> Output Class Initialized
INFO - 2020-03-07 20:00:09 --> Security Class Initialized
DEBUG - 2020-03-07 20:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 20:00:09 --> Input Class Initialized
INFO - 2020-03-07 20:00:09 --> Language Class Initialized
INFO - 2020-03-07 20:00:09 --> Loader Class Initialized
INFO - 2020-03-07 20:00:09 --> Helper loaded: url_helper
INFO - 2020-03-07 20:00:09 --> Helper loaded: string_helper
INFO - 2020-03-07 20:00:09 --> Database Driver Class Initialized
DEBUG - 2020-03-07 20:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 20:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 20:00:09 --> Controller Class Initialized
INFO - 2020-03-07 20:00:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 20:00:09 --> Pagination Class Initialized
INFO - 2020-03-07 20:00:09 --> Model "M_show" initialized
INFO - 2020-03-07 20:00:09 --> Helper loaded: form_helper
INFO - 2020-03-07 20:00:09 --> Form Validation Class Initialized
INFO - 2020-03-07 20:00:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 20:00:09 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 20:00:09 --> Final output sent to browser
DEBUG - 2020-03-07 20:00:09 --> Total execution time: 0.0067
INFO - 2020-03-07 20:00:15 --> Config Class Initialized
INFO - 2020-03-07 20:00:15 --> Hooks Class Initialized
DEBUG - 2020-03-07 20:00:15 --> UTF-8 Support Enabled
INFO - 2020-03-07 20:00:15 --> Utf8 Class Initialized
INFO - 2020-03-07 20:00:15 --> URI Class Initialized
DEBUG - 2020-03-07 20:00:15 --> No URI present. Default controller set.
INFO - 2020-03-07 20:00:15 --> Router Class Initialized
INFO - 2020-03-07 20:00:15 --> Output Class Initialized
INFO - 2020-03-07 20:00:15 --> Security Class Initialized
DEBUG - 2020-03-07 20:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 20:00:15 --> Input Class Initialized
INFO - 2020-03-07 20:00:15 --> Language Class Initialized
INFO - 2020-03-07 20:00:15 --> Loader Class Initialized
INFO - 2020-03-07 20:00:15 --> Helper loaded: url_helper
INFO - 2020-03-07 20:00:15 --> Helper loaded: string_helper
INFO - 2020-03-07 20:00:15 --> Database Driver Class Initialized
DEBUG - 2020-03-07 20:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 20:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 20:00:15 --> Controller Class Initialized
INFO - 2020-03-07 20:00:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 20:00:15 --> Pagination Class Initialized
INFO - 2020-03-07 20:00:15 --> Model "M_show" initialized
INFO - 2020-03-07 20:00:15 --> Helper loaded: form_helper
INFO - 2020-03-07 20:00:15 --> Form Validation Class Initialized
INFO - 2020-03-07 20:00:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 20:00:15 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 20:00:15 --> Final output sent to browser
DEBUG - 2020-03-07 20:00:15 --> Total execution time: 0.0060
INFO - 2020-03-07 20:00:21 --> Config Class Initialized
INFO - 2020-03-07 20:00:21 --> Hooks Class Initialized
DEBUG - 2020-03-07 20:00:21 --> UTF-8 Support Enabled
INFO - 2020-03-07 20:00:21 --> Utf8 Class Initialized
INFO - 2020-03-07 20:00:21 --> URI Class Initialized
INFO - 2020-03-07 20:00:21 --> Router Class Initialized
INFO - 2020-03-07 20:00:21 --> Output Class Initialized
INFO - 2020-03-07 20:00:21 --> Security Class Initialized
DEBUG - 2020-03-07 20:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 20:00:21 --> Input Class Initialized
INFO - 2020-03-07 20:00:21 --> Language Class Initialized
INFO - 2020-03-07 20:00:21 --> Loader Class Initialized
INFO - 2020-03-07 20:00:21 --> Helper loaded: url_helper
INFO - 2020-03-07 20:00:21 --> Helper loaded: string_helper
INFO - 2020-03-07 20:00:21 --> Database Driver Class Initialized
DEBUG - 2020-03-07 20:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 20:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 20:00:21 --> Controller Class Initialized
INFO - 2020-03-07 20:00:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 20:00:21 --> Pagination Class Initialized
INFO - 2020-03-07 20:00:21 --> Model "M_show" initialized
INFO - 2020-03-07 20:00:21 --> Helper loaded: form_helper
INFO - 2020-03-07 20:00:21 --> Form Validation Class Initialized
INFO - 2020-03-07 20:00:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 20:00:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 20:00:21 --> Final output sent to browser
DEBUG - 2020-03-07 20:00:21 --> Total execution time: 0.0085
INFO - 2020-03-07 20:00:25 --> Config Class Initialized
INFO - 2020-03-07 20:00:25 --> Hooks Class Initialized
DEBUG - 2020-03-07 20:00:25 --> UTF-8 Support Enabled
INFO - 2020-03-07 20:00:25 --> Utf8 Class Initialized
INFO - 2020-03-07 20:00:25 --> URI Class Initialized
INFO - 2020-03-07 20:00:25 --> Router Class Initialized
INFO - 2020-03-07 20:00:25 --> Output Class Initialized
INFO - 2020-03-07 20:00:25 --> Security Class Initialized
DEBUG - 2020-03-07 20:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 20:00:25 --> Input Class Initialized
INFO - 2020-03-07 20:00:25 --> Language Class Initialized
INFO - 2020-03-07 20:00:25 --> Loader Class Initialized
INFO - 2020-03-07 20:00:25 --> Helper loaded: url_helper
INFO - 2020-03-07 20:00:25 --> Helper loaded: string_helper
INFO - 2020-03-07 20:00:25 --> Database Driver Class Initialized
DEBUG - 2020-03-07 20:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 20:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 20:00:25 --> Controller Class Initialized
INFO - 2020-03-07 20:00:25 --> Model "M_tiket" initialized
INFO - 2020-03-07 20:00:25 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 20:00:25 --> Model "M_pesan" initialized
INFO - 2020-03-07 20:00:25 --> Helper loaded: form_helper
INFO - 2020-03-07 20:00:25 --> Form Validation Class Initialized
INFO - 2020-03-07 20:00:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 20:00:25 --> Final output sent to browser
DEBUG - 2020-03-07 20:00:25 --> Total execution time: 0.0096
INFO - 2020-03-07 20:00:38 --> Config Class Initialized
INFO - 2020-03-07 20:00:38 --> Hooks Class Initialized
DEBUG - 2020-03-07 20:00:38 --> UTF-8 Support Enabled
INFO - 2020-03-07 20:00:38 --> Utf8 Class Initialized
INFO - 2020-03-07 20:00:38 --> URI Class Initialized
INFO - 2020-03-07 20:00:38 --> Router Class Initialized
INFO - 2020-03-07 20:00:38 --> Output Class Initialized
INFO - 2020-03-07 20:00:38 --> Security Class Initialized
DEBUG - 2020-03-07 20:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 20:00:38 --> Input Class Initialized
INFO - 2020-03-07 20:00:38 --> Language Class Initialized
INFO - 2020-03-07 20:00:38 --> Loader Class Initialized
INFO - 2020-03-07 20:00:38 --> Helper loaded: url_helper
INFO - 2020-03-07 20:00:38 --> Helper loaded: string_helper
INFO - 2020-03-07 20:00:38 --> Database Driver Class Initialized
DEBUG - 2020-03-07 20:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 20:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 20:00:38 --> Controller Class Initialized
INFO - 2020-03-07 20:00:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 20:00:38 --> Pagination Class Initialized
INFO - 2020-03-07 20:00:38 --> Model "M_show" initialized
INFO - 2020-03-07 20:00:38 --> Helper loaded: form_helper
INFO - 2020-03-07 20:00:38 --> Form Validation Class Initialized
INFO - 2020-03-07 20:00:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 20:00:38 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 20:00:38 --> Final output sent to browser
DEBUG - 2020-03-07 20:00:38 --> Total execution time: 0.0067
INFO - 2020-03-07 20:00:58 --> Config Class Initialized
INFO - 2020-03-07 20:00:58 --> Hooks Class Initialized
DEBUG - 2020-03-07 20:00:58 --> UTF-8 Support Enabled
INFO - 2020-03-07 20:00:58 --> Utf8 Class Initialized
INFO - 2020-03-07 20:00:58 --> URI Class Initialized
DEBUG - 2020-03-07 20:00:58 --> No URI present. Default controller set.
INFO - 2020-03-07 20:00:58 --> Router Class Initialized
INFO - 2020-03-07 20:00:58 --> Output Class Initialized
INFO - 2020-03-07 20:00:58 --> Security Class Initialized
DEBUG - 2020-03-07 20:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 20:00:58 --> Input Class Initialized
INFO - 2020-03-07 20:00:58 --> Language Class Initialized
INFO - 2020-03-07 20:00:58 --> Loader Class Initialized
INFO - 2020-03-07 20:00:58 --> Helper loaded: url_helper
INFO - 2020-03-07 20:00:58 --> Helper loaded: string_helper
INFO - 2020-03-07 20:00:58 --> Database Driver Class Initialized
DEBUG - 2020-03-07 20:00:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 20:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 20:00:58 --> Controller Class Initialized
INFO - 2020-03-07 20:00:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 20:00:58 --> Pagination Class Initialized
INFO - 2020-03-07 20:00:58 --> Model "M_show" initialized
INFO - 2020-03-07 20:00:58 --> Helper loaded: form_helper
INFO - 2020-03-07 20:00:58 --> Form Validation Class Initialized
INFO - 2020-03-07 20:00:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 20:00:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 20:00:58 --> Final output sent to browser
DEBUG - 2020-03-07 20:00:58 --> Total execution time: 0.0061
INFO - 2020-03-07 20:01:03 --> Config Class Initialized
INFO - 2020-03-07 20:01:03 --> Hooks Class Initialized
DEBUG - 2020-03-07 20:01:03 --> UTF-8 Support Enabled
INFO - 2020-03-07 20:01:03 --> Utf8 Class Initialized
INFO - 2020-03-07 20:01:03 --> URI Class Initialized
INFO - 2020-03-07 20:01:03 --> Router Class Initialized
INFO - 2020-03-07 20:01:03 --> Output Class Initialized
INFO - 2020-03-07 20:01:03 --> Security Class Initialized
DEBUG - 2020-03-07 20:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 20:01:03 --> Input Class Initialized
INFO - 2020-03-07 20:01:03 --> Language Class Initialized
INFO - 2020-03-07 20:01:03 --> Loader Class Initialized
INFO - 2020-03-07 20:01:03 --> Helper loaded: url_helper
INFO - 2020-03-07 20:01:03 --> Helper loaded: string_helper
INFO - 2020-03-07 20:01:03 --> Database Driver Class Initialized
DEBUG - 2020-03-07 20:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 20:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 20:01:03 --> Controller Class Initialized
INFO - 2020-03-07 20:01:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 20:01:03 --> Pagination Class Initialized
INFO - 2020-03-07 20:01:03 --> Model "M_show" initialized
INFO - 2020-03-07 20:01:03 --> Helper loaded: form_helper
INFO - 2020-03-07 20:01:03 --> Form Validation Class Initialized
INFO - 2020-03-07 20:01:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 20:01:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-07 20:01:03 --> Final output sent to browser
DEBUG - 2020-03-07 20:01:03 --> Total execution time: 0.0074
INFO - 2020-03-07 20:01:23 --> Config Class Initialized
INFO - 2020-03-07 20:01:23 --> Hooks Class Initialized
DEBUG - 2020-03-07 20:01:23 --> UTF-8 Support Enabled
INFO - 2020-03-07 20:01:23 --> Utf8 Class Initialized
INFO - 2020-03-07 20:01:23 --> URI Class Initialized
INFO - 2020-03-07 20:01:23 --> Router Class Initialized
INFO - 2020-03-07 20:01:23 --> Output Class Initialized
INFO - 2020-03-07 20:01:23 --> Security Class Initialized
DEBUG - 2020-03-07 20:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 20:01:23 --> Input Class Initialized
INFO - 2020-03-07 20:01:23 --> Language Class Initialized
INFO - 2020-03-07 20:01:23 --> Loader Class Initialized
INFO - 2020-03-07 20:01:23 --> Helper loaded: url_helper
INFO - 2020-03-07 20:01:23 --> Helper loaded: string_helper
INFO - 2020-03-07 20:01:23 --> Database Driver Class Initialized
DEBUG - 2020-03-07 20:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 20:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 20:01:23 --> Controller Class Initialized
INFO - 2020-03-07 20:01:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 20:01:23 --> Pagination Class Initialized
INFO - 2020-03-07 20:01:23 --> Model "M_show" initialized
INFO - 2020-03-07 20:01:23 --> Helper loaded: form_helper
INFO - 2020-03-07 20:01:23 --> Form Validation Class Initialized
INFO - 2020-03-07 20:01:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 20:01:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol2.php
INFO - 2020-03-07 20:01:23 --> Final output sent to browser
DEBUG - 2020-03-07 20:01:23 --> Total execution time: 0.0061
INFO - 2020-03-07 20:01:48 --> Config Class Initialized
INFO - 2020-03-07 20:01:48 --> Hooks Class Initialized
DEBUG - 2020-03-07 20:01:48 --> UTF-8 Support Enabled
INFO - 2020-03-07 20:01:48 --> Utf8 Class Initialized
INFO - 2020-03-07 20:01:48 --> URI Class Initialized
INFO - 2020-03-07 20:01:48 --> Router Class Initialized
INFO - 2020-03-07 20:01:48 --> Output Class Initialized
INFO - 2020-03-07 20:01:48 --> Security Class Initialized
DEBUG - 2020-03-07 20:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 20:01:48 --> Input Class Initialized
INFO - 2020-03-07 20:01:48 --> Language Class Initialized
INFO - 2020-03-07 20:01:48 --> Loader Class Initialized
INFO - 2020-03-07 20:01:48 --> Helper loaded: url_helper
INFO - 2020-03-07 20:01:48 --> Helper loaded: string_helper
INFO - 2020-03-07 20:01:48 --> Database Driver Class Initialized
DEBUG - 2020-03-07 20:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 20:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 20:01:48 --> Controller Class Initialized
INFO - 2020-03-07 20:01:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 20:01:48 --> Pagination Class Initialized
INFO - 2020-03-07 20:01:48 --> Model "M_show" initialized
INFO - 2020-03-07 20:01:48 --> Helper loaded: form_helper
INFO - 2020-03-07 20:01:48 --> Form Validation Class Initialized
INFO - 2020-03-07 20:01:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 20:01:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/gal.php
INFO - 2020-03-07 20:01:48 --> Final output sent to browser
DEBUG - 2020-03-07 20:01:48 --> Total execution time: 0.0458
INFO - 2020-03-07 20:05:10 --> Config Class Initialized
INFO - 2020-03-07 20:05:10 --> Hooks Class Initialized
DEBUG - 2020-03-07 20:05:10 --> UTF-8 Support Enabled
INFO - 2020-03-07 20:05:10 --> Utf8 Class Initialized
INFO - 2020-03-07 20:05:10 --> URI Class Initialized
DEBUG - 2020-03-07 20:05:10 --> No URI present. Default controller set.
INFO - 2020-03-07 20:05:10 --> Router Class Initialized
INFO - 2020-03-07 20:05:10 --> Output Class Initialized
INFO - 2020-03-07 20:05:10 --> Security Class Initialized
DEBUG - 2020-03-07 20:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 20:05:10 --> Input Class Initialized
INFO - 2020-03-07 20:05:10 --> Language Class Initialized
INFO - 2020-03-07 20:05:10 --> Loader Class Initialized
INFO - 2020-03-07 20:05:10 --> Helper loaded: url_helper
INFO - 2020-03-07 20:05:10 --> Helper loaded: string_helper
INFO - 2020-03-07 20:05:10 --> Database Driver Class Initialized
DEBUG - 2020-03-07 20:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 20:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 20:05:10 --> Controller Class Initialized
INFO - 2020-03-07 20:05:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 20:05:10 --> Pagination Class Initialized
INFO - 2020-03-07 20:05:10 --> Model "M_show" initialized
INFO - 2020-03-07 20:05:10 --> Helper loaded: form_helper
INFO - 2020-03-07 20:05:10 --> Form Validation Class Initialized
INFO - 2020-03-07 20:05:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 20:05:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 20:05:10 --> Final output sent to browser
DEBUG - 2020-03-07 20:05:10 --> Total execution time: 0.0361
INFO - 2020-03-07 20:05:10 --> Config Class Initialized
INFO - 2020-03-07 20:05:10 --> Hooks Class Initialized
DEBUG - 2020-03-07 20:05:10 --> UTF-8 Support Enabled
INFO - 2020-03-07 20:05:10 --> Utf8 Class Initialized
INFO - 2020-03-07 20:05:10 --> URI Class Initialized
DEBUG - 2020-03-07 20:05:10 --> No URI present. Default controller set.
INFO - 2020-03-07 20:05:10 --> Router Class Initialized
INFO - 2020-03-07 20:05:10 --> Output Class Initialized
INFO - 2020-03-07 20:05:10 --> Security Class Initialized
DEBUG - 2020-03-07 20:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 20:05:10 --> Input Class Initialized
INFO - 2020-03-07 20:05:10 --> Language Class Initialized
INFO - 2020-03-07 20:05:10 --> Loader Class Initialized
INFO - 2020-03-07 20:05:10 --> Helper loaded: url_helper
INFO - 2020-03-07 20:05:10 --> Helper loaded: string_helper
INFO - 2020-03-07 20:05:10 --> Database Driver Class Initialized
DEBUG - 2020-03-07 20:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 20:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 20:05:10 --> Controller Class Initialized
INFO - 2020-03-07 20:05:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 20:05:10 --> Pagination Class Initialized
INFO - 2020-03-07 20:05:10 --> Model "M_show" initialized
INFO - 2020-03-07 20:05:10 --> Helper loaded: form_helper
INFO - 2020-03-07 20:05:10 --> Form Validation Class Initialized
INFO - 2020-03-07 20:05:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 20:05:10 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 20:05:10 --> Final output sent to browser
DEBUG - 2020-03-07 20:05:10 --> Total execution time: 0.0038
INFO - 2020-03-07 20:05:21 --> Config Class Initialized
INFO - 2020-03-07 20:05:21 --> Hooks Class Initialized
DEBUG - 2020-03-07 20:05:21 --> UTF-8 Support Enabled
INFO - 2020-03-07 20:05:21 --> Utf8 Class Initialized
INFO - 2020-03-07 20:05:21 --> URI Class Initialized
INFO - 2020-03-07 20:05:21 --> Router Class Initialized
INFO - 2020-03-07 20:05:21 --> Output Class Initialized
INFO - 2020-03-07 20:05:21 --> Security Class Initialized
DEBUG - 2020-03-07 20:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 20:05:21 --> Input Class Initialized
INFO - 2020-03-07 20:05:21 --> Language Class Initialized
INFO - 2020-03-07 20:05:21 --> Loader Class Initialized
INFO - 2020-03-07 20:05:21 --> Helper loaded: url_helper
INFO - 2020-03-07 20:05:21 --> Helper loaded: string_helper
INFO - 2020-03-07 20:05:21 --> Database Driver Class Initialized
DEBUG - 2020-03-07 20:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 20:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 20:05:21 --> Controller Class Initialized
INFO - 2020-03-07 20:05:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 20:05:21 --> Pagination Class Initialized
INFO - 2020-03-07 20:05:21 --> Model "M_show" initialized
INFO - 2020-03-07 20:05:21 --> Helper loaded: form_helper
INFO - 2020-03-07 20:05:21 --> Form Validation Class Initialized
INFO - 2020-03-07 20:05:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 20:05:21 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tentang.php
INFO - 2020-03-07 20:05:21 --> Final output sent to browser
DEBUG - 2020-03-07 20:05:21 --> Total execution time: 0.0074
INFO - 2020-03-07 20:05:25 --> Config Class Initialized
INFO - 2020-03-07 20:05:25 --> Hooks Class Initialized
DEBUG - 2020-03-07 20:05:25 --> UTF-8 Support Enabled
INFO - 2020-03-07 20:05:25 --> Utf8 Class Initialized
INFO - 2020-03-07 20:05:25 --> URI Class Initialized
DEBUG - 2020-03-07 20:05:25 --> No URI present. Default controller set.
INFO - 2020-03-07 20:05:25 --> Router Class Initialized
INFO - 2020-03-07 20:05:25 --> Output Class Initialized
INFO - 2020-03-07 20:05:25 --> Security Class Initialized
DEBUG - 2020-03-07 20:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 20:05:25 --> Input Class Initialized
INFO - 2020-03-07 20:05:25 --> Language Class Initialized
INFO - 2020-03-07 20:05:25 --> Loader Class Initialized
INFO - 2020-03-07 20:05:25 --> Helper loaded: url_helper
INFO - 2020-03-07 20:05:25 --> Helper loaded: string_helper
INFO - 2020-03-07 20:05:25 --> Database Driver Class Initialized
DEBUG - 2020-03-07 20:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 20:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 20:05:25 --> Controller Class Initialized
INFO - 2020-03-07 20:05:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 20:05:25 --> Pagination Class Initialized
INFO - 2020-03-07 20:05:25 --> Model "M_show" initialized
INFO - 2020-03-07 20:05:25 --> Helper loaded: form_helper
INFO - 2020-03-07 20:05:25 --> Form Validation Class Initialized
INFO - 2020-03-07 20:05:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 20:05:25 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 20:05:25 --> Final output sent to browser
DEBUG - 2020-03-07 20:05:25 --> Total execution time: 0.2229
INFO - 2020-03-07 20:05:27 --> Config Class Initialized
INFO - 2020-03-07 20:05:27 --> Hooks Class Initialized
DEBUG - 2020-03-07 20:05:27 --> UTF-8 Support Enabled
INFO - 2020-03-07 20:05:27 --> Utf8 Class Initialized
INFO - 2020-03-07 20:05:27 --> URI Class Initialized
INFO - 2020-03-07 20:05:27 --> Router Class Initialized
INFO - 2020-03-07 20:05:27 --> Output Class Initialized
INFO - 2020-03-07 20:05:27 --> Security Class Initialized
DEBUG - 2020-03-07 20:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 20:05:27 --> Input Class Initialized
INFO - 2020-03-07 20:05:27 --> Language Class Initialized
INFO - 2020-03-07 20:05:27 --> Loader Class Initialized
INFO - 2020-03-07 20:05:27 --> Helper loaded: url_helper
INFO - 2020-03-07 20:05:27 --> Helper loaded: string_helper
INFO - 2020-03-07 20:05:27 --> Database Driver Class Initialized
DEBUG - 2020-03-07 20:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 20:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 20:05:27 --> Controller Class Initialized
INFO - 2020-03-07 20:05:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 20:05:27 --> Pagination Class Initialized
INFO - 2020-03-07 20:05:27 --> Model "M_show" initialized
INFO - 2020-03-07 20:05:27 --> Helper loaded: form_helper
INFO - 2020-03-07 20:05:27 --> Form Validation Class Initialized
INFO - 2020-03-07 20:05:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 20:05:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/hub.php
INFO - 2020-03-07 20:05:27 --> Final output sent to browser
DEBUG - 2020-03-07 20:05:27 --> Total execution time: 0.1328
INFO - 2020-03-07 20:05:41 --> Config Class Initialized
INFO - 2020-03-07 20:05:41 --> Hooks Class Initialized
DEBUG - 2020-03-07 20:05:41 --> UTF-8 Support Enabled
INFO - 2020-03-07 20:05:41 --> Utf8 Class Initialized
INFO - 2020-03-07 20:05:41 --> URI Class Initialized
DEBUG - 2020-03-07 20:05:41 --> No URI present. Default controller set.
INFO - 2020-03-07 20:05:41 --> Router Class Initialized
INFO - 2020-03-07 20:05:41 --> Output Class Initialized
INFO - 2020-03-07 20:05:41 --> Security Class Initialized
DEBUG - 2020-03-07 20:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 20:05:41 --> Input Class Initialized
INFO - 2020-03-07 20:05:41 --> Language Class Initialized
INFO - 2020-03-07 20:05:41 --> Loader Class Initialized
INFO - 2020-03-07 20:05:41 --> Helper loaded: url_helper
INFO - 2020-03-07 20:05:41 --> Helper loaded: string_helper
INFO - 2020-03-07 20:05:41 --> Database Driver Class Initialized
DEBUG - 2020-03-07 20:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 20:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 20:05:41 --> Controller Class Initialized
INFO - 2020-03-07 20:05:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 20:05:41 --> Pagination Class Initialized
INFO - 2020-03-07 20:05:41 --> Model "M_show" initialized
INFO - 2020-03-07 20:05:41 --> Helper loaded: form_helper
INFO - 2020-03-07 20:05:41 --> Form Validation Class Initialized
INFO - 2020-03-07 20:05:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 20:05:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 20:05:41 --> Final output sent to browser
DEBUG - 2020-03-07 20:05:41 --> Total execution time: 0.0057
INFO - 2020-03-07 20:35:20 --> Config Class Initialized
INFO - 2020-03-07 20:35:20 --> Hooks Class Initialized
DEBUG - 2020-03-07 20:35:20 --> UTF-8 Support Enabled
INFO - 2020-03-07 20:35:20 --> Utf8 Class Initialized
INFO - 2020-03-07 20:35:20 --> URI Class Initialized
DEBUG - 2020-03-07 20:35:20 --> No URI present. Default controller set.
INFO - 2020-03-07 20:35:20 --> Router Class Initialized
INFO - 2020-03-07 20:35:20 --> Output Class Initialized
INFO - 2020-03-07 20:35:20 --> Security Class Initialized
DEBUG - 2020-03-07 20:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 20:35:20 --> Input Class Initialized
INFO - 2020-03-07 20:35:20 --> Language Class Initialized
INFO - 2020-03-07 20:35:20 --> Loader Class Initialized
INFO - 2020-03-07 20:35:20 --> Helper loaded: url_helper
INFO - 2020-03-07 20:35:20 --> Helper loaded: string_helper
INFO - 2020-03-07 20:35:20 --> Database Driver Class Initialized
DEBUG - 2020-03-07 20:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 20:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 20:35:20 --> Controller Class Initialized
INFO - 2020-03-07 20:35:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 20:35:20 --> Pagination Class Initialized
INFO - 2020-03-07 20:35:20 --> Model "M_show" initialized
INFO - 2020-03-07 20:35:20 --> Helper loaded: form_helper
INFO - 2020-03-07 20:35:20 --> Form Validation Class Initialized
INFO - 2020-03-07 20:35:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 20:35:20 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 20:35:20 --> Final output sent to browser
DEBUG - 2020-03-07 20:35:20 --> Total execution time: 0.5485
INFO - 2020-03-07 20:35:41 --> Config Class Initialized
INFO - 2020-03-07 20:35:41 --> Hooks Class Initialized
DEBUG - 2020-03-07 20:35:41 --> UTF-8 Support Enabled
INFO - 2020-03-07 20:35:41 --> Utf8 Class Initialized
INFO - 2020-03-07 20:35:41 --> URI Class Initialized
INFO - 2020-03-07 20:35:41 --> Router Class Initialized
INFO - 2020-03-07 20:35:41 --> Output Class Initialized
INFO - 2020-03-07 20:35:41 --> Security Class Initialized
DEBUG - 2020-03-07 20:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 20:35:41 --> Input Class Initialized
INFO - 2020-03-07 20:35:41 --> Language Class Initialized
INFO - 2020-03-07 20:35:41 --> Loader Class Initialized
INFO - 2020-03-07 20:35:41 --> Helper loaded: url_helper
INFO - 2020-03-07 20:35:41 --> Helper loaded: string_helper
INFO - 2020-03-07 20:35:41 --> Database Driver Class Initialized
DEBUG - 2020-03-07 20:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 20:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 20:35:41 --> Controller Class Initialized
INFO - 2020-03-07 20:35:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 20:35:41 --> Pagination Class Initialized
INFO - 2020-03-07 20:35:41 --> Model "M_show" initialized
INFO - 2020-03-07 20:35:41 --> Helper loaded: form_helper
INFO - 2020-03-07 20:35:41 --> Form Validation Class Initialized
INFO - 2020-03-07 20:35:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 20:35:41 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-07 20:35:41 --> Final output sent to browser
DEBUG - 2020-03-07 20:35:41 --> Total execution time: 0.0060
INFO - 2020-03-07 20:35:48 --> Config Class Initialized
INFO - 2020-03-07 20:35:48 --> Hooks Class Initialized
DEBUG - 2020-03-07 20:35:48 --> UTF-8 Support Enabled
INFO - 2020-03-07 20:35:48 --> Utf8 Class Initialized
INFO - 2020-03-07 20:35:48 --> URI Class Initialized
INFO - 2020-03-07 20:35:48 --> Router Class Initialized
INFO - 2020-03-07 20:35:48 --> Output Class Initialized
INFO - 2020-03-07 20:35:48 --> Security Class Initialized
DEBUG - 2020-03-07 20:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 20:35:48 --> Input Class Initialized
INFO - 2020-03-07 20:35:48 --> Language Class Initialized
INFO - 2020-03-07 20:35:48 --> Loader Class Initialized
INFO - 2020-03-07 20:35:48 --> Helper loaded: url_helper
INFO - 2020-03-07 20:35:48 --> Helper loaded: string_helper
INFO - 2020-03-07 20:35:48 --> Database Driver Class Initialized
DEBUG - 2020-03-07 20:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 20:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 20:35:48 --> Controller Class Initialized
INFO - 2020-03-07 20:35:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 20:35:48 --> Pagination Class Initialized
INFO - 2020-03-07 20:35:48 --> Model "M_show" initialized
INFO - 2020-03-07 20:35:48 --> Helper loaded: form_helper
INFO - 2020-03-07 20:35:48 --> Form Validation Class Initialized
INFO - 2020-03-07 20:35:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 20:35:48 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 20:35:48 --> Final output sent to browser
DEBUG - 2020-03-07 20:35:48 --> Total execution time: 0.0059
INFO - 2020-03-07 20:35:52 --> Config Class Initialized
INFO - 2020-03-07 20:35:52 --> Hooks Class Initialized
DEBUG - 2020-03-07 20:35:52 --> UTF-8 Support Enabled
INFO - 2020-03-07 20:35:52 --> Utf8 Class Initialized
INFO - 2020-03-07 20:35:52 --> URI Class Initialized
INFO - 2020-03-07 20:35:52 --> Router Class Initialized
INFO - 2020-03-07 20:35:52 --> Output Class Initialized
INFO - 2020-03-07 20:35:52 --> Security Class Initialized
DEBUG - 2020-03-07 20:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 20:35:52 --> Input Class Initialized
INFO - 2020-03-07 20:35:52 --> Language Class Initialized
INFO - 2020-03-07 20:35:52 --> Loader Class Initialized
INFO - 2020-03-07 20:35:52 --> Helper loaded: url_helper
INFO - 2020-03-07 20:35:52 --> Helper loaded: string_helper
INFO - 2020-03-07 20:35:52 --> Database Driver Class Initialized
DEBUG - 2020-03-07 20:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 20:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 20:35:52 --> Controller Class Initialized
INFO - 2020-03-07 20:35:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 20:35:52 --> Pagination Class Initialized
INFO - 2020-03-07 20:35:52 --> Model "M_show" initialized
INFO - 2020-03-07 20:35:52 --> Helper loaded: form_helper
INFO - 2020-03-07 20:35:52 --> Form Validation Class Initialized
INFO - 2020-03-07 20:35:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 20:35:52 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 20:35:52 --> Final output sent to browser
DEBUG - 2020-03-07 20:35:52 --> Total execution time: 0.0054
INFO - 2020-03-07 20:35:58 --> Config Class Initialized
INFO - 2020-03-07 20:35:58 --> Hooks Class Initialized
DEBUG - 2020-03-07 20:35:58 --> UTF-8 Support Enabled
INFO - 2020-03-07 20:35:58 --> Utf8 Class Initialized
INFO - 2020-03-07 20:35:58 --> URI Class Initialized
INFO - 2020-03-07 20:35:58 --> Router Class Initialized
INFO - 2020-03-07 20:35:58 --> Output Class Initialized
INFO - 2020-03-07 20:35:58 --> Security Class Initialized
DEBUG - 2020-03-07 20:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 20:35:58 --> Input Class Initialized
INFO - 2020-03-07 20:35:58 --> Language Class Initialized
INFO - 2020-03-07 20:35:58 --> Loader Class Initialized
INFO - 2020-03-07 20:35:58 --> Helper loaded: url_helper
INFO - 2020-03-07 20:35:58 --> Helper loaded: string_helper
INFO - 2020-03-07 20:35:58 --> Database Driver Class Initialized
DEBUG - 2020-03-07 20:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 20:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 20:35:58 --> Controller Class Initialized
INFO - 2020-03-07 20:35:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 20:35:58 --> Pagination Class Initialized
INFO - 2020-03-07 20:35:58 --> Model "M_show" initialized
INFO - 2020-03-07 20:35:58 --> Helper loaded: form_helper
INFO - 2020-03-07 20:35:58 --> Form Validation Class Initialized
INFO - 2020-03-07 20:35:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 20:35:58 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 20:35:58 --> Final output sent to browser
DEBUG - 2020-03-07 20:35:58 --> Total execution time: 0.0084
INFO - 2020-03-07 20:36:03 --> Config Class Initialized
INFO - 2020-03-07 20:36:03 --> Hooks Class Initialized
DEBUG - 2020-03-07 20:36:03 --> UTF-8 Support Enabled
INFO - 2020-03-07 20:36:03 --> Utf8 Class Initialized
INFO - 2020-03-07 20:36:03 --> URI Class Initialized
INFO - 2020-03-07 20:36:03 --> Router Class Initialized
INFO - 2020-03-07 20:36:03 --> Output Class Initialized
INFO - 2020-03-07 20:36:03 --> Security Class Initialized
DEBUG - 2020-03-07 20:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 20:36:03 --> Input Class Initialized
INFO - 2020-03-07 20:36:03 --> Language Class Initialized
INFO - 2020-03-07 20:36:03 --> Loader Class Initialized
INFO - 2020-03-07 20:36:03 --> Helper loaded: url_helper
INFO - 2020-03-07 20:36:03 --> Helper loaded: string_helper
INFO - 2020-03-07 20:36:03 --> Database Driver Class Initialized
DEBUG - 2020-03-07 20:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 20:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 20:36:03 --> Controller Class Initialized
INFO - 2020-03-07 20:36:03 --> Model "M_tiket" initialized
INFO - 2020-03-07 20:36:03 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 20:36:03 --> Model "M_pesan" initialized
INFO - 2020-03-07 20:36:03 --> Helper loaded: form_helper
INFO - 2020-03-07 20:36:03 --> Form Validation Class Initialized
INFO - 2020-03-07 20:36:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 20:36:03 --> Final output sent to browser
DEBUG - 2020-03-07 20:36:03 --> Total execution time: 0.0101
INFO - 2020-03-07 20:36:42 --> Config Class Initialized
INFO - 2020-03-07 20:36:42 --> Hooks Class Initialized
DEBUG - 2020-03-07 20:36:42 --> UTF-8 Support Enabled
INFO - 2020-03-07 20:36:42 --> Utf8 Class Initialized
INFO - 2020-03-07 20:36:42 --> URI Class Initialized
INFO - 2020-03-07 20:36:42 --> Router Class Initialized
INFO - 2020-03-07 20:36:42 --> Output Class Initialized
INFO - 2020-03-07 20:36:42 --> Security Class Initialized
DEBUG - 2020-03-07 20:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 20:36:42 --> Input Class Initialized
INFO - 2020-03-07 20:36:42 --> Language Class Initialized
INFO - 2020-03-07 20:36:42 --> Loader Class Initialized
INFO - 2020-03-07 20:36:42 --> Helper loaded: url_helper
INFO - 2020-03-07 20:36:42 --> Helper loaded: string_helper
INFO - 2020-03-07 20:36:42 --> Database Driver Class Initialized
DEBUG - 2020-03-07 20:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 20:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 20:36:42 --> Controller Class Initialized
INFO - 2020-03-07 20:36:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 20:36:42 --> Pagination Class Initialized
INFO - 2020-03-07 20:36:42 --> Model "M_show" initialized
INFO - 2020-03-07 20:36:42 --> Helper loaded: form_helper
INFO - 2020-03-07 20:36:42 --> Form Validation Class Initialized
INFO - 2020-03-07 20:36:42 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 20:36:42 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 20:36:42 --> Final output sent to browser
DEBUG - 2020-03-07 20:36:42 --> Total execution time: 0.0056
INFO - 2020-03-07 20:36:46 --> Config Class Initialized
INFO - 2020-03-07 20:36:46 --> Hooks Class Initialized
DEBUG - 2020-03-07 20:36:46 --> UTF-8 Support Enabled
INFO - 2020-03-07 20:36:46 --> Utf8 Class Initialized
INFO - 2020-03-07 20:36:46 --> URI Class Initialized
INFO - 2020-03-07 20:36:46 --> Router Class Initialized
INFO - 2020-03-07 20:36:46 --> Output Class Initialized
INFO - 2020-03-07 20:36:46 --> Security Class Initialized
DEBUG - 2020-03-07 20:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 20:36:46 --> Input Class Initialized
INFO - 2020-03-07 20:36:46 --> Language Class Initialized
INFO - 2020-03-07 20:36:46 --> Loader Class Initialized
INFO - 2020-03-07 20:36:46 --> Helper loaded: url_helper
INFO - 2020-03-07 20:36:46 --> Helper loaded: string_helper
INFO - 2020-03-07 20:36:46 --> Database Driver Class Initialized
DEBUG - 2020-03-07 20:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 20:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 20:36:46 --> Controller Class Initialized
INFO - 2020-03-07 20:36:46 --> Model "M_tiket" initialized
INFO - 2020-03-07 20:36:46 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 20:36:46 --> Model "M_pesan" initialized
INFO - 2020-03-07 20:36:46 --> Helper loaded: form_helper
INFO - 2020-03-07 20:36:46 --> Form Validation Class Initialized
INFO - 2020-03-07 20:36:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 20:36:46 --> Final output sent to browser
DEBUG - 2020-03-07 20:36:46 --> Total execution time: 0.0073
INFO - 2020-03-07 20:36:56 --> Config Class Initialized
INFO - 2020-03-07 20:36:56 --> Hooks Class Initialized
DEBUG - 2020-03-07 20:36:56 --> UTF-8 Support Enabled
INFO - 2020-03-07 20:36:56 --> Utf8 Class Initialized
INFO - 2020-03-07 20:36:56 --> URI Class Initialized
INFO - 2020-03-07 20:36:56 --> Router Class Initialized
INFO - 2020-03-07 20:36:56 --> Output Class Initialized
INFO - 2020-03-07 20:36:56 --> Security Class Initialized
DEBUG - 2020-03-07 20:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 20:36:56 --> Input Class Initialized
INFO - 2020-03-07 20:36:56 --> Language Class Initialized
INFO - 2020-03-07 20:36:56 --> Loader Class Initialized
INFO - 2020-03-07 20:36:56 --> Helper loaded: url_helper
INFO - 2020-03-07 20:36:56 --> Helper loaded: string_helper
INFO - 2020-03-07 20:36:56 --> Database Driver Class Initialized
DEBUG - 2020-03-07 20:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 20:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 20:36:56 --> Controller Class Initialized
INFO - 2020-03-07 20:36:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 20:36:56 --> Pagination Class Initialized
INFO - 2020-03-07 20:36:56 --> Model "M_show" initialized
INFO - 2020-03-07 20:36:56 --> Helper loaded: form_helper
INFO - 2020-03-07 20:36:56 --> Form Validation Class Initialized
INFO - 2020-03-07 20:36:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 20:36:56 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 20:36:56 --> Final output sent to browser
DEBUG - 2020-03-07 20:36:56 --> Total execution time: 0.0064
INFO - 2020-03-07 20:37:00 --> Config Class Initialized
INFO - 2020-03-07 20:37:00 --> Hooks Class Initialized
DEBUG - 2020-03-07 20:37:00 --> UTF-8 Support Enabled
INFO - 2020-03-07 20:37:00 --> Utf8 Class Initialized
INFO - 2020-03-07 20:37:00 --> URI Class Initialized
INFO - 2020-03-07 20:37:00 --> Router Class Initialized
INFO - 2020-03-07 20:37:00 --> Output Class Initialized
INFO - 2020-03-07 20:37:00 --> Security Class Initialized
DEBUG - 2020-03-07 20:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 20:37:00 --> Input Class Initialized
INFO - 2020-03-07 20:37:00 --> Language Class Initialized
INFO - 2020-03-07 20:37:00 --> Loader Class Initialized
INFO - 2020-03-07 20:37:00 --> Helper loaded: url_helper
INFO - 2020-03-07 20:37:00 --> Helper loaded: string_helper
INFO - 2020-03-07 20:37:00 --> Database Driver Class Initialized
DEBUG - 2020-03-07 20:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 20:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 20:37:00 --> Controller Class Initialized
INFO - 2020-03-07 20:37:00 --> Model "M_tiket" initialized
INFO - 2020-03-07 20:37:00 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 20:37:00 --> Model "M_pesan" initialized
INFO - 2020-03-07 20:37:00 --> Helper loaded: form_helper
INFO - 2020-03-07 20:37:00 --> Form Validation Class Initialized
INFO - 2020-03-07 20:37:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 20:37:00 --> Final output sent to browser
DEBUG - 2020-03-07 20:37:00 --> Total execution time: 0.0068
INFO - 2020-03-07 20:37:11 --> Config Class Initialized
INFO - 2020-03-07 20:37:11 --> Hooks Class Initialized
DEBUG - 2020-03-07 20:37:11 --> UTF-8 Support Enabled
INFO - 2020-03-07 20:37:11 --> Utf8 Class Initialized
INFO - 2020-03-07 20:37:11 --> URI Class Initialized
INFO - 2020-03-07 20:37:11 --> Router Class Initialized
INFO - 2020-03-07 20:37:11 --> Output Class Initialized
INFO - 2020-03-07 20:37:11 --> Security Class Initialized
DEBUG - 2020-03-07 20:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 20:37:11 --> Input Class Initialized
INFO - 2020-03-07 20:37:11 --> Language Class Initialized
INFO - 2020-03-07 20:37:11 --> Loader Class Initialized
INFO - 2020-03-07 20:37:11 --> Helper loaded: url_helper
INFO - 2020-03-07 20:37:11 --> Helper loaded: string_helper
INFO - 2020-03-07 20:37:11 --> Database Driver Class Initialized
DEBUG - 2020-03-07 20:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 20:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 20:37:11 --> Controller Class Initialized
INFO - 2020-03-07 20:37:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 20:37:11 --> Pagination Class Initialized
INFO - 2020-03-07 20:37:11 --> Model "M_show" initialized
INFO - 2020-03-07 20:37:11 --> Helper loaded: form_helper
INFO - 2020-03-07 20:37:11 --> Form Validation Class Initialized
INFO - 2020-03-07 20:37:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 20:37:11 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 20:37:11 --> Final output sent to browser
DEBUG - 2020-03-07 20:37:11 --> Total execution time: 0.0060
INFO - 2020-03-07 20:37:16 --> Config Class Initialized
INFO - 2020-03-07 20:37:18 --> Hooks Class Initialized
DEBUG - 2020-03-07 20:37:18 --> UTF-8 Support Enabled
INFO - 2020-03-07 20:37:18 --> Utf8 Class Initialized
INFO - 2020-03-07 20:37:18 --> URI Class Initialized
INFO - 2020-03-07 20:37:18 --> Router Class Initialized
INFO - 2020-03-07 20:37:18 --> Output Class Initialized
INFO - 2020-03-07 20:37:18 --> Security Class Initialized
DEBUG - 2020-03-07 20:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 20:37:18 --> Input Class Initialized
INFO - 2020-03-07 20:37:18 --> Language Class Initialized
INFO - 2020-03-07 20:37:18 --> Loader Class Initialized
INFO - 2020-03-07 20:37:18 --> Helper loaded: url_helper
INFO - 2020-03-07 20:37:18 --> Helper loaded: string_helper
INFO - 2020-03-07 20:37:18 --> Database Driver Class Initialized
DEBUG - 2020-03-07 20:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 20:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 20:37:18 --> Controller Class Initialized
INFO - 2020-03-07 20:37:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 20:37:18 --> Pagination Class Initialized
INFO - 2020-03-07 20:37:18 --> Model "M_show" initialized
INFO - 2020-03-07 20:37:18 --> Helper loaded: form_helper
INFO - 2020-03-07 20:37:18 --> Form Validation Class Initialized
INFO - 2020-03-07 20:37:18 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 20:37:18 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 20:37:18 --> Final output sent to browser
DEBUG - 2020-03-07 20:37:18 --> Total execution time: 1.7081
INFO - 2020-03-07 20:37:24 --> Config Class Initialized
INFO - 2020-03-07 20:37:24 --> Hooks Class Initialized
DEBUG - 2020-03-07 20:37:24 --> UTF-8 Support Enabled
INFO - 2020-03-07 20:37:24 --> Utf8 Class Initialized
INFO - 2020-03-07 20:37:24 --> URI Class Initialized
INFO - 2020-03-07 20:37:24 --> Router Class Initialized
INFO - 2020-03-07 20:37:24 --> Output Class Initialized
INFO - 2020-03-07 20:37:24 --> Security Class Initialized
DEBUG - 2020-03-07 20:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 20:37:24 --> Input Class Initialized
INFO - 2020-03-07 20:37:24 --> Language Class Initialized
INFO - 2020-03-07 20:37:24 --> Loader Class Initialized
INFO - 2020-03-07 20:37:24 --> Helper loaded: url_helper
INFO - 2020-03-07 20:37:24 --> Helper loaded: string_helper
INFO - 2020-03-07 20:37:24 --> Database Driver Class Initialized
DEBUG - 2020-03-07 20:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 20:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 20:37:24 --> Controller Class Initialized
INFO - 2020-03-07 20:37:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 20:37:24 --> Pagination Class Initialized
INFO - 2020-03-07 20:37:24 --> Model "M_show" initialized
INFO - 2020-03-07 20:37:24 --> Helper loaded: form_helper
INFO - 2020-03-07 20:37:24 --> Form Validation Class Initialized
INFO - 2020-03-07 20:37:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 20:37:24 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-07 20:37:24 --> Final output sent to browser
DEBUG - 2020-03-07 20:37:24 --> Total execution time: 0.0064
INFO - 2020-03-07 20:37:27 --> Config Class Initialized
INFO - 2020-03-07 20:37:27 --> Hooks Class Initialized
DEBUG - 2020-03-07 20:37:27 --> UTF-8 Support Enabled
INFO - 2020-03-07 20:37:27 --> Utf8 Class Initialized
INFO - 2020-03-07 20:37:27 --> URI Class Initialized
DEBUG - 2020-03-07 20:37:27 --> No URI present. Default controller set.
INFO - 2020-03-07 20:37:27 --> Router Class Initialized
INFO - 2020-03-07 20:37:27 --> Output Class Initialized
INFO - 2020-03-07 20:37:27 --> Security Class Initialized
DEBUG - 2020-03-07 20:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 20:37:27 --> Input Class Initialized
INFO - 2020-03-07 20:37:27 --> Language Class Initialized
INFO - 2020-03-07 20:37:27 --> Loader Class Initialized
INFO - 2020-03-07 20:37:27 --> Helper loaded: url_helper
INFO - 2020-03-07 20:37:27 --> Helper loaded: string_helper
INFO - 2020-03-07 20:37:27 --> Database Driver Class Initialized
DEBUG - 2020-03-07 20:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 20:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 20:37:27 --> Controller Class Initialized
INFO - 2020-03-07 20:37:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 20:37:27 --> Pagination Class Initialized
INFO - 2020-03-07 20:37:27 --> Model "M_show" initialized
INFO - 2020-03-07 20:37:27 --> Helper loaded: form_helper
INFO - 2020-03-07 20:37:27 --> Form Validation Class Initialized
INFO - 2020-03-07 20:37:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 20:37:27 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 20:37:27 --> Final output sent to browser
DEBUG - 2020-03-07 20:37:27 --> Total execution time: 0.0055
INFO - 2020-03-07 20:37:33 --> Config Class Initialized
INFO - 2020-03-07 20:37:33 --> Hooks Class Initialized
DEBUG - 2020-03-07 20:37:33 --> UTF-8 Support Enabled
INFO - 2020-03-07 20:37:33 --> Utf8 Class Initialized
INFO - 2020-03-07 20:37:33 --> URI Class Initialized
INFO - 2020-03-07 20:37:33 --> Router Class Initialized
INFO - 2020-03-07 20:37:33 --> Output Class Initialized
INFO - 2020-03-07 20:37:33 --> Security Class Initialized
DEBUG - 2020-03-07 20:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 20:37:33 --> Input Class Initialized
INFO - 2020-03-07 20:37:33 --> Language Class Initialized
INFO - 2020-03-07 20:37:33 --> Loader Class Initialized
INFO - 2020-03-07 20:37:33 --> Helper loaded: url_helper
INFO - 2020-03-07 20:37:33 --> Helper loaded: string_helper
INFO - 2020-03-07 20:37:33 --> Database Driver Class Initialized
DEBUG - 2020-03-07 20:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 20:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 20:37:33 --> Controller Class Initialized
INFO - 2020-03-07 20:37:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 20:37:33 --> Pagination Class Initialized
INFO - 2020-03-07 20:37:33 --> Model "M_show" initialized
INFO - 2020-03-07 20:37:33 --> Helper loaded: form_helper
INFO - 2020-03-07 20:37:33 --> Form Validation Class Initialized
INFO - 2020-03-07 20:37:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 20:37:33 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-07 20:37:33 --> Final output sent to browser
DEBUG - 2020-03-07 20:37:33 --> Total execution time: 0.0110
INFO - 2020-03-07 20:37:40 --> Config Class Initialized
INFO - 2020-03-07 20:37:40 --> Hooks Class Initialized
DEBUG - 2020-03-07 20:37:40 --> UTF-8 Support Enabled
INFO - 2020-03-07 20:37:40 --> Utf8 Class Initialized
INFO - 2020-03-07 20:37:40 --> URI Class Initialized
DEBUG - 2020-03-07 20:37:40 --> No URI present. Default controller set.
INFO - 2020-03-07 20:37:40 --> Router Class Initialized
INFO - 2020-03-07 20:37:40 --> Output Class Initialized
INFO - 2020-03-07 20:37:40 --> Security Class Initialized
DEBUG - 2020-03-07 20:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 20:37:40 --> Input Class Initialized
INFO - 2020-03-07 20:37:40 --> Language Class Initialized
INFO - 2020-03-07 20:37:40 --> Loader Class Initialized
INFO - 2020-03-07 20:37:40 --> Helper loaded: url_helper
INFO - 2020-03-07 20:37:40 --> Helper loaded: string_helper
INFO - 2020-03-07 20:37:40 --> Database Driver Class Initialized
DEBUG - 2020-03-07 20:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 20:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 20:37:40 --> Controller Class Initialized
INFO - 2020-03-07 20:37:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 20:37:40 --> Pagination Class Initialized
INFO - 2020-03-07 20:37:40 --> Model "M_show" initialized
INFO - 2020-03-07 20:37:40 --> Helper loaded: form_helper
INFO - 2020-03-07 20:37:40 --> Form Validation Class Initialized
INFO - 2020-03-07 20:37:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 20:37:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 20:37:40 --> Final output sent to browser
DEBUG - 2020-03-07 20:37:40 --> Total execution time: 0.1083
INFO - 2020-03-07 20:37:46 --> Config Class Initialized
INFO - 2020-03-07 20:37:46 --> Hooks Class Initialized
DEBUG - 2020-03-07 20:37:46 --> UTF-8 Support Enabled
INFO - 2020-03-07 20:37:46 --> Utf8 Class Initialized
INFO - 2020-03-07 20:37:46 --> URI Class Initialized
INFO - 2020-03-07 20:37:46 --> Router Class Initialized
INFO - 2020-03-07 20:37:46 --> Output Class Initialized
INFO - 2020-03-07 20:37:46 --> Security Class Initialized
DEBUG - 2020-03-07 20:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 20:37:46 --> Input Class Initialized
INFO - 2020-03-07 20:37:46 --> Language Class Initialized
INFO - 2020-03-07 20:37:46 --> Loader Class Initialized
INFO - 2020-03-07 20:37:46 --> Helper loaded: url_helper
INFO - 2020-03-07 20:37:46 --> Helper loaded: string_helper
INFO - 2020-03-07 20:37:46 --> Database Driver Class Initialized
DEBUG - 2020-03-07 20:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 20:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 20:37:46 --> Controller Class Initialized
INFO - 2020-03-07 20:37:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 20:37:46 --> Pagination Class Initialized
INFO - 2020-03-07 20:37:46 --> Model "M_show" initialized
INFO - 2020-03-07 20:37:46 --> Helper loaded: form_helper
INFO - 2020-03-07 20:37:46 --> Form Validation Class Initialized
INFO - 2020-03-07 20:37:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 20:37:46 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/vol1.php
INFO - 2020-03-07 20:37:46 --> Final output sent to browser
DEBUG - 2020-03-07 20:37:46 --> Total execution time: 0.0056
INFO - 2020-03-07 21:38:23 --> Config Class Initialized
INFO - 2020-03-07 21:38:23 --> Hooks Class Initialized
DEBUG - 2020-03-07 21:38:23 --> UTF-8 Support Enabled
INFO - 2020-03-07 21:38:23 --> Utf8 Class Initialized
INFO - 2020-03-07 21:38:23 --> URI Class Initialized
DEBUG - 2020-03-07 21:38:23 --> No URI present. Default controller set.
INFO - 2020-03-07 21:38:23 --> Router Class Initialized
INFO - 2020-03-07 21:38:23 --> Output Class Initialized
INFO - 2020-03-07 21:38:23 --> Security Class Initialized
DEBUG - 2020-03-07 21:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 21:38:23 --> Input Class Initialized
INFO - 2020-03-07 21:38:23 --> Language Class Initialized
INFO - 2020-03-07 21:38:23 --> Loader Class Initialized
INFO - 2020-03-07 21:38:23 --> Helper loaded: url_helper
INFO - 2020-03-07 21:38:23 --> Helper loaded: string_helper
INFO - 2020-03-07 21:38:23 --> Database Driver Class Initialized
DEBUG - 2020-03-07 21:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 21:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 21:38:23 --> Controller Class Initialized
INFO - 2020-03-07 21:38:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 21:38:23 --> Pagination Class Initialized
INFO - 2020-03-07 21:38:23 --> Model "M_show" initialized
INFO - 2020-03-07 21:38:23 --> Helper loaded: form_helper
INFO - 2020-03-07 21:38:23 --> Form Validation Class Initialized
INFO - 2020-03-07 21:38:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 21:38:23 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 21:38:23 --> Final output sent to browser
DEBUG - 2020-03-07 21:38:23 --> Total execution time: 0.0325
INFO - 2020-03-07 22:04:28 --> Config Class Initialized
INFO - 2020-03-07 22:04:28 --> Hooks Class Initialized
DEBUG - 2020-03-07 22:04:28 --> UTF-8 Support Enabled
INFO - 2020-03-07 22:04:28 --> Utf8 Class Initialized
INFO - 2020-03-07 22:04:28 --> URI Class Initialized
DEBUG - 2020-03-07 22:04:28 --> No URI present. Default controller set.
INFO - 2020-03-07 22:04:28 --> Router Class Initialized
INFO - 2020-03-07 22:04:28 --> Output Class Initialized
INFO - 2020-03-07 22:04:28 --> Security Class Initialized
DEBUG - 2020-03-07 22:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 22:04:28 --> Input Class Initialized
INFO - 2020-03-07 22:04:28 --> Language Class Initialized
INFO - 2020-03-07 22:04:28 --> Loader Class Initialized
INFO - 2020-03-07 22:04:28 --> Helper loaded: url_helper
INFO - 2020-03-07 22:04:28 --> Helper loaded: string_helper
INFO - 2020-03-07 22:04:28 --> Database Driver Class Initialized
DEBUG - 2020-03-07 22:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 22:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 22:04:28 --> Controller Class Initialized
INFO - 2020-03-07 22:04:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 22:04:28 --> Pagination Class Initialized
INFO - 2020-03-07 22:04:28 --> Model "M_show" initialized
INFO - 2020-03-07 22:04:28 --> Helper loaded: form_helper
INFO - 2020-03-07 22:04:28 --> Form Validation Class Initialized
INFO - 2020-03-07 22:04:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 22:04:28 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 22:04:28 --> Final output sent to browser
DEBUG - 2020-03-07 22:04:28 --> Total execution time: 0.0387
INFO - 2020-03-07 22:56:38 --> Config Class Initialized
INFO - 2020-03-07 22:56:38 --> Hooks Class Initialized
DEBUG - 2020-03-07 22:56:38 --> UTF-8 Support Enabled
INFO - 2020-03-07 22:56:38 --> Utf8 Class Initialized
INFO - 2020-03-07 22:56:38 --> URI Class Initialized
DEBUG - 2020-03-07 22:56:38 --> No URI present. Default controller set.
INFO - 2020-03-07 22:56:38 --> Router Class Initialized
INFO - 2020-03-07 22:56:38 --> Output Class Initialized
INFO - 2020-03-07 22:56:38 --> Security Class Initialized
DEBUG - 2020-03-07 22:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 22:56:38 --> Input Class Initialized
INFO - 2020-03-07 22:56:38 --> Language Class Initialized
INFO - 2020-03-07 22:56:38 --> Loader Class Initialized
INFO - 2020-03-07 22:56:38 --> Helper loaded: url_helper
INFO - 2020-03-07 22:56:38 --> Helper loaded: string_helper
INFO - 2020-03-07 22:56:38 --> Database Driver Class Initialized
DEBUG - 2020-03-07 22:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 22:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 22:56:39 --> Controller Class Initialized
INFO - 2020-03-07 22:56:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 22:56:39 --> Pagination Class Initialized
INFO - 2020-03-07 22:56:39 --> Model "M_show" initialized
INFO - 2020-03-07 22:56:39 --> Helper loaded: form_helper
INFO - 2020-03-07 22:56:39 --> Form Validation Class Initialized
INFO - 2020-03-07 22:56:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 22:56:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 22:56:39 --> Final output sent to browser
DEBUG - 2020-03-07 22:56:39 --> Total execution time: 0.4385
INFO - 2020-03-07 22:56:54 --> Config Class Initialized
INFO - 2020-03-07 22:56:54 --> Hooks Class Initialized
DEBUG - 2020-03-07 22:56:54 --> UTF-8 Support Enabled
INFO - 2020-03-07 22:56:54 --> Utf8 Class Initialized
INFO - 2020-03-07 22:56:54 --> URI Class Initialized
INFO - 2020-03-07 22:56:54 --> Router Class Initialized
INFO - 2020-03-07 22:56:54 --> Output Class Initialized
INFO - 2020-03-07 22:56:54 --> Security Class Initialized
DEBUG - 2020-03-07 22:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 22:56:54 --> Input Class Initialized
INFO - 2020-03-07 22:56:54 --> Language Class Initialized
INFO - 2020-03-07 22:56:54 --> Loader Class Initialized
INFO - 2020-03-07 22:56:54 --> Helper loaded: url_helper
INFO - 2020-03-07 22:56:54 --> Helper loaded: string_helper
INFO - 2020-03-07 22:56:54 --> Database Driver Class Initialized
DEBUG - 2020-03-07 22:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 22:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 22:56:54 --> Controller Class Initialized
INFO - 2020-03-07 22:56:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 22:56:54 --> Pagination Class Initialized
INFO - 2020-03-07 22:56:54 --> Model "M_show" initialized
INFO - 2020-03-07 22:56:54 --> Helper loaded: form_helper
INFO - 2020-03-07 22:56:54 --> Form Validation Class Initialized
INFO - 2020-03-07 22:56:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 22:56:54 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 22:56:54 --> Final output sent to browser
DEBUG - 2020-03-07 22:56:54 --> Total execution time: 0.2014
INFO - 2020-03-07 22:56:58 --> Config Class Initialized
INFO - 2020-03-07 22:56:58 --> Hooks Class Initialized
DEBUG - 2020-03-07 22:56:58 --> UTF-8 Support Enabled
INFO - 2020-03-07 22:56:58 --> Utf8 Class Initialized
INFO - 2020-03-07 22:56:58 --> URI Class Initialized
INFO - 2020-03-07 22:56:58 --> Router Class Initialized
INFO - 2020-03-07 22:56:58 --> Output Class Initialized
INFO - 2020-03-07 22:56:58 --> Security Class Initialized
DEBUG - 2020-03-07 22:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 22:56:58 --> Input Class Initialized
INFO - 2020-03-07 22:56:58 --> Language Class Initialized
INFO - 2020-03-07 22:56:58 --> Loader Class Initialized
INFO - 2020-03-07 22:56:58 --> Helper loaded: url_helper
INFO - 2020-03-07 22:56:58 --> Helper loaded: string_helper
INFO - 2020-03-07 22:56:58 --> Database Driver Class Initialized
DEBUG - 2020-03-07 22:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 22:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 22:56:59 --> Controller Class Initialized
INFO - 2020-03-07 22:56:59 --> Model "M_tiket" initialized
INFO - 2020-03-07 22:56:59 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 22:56:59 --> Model "M_pesan" initialized
INFO - 2020-03-07 22:56:59 --> Helper loaded: form_helper
INFO - 2020-03-07 22:56:59 --> Form Validation Class Initialized
INFO - 2020-03-07 22:56:59 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 22:56:59 --> Final output sent to browser
DEBUG - 2020-03-07 22:56:59 --> Total execution time: 0.1849
INFO - 2020-03-07 22:57:14 --> Config Class Initialized
INFO - 2020-03-07 22:57:14 --> Hooks Class Initialized
DEBUG - 2020-03-07 22:57:14 --> UTF-8 Support Enabled
INFO - 2020-03-07 22:57:14 --> Utf8 Class Initialized
INFO - 2020-03-07 22:57:14 --> URI Class Initialized
INFO - 2020-03-07 22:57:14 --> Router Class Initialized
INFO - 2020-03-07 22:57:14 --> Output Class Initialized
INFO - 2020-03-07 22:57:14 --> Security Class Initialized
DEBUG - 2020-03-07 22:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 22:57:14 --> Input Class Initialized
INFO - 2020-03-07 22:57:14 --> Language Class Initialized
INFO - 2020-03-07 22:57:14 --> Loader Class Initialized
INFO - 2020-03-07 22:57:14 --> Helper loaded: url_helper
INFO - 2020-03-07 22:57:14 --> Helper loaded: string_helper
INFO - 2020-03-07 22:57:14 --> Database Driver Class Initialized
DEBUG - 2020-03-07 22:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 22:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 22:57:14 --> Controller Class Initialized
INFO - 2020-03-07 22:57:14 --> Model "M_tiket" initialized
INFO - 2020-03-07 22:57:14 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 22:57:14 --> Model "M_pesan" initialized
INFO - 2020-03-07 22:57:14 --> Helper loaded: form_helper
INFO - 2020-03-07 22:57:14 --> Form Validation Class Initialized
INFO - 2020-03-07 22:57:14 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/pesan_tiket.php
INFO - 2020-03-07 22:57:14 --> Final output sent to browser
DEBUG - 2020-03-07 22:57:14 --> Total execution time: 0.0511
INFO - 2020-03-07 22:57:40 --> Config Class Initialized
INFO - 2020-03-07 22:57:40 --> Hooks Class Initialized
DEBUG - 2020-03-07 22:57:40 --> UTF-8 Support Enabled
INFO - 2020-03-07 22:57:40 --> Utf8 Class Initialized
INFO - 2020-03-07 22:57:40 --> URI Class Initialized
INFO - 2020-03-07 22:57:40 --> Router Class Initialized
INFO - 2020-03-07 22:57:40 --> Output Class Initialized
INFO - 2020-03-07 22:57:40 --> Security Class Initialized
DEBUG - 2020-03-07 22:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 22:57:40 --> Input Class Initialized
INFO - 2020-03-07 22:57:40 --> Language Class Initialized
INFO - 2020-03-07 22:57:40 --> Loader Class Initialized
INFO - 2020-03-07 22:57:40 --> Helper loaded: url_helper
INFO - 2020-03-07 22:57:40 --> Helper loaded: string_helper
INFO - 2020-03-07 22:57:40 --> Database Driver Class Initialized
DEBUG - 2020-03-07 22:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 22:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 22:57:40 --> Controller Class Initialized
INFO - 2020-03-07 22:57:40 --> Model "M_tiket" initialized
INFO - 2020-03-07 22:57:40 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 22:57:40 --> Model "M_pesan" initialized
INFO - 2020-03-07 22:57:40 --> Helper loaded: form_helper
INFO - 2020-03-07 22:57:40 --> Form Validation Class Initialized
INFO - 2020-03-07 22:57:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 22:57:40 --> Final output sent to browser
DEBUG - 2020-03-07 22:57:40 --> Total execution time: 0.0449
INFO - 2020-03-07 22:57:43 --> Config Class Initialized
INFO - 2020-03-07 22:57:43 --> Hooks Class Initialized
DEBUG - 2020-03-07 22:57:43 --> UTF-8 Support Enabled
INFO - 2020-03-07 22:57:43 --> Utf8 Class Initialized
INFO - 2020-03-07 22:57:43 --> URI Class Initialized
INFO - 2020-03-07 22:57:43 --> Router Class Initialized
INFO - 2020-03-07 22:57:43 --> Output Class Initialized
INFO - 2020-03-07 22:57:43 --> Security Class Initialized
DEBUG - 2020-03-07 22:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 22:57:43 --> Input Class Initialized
INFO - 2020-03-07 22:57:43 --> Language Class Initialized
INFO - 2020-03-07 22:57:43 --> Loader Class Initialized
INFO - 2020-03-07 22:57:43 --> Helper loaded: url_helper
INFO - 2020-03-07 22:57:43 --> Helper loaded: string_helper
INFO - 2020-03-07 22:57:43 --> Database Driver Class Initialized
DEBUG - 2020-03-07 22:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 22:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 22:57:43 --> Controller Class Initialized
INFO - 2020-03-07 22:57:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 22:57:43 --> Pagination Class Initialized
INFO - 2020-03-07 22:57:43 --> Model "M_show" initialized
INFO - 2020-03-07 22:57:43 --> Helper loaded: form_helper
INFO - 2020-03-07 22:57:43 --> Form Validation Class Initialized
INFO - 2020-03-07 22:57:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 22:57:43 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 22:57:43 --> Final output sent to browser
DEBUG - 2020-03-07 22:57:43 --> Total execution time: 0.0534
INFO - 2020-03-07 22:57:47 --> Config Class Initialized
INFO - 2020-03-07 22:57:47 --> Hooks Class Initialized
DEBUG - 2020-03-07 22:57:47 --> UTF-8 Support Enabled
INFO - 2020-03-07 22:57:47 --> Utf8 Class Initialized
INFO - 2020-03-07 22:57:47 --> URI Class Initialized
DEBUG - 2020-03-07 22:57:47 --> No URI present. Default controller set.
INFO - 2020-03-07 22:57:47 --> Router Class Initialized
INFO - 2020-03-07 22:57:47 --> Output Class Initialized
INFO - 2020-03-07 22:57:47 --> Security Class Initialized
DEBUG - 2020-03-07 22:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 22:57:47 --> Input Class Initialized
INFO - 2020-03-07 22:57:47 --> Language Class Initialized
INFO - 2020-03-07 22:57:47 --> Loader Class Initialized
INFO - 2020-03-07 22:57:47 --> Helper loaded: url_helper
INFO - 2020-03-07 22:57:47 --> Helper loaded: string_helper
INFO - 2020-03-07 22:57:47 --> Database Driver Class Initialized
DEBUG - 2020-03-07 22:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 22:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 22:57:47 --> Controller Class Initialized
INFO - 2020-03-07 22:57:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 22:57:47 --> Pagination Class Initialized
INFO - 2020-03-07 22:57:47 --> Model "M_show" initialized
INFO - 2020-03-07 22:57:47 --> Helper loaded: form_helper
INFO - 2020-03-07 22:57:47 --> Form Validation Class Initialized
INFO - 2020-03-07 22:57:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 22:57:47 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 22:57:47 --> Final output sent to browser
DEBUG - 2020-03-07 22:57:47 --> Total execution time: 0.0954
INFO - 2020-03-07 23:12:50 --> Config Class Initialized
INFO - 2020-03-07 23:12:50 --> Hooks Class Initialized
DEBUG - 2020-03-07 23:12:50 --> UTF-8 Support Enabled
INFO - 2020-03-07 23:12:50 --> Utf8 Class Initialized
INFO - 2020-03-07 23:12:50 --> URI Class Initialized
DEBUG - 2020-03-07 23:12:50 --> No URI present. Default controller set.
INFO - 2020-03-07 23:12:50 --> Router Class Initialized
INFO - 2020-03-07 23:12:50 --> Output Class Initialized
INFO - 2020-03-07 23:12:50 --> Security Class Initialized
DEBUG - 2020-03-07 23:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 23:12:50 --> Input Class Initialized
INFO - 2020-03-07 23:12:50 --> Language Class Initialized
INFO - 2020-03-07 23:12:50 --> Loader Class Initialized
INFO - 2020-03-07 23:12:50 --> Helper loaded: url_helper
INFO - 2020-03-07 23:12:50 --> Helper loaded: string_helper
INFO - 2020-03-07 23:12:50 --> Database Driver Class Initialized
DEBUG - 2020-03-07 23:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 23:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 23:12:50 --> Controller Class Initialized
INFO - 2020-03-07 23:12:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 23:12:50 --> Pagination Class Initialized
INFO - 2020-03-07 23:12:50 --> Model "M_show" initialized
INFO - 2020-03-07 23:12:50 --> Helper loaded: form_helper
INFO - 2020-03-07 23:12:50 --> Form Validation Class Initialized
INFO - 2020-03-07 23:12:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 23:12:50 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 23:12:50 --> Final output sent to browser
DEBUG - 2020-03-07 23:12:50 --> Total execution time: 0.0744
INFO - 2020-03-07 23:12:59 --> Config Class Initialized
INFO - 2020-03-07 23:12:59 --> Hooks Class Initialized
DEBUG - 2020-03-07 23:12:59 --> UTF-8 Support Enabled
INFO - 2020-03-07 23:12:59 --> Utf8 Class Initialized
INFO - 2020-03-07 23:12:59 --> URI Class Initialized
INFO - 2020-03-07 23:12:59 --> Router Class Initialized
INFO - 2020-03-07 23:12:59 --> Output Class Initialized
INFO - 2020-03-07 23:12:59 --> Security Class Initialized
DEBUG - 2020-03-07 23:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 23:12:59 --> Input Class Initialized
INFO - 2020-03-07 23:12:59 --> Language Class Initialized
INFO - 2020-03-07 23:12:59 --> Loader Class Initialized
INFO - 2020-03-07 23:12:59 --> Helper loaded: url_helper
INFO - 2020-03-07 23:12:59 --> Helper loaded: string_helper
INFO - 2020-03-07 23:12:59 --> Database Driver Class Initialized
DEBUG - 2020-03-07 23:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 23:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 23:13:00 --> Controller Class Initialized
INFO - 2020-03-07 23:13:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 23:13:00 --> Pagination Class Initialized
INFO - 2020-03-07 23:13:00 --> Model "M_show" initialized
INFO - 2020-03-07 23:13:00 --> Helper loaded: form_helper
INFO - 2020-03-07 23:13:00 --> Form Validation Class Initialized
INFO - 2020-03-07 23:13:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 23:13:00 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 23:13:00 --> Final output sent to browser
DEBUG - 2020-03-07 23:13:00 --> Total execution time: 0.1173
INFO - 2020-03-07 23:13:03 --> Config Class Initialized
INFO - 2020-03-07 23:13:03 --> Hooks Class Initialized
DEBUG - 2020-03-07 23:13:03 --> UTF-8 Support Enabled
INFO - 2020-03-07 23:13:03 --> Utf8 Class Initialized
INFO - 2020-03-07 23:13:03 --> URI Class Initialized
INFO - 2020-03-07 23:13:03 --> Router Class Initialized
INFO - 2020-03-07 23:13:03 --> Output Class Initialized
INFO - 2020-03-07 23:13:03 --> Security Class Initialized
DEBUG - 2020-03-07 23:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 23:13:03 --> Input Class Initialized
INFO - 2020-03-07 23:13:03 --> Language Class Initialized
INFO - 2020-03-07 23:13:03 --> Loader Class Initialized
INFO - 2020-03-07 23:13:03 --> Helper loaded: url_helper
INFO - 2020-03-07 23:13:03 --> Helper loaded: string_helper
INFO - 2020-03-07 23:13:03 --> Database Driver Class Initialized
DEBUG - 2020-03-07 23:13:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 23:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 23:13:03 --> Controller Class Initialized
INFO - 2020-03-07 23:13:03 --> Model "M_tiket" initialized
INFO - 2020-03-07 23:13:03 --> Model "M_pengunjung" initialized
INFO - 2020-03-07 23:13:03 --> Model "M_pesan" initialized
INFO - 2020-03-07 23:13:03 --> Helper loaded: form_helper
INFO - 2020-03-07 23:13:03 --> Form Validation Class Initialized
INFO - 2020-03-07 23:13:03 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/tiket/lihat_jenis.php
INFO - 2020-03-07 23:13:03 --> Final output sent to browser
DEBUG - 2020-03-07 23:13:03 --> Total execution time: 0.0102
INFO - 2020-03-07 23:13:39 --> Config Class Initialized
INFO - 2020-03-07 23:13:39 --> Hooks Class Initialized
DEBUG - 2020-03-07 23:13:39 --> UTF-8 Support Enabled
INFO - 2020-03-07 23:13:39 --> Utf8 Class Initialized
INFO - 2020-03-07 23:13:39 --> URI Class Initialized
INFO - 2020-03-07 23:13:39 --> Router Class Initialized
INFO - 2020-03-07 23:13:39 --> Output Class Initialized
INFO - 2020-03-07 23:13:39 --> Security Class Initialized
DEBUG - 2020-03-07 23:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 23:13:39 --> Input Class Initialized
INFO - 2020-03-07 23:13:39 --> Language Class Initialized
INFO - 2020-03-07 23:13:39 --> Loader Class Initialized
INFO - 2020-03-07 23:13:39 --> Helper loaded: url_helper
INFO - 2020-03-07 23:13:39 --> Helper loaded: string_helper
INFO - 2020-03-07 23:13:39 --> Database Driver Class Initialized
DEBUG - 2020-03-07 23:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 23:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 23:13:39 --> Controller Class Initialized
INFO - 2020-03-07 23:13:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 23:13:39 --> Pagination Class Initialized
INFO - 2020-03-07 23:13:39 --> Model "M_show" initialized
INFO - 2020-03-07 23:13:39 --> Helper loaded: form_helper
INFO - 2020-03-07 23:13:39 --> Form Validation Class Initialized
INFO - 2020-03-07 23:13:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 23:13:39 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/beli.php
INFO - 2020-03-07 23:13:39 --> Final output sent to browser
DEBUG - 2020-03-07 23:13:39 --> Total execution time: 0.0069
INFO - 2020-03-07 23:13:40 --> Config Class Initialized
INFO - 2020-03-07 23:13:40 --> Hooks Class Initialized
DEBUG - 2020-03-07 23:13:40 --> UTF-8 Support Enabled
INFO - 2020-03-07 23:13:40 --> Utf8 Class Initialized
INFO - 2020-03-07 23:13:40 --> URI Class Initialized
DEBUG - 2020-03-07 23:13:40 --> No URI present. Default controller set.
INFO - 2020-03-07 23:13:40 --> Router Class Initialized
INFO - 2020-03-07 23:13:40 --> Output Class Initialized
INFO - 2020-03-07 23:13:40 --> Security Class Initialized
DEBUG - 2020-03-07 23:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-07 23:13:40 --> Input Class Initialized
INFO - 2020-03-07 23:13:40 --> Language Class Initialized
INFO - 2020-03-07 23:13:40 --> Loader Class Initialized
INFO - 2020-03-07 23:13:40 --> Helper loaded: url_helper
INFO - 2020-03-07 23:13:40 --> Helper loaded: string_helper
INFO - 2020-03-07 23:13:40 --> Database Driver Class Initialized
DEBUG - 2020-03-07 23:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-07 23:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-07 23:13:40 --> Controller Class Initialized
INFO - 2020-03-07 23:13:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-03-07 23:13:40 --> Pagination Class Initialized
INFO - 2020-03-07 23:13:40 --> Model "M_show" initialized
INFO - 2020-03-07 23:13:40 --> Helper loaded: form_helper
INFO - 2020-03-07 23:13:40 --> Form Validation Class Initialized
INFO - 2020-03-07 23:13:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/header/header.php
INFO - 2020-03-07 23:13:40 --> File loaded: /home/u107185497/domains/musikologifest.com/public_html/application/views/home.php
INFO - 2020-03-07 23:13:40 --> Final output sent to browser
DEBUG - 2020-03-07 23:13:40 --> Total execution time: 0.0068
