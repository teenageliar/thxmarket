<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-25 00:00:10 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-25 00:00:10 --> Final output sent to browser
DEBUG - 2020-02-25 00:00:10 --> Total execution time: 0.4581
INFO - 2020-02-25 00:01:11 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-25 00:01:11 --> Final output sent to browser
DEBUG - 2020-02-25 00:01:11 --> Total execution time: 0.4395
INFO - 2020-02-25 00:01:21 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-25 00:01:21 --> Final output sent to browser
DEBUG - 2020-02-25 00:01:21 --> Total execution time: 0.3794
INFO - 2020-02-25 00:01:25 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-25 00:01:25 --> Final output sent to browser
DEBUG - 2020-02-25 00:01:25 --> Total execution time: 0.3430
INFO - 2020-02-25 00:21:28 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-25 00:21:28 --> Final output sent to browser
DEBUG - 2020-02-25 00:21:28 --> Total execution time: 0.3628
INFO - 2020-02-25 16:43:49 --> Config Class Initialized
INFO - 2020-02-25 16:43:49 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:43:49 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:43:49 --> Utf8 Class Initialized
INFO - 2020-02-25 16:43:49 --> URI Class Initialized
DEBUG - 2020-02-25 16:43:49 --> No URI present. Default controller set.
INFO - 2020-02-25 16:43:49 --> Router Class Initialized
INFO - 2020-02-25 16:43:49 --> Output Class Initialized
INFO - 2020-02-25 16:43:49 --> Security Class Initialized
DEBUG - 2020-02-25 16:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:43:49 --> Input Class Initialized
INFO - 2020-02-25 16:43:49 --> Language Class Initialized
INFO - 2020-02-25 16:43:49 --> Loader Class Initialized
INFO - 2020-02-25 16:43:49 --> Helper loaded: url_helper
INFO - 2020-02-25 16:43:49 --> Helper loaded: string_helper
INFO - 2020-02-25 16:43:49 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:43:50 --> Controller Class Initialized
INFO - 2020-02-25 16:43:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:43:50 --> Pagination Class Initialized
INFO - 2020-02-25 16:43:50 --> Model "M_show" initialized
INFO - 2020-02-25 16:43:50 --> Helper loaded: form_helper
INFO - 2020-02-25 16:43:50 --> Form Validation Class Initialized
INFO - 2020-02-25 16:43:50 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-25 16:43:50 --> Final output sent to browser
DEBUG - 2020-02-25 16:43:50 --> Total execution time: 0.7885
INFO - 2020-02-25 16:43:52 --> Config Class Initialized
INFO - 2020-02-25 16:43:52 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:43:52 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:43:52 --> Utf8 Class Initialized
INFO - 2020-02-25 16:43:52 --> URI Class Initialized
INFO - 2020-02-25 16:43:52 --> Router Class Initialized
INFO - 2020-02-25 16:43:52 --> Output Class Initialized
INFO - 2020-02-25 16:43:52 --> Security Class Initialized
DEBUG - 2020-02-25 16:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:43:52 --> Input Class Initialized
INFO - 2020-02-25 16:43:52 --> Language Class Initialized
INFO - 2020-02-25 16:43:52 --> Loader Class Initialized
INFO - 2020-02-25 16:43:52 --> Helper loaded: url_helper
INFO - 2020-02-25 16:43:52 --> Helper loaded: string_helper
INFO - 2020-02-25 16:43:52 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:43:52 --> Controller Class Initialized
INFO - 2020-02-25 16:43:52 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:43:52 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:43:52 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:43:52 --> Helper loaded: form_helper
INFO - 2020-02-25 16:43:52 --> Form Validation Class Initialized
INFO - 2020-02-25 16:43:52 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:43:52 --> Final output sent to browser
DEBUG - 2020-02-25 16:43:52 --> Total execution time: 0.2969
INFO - 2020-02-25 16:43:52 --> Config Class Initialized
INFO - 2020-02-25 16:43:52 --> Config Class Initialized
INFO - 2020-02-25 16:43:52 --> Config Class Initialized
INFO - 2020-02-25 16:43:52 --> Config Class Initialized
INFO - 2020-02-25 16:43:52 --> Hooks Class Initialized
INFO - 2020-02-25 16:43:52 --> Hooks Class Initialized
INFO - 2020-02-25 16:43:52 --> Config Class Initialized
INFO - 2020-02-25 16:43:52 --> Hooks Class Initialized
INFO - 2020-02-25 16:43:52 --> Hooks Class Initialized
INFO - 2020-02-25 16:43:52 --> Config Class Initialized
INFO - 2020-02-25 16:43:52 --> Hooks Class Initialized
INFO - 2020-02-25 16:43:52 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:43:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:43:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:43:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:43:52 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:43:52 --> Utf8 Class Initialized
INFO - 2020-02-25 16:43:52 --> Utf8 Class Initialized
INFO - 2020-02-25 16:43:52 --> Utf8 Class Initialized
INFO - 2020-02-25 16:43:52 --> Utf8 Class Initialized
DEBUG - 2020-02-25 16:43:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:43:52 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:43:52 --> Utf8 Class Initialized
INFO - 2020-02-25 16:43:52 --> Utf8 Class Initialized
INFO - 2020-02-25 16:43:52 --> URI Class Initialized
INFO - 2020-02-25 16:43:52 --> URI Class Initialized
INFO - 2020-02-25 16:43:52 --> URI Class Initialized
INFO - 2020-02-25 16:43:52 --> URI Class Initialized
INFO - 2020-02-25 16:43:52 --> URI Class Initialized
INFO - 2020-02-25 16:43:52 --> URI Class Initialized
INFO - 2020-02-25 16:43:52 --> Router Class Initialized
INFO - 2020-02-25 16:43:52 --> Router Class Initialized
INFO - 2020-02-25 16:43:52 --> Router Class Initialized
INFO - 2020-02-25 16:43:52 --> Router Class Initialized
INFO - 2020-02-25 16:43:52 --> Router Class Initialized
INFO - 2020-02-25 16:43:52 --> Router Class Initialized
INFO - 2020-02-25 16:43:52 --> Output Class Initialized
INFO - 2020-02-25 16:43:52 --> Output Class Initialized
INFO - 2020-02-25 16:43:52 --> Output Class Initialized
INFO - 2020-02-25 16:43:52 --> Output Class Initialized
INFO - 2020-02-25 16:43:52 --> Security Class Initialized
INFO - 2020-02-25 16:43:52 --> Security Class Initialized
INFO - 2020-02-25 16:43:52 --> Security Class Initialized
INFO - 2020-02-25 16:43:52 --> Security Class Initialized
INFO - 2020-02-25 16:43:52 --> Output Class Initialized
INFO - 2020-02-25 16:43:52 --> Output Class Initialized
DEBUG - 2020-02-25 16:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:43:52 --> Security Class Initialized
INFO - 2020-02-25 16:43:52 --> Security Class Initialized
INFO - 2020-02-25 16:43:52 --> Input Class Initialized
INFO - 2020-02-25 16:43:52 --> Input Class Initialized
INFO - 2020-02-25 16:43:52 --> Input Class Initialized
INFO - 2020-02-25 16:43:52 --> Input Class Initialized
DEBUG - 2020-02-25 16:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:43:52 --> Input Class Initialized
INFO - 2020-02-25 16:43:52 --> Input Class Initialized
INFO - 2020-02-25 16:43:52 --> Language Class Initialized
INFO - 2020-02-25 16:43:52 --> Language Class Initialized
INFO - 2020-02-25 16:43:52 --> Language Class Initialized
INFO - 2020-02-25 16:43:52 --> Language Class Initialized
INFO - 2020-02-25 16:43:52 --> Language Class Initialized
INFO - 2020-02-25 16:43:52 --> Language Class Initialized
INFO - 2020-02-25 16:43:52 --> Loader Class Initialized
INFO - 2020-02-25 16:43:52 --> Loader Class Initialized
INFO - 2020-02-25 16:43:52 --> Helper loaded: url_helper
INFO - 2020-02-25 16:43:52 --> Helper loaded: url_helper
ERROR - 2020-02-25 16:43:52 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-25 16:43:52 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-25 16:43:52 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-25 16:43:52 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-25 16:43:52 --> Helper loaded: string_helper
INFO - 2020-02-25 16:43:52 --> Helper loaded: string_helper
INFO - 2020-02-25 16:43:52 --> Database Driver Class Initialized
INFO - 2020-02-25 16:43:52 --> Config Class Initialized
INFO - 2020-02-25 16:43:52 --> Config Class Initialized
INFO - 2020-02-25 16:43:52 --> Database Driver Class Initialized
INFO - 2020-02-25 16:43:52 --> Config Class Initialized
INFO - 2020-02-25 16:43:52 --> Config Class Initialized
INFO - 2020-02-25 16:43:52 --> Hooks Class Initialized
INFO - 2020-02-25 16:43:52 --> Hooks Class Initialized
INFO - 2020-02-25 16:43:52 --> Hooks Class Initialized
INFO - 2020-02-25 16:43:52 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-25 16:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:43:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-25 16:43:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:43:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:43:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:43:52 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:43:52 --> Utf8 Class Initialized
INFO - 2020-02-25 16:43:52 --> Utf8 Class Initialized
INFO - 2020-02-25 16:43:52 --> Utf8 Class Initialized
INFO - 2020-02-25 16:43:52 --> Controller Class Initialized
INFO - 2020-02-25 16:43:52 --> Utf8 Class Initialized
INFO - 2020-02-25 16:43:52 --> URI Class Initialized
INFO - 2020-02-25 16:43:52 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:43:52 --> URI Class Initialized
INFO - 2020-02-25 16:43:52 --> URI Class Initialized
INFO - 2020-02-25 16:43:52 --> URI Class Initialized
INFO - 2020-02-25 16:43:52 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:43:52 --> Router Class Initialized
INFO - 2020-02-25 16:43:52 --> Router Class Initialized
INFO - 2020-02-25 16:43:52 --> Router Class Initialized
INFO - 2020-02-25 16:43:52 --> Router Class Initialized
INFO - 2020-02-25 16:43:52 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:43:52 --> Output Class Initialized
INFO - 2020-02-25 16:43:52 --> Output Class Initialized
INFO - 2020-02-25 16:43:52 --> Output Class Initialized
INFO - 2020-02-25 16:43:52 --> Output Class Initialized
INFO - 2020-02-25 16:43:52 --> Security Class Initialized
INFO - 2020-02-25 16:43:52 --> Security Class Initialized
INFO - 2020-02-25 16:43:52 --> Security Class Initialized
INFO - 2020-02-25 16:43:52 --> Security Class Initialized
INFO - 2020-02-25 16:43:52 --> Helper loaded: form_helper
INFO - 2020-02-25 16:43:52 --> Form Validation Class Initialized
DEBUG - 2020-02-25 16:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:43:52 --> Input Class Initialized
INFO - 2020-02-25 16:43:52 --> Input Class Initialized
INFO - 2020-02-25 16:43:52 --> Input Class Initialized
INFO - 2020-02-25 16:43:52 --> Input Class Initialized
ERROR - 2020-02-25 16:43:52 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-25 16:43:52 --> Language Class Initialized
INFO - 2020-02-25 16:43:52 --> Language Class Initialized
INFO - 2020-02-25 16:43:52 --> Language Class Initialized
INFO - 2020-02-25 16:43:52 --> Language Class Initialized
ERROR - 2020-02-25 16:43:52 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-25 16:43:52 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-25 16:43:52 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-25 16:43:52 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-25 16:43:52 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 16:43:52 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:43:52 --> Config Class Initialized
INFO - 2020-02-25 16:43:52 --> Config Class Initialized
INFO - 2020-02-25 16:43:52 --> Config Class Initialized
INFO - 2020-02-25 16:43:52 --> Config Class Initialized
INFO - 2020-02-25 16:43:52 --> Hooks Class Initialized
INFO - 2020-02-25 16:43:52 --> Hooks Class Initialized
INFO - 2020-02-25 16:43:52 --> Hooks Class Initialized
INFO - 2020-02-25 16:43:52 --> Hooks Class Initialized
INFO - 2020-02-25 16:43:52 --> Final output sent to browser
DEBUG - 2020-02-25 16:43:52 --> Total execution time: 0.2807
DEBUG - 2020-02-25 16:43:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:43:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:43:52 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:43:52 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:43:52 --> Utf8 Class Initialized
INFO - 2020-02-25 16:43:52 --> Utf8 Class Initialized
INFO - 2020-02-25 16:43:52 --> Utf8 Class Initialized
INFO - 2020-02-25 16:43:52 --> Utf8 Class Initialized
INFO - 2020-02-25 16:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:43:52 --> Controller Class Initialized
INFO - 2020-02-25 16:43:52 --> URI Class Initialized
INFO - 2020-02-25 16:43:52 --> URI Class Initialized
INFO - 2020-02-25 16:43:52 --> URI Class Initialized
INFO - 2020-02-25 16:43:52 --> URI Class Initialized
INFO - 2020-02-25 16:43:52 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:43:52 --> Router Class Initialized
INFO - 2020-02-25 16:43:52 --> Router Class Initialized
INFO - 2020-02-25 16:43:52 --> Router Class Initialized
INFO - 2020-02-25 16:43:52 --> Router Class Initialized
INFO - 2020-02-25 16:43:52 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:43:52 --> Output Class Initialized
INFO - 2020-02-25 16:43:52 --> Output Class Initialized
INFO - 2020-02-25 16:43:52 --> Output Class Initialized
INFO - 2020-02-25 16:43:52 --> Output Class Initialized
INFO - 2020-02-25 16:43:52 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:43:52 --> Security Class Initialized
INFO - 2020-02-25 16:43:52 --> Security Class Initialized
INFO - 2020-02-25 16:43:52 --> Security Class Initialized
INFO - 2020-02-25 16:43:52 --> Security Class Initialized
DEBUG - 2020-02-25 16:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:43:52 --> Helper loaded: form_helper
INFO - 2020-02-25 16:43:52 --> Input Class Initialized
INFO - 2020-02-25 16:43:52 --> Form Validation Class Initialized
INFO - 2020-02-25 16:43:52 --> Input Class Initialized
INFO - 2020-02-25 16:43:52 --> Input Class Initialized
INFO - 2020-02-25 16:43:52 --> Input Class Initialized
INFO - 2020-02-25 16:43:52 --> Language Class Initialized
INFO - 2020-02-25 16:43:52 --> Language Class Initialized
INFO - 2020-02-25 16:43:52 --> Language Class Initialized
INFO - 2020-02-25 16:43:52 --> Language Class Initialized
ERROR - 2020-02-25 16:43:52 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 16:43:52 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-25 16:43:52 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-25 16:43:52 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-25 16:43:52 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-25 16:43:52 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-25 16:43:52 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:43:52 --> Final output sent to browser
INFO - 2020-02-25 16:43:52 --> Config Class Initialized
INFO - 2020-02-25 16:43:52 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:43:52 --> Total execution time: 0.3856
DEBUG - 2020-02-25 16:43:52 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:43:52 --> Utf8 Class Initialized
INFO - 2020-02-25 16:43:52 --> URI Class Initialized
INFO - 2020-02-25 16:43:52 --> Router Class Initialized
INFO - 2020-02-25 16:43:52 --> Output Class Initialized
INFO - 2020-02-25 16:43:52 --> Security Class Initialized
DEBUG - 2020-02-25 16:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:43:52 --> Input Class Initialized
INFO - 2020-02-25 16:43:52 --> Language Class Initialized
ERROR - 2020-02-25 16:43:52 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-25 16:43:53 --> Config Class Initialized
INFO - 2020-02-25 16:43:53 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:43:53 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:43:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:43:53 --> URI Class Initialized
INFO - 2020-02-25 16:43:53 --> Router Class Initialized
INFO - 2020-02-25 16:43:53 --> Output Class Initialized
INFO - 2020-02-25 16:43:53 --> Security Class Initialized
DEBUG - 2020-02-25 16:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:43:53 --> Input Class Initialized
INFO - 2020-02-25 16:43:53 --> Language Class Initialized
ERROR - 2020-02-25 16:43:53 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-25 16:43:53 --> Config Class Initialized
INFO - 2020-02-25 16:43:53 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:43:53 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:43:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:43:53 --> URI Class Initialized
INFO - 2020-02-25 16:43:53 --> Router Class Initialized
INFO - 2020-02-25 16:43:53 --> Output Class Initialized
INFO - 2020-02-25 16:43:53 --> Security Class Initialized
DEBUG - 2020-02-25 16:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:43:53 --> Input Class Initialized
INFO - 2020-02-25 16:43:53 --> Language Class Initialized
ERROR - 2020-02-25 16:43:53 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 16:43:53 --> Config Class Initialized
INFO - 2020-02-25 16:43:53 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:43:53 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:43:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:43:53 --> URI Class Initialized
INFO - 2020-02-25 16:43:53 --> Router Class Initialized
INFO - 2020-02-25 16:43:53 --> Output Class Initialized
INFO - 2020-02-25 16:43:53 --> Security Class Initialized
DEBUG - 2020-02-25 16:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:43:53 --> Input Class Initialized
INFO - 2020-02-25 16:43:53 --> Language Class Initialized
ERROR - 2020-02-25 16:43:53 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 16:43:53 --> Config Class Initialized
INFO - 2020-02-25 16:43:53 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:43:53 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:43:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:43:53 --> URI Class Initialized
INFO - 2020-02-25 16:43:53 --> Router Class Initialized
INFO - 2020-02-25 16:43:53 --> Output Class Initialized
INFO - 2020-02-25 16:43:53 --> Security Class Initialized
DEBUG - 2020-02-25 16:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:43:53 --> Input Class Initialized
INFO - 2020-02-25 16:43:53 --> Language Class Initialized
ERROR - 2020-02-25 16:43:53 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-25 16:43:53 --> Config Class Initialized
INFO - 2020-02-25 16:43:53 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:43:53 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:43:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:43:53 --> URI Class Initialized
INFO - 2020-02-25 16:43:53 --> Router Class Initialized
INFO - 2020-02-25 16:43:53 --> Output Class Initialized
INFO - 2020-02-25 16:43:53 --> Security Class Initialized
DEBUG - 2020-02-25 16:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:43:53 --> Input Class Initialized
INFO - 2020-02-25 16:43:53 --> Language Class Initialized
ERROR - 2020-02-25 16:43:53 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-25 16:43:53 --> Config Class Initialized
INFO - 2020-02-25 16:43:53 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:43:53 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:43:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:43:53 --> URI Class Initialized
INFO - 2020-02-25 16:43:53 --> Router Class Initialized
INFO - 2020-02-25 16:43:53 --> Output Class Initialized
INFO - 2020-02-25 16:43:53 --> Security Class Initialized
DEBUG - 2020-02-25 16:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:43:53 --> Input Class Initialized
INFO - 2020-02-25 16:43:53 --> Language Class Initialized
ERROR - 2020-02-25 16:43:53 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-25 16:43:53 --> Config Class Initialized
INFO - 2020-02-25 16:43:53 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:43:53 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:43:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:43:53 --> URI Class Initialized
INFO - 2020-02-25 16:43:53 --> Router Class Initialized
INFO - 2020-02-25 16:43:53 --> Output Class Initialized
INFO - 2020-02-25 16:43:53 --> Security Class Initialized
DEBUG - 2020-02-25 16:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:43:53 --> Input Class Initialized
INFO - 2020-02-25 16:43:53 --> Language Class Initialized
ERROR - 2020-02-25 16:43:53 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-25 16:44:04 --> Config Class Initialized
INFO - 2020-02-25 16:44:04 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:44:04 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:44:04 --> Utf8 Class Initialized
INFO - 2020-02-25 16:44:04 --> URI Class Initialized
INFO - 2020-02-25 16:44:04 --> Router Class Initialized
INFO - 2020-02-25 16:44:04 --> Output Class Initialized
INFO - 2020-02-25 16:44:04 --> Security Class Initialized
DEBUG - 2020-02-25 16:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:44:04 --> Input Class Initialized
INFO - 2020-02-25 16:44:04 --> Language Class Initialized
INFO - 2020-02-25 16:44:04 --> Loader Class Initialized
INFO - 2020-02-25 16:44:04 --> Helper loaded: url_helper
INFO - 2020-02-25 16:44:04 --> Helper loaded: string_helper
INFO - 2020-02-25 16:44:04 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:44:05 --> Controller Class Initialized
INFO - 2020-02-25 16:44:05 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:44:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:44:05 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:44:05 --> Helper loaded: form_helper
INFO - 2020-02-25 16:44:05 --> Form Validation Class Initialized
ERROR - 2020-02-25 22:44:05 --> Query error: Column 'tanggal_penukaran' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `tanggal_pesan`, `tanggal_exp`, `tanggal_approve`, `kode_unik`, `tanggal_penukaran`, `id_pengunjung`) VALUES ('33', '100000', '1', '1', '20-02-25 10:44:05', '2020-02-26 10:44:05', NULL, 'PM001', NULL, '136')
INFO - 2020-02-25 22:44:05 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-25 16:44:29 --> Config Class Initialized
INFO - 2020-02-25 16:44:29 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:44:29 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:44:29 --> Utf8 Class Initialized
INFO - 2020-02-25 16:44:29 --> URI Class Initialized
INFO - 2020-02-25 16:44:29 --> Router Class Initialized
INFO - 2020-02-25 16:44:29 --> Output Class Initialized
INFO - 2020-02-25 16:44:29 --> Security Class Initialized
DEBUG - 2020-02-25 16:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:44:29 --> Input Class Initialized
INFO - 2020-02-25 16:44:29 --> Language Class Initialized
INFO - 2020-02-25 16:44:29 --> Loader Class Initialized
INFO - 2020-02-25 16:44:29 --> Helper loaded: url_helper
INFO - 2020-02-25 16:44:29 --> Helper loaded: string_helper
INFO - 2020-02-25 16:44:29 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:44:29 --> Controller Class Initialized
INFO - 2020-02-25 16:44:29 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:44:29 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:44:29 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:44:29 --> Helper loaded: form_helper
INFO - 2020-02-25 16:44:29 --> Form Validation Class Initialized
ERROR - 2020-02-25 16:44:29 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 70
ERROR - 2020-02-25 16:44:29 --> Severity: Notice --> Undefined index: no_identitas C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 71
ERROR - 2020-02-25 16:44:29 --> Severity: Notice --> Undefined index: no_hp C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 72
ERROR - 2020-02-25 16:44:29 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 73
ERROR - 2020-02-25 16:44:29 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 81
ERROR - 2020-02-25 16:44:29 --> Severity: Notice --> Undefined index: no_identitas C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 82
ERROR - 2020-02-25 16:44:29 --> Severity: Notice --> Undefined index: no_hp C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 83
ERROR - 2020-02-25 16:44:29 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 84
ERROR - 2020-02-25 16:44:29 --> Query error: Column 'nama' cannot be null - Invalid query: INSERT INTO `pengunjung` (`nama`, `no_identitas`, `no_hp`, `email`) VALUES (NULL, NULL, NULL, NULL)
INFO - 2020-02-25 16:44:29 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-02-25 16:44:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\roadshow\system\core\Exceptions.php:271) C:\xampp\htdocs\roadshow\system\core\Common.php 570
INFO - 2020-02-25 16:44:31 --> Config Class Initialized
INFO - 2020-02-25 16:44:31 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:44:31 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:44:31 --> Utf8 Class Initialized
INFO - 2020-02-25 16:44:31 --> URI Class Initialized
INFO - 2020-02-25 16:44:31 --> Router Class Initialized
INFO - 2020-02-25 16:44:31 --> Output Class Initialized
INFO - 2020-02-25 16:44:31 --> Security Class Initialized
DEBUG - 2020-02-25 16:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:44:31 --> Input Class Initialized
INFO - 2020-02-25 16:44:31 --> Language Class Initialized
INFO - 2020-02-25 16:44:31 --> Loader Class Initialized
INFO - 2020-02-25 16:44:31 --> Helper loaded: url_helper
INFO - 2020-02-25 16:44:31 --> Helper loaded: string_helper
INFO - 2020-02-25 16:44:31 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:44:31 --> Controller Class Initialized
INFO - 2020-02-25 16:44:31 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:44:31 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:44:31 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:44:31 --> Helper loaded: form_helper
INFO - 2020-02-25 16:44:31 --> Form Validation Class Initialized
INFO - 2020-02-25 16:44:31 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:44:31 --> Final output sent to browser
DEBUG - 2020-02-25 16:44:31 --> Total execution time: 0.2417
INFO - 2020-02-25 16:44:31 --> Config Class Initialized
INFO - 2020-02-25 16:44:31 --> Config Class Initialized
INFO - 2020-02-25 16:44:31 --> Hooks Class Initialized
INFO - 2020-02-25 16:44:31 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:44:31 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:44:31 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:44:31 --> Utf8 Class Initialized
INFO - 2020-02-25 16:44:31 --> Utf8 Class Initialized
INFO - 2020-02-25 16:44:31 --> URI Class Initialized
INFO - 2020-02-25 16:44:31 --> URI Class Initialized
INFO - 2020-02-25 16:44:31 --> Router Class Initialized
INFO - 2020-02-25 16:44:31 --> Router Class Initialized
INFO - 2020-02-25 16:44:31 --> Output Class Initialized
INFO - 2020-02-25 16:44:31 --> Output Class Initialized
INFO - 2020-02-25 16:44:31 --> Security Class Initialized
INFO - 2020-02-25 16:44:31 --> Security Class Initialized
DEBUG - 2020-02-25 16:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:44:31 --> Input Class Initialized
INFO - 2020-02-25 16:44:31 --> Input Class Initialized
INFO - 2020-02-25 16:44:31 --> Language Class Initialized
INFO - 2020-02-25 16:44:31 --> Language Class Initialized
INFO - 2020-02-25 16:44:31 --> Loader Class Initialized
INFO - 2020-02-25 16:44:31 --> Loader Class Initialized
INFO - 2020-02-25 16:44:31 --> Helper loaded: url_helper
INFO - 2020-02-25 16:44:31 --> Helper loaded: url_helper
INFO - 2020-02-25 16:44:31 --> Helper loaded: string_helper
INFO - 2020-02-25 16:44:31 --> Helper loaded: string_helper
INFO - 2020-02-25 16:44:31 --> Database Driver Class Initialized
INFO - 2020-02-25 16:44:31 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-25 16:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:44:31 --> Controller Class Initialized
INFO - 2020-02-25 16:44:31 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:44:31 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:44:31 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:44:31 --> Helper loaded: form_helper
INFO - 2020-02-25 16:44:31 --> Form Validation Class Initialized
ERROR - 2020-02-25 16:44:31 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 16:44:31 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 16:44:31 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:44:31 --> Final output sent to browser
DEBUG - 2020-02-25 16:44:31 --> Total execution time: 0.2633
INFO - 2020-02-25 16:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:44:31 --> Controller Class Initialized
INFO - 2020-02-25 16:44:31 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:44:31 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:44:31 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:44:31 --> Helper loaded: form_helper
INFO - 2020-02-25 16:44:31 --> Form Validation Class Initialized
ERROR - 2020-02-25 16:44:31 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 16:44:31 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 16:44:31 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:44:31 --> Final output sent to browser
DEBUG - 2020-02-25 16:44:32 --> Total execution time: 0.3700
INFO - 2020-02-25 16:44:33 --> Config Class Initialized
INFO - 2020-02-25 16:44:33 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:44:34 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:44:34 --> Utf8 Class Initialized
INFO - 2020-02-25 16:44:34 --> URI Class Initialized
INFO - 2020-02-25 16:44:34 --> Router Class Initialized
INFO - 2020-02-25 16:44:34 --> Output Class Initialized
INFO - 2020-02-25 16:44:34 --> Security Class Initialized
DEBUG - 2020-02-25 16:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:44:34 --> Input Class Initialized
INFO - 2020-02-25 16:44:34 --> Language Class Initialized
INFO - 2020-02-25 16:44:34 --> Loader Class Initialized
INFO - 2020-02-25 16:44:34 --> Helper loaded: url_helper
INFO - 2020-02-25 16:44:34 --> Helper loaded: string_helper
INFO - 2020-02-25 16:44:34 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:44:34 --> Controller Class Initialized
INFO - 2020-02-25 16:44:34 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:44:34 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:44:34 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:44:34 --> Helper loaded: form_helper
INFO - 2020-02-25 16:44:34 --> Form Validation Class Initialized
INFO - 2020-02-25 16:44:34 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:44:34 --> Final output sent to browser
DEBUG - 2020-02-25 16:44:34 --> Total execution time: 0.2394
INFO - 2020-02-25 16:44:34 --> Config Class Initialized
INFO - 2020-02-25 16:44:34 --> Config Class Initialized
INFO - 2020-02-25 16:44:34 --> Config Class Initialized
INFO - 2020-02-25 16:44:34 --> Config Class Initialized
INFO - 2020-02-25 16:44:34 --> Config Class Initialized
INFO - 2020-02-25 16:44:34 --> Config Class Initialized
INFO - 2020-02-25 16:44:34 --> Hooks Class Initialized
INFO - 2020-02-25 16:44:34 --> Hooks Class Initialized
INFO - 2020-02-25 16:44:34 --> Hooks Class Initialized
INFO - 2020-02-25 16:44:34 --> Hooks Class Initialized
INFO - 2020-02-25 16:44:34 --> Hooks Class Initialized
INFO - 2020-02-25 16:44:34 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:44:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:44:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:44:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:44:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:44:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:44:34 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:44:34 --> Utf8 Class Initialized
INFO - 2020-02-25 16:44:34 --> Utf8 Class Initialized
INFO - 2020-02-25 16:44:34 --> Utf8 Class Initialized
INFO - 2020-02-25 16:44:34 --> Utf8 Class Initialized
INFO - 2020-02-25 16:44:34 --> Utf8 Class Initialized
INFO - 2020-02-25 16:44:34 --> Utf8 Class Initialized
INFO - 2020-02-25 16:44:34 --> URI Class Initialized
INFO - 2020-02-25 16:44:34 --> URI Class Initialized
INFO - 2020-02-25 16:44:34 --> URI Class Initialized
INFO - 2020-02-25 16:44:34 --> URI Class Initialized
INFO - 2020-02-25 16:44:34 --> URI Class Initialized
INFO - 2020-02-25 16:44:34 --> URI Class Initialized
INFO - 2020-02-25 16:44:34 --> Router Class Initialized
INFO - 2020-02-25 16:44:34 --> Router Class Initialized
INFO - 2020-02-25 16:44:34 --> Router Class Initialized
INFO - 2020-02-25 16:44:34 --> Router Class Initialized
INFO - 2020-02-25 16:44:34 --> Router Class Initialized
INFO - 2020-02-25 16:44:34 --> Router Class Initialized
INFO - 2020-02-25 16:44:34 --> Output Class Initialized
INFO - 2020-02-25 16:44:34 --> Output Class Initialized
INFO - 2020-02-25 16:44:34 --> Output Class Initialized
INFO - 2020-02-25 16:44:34 --> Output Class Initialized
INFO - 2020-02-25 16:44:34 --> Output Class Initialized
INFO - 2020-02-25 16:44:34 --> Output Class Initialized
INFO - 2020-02-25 16:44:34 --> Security Class Initialized
INFO - 2020-02-25 16:44:34 --> Security Class Initialized
INFO - 2020-02-25 16:44:34 --> Security Class Initialized
INFO - 2020-02-25 16:44:34 --> Security Class Initialized
INFO - 2020-02-25 16:44:34 --> Security Class Initialized
INFO - 2020-02-25 16:44:34 --> Security Class Initialized
DEBUG - 2020-02-25 16:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:44:34 --> Input Class Initialized
INFO - 2020-02-25 16:44:34 --> Input Class Initialized
INFO - 2020-02-25 16:44:34 --> Input Class Initialized
INFO - 2020-02-25 16:44:34 --> Input Class Initialized
INFO - 2020-02-25 16:44:34 --> Input Class Initialized
INFO - 2020-02-25 16:44:34 --> Input Class Initialized
INFO - 2020-02-25 16:44:34 --> Language Class Initialized
INFO - 2020-02-25 16:44:34 --> Language Class Initialized
INFO - 2020-02-25 16:44:34 --> Language Class Initialized
INFO - 2020-02-25 16:44:34 --> Language Class Initialized
INFO - 2020-02-25 16:44:34 --> Language Class Initialized
INFO - 2020-02-25 16:44:34 --> Language Class Initialized
ERROR - 2020-02-25 16:44:34 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-25 16:44:34 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-25 16:44:34 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-25 16:44:34 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-25 16:44:34 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-25 16:44:34 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-25 16:44:34 --> Config Class Initialized
INFO - 2020-02-25 16:44:34 --> Config Class Initialized
INFO - 2020-02-25 16:44:34 --> Config Class Initialized
INFO - 2020-02-25 16:44:34 --> Config Class Initialized
INFO - 2020-02-25 16:44:34 --> Config Class Initialized
INFO - 2020-02-25 16:44:34 --> Config Class Initialized
INFO - 2020-02-25 16:44:34 --> Hooks Class Initialized
INFO - 2020-02-25 16:44:34 --> Hooks Class Initialized
INFO - 2020-02-25 16:44:34 --> Hooks Class Initialized
INFO - 2020-02-25 16:44:34 --> Hooks Class Initialized
INFO - 2020-02-25 16:44:34 --> Hooks Class Initialized
INFO - 2020-02-25 16:44:34 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:44:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:44:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:44:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:44:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:44:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:44:34 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:44:34 --> Utf8 Class Initialized
INFO - 2020-02-25 16:44:34 --> Utf8 Class Initialized
INFO - 2020-02-25 16:44:34 --> Utf8 Class Initialized
INFO - 2020-02-25 16:44:34 --> Utf8 Class Initialized
INFO - 2020-02-25 16:44:34 --> Utf8 Class Initialized
INFO - 2020-02-25 16:44:34 --> Utf8 Class Initialized
INFO - 2020-02-25 16:44:34 --> URI Class Initialized
INFO - 2020-02-25 16:44:34 --> URI Class Initialized
INFO - 2020-02-25 16:44:34 --> URI Class Initialized
INFO - 2020-02-25 16:44:34 --> URI Class Initialized
INFO - 2020-02-25 16:44:34 --> URI Class Initialized
INFO - 2020-02-25 16:44:34 --> URI Class Initialized
INFO - 2020-02-25 16:44:34 --> Router Class Initialized
INFO - 2020-02-25 16:44:34 --> Router Class Initialized
INFO - 2020-02-25 16:44:34 --> Router Class Initialized
INFO - 2020-02-25 16:44:34 --> Router Class Initialized
INFO - 2020-02-25 16:44:34 --> Router Class Initialized
INFO - 2020-02-25 16:44:34 --> Router Class Initialized
INFO - 2020-02-25 16:44:34 --> Output Class Initialized
INFO - 2020-02-25 16:44:34 --> Output Class Initialized
INFO - 2020-02-25 16:44:34 --> Output Class Initialized
INFO - 2020-02-25 16:44:34 --> Output Class Initialized
INFO - 2020-02-25 16:44:34 --> Output Class Initialized
INFO - 2020-02-25 16:44:34 --> Output Class Initialized
INFO - 2020-02-25 16:44:34 --> Security Class Initialized
INFO - 2020-02-25 16:44:34 --> Security Class Initialized
INFO - 2020-02-25 16:44:34 --> Security Class Initialized
INFO - 2020-02-25 16:44:34 --> Security Class Initialized
INFO - 2020-02-25 16:44:34 --> Security Class Initialized
INFO - 2020-02-25 16:44:34 --> Security Class Initialized
DEBUG - 2020-02-25 16:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:44:34 --> Input Class Initialized
INFO - 2020-02-25 16:44:34 --> Input Class Initialized
INFO - 2020-02-25 16:44:34 --> Input Class Initialized
INFO - 2020-02-25 16:44:34 --> Input Class Initialized
INFO - 2020-02-25 16:44:34 --> Input Class Initialized
INFO - 2020-02-25 16:44:34 --> Input Class Initialized
INFO - 2020-02-25 16:44:34 --> Language Class Initialized
INFO - 2020-02-25 16:44:34 --> Language Class Initialized
INFO - 2020-02-25 16:44:34 --> Language Class Initialized
INFO - 2020-02-25 16:44:34 --> Language Class Initialized
INFO - 2020-02-25 16:44:34 --> Language Class Initialized
INFO - 2020-02-25 16:44:34 --> Language Class Initialized
ERROR - 2020-02-25 16:44:34 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-25 16:44:34 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-25 16:44:34 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-25 16:44:34 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-25 16:44:34 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 16:44:34 --> Loader Class Initialized
INFO - 2020-02-25 16:44:34 --> Helper loaded: url_helper
INFO - 2020-02-25 16:44:34 --> Config Class Initialized
INFO - 2020-02-25 16:44:34 --> Hooks Class Initialized
INFO - 2020-02-25 16:44:34 --> Helper loaded: string_helper
DEBUG - 2020-02-25 16:44:34 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:44:34 --> Database Driver Class Initialized
INFO - 2020-02-25 16:44:34 --> Utf8 Class Initialized
DEBUG - 2020-02-25 16:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:44:34 --> URI Class Initialized
INFO - 2020-02-25 16:44:34 --> Controller Class Initialized
INFO - 2020-02-25 16:44:34 --> Router Class Initialized
INFO - 2020-02-25 16:44:34 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:44:34 --> Output Class Initialized
INFO - 2020-02-25 16:44:34 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:44:34 --> Security Class Initialized
INFO - 2020-02-25 16:44:34 --> Model "M_pesan" initialized
DEBUG - 2020-02-25 16:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:44:34 --> Input Class Initialized
INFO - 2020-02-25 16:44:34 --> Helper loaded: form_helper
INFO - 2020-02-25 16:44:34 --> Form Validation Class Initialized
INFO - 2020-02-25 16:44:34 --> Language Class Initialized
INFO - 2020-02-25 16:44:34 --> Loader Class Initialized
ERROR - 2020-02-25 16:44:34 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 16:44:34 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 16:44:34 --> Helper loaded: url_helper
INFO - 2020-02-25 16:44:34 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:44:34 --> Helper loaded: string_helper
INFO - 2020-02-25 16:44:34 --> Config Class Initialized
INFO - 2020-02-25 16:44:34 --> Hooks Class Initialized
INFO - 2020-02-25 16:44:34 --> Final output sent to browser
INFO - 2020-02-25 16:44:34 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:44:34 --> Total execution time: 0.2899
DEBUG - 2020-02-25 16:44:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:44:34 --> Utf8 Class Initialized
INFO - 2020-02-25 16:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:44:34 --> Controller Class Initialized
INFO - 2020-02-25 16:44:34 --> URI Class Initialized
INFO - 2020-02-25 16:44:34 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:44:34 --> Router Class Initialized
INFO - 2020-02-25 16:44:34 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:44:34 --> Output Class Initialized
INFO - 2020-02-25 16:44:34 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:44:34 --> Security Class Initialized
DEBUG - 2020-02-25 16:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:44:34 --> Helper loaded: form_helper
INFO - 2020-02-25 16:44:34 --> Input Class Initialized
INFO - 2020-02-25 16:44:34 --> Form Validation Class Initialized
INFO - 2020-02-25 16:44:34 --> Language Class Initialized
ERROR - 2020-02-25 16:44:34 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 16:44:34 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-25 16:44:34 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-25 16:44:34 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:44:34 --> Final output sent to browser
DEBUG - 2020-02-25 16:44:34 --> Total execution time: 0.2736
INFO - 2020-02-25 16:44:35 --> Config Class Initialized
INFO - 2020-02-25 16:44:35 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:44:35 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:44:35 --> Utf8 Class Initialized
INFO - 2020-02-25 16:44:35 --> URI Class Initialized
INFO - 2020-02-25 16:44:35 --> Router Class Initialized
INFO - 2020-02-25 16:44:35 --> Output Class Initialized
INFO - 2020-02-25 16:44:35 --> Security Class Initialized
DEBUG - 2020-02-25 16:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:44:35 --> Input Class Initialized
INFO - 2020-02-25 16:44:35 --> Language Class Initialized
ERROR - 2020-02-25 16:44:35 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-25 16:44:35 --> Config Class Initialized
INFO - 2020-02-25 16:44:35 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:44:35 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:44:35 --> Utf8 Class Initialized
INFO - 2020-02-25 16:44:35 --> URI Class Initialized
INFO - 2020-02-25 16:44:35 --> Router Class Initialized
INFO - 2020-02-25 16:44:35 --> Output Class Initialized
INFO - 2020-02-25 16:44:35 --> Security Class Initialized
DEBUG - 2020-02-25 16:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:44:35 --> Input Class Initialized
INFO - 2020-02-25 16:44:35 --> Language Class Initialized
ERROR - 2020-02-25 16:44:35 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-25 16:44:35 --> Config Class Initialized
INFO - 2020-02-25 16:44:35 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:44:35 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:44:35 --> Utf8 Class Initialized
INFO - 2020-02-25 16:44:35 --> URI Class Initialized
INFO - 2020-02-25 16:44:35 --> Router Class Initialized
INFO - 2020-02-25 16:44:35 --> Output Class Initialized
INFO - 2020-02-25 16:44:35 --> Security Class Initialized
DEBUG - 2020-02-25 16:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:44:35 --> Input Class Initialized
INFO - 2020-02-25 16:44:35 --> Language Class Initialized
ERROR - 2020-02-25 16:44:35 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-25 16:44:35 --> Config Class Initialized
INFO - 2020-02-25 16:44:35 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:44:35 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:44:35 --> Utf8 Class Initialized
INFO - 2020-02-25 16:44:35 --> URI Class Initialized
INFO - 2020-02-25 16:44:35 --> Router Class Initialized
INFO - 2020-02-25 16:44:35 --> Output Class Initialized
INFO - 2020-02-25 16:44:35 --> Security Class Initialized
DEBUG - 2020-02-25 16:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:44:35 --> Input Class Initialized
INFO - 2020-02-25 16:44:35 --> Language Class Initialized
ERROR - 2020-02-25 16:44:35 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 16:44:35 --> Config Class Initialized
INFO - 2020-02-25 16:44:35 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:44:35 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:44:35 --> Utf8 Class Initialized
INFO - 2020-02-25 16:44:35 --> URI Class Initialized
INFO - 2020-02-25 16:44:35 --> Router Class Initialized
INFO - 2020-02-25 16:44:35 --> Output Class Initialized
INFO - 2020-02-25 16:44:35 --> Security Class Initialized
DEBUG - 2020-02-25 16:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:44:35 --> Input Class Initialized
INFO - 2020-02-25 16:44:35 --> Language Class Initialized
ERROR - 2020-02-25 16:44:35 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 16:44:35 --> Config Class Initialized
INFO - 2020-02-25 16:44:35 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:44:35 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:44:35 --> Utf8 Class Initialized
INFO - 2020-02-25 16:44:35 --> URI Class Initialized
INFO - 2020-02-25 16:44:35 --> Router Class Initialized
INFO - 2020-02-25 16:44:35 --> Output Class Initialized
INFO - 2020-02-25 16:44:35 --> Security Class Initialized
DEBUG - 2020-02-25 16:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:44:35 --> Input Class Initialized
INFO - 2020-02-25 16:44:35 --> Language Class Initialized
ERROR - 2020-02-25 16:44:35 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-25 16:44:35 --> Config Class Initialized
INFO - 2020-02-25 16:44:35 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:44:35 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:44:35 --> Utf8 Class Initialized
INFO - 2020-02-25 16:44:35 --> URI Class Initialized
INFO - 2020-02-25 16:44:35 --> Router Class Initialized
INFO - 2020-02-25 16:44:35 --> Output Class Initialized
INFO - 2020-02-25 16:44:35 --> Security Class Initialized
DEBUG - 2020-02-25 16:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:44:35 --> Input Class Initialized
INFO - 2020-02-25 16:44:35 --> Language Class Initialized
ERROR - 2020-02-25 16:44:35 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-25 16:44:35 --> Config Class Initialized
INFO - 2020-02-25 16:44:35 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:44:35 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:44:35 --> Utf8 Class Initialized
INFO - 2020-02-25 16:44:35 --> URI Class Initialized
INFO - 2020-02-25 16:44:35 --> Router Class Initialized
INFO - 2020-02-25 16:44:35 --> Output Class Initialized
INFO - 2020-02-25 16:44:36 --> Security Class Initialized
DEBUG - 2020-02-25 16:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:44:36 --> Input Class Initialized
INFO - 2020-02-25 16:44:36 --> Language Class Initialized
ERROR - 2020-02-25 16:44:36 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-25 16:44:36 --> Config Class Initialized
INFO - 2020-02-25 16:44:36 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:44:36 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:44:36 --> Utf8 Class Initialized
INFO - 2020-02-25 16:44:36 --> URI Class Initialized
INFO - 2020-02-25 16:44:36 --> Router Class Initialized
INFO - 2020-02-25 16:44:36 --> Output Class Initialized
INFO - 2020-02-25 16:44:36 --> Security Class Initialized
DEBUG - 2020-02-25 16:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:44:36 --> Input Class Initialized
INFO - 2020-02-25 16:44:36 --> Language Class Initialized
ERROR - 2020-02-25 16:44:36 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-25 16:44:50 --> Config Class Initialized
INFO - 2020-02-25 16:44:50 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:44:50 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:44:50 --> Utf8 Class Initialized
INFO - 2020-02-25 16:44:50 --> URI Class Initialized
INFO - 2020-02-25 16:44:50 --> Router Class Initialized
INFO - 2020-02-25 16:44:50 --> Output Class Initialized
INFO - 2020-02-25 16:44:50 --> Security Class Initialized
DEBUG - 2020-02-25 16:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:44:50 --> Input Class Initialized
INFO - 2020-02-25 16:44:50 --> Language Class Initialized
INFO - 2020-02-25 16:44:50 --> Loader Class Initialized
INFO - 2020-02-25 16:44:50 --> Helper loaded: url_helper
INFO - 2020-02-25 16:44:50 --> Helper loaded: string_helper
INFO - 2020-02-25 16:44:50 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:44:50 --> Controller Class Initialized
INFO - 2020-02-25 16:44:50 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:44:50 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:44:50 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:44:50 --> Helper loaded: form_helper
INFO - 2020-02-25 16:44:50 --> Form Validation Class Initialized
ERROR - 2020-02-25 16:44:50 --> Severity: Notice --> Trying to get property 'id_pengunjung' of non-object C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 81
ERROR - 2020-02-25 22:44:50 --> Query error: Column 'id_pengunjung' cannot be null - Invalid query: INSERT INTO `pemesanan` (`id_tiket`, `totalbayar`, `status_pemesanan`, `jumlah_pesanan`, `tanggal_pesan`, `tanggal_exp`, `tanggal_approve`, `kode_unik`, `tanggal_penukaran`, `id_pengunjung`) VALUES ('33', '200000', '1', '2', '20-02-25 10:44:50', '2020-02-26 10:44:50', NULL, 'PM001', NULL, NULL)
INFO - 2020-02-25 22:44:50 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-25 16:45:32 --> Config Class Initialized
INFO - 2020-02-25 16:45:32 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:45:32 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:45:32 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:32 --> URI Class Initialized
INFO - 2020-02-25 16:45:32 --> Router Class Initialized
INFO - 2020-02-25 16:45:32 --> Output Class Initialized
INFO - 2020-02-25 16:45:32 --> Security Class Initialized
DEBUG - 2020-02-25 16:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:45:32 --> Input Class Initialized
INFO - 2020-02-25 16:45:32 --> Language Class Initialized
INFO - 2020-02-25 16:45:32 --> Loader Class Initialized
INFO - 2020-02-25 16:45:32 --> Helper loaded: url_helper
INFO - 2020-02-25 16:45:32 --> Helper loaded: string_helper
INFO - 2020-02-25 16:45:32 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:45:32 --> Controller Class Initialized
INFO - 2020-02-25 16:45:32 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:45:32 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:45:32 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:45:32 --> Helper loaded: form_helper
INFO - 2020-02-25 16:45:32 --> Form Validation Class Initialized
INFO - 2020-02-25 16:45:32 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:45:32 --> Final output sent to browser
DEBUG - 2020-02-25 16:45:32 --> Total execution time: 0.2444
INFO - 2020-02-25 16:45:32 --> Config Class Initialized
INFO - 2020-02-25 16:45:32 --> Config Class Initialized
INFO - 2020-02-25 16:45:32 --> Hooks Class Initialized
INFO - 2020-02-25 16:45:32 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:45:32 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:45:32 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:45:32 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:32 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:32 --> URI Class Initialized
INFO - 2020-02-25 16:45:32 --> URI Class Initialized
INFO - 2020-02-25 16:45:32 --> Router Class Initialized
INFO - 2020-02-25 16:45:32 --> Router Class Initialized
INFO - 2020-02-25 16:45:32 --> Output Class Initialized
INFO - 2020-02-25 16:45:32 --> Output Class Initialized
INFO - 2020-02-25 16:45:32 --> Security Class Initialized
INFO - 2020-02-25 16:45:32 --> Security Class Initialized
DEBUG - 2020-02-25 16:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:45:32 --> Input Class Initialized
INFO - 2020-02-25 16:45:32 --> Input Class Initialized
INFO - 2020-02-25 16:45:32 --> Language Class Initialized
INFO - 2020-02-25 16:45:32 --> Language Class Initialized
INFO - 2020-02-25 16:45:32 --> Loader Class Initialized
INFO - 2020-02-25 16:45:32 --> Loader Class Initialized
INFO - 2020-02-25 16:45:32 --> Helper loaded: url_helper
INFO - 2020-02-25 16:45:32 --> Helper loaded: url_helper
INFO - 2020-02-25 16:45:32 --> Helper loaded: string_helper
INFO - 2020-02-25 16:45:32 --> Helper loaded: string_helper
INFO - 2020-02-25 16:45:32 --> Database Driver Class Initialized
INFO - 2020-02-25 16:45:32 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-25 16:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:45:32 --> Controller Class Initialized
INFO - 2020-02-25 16:45:32 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:45:32 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:45:32 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:45:32 --> Helper loaded: form_helper
INFO - 2020-02-25 16:45:32 --> Form Validation Class Initialized
ERROR - 2020-02-25 16:45:32 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 16:45:32 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 16:45:32 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:45:32 --> Final output sent to browser
DEBUG - 2020-02-25 16:45:32 --> Total execution time: 0.2967
INFO - 2020-02-25 16:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:45:32 --> Controller Class Initialized
INFO - 2020-02-25 16:45:32 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:45:32 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:45:32 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:45:32 --> Helper loaded: form_helper
INFO - 2020-02-25 16:45:32 --> Form Validation Class Initialized
ERROR - 2020-02-25 16:45:32 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 16:45:32 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 16:45:32 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:45:32 --> Final output sent to browser
DEBUG - 2020-02-25 16:45:32 --> Total execution time: 0.4038
INFO - 2020-02-25 16:45:34 --> Config Class Initialized
INFO - 2020-02-25 16:45:34 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:45:34 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:45:34 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:34 --> URI Class Initialized
INFO - 2020-02-25 16:45:34 --> Router Class Initialized
INFO - 2020-02-25 16:45:34 --> Output Class Initialized
INFO - 2020-02-25 16:45:34 --> Security Class Initialized
DEBUG - 2020-02-25 16:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:45:34 --> Input Class Initialized
INFO - 2020-02-25 16:45:34 --> Language Class Initialized
INFO - 2020-02-25 16:45:34 --> Loader Class Initialized
INFO - 2020-02-25 16:45:34 --> Helper loaded: url_helper
INFO - 2020-02-25 16:45:34 --> Helper loaded: string_helper
INFO - 2020-02-25 16:45:34 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:45:34 --> Controller Class Initialized
INFO - 2020-02-25 16:45:34 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:45:34 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:45:34 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:45:34 --> Helper loaded: form_helper
INFO - 2020-02-25 16:45:34 --> Form Validation Class Initialized
INFO - 2020-02-25 16:45:34 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:45:34 --> Final output sent to browser
DEBUG - 2020-02-25 16:45:34 --> Total execution time: 0.2480
INFO - 2020-02-25 16:45:34 --> Config Class Initialized
INFO - 2020-02-25 16:45:34 --> Config Class Initialized
INFO - 2020-02-25 16:45:34 --> Config Class Initialized
INFO - 2020-02-25 16:45:34 --> Config Class Initialized
INFO - 2020-02-25 16:45:34 --> Config Class Initialized
INFO - 2020-02-25 16:45:34 --> Config Class Initialized
INFO - 2020-02-25 16:45:34 --> Hooks Class Initialized
INFO - 2020-02-25 16:45:34 --> Hooks Class Initialized
INFO - 2020-02-25 16:45:34 --> Hooks Class Initialized
INFO - 2020-02-25 16:45:34 --> Hooks Class Initialized
INFO - 2020-02-25 16:45:34 --> Hooks Class Initialized
INFO - 2020-02-25 16:45:34 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:45:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:45:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:45:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:45:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:45:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:45:34 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:45:34 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:34 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:34 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:34 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:34 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:34 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:34 --> URI Class Initialized
INFO - 2020-02-25 16:45:34 --> URI Class Initialized
INFO - 2020-02-25 16:45:34 --> URI Class Initialized
INFO - 2020-02-25 16:45:34 --> URI Class Initialized
INFO - 2020-02-25 16:45:34 --> URI Class Initialized
INFO - 2020-02-25 16:45:34 --> URI Class Initialized
INFO - 2020-02-25 16:45:34 --> Router Class Initialized
INFO - 2020-02-25 16:45:34 --> Router Class Initialized
INFO - 2020-02-25 16:45:34 --> Router Class Initialized
INFO - 2020-02-25 16:45:34 --> Router Class Initialized
INFO - 2020-02-25 16:45:34 --> Router Class Initialized
INFO - 2020-02-25 16:45:34 --> Router Class Initialized
INFO - 2020-02-25 16:45:34 --> Output Class Initialized
INFO - 2020-02-25 16:45:34 --> Output Class Initialized
INFO - 2020-02-25 16:45:34 --> Output Class Initialized
INFO - 2020-02-25 16:45:34 --> Output Class Initialized
INFO - 2020-02-25 16:45:34 --> Output Class Initialized
INFO - 2020-02-25 16:45:34 --> Output Class Initialized
INFO - 2020-02-25 16:45:34 --> Security Class Initialized
INFO - 2020-02-25 16:45:34 --> Security Class Initialized
INFO - 2020-02-25 16:45:34 --> Security Class Initialized
INFO - 2020-02-25 16:45:34 --> Security Class Initialized
INFO - 2020-02-25 16:45:34 --> Security Class Initialized
INFO - 2020-02-25 16:45:34 --> Security Class Initialized
DEBUG - 2020-02-25 16:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:45:34 --> Input Class Initialized
INFO - 2020-02-25 16:45:34 --> Input Class Initialized
INFO - 2020-02-25 16:45:34 --> Input Class Initialized
INFO - 2020-02-25 16:45:34 --> Input Class Initialized
INFO - 2020-02-25 16:45:34 --> Input Class Initialized
INFO - 2020-02-25 16:45:34 --> Input Class Initialized
INFO - 2020-02-25 16:45:34 --> Language Class Initialized
INFO - 2020-02-25 16:45:34 --> Language Class Initialized
INFO - 2020-02-25 16:45:34 --> Language Class Initialized
INFO - 2020-02-25 16:45:34 --> Language Class Initialized
INFO - 2020-02-25 16:45:34 --> Language Class Initialized
INFO - 2020-02-25 16:45:34 --> Language Class Initialized
ERROR - 2020-02-25 16:45:34 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-25 16:45:34 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-25 16:45:34 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-25 16:45:34 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-25 16:45:34 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-25 16:45:34 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 16:45:34 --> Config Class Initialized
INFO - 2020-02-25 16:45:34 --> Config Class Initialized
INFO - 2020-02-25 16:45:34 --> Config Class Initialized
INFO - 2020-02-25 16:45:34 --> Config Class Initialized
INFO - 2020-02-25 16:45:34 --> Config Class Initialized
INFO - 2020-02-25 16:45:34 --> Config Class Initialized
INFO - 2020-02-25 16:45:34 --> Hooks Class Initialized
INFO - 2020-02-25 16:45:34 --> Hooks Class Initialized
INFO - 2020-02-25 16:45:34 --> Hooks Class Initialized
INFO - 2020-02-25 16:45:34 --> Hooks Class Initialized
INFO - 2020-02-25 16:45:34 --> Hooks Class Initialized
INFO - 2020-02-25 16:45:34 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:45:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:45:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:45:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:45:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:45:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:45:34 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:45:34 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:34 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:34 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:34 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:34 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:34 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:34 --> URI Class Initialized
INFO - 2020-02-25 16:45:34 --> URI Class Initialized
INFO - 2020-02-25 16:45:34 --> URI Class Initialized
INFO - 2020-02-25 16:45:34 --> URI Class Initialized
INFO - 2020-02-25 16:45:34 --> URI Class Initialized
INFO - 2020-02-25 16:45:34 --> URI Class Initialized
INFO - 2020-02-25 16:45:34 --> Router Class Initialized
INFO - 2020-02-25 16:45:34 --> Router Class Initialized
INFO - 2020-02-25 16:45:34 --> Router Class Initialized
INFO - 2020-02-25 16:45:34 --> Router Class Initialized
INFO - 2020-02-25 16:45:34 --> Router Class Initialized
INFO - 2020-02-25 16:45:34 --> Router Class Initialized
INFO - 2020-02-25 16:45:34 --> Output Class Initialized
INFO - 2020-02-25 16:45:34 --> Output Class Initialized
INFO - 2020-02-25 16:45:34 --> Output Class Initialized
INFO - 2020-02-25 16:45:34 --> Output Class Initialized
INFO - 2020-02-25 16:45:34 --> Output Class Initialized
INFO - 2020-02-25 16:45:34 --> Output Class Initialized
INFO - 2020-02-25 16:45:34 --> Security Class Initialized
INFO - 2020-02-25 16:45:34 --> Security Class Initialized
INFO - 2020-02-25 16:45:34 --> Security Class Initialized
INFO - 2020-02-25 16:45:34 --> Security Class Initialized
INFO - 2020-02-25 16:45:34 --> Security Class Initialized
INFO - 2020-02-25 16:45:34 --> Security Class Initialized
DEBUG - 2020-02-25 16:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:45:34 --> Input Class Initialized
INFO - 2020-02-25 16:45:34 --> Input Class Initialized
INFO - 2020-02-25 16:45:34 --> Input Class Initialized
INFO - 2020-02-25 16:45:34 --> Input Class Initialized
INFO - 2020-02-25 16:45:34 --> Input Class Initialized
INFO - 2020-02-25 16:45:34 --> Input Class Initialized
INFO - 2020-02-25 16:45:34 --> Language Class Initialized
INFO - 2020-02-25 16:45:34 --> Language Class Initialized
INFO - 2020-02-25 16:45:34 --> Language Class Initialized
INFO - 2020-02-25 16:45:34 --> Language Class Initialized
INFO - 2020-02-25 16:45:34 --> Language Class Initialized
INFO - 2020-02-25 16:45:34 --> Language Class Initialized
ERROR - 2020-02-25 16:45:34 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-25 16:45:34 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-25 16:45:34 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-25 16:45:34 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-25 16:45:34 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-25 16:45:34 --> Loader Class Initialized
INFO - 2020-02-25 16:45:35 --> Helper loaded: url_helper
INFO - 2020-02-25 16:45:35 --> Config Class Initialized
INFO - 2020-02-25 16:45:35 --> Hooks Class Initialized
INFO - 2020-02-25 16:45:35 --> Config Class Initialized
INFO - 2020-02-25 16:45:35 --> Helper loaded: string_helper
INFO - 2020-02-25 16:45:35 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:45:35 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:45:35 --> Database Driver Class Initialized
INFO - 2020-02-25 16:45:35 --> Utf8 Class Initialized
DEBUG - 2020-02-25 16:45:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:45:35 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:45:35 --> URI Class Initialized
INFO - 2020-02-25 16:45:35 --> Controller Class Initialized
INFO - 2020-02-25 16:45:35 --> URI Class Initialized
INFO - 2020-02-25 16:45:35 --> Router Class Initialized
INFO - 2020-02-25 16:45:35 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:45:35 --> Router Class Initialized
INFO - 2020-02-25 16:45:35 --> Output Class Initialized
INFO - 2020-02-25 16:45:35 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:45:35 --> Security Class Initialized
INFO - 2020-02-25 16:45:35 --> Output Class Initialized
INFO - 2020-02-25 16:45:35 --> Model "M_pesan" initialized
DEBUG - 2020-02-25 16:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:45:35 --> Security Class Initialized
INFO - 2020-02-25 16:45:35 --> Input Class Initialized
DEBUG - 2020-02-25 16:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:45:35 --> Helper loaded: form_helper
INFO - 2020-02-25 16:45:35 --> Form Validation Class Initialized
INFO - 2020-02-25 16:45:35 --> Input Class Initialized
INFO - 2020-02-25 16:45:35 --> Language Class Initialized
INFO - 2020-02-25 16:45:35 --> Language Class Initialized
INFO - 2020-02-25 16:45:35 --> Loader Class Initialized
ERROR - 2020-02-25 16:45:35 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 16:45:35 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-25 16:45:35 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-25 16:45:35 --> Helper loaded: url_helper
INFO - 2020-02-25 16:45:35 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:45:35 --> Helper loaded: string_helper
INFO - 2020-02-25 16:45:35 --> Final output sent to browser
INFO - 2020-02-25 16:45:35 --> Config Class Initialized
INFO - 2020-02-25 16:45:35 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:45:35 --> Total execution time: 0.2948
INFO - 2020-02-25 16:45:35 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:45:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:45:35 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:45:35 --> Controller Class Initialized
INFO - 2020-02-25 16:45:35 --> URI Class Initialized
INFO - 2020-02-25 16:45:35 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:45:35 --> Router Class Initialized
INFO - 2020-02-25 16:45:35 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:45:35 --> Output Class Initialized
INFO - 2020-02-25 16:45:35 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:45:35 --> Security Class Initialized
DEBUG - 2020-02-25 16:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:45:35 --> Helper loaded: form_helper
INFO - 2020-02-25 16:45:35 --> Input Class Initialized
INFO - 2020-02-25 16:45:35 --> Form Validation Class Initialized
INFO - 2020-02-25 16:45:35 --> Language Class Initialized
ERROR - 2020-02-25 16:45:35 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 16:45:35 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-25 16:45:35 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-25 16:45:35 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:45:35 --> Final output sent to browser
INFO - 2020-02-25 16:45:35 --> Config Class Initialized
INFO - 2020-02-25 16:45:35 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:45:35 --> Total execution time: 0.2521
DEBUG - 2020-02-25 16:45:35 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:45:35 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:35 --> URI Class Initialized
INFO - 2020-02-25 16:45:35 --> Router Class Initialized
INFO - 2020-02-25 16:45:35 --> Output Class Initialized
INFO - 2020-02-25 16:45:35 --> Security Class Initialized
DEBUG - 2020-02-25 16:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:45:35 --> Input Class Initialized
INFO - 2020-02-25 16:45:35 --> Language Class Initialized
ERROR - 2020-02-25 16:45:35 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-25 16:45:35 --> Config Class Initialized
INFO - 2020-02-25 16:45:35 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:45:35 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:45:35 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:35 --> URI Class Initialized
INFO - 2020-02-25 16:45:35 --> Router Class Initialized
INFO - 2020-02-25 16:45:35 --> Output Class Initialized
INFO - 2020-02-25 16:45:35 --> Security Class Initialized
DEBUG - 2020-02-25 16:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:45:35 --> Input Class Initialized
INFO - 2020-02-25 16:45:35 --> Language Class Initialized
ERROR - 2020-02-25 16:45:35 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-25 16:45:35 --> Config Class Initialized
INFO - 2020-02-25 16:45:35 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:45:35 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:45:35 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:35 --> URI Class Initialized
INFO - 2020-02-25 16:45:35 --> Router Class Initialized
INFO - 2020-02-25 16:45:35 --> Output Class Initialized
INFO - 2020-02-25 16:45:35 --> Security Class Initialized
DEBUG - 2020-02-25 16:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:45:35 --> Input Class Initialized
INFO - 2020-02-25 16:45:35 --> Language Class Initialized
ERROR - 2020-02-25 16:45:35 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 16:45:35 --> Config Class Initialized
INFO - 2020-02-25 16:45:35 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:45:35 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:45:35 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:35 --> URI Class Initialized
INFO - 2020-02-25 16:45:35 --> Router Class Initialized
INFO - 2020-02-25 16:45:35 --> Output Class Initialized
INFO - 2020-02-25 16:45:35 --> Security Class Initialized
DEBUG - 2020-02-25 16:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:45:35 --> Input Class Initialized
INFO - 2020-02-25 16:45:35 --> Language Class Initialized
ERROR - 2020-02-25 16:45:35 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 16:45:35 --> Config Class Initialized
INFO - 2020-02-25 16:45:35 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:45:35 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:45:35 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:35 --> URI Class Initialized
INFO - 2020-02-25 16:45:35 --> Router Class Initialized
INFO - 2020-02-25 16:45:35 --> Output Class Initialized
INFO - 2020-02-25 16:45:35 --> Security Class Initialized
DEBUG - 2020-02-25 16:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:45:35 --> Input Class Initialized
INFO - 2020-02-25 16:45:35 --> Language Class Initialized
ERROR - 2020-02-25 16:45:35 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-25 16:45:35 --> Config Class Initialized
INFO - 2020-02-25 16:45:35 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:45:35 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:45:35 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:35 --> URI Class Initialized
INFO - 2020-02-25 16:45:35 --> Router Class Initialized
INFO - 2020-02-25 16:45:35 --> Output Class Initialized
INFO - 2020-02-25 16:45:36 --> Security Class Initialized
DEBUG - 2020-02-25 16:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:45:36 --> Input Class Initialized
INFO - 2020-02-25 16:45:36 --> Language Class Initialized
ERROR - 2020-02-25 16:45:36 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-25 16:45:36 --> Config Class Initialized
INFO - 2020-02-25 16:45:36 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:45:36 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:45:36 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:36 --> URI Class Initialized
INFO - 2020-02-25 16:45:36 --> Router Class Initialized
INFO - 2020-02-25 16:45:36 --> Output Class Initialized
INFO - 2020-02-25 16:45:36 --> Security Class Initialized
DEBUG - 2020-02-25 16:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:45:36 --> Input Class Initialized
INFO - 2020-02-25 16:45:36 --> Language Class Initialized
ERROR - 2020-02-25 16:45:36 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-25 16:45:36 --> Config Class Initialized
INFO - 2020-02-25 16:45:36 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:45:36 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:45:36 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:36 --> URI Class Initialized
INFO - 2020-02-25 16:45:36 --> Router Class Initialized
INFO - 2020-02-25 16:45:36 --> Output Class Initialized
INFO - 2020-02-25 16:45:36 --> Security Class Initialized
DEBUG - 2020-02-25 16:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:45:36 --> Input Class Initialized
INFO - 2020-02-25 16:45:36 --> Language Class Initialized
ERROR - 2020-02-25 16:45:36 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-25 16:45:48 --> Config Class Initialized
INFO - 2020-02-25 16:45:48 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:45:48 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:45:48 --> Utf8 Class Initialized
INFO - 2020-02-25 16:45:48 --> URI Class Initialized
INFO - 2020-02-25 16:45:48 --> Router Class Initialized
INFO - 2020-02-25 16:45:48 --> Output Class Initialized
INFO - 2020-02-25 16:45:48 --> Security Class Initialized
DEBUG - 2020-02-25 16:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:45:48 --> Input Class Initialized
INFO - 2020-02-25 16:45:48 --> Language Class Initialized
INFO - 2020-02-25 16:45:48 --> Loader Class Initialized
INFO - 2020-02-25 16:45:48 --> Helper loaded: url_helper
INFO - 2020-02-25 16:45:48 --> Helper loaded: string_helper
INFO - 2020-02-25 16:45:48 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:45:48 --> Controller Class Initialized
INFO - 2020-02-25 16:45:48 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:45:48 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:45:48 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:45:48 --> Helper loaded: form_helper
INFO - 2020-02-25 16:45:48 --> Form Validation Class Initialized
INFO - 2020-02-25 22:45:48 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-25 22:45:48 --> Final output sent to browser
DEBUG - 2020-02-25 22:45:48 --> Total execution time: 0.4063
INFO - 2020-02-25 16:46:49 --> Config Class Initialized
INFO - 2020-02-25 16:46:49 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:46:49 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:46:49 --> Utf8 Class Initialized
INFO - 2020-02-25 16:46:49 --> URI Class Initialized
INFO - 2020-02-25 16:46:49 --> Router Class Initialized
INFO - 2020-02-25 16:46:49 --> Output Class Initialized
INFO - 2020-02-25 16:46:49 --> Security Class Initialized
DEBUG - 2020-02-25 16:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:46:49 --> Input Class Initialized
INFO - 2020-02-25 16:46:49 --> Language Class Initialized
INFO - 2020-02-25 16:46:49 --> Loader Class Initialized
INFO - 2020-02-25 16:46:49 --> Helper loaded: url_helper
INFO - 2020-02-25 16:46:49 --> Helper loaded: string_helper
INFO - 2020-02-25 16:46:49 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:46:50 --> Controller Class Initialized
INFO - 2020-02-25 16:46:50 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:46:50 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:46:50 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:46:50 --> Helper loaded: form_helper
INFO - 2020-02-25 16:46:50 --> Form Validation Class Initialized
INFO - 2020-02-25 16:46:50 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:46:50 --> Final output sent to browser
DEBUG - 2020-02-25 16:46:50 --> Total execution time: 0.3036
INFO - 2020-02-25 16:46:50 --> Config Class Initialized
INFO - 2020-02-25 16:46:50 --> Config Class Initialized
INFO - 2020-02-25 16:46:50 --> Hooks Class Initialized
INFO - 2020-02-25 16:46:50 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:46:50 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:46:50 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:46:50 --> Utf8 Class Initialized
INFO - 2020-02-25 16:46:50 --> Utf8 Class Initialized
INFO - 2020-02-25 16:46:50 --> URI Class Initialized
INFO - 2020-02-25 16:46:50 --> URI Class Initialized
INFO - 2020-02-25 16:46:50 --> Router Class Initialized
INFO - 2020-02-25 16:46:50 --> Router Class Initialized
INFO - 2020-02-25 16:46:50 --> Output Class Initialized
INFO - 2020-02-25 16:46:50 --> Output Class Initialized
INFO - 2020-02-25 16:46:50 --> Security Class Initialized
INFO - 2020-02-25 16:46:50 --> Security Class Initialized
DEBUG - 2020-02-25 16:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:46:50 --> Input Class Initialized
INFO - 2020-02-25 16:46:50 --> Input Class Initialized
INFO - 2020-02-25 16:46:50 --> Language Class Initialized
INFO - 2020-02-25 16:46:50 --> Language Class Initialized
INFO - 2020-02-25 16:46:50 --> Loader Class Initialized
INFO - 2020-02-25 16:46:50 --> Loader Class Initialized
INFO - 2020-02-25 16:46:50 --> Helper loaded: url_helper
INFO - 2020-02-25 16:46:50 --> Helper loaded: url_helper
INFO - 2020-02-25 16:46:50 --> Helper loaded: string_helper
INFO - 2020-02-25 16:46:50 --> Helper loaded: string_helper
INFO - 2020-02-25 16:46:50 --> Database Driver Class Initialized
INFO - 2020-02-25 16:46:50 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-25 16:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:46:50 --> Controller Class Initialized
INFO - 2020-02-25 16:46:50 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:46:50 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:46:50 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:46:50 --> Helper loaded: form_helper
INFO - 2020-02-25 16:46:50 --> Form Validation Class Initialized
ERROR - 2020-02-25 16:46:50 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 16:46:50 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 16:46:50 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:46:50 --> Final output sent to browser
DEBUG - 2020-02-25 16:46:50 --> Total execution time: 0.3446
INFO - 2020-02-25 16:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:46:50 --> Controller Class Initialized
INFO - 2020-02-25 16:46:50 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:46:50 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:46:50 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:46:50 --> Helper loaded: form_helper
INFO - 2020-02-25 16:46:50 --> Form Validation Class Initialized
ERROR - 2020-02-25 16:46:50 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 16:46:50 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 16:46:50 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:46:50 --> Final output sent to browser
DEBUG - 2020-02-25 16:46:50 --> Total execution time: 0.4571
INFO - 2020-02-25 16:46:52 --> Config Class Initialized
INFO - 2020-02-25 16:46:52 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:46:52 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:46:52 --> Utf8 Class Initialized
INFO - 2020-02-25 16:46:52 --> URI Class Initialized
INFO - 2020-02-25 16:46:52 --> Router Class Initialized
INFO - 2020-02-25 16:46:52 --> Output Class Initialized
INFO - 2020-02-25 16:46:52 --> Security Class Initialized
DEBUG - 2020-02-25 16:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:46:52 --> Input Class Initialized
INFO - 2020-02-25 16:46:52 --> Language Class Initialized
INFO - 2020-02-25 16:46:52 --> Loader Class Initialized
INFO - 2020-02-25 16:46:52 --> Helper loaded: url_helper
INFO - 2020-02-25 16:46:52 --> Helper loaded: string_helper
INFO - 2020-02-25 16:46:52 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:46:52 --> Controller Class Initialized
INFO - 2020-02-25 16:46:52 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:46:52 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:46:53 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:46:53 --> Helper loaded: form_helper
INFO - 2020-02-25 16:46:53 --> Form Validation Class Initialized
INFO - 2020-02-25 16:46:53 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:46:53 --> Final output sent to browser
DEBUG - 2020-02-25 16:46:53 --> Total execution time: 0.2682
INFO - 2020-02-25 16:46:53 --> Config Class Initialized
INFO - 2020-02-25 16:46:53 --> Config Class Initialized
INFO - 2020-02-25 16:46:53 --> Config Class Initialized
INFO - 2020-02-25 16:46:53 --> Config Class Initialized
INFO - 2020-02-25 16:46:53 --> Config Class Initialized
INFO - 2020-02-25 16:46:53 --> Config Class Initialized
INFO - 2020-02-25 16:46:53 --> Hooks Class Initialized
INFO - 2020-02-25 16:46:53 --> Hooks Class Initialized
INFO - 2020-02-25 16:46:53 --> Hooks Class Initialized
INFO - 2020-02-25 16:46:53 --> Hooks Class Initialized
INFO - 2020-02-25 16:46:53 --> Hooks Class Initialized
INFO - 2020-02-25 16:46:53 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:46:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:46:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:46:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:46:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:46:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:46:53 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:46:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:46:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:46:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:46:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:46:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:46:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:46:53 --> URI Class Initialized
INFO - 2020-02-25 16:46:53 --> URI Class Initialized
INFO - 2020-02-25 16:46:53 --> URI Class Initialized
INFO - 2020-02-25 16:46:53 --> URI Class Initialized
INFO - 2020-02-25 16:46:53 --> URI Class Initialized
INFO - 2020-02-25 16:46:53 --> URI Class Initialized
INFO - 2020-02-25 16:46:53 --> Router Class Initialized
INFO - 2020-02-25 16:46:53 --> Router Class Initialized
INFO - 2020-02-25 16:46:53 --> Router Class Initialized
INFO - 2020-02-25 16:46:53 --> Router Class Initialized
INFO - 2020-02-25 16:46:53 --> Router Class Initialized
INFO - 2020-02-25 16:46:53 --> Router Class Initialized
INFO - 2020-02-25 16:46:53 --> Output Class Initialized
INFO - 2020-02-25 16:46:53 --> Output Class Initialized
INFO - 2020-02-25 16:46:53 --> Output Class Initialized
INFO - 2020-02-25 16:46:53 --> Output Class Initialized
INFO - 2020-02-25 16:46:53 --> Output Class Initialized
INFO - 2020-02-25 16:46:53 --> Output Class Initialized
INFO - 2020-02-25 16:46:53 --> Security Class Initialized
INFO - 2020-02-25 16:46:53 --> Security Class Initialized
INFO - 2020-02-25 16:46:53 --> Security Class Initialized
INFO - 2020-02-25 16:46:53 --> Security Class Initialized
INFO - 2020-02-25 16:46:53 --> Security Class Initialized
INFO - 2020-02-25 16:46:53 --> Security Class Initialized
DEBUG - 2020-02-25 16:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:46:53 --> Input Class Initialized
INFO - 2020-02-25 16:46:53 --> Input Class Initialized
INFO - 2020-02-25 16:46:53 --> Input Class Initialized
INFO - 2020-02-25 16:46:53 --> Input Class Initialized
INFO - 2020-02-25 16:46:53 --> Input Class Initialized
INFO - 2020-02-25 16:46:53 --> Input Class Initialized
INFO - 2020-02-25 16:46:53 --> Language Class Initialized
INFO - 2020-02-25 16:46:53 --> Language Class Initialized
INFO - 2020-02-25 16:46:53 --> Language Class Initialized
INFO - 2020-02-25 16:46:53 --> Language Class Initialized
INFO - 2020-02-25 16:46:53 --> Language Class Initialized
INFO - 2020-02-25 16:46:53 --> Language Class Initialized
ERROR - 2020-02-25 16:46:53 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-25 16:46:53 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-25 16:46:53 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-25 16:46:53 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-25 16:46:53 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-25 16:46:53 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 16:46:53 --> Config Class Initialized
INFO - 2020-02-25 16:46:53 --> Config Class Initialized
INFO - 2020-02-25 16:46:53 --> Config Class Initialized
INFO - 2020-02-25 16:46:53 --> Config Class Initialized
INFO - 2020-02-25 16:46:53 --> Config Class Initialized
INFO - 2020-02-25 16:46:53 --> Config Class Initialized
INFO - 2020-02-25 16:46:53 --> Hooks Class Initialized
INFO - 2020-02-25 16:46:53 --> Hooks Class Initialized
INFO - 2020-02-25 16:46:53 --> Hooks Class Initialized
INFO - 2020-02-25 16:46:53 --> Hooks Class Initialized
INFO - 2020-02-25 16:46:53 --> Hooks Class Initialized
INFO - 2020-02-25 16:46:53 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:46:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:46:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:46:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:46:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:46:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:46:53 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:46:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:46:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:46:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:46:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:46:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:46:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:46:53 --> URI Class Initialized
INFO - 2020-02-25 16:46:53 --> URI Class Initialized
INFO - 2020-02-25 16:46:53 --> URI Class Initialized
INFO - 2020-02-25 16:46:53 --> URI Class Initialized
INFO - 2020-02-25 16:46:53 --> URI Class Initialized
INFO - 2020-02-25 16:46:53 --> URI Class Initialized
INFO - 2020-02-25 16:46:53 --> Router Class Initialized
INFO - 2020-02-25 16:46:53 --> Router Class Initialized
INFO - 2020-02-25 16:46:53 --> Router Class Initialized
INFO - 2020-02-25 16:46:53 --> Router Class Initialized
INFO - 2020-02-25 16:46:53 --> Router Class Initialized
INFO - 2020-02-25 16:46:53 --> Router Class Initialized
INFO - 2020-02-25 16:46:53 --> Output Class Initialized
INFO - 2020-02-25 16:46:53 --> Output Class Initialized
INFO - 2020-02-25 16:46:53 --> Output Class Initialized
INFO - 2020-02-25 16:46:53 --> Output Class Initialized
INFO - 2020-02-25 16:46:53 --> Output Class Initialized
INFO - 2020-02-25 16:46:53 --> Output Class Initialized
INFO - 2020-02-25 16:46:53 --> Security Class Initialized
INFO - 2020-02-25 16:46:53 --> Security Class Initialized
INFO - 2020-02-25 16:46:53 --> Security Class Initialized
INFO - 2020-02-25 16:46:53 --> Security Class Initialized
INFO - 2020-02-25 16:46:53 --> Security Class Initialized
INFO - 2020-02-25 16:46:53 --> Security Class Initialized
DEBUG - 2020-02-25 16:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:46:53 --> Input Class Initialized
INFO - 2020-02-25 16:46:53 --> Input Class Initialized
INFO - 2020-02-25 16:46:53 --> Input Class Initialized
INFO - 2020-02-25 16:46:53 --> Input Class Initialized
INFO - 2020-02-25 16:46:53 --> Input Class Initialized
INFO - 2020-02-25 16:46:53 --> Input Class Initialized
INFO - 2020-02-25 16:46:53 --> Language Class Initialized
INFO - 2020-02-25 16:46:53 --> Language Class Initialized
INFO - 2020-02-25 16:46:53 --> Language Class Initialized
INFO - 2020-02-25 16:46:53 --> Language Class Initialized
INFO - 2020-02-25 16:46:53 --> Language Class Initialized
INFO - 2020-02-25 16:46:53 --> Language Class Initialized
ERROR - 2020-02-25 16:46:53 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-25 16:46:53 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-25 16:46:53 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-25 16:46:53 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-25 16:46:53 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-25 16:46:53 --> Loader Class Initialized
INFO - 2020-02-25 16:46:53 --> Helper loaded: url_helper
INFO - 2020-02-25 16:46:53 --> Config Class Initialized
INFO - 2020-02-25 16:46:53 --> Hooks Class Initialized
INFO - 2020-02-25 16:46:53 --> Config Class Initialized
INFO - 2020-02-25 16:46:53 --> Helper loaded: string_helper
INFO - 2020-02-25 16:46:53 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:46:53 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:46:53 --> Database Driver Class Initialized
INFO - 2020-02-25 16:46:53 --> Utf8 Class Initialized
DEBUG - 2020-02-25 16:46:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:46:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:46:53 --> URI Class Initialized
INFO - 2020-02-25 16:46:53 --> Controller Class Initialized
INFO - 2020-02-25 16:46:53 --> URI Class Initialized
INFO - 2020-02-25 16:46:53 --> Router Class Initialized
INFO - 2020-02-25 16:46:53 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:46:53 --> Router Class Initialized
INFO - 2020-02-25 16:46:53 --> Output Class Initialized
INFO - 2020-02-25 16:46:53 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:46:53 --> Security Class Initialized
INFO - 2020-02-25 16:46:53 --> Output Class Initialized
INFO - 2020-02-25 16:46:53 --> Model "M_pesan" initialized
DEBUG - 2020-02-25 16:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:46:53 --> Security Class Initialized
INFO - 2020-02-25 16:46:53 --> Input Class Initialized
DEBUG - 2020-02-25 16:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:46:53 --> Helper loaded: form_helper
INFO - 2020-02-25 16:46:53 --> Form Validation Class Initialized
INFO - 2020-02-25 16:46:53 --> Input Class Initialized
INFO - 2020-02-25 16:46:53 --> Language Class Initialized
INFO - 2020-02-25 16:46:53 --> Language Class Initialized
INFO - 2020-02-25 16:46:53 --> Loader Class Initialized
ERROR - 2020-02-25 16:46:53 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 16:46:53 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-25 16:46:53 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-25 16:46:53 --> Helper loaded: url_helper
INFO - 2020-02-25 16:46:53 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:46:53 --> Helper loaded: string_helper
INFO - 2020-02-25 16:46:53 --> Config Class Initialized
INFO - 2020-02-25 16:46:53 --> Hooks Class Initialized
INFO - 2020-02-25 16:46:53 --> Final output sent to browser
INFO - 2020-02-25 16:46:53 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:46:53 --> Total execution time: 0.2557
DEBUG - 2020-02-25 16:46:53 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:46:53 --> Utf8 Class Initialized
DEBUG - 2020-02-25 16:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:46:53 --> URI Class Initialized
INFO - 2020-02-25 16:46:53 --> Controller Class Initialized
INFO - 2020-02-25 16:46:53 --> Router Class Initialized
INFO - 2020-02-25 16:46:53 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:46:53 --> Output Class Initialized
INFO - 2020-02-25 16:46:53 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:46:53 --> Security Class Initialized
INFO - 2020-02-25 16:46:53 --> Model "M_pesan" initialized
DEBUG - 2020-02-25 16:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:46:53 --> Input Class Initialized
INFO - 2020-02-25 16:46:53 --> Helper loaded: form_helper
INFO - 2020-02-25 16:46:53 --> Form Validation Class Initialized
INFO - 2020-02-25 16:46:53 --> Language Class Initialized
ERROR - 2020-02-25 16:46:53 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-25 16:46:53 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 16:46:53 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 16:46:53 --> Config Class Initialized
INFO - 2020-02-25 16:46:53 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:46:53 --> Hooks Class Initialized
INFO - 2020-02-25 16:46:53 --> Final output sent to browser
DEBUG - 2020-02-25 16:46:53 --> Total execution time: 0.2457
DEBUG - 2020-02-25 16:46:53 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:46:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:46:53 --> URI Class Initialized
INFO - 2020-02-25 16:46:53 --> Router Class Initialized
INFO - 2020-02-25 16:46:53 --> Output Class Initialized
INFO - 2020-02-25 16:46:53 --> Security Class Initialized
DEBUG - 2020-02-25 16:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:46:53 --> Input Class Initialized
INFO - 2020-02-25 16:46:53 --> Language Class Initialized
ERROR - 2020-02-25 16:46:53 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-25 16:46:53 --> Config Class Initialized
INFO - 2020-02-25 16:46:53 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:46:53 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:46:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:46:53 --> URI Class Initialized
INFO - 2020-02-25 16:46:53 --> Router Class Initialized
INFO - 2020-02-25 16:46:53 --> Output Class Initialized
INFO - 2020-02-25 16:46:53 --> Security Class Initialized
DEBUG - 2020-02-25 16:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:46:53 --> Input Class Initialized
INFO - 2020-02-25 16:46:53 --> Language Class Initialized
ERROR - 2020-02-25 16:46:53 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-25 16:46:53 --> Config Class Initialized
INFO - 2020-02-25 16:46:53 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:46:53 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:46:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:46:53 --> URI Class Initialized
INFO - 2020-02-25 16:46:53 --> Router Class Initialized
INFO - 2020-02-25 16:46:53 --> Output Class Initialized
INFO - 2020-02-25 16:46:53 --> Security Class Initialized
DEBUG - 2020-02-25 16:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:46:53 --> Input Class Initialized
INFO - 2020-02-25 16:46:53 --> Language Class Initialized
ERROR - 2020-02-25 16:46:53 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 16:46:54 --> Config Class Initialized
INFO - 2020-02-25 16:46:54 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:46:54 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:46:54 --> Utf8 Class Initialized
INFO - 2020-02-25 16:46:54 --> URI Class Initialized
INFO - 2020-02-25 16:46:54 --> Router Class Initialized
INFO - 2020-02-25 16:46:54 --> Output Class Initialized
INFO - 2020-02-25 16:46:54 --> Security Class Initialized
DEBUG - 2020-02-25 16:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:46:54 --> Input Class Initialized
INFO - 2020-02-25 16:46:54 --> Language Class Initialized
ERROR - 2020-02-25 16:46:54 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 16:46:54 --> Config Class Initialized
INFO - 2020-02-25 16:46:54 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:46:54 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:46:54 --> Utf8 Class Initialized
INFO - 2020-02-25 16:46:54 --> URI Class Initialized
INFO - 2020-02-25 16:46:54 --> Router Class Initialized
INFO - 2020-02-25 16:46:54 --> Output Class Initialized
INFO - 2020-02-25 16:46:54 --> Security Class Initialized
DEBUG - 2020-02-25 16:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:46:54 --> Input Class Initialized
INFO - 2020-02-25 16:46:54 --> Language Class Initialized
ERROR - 2020-02-25 16:46:54 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-25 16:46:54 --> Config Class Initialized
INFO - 2020-02-25 16:46:54 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:46:54 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:46:54 --> Utf8 Class Initialized
INFO - 2020-02-25 16:46:54 --> URI Class Initialized
INFO - 2020-02-25 16:46:54 --> Router Class Initialized
INFO - 2020-02-25 16:46:54 --> Output Class Initialized
INFO - 2020-02-25 16:46:54 --> Security Class Initialized
DEBUG - 2020-02-25 16:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:46:54 --> Input Class Initialized
INFO - 2020-02-25 16:46:54 --> Language Class Initialized
ERROR - 2020-02-25 16:46:54 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-25 16:46:54 --> Config Class Initialized
INFO - 2020-02-25 16:46:54 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:46:54 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:46:54 --> Utf8 Class Initialized
INFO - 2020-02-25 16:46:54 --> URI Class Initialized
INFO - 2020-02-25 16:46:54 --> Router Class Initialized
INFO - 2020-02-25 16:46:54 --> Output Class Initialized
INFO - 2020-02-25 16:46:54 --> Security Class Initialized
DEBUG - 2020-02-25 16:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:46:54 --> Input Class Initialized
INFO - 2020-02-25 16:46:54 --> Language Class Initialized
ERROR - 2020-02-25 16:46:54 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-25 16:46:54 --> Config Class Initialized
INFO - 2020-02-25 16:46:54 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:46:54 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:46:54 --> Utf8 Class Initialized
INFO - 2020-02-25 16:46:54 --> URI Class Initialized
INFO - 2020-02-25 16:46:54 --> Router Class Initialized
INFO - 2020-02-25 16:46:54 --> Output Class Initialized
INFO - 2020-02-25 16:46:54 --> Security Class Initialized
DEBUG - 2020-02-25 16:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:46:54 --> Input Class Initialized
INFO - 2020-02-25 16:46:54 --> Language Class Initialized
ERROR - 2020-02-25 16:46:54 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-25 16:47:07 --> Config Class Initialized
INFO - 2020-02-25 16:47:07 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:47:07 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:47:07 --> Utf8 Class Initialized
INFO - 2020-02-25 16:47:07 --> URI Class Initialized
INFO - 2020-02-25 16:47:07 --> Router Class Initialized
INFO - 2020-02-25 16:47:07 --> Output Class Initialized
INFO - 2020-02-25 16:47:07 --> Security Class Initialized
DEBUG - 2020-02-25 16:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:47:07 --> Input Class Initialized
INFO - 2020-02-25 16:47:07 --> Language Class Initialized
INFO - 2020-02-25 16:47:07 --> Loader Class Initialized
INFO - 2020-02-25 16:47:07 --> Helper loaded: url_helper
INFO - 2020-02-25 16:47:07 --> Helper loaded: string_helper
INFO - 2020-02-25 16:47:08 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:47:08 --> Controller Class Initialized
INFO - 2020-02-25 16:47:08 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:47:08 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:47:08 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:47:08 --> Helper loaded: form_helper
INFO - 2020-02-25 16:47:08 --> Form Validation Class Initialized
INFO - 2020-02-25 22:47:08 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-25 22:47:08 --> Final output sent to browser
DEBUG - 2020-02-25 22:47:08 --> Total execution time: 0.4491
INFO - 2020-02-25 16:47:22 --> Config Class Initialized
INFO - 2020-02-25 16:47:22 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:47:22 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:47:22 --> Utf8 Class Initialized
INFO - 2020-02-25 16:47:22 --> URI Class Initialized
DEBUG - 2020-02-25 16:47:22 --> No URI present. Default controller set.
INFO - 2020-02-25 16:47:22 --> Router Class Initialized
INFO - 2020-02-25 16:47:22 --> Output Class Initialized
INFO - 2020-02-25 16:47:22 --> Security Class Initialized
DEBUG - 2020-02-25 16:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:47:22 --> Input Class Initialized
INFO - 2020-02-25 16:47:22 --> Language Class Initialized
INFO - 2020-02-25 16:47:22 --> Loader Class Initialized
INFO - 2020-02-25 16:47:22 --> Helper loaded: url_helper
INFO - 2020-02-25 16:47:22 --> Helper loaded: string_helper
INFO - 2020-02-25 16:47:22 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:47:22 --> Controller Class Initialized
INFO - 2020-02-25 16:47:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:47:22 --> Pagination Class Initialized
INFO - 2020-02-25 16:47:22 --> Model "M_show" initialized
INFO - 2020-02-25 16:47:22 --> Helper loaded: form_helper
INFO - 2020-02-25 16:47:22 --> Form Validation Class Initialized
INFO - 2020-02-25 16:47:22 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-25 16:47:22 --> Final output sent to browser
DEBUG - 2020-02-25 16:47:23 --> Total execution time: 0.3138
INFO - 2020-02-25 16:47:23 --> Config Class Initialized
INFO - 2020-02-25 16:47:23 --> Config Class Initialized
INFO - 2020-02-25 16:47:23 --> Hooks Class Initialized
INFO - 2020-02-25 16:47:23 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:47:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:47:23 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:47:23 --> Utf8 Class Initialized
INFO - 2020-02-25 16:47:23 --> Utf8 Class Initialized
INFO - 2020-02-25 16:47:23 --> URI Class Initialized
INFO - 2020-02-25 16:47:23 --> URI Class Initialized
INFO - 2020-02-25 16:47:23 --> Router Class Initialized
INFO - 2020-02-25 16:47:23 --> Router Class Initialized
INFO - 2020-02-25 16:47:23 --> Output Class Initialized
INFO - 2020-02-25 16:47:23 --> Output Class Initialized
INFO - 2020-02-25 16:47:23 --> Security Class Initialized
INFO - 2020-02-25 16:47:23 --> Security Class Initialized
DEBUG - 2020-02-25 16:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:47:23 --> Input Class Initialized
INFO - 2020-02-25 16:47:23 --> Input Class Initialized
INFO - 2020-02-25 16:47:23 --> Language Class Initialized
INFO - 2020-02-25 16:47:23 --> Language Class Initialized
ERROR - 2020-02-25 16:47:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-02-25 16:47:23 --> 404 Page Not Found: Assets/js
INFO - 2020-02-25 16:47:23 --> Config Class Initialized
INFO - 2020-02-25 16:47:23 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:47:23 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:47:23 --> Utf8 Class Initialized
INFO - 2020-02-25 16:47:23 --> URI Class Initialized
INFO - 2020-02-25 16:47:23 --> Router Class Initialized
INFO - 2020-02-25 16:47:23 --> Output Class Initialized
INFO - 2020-02-25 16:47:23 --> Security Class Initialized
DEBUG - 2020-02-25 16:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:47:23 --> Input Class Initialized
INFO - 2020-02-25 16:47:23 --> Language Class Initialized
ERROR - 2020-02-25 16:47:23 --> 404 Page Not Found: Assets/js
INFO - 2020-02-25 16:47:25 --> Config Class Initialized
INFO - 2020-02-25 16:47:25 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:47:25 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:47:25 --> Utf8 Class Initialized
INFO - 2020-02-25 16:47:25 --> URI Class Initialized
INFO - 2020-02-25 16:47:25 --> Router Class Initialized
INFO - 2020-02-25 16:47:25 --> Output Class Initialized
INFO - 2020-02-25 16:47:25 --> Security Class Initialized
DEBUG - 2020-02-25 16:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:47:25 --> Input Class Initialized
INFO - 2020-02-25 16:47:25 --> Language Class Initialized
INFO - 2020-02-25 16:47:25 --> Loader Class Initialized
INFO - 2020-02-25 16:47:25 --> Helper loaded: url_helper
INFO - 2020-02-25 16:47:25 --> Helper loaded: string_helper
INFO - 2020-02-25 16:47:25 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:47:25 --> Controller Class Initialized
INFO - 2020-02-25 16:47:25 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:47:25 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:47:25 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:47:25 --> Helper loaded: form_helper
INFO - 2020-02-25 16:47:25 --> Form Validation Class Initialized
INFO - 2020-02-25 16:47:25 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:47:25 --> Final output sent to browser
DEBUG - 2020-02-25 16:47:25 --> Total execution time: 0.2721
INFO - 2020-02-25 16:47:25 --> Config Class Initialized
INFO - 2020-02-25 16:47:25 --> Config Class Initialized
INFO - 2020-02-25 16:47:25 --> Config Class Initialized
INFO - 2020-02-25 16:47:25 --> Config Class Initialized
INFO - 2020-02-25 16:47:25 --> Config Class Initialized
INFO - 2020-02-25 16:47:25 --> Config Class Initialized
INFO - 2020-02-25 16:47:25 --> Hooks Class Initialized
INFO - 2020-02-25 16:47:25 --> Hooks Class Initialized
INFO - 2020-02-25 16:47:25 --> Hooks Class Initialized
INFO - 2020-02-25 16:47:25 --> Hooks Class Initialized
INFO - 2020-02-25 16:47:25 --> Hooks Class Initialized
INFO - 2020-02-25 16:47:25 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:47:25 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:47:25 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:47:25 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:47:25 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:47:25 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:47:25 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:47:25 --> Utf8 Class Initialized
INFO - 2020-02-25 16:47:25 --> Utf8 Class Initialized
INFO - 2020-02-25 16:47:25 --> Utf8 Class Initialized
INFO - 2020-02-25 16:47:25 --> Utf8 Class Initialized
INFO - 2020-02-25 16:47:25 --> Utf8 Class Initialized
INFO - 2020-02-25 16:47:25 --> Utf8 Class Initialized
INFO - 2020-02-25 16:47:25 --> URI Class Initialized
INFO - 2020-02-25 16:47:25 --> URI Class Initialized
INFO - 2020-02-25 16:47:25 --> URI Class Initialized
INFO - 2020-02-25 16:47:25 --> URI Class Initialized
INFO - 2020-02-25 16:47:25 --> URI Class Initialized
INFO - 2020-02-25 16:47:25 --> URI Class Initialized
INFO - 2020-02-25 16:47:25 --> Router Class Initialized
INFO - 2020-02-25 16:47:25 --> Router Class Initialized
INFO - 2020-02-25 16:47:25 --> Router Class Initialized
INFO - 2020-02-25 16:47:25 --> Router Class Initialized
INFO - 2020-02-25 16:47:25 --> Router Class Initialized
INFO - 2020-02-25 16:47:25 --> Router Class Initialized
INFO - 2020-02-25 16:47:25 --> Output Class Initialized
INFO - 2020-02-25 16:47:25 --> Output Class Initialized
INFO - 2020-02-25 16:47:25 --> Output Class Initialized
INFO - 2020-02-25 16:47:25 --> Output Class Initialized
INFO - 2020-02-25 16:47:25 --> Output Class Initialized
INFO - 2020-02-25 16:47:25 --> Output Class Initialized
INFO - 2020-02-25 16:47:25 --> Security Class Initialized
INFO - 2020-02-25 16:47:25 --> Security Class Initialized
INFO - 2020-02-25 16:47:25 --> Security Class Initialized
INFO - 2020-02-25 16:47:25 --> Security Class Initialized
INFO - 2020-02-25 16:47:25 --> Security Class Initialized
INFO - 2020-02-25 16:47:25 --> Security Class Initialized
DEBUG - 2020-02-25 16:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:47:25 --> Input Class Initialized
INFO - 2020-02-25 16:47:25 --> Input Class Initialized
INFO - 2020-02-25 16:47:25 --> Input Class Initialized
INFO - 2020-02-25 16:47:25 --> Input Class Initialized
INFO - 2020-02-25 16:47:25 --> Input Class Initialized
INFO - 2020-02-25 16:47:25 --> Input Class Initialized
INFO - 2020-02-25 16:47:25 --> Language Class Initialized
INFO - 2020-02-25 16:47:25 --> Language Class Initialized
INFO - 2020-02-25 16:47:25 --> Language Class Initialized
INFO - 2020-02-25 16:47:25 --> Language Class Initialized
INFO - 2020-02-25 16:47:25 --> Language Class Initialized
INFO - 2020-02-25 16:47:25 --> Language Class Initialized
ERROR - 2020-02-25 16:47:25 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-25 16:47:25 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-25 16:47:25 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-25 16:47:25 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-25 16:47:25 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-25 16:47:25 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-25 16:47:25 --> Config Class Initialized
INFO - 2020-02-25 16:47:25 --> Config Class Initialized
INFO - 2020-02-25 16:47:25 --> Config Class Initialized
INFO - 2020-02-25 16:47:25 --> Config Class Initialized
INFO - 2020-02-25 16:47:25 --> Config Class Initialized
INFO - 2020-02-25 16:47:25 --> Config Class Initialized
INFO - 2020-02-25 16:47:25 --> Hooks Class Initialized
INFO - 2020-02-25 16:47:25 --> Hooks Class Initialized
INFO - 2020-02-25 16:47:25 --> Hooks Class Initialized
INFO - 2020-02-25 16:47:25 --> Hooks Class Initialized
INFO - 2020-02-25 16:47:25 --> Hooks Class Initialized
INFO - 2020-02-25 16:47:25 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:47:25 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:47:25 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:47:25 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:47:25 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:47:25 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:47:25 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:47:25 --> Utf8 Class Initialized
INFO - 2020-02-25 16:47:25 --> Utf8 Class Initialized
INFO - 2020-02-25 16:47:25 --> Utf8 Class Initialized
INFO - 2020-02-25 16:47:25 --> Utf8 Class Initialized
INFO - 2020-02-25 16:47:25 --> Utf8 Class Initialized
INFO - 2020-02-25 16:47:25 --> Utf8 Class Initialized
INFO - 2020-02-25 16:47:25 --> URI Class Initialized
INFO - 2020-02-25 16:47:25 --> URI Class Initialized
INFO - 2020-02-25 16:47:25 --> URI Class Initialized
INFO - 2020-02-25 16:47:25 --> URI Class Initialized
INFO - 2020-02-25 16:47:25 --> URI Class Initialized
INFO - 2020-02-25 16:47:25 --> URI Class Initialized
INFO - 2020-02-25 16:47:25 --> Router Class Initialized
INFO - 2020-02-25 16:47:25 --> Router Class Initialized
INFO - 2020-02-25 16:47:25 --> Router Class Initialized
INFO - 2020-02-25 16:47:25 --> Router Class Initialized
INFO - 2020-02-25 16:47:25 --> Router Class Initialized
INFO - 2020-02-25 16:47:25 --> Router Class Initialized
INFO - 2020-02-25 16:47:25 --> Output Class Initialized
INFO - 2020-02-25 16:47:25 --> Output Class Initialized
INFO - 2020-02-25 16:47:25 --> Output Class Initialized
INFO - 2020-02-25 16:47:25 --> Output Class Initialized
INFO - 2020-02-25 16:47:25 --> Output Class Initialized
INFO - 2020-02-25 16:47:25 --> Output Class Initialized
INFO - 2020-02-25 16:47:25 --> Security Class Initialized
INFO - 2020-02-25 16:47:25 --> Security Class Initialized
INFO - 2020-02-25 16:47:25 --> Security Class Initialized
INFO - 2020-02-25 16:47:25 --> Security Class Initialized
INFO - 2020-02-25 16:47:25 --> Security Class Initialized
INFO - 2020-02-25 16:47:25 --> Security Class Initialized
DEBUG - 2020-02-25 16:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:47:25 --> Input Class Initialized
INFO - 2020-02-25 16:47:25 --> Input Class Initialized
INFO - 2020-02-25 16:47:25 --> Input Class Initialized
INFO - 2020-02-25 16:47:25 --> Input Class Initialized
INFO - 2020-02-25 16:47:25 --> Input Class Initialized
INFO - 2020-02-25 16:47:25 --> Input Class Initialized
INFO - 2020-02-25 16:47:25 --> Language Class Initialized
INFO - 2020-02-25 16:47:25 --> Language Class Initialized
INFO - 2020-02-25 16:47:25 --> Language Class Initialized
INFO - 2020-02-25 16:47:25 --> Language Class Initialized
INFO - 2020-02-25 16:47:25 --> Language Class Initialized
INFO - 2020-02-25 16:47:25 --> Language Class Initialized
ERROR - 2020-02-25 16:47:25 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-25 16:47:25 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-25 16:47:25 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-25 16:47:25 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-25 16:47:25 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 16:47:25 --> Loader Class Initialized
INFO - 2020-02-25 16:47:25 --> Helper loaded: url_helper
INFO - 2020-02-25 16:47:25 --> Config Class Initialized
INFO - 2020-02-25 16:47:25 --> Config Class Initialized
INFO - 2020-02-25 16:47:25 --> Hooks Class Initialized
INFO - 2020-02-25 16:47:25 --> Hooks Class Initialized
INFO - 2020-02-25 16:47:25 --> Helper loaded: string_helper
DEBUG - 2020-02-25 16:47:25 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:47:25 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:47:25 --> Database Driver Class Initialized
INFO - 2020-02-25 16:47:25 --> Utf8 Class Initialized
INFO - 2020-02-25 16:47:25 --> Utf8 Class Initialized
DEBUG - 2020-02-25 16:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:47:25 --> URI Class Initialized
INFO - 2020-02-25 16:47:25 --> URI Class Initialized
INFO - 2020-02-25 16:47:25 --> Controller Class Initialized
INFO - 2020-02-25 16:47:25 --> Router Class Initialized
INFO - 2020-02-25 16:47:25 --> Router Class Initialized
INFO - 2020-02-25 16:47:25 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:47:25 --> Output Class Initialized
INFO - 2020-02-25 16:47:25 --> Output Class Initialized
INFO - 2020-02-25 16:47:25 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:47:25 --> Security Class Initialized
INFO - 2020-02-25 16:47:25 --> Security Class Initialized
INFO - 2020-02-25 16:47:25 --> Model "M_pesan" initialized
DEBUG - 2020-02-25 16:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:47:25 --> Input Class Initialized
INFO - 2020-02-25 16:47:25 --> Input Class Initialized
INFO - 2020-02-25 16:47:25 --> Helper loaded: form_helper
INFO - 2020-02-25 16:47:25 --> Form Validation Class Initialized
INFO - 2020-02-25 16:47:25 --> Language Class Initialized
INFO - 2020-02-25 16:47:25 --> Language Class Initialized
ERROR - 2020-02-25 16:47:25 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-25 16:47:25 --> Loader Class Initialized
ERROR - 2020-02-25 16:47:25 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 16:47:25 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 16:47:25 --> Helper loaded: url_helper
INFO - 2020-02-25 16:47:25 --> Config Class Initialized
INFO - 2020-02-25 16:47:25 --> Helper loaded: string_helper
INFO - 2020-02-25 16:47:25 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:47:25 --> Hooks Class Initialized
INFO - 2020-02-25 16:47:25 --> Final output sent to browser
INFO - 2020-02-25 16:47:25 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:47:25 --> Total execution time: 0.2768
DEBUG - 2020-02-25 16:47:25 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:47:25 --> Utf8 Class Initialized
INFO - 2020-02-25 16:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:47:25 --> Controller Class Initialized
INFO - 2020-02-25 16:47:25 --> URI Class Initialized
INFO - 2020-02-25 16:47:25 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:47:25 --> Router Class Initialized
INFO - 2020-02-25 16:47:25 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:47:25 --> Output Class Initialized
INFO - 2020-02-25 16:47:25 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:47:25 --> Security Class Initialized
DEBUG - 2020-02-25 16:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:47:26 --> Helper loaded: form_helper
INFO - 2020-02-25 16:47:26 --> Form Validation Class Initialized
INFO - 2020-02-25 16:47:26 --> Input Class Initialized
INFO - 2020-02-25 16:47:26 --> Language Class Initialized
ERROR - 2020-02-25 16:47:26 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 16:47:26 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-25 16:47:26 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-25 16:47:26 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:47:26 --> Config Class Initialized
INFO - 2020-02-25 16:47:26 --> Final output sent to browser
INFO - 2020-02-25 16:47:26 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:47:26 --> Total execution time: 0.2571
DEBUG - 2020-02-25 16:47:26 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:47:26 --> Utf8 Class Initialized
INFO - 2020-02-25 16:47:26 --> URI Class Initialized
INFO - 2020-02-25 16:47:26 --> Router Class Initialized
INFO - 2020-02-25 16:47:26 --> Output Class Initialized
INFO - 2020-02-25 16:47:26 --> Security Class Initialized
DEBUG - 2020-02-25 16:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:47:26 --> Input Class Initialized
INFO - 2020-02-25 16:47:26 --> Language Class Initialized
ERROR - 2020-02-25 16:47:26 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-25 16:47:26 --> Config Class Initialized
INFO - 2020-02-25 16:47:26 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:47:26 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:47:26 --> Utf8 Class Initialized
INFO - 2020-02-25 16:47:26 --> URI Class Initialized
INFO - 2020-02-25 16:47:26 --> Router Class Initialized
INFO - 2020-02-25 16:47:26 --> Output Class Initialized
INFO - 2020-02-25 16:47:26 --> Security Class Initialized
DEBUG - 2020-02-25 16:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:47:26 --> Input Class Initialized
INFO - 2020-02-25 16:47:26 --> Language Class Initialized
ERROR - 2020-02-25 16:47:26 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-25 16:47:26 --> Config Class Initialized
INFO - 2020-02-25 16:47:26 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:47:26 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:47:26 --> Utf8 Class Initialized
INFO - 2020-02-25 16:47:26 --> URI Class Initialized
INFO - 2020-02-25 16:47:26 --> Router Class Initialized
INFO - 2020-02-25 16:47:26 --> Output Class Initialized
INFO - 2020-02-25 16:47:26 --> Security Class Initialized
DEBUG - 2020-02-25 16:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:47:26 --> Input Class Initialized
INFO - 2020-02-25 16:47:26 --> Language Class Initialized
ERROR - 2020-02-25 16:47:26 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 16:47:26 --> Config Class Initialized
INFO - 2020-02-25 16:47:26 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:47:26 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:47:26 --> Utf8 Class Initialized
INFO - 2020-02-25 16:47:26 --> URI Class Initialized
INFO - 2020-02-25 16:47:26 --> Router Class Initialized
INFO - 2020-02-25 16:47:26 --> Output Class Initialized
INFO - 2020-02-25 16:47:26 --> Security Class Initialized
DEBUG - 2020-02-25 16:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:47:26 --> Input Class Initialized
INFO - 2020-02-25 16:47:26 --> Language Class Initialized
ERROR - 2020-02-25 16:47:26 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 16:47:26 --> Config Class Initialized
INFO - 2020-02-25 16:47:26 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:47:26 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:47:26 --> Utf8 Class Initialized
INFO - 2020-02-25 16:47:26 --> URI Class Initialized
INFO - 2020-02-25 16:47:26 --> Router Class Initialized
INFO - 2020-02-25 16:47:26 --> Output Class Initialized
INFO - 2020-02-25 16:47:26 --> Security Class Initialized
DEBUG - 2020-02-25 16:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:47:26 --> Input Class Initialized
INFO - 2020-02-25 16:47:26 --> Language Class Initialized
ERROR - 2020-02-25 16:47:26 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-25 16:47:26 --> Config Class Initialized
INFO - 2020-02-25 16:47:26 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:47:26 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:47:26 --> Utf8 Class Initialized
INFO - 2020-02-25 16:47:26 --> URI Class Initialized
INFO - 2020-02-25 16:47:26 --> Router Class Initialized
INFO - 2020-02-25 16:47:26 --> Output Class Initialized
INFO - 2020-02-25 16:47:26 --> Security Class Initialized
DEBUG - 2020-02-25 16:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:47:26 --> Input Class Initialized
INFO - 2020-02-25 16:47:26 --> Language Class Initialized
ERROR - 2020-02-25 16:47:26 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-25 16:47:26 --> Config Class Initialized
INFO - 2020-02-25 16:47:26 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:47:26 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:47:26 --> Utf8 Class Initialized
INFO - 2020-02-25 16:47:26 --> URI Class Initialized
INFO - 2020-02-25 16:47:26 --> Router Class Initialized
INFO - 2020-02-25 16:47:26 --> Output Class Initialized
INFO - 2020-02-25 16:47:26 --> Security Class Initialized
DEBUG - 2020-02-25 16:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:47:26 --> Input Class Initialized
INFO - 2020-02-25 16:47:26 --> Language Class Initialized
ERROR - 2020-02-25 16:47:27 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-25 16:47:27 --> Config Class Initialized
INFO - 2020-02-25 16:47:27 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:47:27 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:47:27 --> Utf8 Class Initialized
INFO - 2020-02-25 16:47:27 --> URI Class Initialized
INFO - 2020-02-25 16:47:27 --> Router Class Initialized
INFO - 2020-02-25 16:47:27 --> Output Class Initialized
INFO - 2020-02-25 16:47:27 --> Security Class Initialized
DEBUG - 2020-02-25 16:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:47:27 --> Input Class Initialized
INFO - 2020-02-25 16:47:27 --> Language Class Initialized
ERROR - 2020-02-25 16:47:27 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-25 16:47:40 --> Config Class Initialized
INFO - 2020-02-25 16:47:40 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:47:40 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:47:40 --> Utf8 Class Initialized
INFO - 2020-02-25 16:47:40 --> URI Class Initialized
INFO - 2020-02-25 16:47:40 --> Router Class Initialized
INFO - 2020-02-25 16:47:40 --> Output Class Initialized
INFO - 2020-02-25 16:47:40 --> Security Class Initialized
DEBUG - 2020-02-25 16:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:47:40 --> Input Class Initialized
INFO - 2020-02-25 16:47:40 --> Language Class Initialized
INFO - 2020-02-25 16:47:40 --> Loader Class Initialized
INFO - 2020-02-25 16:47:40 --> Helper loaded: url_helper
INFO - 2020-02-25 16:47:40 --> Helper loaded: string_helper
INFO - 2020-02-25 16:47:40 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:47:40 --> Controller Class Initialized
INFO - 2020-02-25 16:47:40 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:47:40 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:47:40 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:47:40 --> Helper loaded: form_helper
INFO - 2020-02-25 16:47:40 --> Form Validation Class Initialized
INFO - 2020-02-25 22:47:41 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-25 22:47:41 --> Final output sent to browser
DEBUG - 2020-02-25 22:47:41 --> Total execution time: 0.5142
INFO - 2020-02-25 16:49:34 --> Config Class Initialized
INFO - 2020-02-25 16:49:34 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:49:34 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:49:34 --> Utf8 Class Initialized
INFO - 2020-02-25 16:49:34 --> URI Class Initialized
DEBUG - 2020-02-25 16:49:34 --> No URI present. Default controller set.
INFO - 2020-02-25 16:49:34 --> Router Class Initialized
INFO - 2020-02-25 16:49:34 --> Output Class Initialized
INFO - 2020-02-25 16:49:34 --> Security Class Initialized
DEBUG - 2020-02-25 16:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:49:34 --> Input Class Initialized
INFO - 2020-02-25 16:49:34 --> Language Class Initialized
INFO - 2020-02-25 16:49:34 --> Loader Class Initialized
INFO - 2020-02-25 16:49:34 --> Helper loaded: url_helper
INFO - 2020-02-25 16:49:34 --> Helper loaded: string_helper
INFO - 2020-02-25 16:49:34 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:49:34 --> Controller Class Initialized
INFO - 2020-02-25 16:49:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:49:34 --> Pagination Class Initialized
INFO - 2020-02-25 16:49:34 --> Model "M_show" initialized
INFO - 2020-02-25 16:49:34 --> Helper loaded: form_helper
INFO - 2020-02-25 16:49:34 --> Form Validation Class Initialized
INFO - 2020-02-25 16:49:34 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-25 16:49:34 --> Final output sent to browser
DEBUG - 2020-02-25 16:49:34 --> Total execution time: 0.2911
INFO - 2020-02-25 16:49:35 --> Config Class Initialized
INFO - 2020-02-25 16:49:35 --> Config Class Initialized
INFO - 2020-02-25 16:49:35 --> Hooks Class Initialized
INFO - 2020-02-25 16:49:35 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:49:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:49:35 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:49:35 --> Utf8 Class Initialized
INFO - 2020-02-25 16:49:35 --> Utf8 Class Initialized
INFO - 2020-02-25 16:49:35 --> URI Class Initialized
INFO - 2020-02-25 16:49:35 --> URI Class Initialized
INFO - 2020-02-25 16:49:35 --> Router Class Initialized
INFO - 2020-02-25 16:49:35 --> Router Class Initialized
INFO - 2020-02-25 16:49:35 --> Output Class Initialized
INFO - 2020-02-25 16:49:35 --> Output Class Initialized
INFO - 2020-02-25 16:49:35 --> Security Class Initialized
INFO - 2020-02-25 16:49:35 --> Security Class Initialized
DEBUG - 2020-02-25 16:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:49:35 --> Input Class Initialized
INFO - 2020-02-25 16:49:35 --> Input Class Initialized
INFO - 2020-02-25 16:49:35 --> Language Class Initialized
INFO - 2020-02-25 16:49:35 --> Language Class Initialized
ERROR - 2020-02-25 16:49:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-02-25 16:49:35 --> 404 Page Not Found: Assets/js
INFO - 2020-02-25 16:49:36 --> Config Class Initialized
INFO - 2020-02-25 16:49:36 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:49:36 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:49:36 --> Utf8 Class Initialized
INFO - 2020-02-25 16:49:36 --> URI Class Initialized
INFO - 2020-02-25 16:49:36 --> Router Class Initialized
INFO - 2020-02-25 16:49:36 --> Output Class Initialized
INFO - 2020-02-25 16:49:36 --> Security Class Initialized
DEBUG - 2020-02-25 16:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:49:36 --> Input Class Initialized
INFO - 2020-02-25 16:49:36 --> Language Class Initialized
INFO - 2020-02-25 16:49:36 --> Loader Class Initialized
INFO - 2020-02-25 16:49:36 --> Helper loaded: url_helper
INFO - 2020-02-25 16:49:36 --> Helper loaded: string_helper
INFO - 2020-02-25 16:49:36 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:49:36 --> Controller Class Initialized
INFO - 2020-02-25 16:49:36 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:49:36 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:49:36 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:49:36 --> Helper loaded: form_helper
INFO - 2020-02-25 16:49:36 --> Form Validation Class Initialized
INFO - 2020-02-25 16:49:36 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:49:36 --> Final output sent to browser
DEBUG - 2020-02-25 16:49:36 --> Total execution time: 0.3798
INFO - 2020-02-25 16:49:36 --> Config Class Initialized
INFO - 2020-02-25 16:49:36 --> Config Class Initialized
INFO - 2020-02-25 16:49:36 --> Config Class Initialized
INFO - 2020-02-25 16:49:36 --> Config Class Initialized
INFO - 2020-02-25 16:49:36 --> Config Class Initialized
INFO - 2020-02-25 16:49:36 --> Config Class Initialized
INFO - 2020-02-25 16:49:36 --> Hooks Class Initialized
INFO - 2020-02-25 16:49:36 --> Hooks Class Initialized
INFO - 2020-02-25 16:49:36 --> Hooks Class Initialized
INFO - 2020-02-25 16:49:36 --> Hooks Class Initialized
INFO - 2020-02-25 16:49:36 --> Hooks Class Initialized
INFO - 2020-02-25 16:49:36 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:49:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:49:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:49:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:49:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:49:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:49:36 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:49:36 --> Utf8 Class Initialized
INFO - 2020-02-25 16:49:36 --> Utf8 Class Initialized
INFO - 2020-02-25 16:49:36 --> Utf8 Class Initialized
INFO - 2020-02-25 16:49:36 --> Utf8 Class Initialized
INFO - 2020-02-25 16:49:36 --> Utf8 Class Initialized
INFO - 2020-02-25 16:49:36 --> Utf8 Class Initialized
INFO - 2020-02-25 16:49:36 --> URI Class Initialized
INFO - 2020-02-25 16:49:36 --> URI Class Initialized
INFO - 2020-02-25 16:49:36 --> URI Class Initialized
INFO - 2020-02-25 16:49:36 --> URI Class Initialized
INFO - 2020-02-25 16:49:36 --> URI Class Initialized
INFO - 2020-02-25 16:49:36 --> URI Class Initialized
INFO - 2020-02-25 16:49:36 --> Router Class Initialized
INFO - 2020-02-25 16:49:36 --> Router Class Initialized
INFO - 2020-02-25 16:49:36 --> Router Class Initialized
INFO - 2020-02-25 16:49:36 --> Router Class Initialized
INFO - 2020-02-25 16:49:36 --> Router Class Initialized
INFO - 2020-02-25 16:49:36 --> Router Class Initialized
INFO - 2020-02-25 16:49:36 --> Output Class Initialized
INFO - 2020-02-25 16:49:36 --> Output Class Initialized
INFO - 2020-02-25 16:49:36 --> Output Class Initialized
INFO - 2020-02-25 16:49:36 --> Output Class Initialized
INFO - 2020-02-25 16:49:36 --> Output Class Initialized
INFO - 2020-02-25 16:49:36 --> Output Class Initialized
INFO - 2020-02-25 16:49:36 --> Security Class Initialized
INFO - 2020-02-25 16:49:36 --> Security Class Initialized
INFO - 2020-02-25 16:49:36 --> Security Class Initialized
INFO - 2020-02-25 16:49:36 --> Security Class Initialized
INFO - 2020-02-25 16:49:36 --> Security Class Initialized
INFO - 2020-02-25 16:49:36 --> Security Class Initialized
DEBUG - 2020-02-25 16:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:49:36 --> Input Class Initialized
INFO - 2020-02-25 16:49:36 --> Input Class Initialized
INFO - 2020-02-25 16:49:36 --> Input Class Initialized
INFO - 2020-02-25 16:49:36 --> Input Class Initialized
INFO - 2020-02-25 16:49:36 --> Input Class Initialized
INFO - 2020-02-25 16:49:36 --> Input Class Initialized
INFO - 2020-02-25 16:49:36 --> Language Class Initialized
INFO - 2020-02-25 16:49:36 --> Language Class Initialized
INFO - 2020-02-25 16:49:36 --> Language Class Initialized
INFO - 2020-02-25 16:49:36 --> Language Class Initialized
INFO - 2020-02-25 16:49:36 --> Language Class Initialized
INFO - 2020-02-25 16:49:36 --> Language Class Initialized
ERROR - 2020-02-25 16:49:36 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-25 16:49:36 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-25 16:49:36 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-25 16:49:36 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-25 16:49:36 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-25 16:49:36 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-25 16:49:36 --> Config Class Initialized
INFO - 2020-02-25 16:49:36 --> Config Class Initialized
INFO - 2020-02-25 16:49:36 --> Config Class Initialized
INFO - 2020-02-25 16:49:36 --> Config Class Initialized
INFO - 2020-02-25 16:49:36 --> Config Class Initialized
INFO - 2020-02-25 16:49:36 --> Config Class Initialized
INFO - 2020-02-25 16:49:36 --> Hooks Class Initialized
INFO - 2020-02-25 16:49:36 --> Hooks Class Initialized
INFO - 2020-02-25 16:49:36 --> Hooks Class Initialized
INFO - 2020-02-25 16:49:36 --> Hooks Class Initialized
INFO - 2020-02-25 16:49:36 --> Hooks Class Initialized
INFO - 2020-02-25 16:49:36 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:49:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:49:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:49:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:49:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:49:36 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:49:36 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:49:36 --> Utf8 Class Initialized
INFO - 2020-02-25 16:49:36 --> Utf8 Class Initialized
INFO - 2020-02-25 16:49:36 --> Utf8 Class Initialized
INFO - 2020-02-25 16:49:36 --> Utf8 Class Initialized
INFO - 2020-02-25 16:49:36 --> Utf8 Class Initialized
INFO - 2020-02-25 16:49:36 --> Utf8 Class Initialized
INFO - 2020-02-25 16:49:36 --> URI Class Initialized
INFO - 2020-02-25 16:49:36 --> URI Class Initialized
INFO - 2020-02-25 16:49:36 --> URI Class Initialized
INFO - 2020-02-25 16:49:36 --> URI Class Initialized
INFO - 2020-02-25 16:49:36 --> URI Class Initialized
INFO - 2020-02-25 16:49:36 --> URI Class Initialized
INFO - 2020-02-25 16:49:37 --> Router Class Initialized
INFO - 2020-02-25 16:49:37 --> Router Class Initialized
INFO - 2020-02-25 16:49:37 --> Router Class Initialized
INFO - 2020-02-25 16:49:37 --> Router Class Initialized
INFO - 2020-02-25 16:49:37 --> Router Class Initialized
INFO - 2020-02-25 16:49:37 --> Router Class Initialized
INFO - 2020-02-25 16:49:37 --> Output Class Initialized
INFO - 2020-02-25 16:49:37 --> Output Class Initialized
INFO - 2020-02-25 16:49:37 --> Output Class Initialized
INFO - 2020-02-25 16:49:37 --> Output Class Initialized
INFO - 2020-02-25 16:49:37 --> Output Class Initialized
INFO - 2020-02-25 16:49:37 --> Output Class Initialized
INFO - 2020-02-25 16:49:37 --> Security Class Initialized
INFO - 2020-02-25 16:49:37 --> Security Class Initialized
INFO - 2020-02-25 16:49:37 --> Security Class Initialized
INFO - 2020-02-25 16:49:37 --> Security Class Initialized
INFO - 2020-02-25 16:49:37 --> Security Class Initialized
INFO - 2020-02-25 16:49:37 --> Security Class Initialized
DEBUG - 2020-02-25 16:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:49:37 --> Input Class Initialized
INFO - 2020-02-25 16:49:37 --> Input Class Initialized
INFO - 2020-02-25 16:49:37 --> Input Class Initialized
INFO - 2020-02-25 16:49:37 --> Input Class Initialized
INFO - 2020-02-25 16:49:37 --> Input Class Initialized
INFO - 2020-02-25 16:49:37 --> Input Class Initialized
INFO - 2020-02-25 16:49:37 --> Language Class Initialized
INFO - 2020-02-25 16:49:37 --> Language Class Initialized
INFO - 2020-02-25 16:49:37 --> Language Class Initialized
INFO - 2020-02-25 16:49:37 --> Language Class Initialized
INFO - 2020-02-25 16:49:37 --> Language Class Initialized
INFO - 2020-02-25 16:49:37 --> Language Class Initialized
ERROR - 2020-02-25 16:49:37 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-25 16:49:37 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-25 16:49:37 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-25 16:49:37 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-25 16:49:37 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-25 16:49:37 --> Loader Class Initialized
INFO - 2020-02-25 16:49:37 --> Helper loaded: url_helper
INFO - 2020-02-25 16:49:37 --> Config Class Initialized
INFO - 2020-02-25 16:49:37 --> Config Class Initialized
INFO - 2020-02-25 16:49:37 --> Hooks Class Initialized
INFO - 2020-02-25 16:49:37 --> Hooks Class Initialized
INFO - 2020-02-25 16:49:37 --> Helper loaded: string_helper
DEBUG - 2020-02-25 16:49:37 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:49:37 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:49:37 --> Database Driver Class Initialized
INFO - 2020-02-25 16:49:37 --> Utf8 Class Initialized
INFO - 2020-02-25 16:49:37 --> Utf8 Class Initialized
DEBUG - 2020-02-25 16:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:49:37 --> URI Class Initialized
INFO - 2020-02-25 16:49:37 --> URI Class Initialized
INFO - 2020-02-25 16:49:37 --> Controller Class Initialized
INFO - 2020-02-25 16:49:37 --> Router Class Initialized
INFO - 2020-02-25 16:49:37 --> Router Class Initialized
INFO - 2020-02-25 16:49:37 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:49:37 --> Output Class Initialized
INFO - 2020-02-25 16:49:37 --> Output Class Initialized
INFO - 2020-02-25 16:49:37 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:49:37 --> Security Class Initialized
INFO - 2020-02-25 16:49:37 --> Security Class Initialized
INFO - 2020-02-25 16:49:37 --> Model "M_pesan" initialized
DEBUG - 2020-02-25 16:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:49:37 --> Input Class Initialized
INFO - 2020-02-25 16:49:37 --> Input Class Initialized
INFO - 2020-02-25 16:49:37 --> Helper loaded: form_helper
INFO - 2020-02-25 16:49:37 --> Form Validation Class Initialized
INFO - 2020-02-25 16:49:37 --> Language Class Initialized
INFO - 2020-02-25 16:49:37 --> Language Class Initialized
ERROR - 2020-02-25 16:49:37 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-25 16:49:37 --> Loader Class Initialized
ERROR - 2020-02-25 16:49:37 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 16:49:37 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 16:49:37 --> Helper loaded: url_helper
INFO - 2020-02-25 16:49:37 --> Config Class Initialized
INFO - 2020-02-25 16:49:37 --> Hooks Class Initialized
INFO - 2020-02-25 16:49:37 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:49:37 --> Helper loaded: string_helper
INFO - 2020-02-25 16:49:37 --> Final output sent to browser
DEBUG - 2020-02-25 16:49:37 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:49:37 --> Database Driver Class Initialized
INFO - 2020-02-25 16:49:37 --> Utf8 Class Initialized
DEBUG - 2020-02-25 16:49:37 --> Total execution time: 0.2874
DEBUG - 2020-02-25 16:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:49:37 --> URI Class Initialized
INFO - 2020-02-25 16:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:49:37 --> Controller Class Initialized
INFO - 2020-02-25 16:49:37 --> Router Class Initialized
INFO - 2020-02-25 16:49:37 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:49:37 --> Output Class Initialized
INFO - 2020-02-25 16:49:37 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:49:37 --> Security Class Initialized
INFO - 2020-02-25 16:49:37 --> Model "M_pesan" initialized
DEBUG - 2020-02-25 16:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:49:37 --> Input Class Initialized
INFO - 2020-02-25 16:49:37 --> Helper loaded: form_helper
INFO - 2020-02-25 16:49:37 --> Form Validation Class Initialized
INFO - 2020-02-25 16:49:37 --> Language Class Initialized
ERROR - 2020-02-25 16:49:37 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-25 16:49:37 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 16:49:37 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 16:49:37 --> Config Class Initialized
INFO - 2020-02-25 16:49:37 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:49:37 --> Hooks Class Initialized
INFO - 2020-02-25 16:49:37 --> Final output sent to browser
DEBUG - 2020-02-25 16:49:37 --> Total execution time: 0.2655
DEBUG - 2020-02-25 16:49:37 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:49:37 --> Utf8 Class Initialized
INFO - 2020-02-25 16:49:37 --> URI Class Initialized
INFO - 2020-02-25 16:49:37 --> Router Class Initialized
INFO - 2020-02-25 16:49:37 --> Output Class Initialized
INFO - 2020-02-25 16:49:37 --> Security Class Initialized
DEBUG - 2020-02-25 16:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:49:37 --> Input Class Initialized
INFO - 2020-02-25 16:49:37 --> Language Class Initialized
ERROR - 2020-02-25 16:49:37 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-25 16:49:37 --> Config Class Initialized
INFO - 2020-02-25 16:49:37 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:49:37 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:49:37 --> Utf8 Class Initialized
INFO - 2020-02-25 16:49:37 --> URI Class Initialized
INFO - 2020-02-25 16:49:37 --> Router Class Initialized
INFO - 2020-02-25 16:49:37 --> Output Class Initialized
INFO - 2020-02-25 16:49:37 --> Security Class Initialized
DEBUG - 2020-02-25 16:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:49:37 --> Input Class Initialized
INFO - 2020-02-25 16:49:37 --> Language Class Initialized
ERROR - 2020-02-25 16:49:37 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-25 16:49:37 --> Config Class Initialized
INFO - 2020-02-25 16:49:37 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:49:37 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:49:37 --> Utf8 Class Initialized
INFO - 2020-02-25 16:49:37 --> URI Class Initialized
INFO - 2020-02-25 16:49:37 --> Router Class Initialized
INFO - 2020-02-25 16:49:37 --> Output Class Initialized
INFO - 2020-02-25 16:49:37 --> Security Class Initialized
DEBUG - 2020-02-25 16:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:49:37 --> Input Class Initialized
INFO - 2020-02-25 16:49:37 --> Language Class Initialized
ERROR - 2020-02-25 16:49:37 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 16:49:37 --> Config Class Initialized
INFO - 2020-02-25 16:49:37 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:49:37 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:49:37 --> Utf8 Class Initialized
INFO - 2020-02-25 16:49:37 --> URI Class Initialized
INFO - 2020-02-25 16:49:37 --> Router Class Initialized
INFO - 2020-02-25 16:49:37 --> Output Class Initialized
INFO - 2020-02-25 16:49:37 --> Security Class Initialized
DEBUG - 2020-02-25 16:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:49:37 --> Input Class Initialized
INFO - 2020-02-25 16:49:37 --> Language Class Initialized
ERROR - 2020-02-25 16:49:37 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 16:49:37 --> Config Class Initialized
INFO - 2020-02-25 16:49:37 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:49:37 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:49:37 --> Utf8 Class Initialized
INFO - 2020-02-25 16:49:37 --> URI Class Initialized
INFO - 2020-02-25 16:49:37 --> Router Class Initialized
INFO - 2020-02-25 16:49:37 --> Output Class Initialized
INFO - 2020-02-25 16:49:37 --> Security Class Initialized
DEBUG - 2020-02-25 16:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:49:38 --> Input Class Initialized
INFO - 2020-02-25 16:49:38 --> Language Class Initialized
ERROR - 2020-02-25 16:49:38 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-25 16:49:38 --> Config Class Initialized
INFO - 2020-02-25 16:49:38 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:49:38 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:49:38 --> Utf8 Class Initialized
INFO - 2020-02-25 16:49:38 --> URI Class Initialized
INFO - 2020-02-25 16:49:38 --> Router Class Initialized
INFO - 2020-02-25 16:49:38 --> Output Class Initialized
INFO - 2020-02-25 16:49:38 --> Security Class Initialized
DEBUG - 2020-02-25 16:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:49:38 --> Input Class Initialized
INFO - 2020-02-25 16:49:38 --> Language Class Initialized
ERROR - 2020-02-25 16:49:38 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-25 16:49:38 --> Config Class Initialized
INFO - 2020-02-25 16:49:38 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:49:38 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:49:38 --> Utf8 Class Initialized
INFO - 2020-02-25 16:49:38 --> URI Class Initialized
INFO - 2020-02-25 16:49:38 --> Router Class Initialized
INFO - 2020-02-25 16:49:38 --> Output Class Initialized
INFO - 2020-02-25 16:49:38 --> Security Class Initialized
DEBUG - 2020-02-25 16:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:49:38 --> Input Class Initialized
INFO - 2020-02-25 16:49:38 --> Language Class Initialized
ERROR - 2020-02-25 16:49:38 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-25 16:49:38 --> Config Class Initialized
INFO - 2020-02-25 16:49:38 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:49:38 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:49:38 --> Utf8 Class Initialized
INFO - 2020-02-25 16:49:38 --> URI Class Initialized
INFO - 2020-02-25 16:49:38 --> Router Class Initialized
INFO - 2020-02-25 16:49:38 --> Output Class Initialized
INFO - 2020-02-25 16:49:38 --> Security Class Initialized
DEBUG - 2020-02-25 16:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:49:38 --> Input Class Initialized
INFO - 2020-02-25 16:49:38 --> Language Class Initialized
ERROR - 2020-02-25 16:49:38 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-25 16:49:45 --> Config Class Initialized
INFO - 2020-02-25 16:49:45 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:49:45 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:49:45 --> Utf8 Class Initialized
INFO - 2020-02-25 16:49:45 --> URI Class Initialized
INFO - 2020-02-25 16:49:45 --> Router Class Initialized
INFO - 2020-02-25 16:49:45 --> Output Class Initialized
INFO - 2020-02-25 16:49:45 --> Security Class Initialized
DEBUG - 2020-02-25 16:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:49:45 --> Input Class Initialized
INFO - 2020-02-25 16:49:45 --> Language Class Initialized
INFO - 2020-02-25 16:49:45 --> Loader Class Initialized
INFO - 2020-02-25 16:49:45 --> Helper loaded: url_helper
INFO - 2020-02-25 16:49:45 --> Helper loaded: string_helper
INFO - 2020-02-25 16:49:45 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:49:45 --> Controller Class Initialized
INFO - 2020-02-25 16:49:45 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:49:45 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:49:45 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:49:45 --> Helper loaded: form_helper
INFO - 2020-02-25 16:49:45 --> Form Validation Class Initialized
INFO - 2020-02-25 22:49:45 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-25 22:49:45 --> Final output sent to browser
DEBUG - 2020-02-25 22:49:45 --> Total execution time: 0.4303
INFO - 2020-02-25 16:50:29 --> Config Class Initialized
INFO - 2020-02-25 16:50:29 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:50:29 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:50:29 --> Utf8 Class Initialized
INFO - 2020-02-25 16:50:29 --> URI Class Initialized
DEBUG - 2020-02-25 16:50:29 --> No URI present. Default controller set.
INFO - 2020-02-25 16:50:29 --> Router Class Initialized
INFO - 2020-02-25 16:50:29 --> Output Class Initialized
INFO - 2020-02-25 16:50:29 --> Security Class Initialized
DEBUG - 2020-02-25 16:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:50:29 --> Input Class Initialized
INFO - 2020-02-25 16:50:29 --> Language Class Initialized
INFO - 2020-02-25 16:50:29 --> Loader Class Initialized
INFO - 2020-02-25 16:50:29 --> Helper loaded: url_helper
INFO - 2020-02-25 16:50:29 --> Helper loaded: string_helper
INFO - 2020-02-25 16:50:29 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:50:30 --> Controller Class Initialized
INFO - 2020-02-25 16:50:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:50:30 --> Pagination Class Initialized
INFO - 2020-02-25 16:50:30 --> Model "M_show" initialized
INFO - 2020-02-25 16:50:30 --> Helper loaded: form_helper
INFO - 2020-02-25 16:50:30 --> Form Validation Class Initialized
INFO - 2020-02-25 16:50:30 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-25 16:50:30 --> Final output sent to browser
DEBUG - 2020-02-25 16:50:30 --> Total execution time: 0.3256
INFO - 2020-02-25 16:50:30 --> Config Class Initialized
INFO - 2020-02-25 16:50:30 --> Config Class Initialized
INFO - 2020-02-25 16:50:30 --> Hooks Class Initialized
INFO - 2020-02-25 16:50:30 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:50:30 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:50:30 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:50:30 --> Utf8 Class Initialized
INFO - 2020-02-25 16:50:30 --> Utf8 Class Initialized
INFO - 2020-02-25 16:50:30 --> URI Class Initialized
INFO - 2020-02-25 16:50:30 --> URI Class Initialized
INFO - 2020-02-25 16:50:30 --> Router Class Initialized
INFO - 2020-02-25 16:50:30 --> Router Class Initialized
INFO - 2020-02-25 16:50:30 --> Output Class Initialized
INFO - 2020-02-25 16:50:30 --> Output Class Initialized
INFO - 2020-02-25 16:50:30 --> Security Class Initialized
INFO - 2020-02-25 16:50:30 --> Security Class Initialized
DEBUG - 2020-02-25 16:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:50:30 --> Input Class Initialized
INFO - 2020-02-25 16:50:30 --> Input Class Initialized
INFO - 2020-02-25 16:50:30 --> Language Class Initialized
INFO - 2020-02-25 16:50:30 --> Language Class Initialized
ERROR - 2020-02-25 16:50:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-02-25 16:50:30 --> 404 Page Not Found: Assets/js
INFO - 2020-02-25 16:50:31 --> Config Class Initialized
INFO - 2020-02-25 16:50:31 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:50:31 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:50:31 --> Utf8 Class Initialized
INFO - 2020-02-25 16:50:31 --> URI Class Initialized
INFO - 2020-02-25 16:50:31 --> Router Class Initialized
INFO - 2020-02-25 16:50:31 --> Output Class Initialized
INFO - 2020-02-25 16:50:31 --> Security Class Initialized
DEBUG - 2020-02-25 16:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:50:31 --> Input Class Initialized
INFO - 2020-02-25 16:50:31 --> Language Class Initialized
INFO - 2020-02-25 16:50:31 --> Loader Class Initialized
INFO - 2020-02-25 16:50:31 --> Helper loaded: url_helper
INFO - 2020-02-25 16:50:31 --> Helper loaded: string_helper
INFO - 2020-02-25 16:50:31 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:50:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:50:31 --> Controller Class Initialized
INFO - 2020-02-25 16:50:31 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:50:31 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:50:31 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:50:31 --> Helper loaded: form_helper
INFO - 2020-02-25 16:50:31 --> Form Validation Class Initialized
INFO - 2020-02-25 16:50:31 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:50:32 --> Final output sent to browser
DEBUG - 2020-02-25 16:50:32 --> Total execution time: 0.3090
INFO - 2020-02-25 16:50:32 --> Config Class Initialized
INFO - 2020-02-25 16:50:32 --> Config Class Initialized
INFO - 2020-02-25 16:50:32 --> Config Class Initialized
INFO - 2020-02-25 16:50:32 --> Config Class Initialized
INFO - 2020-02-25 16:50:32 --> Config Class Initialized
INFO - 2020-02-25 16:50:32 --> Config Class Initialized
INFO - 2020-02-25 16:50:32 --> Hooks Class Initialized
INFO - 2020-02-25 16:50:32 --> Hooks Class Initialized
INFO - 2020-02-25 16:50:32 --> Hooks Class Initialized
INFO - 2020-02-25 16:50:32 --> Hooks Class Initialized
INFO - 2020-02-25 16:50:32 --> Hooks Class Initialized
INFO - 2020-02-25 16:50:32 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:50:32 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:50:32 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:50:32 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:50:32 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:50:32 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:50:32 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:50:32 --> Utf8 Class Initialized
INFO - 2020-02-25 16:50:32 --> Utf8 Class Initialized
INFO - 2020-02-25 16:50:32 --> Utf8 Class Initialized
INFO - 2020-02-25 16:50:32 --> Utf8 Class Initialized
INFO - 2020-02-25 16:50:32 --> Utf8 Class Initialized
INFO - 2020-02-25 16:50:32 --> Utf8 Class Initialized
INFO - 2020-02-25 16:50:32 --> URI Class Initialized
INFO - 2020-02-25 16:50:32 --> URI Class Initialized
INFO - 2020-02-25 16:50:32 --> URI Class Initialized
INFO - 2020-02-25 16:50:32 --> URI Class Initialized
INFO - 2020-02-25 16:50:32 --> URI Class Initialized
INFO - 2020-02-25 16:50:32 --> URI Class Initialized
INFO - 2020-02-25 16:50:32 --> Router Class Initialized
INFO - 2020-02-25 16:50:32 --> Router Class Initialized
INFO - 2020-02-25 16:50:32 --> Router Class Initialized
INFO - 2020-02-25 16:50:32 --> Router Class Initialized
INFO - 2020-02-25 16:50:32 --> Router Class Initialized
INFO - 2020-02-25 16:50:32 --> Router Class Initialized
INFO - 2020-02-25 16:50:32 --> Output Class Initialized
INFO - 2020-02-25 16:50:32 --> Output Class Initialized
INFO - 2020-02-25 16:50:32 --> Output Class Initialized
INFO - 2020-02-25 16:50:32 --> Output Class Initialized
INFO - 2020-02-25 16:50:32 --> Output Class Initialized
INFO - 2020-02-25 16:50:32 --> Output Class Initialized
INFO - 2020-02-25 16:50:32 --> Security Class Initialized
INFO - 2020-02-25 16:50:32 --> Security Class Initialized
INFO - 2020-02-25 16:50:32 --> Security Class Initialized
INFO - 2020-02-25 16:50:32 --> Security Class Initialized
INFO - 2020-02-25 16:50:32 --> Security Class Initialized
INFO - 2020-02-25 16:50:32 --> Security Class Initialized
DEBUG - 2020-02-25 16:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:50:32 --> Input Class Initialized
INFO - 2020-02-25 16:50:32 --> Input Class Initialized
INFO - 2020-02-25 16:50:32 --> Input Class Initialized
INFO - 2020-02-25 16:50:32 --> Input Class Initialized
INFO - 2020-02-25 16:50:32 --> Input Class Initialized
INFO - 2020-02-25 16:50:32 --> Input Class Initialized
INFO - 2020-02-25 16:50:32 --> Language Class Initialized
INFO - 2020-02-25 16:50:32 --> Language Class Initialized
INFO - 2020-02-25 16:50:32 --> Language Class Initialized
INFO - 2020-02-25 16:50:32 --> Language Class Initialized
INFO - 2020-02-25 16:50:32 --> Language Class Initialized
INFO - 2020-02-25 16:50:32 --> Language Class Initialized
ERROR - 2020-02-25 16:50:32 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-25 16:50:32 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-25 16:50:32 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-25 16:50:32 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-25 16:50:32 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-25 16:50:32 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-25 16:50:32 --> Config Class Initialized
INFO - 2020-02-25 16:50:32 --> Config Class Initialized
INFO - 2020-02-25 16:50:32 --> Config Class Initialized
INFO - 2020-02-25 16:50:32 --> Config Class Initialized
INFO - 2020-02-25 16:50:32 --> Config Class Initialized
INFO - 2020-02-25 16:50:32 --> Config Class Initialized
INFO - 2020-02-25 16:50:32 --> Hooks Class Initialized
INFO - 2020-02-25 16:50:32 --> Hooks Class Initialized
INFO - 2020-02-25 16:50:32 --> Hooks Class Initialized
INFO - 2020-02-25 16:50:32 --> Hooks Class Initialized
INFO - 2020-02-25 16:50:32 --> Hooks Class Initialized
INFO - 2020-02-25 16:50:32 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:50:32 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:50:32 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:50:32 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:50:32 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:50:32 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:50:32 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:50:32 --> Utf8 Class Initialized
INFO - 2020-02-25 16:50:32 --> Utf8 Class Initialized
INFO - 2020-02-25 16:50:32 --> Utf8 Class Initialized
INFO - 2020-02-25 16:50:32 --> Utf8 Class Initialized
INFO - 2020-02-25 16:50:32 --> Utf8 Class Initialized
INFO - 2020-02-25 16:50:32 --> Utf8 Class Initialized
INFO - 2020-02-25 16:50:32 --> URI Class Initialized
INFO - 2020-02-25 16:50:32 --> URI Class Initialized
INFO - 2020-02-25 16:50:32 --> URI Class Initialized
INFO - 2020-02-25 16:50:32 --> URI Class Initialized
INFO - 2020-02-25 16:50:32 --> URI Class Initialized
INFO - 2020-02-25 16:50:32 --> URI Class Initialized
INFO - 2020-02-25 16:50:32 --> Router Class Initialized
INFO - 2020-02-25 16:50:32 --> Router Class Initialized
INFO - 2020-02-25 16:50:32 --> Router Class Initialized
INFO - 2020-02-25 16:50:32 --> Router Class Initialized
INFO - 2020-02-25 16:50:32 --> Router Class Initialized
INFO - 2020-02-25 16:50:32 --> Router Class Initialized
INFO - 2020-02-25 16:50:32 --> Output Class Initialized
INFO - 2020-02-25 16:50:32 --> Output Class Initialized
INFO - 2020-02-25 16:50:32 --> Output Class Initialized
INFO - 2020-02-25 16:50:32 --> Output Class Initialized
INFO - 2020-02-25 16:50:32 --> Output Class Initialized
INFO - 2020-02-25 16:50:32 --> Output Class Initialized
INFO - 2020-02-25 16:50:32 --> Security Class Initialized
INFO - 2020-02-25 16:50:32 --> Security Class Initialized
INFO - 2020-02-25 16:50:32 --> Security Class Initialized
INFO - 2020-02-25 16:50:32 --> Security Class Initialized
INFO - 2020-02-25 16:50:32 --> Security Class Initialized
INFO - 2020-02-25 16:50:32 --> Security Class Initialized
DEBUG - 2020-02-25 16:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:50:32 --> Input Class Initialized
INFO - 2020-02-25 16:50:32 --> Input Class Initialized
INFO - 2020-02-25 16:50:32 --> Input Class Initialized
INFO - 2020-02-25 16:50:32 --> Input Class Initialized
INFO - 2020-02-25 16:50:32 --> Input Class Initialized
INFO - 2020-02-25 16:50:32 --> Input Class Initialized
INFO - 2020-02-25 16:50:32 --> Language Class Initialized
INFO - 2020-02-25 16:50:32 --> Language Class Initialized
INFO - 2020-02-25 16:50:32 --> Language Class Initialized
INFO - 2020-02-25 16:50:32 --> Language Class Initialized
INFO - 2020-02-25 16:50:32 --> Language Class Initialized
INFO - 2020-02-25 16:50:32 --> Language Class Initialized
ERROR - 2020-02-25 16:50:32 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-25 16:50:32 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-25 16:50:32 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-25 16:50:32 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-25 16:50:32 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-25 16:50:32 --> Loader Class Initialized
INFO - 2020-02-25 16:50:32 --> Helper loaded: url_helper
INFO - 2020-02-25 16:50:32 --> Config Class Initialized
INFO - 2020-02-25 16:50:32 --> Config Class Initialized
INFO - 2020-02-25 16:50:32 --> Hooks Class Initialized
INFO - 2020-02-25 16:50:32 --> Hooks Class Initialized
INFO - 2020-02-25 16:50:32 --> Helper loaded: string_helper
DEBUG - 2020-02-25 16:50:32 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:50:32 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:50:32 --> Database Driver Class Initialized
INFO - 2020-02-25 16:50:32 --> Utf8 Class Initialized
INFO - 2020-02-25 16:50:32 --> Utf8 Class Initialized
INFO - 2020-02-25 16:50:32 --> URI Class Initialized
INFO - 2020-02-25 16:50:32 --> URI Class Initialized
DEBUG - 2020-02-25 16:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:50:32 --> Router Class Initialized
INFO - 2020-02-25 16:50:32 --> Router Class Initialized
INFO - 2020-02-25 16:50:32 --> Controller Class Initialized
INFO - 2020-02-25 16:50:32 --> Output Class Initialized
INFO - 2020-02-25 16:50:32 --> Output Class Initialized
INFO - 2020-02-25 16:50:32 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:50:32 --> Security Class Initialized
INFO - 2020-02-25 16:50:32 --> Security Class Initialized
INFO - 2020-02-25 16:50:32 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-25 16:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:50:32 --> Input Class Initialized
INFO - 2020-02-25 16:50:32 --> Input Class Initialized
INFO - 2020-02-25 16:50:32 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:50:32 --> Language Class Initialized
INFO - 2020-02-25 16:50:32 --> Language Class Initialized
INFO - 2020-02-25 16:50:32 --> Helper loaded: form_helper
INFO - 2020-02-25 16:50:32 --> Form Validation Class Initialized
ERROR - 2020-02-25 16:50:32 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-25 16:50:32 --> Loader Class Initialized
INFO - 2020-02-25 16:50:32 --> Helper loaded: url_helper
ERROR - 2020-02-25 16:50:32 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-25 16:50:32 --> Config Class Initialized
INFO - 2020-02-25 16:50:32 --> Hooks Class Initialized
ERROR - 2020-02-25 16:50:32 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 16:50:32 --> Helper loaded: string_helper
INFO - 2020-02-25 16:50:32 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-25 16:50:32 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:50:32 --> Database Driver Class Initialized
INFO - 2020-02-25 16:50:32 --> Utf8 Class Initialized
INFO - 2020-02-25 16:50:32 --> Final output sent to browser
DEBUG - 2020-02-25 16:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-25 16:50:32 --> Total execution time: 0.3122
INFO - 2020-02-25 16:50:32 --> URI Class Initialized
INFO - 2020-02-25 16:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:50:32 --> Router Class Initialized
INFO - 2020-02-25 16:50:32 --> Controller Class Initialized
INFO - 2020-02-25 16:50:32 --> Output Class Initialized
INFO - 2020-02-25 16:50:32 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:50:32 --> Security Class Initialized
INFO - 2020-02-25 16:50:32 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-25 16:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:50:32 --> Input Class Initialized
INFO - 2020-02-25 16:50:32 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:50:32 --> Language Class Initialized
INFO - 2020-02-25 16:50:32 --> Helper loaded: form_helper
INFO - 2020-02-25 16:50:32 --> Form Validation Class Initialized
ERROR - 2020-02-25 16:50:32 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-25 16:50:32 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-25 16:50:32 --> Config Class Initialized
INFO - 2020-02-25 16:50:32 --> Hooks Class Initialized
ERROR - 2020-02-25 16:50:32 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 16:50:32 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-25 16:50:32 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:50:32 --> Utf8 Class Initialized
INFO - 2020-02-25 16:50:32 --> Final output sent to browser
DEBUG - 2020-02-25 16:50:32 --> Total execution time: 0.2978
INFO - 2020-02-25 16:50:32 --> URI Class Initialized
INFO - 2020-02-25 16:50:32 --> Router Class Initialized
INFO - 2020-02-25 16:50:32 --> Output Class Initialized
INFO - 2020-02-25 16:50:32 --> Security Class Initialized
DEBUG - 2020-02-25 16:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:50:32 --> Input Class Initialized
INFO - 2020-02-25 16:50:32 --> Language Class Initialized
ERROR - 2020-02-25 16:50:32 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-25 16:50:32 --> Config Class Initialized
INFO - 2020-02-25 16:50:32 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:50:32 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:50:32 --> Utf8 Class Initialized
INFO - 2020-02-25 16:50:32 --> URI Class Initialized
INFO - 2020-02-25 16:50:32 --> Router Class Initialized
INFO - 2020-02-25 16:50:32 --> Output Class Initialized
INFO - 2020-02-25 16:50:32 --> Security Class Initialized
DEBUG - 2020-02-25 16:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:50:32 --> Input Class Initialized
INFO - 2020-02-25 16:50:32 --> Language Class Initialized
ERROR - 2020-02-25 16:50:32 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 16:50:32 --> Config Class Initialized
INFO - 2020-02-25 16:50:32 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:50:32 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:50:32 --> Utf8 Class Initialized
INFO - 2020-02-25 16:50:33 --> URI Class Initialized
INFO - 2020-02-25 16:50:33 --> Router Class Initialized
INFO - 2020-02-25 16:50:33 --> Output Class Initialized
INFO - 2020-02-25 16:50:33 --> Security Class Initialized
DEBUG - 2020-02-25 16:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:50:33 --> Input Class Initialized
INFO - 2020-02-25 16:50:33 --> Language Class Initialized
ERROR - 2020-02-25 16:50:33 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 16:50:33 --> Config Class Initialized
INFO - 2020-02-25 16:50:33 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:50:33 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:50:33 --> Utf8 Class Initialized
INFO - 2020-02-25 16:50:33 --> URI Class Initialized
INFO - 2020-02-25 16:50:33 --> Router Class Initialized
INFO - 2020-02-25 16:50:33 --> Output Class Initialized
INFO - 2020-02-25 16:50:33 --> Security Class Initialized
DEBUG - 2020-02-25 16:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:50:33 --> Input Class Initialized
INFO - 2020-02-25 16:50:33 --> Language Class Initialized
ERROR - 2020-02-25 16:50:33 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-25 16:50:33 --> Config Class Initialized
INFO - 2020-02-25 16:50:33 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:50:33 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:50:33 --> Utf8 Class Initialized
INFO - 2020-02-25 16:50:33 --> URI Class Initialized
INFO - 2020-02-25 16:50:33 --> Router Class Initialized
INFO - 2020-02-25 16:50:33 --> Output Class Initialized
INFO - 2020-02-25 16:50:33 --> Security Class Initialized
DEBUG - 2020-02-25 16:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:50:33 --> Input Class Initialized
INFO - 2020-02-25 16:50:33 --> Language Class Initialized
ERROR - 2020-02-25 16:50:33 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-25 16:50:33 --> Config Class Initialized
INFO - 2020-02-25 16:50:33 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:50:33 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:50:33 --> Utf8 Class Initialized
INFO - 2020-02-25 16:50:33 --> URI Class Initialized
INFO - 2020-02-25 16:50:33 --> Router Class Initialized
INFO - 2020-02-25 16:50:33 --> Output Class Initialized
INFO - 2020-02-25 16:50:33 --> Security Class Initialized
DEBUG - 2020-02-25 16:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:50:33 --> Input Class Initialized
INFO - 2020-02-25 16:50:33 --> Language Class Initialized
ERROR - 2020-02-25 16:50:33 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-25 16:50:33 --> Config Class Initialized
INFO - 2020-02-25 16:50:33 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:50:33 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:50:33 --> Utf8 Class Initialized
INFO - 2020-02-25 16:50:33 --> URI Class Initialized
INFO - 2020-02-25 16:50:33 --> Router Class Initialized
INFO - 2020-02-25 16:50:33 --> Output Class Initialized
INFO - 2020-02-25 16:50:33 --> Security Class Initialized
DEBUG - 2020-02-25 16:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:50:33 --> Input Class Initialized
INFO - 2020-02-25 16:50:33 --> Language Class Initialized
ERROR - 2020-02-25 16:50:33 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-25 16:50:40 --> Config Class Initialized
INFO - 2020-02-25 16:50:40 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:50:40 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:50:40 --> Utf8 Class Initialized
INFO - 2020-02-25 16:50:40 --> URI Class Initialized
INFO - 2020-02-25 16:50:40 --> Router Class Initialized
INFO - 2020-02-25 16:50:40 --> Output Class Initialized
INFO - 2020-02-25 16:50:40 --> Security Class Initialized
DEBUG - 2020-02-25 16:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:50:40 --> Input Class Initialized
INFO - 2020-02-25 16:50:40 --> Language Class Initialized
INFO - 2020-02-25 16:50:41 --> Loader Class Initialized
INFO - 2020-02-25 16:50:41 --> Helper loaded: url_helper
INFO - 2020-02-25 16:50:41 --> Helper loaded: string_helper
INFO - 2020-02-25 16:50:41 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:50:41 --> Controller Class Initialized
INFO - 2020-02-25 16:50:41 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:50:41 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:50:41 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:50:41 --> Helper loaded: form_helper
INFO - 2020-02-25 16:50:41 --> Form Validation Class Initialized
INFO - 2020-02-25 22:50:41 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-25 22:50:41 --> Final output sent to browser
DEBUG - 2020-02-25 22:50:41 --> Total execution time: 0.4723
INFO - 2020-02-25 16:52:21 --> Config Class Initialized
INFO - 2020-02-25 16:52:21 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:52:21 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:52:21 --> Utf8 Class Initialized
INFO - 2020-02-25 16:52:21 --> URI Class Initialized
DEBUG - 2020-02-25 16:52:21 --> No URI present. Default controller set.
INFO - 2020-02-25 16:52:21 --> Router Class Initialized
INFO - 2020-02-25 16:52:21 --> Output Class Initialized
INFO - 2020-02-25 16:52:21 --> Security Class Initialized
DEBUG - 2020-02-25 16:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:52:21 --> Input Class Initialized
INFO - 2020-02-25 16:52:21 --> Language Class Initialized
INFO - 2020-02-25 16:52:21 --> Loader Class Initialized
INFO - 2020-02-25 16:52:21 --> Helper loaded: url_helper
INFO - 2020-02-25 16:52:21 --> Helper loaded: string_helper
INFO - 2020-02-25 16:52:21 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:52:21 --> Controller Class Initialized
INFO - 2020-02-25 16:52:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:52:21 --> Pagination Class Initialized
INFO - 2020-02-25 16:52:21 --> Model "M_show" initialized
INFO - 2020-02-25 16:52:21 --> Helper loaded: form_helper
INFO - 2020-02-25 16:52:21 --> Form Validation Class Initialized
INFO - 2020-02-25 16:52:21 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-25 16:52:21 --> Final output sent to browser
DEBUG - 2020-02-25 16:52:21 --> Total execution time: 0.3196
INFO - 2020-02-25 16:52:23 --> Config Class Initialized
INFO - 2020-02-25 16:52:23 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:52:23 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:52:23 --> Utf8 Class Initialized
INFO - 2020-02-25 16:52:23 --> URI Class Initialized
INFO - 2020-02-25 16:52:23 --> Router Class Initialized
INFO - 2020-02-25 16:52:23 --> Output Class Initialized
INFO - 2020-02-25 16:52:23 --> Security Class Initialized
DEBUG - 2020-02-25 16:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:52:23 --> Input Class Initialized
INFO - 2020-02-25 16:52:23 --> Language Class Initialized
INFO - 2020-02-25 16:52:23 --> Loader Class Initialized
INFO - 2020-02-25 16:52:23 --> Helper loaded: url_helper
INFO - 2020-02-25 16:52:23 --> Helper loaded: string_helper
INFO - 2020-02-25 16:52:23 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:52:23 --> Controller Class Initialized
INFO - 2020-02-25 16:52:23 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:52:23 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:52:23 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:52:23 --> Helper loaded: form_helper
INFO - 2020-02-25 16:52:23 --> Form Validation Class Initialized
INFO - 2020-02-25 16:52:23 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:52:23 --> Final output sent to browser
DEBUG - 2020-02-25 16:52:23 --> Total execution time: 0.2912
INFO - 2020-02-25 16:52:23 --> Config Class Initialized
INFO - 2020-02-25 16:52:23 --> Config Class Initialized
INFO - 2020-02-25 16:52:23 --> Config Class Initialized
INFO - 2020-02-25 16:52:23 --> Config Class Initialized
INFO - 2020-02-25 16:52:23 --> Config Class Initialized
INFO - 2020-02-25 16:52:23 --> Config Class Initialized
INFO - 2020-02-25 16:52:23 --> Hooks Class Initialized
INFO - 2020-02-25 16:52:23 --> Hooks Class Initialized
INFO - 2020-02-25 16:52:23 --> Hooks Class Initialized
INFO - 2020-02-25 16:52:23 --> Hooks Class Initialized
INFO - 2020-02-25 16:52:23 --> Hooks Class Initialized
INFO - 2020-02-25 16:52:23 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:52:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:52:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:52:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:52:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:52:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:52:23 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:52:23 --> Utf8 Class Initialized
INFO - 2020-02-25 16:52:23 --> Utf8 Class Initialized
INFO - 2020-02-25 16:52:23 --> Utf8 Class Initialized
INFO - 2020-02-25 16:52:23 --> Utf8 Class Initialized
INFO - 2020-02-25 16:52:23 --> Utf8 Class Initialized
INFO - 2020-02-25 16:52:23 --> Utf8 Class Initialized
INFO - 2020-02-25 16:52:23 --> URI Class Initialized
INFO - 2020-02-25 16:52:23 --> URI Class Initialized
INFO - 2020-02-25 16:52:23 --> URI Class Initialized
INFO - 2020-02-25 16:52:23 --> URI Class Initialized
INFO - 2020-02-25 16:52:23 --> URI Class Initialized
INFO - 2020-02-25 16:52:23 --> URI Class Initialized
INFO - 2020-02-25 16:52:23 --> Router Class Initialized
INFO - 2020-02-25 16:52:23 --> Router Class Initialized
INFO - 2020-02-25 16:52:23 --> Router Class Initialized
INFO - 2020-02-25 16:52:23 --> Router Class Initialized
INFO - 2020-02-25 16:52:23 --> Router Class Initialized
INFO - 2020-02-25 16:52:23 --> Router Class Initialized
INFO - 2020-02-25 16:52:23 --> Output Class Initialized
INFO - 2020-02-25 16:52:23 --> Output Class Initialized
INFO - 2020-02-25 16:52:23 --> Output Class Initialized
INFO - 2020-02-25 16:52:23 --> Output Class Initialized
INFO - 2020-02-25 16:52:23 --> Output Class Initialized
INFO - 2020-02-25 16:52:23 --> Output Class Initialized
INFO - 2020-02-25 16:52:23 --> Security Class Initialized
INFO - 2020-02-25 16:52:23 --> Security Class Initialized
INFO - 2020-02-25 16:52:23 --> Security Class Initialized
INFO - 2020-02-25 16:52:23 --> Security Class Initialized
INFO - 2020-02-25 16:52:23 --> Security Class Initialized
INFO - 2020-02-25 16:52:23 --> Security Class Initialized
DEBUG - 2020-02-25 16:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:52:23 --> Input Class Initialized
INFO - 2020-02-25 16:52:23 --> Input Class Initialized
INFO - 2020-02-25 16:52:23 --> Input Class Initialized
INFO - 2020-02-25 16:52:23 --> Input Class Initialized
INFO - 2020-02-25 16:52:23 --> Input Class Initialized
INFO - 2020-02-25 16:52:23 --> Input Class Initialized
INFO - 2020-02-25 16:52:23 --> Language Class Initialized
INFO - 2020-02-25 16:52:23 --> Language Class Initialized
INFO - 2020-02-25 16:52:23 --> Language Class Initialized
INFO - 2020-02-25 16:52:23 --> Language Class Initialized
INFO - 2020-02-25 16:52:23 --> Language Class Initialized
INFO - 2020-02-25 16:52:23 --> Language Class Initialized
ERROR - 2020-02-25 16:52:23 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-25 16:52:23 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-25 16:52:23 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-25 16:52:23 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-25 16:52:23 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-25 16:52:23 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-25 16:52:23 --> Config Class Initialized
INFO - 2020-02-25 16:52:23 --> Config Class Initialized
INFO - 2020-02-25 16:52:23 --> Config Class Initialized
INFO - 2020-02-25 16:52:23 --> Config Class Initialized
INFO - 2020-02-25 16:52:23 --> Config Class Initialized
INFO - 2020-02-25 16:52:23 --> Config Class Initialized
INFO - 2020-02-25 16:52:23 --> Hooks Class Initialized
INFO - 2020-02-25 16:52:23 --> Hooks Class Initialized
INFO - 2020-02-25 16:52:23 --> Hooks Class Initialized
INFO - 2020-02-25 16:52:23 --> Hooks Class Initialized
INFO - 2020-02-25 16:52:23 --> Hooks Class Initialized
INFO - 2020-02-25 16:52:23 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:52:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:52:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:52:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:52:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:52:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:52:23 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:52:23 --> Utf8 Class Initialized
INFO - 2020-02-25 16:52:23 --> Utf8 Class Initialized
INFO - 2020-02-25 16:52:23 --> Utf8 Class Initialized
INFO - 2020-02-25 16:52:23 --> Utf8 Class Initialized
INFO - 2020-02-25 16:52:23 --> Utf8 Class Initialized
INFO - 2020-02-25 16:52:23 --> Utf8 Class Initialized
INFO - 2020-02-25 16:52:23 --> URI Class Initialized
INFO - 2020-02-25 16:52:23 --> URI Class Initialized
INFO - 2020-02-25 16:52:23 --> URI Class Initialized
INFO - 2020-02-25 16:52:23 --> URI Class Initialized
INFO - 2020-02-25 16:52:23 --> URI Class Initialized
INFO - 2020-02-25 16:52:23 --> URI Class Initialized
INFO - 2020-02-25 16:52:23 --> Router Class Initialized
INFO - 2020-02-25 16:52:23 --> Router Class Initialized
INFO - 2020-02-25 16:52:23 --> Router Class Initialized
INFO - 2020-02-25 16:52:23 --> Router Class Initialized
INFO - 2020-02-25 16:52:23 --> Router Class Initialized
INFO - 2020-02-25 16:52:23 --> Router Class Initialized
INFO - 2020-02-25 16:52:23 --> Output Class Initialized
INFO - 2020-02-25 16:52:23 --> Output Class Initialized
INFO - 2020-02-25 16:52:23 --> Output Class Initialized
INFO - 2020-02-25 16:52:23 --> Output Class Initialized
INFO - 2020-02-25 16:52:23 --> Output Class Initialized
INFO - 2020-02-25 16:52:23 --> Output Class Initialized
INFO - 2020-02-25 16:52:23 --> Security Class Initialized
INFO - 2020-02-25 16:52:23 --> Security Class Initialized
INFO - 2020-02-25 16:52:23 --> Security Class Initialized
INFO - 2020-02-25 16:52:23 --> Security Class Initialized
INFO - 2020-02-25 16:52:23 --> Security Class Initialized
INFO - 2020-02-25 16:52:23 --> Security Class Initialized
DEBUG - 2020-02-25 16:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:52:23 --> Input Class Initialized
INFO - 2020-02-25 16:52:23 --> Input Class Initialized
INFO - 2020-02-25 16:52:23 --> Input Class Initialized
INFO - 2020-02-25 16:52:23 --> Input Class Initialized
INFO - 2020-02-25 16:52:23 --> Input Class Initialized
INFO - 2020-02-25 16:52:23 --> Input Class Initialized
INFO - 2020-02-25 16:52:23 --> Language Class Initialized
INFO - 2020-02-25 16:52:23 --> Language Class Initialized
INFO - 2020-02-25 16:52:23 --> Language Class Initialized
INFO - 2020-02-25 16:52:23 --> Language Class Initialized
INFO - 2020-02-25 16:52:23 --> Language Class Initialized
INFO - 2020-02-25 16:52:23 --> Language Class Initialized
ERROR - 2020-02-25 16:52:23 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-25 16:52:23 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-25 16:52:23 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-25 16:52:23 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-25 16:52:23 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-25 16:52:23 --> Loader Class Initialized
INFO - 2020-02-25 16:52:23 --> Helper loaded: url_helper
INFO - 2020-02-25 16:52:23 --> Config Class Initialized
INFO - 2020-02-25 16:52:23 --> Config Class Initialized
INFO - 2020-02-25 16:52:23 --> Hooks Class Initialized
INFO - 2020-02-25 16:52:23 --> Hooks Class Initialized
INFO - 2020-02-25 16:52:23 --> Helper loaded: string_helper
DEBUG - 2020-02-25 16:52:23 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:52:23 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:52:23 --> Database Driver Class Initialized
INFO - 2020-02-25 16:52:23 --> Utf8 Class Initialized
INFO - 2020-02-25 16:52:23 --> Utf8 Class Initialized
INFO - 2020-02-25 16:52:23 --> URI Class Initialized
INFO - 2020-02-25 16:52:23 --> URI Class Initialized
DEBUG - 2020-02-25 16:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:52:23 --> Router Class Initialized
INFO - 2020-02-25 16:52:23 --> Router Class Initialized
INFO - 2020-02-25 16:52:23 --> Controller Class Initialized
INFO - 2020-02-25 16:52:23 --> Output Class Initialized
INFO - 2020-02-25 16:52:23 --> Output Class Initialized
INFO - 2020-02-25 16:52:23 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:52:23 --> Security Class Initialized
INFO - 2020-02-25 16:52:23 --> Security Class Initialized
INFO - 2020-02-25 16:52:23 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-25 16:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:52:23 --> Input Class Initialized
INFO - 2020-02-25 16:52:23 --> Input Class Initialized
INFO - 2020-02-25 16:52:23 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:52:23 --> Language Class Initialized
INFO - 2020-02-25 16:52:23 --> Language Class Initialized
INFO - 2020-02-25 16:52:23 --> Helper loaded: form_helper
INFO - 2020-02-25 16:52:23 --> Form Validation Class Initialized
ERROR - 2020-02-25 16:52:23 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-25 16:52:23 --> Loader Class Initialized
INFO - 2020-02-25 16:52:23 --> Helper loaded: url_helper
ERROR - 2020-02-25 16:52:23 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-25 16:52:23 --> Config Class Initialized
INFO - 2020-02-25 16:52:23 --> Hooks Class Initialized
ERROR - 2020-02-25 16:52:23 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 16:52:23 --> Helper loaded: string_helper
INFO - 2020-02-25 16:52:23 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-25 16:52:23 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:52:23 --> Database Driver Class Initialized
INFO - 2020-02-25 16:52:23 --> Final output sent to browser
INFO - 2020-02-25 16:52:23 --> Utf8 Class Initialized
DEBUG - 2020-02-25 16:52:23 --> Total execution time: 0.3289
INFO - 2020-02-25 16:52:23 --> URI Class Initialized
DEBUG - 2020-02-25 16:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:52:23 --> Router Class Initialized
INFO - 2020-02-25 16:52:23 --> Controller Class Initialized
INFO - 2020-02-25 16:52:23 --> Output Class Initialized
INFO - 2020-02-25 16:52:23 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:52:23 --> Security Class Initialized
INFO - 2020-02-25 16:52:23 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-25 16:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:52:23 --> Input Class Initialized
INFO - 2020-02-25 16:52:23 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:52:24 --> Language Class Initialized
INFO - 2020-02-25 16:52:24 --> Helper loaded: form_helper
INFO - 2020-02-25 16:52:24 --> Form Validation Class Initialized
ERROR - 2020-02-25 16:52:24 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-25 16:52:24 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-25 16:52:24 --> Config Class Initialized
INFO - 2020-02-25 16:52:24 --> Hooks Class Initialized
ERROR - 2020-02-25 16:52:24 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 16:52:24 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-25 16:52:24 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:52:24 --> Utf8 Class Initialized
INFO - 2020-02-25 16:52:24 --> Final output sent to browser
DEBUG - 2020-02-25 16:52:24 --> Total execution time: 0.3230
INFO - 2020-02-25 16:52:24 --> URI Class Initialized
INFO - 2020-02-25 16:52:24 --> Router Class Initialized
INFO - 2020-02-25 16:52:24 --> Output Class Initialized
INFO - 2020-02-25 16:52:24 --> Security Class Initialized
DEBUG - 2020-02-25 16:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:52:24 --> Input Class Initialized
INFO - 2020-02-25 16:52:24 --> Language Class Initialized
ERROR - 2020-02-25 16:52:24 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-25 16:52:24 --> Config Class Initialized
INFO - 2020-02-25 16:52:24 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:52:24 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:52:24 --> Utf8 Class Initialized
INFO - 2020-02-25 16:52:24 --> URI Class Initialized
INFO - 2020-02-25 16:52:24 --> Router Class Initialized
INFO - 2020-02-25 16:52:24 --> Output Class Initialized
INFO - 2020-02-25 16:52:24 --> Security Class Initialized
DEBUG - 2020-02-25 16:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:52:24 --> Input Class Initialized
INFO - 2020-02-25 16:52:24 --> Language Class Initialized
ERROR - 2020-02-25 16:52:24 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 16:52:24 --> Config Class Initialized
INFO - 2020-02-25 16:52:24 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:52:24 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:52:24 --> Utf8 Class Initialized
INFO - 2020-02-25 16:52:24 --> URI Class Initialized
INFO - 2020-02-25 16:52:24 --> Router Class Initialized
INFO - 2020-02-25 16:52:24 --> Output Class Initialized
INFO - 2020-02-25 16:52:24 --> Security Class Initialized
DEBUG - 2020-02-25 16:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:52:24 --> Input Class Initialized
INFO - 2020-02-25 16:52:24 --> Language Class Initialized
ERROR - 2020-02-25 16:52:24 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 16:52:24 --> Config Class Initialized
INFO - 2020-02-25 16:52:24 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:52:24 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:52:24 --> Utf8 Class Initialized
INFO - 2020-02-25 16:52:24 --> URI Class Initialized
INFO - 2020-02-25 16:52:24 --> Router Class Initialized
INFO - 2020-02-25 16:52:24 --> Output Class Initialized
INFO - 2020-02-25 16:52:24 --> Security Class Initialized
DEBUG - 2020-02-25 16:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:52:24 --> Input Class Initialized
INFO - 2020-02-25 16:52:24 --> Language Class Initialized
ERROR - 2020-02-25 16:52:24 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-25 16:52:24 --> Config Class Initialized
INFO - 2020-02-25 16:52:24 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:52:24 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:52:24 --> Utf8 Class Initialized
INFO - 2020-02-25 16:52:24 --> URI Class Initialized
INFO - 2020-02-25 16:52:24 --> Router Class Initialized
INFO - 2020-02-25 16:52:24 --> Output Class Initialized
INFO - 2020-02-25 16:52:24 --> Security Class Initialized
DEBUG - 2020-02-25 16:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:52:24 --> Input Class Initialized
INFO - 2020-02-25 16:52:24 --> Language Class Initialized
ERROR - 2020-02-25 16:52:24 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-25 16:52:24 --> Config Class Initialized
INFO - 2020-02-25 16:52:24 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:52:24 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:52:24 --> Utf8 Class Initialized
INFO - 2020-02-25 16:52:24 --> URI Class Initialized
INFO - 2020-02-25 16:52:24 --> Router Class Initialized
INFO - 2020-02-25 16:52:24 --> Output Class Initialized
INFO - 2020-02-25 16:52:24 --> Security Class Initialized
DEBUG - 2020-02-25 16:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:52:24 --> Input Class Initialized
INFO - 2020-02-25 16:52:24 --> Language Class Initialized
ERROR - 2020-02-25 16:52:24 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-25 16:52:24 --> Config Class Initialized
INFO - 2020-02-25 16:52:24 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:52:24 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:52:24 --> Utf8 Class Initialized
INFO - 2020-02-25 16:52:24 --> URI Class Initialized
INFO - 2020-02-25 16:52:24 --> Router Class Initialized
INFO - 2020-02-25 16:52:25 --> Output Class Initialized
INFO - 2020-02-25 16:52:25 --> Security Class Initialized
DEBUG - 2020-02-25 16:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:52:25 --> Input Class Initialized
INFO - 2020-02-25 16:52:25 --> Language Class Initialized
ERROR - 2020-02-25 16:52:25 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-25 16:52:38 --> Config Class Initialized
INFO - 2020-02-25 16:52:38 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:52:38 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:52:38 --> Utf8 Class Initialized
INFO - 2020-02-25 16:52:38 --> URI Class Initialized
INFO - 2020-02-25 16:52:38 --> Router Class Initialized
INFO - 2020-02-25 16:52:38 --> Output Class Initialized
INFO - 2020-02-25 16:52:38 --> Security Class Initialized
DEBUG - 2020-02-25 16:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:52:38 --> Input Class Initialized
INFO - 2020-02-25 16:52:38 --> Language Class Initialized
INFO - 2020-02-25 16:52:38 --> Loader Class Initialized
INFO - 2020-02-25 16:52:38 --> Helper loaded: url_helper
INFO - 2020-02-25 16:52:38 --> Helper loaded: string_helper
INFO - 2020-02-25 16:52:38 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:52:38 --> Controller Class Initialized
INFO - 2020-02-25 16:52:38 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:52:38 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:52:38 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:52:38 --> Helper loaded: form_helper
INFO - 2020-02-25 16:52:38 --> Form Validation Class Initialized
INFO - 2020-02-25 22:52:38 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-25 22:52:38 --> Final output sent to browser
DEBUG - 2020-02-25 22:52:38 --> Total execution time: 0.4933
INFO - 2020-02-25 16:54:51 --> Config Class Initialized
INFO - 2020-02-25 16:54:51 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:54:51 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:54:51 --> Utf8 Class Initialized
INFO - 2020-02-25 16:54:51 --> URI Class Initialized
DEBUG - 2020-02-25 16:54:51 --> No URI present. Default controller set.
INFO - 2020-02-25 16:54:51 --> Router Class Initialized
INFO - 2020-02-25 16:54:51 --> Output Class Initialized
INFO - 2020-02-25 16:54:51 --> Security Class Initialized
DEBUG - 2020-02-25 16:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:54:51 --> Input Class Initialized
INFO - 2020-02-25 16:54:51 --> Language Class Initialized
INFO - 2020-02-25 16:54:51 --> Loader Class Initialized
INFO - 2020-02-25 16:54:51 --> Helper loaded: url_helper
INFO - 2020-02-25 16:54:51 --> Helper loaded: string_helper
INFO - 2020-02-25 16:54:51 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:54:51 --> Controller Class Initialized
INFO - 2020-02-25 16:54:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 16:54:51 --> Pagination Class Initialized
INFO - 2020-02-25 16:54:51 --> Model "M_show" initialized
INFO - 2020-02-25 16:54:51 --> Helper loaded: form_helper
INFO - 2020-02-25 16:54:51 --> Form Validation Class Initialized
INFO - 2020-02-25 16:54:51 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-25 16:54:51 --> Final output sent to browser
DEBUG - 2020-02-25 16:54:51 --> Total execution time: 0.3195
INFO - 2020-02-25 16:54:51 --> Config Class Initialized
INFO - 2020-02-25 16:54:51 --> Config Class Initialized
INFO - 2020-02-25 16:54:51 --> Hooks Class Initialized
INFO - 2020-02-25 16:54:51 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:54:51 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:54:51 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:54:51 --> Utf8 Class Initialized
INFO - 2020-02-25 16:54:51 --> Utf8 Class Initialized
INFO - 2020-02-25 16:54:51 --> URI Class Initialized
INFO - 2020-02-25 16:54:51 --> URI Class Initialized
INFO - 2020-02-25 16:54:51 --> Router Class Initialized
INFO - 2020-02-25 16:54:51 --> Router Class Initialized
INFO - 2020-02-25 16:54:51 --> Output Class Initialized
INFO - 2020-02-25 16:54:51 --> Output Class Initialized
INFO - 2020-02-25 16:54:51 --> Security Class Initialized
INFO - 2020-02-25 16:54:51 --> Security Class Initialized
DEBUG - 2020-02-25 16:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:54:51 --> Input Class Initialized
INFO - 2020-02-25 16:54:51 --> Input Class Initialized
INFO - 2020-02-25 16:54:51 --> Language Class Initialized
INFO - 2020-02-25 16:54:51 --> Language Class Initialized
ERROR - 2020-02-25 16:54:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-02-25 16:54:51 --> 404 Page Not Found: Assets/js
INFO - 2020-02-25 16:54:53 --> Config Class Initialized
INFO - 2020-02-25 16:54:53 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:54:53 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:54:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:54:53 --> URI Class Initialized
INFO - 2020-02-25 16:54:53 --> Router Class Initialized
INFO - 2020-02-25 16:54:53 --> Output Class Initialized
INFO - 2020-02-25 16:54:53 --> Security Class Initialized
DEBUG - 2020-02-25 16:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:54:53 --> Input Class Initialized
INFO - 2020-02-25 16:54:53 --> Language Class Initialized
INFO - 2020-02-25 16:54:53 --> Loader Class Initialized
INFO - 2020-02-25 16:54:53 --> Helper loaded: url_helper
INFO - 2020-02-25 16:54:53 --> Helper loaded: string_helper
INFO - 2020-02-25 16:54:53 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:54:53 --> Controller Class Initialized
INFO - 2020-02-25 16:54:53 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:54:53 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:54:53 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:54:53 --> Helper loaded: form_helper
INFO - 2020-02-25 16:54:53 --> Form Validation Class Initialized
INFO - 2020-02-25 16:54:53 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:54:53 --> Final output sent to browser
DEBUG - 2020-02-25 16:54:53 --> Total execution time: 0.3248
INFO - 2020-02-25 16:54:53 --> Config Class Initialized
INFO - 2020-02-25 16:54:53 --> Config Class Initialized
INFO - 2020-02-25 16:54:53 --> Config Class Initialized
INFO - 2020-02-25 16:54:53 --> Config Class Initialized
INFO - 2020-02-25 16:54:53 --> Config Class Initialized
INFO - 2020-02-25 16:54:53 --> Config Class Initialized
INFO - 2020-02-25 16:54:53 --> Hooks Class Initialized
INFO - 2020-02-25 16:54:53 --> Hooks Class Initialized
INFO - 2020-02-25 16:54:53 --> Hooks Class Initialized
INFO - 2020-02-25 16:54:53 --> Hooks Class Initialized
INFO - 2020-02-25 16:54:53 --> Hooks Class Initialized
INFO - 2020-02-25 16:54:53 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:54:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:54:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:54:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:54:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:54:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:54:53 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:54:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:54:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:54:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:54:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:54:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:54:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:54:53 --> URI Class Initialized
INFO - 2020-02-25 16:54:53 --> URI Class Initialized
INFO - 2020-02-25 16:54:53 --> URI Class Initialized
INFO - 2020-02-25 16:54:53 --> URI Class Initialized
INFO - 2020-02-25 16:54:53 --> URI Class Initialized
INFO - 2020-02-25 16:54:53 --> URI Class Initialized
INFO - 2020-02-25 16:54:53 --> Router Class Initialized
INFO - 2020-02-25 16:54:53 --> Router Class Initialized
INFO - 2020-02-25 16:54:53 --> Router Class Initialized
INFO - 2020-02-25 16:54:53 --> Router Class Initialized
INFO - 2020-02-25 16:54:53 --> Router Class Initialized
INFO - 2020-02-25 16:54:53 --> Router Class Initialized
INFO - 2020-02-25 16:54:53 --> Output Class Initialized
INFO - 2020-02-25 16:54:53 --> Output Class Initialized
INFO - 2020-02-25 16:54:53 --> Output Class Initialized
INFO - 2020-02-25 16:54:53 --> Output Class Initialized
INFO - 2020-02-25 16:54:53 --> Output Class Initialized
INFO - 2020-02-25 16:54:53 --> Output Class Initialized
INFO - 2020-02-25 16:54:53 --> Security Class Initialized
INFO - 2020-02-25 16:54:53 --> Security Class Initialized
INFO - 2020-02-25 16:54:53 --> Security Class Initialized
INFO - 2020-02-25 16:54:53 --> Security Class Initialized
INFO - 2020-02-25 16:54:53 --> Security Class Initialized
INFO - 2020-02-25 16:54:53 --> Security Class Initialized
DEBUG - 2020-02-25 16:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:54:53 --> Input Class Initialized
INFO - 2020-02-25 16:54:53 --> Input Class Initialized
INFO - 2020-02-25 16:54:53 --> Input Class Initialized
INFO - 2020-02-25 16:54:53 --> Input Class Initialized
INFO - 2020-02-25 16:54:53 --> Input Class Initialized
INFO - 2020-02-25 16:54:53 --> Input Class Initialized
INFO - 2020-02-25 16:54:53 --> Language Class Initialized
INFO - 2020-02-25 16:54:53 --> Language Class Initialized
INFO - 2020-02-25 16:54:53 --> Language Class Initialized
INFO - 2020-02-25 16:54:53 --> Language Class Initialized
INFO - 2020-02-25 16:54:53 --> Language Class Initialized
INFO - 2020-02-25 16:54:53 --> Language Class Initialized
ERROR - 2020-02-25 16:54:53 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-25 16:54:53 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-25 16:54:53 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-25 16:54:53 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-25 16:54:53 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-25 16:54:53 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 16:54:53 --> Config Class Initialized
INFO - 2020-02-25 16:54:53 --> Config Class Initialized
INFO - 2020-02-25 16:54:53 --> Config Class Initialized
INFO - 2020-02-25 16:54:53 --> Config Class Initialized
INFO - 2020-02-25 16:54:53 --> Config Class Initialized
INFO - 2020-02-25 16:54:53 --> Config Class Initialized
INFO - 2020-02-25 16:54:53 --> Hooks Class Initialized
INFO - 2020-02-25 16:54:53 --> Hooks Class Initialized
INFO - 2020-02-25 16:54:53 --> Hooks Class Initialized
INFO - 2020-02-25 16:54:53 --> Hooks Class Initialized
INFO - 2020-02-25 16:54:53 --> Hooks Class Initialized
INFO - 2020-02-25 16:54:53 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:54:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:54:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:54:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:54:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:54:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:54:53 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:54:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:54:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:54:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:54:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:54:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:54:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:54:53 --> URI Class Initialized
INFO - 2020-02-25 16:54:53 --> URI Class Initialized
INFO - 2020-02-25 16:54:53 --> URI Class Initialized
INFO - 2020-02-25 16:54:53 --> URI Class Initialized
INFO - 2020-02-25 16:54:53 --> URI Class Initialized
INFO - 2020-02-25 16:54:53 --> URI Class Initialized
INFO - 2020-02-25 16:54:53 --> Router Class Initialized
INFO - 2020-02-25 16:54:53 --> Router Class Initialized
INFO - 2020-02-25 16:54:53 --> Router Class Initialized
INFO - 2020-02-25 16:54:53 --> Router Class Initialized
INFO - 2020-02-25 16:54:53 --> Router Class Initialized
INFO - 2020-02-25 16:54:53 --> Router Class Initialized
INFO - 2020-02-25 16:54:53 --> Output Class Initialized
INFO - 2020-02-25 16:54:53 --> Output Class Initialized
INFO - 2020-02-25 16:54:53 --> Output Class Initialized
INFO - 2020-02-25 16:54:53 --> Output Class Initialized
INFO - 2020-02-25 16:54:53 --> Output Class Initialized
INFO - 2020-02-25 16:54:53 --> Output Class Initialized
INFO - 2020-02-25 16:54:53 --> Security Class Initialized
INFO - 2020-02-25 16:54:53 --> Security Class Initialized
INFO - 2020-02-25 16:54:53 --> Security Class Initialized
INFO - 2020-02-25 16:54:53 --> Security Class Initialized
INFO - 2020-02-25 16:54:53 --> Security Class Initialized
INFO - 2020-02-25 16:54:53 --> Security Class Initialized
DEBUG - 2020-02-25 16:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:54:53 --> Input Class Initialized
INFO - 2020-02-25 16:54:53 --> Input Class Initialized
INFO - 2020-02-25 16:54:53 --> Input Class Initialized
INFO - 2020-02-25 16:54:53 --> Input Class Initialized
INFO - 2020-02-25 16:54:53 --> Input Class Initialized
INFO - 2020-02-25 16:54:53 --> Input Class Initialized
INFO - 2020-02-25 16:54:53 --> Language Class Initialized
INFO - 2020-02-25 16:54:53 --> Language Class Initialized
INFO - 2020-02-25 16:54:53 --> Language Class Initialized
INFO - 2020-02-25 16:54:53 --> Language Class Initialized
INFO - 2020-02-25 16:54:53 --> Language Class Initialized
INFO - 2020-02-25 16:54:53 --> Language Class Initialized
ERROR - 2020-02-25 16:54:53 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-25 16:54:53 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-25 16:54:53 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-25 16:54:53 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-25 16:54:53 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 16:54:53 --> Loader Class Initialized
INFO - 2020-02-25 16:54:53 --> Helper loaded: url_helper
INFO - 2020-02-25 16:54:53 --> Config Class Initialized
INFO - 2020-02-25 16:54:53 --> Config Class Initialized
INFO - 2020-02-25 16:54:53 --> Hooks Class Initialized
INFO - 2020-02-25 16:54:53 --> Hooks Class Initialized
INFO - 2020-02-25 16:54:53 --> Helper loaded: string_helper
DEBUG - 2020-02-25 16:54:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:54:53 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:54:53 --> Database Driver Class Initialized
INFO - 2020-02-25 16:54:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:54:53 --> Utf8 Class Initialized
DEBUG - 2020-02-25 16:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:54:53 --> URI Class Initialized
INFO - 2020-02-25 16:54:53 --> URI Class Initialized
INFO - 2020-02-25 16:54:53 --> Controller Class Initialized
INFO - 2020-02-25 16:54:53 --> Router Class Initialized
INFO - 2020-02-25 16:54:53 --> Router Class Initialized
INFO - 2020-02-25 16:54:53 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:54:53 --> Output Class Initialized
INFO - 2020-02-25 16:54:53 --> Output Class Initialized
INFO - 2020-02-25 16:54:53 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:54:53 --> Security Class Initialized
INFO - 2020-02-25 16:54:53 --> Security Class Initialized
INFO - 2020-02-25 16:54:53 --> Model "M_pesan" initialized
DEBUG - 2020-02-25 16:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:54:53 --> Input Class Initialized
INFO - 2020-02-25 16:54:53 --> Input Class Initialized
INFO - 2020-02-25 16:54:53 --> Helper loaded: form_helper
INFO - 2020-02-25 16:54:53 --> Form Validation Class Initialized
INFO - 2020-02-25 16:54:53 --> Language Class Initialized
INFO - 2020-02-25 16:54:53 --> Language Class Initialized
ERROR - 2020-02-25 16:54:53 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-25 16:54:53 --> Loader Class Initialized
ERROR - 2020-02-25 16:54:53 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 16:54:53 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 16:54:53 --> Helper loaded: url_helper
INFO - 2020-02-25 16:54:53 --> Config Class Initialized
INFO - 2020-02-25 16:54:53 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:54:53 --> Helper loaded: string_helper
INFO - 2020-02-25 16:54:53 --> Hooks Class Initialized
INFO - 2020-02-25 16:54:53 --> Final output sent to browser
INFO - 2020-02-25 16:54:53 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:54:53 --> Total execution time: 0.3530
DEBUG - 2020-02-25 16:54:53 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:54:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:54:53 --> Controller Class Initialized
INFO - 2020-02-25 16:54:53 --> URI Class Initialized
INFO - 2020-02-25 16:54:53 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:54:53 --> Router Class Initialized
INFO - 2020-02-25 16:54:53 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:54:54 --> Output Class Initialized
INFO - 2020-02-25 16:54:54 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:54:54 --> Security Class Initialized
DEBUG - 2020-02-25 16:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:54:54 --> Helper loaded: form_helper
INFO - 2020-02-25 16:54:54 --> Input Class Initialized
INFO - 2020-02-25 16:54:54 --> Form Validation Class Initialized
INFO - 2020-02-25 16:54:54 --> Language Class Initialized
ERROR - 2020-02-25 16:54:54 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 16:54:54 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-25 16:54:54 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-25 16:54:54 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:54:54 --> Config Class Initialized
INFO - 2020-02-25 16:54:54 --> Hooks Class Initialized
INFO - 2020-02-25 16:54:54 --> Final output sent to browser
DEBUG - 2020-02-25 16:54:54 --> Total execution time: 0.3274
DEBUG - 2020-02-25 16:54:54 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:54:54 --> Utf8 Class Initialized
INFO - 2020-02-25 16:54:54 --> URI Class Initialized
INFO - 2020-02-25 16:54:54 --> Router Class Initialized
INFO - 2020-02-25 16:54:54 --> Output Class Initialized
INFO - 2020-02-25 16:54:54 --> Security Class Initialized
DEBUG - 2020-02-25 16:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:54:54 --> Input Class Initialized
INFO - 2020-02-25 16:54:54 --> Language Class Initialized
ERROR - 2020-02-25 16:54:54 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-25 16:54:54 --> Config Class Initialized
INFO - 2020-02-25 16:54:54 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:54:54 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:54:54 --> Utf8 Class Initialized
INFO - 2020-02-25 16:54:54 --> URI Class Initialized
INFO - 2020-02-25 16:54:54 --> Router Class Initialized
INFO - 2020-02-25 16:54:54 --> Output Class Initialized
INFO - 2020-02-25 16:54:54 --> Security Class Initialized
DEBUG - 2020-02-25 16:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:54:54 --> Input Class Initialized
INFO - 2020-02-25 16:54:54 --> Language Class Initialized
ERROR - 2020-02-25 16:54:54 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 16:54:54 --> Config Class Initialized
INFO - 2020-02-25 16:54:54 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:54:54 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:54:54 --> Utf8 Class Initialized
INFO - 2020-02-25 16:54:54 --> URI Class Initialized
INFO - 2020-02-25 16:54:54 --> Router Class Initialized
INFO - 2020-02-25 16:54:54 --> Output Class Initialized
INFO - 2020-02-25 16:54:54 --> Security Class Initialized
DEBUG - 2020-02-25 16:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:54:54 --> Input Class Initialized
INFO - 2020-02-25 16:54:54 --> Language Class Initialized
ERROR - 2020-02-25 16:54:54 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 16:54:54 --> Config Class Initialized
INFO - 2020-02-25 16:54:54 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:54:54 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:54:54 --> Utf8 Class Initialized
INFO - 2020-02-25 16:54:54 --> URI Class Initialized
INFO - 2020-02-25 16:54:54 --> Router Class Initialized
INFO - 2020-02-25 16:54:54 --> Output Class Initialized
INFO - 2020-02-25 16:54:54 --> Security Class Initialized
DEBUG - 2020-02-25 16:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:54:54 --> Input Class Initialized
INFO - 2020-02-25 16:54:54 --> Language Class Initialized
ERROR - 2020-02-25 16:54:54 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-25 16:54:54 --> Config Class Initialized
INFO - 2020-02-25 16:54:54 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:54:54 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:54:54 --> Utf8 Class Initialized
INFO - 2020-02-25 16:54:54 --> URI Class Initialized
INFO - 2020-02-25 16:54:54 --> Router Class Initialized
INFO - 2020-02-25 16:54:54 --> Output Class Initialized
INFO - 2020-02-25 16:54:54 --> Security Class Initialized
DEBUG - 2020-02-25 16:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:54:54 --> Input Class Initialized
INFO - 2020-02-25 16:54:54 --> Language Class Initialized
ERROR - 2020-02-25 16:54:54 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-25 16:54:54 --> Config Class Initialized
INFO - 2020-02-25 16:54:54 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:54:54 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:54:54 --> Utf8 Class Initialized
INFO - 2020-02-25 16:54:54 --> URI Class Initialized
INFO - 2020-02-25 16:54:54 --> Router Class Initialized
INFO - 2020-02-25 16:54:55 --> Output Class Initialized
INFO - 2020-02-25 16:54:55 --> Security Class Initialized
DEBUG - 2020-02-25 16:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:54:55 --> Input Class Initialized
INFO - 2020-02-25 16:54:55 --> Language Class Initialized
ERROR - 2020-02-25 16:54:55 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-25 16:54:55 --> Config Class Initialized
INFO - 2020-02-25 16:54:55 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:54:55 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:54:55 --> Utf8 Class Initialized
INFO - 2020-02-25 16:54:55 --> URI Class Initialized
INFO - 2020-02-25 16:54:55 --> Router Class Initialized
INFO - 2020-02-25 16:54:55 --> Output Class Initialized
INFO - 2020-02-25 16:54:55 --> Security Class Initialized
DEBUG - 2020-02-25 16:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:54:55 --> Input Class Initialized
INFO - 2020-02-25 16:54:55 --> Language Class Initialized
ERROR - 2020-02-25 16:54:55 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-25 16:55:05 --> Config Class Initialized
INFO - 2020-02-25 16:55:05 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:55:05 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:55:05 --> Utf8 Class Initialized
INFO - 2020-02-25 16:55:05 --> URI Class Initialized
INFO - 2020-02-25 16:55:05 --> Router Class Initialized
INFO - 2020-02-25 16:55:05 --> Output Class Initialized
INFO - 2020-02-25 16:55:05 --> Security Class Initialized
DEBUG - 2020-02-25 16:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:55:05 --> Input Class Initialized
INFO - 2020-02-25 16:55:05 --> Language Class Initialized
INFO - 2020-02-25 16:55:05 --> Loader Class Initialized
INFO - 2020-02-25 16:55:05 --> Helper loaded: url_helper
INFO - 2020-02-25 16:55:05 --> Helper loaded: string_helper
INFO - 2020-02-25 16:55:06 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:55:06 --> Controller Class Initialized
INFO - 2020-02-25 16:55:06 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:55:06 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:55:06 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:55:06 --> Helper loaded: form_helper
INFO - 2020-02-25 16:55:06 --> Form Validation Class Initialized
ERROR - 2020-02-25 16:55:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'SELECT max(id_pemesanan) as maxKode FROM pemesanan' at line 2 - Invalid query: SELECT *
FROM SELECT max(id_pemesanan) as maxKode FROM pemesanan
INFO - 2020-02-25 16:55:06 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-25 16:55:22 --> Config Class Initialized
INFO - 2020-02-25 16:55:22 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:55:22 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:55:22 --> Utf8 Class Initialized
INFO - 2020-02-25 16:55:22 --> URI Class Initialized
INFO - 2020-02-25 16:55:22 --> Router Class Initialized
INFO - 2020-02-25 16:55:22 --> Output Class Initialized
INFO - 2020-02-25 16:55:22 --> Security Class Initialized
DEBUG - 2020-02-25 16:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:55:22 --> Input Class Initialized
INFO - 2020-02-25 16:55:22 --> Language Class Initialized
INFO - 2020-02-25 16:55:22 --> Loader Class Initialized
INFO - 2020-02-25 16:55:22 --> Helper loaded: url_helper
INFO - 2020-02-25 16:55:22 --> Helper loaded: string_helper
INFO - 2020-02-25 16:55:22 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:55:22 --> Controller Class Initialized
INFO - 2020-02-25 16:55:22 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:55:22 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:55:22 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:55:22 --> Helper loaded: form_helper
INFO - 2020-02-25 16:55:22 --> Form Validation Class Initialized
ERROR - 2020-02-25 16:55:22 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 70
ERROR - 2020-02-25 16:55:22 --> Severity: Notice --> Undefined index: no_identitas C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 71
ERROR - 2020-02-25 16:55:22 --> Severity: Notice --> Undefined index: no_hp C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 72
ERROR - 2020-02-25 16:55:22 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 73
ERROR - 2020-02-25 16:55:22 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 81
ERROR - 2020-02-25 16:55:23 --> Severity: Notice --> Undefined index: no_identitas C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 82
ERROR - 2020-02-25 16:55:23 --> Severity: Notice --> Undefined index: no_hp C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 83
ERROR - 2020-02-25 16:55:23 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 84
ERROR - 2020-02-25 16:55:23 --> Query error: Column 'nama' cannot be null - Invalid query: INSERT INTO `pengunjung` (`nama`, `no_identitas`, `no_hp`, `email`) VALUES (NULL, NULL, NULL, NULL)
INFO - 2020-02-25 16:55:23 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-02-25 16:55:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\roadshow\system\core\Exceptions.php:271) C:\xampp\htdocs\roadshow\system\core\Common.php 570
INFO - 2020-02-25 16:55:24 --> Config Class Initialized
INFO - 2020-02-25 16:55:24 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:55:24 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:55:24 --> Utf8 Class Initialized
INFO - 2020-02-25 16:55:24 --> URI Class Initialized
INFO - 2020-02-25 16:55:24 --> Router Class Initialized
INFO - 2020-02-25 16:55:24 --> Output Class Initialized
INFO - 2020-02-25 16:55:24 --> Security Class Initialized
DEBUG - 2020-02-25 16:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:55:24 --> Input Class Initialized
INFO - 2020-02-25 16:55:24 --> Language Class Initialized
INFO - 2020-02-25 16:55:24 --> Loader Class Initialized
INFO - 2020-02-25 16:55:24 --> Helper loaded: url_helper
INFO - 2020-02-25 16:55:24 --> Helper loaded: string_helper
INFO - 2020-02-25 16:55:24 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:55:24 --> Controller Class Initialized
INFO - 2020-02-25 16:55:24 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:55:24 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:55:24 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:55:24 --> Helper loaded: form_helper
INFO - 2020-02-25 16:55:24 --> Form Validation Class Initialized
INFO - 2020-02-25 16:55:24 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:55:24 --> Final output sent to browser
DEBUG - 2020-02-25 16:55:24 --> Total execution time: 0.3387
INFO - 2020-02-25 16:55:24 --> Config Class Initialized
INFO - 2020-02-25 16:55:24 --> Config Class Initialized
INFO - 2020-02-25 16:55:24 --> Hooks Class Initialized
INFO - 2020-02-25 16:55:24 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:55:24 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:55:24 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:55:24 --> Utf8 Class Initialized
INFO - 2020-02-25 16:55:24 --> Utf8 Class Initialized
INFO - 2020-02-25 16:55:24 --> URI Class Initialized
INFO - 2020-02-25 16:55:24 --> URI Class Initialized
INFO - 2020-02-25 16:55:24 --> Router Class Initialized
INFO - 2020-02-25 16:55:24 --> Router Class Initialized
INFO - 2020-02-25 16:55:25 --> Output Class Initialized
INFO - 2020-02-25 16:55:25 --> Output Class Initialized
INFO - 2020-02-25 16:55:25 --> Security Class Initialized
INFO - 2020-02-25 16:55:25 --> Security Class Initialized
DEBUG - 2020-02-25 16:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:55:25 --> Input Class Initialized
INFO - 2020-02-25 16:55:25 --> Input Class Initialized
INFO - 2020-02-25 16:55:25 --> Language Class Initialized
INFO - 2020-02-25 16:55:25 --> Language Class Initialized
INFO - 2020-02-25 16:55:25 --> Loader Class Initialized
INFO - 2020-02-25 16:55:25 --> Loader Class Initialized
INFO - 2020-02-25 16:55:25 --> Helper loaded: url_helper
INFO - 2020-02-25 16:55:25 --> Helper loaded: url_helper
INFO - 2020-02-25 16:55:25 --> Helper loaded: string_helper
INFO - 2020-02-25 16:55:25 --> Helper loaded: string_helper
INFO - 2020-02-25 16:55:25 --> Database Driver Class Initialized
INFO - 2020-02-25 16:55:25 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-25 16:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:55:25 --> Controller Class Initialized
INFO - 2020-02-25 16:55:25 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:55:25 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:55:25 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:55:25 --> Helper loaded: form_helper
INFO - 2020-02-25 16:55:25 --> Form Validation Class Initialized
ERROR - 2020-02-25 16:55:25 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 16:55:25 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 16:55:25 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:55:25 --> Final output sent to browser
DEBUG - 2020-02-25 16:55:25 --> Total execution time: 0.3486
INFO - 2020-02-25 16:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:55:25 --> Controller Class Initialized
INFO - 2020-02-25 16:55:25 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:55:25 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:55:25 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:55:25 --> Helper loaded: form_helper
INFO - 2020-02-25 16:55:25 --> Form Validation Class Initialized
ERROR - 2020-02-25 16:55:25 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 16:55:25 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 16:55:25 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:55:25 --> Final output sent to browser
DEBUG - 2020-02-25 16:55:25 --> Total execution time: 0.4858
INFO - 2020-02-25 16:55:47 --> Config Class Initialized
INFO - 2020-02-25 16:55:47 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:55:47 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:55:47 --> Utf8 Class Initialized
INFO - 2020-02-25 16:55:47 --> URI Class Initialized
INFO - 2020-02-25 16:55:47 --> Router Class Initialized
INFO - 2020-02-25 16:55:47 --> Output Class Initialized
INFO - 2020-02-25 16:55:47 --> Security Class Initialized
DEBUG - 2020-02-25 16:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:55:47 --> Input Class Initialized
INFO - 2020-02-25 16:55:47 --> Language Class Initialized
INFO - 2020-02-25 16:55:47 --> Loader Class Initialized
INFO - 2020-02-25 16:55:47 --> Helper loaded: url_helper
INFO - 2020-02-25 16:55:47 --> Helper loaded: string_helper
INFO - 2020-02-25 16:55:47 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:55:47 --> Controller Class Initialized
INFO - 2020-02-25 16:55:47 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:55:47 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:55:47 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:55:47 --> Helper loaded: form_helper
INFO - 2020-02-25 16:55:47 --> Form Validation Class Initialized
INFO - 2020-02-25 16:55:47 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:55:47 --> Final output sent to browser
DEBUG - 2020-02-25 16:55:47 --> Total execution time: 0.3386
INFO - 2020-02-25 16:55:47 --> Config Class Initialized
INFO - 2020-02-25 16:55:47 --> Config Class Initialized
INFO - 2020-02-25 16:55:47 --> Config Class Initialized
INFO - 2020-02-25 16:55:47 --> Hooks Class Initialized
INFO - 2020-02-25 16:55:47 --> Hooks Class Initialized
INFO - 2020-02-25 16:55:47 --> Hooks Class Initialized
INFO - 2020-02-25 16:55:47 --> Config Class Initialized
INFO - 2020-02-25 16:55:47 --> Config Class Initialized
INFO - 2020-02-25 16:55:47 --> Config Class Initialized
INFO - 2020-02-25 16:55:47 --> Hooks Class Initialized
INFO - 2020-02-25 16:55:47 --> Hooks Class Initialized
INFO - 2020-02-25 16:55:47 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:55:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:55:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:55:47 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:55:47 --> Utf8 Class Initialized
INFO - 2020-02-25 16:55:47 --> Utf8 Class Initialized
INFO - 2020-02-25 16:55:47 --> Utf8 Class Initialized
DEBUG - 2020-02-25 16:55:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:55:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:55:47 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:55:47 --> Utf8 Class Initialized
INFO - 2020-02-25 16:55:47 --> Utf8 Class Initialized
INFO - 2020-02-25 16:55:47 --> Utf8 Class Initialized
INFO - 2020-02-25 16:55:47 --> URI Class Initialized
INFO - 2020-02-25 16:55:47 --> URI Class Initialized
INFO - 2020-02-25 16:55:47 --> URI Class Initialized
INFO - 2020-02-25 16:55:47 --> URI Class Initialized
INFO - 2020-02-25 16:55:47 --> URI Class Initialized
INFO - 2020-02-25 16:55:47 --> URI Class Initialized
INFO - 2020-02-25 16:55:47 --> Router Class Initialized
INFO - 2020-02-25 16:55:47 --> Router Class Initialized
INFO - 2020-02-25 16:55:47 --> Router Class Initialized
INFO - 2020-02-25 16:55:47 --> Output Class Initialized
INFO - 2020-02-25 16:55:47 --> Output Class Initialized
INFO - 2020-02-25 16:55:47 --> Router Class Initialized
INFO - 2020-02-25 16:55:47 --> Router Class Initialized
INFO - 2020-02-25 16:55:47 --> Router Class Initialized
INFO - 2020-02-25 16:55:47 --> Output Class Initialized
INFO - 2020-02-25 16:55:47 --> Security Class Initialized
INFO - 2020-02-25 16:55:47 --> Security Class Initialized
INFO - 2020-02-25 16:55:47 --> Security Class Initialized
INFO - 2020-02-25 16:55:47 --> Output Class Initialized
INFO - 2020-02-25 16:55:47 --> Output Class Initialized
INFO - 2020-02-25 16:55:47 --> Output Class Initialized
DEBUG - 2020-02-25 16:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:55:47 --> Security Class Initialized
DEBUG - 2020-02-25 16:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:55:47 --> Security Class Initialized
INFO - 2020-02-25 16:55:47 --> Security Class Initialized
INFO - 2020-02-25 16:55:47 --> Input Class Initialized
INFO - 2020-02-25 16:55:47 --> Input Class Initialized
INFO - 2020-02-25 16:55:47 --> Input Class Initialized
DEBUG - 2020-02-25 16:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:55:47 --> Input Class Initialized
INFO - 2020-02-25 16:55:47 --> Input Class Initialized
INFO - 2020-02-25 16:55:47 --> Input Class Initialized
INFO - 2020-02-25 16:55:47 --> Language Class Initialized
INFO - 2020-02-25 16:55:47 --> Language Class Initialized
INFO - 2020-02-25 16:55:47 --> Language Class Initialized
INFO - 2020-02-25 16:55:47 --> Language Class Initialized
INFO - 2020-02-25 16:55:47 --> Language Class Initialized
INFO - 2020-02-25 16:55:47 --> Language Class Initialized
ERROR - 2020-02-25 16:55:47 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-25 16:55:47 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-25 16:55:47 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-25 16:55:47 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-25 16:55:47 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-25 16:55:47 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 16:55:47 --> Config Class Initialized
INFO - 2020-02-25 16:55:47 --> Config Class Initialized
INFO - 2020-02-25 16:55:47 --> Config Class Initialized
INFO - 2020-02-25 16:55:47 --> Hooks Class Initialized
INFO - 2020-02-25 16:55:47 --> Hooks Class Initialized
INFO - 2020-02-25 16:55:47 --> Hooks Class Initialized
INFO - 2020-02-25 16:55:47 --> Config Class Initialized
INFO - 2020-02-25 16:55:47 --> Config Class Initialized
INFO - 2020-02-25 16:55:47 --> Config Class Initialized
INFO - 2020-02-25 16:55:47 --> Hooks Class Initialized
INFO - 2020-02-25 16:55:47 --> Hooks Class Initialized
INFO - 2020-02-25 16:55:47 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:55:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:55:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:55:47 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:55:47 --> Utf8 Class Initialized
INFO - 2020-02-25 16:55:47 --> Utf8 Class Initialized
INFO - 2020-02-25 16:55:47 --> Utf8 Class Initialized
DEBUG - 2020-02-25 16:55:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:55:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:55:47 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:55:47 --> Utf8 Class Initialized
INFO - 2020-02-25 16:55:47 --> Utf8 Class Initialized
INFO - 2020-02-25 16:55:47 --> Utf8 Class Initialized
INFO - 2020-02-25 16:55:47 --> URI Class Initialized
INFO - 2020-02-25 16:55:47 --> URI Class Initialized
INFO - 2020-02-25 16:55:47 --> URI Class Initialized
INFO - 2020-02-25 16:55:47 --> URI Class Initialized
INFO - 2020-02-25 16:55:47 --> Router Class Initialized
INFO - 2020-02-25 16:55:47 --> Router Class Initialized
INFO - 2020-02-25 16:55:47 --> URI Class Initialized
INFO - 2020-02-25 16:55:47 --> URI Class Initialized
INFO - 2020-02-25 16:55:47 --> Router Class Initialized
INFO - 2020-02-25 16:55:47 --> Router Class Initialized
INFO - 2020-02-25 16:55:47 --> Router Class Initialized
INFO - 2020-02-25 16:55:47 --> Router Class Initialized
INFO - 2020-02-25 16:55:47 --> Output Class Initialized
INFO - 2020-02-25 16:55:47 --> Output Class Initialized
INFO - 2020-02-25 16:55:47 --> Output Class Initialized
INFO - 2020-02-25 16:55:47 --> Security Class Initialized
INFO - 2020-02-25 16:55:47 --> Security Class Initialized
INFO - 2020-02-25 16:55:47 --> Security Class Initialized
INFO - 2020-02-25 16:55:47 --> Output Class Initialized
INFO - 2020-02-25 16:55:47 --> Output Class Initialized
INFO - 2020-02-25 16:55:47 --> Output Class Initialized
INFO - 2020-02-25 16:55:47 --> Security Class Initialized
DEBUG - 2020-02-25 16:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:55:47 --> Security Class Initialized
INFO - 2020-02-25 16:55:47 --> Security Class Initialized
INFO - 2020-02-25 16:55:48 --> Input Class Initialized
INFO - 2020-02-25 16:55:48 --> Input Class Initialized
INFO - 2020-02-25 16:55:48 --> Input Class Initialized
DEBUG - 2020-02-25 16:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:55:48 --> Input Class Initialized
INFO - 2020-02-25 16:55:48 --> Input Class Initialized
INFO - 2020-02-25 16:55:48 --> Input Class Initialized
INFO - 2020-02-25 16:55:48 --> Language Class Initialized
INFO - 2020-02-25 16:55:48 --> Language Class Initialized
INFO - 2020-02-25 16:55:48 --> Language Class Initialized
INFO - 2020-02-25 16:55:48 --> Language Class Initialized
INFO - 2020-02-25 16:55:48 --> Language Class Initialized
INFO - 2020-02-25 16:55:48 --> Language Class Initialized
ERROR - 2020-02-25 16:55:48 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-25 16:55:48 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-25 16:55:48 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-25 16:55:48 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-25 16:55:48 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-25 16:55:48 --> Loader Class Initialized
INFO - 2020-02-25 16:55:48 --> Config Class Initialized
INFO - 2020-02-25 16:55:48 --> Config Class Initialized
INFO - 2020-02-25 16:55:48 --> Hooks Class Initialized
INFO - 2020-02-25 16:55:48 --> Hooks Class Initialized
INFO - 2020-02-25 16:55:48 --> Helper loaded: url_helper
INFO - 2020-02-25 16:55:48 --> Helper loaded: string_helper
DEBUG - 2020-02-25 16:55:48 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:55:48 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:55:48 --> Utf8 Class Initialized
INFO - 2020-02-25 16:55:48 --> Utf8 Class Initialized
INFO - 2020-02-25 16:55:48 --> Database Driver Class Initialized
INFO - 2020-02-25 16:55:48 --> URI Class Initialized
INFO - 2020-02-25 16:55:48 --> URI Class Initialized
DEBUG - 2020-02-25 16:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:55:48 --> Router Class Initialized
INFO - 2020-02-25 16:55:48 --> Router Class Initialized
INFO - 2020-02-25 16:55:48 --> Controller Class Initialized
INFO - 2020-02-25 16:55:48 --> Output Class Initialized
INFO - 2020-02-25 16:55:48 --> Output Class Initialized
INFO - 2020-02-25 16:55:48 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:55:48 --> Security Class Initialized
INFO - 2020-02-25 16:55:48 --> Security Class Initialized
INFO - 2020-02-25 16:55:48 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-25 16:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:55:48 --> Input Class Initialized
INFO - 2020-02-25 16:55:48 --> Input Class Initialized
INFO - 2020-02-25 16:55:48 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:55:48 --> Language Class Initialized
INFO - 2020-02-25 16:55:48 --> Language Class Initialized
INFO - 2020-02-25 16:55:48 --> Helper loaded: form_helper
INFO - 2020-02-25 16:55:48 --> Form Validation Class Initialized
ERROR - 2020-02-25 16:55:48 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-25 16:55:48 --> Loader Class Initialized
INFO - 2020-02-25 16:55:48 --> Helper loaded: url_helper
ERROR - 2020-02-25 16:55:48 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-25 16:55:48 --> Config Class Initialized
INFO - 2020-02-25 16:55:48 --> Hooks Class Initialized
INFO - 2020-02-25 16:55:48 --> Helper loaded: string_helper
ERROR - 2020-02-25 16:55:48 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 16:55:48 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-25 16:55:48 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:55:48 --> Database Driver Class Initialized
INFO - 2020-02-25 16:55:48 --> Utf8 Class Initialized
INFO - 2020-02-25 16:55:48 --> Final output sent to browser
DEBUG - 2020-02-25 16:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-25 16:55:48 --> Total execution time: 0.3221
INFO - 2020-02-25 16:55:48 --> URI Class Initialized
INFO - 2020-02-25 16:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:55:48 --> Router Class Initialized
INFO - 2020-02-25 16:55:48 --> Controller Class Initialized
INFO - 2020-02-25 16:55:48 --> Output Class Initialized
INFO - 2020-02-25 16:55:48 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:55:48 --> Security Class Initialized
INFO - 2020-02-25 16:55:48 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-25 16:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:55:48 --> Input Class Initialized
INFO - 2020-02-25 16:55:48 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:55:48 --> Language Class Initialized
INFO - 2020-02-25 16:55:48 --> Helper loaded: form_helper
INFO - 2020-02-25 16:55:48 --> Form Validation Class Initialized
ERROR - 2020-02-25 16:55:48 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-25 16:55:48 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-25 16:55:48 --> Config Class Initialized
INFO - 2020-02-25 16:55:48 --> Hooks Class Initialized
ERROR - 2020-02-25 16:55:48 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 16:55:48 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-25 16:55:48 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:55:48 --> Utf8 Class Initialized
INFO - 2020-02-25 16:55:48 --> Final output sent to browser
DEBUG - 2020-02-25 16:55:48 --> Total execution time: 0.3275
INFO - 2020-02-25 16:55:48 --> URI Class Initialized
INFO - 2020-02-25 16:55:48 --> Router Class Initialized
INFO - 2020-02-25 16:55:48 --> Output Class Initialized
INFO - 2020-02-25 16:55:48 --> Security Class Initialized
DEBUG - 2020-02-25 16:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:55:48 --> Input Class Initialized
INFO - 2020-02-25 16:55:48 --> Language Class Initialized
ERROR - 2020-02-25 16:55:48 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-25 16:55:48 --> Config Class Initialized
INFO - 2020-02-25 16:55:48 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:55:48 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:55:48 --> Utf8 Class Initialized
INFO - 2020-02-25 16:55:48 --> URI Class Initialized
INFO - 2020-02-25 16:55:48 --> Router Class Initialized
INFO - 2020-02-25 16:55:48 --> Output Class Initialized
INFO - 2020-02-25 16:55:48 --> Security Class Initialized
DEBUG - 2020-02-25 16:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:55:48 --> Input Class Initialized
INFO - 2020-02-25 16:55:48 --> Language Class Initialized
ERROR - 2020-02-25 16:55:48 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-25 16:55:48 --> Config Class Initialized
INFO - 2020-02-25 16:55:48 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:55:48 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:55:48 --> Utf8 Class Initialized
INFO - 2020-02-25 16:55:48 --> URI Class Initialized
INFO - 2020-02-25 16:55:48 --> Router Class Initialized
INFO - 2020-02-25 16:55:48 --> Output Class Initialized
INFO - 2020-02-25 16:55:48 --> Security Class Initialized
DEBUG - 2020-02-25 16:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:55:48 --> Input Class Initialized
INFO - 2020-02-25 16:55:48 --> Language Class Initialized
ERROR - 2020-02-25 16:55:48 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 16:55:48 --> Config Class Initialized
INFO - 2020-02-25 16:55:48 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:55:48 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:55:48 --> Utf8 Class Initialized
INFO - 2020-02-25 16:55:48 --> URI Class Initialized
INFO - 2020-02-25 16:55:48 --> Router Class Initialized
INFO - 2020-02-25 16:55:48 --> Output Class Initialized
INFO - 2020-02-25 16:55:48 --> Security Class Initialized
DEBUG - 2020-02-25 16:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:55:48 --> Input Class Initialized
INFO - 2020-02-25 16:55:48 --> Language Class Initialized
ERROR - 2020-02-25 16:55:48 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 16:55:48 --> Config Class Initialized
INFO - 2020-02-25 16:55:48 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:55:48 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:55:49 --> Utf8 Class Initialized
INFO - 2020-02-25 16:55:49 --> URI Class Initialized
INFO - 2020-02-25 16:55:49 --> Router Class Initialized
INFO - 2020-02-25 16:55:49 --> Output Class Initialized
INFO - 2020-02-25 16:55:49 --> Security Class Initialized
DEBUG - 2020-02-25 16:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:55:49 --> Input Class Initialized
INFO - 2020-02-25 16:55:49 --> Language Class Initialized
ERROR - 2020-02-25 16:55:49 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-25 16:55:49 --> Config Class Initialized
INFO - 2020-02-25 16:55:49 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:55:49 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:55:49 --> Utf8 Class Initialized
INFO - 2020-02-25 16:55:49 --> URI Class Initialized
INFO - 2020-02-25 16:55:49 --> Router Class Initialized
INFO - 2020-02-25 16:55:49 --> Output Class Initialized
INFO - 2020-02-25 16:55:49 --> Security Class Initialized
DEBUG - 2020-02-25 16:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:55:49 --> Input Class Initialized
INFO - 2020-02-25 16:55:49 --> Language Class Initialized
ERROR - 2020-02-25 16:55:49 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-25 16:55:49 --> Config Class Initialized
INFO - 2020-02-25 16:55:49 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:55:49 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:55:49 --> Utf8 Class Initialized
INFO - 2020-02-25 16:55:49 --> URI Class Initialized
INFO - 2020-02-25 16:55:49 --> Router Class Initialized
INFO - 2020-02-25 16:55:49 --> Output Class Initialized
INFO - 2020-02-25 16:55:49 --> Security Class Initialized
DEBUG - 2020-02-25 16:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:55:49 --> Input Class Initialized
INFO - 2020-02-25 16:55:49 --> Language Class Initialized
ERROR - 2020-02-25 16:55:49 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-25 16:55:49 --> Config Class Initialized
INFO - 2020-02-25 16:55:49 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:55:49 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:55:49 --> Utf8 Class Initialized
INFO - 2020-02-25 16:55:49 --> URI Class Initialized
INFO - 2020-02-25 16:55:49 --> Router Class Initialized
INFO - 2020-02-25 16:55:49 --> Output Class Initialized
INFO - 2020-02-25 16:55:49 --> Security Class Initialized
DEBUG - 2020-02-25 16:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:55:49 --> Input Class Initialized
INFO - 2020-02-25 16:55:49 --> Language Class Initialized
ERROR - 2020-02-25 16:55:49 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-25 16:56:01 --> Config Class Initialized
INFO - 2020-02-25 16:56:01 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:56:01 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:56:01 --> Utf8 Class Initialized
INFO - 2020-02-25 16:56:02 --> URI Class Initialized
INFO - 2020-02-25 16:56:02 --> Router Class Initialized
INFO - 2020-02-25 16:56:02 --> Output Class Initialized
INFO - 2020-02-25 16:56:02 --> Security Class Initialized
DEBUG - 2020-02-25 16:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:56:02 --> Input Class Initialized
INFO - 2020-02-25 16:56:02 --> Language Class Initialized
INFO - 2020-02-25 16:56:02 --> Loader Class Initialized
INFO - 2020-02-25 16:56:02 --> Helper loaded: url_helper
INFO - 2020-02-25 16:56:02 --> Helper loaded: string_helper
INFO - 2020-02-25 16:56:02 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:56:02 --> Controller Class Initialized
INFO - 2020-02-25 16:56:02 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:56:02 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:56:02 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:56:02 --> Helper loaded: form_helper
INFO - 2020-02-25 16:56:02 --> Form Validation Class Initialized
ERROR - 2020-02-25 16:56:02 --> Severity: Notice --> Trying to get property 'id_pengunjung' of non-object C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 81
ERROR - 2020-02-25 16:56:02 --> Severity: error --> Exception: Call to undefined method M_pesan::db() C:\xampp\htdocs\roadshow\application\models\M_pesan.php 54
INFO - 2020-02-25 16:58:04 --> Config Class Initialized
INFO - 2020-02-25 16:58:04 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:58:04 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:58:04 --> Utf8 Class Initialized
INFO - 2020-02-25 16:58:04 --> URI Class Initialized
INFO - 2020-02-25 16:58:04 --> Router Class Initialized
INFO - 2020-02-25 16:58:04 --> Output Class Initialized
INFO - 2020-02-25 16:58:04 --> Security Class Initialized
DEBUG - 2020-02-25 16:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:58:04 --> Input Class Initialized
INFO - 2020-02-25 16:58:04 --> Language Class Initialized
INFO - 2020-02-25 16:58:04 --> Loader Class Initialized
INFO - 2020-02-25 16:58:04 --> Helper loaded: url_helper
INFO - 2020-02-25 16:58:04 --> Helper loaded: string_helper
INFO - 2020-02-25 16:58:04 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:58:04 --> Controller Class Initialized
INFO - 2020-02-25 16:58:04 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:58:04 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:58:04 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:58:04 --> Helper loaded: form_helper
INFO - 2020-02-25 16:58:04 --> Form Validation Class Initialized
INFO - 2020-02-25 16:58:05 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:58:05 --> Final output sent to browser
DEBUG - 2020-02-25 16:58:05 --> Total execution time: 0.3147
INFO - 2020-02-25 16:58:05 --> Config Class Initialized
INFO - 2020-02-25 16:58:05 --> Config Class Initialized
INFO - 2020-02-25 16:58:05 --> Hooks Class Initialized
INFO - 2020-02-25 16:58:05 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:58:05 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:58:05 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:58:05 --> Utf8 Class Initialized
INFO - 2020-02-25 16:58:05 --> Utf8 Class Initialized
INFO - 2020-02-25 16:58:05 --> URI Class Initialized
INFO - 2020-02-25 16:58:05 --> URI Class Initialized
INFO - 2020-02-25 16:58:05 --> Router Class Initialized
INFO - 2020-02-25 16:58:05 --> Router Class Initialized
INFO - 2020-02-25 16:58:05 --> Output Class Initialized
INFO - 2020-02-25 16:58:05 --> Output Class Initialized
INFO - 2020-02-25 16:58:05 --> Security Class Initialized
INFO - 2020-02-25 16:58:05 --> Security Class Initialized
DEBUG - 2020-02-25 16:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:58:05 --> Input Class Initialized
INFO - 2020-02-25 16:58:05 --> Input Class Initialized
INFO - 2020-02-25 16:58:05 --> Language Class Initialized
INFO - 2020-02-25 16:58:05 --> Language Class Initialized
INFO - 2020-02-25 16:58:05 --> Loader Class Initialized
INFO - 2020-02-25 16:58:05 --> Loader Class Initialized
INFO - 2020-02-25 16:58:05 --> Helper loaded: url_helper
INFO - 2020-02-25 16:58:05 --> Helper loaded: url_helper
INFO - 2020-02-25 16:58:05 --> Helper loaded: string_helper
INFO - 2020-02-25 16:58:05 --> Helper loaded: string_helper
INFO - 2020-02-25 16:58:05 --> Database Driver Class Initialized
INFO - 2020-02-25 16:58:05 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-25 16:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:58:05 --> Controller Class Initialized
INFO - 2020-02-25 16:58:05 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:58:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:58:05 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:58:05 --> Helper loaded: form_helper
INFO - 2020-02-25 16:58:05 --> Form Validation Class Initialized
ERROR - 2020-02-25 16:58:05 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 16:58:05 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 16:58:05 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:58:05 --> Final output sent to browser
DEBUG - 2020-02-25 16:58:05 --> Total execution time: 0.3814
INFO - 2020-02-25 16:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:58:05 --> Controller Class Initialized
INFO - 2020-02-25 16:58:05 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:58:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:58:05 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:58:05 --> Helper loaded: form_helper
INFO - 2020-02-25 16:58:05 --> Form Validation Class Initialized
ERROR - 2020-02-25 16:58:05 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 16:58:05 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 16:58:05 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:58:05 --> Final output sent to browser
DEBUG - 2020-02-25 16:58:05 --> Total execution time: 0.5313
INFO - 2020-02-25 16:58:06 --> Config Class Initialized
INFO - 2020-02-25 16:58:06 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:58:06 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:58:06 --> Utf8 Class Initialized
INFO - 2020-02-25 16:58:06 --> URI Class Initialized
INFO - 2020-02-25 16:58:06 --> Router Class Initialized
INFO - 2020-02-25 16:58:06 --> Output Class Initialized
INFO - 2020-02-25 16:58:06 --> Security Class Initialized
DEBUG - 2020-02-25 16:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:58:06 --> Input Class Initialized
INFO - 2020-02-25 16:58:06 --> Language Class Initialized
INFO - 2020-02-25 16:58:06 --> Loader Class Initialized
INFO - 2020-02-25 16:58:06 --> Helper loaded: url_helper
INFO - 2020-02-25 16:58:06 --> Helper loaded: string_helper
INFO - 2020-02-25 16:58:06 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:58:06 --> Controller Class Initialized
INFO - 2020-02-25 16:58:06 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:58:06 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:58:06 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:58:06 --> Helper loaded: form_helper
INFO - 2020-02-25 16:58:06 --> Form Validation Class Initialized
INFO - 2020-02-25 16:58:06 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:58:06 --> Final output sent to browser
DEBUG - 2020-02-25 16:58:06 --> Total execution time: 0.3158
INFO - 2020-02-25 16:58:06 --> Config Class Initialized
INFO - 2020-02-25 16:58:06 --> Config Class Initialized
INFO - 2020-02-25 16:58:06 --> Config Class Initialized
INFO - 2020-02-25 16:58:06 --> Config Class Initialized
INFO - 2020-02-25 16:58:06 --> Config Class Initialized
INFO - 2020-02-25 16:58:06 --> Config Class Initialized
INFO - 2020-02-25 16:58:06 --> Hooks Class Initialized
INFO - 2020-02-25 16:58:06 --> Hooks Class Initialized
INFO - 2020-02-25 16:58:06 --> Hooks Class Initialized
INFO - 2020-02-25 16:58:06 --> Hooks Class Initialized
INFO - 2020-02-25 16:58:06 --> Hooks Class Initialized
INFO - 2020-02-25 16:58:06 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:58:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:58:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:58:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:58:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:58:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:58:06 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:58:06 --> Utf8 Class Initialized
INFO - 2020-02-25 16:58:06 --> Utf8 Class Initialized
INFO - 2020-02-25 16:58:06 --> Utf8 Class Initialized
INFO - 2020-02-25 16:58:06 --> Utf8 Class Initialized
INFO - 2020-02-25 16:58:06 --> Utf8 Class Initialized
INFO - 2020-02-25 16:58:06 --> Utf8 Class Initialized
INFO - 2020-02-25 16:58:06 --> URI Class Initialized
INFO - 2020-02-25 16:58:06 --> URI Class Initialized
INFO - 2020-02-25 16:58:06 --> URI Class Initialized
INFO - 2020-02-25 16:58:06 --> URI Class Initialized
INFO - 2020-02-25 16:58:06 --> URI Class Initialized
INFO - 2020-02-25 16:58:06 --> URI Class Initialized
INFO - 2020-02-25 16:58:06 --> Router Class Initialized
INFO - 2020-02-25 16:58:06 --> Router Class Initialized
INFO - 2020-02-25 16:58:06 --> Router Class Initialized
INFO - 2020-02-25 16:58:06 --> Router Class Initialized
INFO - 2020-02-25 16:58:06 --> Router Class Initialized
INFO - 2020-02-25 16:58:06 --> Router Class Initialized
INFO - 2020-02-25 16:58:06 --> Output Class Initialized
INFO - 2020-02-25 16:58:06 --> Output Class Initialized
INFO - 2020-02-25 16:58:06 --> Output Class Initialized
INFO - 2020-02-25 16:58:06 --> Output Class Initialized
INFO - 2020-02-25 16:58:06 --> Output Class Initialized
INFO - 2020-02-25 16:58:06 --> Output Class Initialized
INFO - 2020-02-25 16:58:06 --> Security Class Initialized
INFO - 2020-02-25 16:58:06 --> Security Class Initialized
INFO - 2020-02-25 16:58:06 --> Security Class Initialized
INFO - 2020-02-25 16:58:06 --> Security Class Initialized
INFO - 2020-02-25 16:58:06 --> Security Class Initialized
INFO - 2020-02-25 16:58:06 --> Security Class Initialized
DEBUG - 2020-02-25 16:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:58:06 --> Input Class Initialized
INFO - 2020-02-25 16:58:06 --> Input Class Initialized
INFO - 2020-02-25 16:58:06 --> Input Class Initialized
INFO - 2020-02-25 16:58:06 --> Input Class Initialized
INFO - 2020-02-25 16:58:06 --> Input Class Initialized
INFO - 2020-02-25 16:58:06 --> Input Class Initialized
INFO - 2020-02-25 16:58:06 --> Language Class Initialized
INFO - 2020-02-25 16:58:06 --> Language Class Initialized
INFO - 2020-02-25 16:58:06 --> Language Class Initialized
INFO - 2020-02-25 16:58:06 --> Language Class Initialized
INFO - 2020-02-25 16:58:06 --> Language Class Initialized
INFO - 2020-02-25 16:58:06 --> Language Class Initialized
ERROR - 2020-02-25 16:58:06 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-25 16:58:06 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-25 16:58:06 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-25 16:58:06 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-25 16:58:06 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-25 16:58:06 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-25 16:58:06 --> Config Class Initialized
INFO - 2020-02-25 16:58:06 --> Config Class Initialized
INFO - 2020-02-25 16:58:06 --> Config Class Initialized
INFO - 2020-02-25 16:58:06 --> Config Class Initialized
INFO - 2020-02-25 16:58:06 --> Config Class Initialized
INFO - 2020-02-25 16:58:06 --> Config Class Initialized
INFO - 2020-02-25 16:58:06 --> Hooks Class Initialized
INFO - 2020-02-25 16:58:06 --> Hooks Class Initialized
INFO - 2020-02-25 16:58:06 --> Hooks Class Initialized
INFO - 2020-02-25 16:58:06 --> Hooks Class Initialized
INFO - 2020-02-25 16:58:06 --> Hooks Class Initialized
INFO - 2020-02-25 16:58:06 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:58:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:58:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:58:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:58:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:58:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:58:06 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:58:06 --> Utf8 Class Initialized
INFO - 2020-02-25 16:58:06 --> Utf8 Class Initialized
INFO - 2020-02-25 16:58:06 --> Utf8 Class Initialized
INFO - 2020-02-25 16:58:06 --> Utf8 Class Initialized
INFO - 2020-02-25 16:58:06 --> Utf8 Class Initialized
INFO - 2020-02-25 16:58:06 --> Utf8 Class Initialized
INFO - 2020-02-25 16:58:07 --> URI Class Initialized
INFO - 2020-02-25 16:58:07 --> URI Class Initialized
INFO - 2020-02-25 16:58:07 --> URI Class Initialized
INFO - 2020-02-25 16:58:07 --> URI Class Initialized
INFO - 2020-02-25 16:58:07 --> URI Class Initialized
INFO - 2020-02-25 16:58:07 --> URI Class Initialized
INFO - 2020-02-25 16:58:07 --> Router Class Initialized
INFO - 2020-02-25 16:58:07 --> Router Class Initialized
INFO - 2020-02-25 16:58:07 --> Router Class Initialized
INFO - 2020-02-25 16:58:07 --> Router Class Initialized
INFO - 2020-02-25 16:58:07 --> Router Class Initialized
INFO - 2020-02-25 16:58:07 --> Router Class Initialized
INFO - 2020-02-25 16:58:07 --> Output Class Initialized
INFO - 2020-02-25 16:58:07 --> Output Class Initialized
INFO - 2020-02-25 16:58:07 --> Output Class Initialized
INFO - 2020-02-25 16:58:07 --> Output Class Initialized
INFO - 2020-02-25 16:58:07 --> Output Class Initialized
INFO - 2020-02-25 16:58:07 --> Output Class Initialized
INFO - 2020-02-25 16:58:07 --> Security Class Initialized
INFO - 2020-02-25 16:58:07 --> Security Class Initialized
INFO - 2020-02-25 16:58:07 --> Security Class Initialized
INFO - 2020-02-25 16:58:07 --> Security Class Initialized
INFO - 2020-02-25 16:58:07 --> Security Class Initialized
INFO - 2020-02-25 16:58:07 --> Security Class Initialized
DEBUG - 2020-02-25 16:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:58:07 --> Input Class Initialized
INFO - 2020-02-25 16:58:07 --> Input Class Initialized
INFO - 2020-02-25 16:58:07 --> Input Class Initialized
INFO - 2020-02-25 16:58:07 --> Input Class Initialized
INFO - 2020-02-25 16:58:07 --> Input Class Initialized
INFO - 2020-02-25 16:58:07 --> Input Class Initialized
INFO - 2020-02-25 16:58:07 --> Language Class Initialized
INFO - 2020-02-25 16:58:07 --> Language Class Initialized
INFO - 2020-02-25 16:58:07 --> Language Class Initialized
INFO - 2020-02-25 16:58:07 --> Language Class Initialized
INFO - 2020-02-25 16:58:07 --> Language Class Initialized
INFO - 2020-02-25 16:58:07 --> Language Class Initialized
ERROR - 2020-02-25 16:58:07 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-25 16:58:07 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-25 16:58:07 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-25 16:58:07 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-25 16:58:07 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-25 16:58:07 --> Loader Class Initialized
INFO - 2020-02-25 16:58:07 --> Helper loaded: url_helper
INFO - 2020-02-25 16:58:07 --> Config Class Initialized
INFO - 2020-02-25 16:58:07 --> Config Class Initialized
INFO - 2020-02-25 16:58:07 --> Hooks Class Initialized
INFO - 2020-02-25 16:58:07 --> Hooks Class Initialized
INFO - 2020-02-25 16:58:07 --> Helper loaded: string_helper
DEBUG - 2020-02-25 16:58:07 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:58:07 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:58:07 --> Database Driver Class Initialized
INFO - 2020-02-25 16:58:07 --> Utf8 Class Initialized
INFO - 2020-02-25 16:58:07 --> Utf8 Class Initialized
DEBUG - 2020-02-25 16:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:58:07 --> URI Class Initialized
INFO - 2020-02-25 16:58:07 --> URI Class Initialized
INFO - 2020-02-25 16:58:07 --> Controller Class Initialized
INFO - 2020-02-25 16:58:07 --> Router Class Initialized
INFO - 2020-02-25 16:58:07 --> Router Class Initialized
INFO - 2020-02-25 16:58:07 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:58:07 --> Output Class Initialized
INFO - 2020-02-25 16:58:07 --> Output Class Initialized
INFO - 2020-02-25 16:58:07 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:58:07 --> Security Class Initialized
INFO - 2020-02-25 16:58:07 --> Security Class Initialized
INFO - 2020-02-25 16:58:07 --> Model "M_pesan" initialized
DEBUG - 2020-02-25 16:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:58:07 --> Input Class Initialized
INFO - 2020-02-25 16:58:07 --> Input Class Initialized
INFO - 2020-02-25 16:58:07 --> Helper loaded: form_helper
INFO - 2020-02-25 16:58:07 --> Form Validation Class Initialized
INFO - 2020-02-25 16:58:07 --> Language Class Initialized
INFO - 2020-02-25 16:58:07 --> Language Class Initialized
ERROR - 2020-02-25 16:58:07 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-25 16:58:07 --> Loader Class Initialized
ERROR - 2020-02-25 16:58:07 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 16:58:07 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 16:58:07 --> Helper loaded: url_helper
INFO - 2020-02-25 16:58:07 --> Config Class Initialized
INFO - 2020-02-25 16:58:07 --> Hooks Class Initialized
INFO - 2020-02-25 16:58:07 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:58:07 --> Helper loaded: string_helper
INFO - 2020-02-25 16:58:07 --> Final output sent to browser
DEBUG - 2020-02-25 16:58:07 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:58:07 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:58:07 --> Total execution time: 0.3500
INFO - 2020-02-25 16:58:07 --> Utf8 Class Initialized
INFO - 2020-02-25 16:58:07 --> URI Class Initialized
DEBUG - 2020-02-25 16:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:58:07 --> Router Class Initialized
INFO - 2020-02-25 16:58:07 --> Controller Class Initialized
INFO - 2020-02-25 16:58:07 --> Output Class Initialized
INFO - 2020-02-25 16:58:07 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:58:07 --> Security Class Initialized
INFO - 2020-02-25 16:58:07 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-25 16:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:58:07 --> Input Class Initialized
INFO - 2020-02-25 16:58:07 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:58:07 --> Language Class Initialized
INFO - 2020-02-25 16:58:07 --> Helper loaded: form_helper
INFO - 2020-02-25 16:58:07 --> Form Validation Class Initialized
ERROR - 2020-02-25 16:58:07 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-25 16:58:07 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-25 16:58:07 --> Config Class Initialized
INFO - 2020-02-25 16:58:07 --> Hooks Class Initialized
ERROR - 2020-02-25 16:58:07 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 16:58:07 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-25 16:58:07 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:58:07 --> Utf8 Class Initialized
INFO - 2020-02-25 16:58:07 --> Final output sent to browser
DEBUG - 2020-02-25 16:58:07 --> Total execution time: 0.3298
INFO - 2020-02-25 16:58:07 --> URI Class Initialized
INFO - 2020-02-25 16:58:07 --> Router Class Initialized
INFO - 2020-02-25 16:58:07 --> Output Class Initialized
INFO - 2020-02-25 16:58:07 --> Security Class Initialized
DEBUG - 2020-02-25 16:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:58:07 --> Input Class Initialized
INFO - 2020-02-25 16:58:07 --> Language Class Initialized
ERROR - 2020-02-25 16:58:07 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-25 16:58:07 --> Config Class Initialized
INFO - 2020-02-25 16:58:07 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:58:07 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:58:07 --> Utf8 Class Initialized
INFO - 2020-02-25 16:58:07 --> URI Class Initialized
INFO - 2020-02-25 16:58:07 --> Router Class Initialized
INFO - 2020-02-25 16:58:07 --> Output Class Initialized
INFO - 2020-02-25 16:58:07 --> Security Class Initialized
DEBUG - 2020-02-25 16:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:58:07 --> Input Class Initialized
INFO - 2020-02-25 16:58:07 --> Language Class Initialized
ERROR - 2020-02-25 16:58:07 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-25 16:58:07 --> Config Class Initialized
INFO - 2020-02-25 16:58:07 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:58:07 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:58:07 --> Utf8 Class Initialized
INFO - 2020-02-25 16:58:07 --> URI Class Initialized
INFO - 2020-02-25 16:58:07 --> Router Class Initialized
INFO - 2020-02-25 16:58:07 --> Output Class Initialized
INFO - 2020-02-25 16:58:07 --> Security Class Initialized
DEBUG - 2020-02-25 16:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:58:07 --> Input Class Initialized
INFO - 2020-02-25 16:58:07 --> Language Class Initialized
ERROR - 2020-02-25 16:58:07 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 16:58:07 --> Config Class Initialized
INFO - 2020-02-25 16:58:07 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:58:07 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:58:07 --> Utf8 Class Initialized
INFO - 2020-02-25 16:58:07 --> URI Class Initialized
INFO - 2020-02-25 16:58:07 --> Router Class Initialized
INFO - 2020-02-25 16:58:07 --> Output Class Initialized
INFO - 2020-02-25 16:58:08 --> Security Class Initialized
DEBUG - 2020-02-25 16:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:58:08 --> Input Class Initialized
INFO - 2020-02-25 16:58:08 --> Language Class Initialized
ERROR - 2020-02-25 16:58:08 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 16:58:08 --> Config Class Initialized
INFO - 2020-02-25 16:58:08 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:58:08 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:58:08 --> Utf8 Class Initialized
INFO - 2020-02-25 16:58:08 --> URI Class Initialized
INFO - 2020-02-25 16:58:08 --> Router Class Initialized
INFO - 2020-02-25 16:58:08 --> Output Class Initialized
INFO - 2020-02-25 16:58:08 --> Security Class Initialized
DEBUG - 2020-02-25 16:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:58:08 --> Input Class Initialized
INFO - 2020-02-25 16:58:08 --> Language Class Initialized
ERROR - 2020-02-25 16:58:08 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-25 16:58:08 --> Config Class Initialized
INFO - 2020-02-25 16:58:08 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:58:08 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:58:08 --> Utf8 Class Initialized
INFO - 2020-02-25 16:58:08 --> URI Class Initialized
INFO - 2020-02-25 16:58:08 --> Router Class Initialized
INFO - 2020-02-25 16:58:08 --> Output Class Initialized
INFO - 2020-02-25 16:58:08 --> Security Class Initialized
DEBUG - 2020-02-25 16:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:58:08 --> Input Class Initialized
INFO - 2020-02-25 16:58:08 --> Language Class Initialized
ERROR - 2020-02-25 16:58:08 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-25 16:58:08 --> Config Class Initialized
INFO - 2020-02-25 16:58:08 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:58:08 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:58:08 --> Utf8 Class Initialized
INFO - 2020-02-25 16:58:08 --> URI Class Initialized
INFO - 2020-02-25 16:58:08 --> Router Class Initialized
INFO - 2020-02-25 16:58:08 --> Output Class Initialized
INFO - 2020-02-25 16:58:08 --> Security Class Initialized
DEBUG - 2020-02-25 16:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:58:08 --> Input Class Initialized
INFO - 2020-02-25 16:58:08 --> Language Class Initialized
ERROR - 2020-02-25 16:58:08 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-25 16:58:08 --> Config Class Initialized
INFO - 2020-02-25 16:58:08 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:58:08 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:58:08 --> Utf8 Class Initialized
INFO - 2020-02-25 16:58:08 --> URI Class Initialized
INFO - 2020-02-25 16:58:08 --> Router Class Initialized
INFO - 2020-02-25 16:58:08 --> Output Class Initialized
INFO - 2020-02-25 16:58:08 --> Security Class Initialized
DEBUG - 2020-02-25 16:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:58:08 --> Input Class Initialized
INFO - 2020-02-25 16:58:08 --> Language Class Initialized
ERROR - 2020-02-25 16:58:08 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-25 16:58:16 --> Config Class Initialized
INFO - 2020-02-25 16:58:16 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:58:16 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:58:16 --> Utf8 Class Initialized
INFO - 2020-02-25 16:58:16 --> URI Class Initialized
INFO - 2020-02-25 16:58:16 --> Router Class Initialized
INFO - 2020-02-25 16:58:16 --> Output Class Initialized
INFO - 2020-02-25 16:58:16 --> Security Class Initialized
DEBUG - 2020-02-25 16:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:58:16 --> Input Class Initialized
INFO - 2020-02-25 16:58:16 --> Language Class Initialized
INFO - 2020-02-25 16:58:16 --> Loader Class Initialized
INFO - 2020-02-25 16:58:16 --> Helper loaded: url_helper
INFO - 2020-02-25 16:58:16 --> Helper loaded: string_helper
INFO - 2020-02-25 16:58:16 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:58:16 --> Controller Class Initialized
INFO - 2020-02-25 16:58:16 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:58:16 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:58:16 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:58:16 --> Helper loaded: form_helper
INFO - 2020-02-25 16:58:16 --> Form Validation Class Initialized
INFO - 2020-02-25 22:58:16 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-25 22:58:16 --> Final output sent to browser
DEBUG - 2020-02-25 22:58:16 --> Total execution time: 0.5076
INFO - 2020-02-25 16:58:53 --> Config Class Initialized
INFO - 2020-02-25 16:58:53 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:58:53 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:58:53 --> Utf8 Class Initialized
INFO - 2020-02-25 16:58:53 --> URI Class Initialized
INFO - 2020-02-25 16:58:53 --> Router Class Initialized
INFO - 2020-02-25 16:58:53 --> Output Class Initialized
INFO - 2020-02-25 16:58:54 --> Security Class Initialized
DEBUG - 2020-02-25 16:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:58:54 --> Input Class Initialized
INFO - 2020-02-25 16:58:54 --> Language Class Initialized
INFO - 2020-02-25 16:58:54 --> Loader Class Initialized
INFO - 2020-02-25 16:58:54 --> Helper loaded: url_helper
INFO - 2020-02-25 16:58:54 --> Helper loaded: string_helper
INFO - 2020-02-25 16:58:54 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:58:54 --> Controller Class Initialized
INFO - 2020-02-25 16:58:54 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:58:54 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:58:54 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:58:54 --> Helper loaded: form_helper
INFO - 2020-02-25 16:58:54 --> Form Validation Class Initialized
INFO - 2020-02-25 16:58:54 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:58:54 --> Final output sent to browser
DEBUG - 2020-02-25 16:58:54 --> Total execution time: 0.3429
INFO - 2020-02-25 16:58:54 --> Config Class Initialized
INFO - 2020-02-25 16:58:54 --> Config Class Initialized
INFO - 2020-02-25 16:58:54 --> Hooks Class Initialized
INFO - 2020-02-25 16:58:54 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:58:54 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 16:58:54 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:58:54 --> Utf8 Class Initialized
INFO - 2020-02-25 16:58:54 --> Utf8 Class Initialized
INFO - 2020-02-25 16:58:54 --> URI Class Initialized
INFO - 2020-02-25 16:58:54 --> URI Class Initialized
INFO - 2020-02-25 16:58:54 --> Router Class Initialized
INFO - 2020-02-25 16:58:54 --> Router Class Initialized
INFO - 2020-02-25 16:58:54 --> Output Class Initialized
INFO - 2020-02-25 16:58:54 --> Output Class Initialized
INFO - 2020-02-25 16:58:54 --> Security Class Initialized
INFO - 2020-02-25 16:58:54 --> Security Class Initialized
DEBUG - 2020-02-25 16:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 16:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:58:54 --> Input Class Initialized
INFO - 2020-02-25 16:58:54 --> Input Class Initialized
INFO - 2020-02-25 16:58:54 --> Language Class Initialized
INFO - 2020-02-25 16:58:54 --> Language Class Initialized
INFO - 2020-02-25 16:58:54 --> Loader Class Initialized
INFO - 2020-02-25 16:58:54 --> Loader Class Initialized
INFO - 2020-02-25 16:58:54 --> Helper loaded: url_helper
INFO - 2020-02-25 16:58:54 --> Helper loaded: url_helper
INFO - 2020-02-25 16:58:54 --> Helper loaded: string_helper
INFO - 2020-02-25 16:58:54 --> Helper loaded: string_helper
INFO - 2020-02-25 16:58:54 --> Database Driver Class Initialized
INFO - 2020-02-25 16:58:54 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-25 16:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:58:54 --> Controller Class Initialized
INFO - 2020-02-25 16:58:54 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:58:54 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:58:54 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:58:54 --> Helper loaded: form_helper
INFO - 2020-02-25 16:58:54 --> Form Validation Class Initialized
ERROR - 2020-02-25 16:58:54 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 16:58:54 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 16:58:54 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:58:54 --> Final output sent to browser
DEBUG - 2020-02-25 16:58:54 --> Total execution time: 0.3966
INFO - 2020-02-25 16:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:58:54 --> Controller Class Initialized
INFO - 2020-02-25 16:58:54 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:58:54 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:58:54 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:58:54 --> Helper loaded: form_helper
INFO - 2020-02-25 16:58:54 --> Form Validation Class Initialized
ERROR - 2020-02-25 16:58:54 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 16:58:54 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 16:58:54 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 16:58:54 --> Final output sent to browser
DEBUG - 2020-02-25 16:58:54 --> Total execution time: 0.5729
INFO - 2020-02-25 16:59:01 --> Config Class Initialized
INFO - 2020-02-25 16:59:01 --> Hooks Class Initialized
DEBUG - 2020-02-25 16:59:01 --> UTF-8 Support Enabled
INFO - 2020-02-25 16:59:01 --> Utf8 Class Initialized
INFO - 2020-02-25 16:59:01 --> URI Class Initialized
INFO - 2020-02-25 16:59:01 --> Router Class Initialized
INFO - 2020-02-25 16:59:01 --> Output Class Initialized
INFO - 2020-02-25 16:59:01 --> Security Class Initialized
DEBUG - 2020-02-25 16:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 16:59:01 --> Input Class Initialized
INFO - 2020-02-25 16:59:01 --> Language Class Initialized
INFO - 2020-02-25 16:59:01 --> Loader Class Initialized
INFO - 2020-02-25 16:59:01 --> Helper loaded: url_helper
INFO - 2020-02-25 16:59:01 --> Helper loaded: string_helper
INFO - 2020-02-25 16:59:01 --> Database Driver Class Initialized
DEBUG - 2020-02-25 16:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 16:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 16:59:01 --> Controller Class Initialized
INFO - 2020-02-25 16:59:01 --> Model "M_tiket" initialized
INFO - 2020-02-25 16:59:01 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 16:59:01 --> Model "M_pesan" initialized
INFO - 2020-02-25 16:59:01 --> Helper loaded: form_helper
INFO - 2020-02-25 16:59:01 --> Form Validation Class Initialized
ERROR - 2020-02-25 22:59:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 9
INFO - 2020-02-25 22:59:01 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-25 22:59:01 --> Final output sent to browser
DEBUG - 2020-02-25 22:59:01 --> Total execution time: 0.5118
INFO - 2020-02-25 17:01:12 --> Config Class Initialized
INFO - 2020-02-25 17:01:12 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:01:12 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:01:12 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:12 --> URI Class Initialized
INFO - 2020-02-25 17:01:12 --> Router Class Initialized
INFO - 2020-02-25 17:01:12 --> Output Class Initialized
INFO - 2020-02-25 17:01:12 --> Security Class Initialized
DEBUG - 2020-02-25 17:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:01:12 --> Input Class Initialized
INFO - 2020-02-25 17:01:12 --> Language Class Initialized
INFO - 2020-02-25 17:01:12 --> Loader Class Initialized
INFO - 2020-02-25 17:01:12 --> Helper loaded: url_helper
INFO - 2020-02-25 17:01:12 --> Helper loaded: string_helper
INFO - 2020-02-25 17:01:12 --> Database Driver Class Initialized
DEBUG - 2020-02-25 17:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 17:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 17:01:12 --> Controller Class Initialized
INFO - 2020-02-25 17:01:12 --> Model "M_tiket" initialized
INFO - 2020-02-25 17:01:12 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 17:01:12 --> Model "M_pesan" initialized
INFO - 2020-02-25 17:01:12 --> Helper loaded: form_helper
INFO - 2020-02-25 17:01:12 --> Form Validation Class Initialized
INFO - 2020-02-25 17:01:12 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 17:01:12 --> Final output sent to browser
DEBUG - 2020-02-25 17:01:12 --> Total execution time: 0.3555
INFO - 2020-02-25 17:01:12 --> Config Class Initialized
INFO - 2020-02-25 17:01:12 --> Config Class Initialized
INFO - 2020-02-25 17:01:12 --> Hooks Class Initialized
INFO - 2020-02-25 17:01:12 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:01:12 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:01:12 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:01:12 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:12 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:12 --> URI Class Initialized
INFO - 2020-02-25 17:01:12 --> URI Class Initialized
INFO - 2020-02-25 17:01:12 --> Router Class Initialized
INFO - 2020-02-25 17:01:12 --> Router Class Initialized
INFO - 2020-02-25 17:01:12 --> Output Class Initialized
INFO - 2020-02-25 17:01:12 --> Output Class Initialized
INFO - 2020-02-25 17:01:12 --> Security Class Initialized
INFO - 2020-02-25 17:01:12 --> Security Class Initialized
DEBUG - 2020-02-25 17:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:01:12 --> Input Class Initialized
INFO - 2020-02-25 17:01:12 --> Input Class Initialized
INFO - 2020-02-25 17:01:12 --> Language Class Initialized
INFO - 2020-02-25 17:01:12 --> Language Class Initialized
INFO - 2020-02-25 17:01:12 --> Loader Class Initialized
INFO - 2020-02-25 17:01:12 --> Loader Class Initialized
INFO - 2020-02-25 17:01:12 --> Helper loaded: url_helper
INFO - 2020-02-25 17:01:12 --> Helper loaded: url_helper
INFO - 2020-02-25 17:01:12 --> Helper loaded: string_helper
INFO - 2020-02-25 17:01:12 --> Helper loaded: string_helper
INFO - 2020-02-25 17:01:12 --> Database Driver Class Initialized
INFO - 2020-02-25 17:01:12 --> Database Driver Class Initialized
DEBUG - 2020-02-25 17:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-25 17:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 17:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 17:01:12 --> Controller Class Initialized
INFO - 2020-02-25 17:01:12 --> Model "M_tiket" initialized
INFO - 2020-02-25 17:01:12 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 17:01:12 --> Model "M_pesan" initialized
INFO - 2020-02-25 17:01:12 --> Helper loaded: form_helper
INFO - 2020-02-25 17:01:12 --> Form Validation Class Initialized
ERROR - 2020-02-25 17:01:12 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 17:01:12 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 17:01:12 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 17:01:12 --> Final output sent to browser
DEBUG - 2020-02-25 17:01:12 --> Total execution time: 0.3945
INFO - 2020-02-25 17:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 17:01:12 --> Controller Class Initialized
INFO - 2020-02-25 17:01:13 --> Model "M_tiket" initialized
INFO - 2020-02-25 17:01:13 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 17:01:13 --> Model "M_pesan" initialized
INFO - 2020-02-25 17:01:13 --> Helper loaded: form_helper
INFO - 2020-02-25 17:01:13 --> Form Validation Class Initialized
ERROR - 2020-02-25 17:01:13 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 17:01:13 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 17:01:13 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 17:01:13 --> Final output sent to browser
DEBUG - 2020-02-25 17:01:13 --> Total execution time: 0.5654
INFO - 2020-02-25 17:01:14 --> Config Class Initialized
INFO - 2020-02-25 17:01:14 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:01:14 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:01:14 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:14 --> URI Class Initialized
INFO - 2020-02-25 17:01:14 --> Router Class Initialized
INFO - 2020-02-25 17:01:14 --> Output Class Initialized
INFO - 2020-02-25 17:01:14 --> Security Class Initialized
DEBUG - 2020-02-25 17:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:01:14 --> Input Class Initialized
INFO - 2020-02-25 17:01:14 --> Language Class Initialized
INFO - 2020-02-25 17:01:14 --> Loader Class Initialized
INFO - 2020-02-25 17:01:14 --> Helper loaded: url_helper
INFO - 2020-02-25 17:01:14 --> Helper loaded: string_helper
INFO - 2020-02-25 17:01:14 --> Database Driver Class Initialized
DEBUG - 2020-02-25 17:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 17:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 17:01:14 --> Controller Class Initialized
INFO - 2020-02-25 17:01:14 --> Model "M_tiket" initialized
INFO - 2020-02-25 17:01:14 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 17:01:14 --> Model "M_pesan" initialized
INFO - 2020-02-25 17:01:14 --> Helper loaded: form_helper
INFO - 2020-02-25 17:01:14 --> Form Validation Class Initialized
INFO - 2020-02-25 17:01:14 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 17:01:14 --> Final output sent to browser
DEBUG - 2020-02-25 17:01:14 --> Total execution time: 0.3333
INFO - 2020-02-25 17:01:14 --> Config Class Initialized
INFO - 2020-02-25 17:01:14 --> Config Class Initialized
INFO - 2020-02-25 17:01:14 --> Config Class Initialized
INFO - 2020-02-25 17:01:14 --> Config Class Initialized
INFO - 2020-02-25 17:01:14 --> Config Class Initialized
INFO - 2020-02-25 17:01:14 --> Config Class Initialized
INFO - 2020-02-25 17:01:14 --> Hooks Class Initialized
INFO - 2020-02-25 17:01:14 --> Hooks Class Initialized
INFO - 2020-02-25 17:01:14 --> Hooks Class Initialized
INFO - 2020-02-25 17:01:14 --> Hooks Class Initialized
INFO - 2020-02-25 17:01:14 --> Hooks Class Initialized
INFO - 2020-02-25 17:01:14 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:01:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:01:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:01:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:01:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:01:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:01:14 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:01:14 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:14 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:14 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:14 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:14 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:14 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:14 --> URI Class Initialized
INFO - 2020-02-25 17:01:14 --> URI Class Initialized
INFO - 2020-02-25 17:01:14 --> URI Class Initialized
INFO - 2020-02-25 17:01:14 --> URI Class Initialized
INFO - 2020-02-25 17:01:14 --> URI Class Initialized
INFO - 2020-02-25 17:01:14 --> URI Class Initialized
INFO - 2020-02-25 17:01:14 --> Router Class Initialized
INFO - 2020-02-25 17:01:14 --> Router Class Initialized
INFO - 2020-02-25 17:01:14 --> Router Class Initialized
INFO - 2020-02-25 17:01:14 --> Router Class Initialized
INFO - 2020-02-25 17:01:14 --> Router Class Initialized
INFO - 2020-02-25 17:01:14 --> Router Class Initialized
INFO - 2020-02-25 17:01:14 --> Output Class Initialized
INFO - 2020-02-25 17:01:14 --> Output Class Initialized
INFO - 2020-02-25 17:01:14 --> Output Class Initialized
INFO - 2020-02-25 17:01:14 --> Output Class Initialized
INFO - 2020-02-25 17:01:14 --> Output Class Initialized
INFO - 2020-02-25 17:01:14 --> Output Class Initialized
INFO - 2020-02-25 17:01:14 --> Security Class Initialized
INFO - 2020-02-25 17:01:14 --> Security Class Initialized
INFO - 2020-02-25 17:01:14 --> Security Class Initialized
INFO - 2020-02-25 17:01:14 --> Security Class Initialized
INFO - 2020-02-25 17:01:14 --> Security Class Initialized
INFO - 2020-02-25 17:01:14 --> Security Class Initialized
DEBUG - 2020-02-25 17:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:01:14 --> Input Class Initialized
INFO - 2020-02-25 17:01:14 --> Input Class Initialized
INFO - 2020-02-25 17:01:14 --> Input Class Initialized
INFO - 2020-02-25 17:01:14 --> Input Class Initialized
INFO - 2020-02-25 17:01:14 --> Input Class Initialized
INFO - 2020-02-25 17:01:14 --> Input Class Initialized
INFO - 2020-02-25 17:01:14 --> Language Class Initialized
INFO - 2020-02-25 17:01:14 --> Language Class Initialized
INFO - 2020-02-25 17:01:14 --> Language Class Initialized
INFO - 2020-02-25 17:01:14 --> Language Class Initialized
INFO - 2020-02-25 17:01:14 --> Language Class Initialized
INFO - 2020-02-25 17:01:14 --> Language Class Initialized
ERROR - 2020-02-25 17:01:14 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-25 17:01:14 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-25 17:01:14 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-25 17:01:14 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-25 17:01:14 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-25 17:01:14 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-25 17:01:14 --> Config Class Initialized
INFO - 2020-02-25 17:01:14 --> Config Class Initialized
INFO - 2020-02-25 17:01:14 --> Config Class Initialized
INFO - 2020-02-25 17:01:14 --> Config Class Initialized
INFO - 2020-02-25 17:01:14 --> Config Class Initialized
INFO - 2020-02-25 17:01:14 --> Config Class Initialized
INFO - 2020-02-25 17:01:14 --> Hooks Class Initialized
INFO - 2020-02-25 17:01:14 --> Hooks Class Initialized
INFO - 2020-02-25 17:01:14 --> Hooks Class Initialized
INFO - 2020-02-25 17:01:14 --> Hooks Class Initialized
INFO - 2020-02-25 17:01:14 --> Hooks Class Initialized
INFO - 2020-02-25 17:01:14 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:01:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:01:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:01:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:01:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:01:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:01:14 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:01:14 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:14 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:14 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:14 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:14 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:14 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:14 --> URI Class Initialized
INFO - 2020-02-25 17:01:14 --> URI Class Initialized
INFO - 2020-02-25 17:01:14 --> URI Class Initialized
INFO - 2020-02-25 17:01:14 --> URI Class Initialized
INFO - 2020-02-25 17:01:14 --> URI Class Initialized
INFO - 2020-02-25 17:01:14 --> URI Class Initialized
INFO - 2020-02-25 17:01:14 --> Router Class Initialized
INFO - 2020-02-25 17:01:14 --> Router Class Initialized
INFO - 2020-02-25 17:01:14 --> Router Class Initialized
INFO - 2020-02-25 17:01:14 --> Router Class Initialized
INFO - 2020-02-25 17:01:14 --> Router Class Initialized
INFO - 2020-02-25 17:01:14 --> Router Class Initialized
INFO - 2020-02-25 17:01:14 --> Output Class Initialized
INFO - 2020-02-25 17:01:14 --> Output Class Initialized
INFO - 2020-02-25 17:01:14 --> Output Class Initialized
INFO - 2020-02-25 17:01:14 --> Output Class Initialized
INFO - 2020-02-25 17:01:14 --> Output Class Initialized
INFO - 2020-02-25 17:01:14 --> Output Class Initialized
INFO - 2020-02-25 17:01:14 --> Security Class Initialized
INFO - 2020-02-25 17:01:14 --> Security Class Initialized
INFO - 2020-02-25 17:01:14 --> Security Class Initialized
INFO - 2020-02-25 17:01:14 --> Security Class Initialized
INFO - 2020-02-25 17:01:14 --> Security Class Initialized
INFO - 2020-02-25 17:01:14 --> Security Class Initialized
DEBUG - 2020-02-25 17:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:01:14 --> Input Class Initialized
INFO - 2020-02-25 17:01:14 --> Input Class Initialized
INFO - 2020-02-25 17:01:14 --> Input Class Initialized
INFO - 2020-02-25 17:01:14 --> Input Class Initialized
INFO - 2020-02-25 17:01:14 --> Input Class Initialized
INFO - 2020-02-25 17:01:14 --> Input Class Initialized
INFO - 2020-02-25 17:01:15 --> Language Class Initialized
INFO - 2020-02-25 17:01:15 --> Language Class Initialized
INFO - 2020-02-25 17:01:15 --> Language Class Initialized
INFO - 2020-02-25 17:01:15 --> Language Class Initialized
INFO - 2020-02-25 17:01:15 --> Language Class Initialized
INFO - 2020-02-25 17:01:15 --> Language Class Initialized
ERROR - 2020-02-25 17:01:15 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-25 17:01:15 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-25 17:01:15 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-25 17:01:15 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-25 17:01:15 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 17:01:15 --> Loader Class Initialized
INFO - 2020-02-25 17:01:15 --> Helper loaded: url_helper
INFO - 2020-02-25 17:01:15 --> Config Class Initialized
INFO - 2020-02-25 17:01:15 --> Config Class Initialized
INFO - 2020-02-25 17:01:15 --> Hooks Class Initialized
INFO - 2020-02-25 17:01:15 --> Hooks Class Initialized
INFO - 2020-02-25 17:01:15 --> Helper loaded: string_helper
DEBUG - 2020-02-25 17:01:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:01:15 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:01:15 --> Database Driver Class Initialized
INFO - 2020-02-25 17:01:15 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:15 --> Utf8 Class Initialized
DEBUG - 2020-02-25 17:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 17:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 17:01:15 --> URI Class Initialized
INFO - 2020-02-25 17:01:15 --> URI Class Initialized
INFO - 2020-02-25 17:01:15 --> Controller Class Initialized
INFO - 2020-02-25 17:01:15 --> Router Class Initialized
INFO - 2020-02-25 17:01:15 --> Router Class Initialized
INFO - 2020-02-25 17:01:15 --> Model "M_tiket" initialized
INFO - 2020-02-25 17:01:15 --> Output Class Initialized
INFO - 2020-02-25 17:01:15 --> Output Class Initialized
INFO - 2020-02-25 17:01:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 17:01:15 --> Security Class Initialized
INFO - 2020-02-25 17:01:15 --> Security Class Initialized
INFO - 2020-02-25 17:01:15 --> Model "M_pesan" initialized
DEBUG - 2020-02-25 17:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:01:15 --> Input Class Initialized
INFO - 2020-02-25 17:01:15 --> Input Class Initialized
INFO - 2020-02-25 17:01:15 --> Helper loaded: form_helper
INFO - 2020-02-25 17:01:15 --> Form Validation Class Initialized
INFO - 2020-02-25 17:01:15 --> Language Class Initialized
INFO - 2020-02-25 17:01:15 --> Language Class Initialized
ERROR - 2020-02-25 17:01:15 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-25 17:01:15 --> Loader Class Initialized
ERROR - 2020-02-25 17:01:15 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 17:01:15 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 17:01:15 --> Helper loaded: url_helper
INFO - 2020-02-25 17:01:15 --> Config Class Initialized
INFO - 2020-02-25 17:01:15 --> Hooks Class Initialized
INFO - 2020-02-25 17:01:15 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 17:01:15 --> Helper loaded: string_helper
INFO - 2020-02-25 17:01:15 --> Final output sent to browser
DEBUG - 2020-02-25 17:01:15 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:01:15 --> Database Driver Class Initialized
DEBUG - 2020-02-25 17:01:15 --> Total execution time: 0.3793
INFO - 2020-02-25 17:01:15 --> Utf8 Class Initialized
DEBUG - 2020-02-25 17:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 17:01:15 --> URI Class Initialized
INFO - 2020-02-25 17:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 17:01:15 --> Router Class Initialized
INFO - 2020-02-25 17:01:15 --> Controller Class Initialized
INFO - 2020-02-25 17:01:15 --> Output Class Initialized
INFO - 2020-02-25 17:01:15 --> Model "M_tiket" initialized
INFO - 2020-02-25 17:01:15 --> Security Class Initialized
INFO - 2020-02-25 17:01:15 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-25 17:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:01:15 --> Input Class Initialized
INFO - 2020-02-25 17:01:15 --> Model "M_pesan" initialized
INFO - 2020-02-25 17:01:15 --> Language Class Initialized
INFO - 2020-02-25 17:01:15 --> Helper loaded: form_helper
INFO - 2020-02-25 17:01:15 --> Form Validation Class Initialized
ERROR - 2020-02-25 17:01:15 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-25 17:01:15 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-25 17:01:15 --> Config Class Initialized
INFO - 2020-02-25 17:01:15 --> Hooks Class Initialized
ERROR - 2020-02-25 17:01:15 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 17:01:15 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-25 17:01:15 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:01:15 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:15 --> Final output sent to browser
DEBUG - 2020-02-25 17:01:15 --> Total execution time: 0.3669
INFO - 2020-02-25 17:01:15 --> URI Class Initialized
INFO - 2020-02-25 17:01:15 --> Router Class Initialized
INFO - 2020-02-25 17:01:15 --> Output Class Initialized
INFO - 2020-02-25 17:01:15 --> Security Class Initialized
DEBUG - 2020-02-25 17:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:01:15 --> Input Class Initialized
INFO - 2020-02-25 17:01:15 --> Language Class Initialized
ERROR - 2020-02-25 17:01:15 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-25 17:01:15 --> Config Class Initialized
INFO - 2020-02-25 17:01:15 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:01:15 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:01:15 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:15 --> URI Class Initialized
INFO - 2020-02-25 17:01:15 --> Router Class Initialized
INFO - 2020-02-25 17:01:15 --> Output Class Initialized
INFO - 2020-02-25 17:01:15 --> Security Class Initialized
DEBUG - 2020-02-25 17:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:01:15 --> Input Class Initialized
INFO - 2020-02-25 17:01:15 --> Language Class Initialized
ERROR - 2020-02-25 17:01:15 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-25 17:01:15 --> Config Class Initialized
INFO - 2020-02-25 17:01:15 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:01:15 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:01:15 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:15 --> URI Class Initialized
INFO - 2020-02-25 17:01:15 --> Router Class Initialized
INFO - 2020-02-25 17:01:15 --> Output Class Initialized
INFO - 2020-02-25 17:01:15 --> Security Class Initialized
DEBUG - 2020-02-25 17:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:01:15 --> Input Class Initialized
INFO - 2020-02-25 17:01:15 --> Language Class Initialized
ERROR - 2020-02-25 17:01:15 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 17:01:15 --> Config Class Initialized
INFO - 2020-02-25 17:01:15 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:01:15 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:01:15 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:15 --> URI Class Initialized
INFO - 2020-02-25 17:01:15 --> Router Class Initialized
INFO - 2020-02-25 17:01:15 --> Output Class Initialized
INFO - 2020-02-25 17:01:16 --> Security Class Initialized
DEBUG - 2020-02-25 17:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:01:16 --> Input Class Initialized
INFO - 2020-02-25 17:01:16 --> Language Class Initialized
ERROR - 2020-02-25 17:01:16 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 17:01:16 --> Config Class Initialized
INFO - 2020-02-25 17:01:16 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:01:16 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:01:16 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:16 --> URI Class Initialized
INFO - 2020-02-25 17:01:16 --> Router Class Initialized
INFO - 2020-02-25 17:01:16 --> Output Class Initialized
INFO - 2020-02-25 17:01:16 --> Security Class Initialized
DEBUG - 2020-02-25 17:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:01:16 --> Input Class Initialized
INFO - 2020-02-25 17:01:16 --> Language Class Initialized
ERROR - 2020-02-25 17:01:16 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-25 17:01:16 --> Config Class Initialized
INFO - 2020-02-25 17:01:16 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:01:16 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:01:16 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:16 --> URI Class Initialized
INFO - 2020-02-25 17:01:16 --> Router Class Initialized
INFO - 2020-02-25 17:01:16 --> Output Class Initialized
INFO - 2020-02-25 17:01:16 --> Security Class Initialized
DEBUG - 2020-02-25 17:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:01:16 --> Input Class Initialized
INFO - 2020-02-25 17:01:16 --> Language Class Initialized
ERROR - 2020-02-25 17:01:16 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-25 17:01:16 --> Config Class Initialized
INFO - 2020-02-25 17:01:16 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:01:16 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:01:16 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:16 --> URI Class Initialized
INFO - 2020-02-25 17:01:16 --> Router Class Initialized
INFO - 2020-02-25 17:01:16 --> Output Class Initialized
INFO - 2020-02-25 17:01:16 --> Security Class Initialized
DEBUG - 2020-02-25 17:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:01:16 --> Input Class Initialized
INFO - 2020-02-25 17:01:16 --> Language Class Initialized
ERROR - 2020-02-25 17:01:16 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-25 17:01:16 --> Config Class Initialized
INFO - 2020-02-25 17:01:16 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:01:16 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:01:16 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:16 --> URI Class Initialized
INFO - 2020-02-25 17:01:16 --> Router Class Initialized
INFO - 2020-02-25 17:01:16 --> Output Class Initialized
INFO - 2020-02-25 17:01:16 --> Security Class Initialized
DEBUG - 2020-02-25 17:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:01:16 --> Input Class Initialized
INFO - 2020-02-25 17:01:16 --> Language Class Initialized
ERROR - 2020-02-25 17:01:16 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-25 17:01:24 --> Config Class Initialized
INFO - 2020-02-25 17:01:24 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:01:24 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:01:24 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:24 --> URI Class Initialized
INFO - 2020-02-25 17:01:24 --> Router Class Initialized
INFO - 2020-02-25 17:01:24 --> Output Class Initialized
INFO - 2020-02-25 17:01:25 --> Security Class Initialized
DEBUG - 2020-02-25 17:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:01:25 --> Input Class Initialized
INFO - 2020-02-25 17:01:25 --> Language Class Initialized
INFO - 2020-02-25 17:01:25 --> Loader Class Initialized
INFO - 2020-02-25 17:01:25 --> Helper loaded: url_helper
INFO - 2020-02-25 17:01:25 --> Helper loaded: string_helper
INFO - 2020-02-25 17:01:25 --> Database Driver Class Initialized
DEBUG - 2020-02-25 17:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 17:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 17:01:25 --> Controller Class Initialized
INFO - 2020-02-25 17:01:25 --> Model "M_tiket" initialized
INFO - 2020-02-25 17:01:25 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 17:01:25 --> Model "M_pesan" initialized
INFO - 2020-02-25 17:01:25 --> Helper loaded: form_helper
INFO - 2020-02-25 17:01:25 --> Form Validation Class Initialized
INFO - 2020-02-25 23:01:25 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-25 23:01:25 --> Final output sent to browser
DEBUG - 2020-02-25 23:01:25 --> Total execution time: 0.5497
INFO - 2020-02-25 17:01:45 --> Config Class Initialized
INFO - 2020-02-25 17:01:45 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:01:45 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:01:46 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:46 --> URI Class Initialized
DEBUG - 2020-02-25 17:01:46 --> No URI present. Default controller set.
INFO - 2020-02-25 17:01:46 --> Router Class Initialized
INFO - 2020-02-25 17:01:46 --> Output Class Initialized
INFO - 2020-02-25 17:01:46 --> Security Class Initialized
DEBUG - 2020-02-25 17:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:01:46 --> Input Class Initialized
INFO - 2020-02-25 17:01:46 --> Language Class Initialized
INFO - 2020-02-25 17:01:46 --> Loader Class Initialized
INFO - 2020-02-25 17:01:46 --> Helper loaded: url_helper
INFO - 2020-02-25 17:01:46 --> Helper loaded: string_helper
INFO - 2020-02-25 17:01:46 --> Database Driver Class Initialized
DEBUG - 2020-02-25 17:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 17:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 17:01:46 --> Controller Class Initialized
INFO - 2020-02-25 17:01:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:01:46 --> Pagination Class Initialized
INFO - 2020-02-25 17:01:46 --> Model "M_show" initialized
INFO - 2020-02-25 17:01:46 --> Helper loaded: form_helper
INFO - 2020-02-25 17:01:46 --> Form Validation Class Initialized
INFO - 2020-02-25 17:01:46 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-25 17:01:46 --> Final output sent to browser
DEBUG - 2020-02-25 17:01:46 --> Total execution time: 0.3524
INFO - 2020-02-25 17:01:46 --> Config Class Initialized
INFO - 2020-02-25 17:01:46 --> Config Class Initialized
INFO - 2020-02-25 17:01:46 --> Hooks Class Initialized
INFO - 2020-02-25 17:01:46 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:01:46 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:01:46 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:01:46 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:46 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:46 --> URI Class Initialized
INFO - 2020-02-25 17:01:46 --> URI Class Initialized
INFO - 2020-02-25 17:01:46 --> Router Class Initialized
INFO - 2020-02-25 17:01:46 --> Router Class Initialized
INFO - 2020-02-25 17:01:46 --> Output Class Initialized
INFO - 2020-02-25 17:01:46 --> Output Class Initialized
INFO - 2020-02-25 17:01:46 --> Security Class Initialized
INFO - 2020-02-25 17:01:46 --> Security Class Initialized
DEBUG - 2020-02-25 17:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:01:46 --> Input Class Initialized
INFO - 2020-02-25 17:01:46 --> Input Class Initialized
INFO - 2020-02-25 17:01:46 --> Language Class Initialized
INFO - 2020-02-25 17:01:46 --> Language Class Initialized
ERROR - 2020-02-25 17:01:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-02-25 17:01:46 --> 404 Page Not Found: Assets/js
INFO - 2020-02-25 17:01:46 --> Config Class Initialized
INFO - 2020-02-25 17:01:46 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:01:46 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:01:46 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:46 --> URI Class Initialized
INFO - 2020-02-25 17:01:46 --> Router Class Initialized
INFO - 2020-02-25 17:01:46 --> Output Class Initialized
INFO - 2020-02-25 17:01:46 --> Security Class Initialized
DEBUG - 2020-02-25 17:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:01:46 --> Input Class Initialized
INFO - 2020-02-25 17:01:46 --> Language Class Initialized
ERROR - 2020-02-25 17:01:46 --> 404 Page Not Found: Assets/js
INFO - 2020-02-25 17:01:48 --> Config Class Initialized
INFO - 2020-02-25 17:01:48 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:01:48 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:01:48 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:48 --> URI Class Initialized
INFO - 2020-02-25 17:01:48 --> Router Class Initialized
INFO - 2020-02-25 17:01:48 --> Output Class Initialized
INFO - 2020-02-25 17:01:48 --> Security Class Initialized
DEBUG - 2020-02-25 17:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:01:48 --> Input Class Initialized
INFO - 2020-02-25 17:01:48 --> Language Class Initialized
INFO - 2020-02-25 17:01:48 --> Loader Class Initialized
INFO - 2020-02-25 17:01:48 --> Helper loaded: url_helper
INFO - 2020-02-25 17:01:48 --> Helper loaded: string_helper
INFO - 2020-02-25 17:01:48 --> Database Driver Class Initialized
DEBUG - 2020-02-25 17:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 17:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 17:01:48 --> Controller Class Initialized
INFO - 2020-02-25 17:01:48 --> Model "M_tiket" initialized
INFO - 2020-02-25 17:01:48 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 17:01:48 --> Model "M_pesan" initialized
INFO - 2020-02-25 17:01:48 --> Helper loaded: form_helper
INFO - 2020-02-25 17:01:48 --> Form Validation Class Initialized
INFO - 2020-02-25 17:01:48 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 17:01:48 --> Final output sent to browser
DEBUG - 2020-02-25 17:01:48 --> Total execution time: 0.3904
INFO - 2020-02-25 17:01:48 --> Config Class Initialized
INFO - 2020-02-25 17:01:48 --> Config Class Initialized
INFO - 2020-02-25 17:01:48 --> Config Class Initialized
INFO - 2020-02-25 17:01:48 --> Config Class Initialized
INFO - 2020-02-25 17:01:48 --> Config Class Initialized
INFO - 2020-02-25 17:01:48 --> Config Class Initialized
INFO - 2020-02-25 17:01:48 --> Hooks Class Initialized
INFO - 2020-02-25 17:01:48 --> Hooks Class Initialized
INFO - 2020-02-25 17:01:48 --> Hooks Class Initialized
INFO - 2020-02-25 17:01:48 --> Hooks Class Initialized
INFO - 2020-02-25 17:01:48 --> Hooks Class Initialized
INFO - 2020-02-25 17:01:48 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:01:48 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:01:48 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:01:48 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:01:48 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:01:48 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:01:48 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:01:48 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:48 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:48 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:48 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:48 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:48 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:48 --> URI Class Initialized
INFO - 2020-02-25 17:01:48 --> URI Class Initialized
INFO - 2020-02-25 17:01:48 --> URI Class Initialized
INFO - 2020-02-25 17:01:48 --> URI Class Initialized
INFO - 2020-02-25 17:01:48 --> URI Class Initialized
INFO - 2020-02-25 17:01:48 --> URI Class Initialized
INFO - 2020-02-25 17:01:48 --> Router Class Initialized
INFO - 2020-02-25 17:01:48 --> Router Class Initialized
INFO - 2020-02-25 17:01:48 --> Router Class Initialized
INFO - 2020-02-25 17:01:48 --> Router Class Initialized
INFO - 2020-02-25 17:01:48 --> Router Class Initialized
INFO - 2020-02-25 17:01:48 --> Router Class Initialized
INFO - 2020-02-25 17:01:48 --> Output Class Initialized
INFO - 2020-02-25 17:01:48 --> Output Class Initialized
INFO - 2020-02-25 17:01:48 --> Output Class Initialized
INFO - 2020-02-25 17:01:48 --> Output Class Initialized
INFO - 2020-02-25 17:01:48 --> Output Class Initialized
INFO - 2020-02-25 17:01:48 --> Output Class Initialized
INFO - 2020-02-25 17:01:48 --> Security Class Initialized
INFO - 2020-02-25 17:01:48 --> Security Class Initialized
INFO - 2020-02-25 17:01:48 --> Security Class Initialized
INFO - 2020-02-25 17:01:48 --> Security Class Initialized
INFO - 2020-02-25 17:01:48 --> Security Class Initialized
INFO - 2020-02-25 17:01:48 --> Security Class Initialized
DEBUG - 2020-02-25 17:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:01:48 --> Input Class Initialized
INFO - 2020-02-25 17:01:48 --> Input Class Initialized
INFO - 2020-02-25 17:01:48 --> Input Class Initialized
INFO - 2020-02-25 17:01:48 --> Input Class Initialized
INFO - 2020-02-25 17:01:48 --> Input Class Initialized
INFO - 2020-02-25 17:01:48 --> Input Class Initialized
INFO - 2020-02-25 17:01:48 --> Language Class Initialized
INFO - 2020-02-25 17:01:48 --> Language Class Initialized
INFO - 2020-02-25 17:01:48 --> Language Class Initialized
INFO - 2020-02-25 17:01:48 --> Language Class Initialized
INFO - 2020-02-25 17:01:48 --> Language Class Initialized
INFO - 2020-02-25 17:01:48 --> Language Class Initialized
ERROR - 2020-02-25 17:01:48 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-25 17:01:48 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-25 17:01:48 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-25 17:01:48 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-25 17:01:48 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-25 17:01:48 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-25 17:01:48 --> Config Class Initialized
INFO - 2020-02-25 17:01:48 --> Config Class Initialized
INFO - 2020-02-25 17:01:48 --> Config Class Initialized
INFO - 2020-02-25 17:01:48 --> Config Class Initialized
INFO - 2020-02-25 17:01:48 --> Config Class Initialized
INFO - 2020-02-25 17:01:48 --> Config Class Initialized
INFO - 2020-02-25 17:01:48 --> Hooks Class Initialized
INFO - 2020-02-25 17:01:48 --> Hooks Class Initialized
INFO - 2020-02-25 17:01:48 --> Hooks Class Initialized
INFO - 2020-02-25 17:01:48 --> Hooks Class Initialized
INFO - 2020-02-25 17:01:48 --> Hooks Class Initialized
INFO - 2020-02-25 17:01:48 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:01:48 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:01:48 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:01:48 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:01:48 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:01:48 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:01:48 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:01:48 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:48 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:48 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:48 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:48 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:48 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:48 --> URI Class Initialized
INFO - 2020-02-25 17:01:48 --> URI Class Initialized
INFO - 2020-02-25 17:01:48 --> URI Class Initialized
INFO - 2020-02-25 17:01:48 --> URI Class Initialized
INFO - 2020-02-25 17:01:48 --> URI Class Initialized
INFO - 2020-02-25 17:01:48 --> URI Class Initialized
INFO - 2020-02-25 17:01:48 --> Router Class Initialized
INFO - 2020-02-25 17:01:48 --> Router Class Initialized
INFO - 2020-02-25 17:01:48 --> Router Class Initialized
INFO - 2020-02-25 17:01:48 --> Router Class Initialized
INFO - 2020-02-25 17:01:48 --> Router Class Initialized
INFO - 2020-02-25 17:01:48 --> Router Class Initialized
INFO - 2020-02-25 17:01:48 --> Output Class Initialized
INFO - 2020-02-25 17:01:48 --> Output Class Initialized
INFO - 2020-02-25 17:01:48 --> Output Class Initialized
INFO - 2020-02-25 17:01:48 --> Output Class Initialized
INFO - 2020-02-25 17:01:48 --> Output Class Initialized
INFO - 2020-02-25 17:01:48 --> Output Class Initialized
INFO - 2020-02-25 17:01:48 --> Security Class Initialized
INFO - 2020-02-25 17:01:48 --> Security Class Initialized
INFO - 2020-02-25 17:01:48 --> Security Class Initialized
INFO - 2020-02-25 17:01:48 --> Security Class Initialized
INFO - 2020-02-25 17:01:48 --> Security Class Initialized
INFO - 2020-02-25 17:01:48 --> Security Class Initialized
DEBUG - 2020-02-25 17:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:01:48 --> Input Class Initialized
INFO - 2020-02-25 17:01:48 --> Input Class Initialized
INFO - 2020-02-25 17:01:48 --> Input Class Initialized
INFO - 2020-02-25 17:01:48 --> Input Class Initialized
INFO - 2020-02-25 17:01:48 --> Input Class Initialized
INFO - 2020-02-25 17:01:48 --> Input Class Initialized
INFO - 2020-02-25 17:01:48 --> Language Class Initialized
INFO - 2020-02-25 17:01:48 --> Language Class Initialized
INFO - 2020-02-25 17:01:48 --> Language Class Initialized
INFO - 2020-02-25 17:01:48 --> Language Class Initialized
INFO - 2020-02-25 17:01:48 --> Language Class Initialized
INFO - 2020-02-25 17:01:48 --> Language Class Initialized
ERROR - 2020-02-25 17:01:48 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-25 17:01:48 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-25 17:01:48 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-25 17:01:48 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-25 17:01:48 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-25 17:01:48 --> Loader Class Initialized
INFO - 2020-02-25 17:01:48 --> Helper loaded: url_helper
INFO - 2020-02-25 17:01:48 --> Config Class Initialized
INFO - 2020-02-25 17:01:48 --> Config Class Initialized
INFO - 2020-02-25 17:01:48 --> Hooks Class Initialized
INFO - 2020-02-25 17:01:48 --> Hooks Class Initialized
INFO - 2020-02-25 17:01:48 --> Helper loaded: string_helper
DEBUG - 2020-02-25 17:01:48 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:01:48 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:01:48 --> Database Driver Class Initialized
INFO - 2020-02-25 17:01:48 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:48 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:48 --> URI Class Initialized
INFO - 2020-02-25 17:01:48 --> URI Class Initialized
DEBUG - 2020-02-25 17:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 17:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 17:01:49 --> Router Class Initialized
INFO - 2020-02-25 17:01:49 --> Router Class Initialized
INFO - 2020-02-25 17:01:49 --> Controller Class Initialized
INFO - 2020-02-25 17:01:49 --> Output Class Initialized
INFO - 2020-02-25 17:01:49 --> Output Class Initialized
INFO - 2020-02-25 17:01:49 --> Model "M_tiket" initialized
INFO - 2020-02-25 17:01:49 --> Security Class Initialized
INFO - 2020-02-25 17:01:49 --> Security Class Initialized
INFO - 2020-02-25 17:01:49 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-25 17:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:01:49 --> Input Class Initialized
INFO - 2020-02-25 17:01:49 --> Input Class Initialized
INFO - 2020-02-25 17:01:49 --> Model "M_pesan" initialized
INFO - 2020-02-25 17:01:49 --> Language Class Initialized
INFO - 2020-02-25 17:01:49 --> Language Class Initialized
INFO - 2020-02-25 17:01:49 --> Helper loaded: form_helper
INFO - 2020-02-25 17:01:49 --> Form Validation Class Initialized
ERROR - 2020-02-25 17:01:49 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-25 17:01:49 --> Loader Class Initialized
INFO - 2020-02-25 17:01:49 --> Helper loaded: url_helper
ERROR - 2020-02-25 17:01:49 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-25 17:01:49 --> Config Class Initialized
INFO - 2020-02-25 17:01:49 --> Hooks Class Initialized
INFO - 2020-02-25 17:01:49 --> Helper loaded: string_helper
ERROR - 2020-02-25 17:01:49 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 17:01:49 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-25 17:01:49 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:01:49 --> Database Driver Class Initialized
INFO - 2020-02-25 17:01:49 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:49 --> Final output sent to browser
DEBUG - 2020-02-25 17:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-25 17:01:49 --> Total execution time: 0.4214
INFO - 2020-02-25 17:01:49 --> URI Class Initialized
INFO - 2020-02-25 17:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 17:01:49 --> Router Class Initialized
INFO - 2020-02-25 17:01:49 --> Controller Class Initialized
INFO - 2020-02-25 17:01:49 --> Output Class Initialized
INFO - 2020-02-25 17:01:49 --> Model "M_tiket" initialized
INFO - 2020-02-25 17:01:49 --> Security Class Initialized
INFO - 2020-02-25 17:01:49 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-25 17:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:01:49 --> Input Class Initialized
INFO - 2020-02-25 17:01:49 --> Model "M_pesan" initialized
INFO - 2020-02-25 17:01:49 --> Language Class Initialized
INFO - 2020-02-25 17:01:49 --> Helper loaded: form_helper
INFO - 2020-02-25 17:01:49 --> Form Validation Class Initialized
ERROR - 2020-02-25 17:01:49 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-25 17:01:49 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-25 17:01:49 --> Config Class Initialized
INFO - 2020-02-25 17:01:49 --> Hooks Class Initialized
ERROR - 2020-02-25 17:01:49 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 17:01:49 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-25 17:01:49 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:01:49 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:49 --> Final output sent to browser
DEBUG - 2020-02-25 17:01:49 --> Total execution time: 0.4178
INFO - 2020-02-25 17:01:49 --> URI Class Initialized
INFO - 2020-02-25 17:01:49 --> Router Class Initialized
INFO - 2020-02-25 17:01:49 --> Output Class Initialized
INFO - 2020-02-25 17:01:49 --> Security Class Initialized
DEBUG - 2020-02-25 17:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:01:49 --> Input Class Initialized
INFO - 2020-02-25 17:01:49 --> Language Class Initialized
ERROR - 2020-02-25 17:01:49 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-25 17:01:49 --> Config Class Initialized
INFO - 2020-02-25 17:01:49 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:01:49 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:01:49 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:49 --> URI Class Initialized
INFO - 2020-02-25 17:01:49 --> Router Class Initialized
INFO - 2020-02-25 17:01:49 --> Output Class Initialized
INFO - 2020-02-25 17:01:49 --> Security Class Initialized
DEBUG - 2020-02-25 17:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:01:49 --> Input Class Initialized
INFO - 2020-02-25 17:01:49 --> Language Class Initialized
ERROR - 2020-02-25 17:01:49 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 17:01:49 --> Config Class Initialized
INFO - 2020-02-25 17:01:49 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:01:49 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:01:49 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:49 --> URI Class Initialized
INFO - 2020-02-25 17:01:49 --> Router Class Initialized
INFO - 2020-02-25 17:01:49 --> Output Class Initialized
INFO - 2020-02-25 17:01:49 --> Security Class Initialized
DEBUG - 2020-02-25 17:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:01:49 --> Input Class Initialized
INFO - 2020-02-25 17:01:49 --> Language Class Initialized
ERROR - 2020-02-25 17:01:49 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 17:01:49 --> Config Class Initialized
INFO - 2020-02-25 17:01:49 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:01:49 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:01:49 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:49 --> URI Class Initialized
INFO - 2020-02-25 17:01:49 --> Router Class Initialized
INFO - 2020-02-25 17:01:49 --> Output Class Initialized
INFO - 2020-02-25 17:01:49 --> Security Class Initialized
DEBUG - 2020-02-25 17:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:01:49 --> Input Class Initialized
INFO - 2020-02-25 17:01:49 --> Language Class Initialized
ERROR - 2020-02-25 17:01:49 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-25 17:01:49 --> Config Class Initialized
INFO - 2020-02-25 17:01:49 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:01:49 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:01:49 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:50 --> URI Class Initialized
INFO - 2020-02-25 17:01:50 --> Router Class Initialized
INFO - 2020-02-25 17:01:50 --> Output Class Initialized
INFO - 2020-02-25 17:01:50 --> Security Class Initialized
DEBUG - 2020-02-25 17:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:01:50 --> Input Class Initialized
INFO - 2020-02-25 17:01:50 --> Language Class Initialized
ERROR - 2020-02-25 17:01:50 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-25 17:01:50 --> Config Class Initialized
INFO - 2020-02-25 17:01:50 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:01:50 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:01:50 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:50 --> URI Class Initialized
INFO - 2020-02-25 17:01:50 --> Router Class Initialized
INFO - 2020-02-25 17:01:50 --> Output Class Initialized
INFO - 2020-02-25 17:01:50 --> Security Class Initialized
DEBUG - 2020-02-25 17:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:01:50 --> Input Class Initialized
INFO - 2020-02-25 17:01:50 --> Language Class Initialized
ERROR - 2020-02-25 17:01:50 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-25 17:01:50 --> Config Class Initialized
INFO - 2020-02-25 17:01:50 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:01:50 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:01:50 --> Utf8 Class Initialized
INFO - 2020-02-25 17:01:50 --> URI Class Initialized
INFO - 2020-02-25 17:01:50 --> Router Class Initialized
INFO - 2020-02-25 17:01:50 --> Output Class Initialized
INFO - 2020-02-25 17:01:50 --> Security Class Initialized
DEBUG - 2020-02-25 17:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:01:50 --> Input Class Initialized
INFO - 2020-02-25 17:01:50 --> Language Class Initialized
ERROR - 2020-02-25 17:01:50 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-25 17:02:05 --> Config Class Initialized
INFO - 2020-02-25 17:02:05 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:02:05 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:02:05 --> Utf8 Class Initialized
INFO - 2020-02-25 17:02:05 --> URI Class Initialized
INFO - 2020-02-25 17:02:05 --> Router Class Initialized
INFO - 2020-02-25 17:02:05 --> Output Class Initialized
INFO - 2020-02-25 17:02:05 --> Security Class Initialized
DEBUG - 2020-02-25 17:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:02:05 --> Input Class Initialized
INFO - 2020-02-25 17:02:05 --> Language Class Initialized
INFO - 2020-02-25 17:02:05 --> Loader Class Initialized
INFO - 2020-02-25 17:02:05 --> Helper loaded: url_helper
INFO - 2020-02-25 17:02:05 --> Helper loaded: string_helper
INFO - 2020-02-25 17:02:05 --> Database Driver Class Initialized
DEBUG - 2020-02-25 17:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 17:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 17:02:05 --> Controller Class Initialized
INFO - 2020-02-25 17:02:05 --> Model "M_tiket" initialized
INFO - 2020-02-25 17:02:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 17:02:05 --> Model "M_pesan" initialized
INFO - 2020-02-25 17:02:05 --> Helper loaded: form_helper
INFO - 2020-02-25 17:02:05 --> Form Validation Class Initialized
INFO - 2020-02-25 23:02:06 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-25 23:02:06 --> Final output sent to browser
DEBUG - 2020-02-25 23:02:06 --> Total execution time: 0.5650
INFO - 2020-02-25 17:02:25 --> Config Class Initialized
INFO - 2020-02-25 17:02:25 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:02:25 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:02:25 --> Utf8 Class Initialized
INFO - 2020-02-25 17:02:25 --> URI Class Initialized
DEBUG - 2020-02-25 17:02:25 --> No URI present. Default controller set.
INFO - 2020-02-25 17:02:25 --> Router Class Initialized
INFO - 2020-02-25 17:02:25 --> Output Class Initialized
INFO - 2020-02-25 17:02:25 --> Security Class Initialized
DEBUG - 2020-02-25 17:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:02:25 --> Input Class Initialized
INFO - 2020-02-25 17:02:25 --> Language Class Initialized
INFO - 2020-02-25 17:02:25 --> Loader Class Initialized
INFO - 2020-02-25 17:02:25 --> Helper loaded: url_helper
INFO - 2020-02-25 17:02:25 --> Helper loaded: string_helper
INFO - 2020-02-25 17:02:25 --> Database Driver Class Initialized
DEBUG - 2020-02-25 17:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 17:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 17:02:25 --> Controller Class Initialized
INFO - 2020-02-25 17:02:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:02:25 --> Pagination Class Initialized
INFO - 2020-02-25 17:02:25 --> Model "M_show" initialized
INFO - 2020-02-25 17:02:25 --> Helper loaded: form_helper
INFO - 2020-02-25 17:02:25 --> Form Validation Class Initialized
INFO - 2020-02-25 17:02:25 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-25 17:02:25 --> Final output sent to browser
DEBUG - 2020-02-25 17:02:25 --> Total execution time: 0.3812
INFO - 2020-02-25 17:02:25 --> Config Class Initialized
INFO - 2020-02-25 17:02:25 --> Config Class Initialized
INFO - 2020-02-25 17:02:25 --> Hooks Class Initialized
INFO - 2020-02-25 17:02:25 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:02:25 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:02:25 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:02:25 --> Utf8 Class Initialized
INFO - 2020-02-25 17:02:25 --> Utf8 Class Initialized
INFO - 2020-02-25 17:02:25 --> URI Class Initialized
INFO - 2020-02-25 17:02:25 --> URI Class Initialized
INFO - 2020-02-25 17:02:25 --> Router Class Initialized
INFO - 2020-02-25 17:02:25 --> Router Class Initialized
INFO - 2020-02-25 17:02:25 --> Output Class Initialized
INFO - 2020-02-25 17:02:25 --> Output Class Initialized
INFO - 2020-02-25 17:02:25 --> Security Class Initialized
INFO - 2020-02-25 17:02:25 --> Security Class Initialized
DEBUG - 2020-02-25 17:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:02:25 --> Input Class Initialized
INFO - 2020-02-25 17:02:25 --> Input Class Initialized
INFO - 2020-02-25 17:02:25 --> Language Class Initialized
INFO - 2020-02-25 17:02:25 --> Language Class Initialized
ERROR - 2020-02-25 17:02:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-02-25 17:02:25 --> 404 Page Not Found: Assets/js
INFO - 2020-02-25 17:02:27 --> Config Class Initialized
INFO - 2020-02-25 17:02:27 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:02:27 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:02:27 --> Utf8 Class Initialized
INFO - 2020-02-25 17:02:27 --> URI Class Initialized
INFO - 2020-02-25 17:02:27 --> Router Class Initialized
INFO - 2020-02-25 17:02:27 --> Output Class Initialized
INFO - 2020-02-25 17:02:27 --> Security Class Initialized
DEBUG - 2020-02-25 17:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:02:27 --> Input Class Initialized
INFO - 2020-02-25 17:02:27 --> Language Class Initialized
INFO - 2020-02-25 17:02:27 --> Loader Class Initialized
INFO - 2020-02-25 17:02:27 --> Helper loaded: url_helper
INFO - 2020-02-25 17:02:27 --> Helper loaded: string_helper
INFO - 2020-02-25 17:02:27 --> Database Driver Class Initialized
DEBUG - 2020-02-25 17:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 17:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 17:02:27 --> Controller Class Initialized
INFO - 2020-02-25 17:02:27 --> Model "M_tiket" initialized
INFO - 2020-02-25 17:02:27 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 17:02:27 --> Model "M_pesan" initialized
INFO - 2020-02-25 17:02:27 --> Helper loaded: form_helper
INFO - 2020-02-25 17:02:27 --> Form Validation Class Initialized
INFO - 2020-02-25 17:02:27 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 17:02:27 --> Final output sent to browser
DEBUG - 2020-02-25 17:02:27 --> Total execution time: 0.3993
INFO - 2020-02-25 17:02:27 --> Config Class Initialized
INFO - 2020-02-25 17:02:27 --> Config Class Initialized
INFO - 2020-02-25 17:02:27 --> Config Class Initialized
INFO - 2020-02-25 17:02:27 --> Config Class Initialized
INFO - 2020-02-25 17:02:27 --> Config Class Initialized
INFO - 2020-02-25 17:02:27 --> Config Class Initialized
INFO - 2020-02-25 17:02:27 --> Hooks Class Initialized
INFO - 2020-02-25 17:02:27 --> Hooks Class Initialized
INFO - 2020-02-25 17:02:27 --> Hooks Class Initialized
INFO - 2020-02-25 17:02:27 --> Hooks Class Initialized
INFO - 2020-02-25 17:02:27 --> Hooks Class Initialized
INFO - 2020-02-25 17:02:27 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:02:27 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:02:27 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:02:27 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:02:27 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:02:27 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:02:27 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:02:27 --> Utf8 Class Initialized
INFO - 2020-02-25 17:02:27 --> Utf8 Class Initialized
INFO - 2020-02-25 17:02:27 --> Utf8 Class Initialized
INFO - 2020-02-25 17:02:27 --> Utf8 Class Initialized
INFO - 2020-02-25 17:02:27 --> Utf8 Class Initialized
INFO - 2020-02-25 17:02:27 --> Utf8 Class Initialized
INFO - 2020-02-25 17:02:27 --> URI Class Initialized
INFO - 2020-02-25 17:02:27 --> URI Class Initialized
INFO - 2020-02-25 17:02:27 --> URI Class Initialized
INFO - 2020-02-25 17:02:27 --> URI Class Initialized
INFO - 2020-02-25 17:02:27 --> URI Class Initialized
INFO - 2020-02-25 17:02:27 --> URI Class Initialized
INFO - 2020-02-25 17:02:27 --> Router Class Initialized
INFO - 2020-02-25 17:02:27 --> Router Class Initialized
INFO - 2020-02-25 17:02:27 --> Router Class Initialized
INFO - 2020-02-25 17:02:27 --> Router Class Initialized
INFO - 2020-02-25 17:02:27 --> Router Class Initialized
INFO - 2020-02-25 17:02:27 --> Router Class Initialized
INFO - 2020-02-25 17:02:27 --> Output Class Initialized
INFO - 2020-02-25 17:02:27 --> Output Class Initialized
INFO - 2020-02-25 17:02:27 --> Output Class Initialized
INFO - 2020-02-25 17:02:27 --> Output Class Initialized
INFO - 2020-02-25 17:02:27 --> Output Class Initialized
INFO - 2020-02-25 17:02:27 --> Output Class Initialized
INFO - 2020-02-25 17:02:27 --> Security Class Initialized
INFO - 2020-02-25 17:02:27 --> Security Class Initialized
INFO - 2020-02-25 17:02:27 --> Security Class Initialized
INFO - 2020-02-25 17:02:27 --> Security Class Initialized
INFO - 2020-02-25 17:02:27 --> Security Class Initialized
INFO - 2020-02-25 17:02:27 --> Security Class Initialized
DEBUG - 2020-02-25 17:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:02:27 --> Input Class Initialized
INFO - 2020-02-25 17:02:27 --> Input Class Initialized
INFO - 2020-02-25 17:02:27 --> Input Class Initialized
INFO - 2020-02-25 17:02:27 --> Input Class Initialized
INFO - 2020-02-25 17:02:27 --> Input Class Initialized
INFO - 2020-02-25 17:02:27 --> Input Class Initialized
INFO - 2020-02-25 17:02:27 --> Language Class Initialized
INFO - 2020-02-25 17:02:27 --> Language Class Initialized
INFO - 2020-02-25 17:02:27 --> Language Class Initialized
INFO - 2020-02-25 17:02:27 --> Language Class Initialized
INFO - 2020-02-25 17:02:27 --> Language Class Initialized
INFO - 2020-02-25 17:02:27 --> Language Class Initialized
ERROR - 2020-02-25 17:02:27 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-25 17:02:27 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-25 17:02:27 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-25 17:02:27 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-25 17:02:27 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-25 17:02:27 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-25 17:02:28 --> Config Class Initialized
INFO - 2020-02-25 17:02:28 --> Config Class Initialized
INFO - 2020-02-25 17:02:28 --> Config Class Initialized
INFO - 2020-02-25 17:02:28 --> Config Class Initialized
INFO - 2020-02-25 17:02:28 --> Config Class Initialized
INFO - 2020-02-25 17:02:28 --> Config Class Initialized
INFO - 2020-02-25 17:02:28 --> Hooks Class Initialized
INFO - 2020-02-25 17:02:28 --> Hooks Class Initialized
INFO - 2020-02-25 17:02:28 --> Hooks Class Initialized
INFO - 2020-02-25 17:02:28 --> Hooks Class Initialized
INFO - 2020-02-25 17:02:28 --> Hooks Class Initialized
INFO - 2020-02-25 17:02:28 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:02:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:02:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:02:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:02:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:02:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:02:28 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:02:28 --> Utf8 Class Initialized
INFO - 2020-02-25 17:02:28 --> Utf8 Class Initialized
INFO - 2020-02-25 17:02:28 --> Utf8 Class Initialized
INFO - 2020-02-25 17:02:28 --> Utf8 Class Initialized
INFO - 2020-02-25 17:02:28 --> Utf8 Class Initialized
INFO - 2020-02-25 17:02:28 --> Utf8 Class Initialized
INFO - 2020-02-25 17:02:28 --> URI Class Initialized
INFO - 2020-02-25 17:02:28 --> URI Class Initialized
INFO - 2020-02-25 17:02:28 --> URI Class Initialized
INFO - 2020-02-25 17:02:28 --> URI Class Initialized
INFO - 2020-02-25 17:02:28 --> URI Class Initialized
INFO - 2020-02-25 17:02:28 --> URI Class Initialized
INFO - 2020-02-25 17:02:28 --> Router Class Initialized
INFO - 2020-02-25 17:02:28 --> Router Class Initialized
INFO - 2020-02-25 17:02:28 --> Router Class Initialized
INFO - 2020-02-25 17:02:28 --> Router Class Initialized
INFO - 2020-02-25 17:02:28 --> Router Class Initialized
INFO - 2020-02-25 17:02:28 --> Router Class Initialized
INFO - 2020-02-25 17:02:28 --> Output Class Initialized
INFO - 2020-02-25 17:02:28 --> Output Class Initialized
INFO - 2020-02-25 17:02:28 --> Output Class Initialized
INFO - 2020-02-25 17:02:28 --> Output Class Initialized
INFO - 2020-02-25 17:02:28 --> Output Class Initialized
INFO - 2020-02-25 17:02:28 --> Output Class Initialized
INFO - 2020-02-25 17:02:28 --> Security Class Initialized
INFO - 2020-02-25 17:02:28 --> Security Class Initialized
INFO - 2020-02-25 17:02:28 --> Security Class Initialized
INFO - 2020-02-25 17:02:28 --> Security Class Initialized
INFO - 2020-02-25 17:02:28 --> Security Class Initialized
INFO - 2020-02-25 17:02:28 --> Security Class Initialized
DEBUG - 2020-02-25 17:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:02:28 --> Input Class Initialized
INFO - 2020-02-25 17:02:28 --> Input Class Initialized
INFO - 2020-02-25 17:02:28 --> Input Class Initialized
INFO - 2020-02-25 17:02:28 --> Input Class Initialized
INFO - 2020-02-25 17:02:28 --> Input Class Initialized
INFO - 2020-02-25 17:02:28 --> Input Class Initialized
INFO - 2020-02-25 17:02:28 --> Language Class Initialized
INFO - 2020-02-25 17:02:28 --> Language Class Initialized
INFO - 2020-02-25 17:02:28 --> Language Class Initialized
INFO - 2020-02-25 17:02:28 --> Language Class Initialized
INFO - 2020-02-25 17:02:28 --> Language Class Initialized
INFO - 2020-02-25 17:02:28 --> Language Class Initialized
ERROR - 2020-02-25 17:02:28 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-25 17:02:28 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-25 17:02:28 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-25 17:02:28 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-25 17:02:28 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-25 17:02:28 --> Loader Class Initialized
INFO - 2020-02-25 17:02:28 --> Helper loaded: url_helper
INFO - 2020-02-25 17:02:28 --> Config Class Initialized
INFO - 2020-02-25 17:02:28 --> Config Class Initialized
INFO - 2020-02-25 17:02:28 --> Hooks Class Initialized
INFO - 2020-02-25 17:02:28 --> Hooks Class Initialized
INFO - 2020-02-25 17:02:28 --> Helper loaded: string_helper
DEBUG - 2020-02-25 17:02:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:02:28 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:02:28 --> Database Driver Class Initialized
INFO - 2020-02-25 17:02:28 --> Utf8 Class Initialized
INFO - 2020-02-25 17:02:28 --> Utf8 Class Initialized
DEBUG - 2020-02-25 17:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 17:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 17:02:28 --> URI Class Initialized
INFO - 2020-02-25 17:02:28 --> URI Class Initialized
INFO - 2020-02-25 17:02:28 --> Controller Class Initialized
INFO - 2020-02-25 17:02:28 --> Router Class Initialized
INFO - 2020-02-25 17:02:28 --> Router Class Initialized
INFO - 2020-02-25 17:02:28 --> Model "M_tiket" initialized
INFO - 2020-02-25 17:02:28 --> Output Class Initialized
INFO - 2020-02-25 17:02:28 --> Output Class Initialized
INFO - 2020-02-25 17:02:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 17:02:28 --> Security Class Initialized
INFO - 2020-02-25 17:02:28 --> Security Class Initialized
INFO - 2020-02-25 17:02:28 --> Model "M_pesan" initialized
DEBUG - 2020-02-25 17:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:02:28 --> Input Class Initialized
INFO - 2020-02-25 17:02:28 --> Input Class Initialized
INFO - 2020-02-25 17:02:28 --> Helper loaded: form_helper
INFO - 2020-02-25 17:02:28 --> Form Validation Class Initialized
INFO - 2020-02-25 17:02:28 --> Language Class Initialized
INFO - 2020-02-25 17:02:28 --> Language Class Initialized
ERROR - 2020-02-25 17:02:28 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-25 17:02:28 --> Loader Class Initialized
ERROR - 2020-02-25 17:02:28 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 17:02:28 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 17:02:28 --> Helper loaded: url_helper
INFO - 2020-02-25 17:02:28 --> Config Class Initialized
INFO - 2020-02-25 17:02:28 --> Hooks Class Initialized
INFO - 2020-02-25 17:02:28 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 17:02:28 --> Helper loaded: string_helper
INFO - 2020-02-25 17:02:28 --> Final output sent to browser
DEBUG - 2020-02-25 17:02:28 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:02:28 --> Database Driver Class Initialized
INFO - 2020-02-25 17:02:28 --> Utf8 Class Initialized
DEBUG - 2020-02-25 17:02:28 --> Total execution time: 0.3777
DEBUG - 2020-02-25 17:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 17:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 17:02:28 --> URI Class Initialized
INFO - 2020-02-25 17:02:28 --> Controller Class Initialized
INFO - 2020-02-25 17:02:28 --> Router Class Initialized
INFO - 2020-02-25 17:02:28 --> Model "M_tiket" initialized
INFO - 2020-02-25 17:02:28 --> Output Class Initialized
INFO - 2020-02-25 17:02:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 17:02:28 --> Security Class Initialized
INFO - 2020-02-25 17:02:28 --> Model "M_pesan" initialized
DEBUG - 2020-02-25 17:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:02:28 --> Input Class Initialized
INFO - 2020-02-25 17:02:28 --> Helper loaded: form_helper
INFO - 2020-02-25 17:02:28 --> Form Validation Class Initialized
INFO - 2020-02-25 17:02:28 --> Language Class Initialized
ERROR - 2020-02-25 17:02:28 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-25 17:02:28 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 17:02:28 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 17:02:28 --> Config Class Initialized
INFO - 2020-02-25 17:02:28 --> Hooks Class Initialized
INFO - 2020-02-25 17:02:28 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 17:02:28 --> Final output sent to browser
DEBUG - 2020-02-25 17:02:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:02:28 --> Total execution time: 0.3541
INFO - 2020-02-25 17:02:28 --> Utf8 Class Initialized
INFO - 2020-02-25 17:02:28 --> URI Class Initialized
INFO - 2020-02-25 17:02:28 --> Router Class Initialized
INFO - 2020-02-25 17:02:28 --> Output Class Initialized
INFO - 2020-02-25 17:02:28 --> Security Class Initialized
DEBUG - 2020-02-25 17:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:02:28 --> Input Class Initialized
INFO - 2020-02-25 17:02:28 --> Language Class Initialized
ERROR - 2020-02-25 17:02:28 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-25 17:02:28 --> Config Class Initialized
INFO - 2020-02-25 17:02:28 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:02:28 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:02:28 --> Utf8 Class Initialized
INFO - 2020-02-25 17:02:28 --> URI Class Initialized
INFO - 2020-02-25 17:02:28 --> Router Class Initialized
INFO - 2020-02-25 17:02:28 --> Output Class Initialized
INFO - 2020-02-25 17:02:28 --> Security Class Initialized
DEBUG - 2020-02-25 17:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:02:28 --> Input Class Initialized
INFO - 2020-02-25 17:02:28 --> Language Class Initialized
ERROR - 2020-02-25 17:02:28 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-25 17:02:28 --> Config Class Initialized
INFO - 2020-02-25 17:02:28 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:02:28 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:02:28 --> Utf8 Class Initialized
INFO - 2020-02-25 17:02:28 --> URI Class Initialized
INFO - 2020-02-25 17:02:28 --> Router Class Initialized
INFO - 2020-02-25 17:02:28 --> Output Class Initialized
INFO - 2020-02-25 17:02:28 --> Security Class Initialized
DEBUG - 2020-02-25 17:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:02:29 --> Input Class Initialized
INFO - 2020-02-25 17:02:29 --> Language Class Initialized
ERROR - 2020-02-25 17:02:29 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 17:02:29 --> Config Class Initialized
INFO - 2020-02-25 17:02:29 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:02:29 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:02:29 --> Utf8 Class Initialized
INFO - 2020-02-25 17:02:29 --> URI Class Initialized
INFO - 2020-02-25 17:02:29 --> Router Class Initialized
INFO - 2020-02-25 17:02:29 --> Output Class Initialized
INFO - 2020-02-25 17:02:29 --> Security Class Initialized
DEBUG - 2020-02-25 17:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:02:29 --> Input Class Initialized
INFO - 2020-02-25 17:02:29 --> Language Class Initialized
ERROR - 2020-02-25 17:02:29 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 17:02:29 --> Config Class Initialized
INFO - 2020-02-25 17:02:29 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:02:29 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:02:29 --> Utf8 Class Initialized
INFO - 2020-02-25 17:02:29 --> URI Class Initialized
INFO - 2020-02-25 17:02:29 --> Router Class Initialized
INFO - 2020-02-25 17:02:29 --> Output Class Initialized
INFO - 2020-02-25 17:02:29 --> Security Class Initialized
DEBUG - 2020-02-25 17:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:02:29 --> Input Class Initialized
INFO - 2020-02-25 17:02:29 --> Language Class Initialized
ERROR - 2020-02-25 17:02:29 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-25 17:02:29 --> Config Class Initialized
INFO - 2020-02-25 17:02:29 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:02:29 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:02:29 --> Utf8 Class Initialized
INFO - 2020-02-25 17:02:29 --> URI Class Initialized
INFO - 2020-02-25 17:02:29 --> Router Class Initialized
INFO - 2020-02-25 17:02:29 --> Output Class Initialized
INFO - 2020-02-25 17:02:29 --> Security Class Initialized
DEBUG - 2020-02-25 17:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:02:29 --> Input Class Initialized
INFO - 2020-02-25 17:02:29 --> Language Class Initialized
ERROR - 2020-02-25 17:02:29 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-25 17:02:29 --> Config Class Initialized
INFO - 2020-02-25 17:02:29 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:02:29 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:02:29 --> Utf8 Class Initialized
INFO - 2020-02-25 17:02:29 --> URI Class Initialized
INFO - 2020-02-25 17:02:29 --> Router Class Initialized
INFO - 2020-02-25 17:02:29 --> Output Class Initialized
INFO - 2020-02-25 17:02:29 --> Security Class Initialized
DEBUG - 2020-02-25 17:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:02:29 --> Input Class Initialized
INFO - 2020-02-25 17:02:29 --> Language Class Initialized
ERROR - 2020-02-25 17:02:29 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-25 17:02:29 --> Config Class Initialized
INFO - 2020-02-25 17:02:29 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:02:29 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:02:29 --> Utf8 Class Initialized
INFO - 2020-02-25 17:02:29 --> URI Class Initialized
INFO - 2020-02-25 17:02:29 --> Router Class Initialized
INFO - 2020-02-25 17:02:29 --> Output Class Initialized
INFO - 2020-02-25 17:02:29 --> Security Class Initialized
DEBUG - 2020-02-25 17:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:02:29 --> Input Class Initialized
INFO - 2020-02-25 17:02:29 --> Language Class Initialized
ERROR - 2020-02-25 17:02:29 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-25 17:02:38 --> Config Class Initialized
INFO - 2020-02-25 17:02:38 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:02:38 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:02:38 --> Utf8 Class Initialized
INFO - 2020-02-25 17:02:38 --> URI Class Initialized
INFO - 2020-02-25 17:02:38 --> Router Class Initialized
INFO - 2020-02-25 17:02:38 --> Output Class Initialized
INFO - 2020-02-25 17:02:38 --> Security Class Initialized
DEBUG - 2020-02-25 17:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:02:38 --> Input Class Initialized
INFO - 2020-02-25 17:02:38 --> Language Class Initialized
INFO - 2020-02-25 17:02:38 --> Loader Class Initialized
INFO - 2020-02-25 17:02:38 --> Helper loaded: url_helper
INFO - 2020-02-25 17:02:39 --> Helper loaded: string_helper
INFO - 2020-02-25 17:02:39 --> Database Driver Class Initialized
DEBUG - 2020-02-25 17:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 17:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 17:02:39 --> Controller Class Initialized
INFO - 2020-02-25 17:02:39 --> Model "M_tiket" initialized
INFO - 2020-02-25 17:02:39 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 17:02:39 --> Model "M_pesan" initialized
INFO - 2020-02-25 17:02:39 --> Helper loaded: form_helper
INFO - 2020-02-25 17:02:39 --> Form Validation Class Initialized
INFO - 2020-02-25 23:02:39 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-25 23:02:39 --> Final output sent to browser
DEBUG - 2020-02-25 23:02:39 --> Total execution time: 0.5081
INFO - 2020-02-25 17:12:56 --> Config Class Initialized
INFO - 2020-02-25 17:12:56 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:12:56 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:12:56 --> Utf8 Class Initialized
INFO - 2020-02-25 17:12:56 --> URI Class Initialized
DEBUG - 2020-02-25 17:12:56 --> No URI present. Default controller set.
INFO - 2020-02-25 17:12:56 --> Router Class Initialized
INFO - 2020-02-25 17:12:56 --> Output Class Initialized
INFO - 2020-02-25 17:12:56 --> Security Class Initialized
DEBUG - 2020-02-25 17:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:12:56 --> Input Class Initialized
INFO - 2020-02-25 17:12:56 --> Language Class Initialized
INFO - 2020-02-25 17:12:56 --> Loader Class Initialized
INFO - 2020-02-25 17:12:56 --> Helper loaded: url_helper
INFO - 2020-02-25 17:12:56 --> Helper loaded: string_helper
INFO - 2020-02-25 17:12:56 --> Database Driver Class Initialized
DEBUG - 2020-02-25 17:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 17:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 17:12:56 --> Controller Class Initialized
INFO - 2020-02-25 17:12:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 17:12:56 --> Pagination Class Initialized
INFO - 2020-02-25 17:12:56 --> Model "M_show" initialized
INFO - 2020-02-25 17:12:56 --> Helper loaded: form_helper
INFO - 2020-02-25 17:12:56 --> Form Validation Class Initialized
INFO - 2020-02-25 17:12:56 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-25 17:12:56 --> Final output sent to browser
DEBUG - 2020-02-25 17:12:56 --> Total execution time: 0.3838
INFO - 2020-02-25 17:13:01 --> Config Class Initialized
INFO - 2020-02-25 17:13:01 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:13:01 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:13:01 --> Utf8 Class Initialized
INFO - 2020-02-25 17:13:01 --> URI Class Initialized
INFO - 2020-02-25 17:13:01 --> Router Class Initialized
INFO - 2020-02-25 17:13:01 --> Output Class Initialized
INFO - 2020-02-25 17:13:01 --> Security Class Initialized
DEBUG - 2020-02-25 17:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:13:01 --> Input Class Initialized
INFO - 2020-02-25 17:13:01 --> Language Class Initialized
INFO - 2020-02-25 17:13:01 --> Loader Class Initialized
INFO - 2020-02-25 17:13:01 --> Helper loaded: url_helper
INFO - 2020-02-25 17:13:01 --> Helper loaded: string_helper
INFO - 2020-02-25 17:13:01 --> Database Driver Class Initialized
DEBUG - 2020-02-25 17:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 17:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 17:13:01 --> Controller Class Initialized
INFO - 2020-02-25 17:13:01 --> Model "M_tiket" initialized
INFO - 2020-02-25 17:13:01 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 17:13:01 --> Model "M_pesan" initialized
INFO - 2020-02-25 17:13:01 --> Helper loaded: form_helper
INFO - 2020-02-25 17:13:01 --> Form Validation Class Initialized
INFO - 2020-02-25 17:13:01 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 17:13:01 --> Final output sent to browser
DEBUG - 2020-02-25 17:13:01 --> Total execution time: 0.4143
INFO - 2020-02-25 17:13:01 --> Config Class Initialized
INFO - 2020-02-25 17:13:01 --> Config Class Initialized
INFO - 2020-02-25 17:13:01 --> Config Class Initialized
INFO - 2020-02-25 17:13:01 --> Config Class Initialized
INFO - 2020-02-25 17:13:01 --> Config Class Initialized
INFO - 2020-02-25 17:13:01 --> Config Class Initialized
INFO - 2020-02-25 17:13:01 --> Hooks Class Initialized
INFO - 2020-02-25 17:13:01 --> Hooks Class Initialized
INFO - 2020-02-25 17:13:01 --> Hooks Class Initialized
INFO - 2020-02-25 17:13:01 --> Hooks Class Initialized
INFO - 2020-02-25 17:13:01 --> Hooks Class Initialized
INFO - 2020-02-25 17:13:01 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:13:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:13:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:13:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:13:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:13:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:13:01 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:13:01 --> Utf8 Class Initialized
INFO - 2020-02-25 17:13:01 --> Utf8 Class Initialized
INFO - 2020-02-25 17:13:01 --> Utf8 Class Initialized
INFO - 2020-02-25 17:13:01 --> Utf8 Class Initialized
INFO - 2020-02-25 17:13:01 --> Utf8 Class Initialized
INFO - 2020-02-25 17:13:01 --> Utf8 Class Initialized
INFO - 2020-02-25 17:13:02 --> URI Class Initialized
INFO - 2020-02-25 17:13:02 --> URI Class Initialized
INFO - 2020-02-25 17:13:02 --> URI Class Initialized
INFO - 2020-02-25 17:13:02 --> URI Class Initialized
INFO - 2020-02-25 17:13:02 --> URI Class Initialized
INFO - 2020-02-25 17:13:02 --> URI Class Initialized
INFO - 2020-02-25 17:13:02 --> Router Class Initialized
INFO - 2020-02-25 17:13:02 --> Router Class Initialized
INFO - 2020-02-25 17:13:02 --> Router Class Initialized
INFO - 2020-02-25 17:13:02 --> Router Class Initialized
INFO - 2020-02-25 17:13:02 --> Router Class Initialized
INFO - 2020-02-25 17:13:02 --> Router Class Initialized
INFO - 2020-02-25 17:13:02 --> Output Class Initialized
INFO - 2020-02-25 17:13:02 --> Output Class Initialized
INFO - 2020-02-25 17:13:02 --> Output Class Initialized
INFO - 2020-02-25 17:13:02 --> Output Class Initialized
INFO - 2020-02-25 17:13:02 --> Output Class Initialized
INFO - 2020-02-25 17:13:02 --> Output Class Initialized
INFO - 2020-02-25 17:13:02 --> Security Class Initialized
INFO - 2020-02-25 17:13:02 --> Security Class Initialized
INFO - 2020-02-25 17:13:02 --> Security Class Initialized
INFO - 2020-02-25 17:13:02 --> Security Class Initialized
INFO - 2020-02-25 17:13:02 --> Security Class Initialized
INFO - 2020-02-25 17:13:02 --> Security Class Initialized
DEBUG - 2020-02-25 17:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:13:02 --> Input Class Initialized
INFO - 2020-02-25 17:13:02 --> Input Class Initialized
INFO - 2020-02-25 17:13:02 --> Input Class Initialized
INFO - 2020-02-25 17:13:02 --> Input Class Initialized
INFO - 2020-02-25 17:13:02 --> Input Class Initialized
INFO - 2020-02-25 17:13:02 --> Input Class Initialized
INFO - 2020-02-25 17:13:02 --> Language Class Initialized
INFO - 2020-02-25 17:13:02 --> Language Class Initialized
INFO - 2020-02-25 17:13:02 --> Language Class Initialized
INFO - 2020-02-25 17:13:02 --> Language Class Initialized
INFO - 2020-02-25 17:13:02 --> Language Class Initialized
INFO - 2020-02-25 17:13:02 --> Language Class Initialized
ERROR - 2020-02-25 17:13:02 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-25 17:13:02 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-25 17:13:02 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-25 17:13:02 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-25 17:13:02 --> Loader Class Initialized
INFO - 2020-02-25 17:13:02 --> Loader Class Initialized
INFO - 2020-02-25 17:13:02 --> Helper loaded: url_helper
INFO - 2020-02-25 17:13:02 --> Helper loaded: url_helper
INFO - 2020-02-25 17:13:02 --> Config Class Initialized
INFO - 2020-02-25 17:13:02 --> Config Class Initialized
INFO - 2020-02-25 17:13:02 --> Config Class Initialized
INFO - 2020-02-25 17:13:02 --> Config Class Initialized
INFO - 2020-02-25 17:13:02 --> Hooks Class Initialized
INFO - 2020-02-25 17:13:02 --> Hooks Class Initialized
INFO - 2020-02-25 17:13:02 --> Hooks Class Initialized
INFO - 2020-02-25 17:13:02 --> Hooks Class Initialized
INFO - 2020-02-25 17:13:02 --> Helper loaded: string_helper
INFO - 2020-02-25 17:13:02 --> Helper loaded: string_helper
DEBUG - 2020-02-25 17:13:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:13:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:13:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:13:02 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:13:02 --> Database Driver Class Initialized
INFO - 2020-02-25 17:13:02 --> Database Driver Class Initialized
INFO - 2020-02-25 17:13:02 --> Utf8 Class Initialized
INFO - 2020-02-25 17:13:02 --> Utf8 Class Initialized
INFO - 2020-02-25 17:13:02 --> Utf8 Class Initialized
INFO - 2020-02-25 17:13:02 --> Utf8 Class Initialized
DEBUG - 2020-02-25 17:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-25 17:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 17:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 17:13:02 --> URI Class Initialized
INFO - 2020-02-25 17:13:02 --> URI Class Initialized
INFO - 2020-02-25 17:13:02 --> URI Class Initialized
INFO - 2020-02-25 17:13:02 --> URI Class Initialized
INFO - 2020-02-25 17:13:02 --> Controller Class Initialized
INFO - 2020-02-25 17:13:02 --> Router Class Initialized
INFO - 2020-02-25 17:13:02 --> Router Class Initialized
INFO - 2020-02-25 17:13:02 --> Router Class Initialized
INFO - 2020-02-25 17:13:02 --> Router Class Initialized
INFO - 2020-02-25 17:13:02 --> Model "M_tiket" initialized
INFO - 2020-02-25 17:13:02 --> Output Class Initialized
INFO - 2020-02-25 17:13:02 --> Output Class Initialized
INFO - 2020-02-25 17:13:02 --> Output Class Initialized
INFO - 2020-02-25 17:13:02 --> Output Class Initialized
INFO - 2020-02-25 17:13:02 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 17:13:02 --> Security Class Initialized
INFO - 2020-02-25 17:13:02 --> Security Class Initialized
INFO - 2020-02-25 17:13:02 --> Security Class Initialized
INFO - 2020-02-25 17:13:02 --> Security Class Initialized
INFO - 2020-02-25 17:13:02 --> Model "M_pesan" initialized
DEBUG - 2020-02-25 17:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:13:02 --> Input Class Initialized
INFO - 2020-02-25 17:13:02 --> Input Class Initialized
INFO - 2020-02-25 17:13:02 --> Input Class Initialized
INFO - 2020-02-25 17:13:02 --> Input Class Initialized
INFO - 2020-02-25 17:13:02 --> Helper loaded: form_helper
INFO - 2020-02-25 17:13:02 --> Form Validation Class Initialized
INFO - 2020-02-25 17:13:02 --> Language Class Initialized
INFO - 2020-02-25 17:13:02 --> Language Class Initialized
INFO - 2020-02-25 17:13:02 --> Language Class Initialized
INFO - 2020-02-25 17:13:02 --> Language Class Initialized
ERROR - 2020-02-25 17:13:02 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-25 17:13:02 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-25 17:13:02 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-25 17:13:02 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-25 17:13:02 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 17:13:02 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 17:13:02 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 17:13:02 --> Config Class Initialized
INFO - 2020-02-25 17:13:02 --> Config Class Initialized
INFO - 2020-02-25 17:13:02 --> Config Class Initialized
INFO - 2020-02-25 17:13:02 --> Config Class Initialized
INFO - 2020-02-25 17:13:02 --> Hooks Class Initialized
INFO - 2020-02-25 17:13:02 --> Hooks Class Initialized
INFO - 2020-02-25 17:13:02 --> Hooks Class Initialized
INFO - 2020-02-25 17:13:02 --> Hooks Class Initialized
INFO - 2020-02-25 17:13:02 --> Final output sent to browser
DEBUG - 2020-02-25 17:13:02 --> Total execution time: 0.9391
DEBUG - 2020-02-25 17:13:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:13:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:13:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 17:13:02 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:13:02 --> Utf8 Class Initialized
INFO - 2020-02-25 17:13:02 --> Utf8 Class Initialized
INFO - 2020-02-25 17:13:02 --> Utf8 Class Initialized
INFO - 2020-02-25 17:13:02 --> Utf8 Class Initialized
INFO - 2020-02-25 17:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 17:13:02 --> Controller Class Initialized
INFO - 2020-02-25 17:13:02 --> URI Class Initialized
INFO - 2020-02-25 17:13:02 --> URI Class Initialized
INFO - 2020-02-25 17:13:02 --> URI Class Initialized
INFO - 2020-02-25 17:13:02 --> URI Class Initialized
INFO - 2020-02-25 17:13:02 --> Router Class Initialized
INFO - 2020-02-25 17:13:02 --> Model "M_tiket" initialized
INFO - 2020-02-25 17:13:02 --> Router Class Initialized
INFO - 2020-02-25 17:13:02 --> Router Class Initialized
INFO - 2020-02-25 17:13:02 --> Router Class Initialized
INFO - 2020-02-25 17:13:02 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 17:13:02 --> Output Class Initialized
INFO - 2020-02-25 17:13:02 --> Output Class Initialized
INFO - 2020-02-25 17:13:02 --> Output Class Initialized
INFO - 2020-02-25 17:13:02 --> Output Class Initialized
INFO - 2020-02-25 17:13:02 --> Model "M_pesan" initialized
INFO - 2020-02-25 17:13:02 --> Security Class Initialized
INFO - 2020-02-25 17:13:02 --> Security Class Initialized
INFO - 2020-02-25 17:13:02 --> Security Class Initialized
INFO - 2020-02-25 17:13:02 --> Security Class Initialized
DEBUG - 2020-02-25 17:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 17:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:13:02 --> Helper loaded: form_helper
INFO - 2020-02-25 17:13:02 --> Input Class Initialized
INFO - 2020-02-25 17:13:02 --> Input Class Initialized
INFO - 2020-02-25 17:13:02 --> Form Validation Class Initialized
INFO - 2020-02-25 17:13:02 --> Input Class Initialized
INFO - 2020-02-25 17:13:02 --> Input Class Initialized
INFO - 2020-02-25 17:13:02 --> Language Class Initialized
INFO - 2020-02-25 17:13:02 --> Language Class Initialized
INFO - 2020-02-25 17:13:02 --> Language Class Initialized
INFO - 2020-02-25 17:13:02 --> Language Class Initialized
ERROR - 2020-02-25 17:13:02 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 17:13:03 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-25 17:13:03 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-25 17:13:03 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-25 17:13:03 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-25 17:13:03 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-25 17:13:03 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 17:13:03 --> Config Class Initialized
INFO - 2020-02-25 17:13:03 --> Hooks Class Initialized
INFO - 2020-02-25 17:13:03 --> Final output sent to browser
DEBUG - 2020-02-25 17:13:03 --> Total execution time: 1.1437
DEBUG - 2020-02-25 17:13:03 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:13:03 --> Utf8 Class Initialized
INFO - 2020-02-25 17:13:03 --> URI Class Initialized
INFO - 2020-02-25 17:13:03 --> Router Class Initialized
INFO - 2020-02-25 17:13:03 --> Output Class Initialized
INFO - 2020-02-25 17:13:03 --> Security Class Initialized
DEBUG - 2020-02-25 17:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:13:03 --> Input Class Initialized
INFO - 2020-02-25 17:13:03 --> Language Class Initialized
ERROR - 2020-02-25 17:13:03 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-25 17:13:03 --> Config Class Initialized
INFO - 2020-02-25 17:13:03 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:13:03 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:13:03 --> Utf8 Class Initialized
INFO - 2020-02-25 17:13:03 --> URI Class Initialized
INFO - 2020-02-25 17:13:03 --> Router Class Initialized
INFO - 2020-02-25 17:13:03 --> Output Class Initialized
INFO - 2020-02-25 17:13:03 --> Security Class Initialized
DEBUG - 2020-02-25 17:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:13:03 --> Input Class Initialized
INFO - 2020-02-25 17:13:03 --> Language Class Initialized
ERROR - 2020-02-25 17:13:03 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-25 17:13:03 --> Config Class Initialized
INFO - 2020-02-25 17:13:03 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:13:03 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:13:03 --> Utf8 Class Initialized
INFO - 2020-02-25 17:13:03 --> URI Class Initialized
INFO - 2020-02-25 17:13:03 --> Router Class Initialized
INFO - 2020-02-25 17:13:03 --> Output Class Initialized
INFO - 2020-02-25 17:13:03 --> Security Class Initialized
DEBUG - 2020-02-25 17:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:13:03 --> Input Class Initialized
INFO - 2020-02-25 17:13:03 --> Language Class Initialized
ERROR - 2020-02-25 17:13:03 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-25 17:13:03 --> Config Class Initialized
INFO - 2020-02-25 17:13:03 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:13:03 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:13:03 --> Utf8 Class Initialized
INFO - 2020-02-25 17:13:03 --> URI Class Initialized
INFO - 2020-02-25 17:13:03 --> Router Class Initialized
INFO - 2020-02-25 17:13:03 --> Output Class Initialized
INFO - 2020-02-25 17:13:03 --> Security Class Initialized
DEBUG - 2020-02-25 17:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:13:03 --> Input Class Initialized
INFO - 2020-02-25 17:13:03 --> Language Class Initialized
ERROR - 2020-02-25 17:13:03 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 17:13:03 --> Config Class Initialized
INFO - 2020-02-25 17:13:03 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:13:03 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:13:03 --> Utf8 Class Initialized
INFO - 2020-02-25 17:13:03 --> URI Class Initialized
INFO - 2020-02-25 17:13:03 --> Router Class Initialized
INFO - 2020-02-25 17:13:03 --> Output Class Initialized
INFO - 2020-02-25 17:13:03 --> Security Class Initialized
DEBUG - 2020-02-25 17:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:13:03 --> Input Class Initialized
INFO - 2020-02-25 17:13:04 --> Language Class Initialized
ERROR - 2020-02-25 17:13:04 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 17:13:04 --> Config Class Initialized
INFO - 2020-02-25 17:13:04 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:13:04 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:13:04 --> Utf8 Class Initialized
INFO - 2020-02-25 17:13:04 --> URI Class Initialized
INFO - 2020-02-25 17:13:04 --> Router Class Initialized
INFO - 2020-02-25 17:13:04 --> Output Class Initialized
INFO - 2020-02-25 17:13:04 --> Security Class Initialized
DEBUG - 2020-02-25 17:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:13:04 --> Input Class Initialized
INFO - 2020-02-25 17:13:04 --> Language Class Initialized
ERROR - 2020-02-25 17:13:04 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-25 17:13:04 --> Config Class Initialized
INFO - 2020-02-25 17:13:04 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:13:04 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:13:04 --> Utf8 Class Initialized
INFO - 2020-02-25 17:13:04 --> URI Class Initialized
INFO - 2020-02-25 17:13:04 --> Router Class Initialized
INFO - 2020-02-25 17:13:04 --> Output Class Initialized
INFO - 2020-02-25 17:13:04 --> Security Class Initialized
DEBUG - 2020-02-25 17:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:13:04 --> Input Class Initialized
INFO - 2020-02-25 17:13:04 --> Language Class Initialized
ERROR - 2020-02-25 17:13:04 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-25 17:13:04 --> Config Class Initialized
INFO - 2020-02-25 17:13:04 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:13:04 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:13:04 --> Utf8 Class Initialized
INFO - 2020-02-25 17:13:04 --> URI Class Initialized
INFO - 2020-02-25 17:13:04 --> Router Class Initialized
INFO - 2020-02-25 17:13:04 --> Output Class Initialized
INFO - 2020-02-25 17:13:04 --> Security Class Initialized
DEBUG - 2020-02-25 17:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:13:04 --> Input Class Initialized
INFO - 2020-02-25 17:13:04 --> Language Class Initialized
ERROR - 2020-02-25 17:13:04 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-25 17:13:04 --> Config Class Initialized
INFO - 2020-02-25 17:13:04 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:13:04 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:13:04 --> Utf8 Class Initialized
INFO - 2020-02-25 17:13:04 --> URI Class Initialized
INFO - 2020-02-25 17:13:04 --> Router Class Initialized
INFO - 2020-02-25 17:13:04 --> Output Class Initialized
INFO - 2020-02-25 17:13:04 --> Security Class Initialized
DEBUG - 2020-02-25 17:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:13:04 --> Input Class Initialized
INFO - 2020-02-25 17:13:04 --> Language Class Initialized
ERROR - 2020-02-25 17:13:04 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-25 17:13:19 --> Config Class Initialized
INFO - 2020-02-25 17:13:19 --> Hooks Class Initialized
DEBUG - 2020-02-25 17:13:19 --> UTF-8 Support Enabled
INFO - 2020-02-25 17:13:19 --> Utf8 Class Initialized
INFO - 2020-02-25 17:13:19 --> URI Class Initialized
INFO - 2020-02-25 17:13:19 --> Router Class Initialized
INFO - 2020-02-25 17:13:19 --> Output Class Initialized
INFO - 2020-02-25 17:13:19 --> Security Class Initialized
DEBUG - 2020-02-25 17:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 17:13:19 --> Input Class Initialized
INFO - 2020-02-25 17:13:19 --> Language Class Initialized
INFO - 2020-02-25 17:13:19 --> Loader Class Initialized
INFO - 2020-02-25 17:13:19 --> Helper loaded: url_helper
INFO - 2020-02-25 17:13:19 --> Helper loaded: string_helper
INFO - 2020-02-25 17:13:19 --> Database Driver Class Initialized
DEBUG - 2020-02-25 17:13:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 17:13:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 17:13:19 --> Controller Class Initialized
INFO - 2020-02-25 17:13:19 --> Model "M_tiket" initialized
INFO - 2020-02-25 17:13:19 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 17:13:19 --> Model "M_pesan" initialized
INFO - 2020-02-25 17:13:20 --> Helper loaded: form_helper
INFO - 2020-02-25 17:13:20 --> Form Validation Class Initialized
INFO - 2020-02-25 23:13:21 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-25 23:13:21 --> Final output sent to browser
DEBUG - 2020-02-25 23:13:21 --> Total execution time: 1.4416
INFO - 2020-02-25 18:47:15 --> Config Class Initialized
INFO - 2020-02-25 18:47:15 --> Hooks Class Initialized
DEBUG - 2020-02-25 18:47:15 --> UTF-8 Support Enabled
INFO - 2020-02-25 18:47:15 --> Utf8 Class Initialized
INFO - 2020-02-25 18:47:15 --> URI Class Initialized
DEBUG - 2020-02-25 18:47:15 --> No URI present. Default controller set.
INFO - 2020-02-25 18:47:15 --> Router Class Initialized
INFO - 2020-02-25 18:47:15 --> Output Class Initialized
INFO - 2020-02-25 18:47:15 --> Security Class Initialized
DEBUG - 2020-02-25 18:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 18:47:15 --> Input Class Initialized
INFO - 2020-02-25 18:47:15 --> Language Class Initialized
INFO - 2020-02-25 18:47:15 --> Loader Class Initialized
INFO - 2020-02-25 18:47:15 --> Helper loaded: url_helper
INFO - 2020-02-25 18:47:15 --> Helper loaded: string_helper
INFO - 2020-02-25 18:47:15 --> Database Driver Class Initialized
DEBUG - 2020-02-25 18:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 18:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 18:47:15 --> Controller Class Initialized
INFO - 2020-02-25 18:47:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 18:47:15 --> Pagination Class Initialized
INFO - 2020-02-25 18:47:15 --> Model "M_show" initialized
INFO - 2020-02-25 18:47:15 --> Helper loaded: form_helper
INFO - 2020-02-25 18:47:15 --> Form Validation Class Initialized
INFO - 2020-02-25 18:47:15 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-25 18:47:15 --> Final output sent to browser
DEBUG - 2020-02-25 18:47:15 --> Total execution time: 0.4163
INFO - 2020-02-25 18:47:17 --> Config Class Initialized
INFO - 2020-02-25 18:47:17 --> Hooks Class Initialized
DEBUG - 2020-02-25 18:47:17 --> UTF-8 Support Enabled
INFO - 2020-02-25 18:47:17 --> Utf8 Class Initialized
INFO - 2020-02-25 18:47:17 --> URI Class Initialized
INFO - 2020-02-25 18:47:17 --> Router Class Initialized
INFO - 2020-02-25 18:47:17 --> Output Class Initialized
INFO - 2020-02-25 18:47:17 --> Security Class Initialized
DEBUG - 2020-02-25 18:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 18:47:17 --> Input Class Initialized
INFO - 2020-02-25 18:47:17 --> Language Class Initialized
INFO - 2020-02-25 18:47:17 --> Loader Class Initialized
INFO - 2020-02-25 18:47:17 --> Helper loaded: url_helper
INFO - 2020-02-25 18:47:17 --> Helper loaded: string_helper
INFO - 2020-02-25 18:47:17 --> Database Driver Class Initialized
DEBUG - 2020-02-25 18:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 18:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 18:47:17 --> Controller Class Initialized
INFO - 2020-02-25 18:47:17 --> Model "M_tiket" initialized
INFO - 2020-02-25 18:47:17 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 18:47:17 --> Model "M_pesan" initialized
INFO - 2020-02-25 18:47:17 --> Helper loaded: form_helper
INFO - 2020-02-25 18:47:17 --> Form Validation Class Initialized
INFO - 2020-02-25 18:47:17 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 18:47:17 --> Final output sent to browser
DEBUG - 2020-02-25 18:47:17 --> Total execution time: 0.3734
INFO - 2020-02-25 18:47:17 --> Config Class Initialized
INFO - 2020-02-25 18:47:17 --> Config Class Initialized
INFO - 2020-02-25 18:47:17 --> Config Class Initialized
INFO - 2020-02-25 18:47:17 --> Config Class Initialized
INFO - 2020-02-25 18:47:17 --> Config Class Initialized
INFO - 2020-02-25 18:47:17 --> Config Class Initialized
INFO - 2020-02-25 18:47:17 --> Hooks Class Initialized
INFO - 2020-02-25 18:47:17 --> Hooks Class Initialized
INFO - 2020-02-25 18:47:17 --> Hooks Class Initialized
INFO - 2020-02-25 18:47:17 --> Hooks Class Initialized
INFO - 2020-02-25 18:47:17 --> Hooks Class Initialized
INFO - 2020-02-25 18:47:17 --> Hooks Class Initialized
DEBUG - 2020-02-25 18:47:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 18:47:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 18:47:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 18:47:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 18:47:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 18:47:17 --> UTF-8 Support Enabled
INFO - 2020-02-25 18:47:17 --> Utf8 Class Initialized
INFO - 2020-02-25 18:47:17 --> Utf8 Class Initialized
INFO - 2020-02-25 18:47:17 --> Utf8 Class Initialized
INFO - 2020-02-25 18:47:17 --> Utf8 Class Initialized
INFO - 2020-02-25 18:47:17 --> Utf8 Class Initialized
INFO - 2020-02-25 18:47:17 --> Utf8 Class Initialized
INFO - 2020-02-25 18:47:17 --> URI Class Initialized
INFO - 2020-02-25 18:47:17 --> URI Class Initialized
INFO - 2020-02-25 18:47:17 --> URI Class Initialized
INFO - 2020-02-25 18:47:17 --> URI Class Initialized
INFO - 2020-02-25 18:47:17 --> URI Class Initialized
INFO - 2020-02-25 18:47:17 --> URI Class Initialized
INFO - 2020-02-25 18:47:17 --> Router Class Initialized
INFO - 2020-02-25 18:47:17 --> Router Class Initialized
INFO - 2020-02-25 18:47:17 --> Router Class Initialized
INFO - 2020-02-25 18:47:17 --> Router Class Initialized
INFO - 2020-02-25 18:47:17 --> Router Class Initialized
INFO - 2020-02-25 18:47:17 --> Router Class Initialized
INFO - 2020-02-25 18:47:17 --> Output Class Initialized
INFO - 2020-02-25 18:47:17 --> Output Class Initialized
INFO - 2020-02-25 18:47:17 --> Output Class Initialized
INFO - 2020-02-25 18:47:17 --> Output Class Initialized
INFO - 2020-02-25 18:47:17 --> Output Class Initialized
INFO - 2020-02-25 18:47:17 --> Output Class Initialized
INFO - 2020-02-25 18:47:17 --> Security Class Initialized
INFO - 2020-02-25 18:47:17 --> Security Class Initialized
INFO - 2020-02-25 18:47:17 --> Security Class Initialized
INFO - 2020-02-25 18:47:17 --> Security Class Initialized
INFO - 2020-02-25 18:47:17 --> Security Class Initialized
INFO - 2020-02-25 18:47:17 --> Security Class Initialized
DEBUG - 2020-02-25 18:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 18:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 18:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 18:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 18:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 18:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 18:47:17 --> Input Class Initialized
INFO - 2020-02-25 18:47:17 --> Input Class Initialized
INFO - 2020-02-25 18:47:17 --> Input Class Initialized
INFO - 2020-02-25 18:47:17 --> Input Class Initialized
INFO - 2020-02-25 18:47:17 --> Input Class Initialized
INFO - 2020-02-25 18:47:17 --> Input Class Initialized
INFO - 2020-02-25 18:47:17 --> Language Class Initialized
INFO - 2020-02-25 18:47:17 --> Language Class Initialized
INFO - 2020-02-25 18:47:17 --> Language Class Initialized
INFO - 2020-02-25 18:47:17 --> Language Class Initialized
INFO - 2020-02-25 18:47:17 --> Language Class Initialized
INFO - 2020-02-25 18:47:17 --> Language Class Initialized
ERROR - 2020-02-25 18:47:17 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-25 18:47:17 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-25 18:47:17 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-25 18:47:17 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-25 18:47:17 --> Loader Class Initialized
INFO - 2020-02-25 18:47:17 --> Loader Class Initialized
INFO - 2020-02-25 18:47:17 --> Helper loaded: url_helper
INFO - 2020-02-25 18:47:17 --> Helper loaded: url_helper
INFO - 2020-02-25 18:47:17 --> Config Class Initialized
INFO - 2020-02-25 18:47:17 --> Config Class Initialized
INFO - 2020-02-25 18:47:17 --> Config Class Initialized
INFO - 2020-02-25 18:47:17 --> Config Class Initialized
INFO - 2020-02-25 18:47:17 --> Hooks Class Initialized
INFO - 2020-02-25 18:47:17 --> Hooks Class Initialized
INFO - 2020-02-25 18:47:17 --> Hooks Class Initialized
INFO - 2020-02-25 18:47:17 --> Hooks Class Initialized
INFO - 2020-02-25 18:47:17 --> Helper loaded: string_helper
INFO - 2020-02-25 18:47:17 --> Helper loaded: string_helper
DEBUG - 2020-02-25 18:47:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 18:47:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 18:47:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 18:47:17 --> UTF-8 Support Enabled
INFO - 2020-02-25 18:47:17 --> Database Driver Class Initialized
INFO - 2020-02-25 18:47:17 --> Database Driver Class Initialized
INFO - 2020-02-25 18:47:17 --> Utf8 Class Initialized
INFO - 2020-02-25 18:47:17 --> Utf8 Class Initialized
INFO - 2020-02-25 18:47:17 --> Utf8 Class Initialized
INFO - 2020-02-25 18:47:17 --> Utf8 Class Initialized
DEBUG - 2020-02-25 18:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-25 18:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 18:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 18:47:17 --> URI Class Initialized
INFO - 2020-02-25 18:47:17 --> URI Class Initialized
INFO - 2020-02-25 18:47:17 --> URI Class Initialized
INFO - 2020-02-25 18:47:17 --> URI Class Initialized
INFO - 2020-02-25 18:47:17 --> Controller Class Initialized
INFO - 2020-02-25 18:47:17 --> Router Class Initialized
INFO - 2020-02-25 18:47:17 --> Router Class Initialized
INFO - 2020-02-25 18:47:17 --> Router Class Initialized
INFO - 2020-02-25 18:47:17 --> Router Class Initialized
INFO - 2020-02-25 18:47:17 --> Model "M_tiket" initialized
INFO - 2020-02-25 18:47:17 --> Output Class Initialized
INFO - 2020-02-25 18:47:17 --> Output Class Initialized
INFO - 2020-02-25 18:47:17 --> Output Class Initialized
INFO - 2020-02-25 18:47:17 --> Output Class Initialized
INFO - 2020-02-25 18:47:17 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 18:47:17 --> Security Class Initialized
INFO - 2020-02-25 18:47:17 --> Security Class Initialized
INFO - 2020-02-25 18:47:17 --> Security Class Initialized
INFO - 2020-02-25 18:47:17 --> Security Class Initialized
INFO - 2020-02-25 18:47:17 --> Model "M_pesan" initialized
DEBUG - 2020-02-25 18:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 18:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 18:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 18:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 18:47:17 --> Input Class Initialized
INFO - 2020-02-25 18:47:17 --> Input Class Initialized
INFO - 2020-02-25 18:47:17 --> Input Class Initialized
INFO - 2020-02-25 18:47:17 --> Input Class Initialized
INFO - 2020-02-25 18:47:17 --> Helper loaded: form_helper
INFO - 2020-02-25 18:47:17 --> Form Validation Class Initialized
INFO - 2020-02-25 18:47:17 --> Language Class Initialized
INFO - 2020-02-25 18:47:17 --> Language Class Initialized
INFO - 2020-02-25 18:47:17 --> Language Class Initialized
INFO - 2020-02-25 18:47:17 --> Language Class Initialized
ERROR - 2020-02-25 18:47:17 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-25 18:47:17 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-25 18:47:17 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-25 18:47:17 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-25 18:47:17 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 18:47:17 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 18:47:17 --> Config Class Initialized
INFO - 2020-02-25 18:47:17 --> Config Class Initialized
INFO - 2020-02-25 18:47:17 --> Config Class Initialized
INFO - 2020-02-25 18:47:17 --> Config Class Initialized
INFO - 2020-02-25 18:47:17 --> Hooks Class Initialized
INFO - 2020-02-25 18:47:17 --> Hooks Class Initialized
INFO - 2020-02-25 18:47:17 --> Hooks Class Initialized
INFO - 2020-02-25 18:47:17 --> Hooks Class Initialized
INFO - 2020-02-25 18:47:17 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 18:47:17 --> Final output sent to browser
DEBUG - 2020-02-25 18:47:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 18:47:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 18:47:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 18:47:17 --> UTF-8 Support Enabled
INFO - 2020-02-25 18:47:17 --> Utf8 Class Initialized
INFO - 2020-02-25 18:47:17 --> Utf8 Class Initialized
INFO - 2020-02-25 18:47:17 --> Utf8 Class Initialized
DEBUG - 2020-02-25 18:47:17 --> Total execution time: 0.4279
INFO - 2020-02-25 18:47:17 --> Utf8 Class Initialized
INFO - 2020-02-25 18:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 18:47:18 --> URI Class Initialized
INFO - 2020-02-25 18:47:18 --> URI Class Initialized
INFO - 2020-02-25 18:47:18 --> URI Class Initialized
INFO - 2020-02-25 18:47:18 --> URI Class Initialized
INFO - 2020-02-25 18:47:18 --> Controller Class Initialized
INFO - 2020-02-25 18:47:18 --> Router Class Initialized
INFO - 2020-02-25 18:47:18 --> Router Class Initialized
INFO - 2020-02-25 18:47:18 --> Router Class Initialized
INFO - 2020-02-25 18:47:18 --> Router Class Initialized
INFO - 2020-02-25 18:47:18 --> Model "M_tiket" initialized
INFO - 2020-02-25 18:47:18 --> Output Class Initialized
INFO - 2020-02-25 18:47:18 --> Output Class Initialized
INFO - 2020-02-25 18:47:18 --> Output Class Initialized
INFO - 2020-02-25 18:47:18 --> Output Class Initialized
INFO - 2020-02-25 18:47:18 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 18:47:18 --> Security Class Initialized
INFO - 2020-02-25 18:47:18 --> Security Class Initialized
INFO - 2020-02-25 18:47:18 --> Security Class Initialized
INFO - 2020-02-25 18:47:18 --> Security Class Initialized
INFO - 2020-02-25 18:47:18 --> Model "M_pesan" initialized
DEBUG - 2020-02-25 18:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 18:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 18:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 18:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 18:47:18 --> Input Class Initialized
INFO - 2020-02-25 18:47:18 --> Input Class Initialized
INFO - 2020-02-25 18:47:18 --> Input Class Initialized
INFO - 2020-02-25 18:47:18 --> Input Class Initialized
INFO - 2020-02-25 18:47:18 --> Helper loaded: form_helper
INFO - 2020-02-25 18:47:18 --> Form Validation Class Initialized
INFO - 2020-02-25 18:47:18 --> Language Class Initialized
INFO - 2020-02-25 18:47:18 --> Language Class Initialized
INFO - 2020-02-25 18:47:18 --> Language Class Initialized
INFO - 2020-02-25 18:47:18 --> Language Class Initialized
ERROR - 2020-02-25 18:47:18 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-25 18:47:18 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-25 18:47:18 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-25 18:47:18 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-25 18:47:18 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 18:47:18 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 18:47:18 --> Config Class Initialized
INFO - 2020-02-25 18:47:18 --> Hooks Class Initialized
INFO - 2020-02-25 18:47:18 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 18:47:18 --> Final output sent to browser
DEBUG - 2020-02-25 18:47:18 --> UTF-8 Support Enabled
INFO - 2020-02-25 18:47:18 --> Utf8 Class Initialized
DEBUG - 2020-02-25 18:47:18 --> Total execution time: 0.6078
INFO - 2020-02-25 18:47:18 --> URI Class Initialized
INFO - 2020-02-25 18:47:18 --> Router Class Initialized
INFO - 2020-02-25 18:47:18 --> Output Class Initialized
INFO - 2020-02-25 18:47:18 --> Security Class Initialized
DEBUG - 2020-02-25 18:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 18:47:18 --> Input Class Initialized
INFO - 2020-02-25 18:47:18 --> Language Class Initialized
ERROR - 2020-02-25 18:47:18 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-25 18:47:18 --> Config Class Initialized
INFO - 2020-02-25 18:47:18 --> Hooks Class Initialized
DEBUG - 2020-02-25 18:47:18 --> UTF-8 Support Enabled
INFO - 2020-02-25 18:47:18 --> Utf8 Class Initialized
INFO - 2020-02-25 18:47:18 --> URI Class Initialized
INFO - 2020-02-25 18:47:18 --> Router Class Initialized
INFO - 2020-02-25 18:47:18 --> Output Class Initialized
INFO - 2020-02-25 18:47:18 --> Security Class Initialized
DEBUG - 2020-02-25 18:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 18:47:18 --> Input Class Initialized
INFO - 2020-02-25 18:47:18 --> Language Class Initialized
ERROR - 2020-02-25 18:47:18 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-25 18:47:18 --> Config Class Initialized
INFO - 2020-02-25 18:47:18 --> Hooks Class Initialized
DEBUG - 2020-02-25 18:47:18 --> UTF-8 Support Enabled
INFO - 2020-02-25 18:47:18 --> Utf8 Class Initialized
INFO - 2020-02-25 18:47:18 --> URI Class Initialized
INFO - 2020-02-25 18:47:18 --> Router Class Initialized
INFO - 2020-02-25 18:47:18 --> Output Class Initialized
INFO - 2020-02-25 18:47:18 --> Security Class Initialized
DEBUG - 2020-02-25 18:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 18:47:18 --> Input Class Initialized
INFO - 2020-02-25 18:47:18 --> Language Class Initialized
ERROR - 2020-02-25 18:47:18 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-25 18:47:18 --> Config Class Initialized
INFO - 2020-02-25 18:47:18 --> Hooks Class Initialized
DEBUG - 2020-02-25 18:47:18 --> UTF-8 Support Enabled
INFO - 2020-02-25 18:47:18 --> Utf8 Class Initialized
INFO - 2020-02-25 18:47:18 --> URI Class Initialized
INFO - 2020-02-25 18:47:18 --> Router Class Initialized
INFO - 2020-02-25 18:47:18 --> Output Class Initialized
INFO - 2020-02-25 18:47:18 --> Security Class Initialized
DEBUG - 2020-02-25 18:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 18:47:18 --> Input Class Initialized
INFO - 2020-02-25 18:47:18 --> Language Class Initialized
ERROR - 2020-02-25 18:47:18 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 18:47:18 --> Config Class Initialized
INFO - 2020-02-25 18:47:18 --> Hooks Class Initialized
DEBUG - 2020-02-25 18:47:18 --> UTF-8 Support Enabled
INFO - 2020-02-25 18:47:18 --> Utf8 Class Initialized
INFO - 2020-02-25 18:47:18 --> URI Class Initialized
INFO - 2020-02-25 18:47:19 --> Router Class Initialized
INFO - 2020-02-25 18:47:19 --> Output Class Initialized
INFO - 2020-02-25 18:47:19 --> Security Class Initialized
DEBUG - 2020-02-25 18:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 18:47:19 --> Input Class Initialized
INFO - 2020-02-25 18:47:19 --> Language Class Initialized
ERROR - 2020-02-25 18:47:19 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 18:47:19 --> Config Class Initialized
INFO - 2020-02-25 18:47:19 --> Hooks Class Initialized
DEBUG - 2020-02-25 18:47:19 --> UTF-8 Support Enabled
INFO - 2020-02-25 18:47:19 --> Utf8 Class Initialized
INFO - 2020-02-25 18:47:19 --> URI Class Initialized
INFO - 2020-02-25 18:47:19 --> Router Class Initialized
INFO - 2020-02-25 18:47:19 --> Output Class Initialized
INFO - 2020-02-25 18:47:19 --> Security Class Initialized
DEBUG - 2020-02-25 18:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 18:47:19 --> Input Class Initialized
INFO - 2020-02-25 18:47:19 --> Language Class Initialized
ERROR - 2020-02-25 18:47:19 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-25 18:47:19 --> Config Class Initialized
INFO - 2020-02-25 18:47:19 --> Hooks Class Initialized
DEBUG - 2020-02-25 18:47:19 --> UTF-8 Support Enabled
INFO - 2020-02-25 18:47:19 --> Utf8 Class Initialized
INFO - 2020-02-25 18:47:19 --> URI Class Initialized
INFO - 2020-02-25 18:47:19 --> Router Class Initialized
INFO - 2020-02-25 18:47:19 --> Output Class Initialized
INFO - 2020-02-25 18:47:19 --> Security Class Initialized
DEBUG - 2020-02-25 18:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 18:47:19 --> Input Class Initialized
INFO - 2020-02-25 18:47:19 --> Language Class Initialized
ERROR - 2020-02-25 18:47:19 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-25 18:47:19 --> Config Class Initialized
INFO - 2020-02-25 18:47:19 --> Hooks Class Initialized
DEBUG - 2020-02-25 18:47:19 --> UTF-8 Support Enabled
INFO - 2020-02-25 18:47:19 --> Utf8 Class Initialized
INFO - 2020-02-25 18:47:19 --> URI Class Initialized
INFO - 2020-02-25 18:47:19 --> Router Class Initialized
INFO - 2020-02-25 18:47:19 --> Output Class Initialized
INFO - 2020-02-25 18:47:19 --> Security Class Initialized
DEBUG - 2020-02-25 18:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 18:47:19 --> Input Class Initialized
INFO - 2020-02-25 18:47:19 --> Language Class Initialized
ERROR - 2020-02-25 18:47:19 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-25 18:47:19 --> Config Class Initialized
INFO - 2020-02-25 18:47:19 --> Hooks Class Initialized
DEBUG - 2020-02-25 18:47:19 --> UTF-8 Support Enabled
INFO - 2020-02-25 18:47:19 --> Utf8 Class Initialized
INFO - 2020-02-25 18:47:19 --> URI Class Initialized
INFO - 2020-02-25 18:47:19 --> Router Class Initialized
INFO - 2020-02-25 18:47:19 --> Output Class Initialized
INFO - 2020-02-25 18:47:19 --> Security Class Initialized
DEBUG - 2020-02-25 18:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 18:47:19 --> Input Class Initialized
INFO - 2020-02-25 18:47:19 --> Language Class Initialized
ERROR - 2020-02-25 18:47:19 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-25 18:47:42 --> Config Class Initialized
INFO - 2020-02-25 18:47:42 --> Hooks Class Initialized
DEBUG - 2020-02-25 18:47:42 --> UTF-8 Support Enabled
INFO - 2020-02-25 18:47:42 --> Utf8 Class Initialized
INFO - 2020-02-25 18:47:42 --> URI Class Initialized
INFO - 2020-02-25 18:47:42 --> Router Class Initialized
INFO - 2020-02-25 18:47:42 --> Output Class Initialized
INFO - 2020-02-25 18:47:42 --> Security Class Initialized
DEBUG - 2020-02-25 18:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 18:47:42 --> Input Class Initialized
INFO - 2020-02-25 18:47:42 --> Language Class Initialized
INFO - 2020-02-25 18:47:42 --> Loader Class Initialized
INFO - 2020-02-25 18:47:42 --> Helper loaded: url_helper
INFO - 2020-02-25 18:47:42 --> Helper loaded: string_helper
INFO - 2020-02-25 18:47:42 --> Database Driver Class Initialized
DEBUG - 2020-02-25 18:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 18:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 18:47:42 --> Controller Class Initialized
INFO - 2020-02-25 18:47:42 --> Model "M_tiket" initialized
INFO - 2020-02-25 18:47:42 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 18:47:42 --> Model "M_pesan" initialized
INFO - 2020-02-25 18:47:42 --> Helper loaded: form_helper
INFO - 2020-02-25 18:47:42 --> Form Validation Class Initialized
ERROR - 2020-02-25 18:47:43 --> Severity: Notice --> Trying to get property 'id_pengunjung' of non-object C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 81
INFO - 2020-02-25 18:47:54 --> Config Class Initialized
INFO - 2020-02-25 18:47:54 --> Hooks Class Initialized
DEBUG - 2020-02-25 18:47:54 --> UTF-8 Support Enabled
INFO - 2020-02-25 18:47:54 --> Utf8 Class Initialized
INFO - 2020-02-25 18:47:54 --> URI Class Initialized
INFO - 2020-02-25 18:47:54 --> Router Class Initialized
INFO - 2020-02-25 18:47:54 --> Output Class Initialized
INFO - 2020-02-25 18:47:54 --> Security Class Initialized
DEBUG - 2020-02-25 18:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 18:47:54 --> Input Class Initialized
INFO - 2020-02-25 18:47:54 --> Language Class Initialized
INFO - 2020-02-25 18:47:54 --> Loader Class Initialized
INFO - 2020-02-25 18:47:54 --> Helper loaded: url_helper
INFO - 2020-02-25 18:47:54 --> Helper loaded: string_helper
INFO - 2020-02-25 18:47:54 --> Database Driver Class Initialized
DEBUG - 2020-02-25 18:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 18:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 18:47:54 --> Controller Class Initialized
INFO - 2020-02-25 18:47:54 --> Model "M_tiket" initialized
INFO - 2020-02-25 18:47:54 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 18:47:54 --> Model "M_pesan" initialized
INFO - 2020-02-25 18:47:54 --> Helper loaded: form_helper
INFO - 2020-02-25 18:47:54 --> Form Validation Class Initialized
INFO - 2020-02-25 18:47:54 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 18:47:54 --> Final output sent to browser
DEBUG - 2020-02-25 18:47:54 --> Total execution time: 0.3845
INFO - 2020-02-25 18:47:54 --> Config Class Initialized
INFO - 2020-02-25 18:47:54 --> Config Class Initialized
INFO - 2020-02-25 18:47:54 --> Hooks Class Initialized
INFO - 2020-02-25 18:47:54 --> Hooks Class Initialized
DEBUG - 2020-02-25 18:47:54 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 18:47:54 --> UTF-8 Support Enabled
INFO - 2020-02-25 18:47:54 --> Utf8 Class Initialized
INFO - 2020-02-25 18:47:54 --> Utf8 Class Initialized
INFO - 2020-02-25 18:47:54 --> URI Class Initialized
INFO - 2020-02-25 18:47:54 --> URI Class Initialized
INFO - 2020-02-25 18:47:54 --> Router Class Initialized
INFO - 2020-02-25 18:47:54 --> Router Class Initialized
INFO - 2020-02-25 18:47:55 --> Output Class Initialized
INFO - 2020-02-25 18:47:55 --> Output Class Initialized
INFO - 2020-02-25 18:47:55 --> Security Class Initialized
INFO - 2020-02-25 18:47:55 --> Security Class Initialized
DEBUG - 2020-02-25 18:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 18:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 18:47:55 --> Input Class Initialized
INFO - 2020-02-25 18:47:55 --> Input Class Initialized
INFO - 2020-02-25 18:47:55 --> Language Class Initialized
INFO - 2020-02-25 18:47:55 --> Language Class Initialized
INFO - 2020-02-25 18:47:55 --> Loader Class Initialized
INFO - 2020-02-25 18:47:55 --> Loader Class Initialized
INFO - 2020-02-25 18:47:55 --> Helper loaded: url_helper
INFO - 2020-02-25 18:47:55 --> Helper loaded: url_helper
INFO - 2020-02-25 18:47:55 --> Helper loaded: string_helper
INFO - 2020-02-25 18:47:55 --> Helper loaded: string_helper
INFO - 2020-02-25 18:47:55 --> Database Driver Class Initialized
INFO - 2020-02-25 18:47:55 --> Database Driver Class Initialized
DEBUG - 2020-02-25 18:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-25 18:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 18:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 18:47:55 --> Controller Class Initialized
INFO - 2020-02-25 18:47:55 --> Model "M_tiket" initialized
INFO - 2020-02-25 18:47:55 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 18:47:55 --> Model "M_pesan" initialized
INFO - 2020-02-25 18:47:55 --> Helper loaded: form_helper
INFO - 2020-02-25 18:47:55 --> Form Validation Class Initialized
ERROR - 2020-02-25 18:47:55 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 18:47:55 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 18:47:55 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 18:47:55 --> Final output sent to browser
DEBUG - 2020-02-25 18:47:55 --> Total execution time: 0.4228
INFO - 2020-02-25 18:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 18:47:55 --> Controller Class Initialized
INFO - 2020-02-25 18:47:55 --> Model "M_tiket" initialized
INFO - 2020-02-25 18:47:55 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 18:47:55 --> Model "M_pesan" initialized
INFO - 2020-02-25 18:47:55 --> Helper loaded: form_helper
INFO - 2020-02-25 18:47:55 --> Form Validation Class Initialized
ERROR - 2020-02-25 18:47:55 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 18:47:55 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 18:47:55 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 18:47:55 --> Final output sent to browser
DEBUG - 2020-02-25 18:47:55 --> Total execution time: 0.6033
INFO - 2020-02-25 18:48:06 --> Config Class Initialized
INFO - 2020-02-25 18:48:06 --> Hooks Class Initialized
DEBUG - 2020-02-25 18:48:06 --> UTF-8 Support Enabled
INFO - 2020-02-25 18:48:06 --> Utf8 Class Initialized
INFO - 2020-02-25 18:48:06 --> URI Class Initialized
INFO - 2020-02-25 18:48:06 --> Router Class Initialized
INFO - 2020-02-25 18:48:06 --> Output Class Initialized
INFO - 2020-02-25 18:48:06 --> Security Class Initialized
DEBUG - 2020-02-25 18:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 18:48:06 --> Input Class Initialized
INFO - 2020-02-25 18:48:06 --> Language Class Initialized
INFO - 2020-02-25 18:48:06 --> Loader Class Initialized
INFO - 2020-02-25 18:48:06 --> Helper loaded: url_helper
INFO - 2020-02-25 18:48:06 --> Helper loaded: string_helper
INFO - 2020-02-25 18:48:06 --> Database Driver Class Initialized
DEBUG - 2020-02-25 18:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 18:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 18:48:06 --> Controller Class Initialized
INFO - 2020-02-25 18:48:06 --> Model "M_tiket" initialized
INFO - 2020-02-25 18:48:06 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 18:48:06 --> Model "M_pesan" initialized
INFO - 2020-02-25 18:48:06 --> Helper loaded: form_helper
INFO - 2020-02-25 18:48:06 --> Form Validation Class Initialized
INFO - 2020-02-25 18:48:12 --> Config Class Initialized
INFO - 2020-02-25 18:48:12 --> Hooks Class Initialized
DEBUG - 2020-02-25 18:48:12 --> UTF-8 Support Enabled
INFO - 2020-02-25 18:48:12 --> Utf8 Class Initialized
INFO - 2020-02-25 18:48:12 --> URI Class Initialized
DEBUG - 2020-02-25 18:48:12 --> No URI present. Default controller set.
INFO - 2020-02-25 18:48:12 --> Router Class Initialized
INFO - 2020-02-25 18:48:12 --> Output Class Initialized
INFO - 2020-02-25 18:48:12 --> Security Class Initialized
DEBUG - 2020-02-25 18:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 18:48:12 --> Input Class Initialized
INFO - 2020-02-25 18:48:12 --> Language Class Initialized
INFO - 2020-02-25 18:48:12 --> Loader Class Initialized
INFO - 2020-02-25 18:48:12 --> Helper loaded: url_helper
INFO - 2020-02-25 18:48:13 --> Helper loaded: string_helper
INFO - 2020-02-25 18:48:13 --> Database Driver Class Initialized
DEBUG - 2020-02-25 18:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 18:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 18:48:13 --> Controller Class Initialized
INFO - 2020-02-25 18:48:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 18:48:13 --> Pagination Class Initialized
INFO - 2020-02-25 18:48:13 --> Model "M_show" initialized
INFO - 2020-02-25 18:48:13 --> Helper loaded: form_helper
INFO - 2020-02-25 18:48:13 --> Form Validation Class Initialized
INFO - 2020-02-25 18:48:13 --> File loaded: C:\xampp\htdocs\roadshow\application\views\show/lihat_show.php
INFO - 2020-02-25 18:48:13 --> Final output sent to browser
DEBUG - 2020-02-25 18:48:13 --> Total execution time: 0.4061
INFO - 2020-02-25 18:48:14 --> Config Class Initialized
INFO - 2020-02-25 18:48:14 --> Hooks Class Initialized
DEBUG - 2020-02-25 18:48:14 --> UTF-8 Support Enabled
INFO - 2020-02-25 18:48:14 --> Utf8 Class Initialized
INFO - 2020-02-25 18:48:14 --> URI Class Initialized
INFO - 2020-02-25 18:48:14 --> Router Class Initialized
INFO - 2020-02-25 18:48:14 --> Output Class Initialized
INFO - 2020-02-25 18:48:14 --> Security Class Initialized
DEBUG - 2020-02-25 18:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 18:48:14 --> Input Class Initialized
INFO - 2020-02-25 18:48:14 --> Language Class Initialized
INFO - 2020-02-25 18:48:14 --> Loader Class Initialized
INFO - 2020-02-25 18:48:14 --> Helper loaded: url_helper
INFO - 2020-02-25 18:48:14 --> Helper loaded: string_helper
INFO - 2020-02-25 18:48:14 --> Database Driver Class Initialized
DEBUG - 2020-02-25 18:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 18:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 18:48:14 --> Controller Class Initialized
INFO - 2020-02-25 18:48:14 --> Model "M_tiket" initialized
INFO - 2020-02-25 18:48:14 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 18:48:14 --> Model "M_pesan" initialized
INFO - 2020-02-25 18:48:15 --> Helper loaded: form_helper
INFO - 2020-02-25 18:48:15 --> Form Validation Class Initialized
INFO - 2020-02-25 18:48:15 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 18:48:15 --> Final output sent to browser
DEBUG - 2020-02-25 18:48:15 --> Total execution time: 0.4314
INFO - 2020-02-25 18:48:15 --> Config Class Initialized
INFO - 2020-02-25 18:48:15 --> Config Class Initialized
INFO - 2020-02-25 18:48:15 --> Config Class Initialized
INFO - 2020-02-25 18:48:15 --> Config Class Initialized
INFO - 2020-02-25 18:48:15 --> Config Class Initialized
INFO - 2020-02-25 18:48:15 --> Config Class Initialized
INFO - 2020-02-25 18:48:15 --> Hooks Class Initialized
INFO - 2020-02-25 18:48:15 --> Hooks Class Initialized
INFO - 2020-02-25 18:48:15 --> Hooks Class Initialized
INFO - 2020-02-25 18:48:15 --> Hooks Class Initialized
INFO - 2020-02-25 18:48:15 --> Hooks Class Initialized
INFO - 2020-02-25 18:48:15 --> Hooks Class Initialized
DEBUG - 2020-02-25 18:48:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 18:48:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 18:48:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 18:48:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 18:48:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 18:48:15 --> UTF-8 Support Enabled
INFO - 2020-02-25 18:48:15 --> Utf8 Class Initialized
INFO - 2020-02-25 18:48:15 --> Utf8 Class Initialized
INFO - 2020-02-25 18:48:15 --> Utf8 Class Initialized
INFO - 2020-02-25 18:48:15 --> Utf8 Class Initialized
INFO - 2020-02-25 18:48:15 --> Utf8 Class Initialized
INFO - 2020-02-25 18:48:15 --> Utf8 Class Initialized
INFO - 2020-02-25 18:48:15 --> URI Class Initialized
INFO - 2020-02-25 18:48:15 --> URI Class Initialized
INFO - 2020-02-25 18:48:15 --> URI Class Initialized
INFO - 2020-02-25 18:48:15 --> URI Class Initialized
INFO - 2020-02-25 18:48:15 --> URI Class Initialized
INFO - 2020-02-25 18:48:15 --> URI Class Initialized
INFO - 2020-02-25 18:48:15 --> Router Class Initialized
INFO - 2020-02-25 18:48:15 --> Router Class Initialized
INFO - 2020-02-25 18:48:15 --> Router Class Initialized
INFO - 2020-02-25 18:48:15 --> Router Class Initialized
INFO - 2020-02-25 18:48:15 --> Router Class Initialized
INFO - 2020-02-25 18:48:15 --> Router Class Initialized
INFO - 2020-02-25 18:48:15 --> Output Class Initialized
INFO - 2020-02-25 18:48:15 --> Output Class Initialized
INFO - 2020-02-25 18:48:15 --> Output Class Initialized
INFO - 2020-02-25 18:48:15 --> Output Class Initialized
INFO - 2020-02-25 18:48:15 --> Output Class Initialized
INFO - 2020-02-25 18:48:15 --> Output Class Initialized
INFO - 2020-02-25 18:48:15 --> Security Class Initialized
INFO - 2020-02-25 18:48:15 --> Security Class Initialized
INFO - 2020-02-25 18:48:15 --> Security Class Initialized
INFO - 2020-02-25 18:48:15 --> Security Class Initialized
INFO - 2020-02-25 18:48:15 --> Security Class Initialized
INFO - 2020-02-25 18:48:15 --> Security Class Initialized
DEBUG - 2020-02-25 18:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 18:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 18:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 18:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 18:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 18:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 18:48:15 --> Input Class Initialized
INFO - 2020-02-25 18:48:15 --> Input Class Initialized
INFO - 2020-02-25 18:48:15 --> Input Class Initialized
INFO - 2020-02-25 18:48:15 --> Input Class Initialized
INFO - 2020-02-25 18:48:15 --> Input Class Initialized
INFO - 2020-02-25 18:48:15 --> Input Class Initialized
INFO - 2020-02-25 18:48:15 --> Language Class Initialized
INFO - 2020-02-25 18:48:15 --> Language Class Initialized
INFO - 2020-02-25 18:48:15 --> Language Class Initialized
INFO - 2020-02-25 18:48:15 --> Language Class Initialized
INFO - 2020-02-25 18:48:15 --> Language Class Initialized
INFO - 2020-02-25 18:48:15 --> Language Class Initialized
ERROR - 2020-02-25 18:48:15 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-25 18:48:15 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-25 18:48:15 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-25 18:48:15 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-25 18:48:15 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-25 18:48:15 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-25 18:48:15 --> Config Class Initialized
INFO - 2020-02-25 18:48:15 --> Config Class Initialized
INFO - 2020-02-25 18:48:15 --> Config Class Initialized
INFO - 2020-02-25 18:48:15 --> Config Class Initialized
INFO - 2020-02-25 18:48:15 --> Config Class Initialized
INFO - 2020-02-25 18:48:15 --> Config Class Initialized
INFO - 2020-02-25 18:48:15 --> Hooks Class Initialized
INFO - 2020-02-25 18:48:15 --> Hooks Class Initialized
INFO - 2020-02-25 18:48:15 --> Hooks Class Initialized
INFO - 2020-02-25 18:48:15 --> Hooks Class Initialized
INFO - 2020-02-25 18:48:15 --> Hooks Class Initialized
INFO - 2020-02-25 18:48:15 --> Hooks Class Initialized
DEBUG - 2020-02-25 18:48:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 18:48:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 18:48:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 18:48:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 18:48:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 18:48:15 --> UTF-8 Support Enabled
INFO - 2020-02-25 18:48:15 --> Utf8 Class Initialized
INFO - 2020-02-25 18:48:15 --> Utf8 Class Initialized
INFO - 2020-02-25 18:48:15 --> Utf8 Class Initialized
INFO - 2020-02-25 18:48:15 --> Utf8 Class Initialized
INFO - 2020-02-25 18:48:15 --> Utf8 Class Initialized
INFO - 2020-02-25 18:48:15 --> Utf8 Class Initialized
INFO - 2020-02-25 18:48:15 --> URI Class Initialized
INFO - 2020-02-25 18:48:15 --> URI Class Initialized
INFO - 2020-02-25 18:48:15 --> URI Class Initialized
INFO - 2020-02-25 18:48:15 --> URI Class Initialized
INFO - 2020-02-25 18:48:15 --> URI Class Initialized
INFO - 2020-02-25 18:48:15 --> URI Class Initialized
INFO - 2020-02-25 18:48:15 --> Router Class Initialized
INFO - 2020-02-25 18:48:15 --> Router Class Initialized
INFO - 2020-02-25 18:48:15 --> Router Class Initialized
INFO - 2020-02-25 18:48:15 --> Router Class Initialized
INFO - 2020-02-25 18:48:15 --> Router Class Initialized
INFO - 2020-02-25 18:48:15 --> Router Class Initialized
INFO - 2020-02-25 18:48:15 --> Output Class Initialized
INFO - 2020-02-25 18:48:15 --> Output Class Initialized
INFO - 2020-02-25 18:48:15 --> Output Class Initialized
INFO - 2020-02-25 18:48:15 --> Output Class Initialized
INFO - 2020-02-25 18:48:15 --> Output Class Initialized
INFO - 2020-02-25 18:48:15 --> Output Class Initialized
INFO - 2020-02-25 18:48:15 --> Security Class Initialized
INFO - 2020-02-25 18:48:15 --> Security Class Initialized
INFO - 2020-02-25 18:48:15 --> Security Class Initialized
INFO - 2020-02-25 18:48:15 --> Security Class Initialized
INFO - 2020-02-25 18:48:15 --> Security Class Initialized
INFO - 2020-02-25 18:48:15 --> Security Class Initialized
DEBUG - 2020-02-25 18:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 18:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 18:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 18:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 18:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 18:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 18:48:15 --> Input Class Initialized
INFO - 2020-02-25 18:48:15 --> Input Class Initialized
INFO - 2020-02-25 18:48:15 --> Input Class Initialized
INFO - 2020-02-25 18:48:15 --> Input Class Initialized
INFO - 2020-02-25 18:48:15 --> Input Class Initialized
INFO - 2020-02-25 18:48:15 --> Input Class Initialized
INFO - 2020-02-25 18:48:15 --> Language Class Initialized
INFO - 2020-02-25 18:48:15 --> Language Class Initialized
INFO - 2020-02-25 18:48:15 --> Language Class Initialized
INFO - 2020-02-25 18:48:15 --> Language Class Initialized
INFO - 2020-02-25 18:48:15 --> Language Class Initialized
INFO - 2020-02-25 18:48:15 --> Language Class Initialized
ERROR - 2020-02-25 18:48:15 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-25 18:48:15 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-25 18:48:15 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-25 18:48:15 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-25 18:48:15 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-25 18:48:15 --> Loader Class Initialized
INFO - 2020-02-25 18:48:15 --> Helper loaded: url_helper
INFO - 2020-02-25 18:48:15 --> Config Class Initialized
INFO - 2020-02-25 18:48:15 --> Config Class Initialized
INFO - 2020-02-25 18:48:15 --> Hooks Class Initialized
INFO - 2020-02-25 18:48:15 --> Hooks Class Initialized
INFO - 2020-02-25 18:48:15 --> Helper loaded: string_helper
DEBUG - 2020-02-25 18:48:15 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 18:48:15 --> UTF-8 Support Enabled
INFO - 2020-02-25 18:48:15 --> Database Driver Class Initialized
INFO - 2020-02-25 18:48:15 --> Utf8 Class Initialized
INFO - 2020-02-25 18:48:15 --> Utf8 Class Initialized
DEBUG - 2020-02-25 18:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 18:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 18:48:15 --> URI Class Initialized
INFO - 2020-02-25 18:48:15 --> URI Class Initialized
INFO - 2020-02-25 18:48:15 --> Controller Class Initialized
INFO - 2020-02-25 18:48:15 --> Router Class Initialized
INFO - 2020-02-25 18:48:15 --> Router Class Initialized
INFO - 2020-02-25 18:48:15 --> Model "M_tiket" initialized
INFO - 2020-02-25 18:48:15 --> Output Class Initialized
INFO - 2020-02-25 18:48:15 --> Output Class Initialized
INFO - 2020-02-25 18:48:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 18:48:15 --> Security Class Initialized
INFO - 2020-02-25 18:48:15 --> Security Class Initialized
INFO - 2020-02-25 18:48:15 --> Model "M_pesan" initialized
DEBUG - 2020-02-25 18:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 18:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 18:48:15 --> Input Class Initialized
INFO - 2020-02-25 18:48:15 --> Input Class Initialized
INFO - 2020-02-25 18:48:15 --> Helper loaded: form_helper
INFO - 2020-02-25 18:48:15 --> Form Validation Class Initialized
INFO - 2020-02-25 18:48:15 --> Language Class Initialized
INFO - 2020-02-25 18:48:15 --> Language Class Initialized
ERROR - 2020-02-25 18:48:15 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-25 18:48:15 --> Loader Class Initialized
ERROR - 2020-02-25 18:48:15 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 18:48:15 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 18:48:15 --> Helper loaded: url_helper
INFO - 2020-02-25 18:48:15 --> Config Class Initialized
INFO - 2020-02-25 18:48:15 --> Hooks Class Initialized
INFO - 2020-02-25 18:48:15 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 18:48:15 --> Helper loaded: string_helper
INFO - 2020-02-25 18:48:15 --> Final output sent to browser
DEBUG - 2020-02-25 18:48:15 --> UTF-8 Support Enabled
INFO - 2020-02-25 18:48:15 --> Database Driver Class Initialized
INFO - 2020-02-25 18:48:15 --> Utf8 Class Initialized
DEBUG - 2020-02-25 18:48:15 --> Total execution time: 0.4073
DEBUG - 2020-02-25 18:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 18:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 18:48:15 --> URI Class Initialized
INFO - 2020-02-25 18:48:15 --> Controller Class Initialized
INFO - 2020-02-25 18:48:15 --> Router Class Initialized
INFO - 2020-02-25 18:48:15 --> Model "M_tiket" initialized
INFO - 2020-02-25 18:48:15 --> Output Class Initialized
INFO - 2020-02-25 18:48:15 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 18:48:15 --> Security Class Initialized
INFO - 2020-02-25 18:48:15 --> Model "M_pesan" initialized
DEBUG - 2020-02-25 18:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 18:48:15 --> Input Class Initialized
INFO - 2020-02-25 18:48:15 --> Helper loaded: form_helper
INFO - 2020-02-25 18:48:15 --> Form Validation Class Initialized
INFO - 2020-02-25 18:48:15 --> Language Class Initialized
ERROR - 2020-02-25 18:48:15 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-25 18:48:15 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 18:48:15 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 18:48:15 --> Config Class Initialized
INFO - 2020-02-25 18:48:15 --> Hooks Class Initialized
INFO - 2020-02-25 18:48:15 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 18:48:15 --> Final output sent to browser
DEBUG - 2020-02-25 18:48:15 --> UTF-8 Support Enabled
INFO - 2020-02-25 18:48:15 --> Utf8 Class Initialized
DEBUG - 2020-02-25 18:48:15 --> Total execution time: 0.3914
INFO - 2020-02-25 18:48:15 --> URI Class Initialized
INFO - 2020-02-25 18:48:15 --> Router Class Initialized
INFO - 2020-02-25 18:48:15 --> Output Class Initialized
INFO - 2020-02-25 18:48:15 --> Security Class Initialized
DEBUG - 2020-02-25 18:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 18:48:16 --> Input Class Initialized
INFO - 2020-02-25 18:48:16 --> Language Class Initialized
ERROR - 2020-02-25 18:48:16 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-25 18:48:16 --> Config Class Initialized
INFO - 2020-02-25 18:48:16 --> Hooks Class Initialized
DEBUG - 2020-02-25 18:48:16 --> UTF-8 Support Enabled
INFO - 2020-02-25 18:48:16 --> Utf8 Class Initialized
INFO - 2020-02-25 18:48:16 --> URI Class Initialized
INFO - 2020-02-25 18:48:16 --> Router Class Initialized
INFO - 2020-02-25 18:48:16 --> Output Class Initialized
INFO - 2020-02-25 18:48:16 --> Security Class Initialized
DEBUG - 2020-02-25 18:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 18:48:16 --> Input Class Initialized
INFO - 2020-02-25 18:48:16 --> Language Class Initialized
ERROR - 2020-02-25 18:48:16 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 18:48:16 --> Config Class Initialized
INFO - 2020-02-25 18:48:16 --> Hooks Class Initialized
DEBUG - 2020-02-25 18:48:16 --> UTF-8 Support Enabled
INFO - 2020-02-25 18:48:16 --> Utf8 Class Initialized
INFO - 2020-02-25 18:48:16 --> URI Class Initialized
INFO - 2020-02-25 18:48:16 --> Router Class Initialized
INFO - 2020-02-25 18:48:16 --> Output Class Initialized
INFO - 2020-02-25 18:48:16 --> Security Class Initialized
DEBUG - 2020-02-25 18:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 18:48:16 --> Input Class Initialized
INFO - 2020-02-25 18:48:16 --> Language Class Initialized
ERROR - 2020-02-25 18:48:16 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 18:48:16 --> Config Class Initialized
INFO - 2020-02-25 18:48:16 --> Hooks Class Initialized
DEBUG - 2020-02-25 18:48:16 --> UTF-8 Support Enabled
INFO - 2020-02-25 18:48:16 --> Utf8 Class Initialized
INFO - 2020-02-25 18:48:16 --> URI Class Initialized
INFO - 2020-02-25 18:48:16 --> Router Class Initialized
INFO - 2020-02-25 18:48:16 --> Output Class Initialized
INFO - 2020-02-25 18:48:16 --> Security Class Initialized
DEBUG - 2020-02-25 18:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 18:48:16 --> Input Class Initialized
INFO - 2020-02-25 18:48:16 --> Language Class Initialized
ERROR - 2020-02-25 18:48:16 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-25 18:48:16 --> Config Class Initialized
INFO - 2020-02-25 18:48:16 --> Hooks Class Initialized
DEBUG - 2020-02-25 18:48:16 --> UTF-8 Support Enabled
INFO - 2020-02-25 18:48:16 --> Utf8 Class Initialized
INFO - 2020-02-25 18:48:16 --> URI Class Initialized
INFO - 2020-02-25 18:48:16 --> Router Class Initialized
INFO - 2020-02-25 18:48:16 --> Output Class Initialized
INFO - 2020-02-25 18:48:16 --> Security Class Initialized
DEBUG - 2020-02-25 18:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 18:48:16 --> Input Class Initialized
INFO - 2020-02-25 18:48:16 --> Language Class Initialized
ERROR - 2020-02-25 18:48:16 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-25 18:48:16 --> Config Class Initialized
INFO - 2020-02-25 18:48:16 --> Hooks Class Initialized
DEBUG - 2020-02-25 18:48:16 --> UTF-8 Support Enabled
INFO - 2020-02-25 18:48:16 --> Utf8 Class Initialized
INFO - 2020-02-25 18:48:16 --> URI Class Initialized
INFO - 2020-02-25 18:48:16 --> Router Class Initialized
INFO - 2020-02-25 18:48:16 --> Output Class Initialized
INFO - 2020-02-25 18:48:17 --> Security Class Initialized
DEBUG - 2020-02-25 18:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 18:48:17 --> Input Class Initialized
INFO - 2020-02-25 18:48:17 --> Language Class Initialized
ERROR - 2020-02-25 18:48:17 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-25 18:48:17 --> Config Class Initialized
INFO - 2020-02-25 18:48:17 --> Hooks Class Initialized
DEBUG - 2020-02-25 18:48:17 --> UTF-8 Support Enabled
INFO - 2020-02-25 18:48:17 --> Utf8 Class Initialized
INFO - 2020-02-25 18:48:17 --> URI Class Initialized
INFO - 2020-02-25 18:48:17 --> Router Class Initialized
INFO - 2020-02-25 18:48:17 --> Output Class Initialized
INFO - 2020-02-25 18:48:17 --> Security Class Initialized
DEBUG - 2020-02-25 18:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 18:48:17 --> Input Class Initialized
INFO - 2020-02-25 18:48:17 --> Language Class Initialized
ERROR - 2020-02-25 18:48:17 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-25 18:48:25 --> Config Class Initialized
INFO - 2020-02-25 18:48:25 --> Hooks Class Initialized
DEBUG - 2020-02-25 18:48:25 --> UTF-8 Support Enabled
INFO - 2020-02-25 18:48:25 --> Utf8 Class Initialized
INFO - 2020-02-25 18:48:25 --> URI Class Initialized
INFO - 2020-02-25 18:48:25 --> Router Class Initialized
INFO - 2020-02-25 18:48:25 --> Output Class Initialized
INFO - 2020-02-25 18:48:25 --> Security Class Initialized
DEBUG - 2020-02-25 18:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 18:48:25 --> Input Class Initialized
INFO - 2020-02-25 18:48:25 --> Language Class Initialized
INFO - 2020-02-25 18:48:25 --> Loader Class Initialized
INFO - 2020-02-25 18:48:25 --> Helper loaded: url_helper
INFO - 2020-02-25 18:48:25 --> Helper loaded: string_helper
INFO - 2020-02-25 18:48:25 --> Database Driver Class Initialized
DEBUG - 2020-02-25 18:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 18:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 18:48:25 --> Controller Class Initialized
INFO - 2020-02-25 18:48:25 --> Model "M_tiket" initialized
INFO - 2020-02-25 18:48:26 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 18:48:26 --> Model "M_pesan" initialized
INFO - 2020-02-25 18:48:26 --> Helper loaded: form_helper
INFO - 2020-02-25 18:48:26 --> Form Validation Class Initialized
ERROR - 2020-02-25 18:48:26 --> Severity: Notice --> Trying to get property 'id_pengunjung' of non-object C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 81
INFO - 2020-02-25 18:48:31 --> Config Class Initialized
INFO - 2020-02-25 18:48:31 --> Hooks Class Initialized
DEBUG - 2020-02-25 18:48:31 --> UTF-8 Support Enabled
INFO - 2020-02-25 18:48:31 --> Utf8 Class Initialized
INFO - 2020-02-25 18:48:31 --> URI Class Initialized
INFO - 2020-02-25 18:48:31 --> Router Class Initialized
INFO - 2020-02-25 18:48:31 --> Output Class Initialized
INFO - 2020-02-25 18:48:31 --> Security Class Initialized
DEBUG - 2020-02-25 18:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 18:48:32 --> Input Class Initialized
INFO - 2020-02-25 18:48:32 --> Language Class Initialized
INFO - 2020-02-25 18:48:32 --> Loader Class Initialized
INFO - 2020-02-25 18:48:32 --> Helper loaded: url_helper
INFO - 2020-02-25 18:48:32 --> Helper loaded: string_helper
INFO - 2020-02-25 18:48:32 --> Database Driver Class Initialized
DEBUG - 2020-02-25 18:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 18:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 18:48:32 --> Controller Class Initialized
INFO - 2020-02-25 18:48:32 --> Model "M_tiket" initialized
INFO - 2020-02-25 18:48:32 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 18:48:32 --> Model "M_pesan" initialized
INFO - 2020-02-25 18:48:32 --> Helper loaded: form_helper
INFO - 2020-02-25 18:48:32 --> Form Validation Class Initialized
ERROR - 2020-02-25 18:48:32 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 70
ERROR - 2020-02-25 18:48:32 --> Severity: Notice --> Undefined index: no_identitas C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 71
ERROR - 2020-02-25 18:48:32 --> Severity: Notice --> Undefined index: no_hp C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 72
ERROR - 2020-02-25 18:48:32 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 73
ERROR - 2020-02-25 18:48:32 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 81
ERROR - 2020-02-25 18:48:32 --> Severity: Notice --> Undefined index: no_identitas C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 82
ERROR - 2020-02-25 18:48:32 --> Severity: Notice --> Undefined index: no_hp C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 83
ERROR - 2020-02-25 18:48:32 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\roadshow\application\models\M_pengunjung.php 84
ERROR - 2020-02-25 18:48:32 --> Query error: Column 'nama' cannot be null - Invalid query: INSERT INTO `pengunjung` (`nama`, `no_identitas`, `no_hp`, `email`) VALUES (NULL, NULL, NULL, NULL)
INFO - 2020-02-25 18:48:32 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-02-25 18:48:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\roadshow\system\core\Exceptions.php:271) C:\xampp\htdocs\roadshow\system\core\Common.php 570
INFO - 2020-02-25 18:48:34 --> Config Class Initialized
INFO - 2020-02-25 18:48:34 --> Hooks Class Initialized
DEBUG - 2020-02-25 18:48:34 --> UTF-8 Support Enabled
INFO - 2020-02-25 18:48:34 --> Utf8 Class Initialized
INFO - 2020-02-25 18:48:34 --> URI Class Initialized
INFO - 2020-02-25 18:48:34 --> Router Class Initialized
INFO - 2020-02-25 18:48:34 --> Output Class Initialized
INFO - 2020-02-25 18:48:34 --> Security Class Initialized
DEBUG - 2020-02-25 18:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 18:48:34 --> Input Class Initialized
INFO - 2020-02-25 18:48:34 --> Language Class Initialized
INFO - 2020-02-25 18:48:34 --> Loader Class Initialized
INFO - 2020-02-25 18:48:34 --> Helper loaded: url_helper
INFO - 2020-02-25 18:48:34 --> Helper loaded: string_helper
INFO - 2020-02-25 18:48:34 --> Database Driver Class Initialized
DEBUG - 2020-02-25 18:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 18:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 18:48:34 --> Controller Class Initialized
INFO - 2020-02-25 18:48:34 --> Model "M_tiket" initialized
INFO - 2020-02-25 18:48:34 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 18:48:34 --> Model "M_pesan" initialized
INFO - 2020-02-25 18:48:34 --> Helper loaded: form_helper
INFO - 2020-02-25 18:48:34 --> Form Validation Class Initialized
INFO - 2020-02-25 18:48:34 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 18:48:34 --> Final output sent to browser
DEBUG - 2020-02-25 18:48:34 --> Total execution time: 0.3853
INFO - 2020-02-25 18:48:34 --> Config Class Initialized
INFO - 2020-02-25 18:48:34 --> Config Class Initialized
INFO - 2020-02-25 18:48:34 --> Hooks Class Initialized
INFO - 2020-02-25 18:48:34 --> Hooks Class Initialized
DEBUG - 2020-02-25 18:48:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 18:48:34 --> UTF-8 Support Enabled
INFO - 2020-02-25 18:48:34 --> Utf8 Class Initialized
INFO - 2020-02-25 18:48:34 --> Utf8 Class Initialized
INFO - 2020-02-25 18:48:34 --> URI Class Initialized
INFO - 2020-02-25 18:48:34 --> URI Class Initialized
INFO - 2020-02-25 18:48:34 --> Router Class Initialized
INFO - 2020-02-25 18:48:34 --> Router Class Initialized
INFO - 2020-02-25 18:48:34 --> Output Class Initialized
INFO - 2020-02-25 18:48:34 --> Output Class Initialized
INFO - 2020-02-25 18:48:34 --> Security Class Initialized
INFO - 2020-02-25 18:48:34 --> Security Class Initialized
DEBUG - 2020-02-25 18:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 18:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 18:48:34 --> Input Class Initialized
INFO - 2020-02-25 18:48:34 --> Input Class Initialized
INFO - 2020-02-25 18:48:34 --> Language Class Initialized
INFO - 2020-02-25 18:48:34 --> Language Class Initialized
INFO - 2020-02-25 18:48:34 --> Loader Class Initialized
INFO - 2020-02-25 18:48:34 --> Loader Class Initialized
INFO - 2020-02-25 18:48:34 --> Helper loaded: url_helper
INFO - 2020-02-25 18:48:34 --> Helper loaded: url_helper
INFO - 2020-02-25 18:48:34 --> Helper loaded: string_helper
INFO - 2020-02-25 18:48:34 --> Helper loaded: string_helper
INFO - 2020-02-25 18:48:34 --> Database Driver Class Initialized
INFO - 2020-02-25 18:48:34 --> Database Driver Class Initialized
DEBUG - 2020-02-25 18:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-25 18:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 18:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 18:48:34 --> Controller Class Initialized
INFO - 2020-02-25 18:48:34 --> Model "M_tiket" initialized
INFO - 2020-02-25 18:48:34 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 18:48:34 --> Model "M_pesan" initialized
INFO - 2020-02-25 18:48:35 --> Helper loaded: form_helper
INFO - 2020-02-25 18:48:35 --> Form Validation Class Initialized
ERROR - 2020-02-25 18:48:35 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 18:48:35 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 18:48:35 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 18:48:35 --> Final output sent to browser
DEBUG - 2020-02-25 18:48:35 --> Total execution time: 0.4456
INFO - 2020-02-25 18:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 18:48:35 --> Controller Class Initialized
INFO - 2020-02-25 18:48:35 --> Model "M_tiket" initialized
INFO - 2020-02-25 18:48:35 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 18:48:35 --> Model "M_pesan" initialized
INFO - 2020-02-25 18:48:35 --> Helper loaded: form_helper
INFO - 2020-02-25 18:48:35 --> Form Validation Class Initialized
ERROR - 2020-02-25 18:48:35 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 18:48:35 --> Severity: Notice --> Trying to get property 'lokasi' of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 18:48:35 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 18:48:35 --> Final output sent to browser
DEBUG - 2020-02-25 18:48:35 --> Total execution time: 0.6230
INFO - 2020-02-25 18:48:51 --> Config Class Initialized
INFO - 2020-02-25 18:48:51 --> Hooks Class Initialized
DEBUG - 2020-02-25 18:48:51 --> UTF-8 Support Enabled
INFO - 2020-02-25 18:48:51 --> Utf8 Class Initialized
INFO - 2020-02-25 18:48:51 --> URI Class Initialized
INFO - 2020-02-25 18:48:51 --> Router Class Initialized
INFO - 2020-02-25 18:48:51 --> Output Class Initialized
INFO - 2020-02-25 18:48:51 --> Security Class Initialized
DEBUG - 2020-02-25 18:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 18:48:51 --> Input Class Initialized
INFO - 2020-02-25 18:48:51 --> Language Class Initialized
INFO - 2020-02-25 18:48:51 --> Loader Class Initialized
INFO - 2020-02-25 18:48:51 --> Helper loaded: url_helper
INFO - 2020-02-25 18:48:51 --> Helper loaded: string_helper
INFO - 2020-02-25 18:48:51 --> Database Driver Class Initialized
DEBUG - 2020-02-25 18:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 18:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 18:48:51 --> Controller Class Initialized
INFO - 2020-02-25 18:48:51 --> Model "M_tiket" initialized
INFO - 2020-02-25 18:48:51 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 18:48:51 --> Model "M_pesan" initialized
INFO - 2020-02-25 18:48:51 --> Helper loaded: form_helper
INFO - 2020-02-25 18:48:51 --> Form Validation Class Initialized
INFO - 2020-02-25 19:21:39 --> Config Class Initialized
INFO - 2020-02-25 19:21:39 --> Hooks Class Initialized
DEBUG - 2020-02-25 19:21:40 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:21:40 --> Utf8 Class Initialized
INFO - 2020-02-25 19:21:40 --> URI Class Initialized
DEBUG - 2020-02-25 19:21:40 --> No URI present. Default controller set.
INFO - 2020-02-25 19:21:40 --> Router Class Initialized
INFO - 2020-02-25 19:21:40 --> Output Class Initialized
INFO - 2020-02-25 19:21:40 --> Security Class Initialized
DEBUG - 2020-02-25 19:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:21:40 --> Input Class Initialized
INFO - 2020-02-25 19:21:41 --> Language Class Initialized
INFO - 2020-02-25 19:21:41 --> Loader Class Initialized
INFO - 2020-02-25 19:21:42 --> Helper loaded: url_helper
INFO - 2020-02-25 19:21:42 --> Helper loaded: string_helper
INFO - 2020-02-25 19:21:42 --> Database Driver Class Initialized
DEBUG - 2020-02-25 19:21:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 19:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 19:21:42 --> Controller Class Initialized
INFO - 2020-02-25 19:21:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 19:21:42 --> Pagination Class Initialized
INFO - 2020-02-25 19:21:43 --> Model "M_show" initialized
INFO - 2020-02-25 19:21:43 --> Helper loaded: form_helper
INFO - 2020-02-25 19:21:43 --> Form Validation Class Initialized
INFO - 2020-02-25 19:21:43 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-25 19:21:43 --> Final output sent to browser
DEBUG - 2020-02-25 19:21:43 --> Total execution time: 4.1797
INFO - 2020-02-25 19:22:00 --> Config Class Initialized
INFO - 2020-02-25 19:22:00 --> Hooks Class Initialized
DEBUG - 2020-02-25 19:22:00 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:00 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:00 --> URI Class Initialized
INFO - 2020-02-25 19:22:00 --> Router Class Initialized
INFO - 2020-02-25 19:22:00 --> Output Class Initialized
INFO - 2020-02-25 19:22:00 --> Security Class Initialized
DEBUG - 2020-02-25 19:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:00 --> Input Class Initialized
INFO - 2020-02-25 19:22:00 --> Language Class Initialized
INFO - 2020-02-25 19:22:00 --> Loader Class Initialized
INFO - 2020-02-25 19:22:00 --> Helper loaded: url_helper
INFO - 2020-02-25 19:22:00 --> Helper loaded: string_helper
INFO - 2020-02-25 19:22:00 --> Database Driver Class Initialized
DEBUG - 2020-02-25 19:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 19:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 19:22:00 --> Controller Class Initialized
INFO - 2020-02-25 19:22:01 --> Model "M_tiket" initialized
INFO - 2020-02-25 19:22:01 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 19:22:01 --> Model "M_pesan" initialized
INFO - 2020-02-25 19:22:01 --> Helper loaded: form_helper
INFO - 2020-02-25 19:22:01 --> Form Validation Class Initialized
INFO - 2020-02-25 19:22:01 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 19:22:01 --> Final output sent to browser
DEBUG - 2020-02-25 19:22:01 --> Total execution time: 1.0888
INFO - 2020-02-25 19:22:01 --> Config Class Initialized
INFO - 2020-02-25 19:22:01 --> Config Class Initialized
INFO - 2020-02-25 19:22:01 --> Config Class Initialized
INFO - 2020-02-25 19:22:01 --> Config Class Initialized
INFO - 2020-02-25 19:22:01 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:01 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:01 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:01 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:01 --> Config Class Initialized
INFO - 2020-02-25 19:22:01 --> Config Class Initialized
INFO - 2020-02-25 19:22:01 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:01 --> Hooks Class Initialized
DEBUG - 2020-02-25 19:22:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 19:22:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 19:22:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 19:22:01 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:01 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:01 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:01 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:01 --> Utf8 Class Initialized
DEBUG - 2020-02-25 19:22:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 19:22:01 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:01 --> URI Class Initialized
INFO - 2020-02-25 19:22:01 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:01 --> Router Class Initialized
INFO - 2020-02-25 19:22:01 --> URI Class Initialized
INFO - 2020-02-25 19:22:01 --> URI Class Initialized
INFO - 2020-02-25 19:22:01 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:01 --> URI Class Initialized
INFO - 2020-02-25 19:22:01 --> URI Class Initialized
INFO - 2020-02-25 19:22:01 --> Router Class Initialized
INFO - 2020-02-25 19:22:01 --> Router Class Initialized
INFO - 2020-02-25 19:22:01 --> Output Class Initialized
INFO - 2020-02-25 19:22:01 --> Router Class Initialized
INFO - 2020-02-25 19:22:01 --> URI Class Initialized
INFO - 2020-02-25 19:22:01 --> Security Class Initialized
INFO - 2020-02-25 19:22:01 --> Router Class Initialized
INFO - 2020-02-25 19:22:01 --> Router Class Initialized
INFO - 2020-02-25 19:22:01 --> Output Class Initialized
INFO - 2020-02-25 19:22:01 --> Output Class Initialized
INFO - 2020-02-25 19:22:01 --> Output Class Initialized
INFO - 2020-02-25 19:22:02 --> Security Class Initialized
INFO - 2020-02-25 19:22:02 --> Security Class Initialized
INFO - 2020-02-25 19:22:02 --> Security Class Initialized
INFO - 2020-02-25 19:22:02 --> Output Class Initialized
DEBUG - 2020-02-25 19:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:02 --> Output Class Initialized
INFO - 2020-02-25 19:22:02 --> Input Class Initialized
DEBUG - 2020-02-25 19:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:02 --> Security Class Initialized
INFO - 2020-02-25 19:22:02 --> Security Class Initialized
DEBUG - 2020-02-25 19:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 19:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:02 --> Input Class Initialized
INFO - 2020-02-25 19:22:02 --> Input Class Initialized
INFO - 2020-02-25 19:22:02 --> Input Class Initialized
INFO - 2020-02-25 19:22:02 --> Language Class Initialized
DEBUG - 2020-02-25 19:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 19:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:02 --> Input Class Initialized
INFO - 2020-02-25 19:22:02 --> Input Class Initialized
INFO - 2020-02-25 19:22:02 --> Language Class Initialized
INFO - 2020-02-25 19:22:02 --> Language Class Initialized
INFO - 2020-02-25 19:22:02 --> Language Class Initialized
ERROR - 2020-02-25 19:22:02 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-25 19:22:02 --> Language Class Initialized
ERROR - 2020-02-25 19:22:02 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-25 19:22:02 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-25 19:22:02 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-25 19:22:02 --> Language Class Initialized
INFO - 2020-02-25 19:22:02 --> Config Class Initialized
INFO - 2020-02-25 19:22:02 --> Hooks Class Initialized
ERROR - 2020-02-25 19:22:02 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-25 19:22:02 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 19:22:02 --> Config Class Initialized
INFO - 2020-02-25 19:22:02 --> Config Class Initialized
INFO - 2020-02-25 19:22:02 --> Config Class Initialized
INFO - 2020-02-25 19:22:02 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:02 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:02 --> Hooks Class Initialized
DEBUG - 2020-02-25 19:22:02 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:02 --> Config Class Initialized
INFO - 2020-02-25 19:22:02 --> Config Class Initialized
INFO - 2020-02-25 19:22:02 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:02 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:02 --> Utf8 Class Initialized
DEBUG - 2020-02-25 19:22:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 19:22:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 19:22:02 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:02 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:02 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:02 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:02 --> URI Class Initialized
DEBUG - 2020-02-25 19:22:02 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 19:22:02 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:02 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:02 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:02 --> URI Class Initialized
INFO - 2020-02-25 19:22:02 --> URI Class Initialized
INFO - 2020-02-25 19:22:02 --> URI Class Initialized
INFO - 2020-02-25 19:22:02 --> Router Class Initialized
INFO - 2020-02-25 19:22:02 --> Router Class Initialized
INFO - 2020-02-25 19:22:02 --> Router Class Initialized
INFO - 2020-02-25 19:22:02 --> Output Class Initialized
INFO - 2020-02-25 19:22:02 --> Router Class Initialized
INFO - 2020-02-25 19:22:02 --> URI Class Initialized
INFO - 2020-02-25 19:22:02 --> URI Class Initialized
INFO - 2020-02-25 19:22:02 --> Security Class Initialized
INFO - 2020-02-25 19:22:02 --> Router Class Initialized
INFO - 2020-02-25 19:22:02 --> Router Class Initialized
INFO - 2020-02-25 19:22:02 --> Output Class Initialized
INFO - 2020-02-25 19:22:02 --> Output Class Initialized
INFO - 2020-02-25 19:22:02 --> Output Class Initialized
INFO - 2020-02-25 19:22:02 --> Security Class Initialized
INFO - 2020-02-25 19:22:02 --> Security Class Initialized
INFO - 2020-02-25 19:22:02 --> Security Class Initialized
INFO - 2020-02-25 19:22:02 --> Output Class Initialized
INFO - 2020-02-25 19:22:02 --> Output Class Initialized
DEBUG - 2020-02-25 19:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:02 --> Input Class Initialized
DEBUG - 2020-02-25 19:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 19:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:02 --> Security Class Initialized
DEBUG - 2020-02-25 19:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:02 --> Security Class Initialized
INFO - 2020-02-25 19:22:02 --> Input Class Initialized
INFO - 2020-02-25 19:22:02 --> Input Class Initialized
INFO - 2020-02-25 19:22:02 --> Input Class Initialized
INFO - 2020-02-25 19:22:02 --> Language Class Initialized
DEBUG - 2020-02-25 19:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 19:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:02 --> Input Class Initialized
INFO - 2020-02-25 19:22:02 --> Input Class Initialized
INFO - 2020-02-25 19:22:02 --> Language Class Initialized
INFO - 2020-02-25 19:22:02 --> Language Class Initialized
INFO - 2020-02-25 19:22:02 --> Language Class Initialized
ERROR - 2020-02-25 19:22:02 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 19:22:02 --> Language Class Initialized
INFO - 2020-02-25 19:22:02 --> Language Class Initialized
ERROR - 2020-02-25 19:22:02 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-25 19:22:02 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-25 19:22:02 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-25 19:22:02 --> Config Class Initialized
INFO - 2020-02-25 19:22:02 --> Hooks Class Initialized
ERROR - 2020-02-25 19:22:02 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-25 19:22:02 --> Loader Class Initialized
INFO - 2020-02-25 19:22:02 --> Config Class Initialized
INFO - 2020-02-25 19:22:02 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:02 --> Helper loaded: url_helper
DEBUG - 2020-02-25 19:22:02 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:02 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:02 --> Helper loaded: string_helper
DEBUG - 2020-02-25 19:22:02 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:02 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:02 --> URI Class Initialized
INFO - 2020-02-25 19:22:02 --> Database Driver Class Initialized
INFO - 2020-02-25 19:22:02 --> URI Class Initialized
INFO - 2020-02-25 19:22:02 --> Router Class Initialized
DEBUG - 2020-02-25 19:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 19:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 19:22:02 --> Router Class Initialized
INFO - 2020-02-25 19:22:02 --> Output Class Initialized
INFO - 2020-02-25 19:22:02 --> Controller Class Initialized
INFO - 2020-02-25 19:22:02 --> Security Class Initialized
INFO - 2020-02-25 19:22:02 --> Output Class Initialized
INFO - 2020-02-25 19:22:02 --> Security Class Initialized
INFO - 2020-02-25 19:22:02 --> Model "M_tiket" initialized
DEBUG - 2020-02-25 19:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:02 --> Input Class Initialized
INFO - 2020-02-25 19:22:02 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-25 19:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:03 --> Input Class Initialized
INFO - 2020-02-25 19:22:03 --> Model "M_pesan" initialized
INFO - 2020-02-25 19:22:03 --> Language Class Initialized
INFO - 2020-02-25 19:22:03 --> Language Class Initialized
INFO - 2020-02-25 19:22:03 --> Loader Class Initialized
INFO - 2020-02-25 19:22:03 --> Helper loaded: form_helper
INFO - 2020-02-25 19:22:03 --> Form Validation Class Initialized
ERROR - 2020-02-25 19:22:03 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-25 19:22:03 --> Helper loaded: url_helper
INFO - 2020-02-25 19:22:03 --> Helper loaded: string_helper
ERROR - 2020-02-25 19:22:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-25 19:22:03 --> Config Class Initialized
INFO - 2020-02-25 19:22:03 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:03 --> Database Driver Class Initialized
ERROR - 2020-02-25 19:22:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 19:22:03 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-25 19:22:03 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 19:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 19:22:03 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:03 --> Final output sent to browser
DEBUG - 2020-02-25 19:22:03 --> Total execution time: 0.9428
INFO - 2020-02-25 19:22:03 --> URI Class Initialized
INFO - 2020-02-25 19:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 19:22:03 --> Router Class Initialized
INFO - 2020-02-25 19:22:03 --> Controller Class Initialized
INFO - 2020-02-25 19:22:03 --> Output Class Initialized
INFO - 2020-02-25 19:22:03 --> Model "M_tiket" initialized
INFO - 2020-02-25 19:22:03 --> Security Class Initialized
INFO - 2020-02-25 19:22:03 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-25 19:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:03 --> Input Class Initialized
INFO - 2020-02-25 19:22:03 --> Model "M_pesan" initialized
INFO - 2020-02-25 19:22:03 --> Language Class Initialized
INFO - 2020-02-25 19:22:03 --> Helper loaded: form_helper
INFO - 2020-02-25 19:22:03 --> Form Validation Class Initialized
ERROR - 2020-02-25 19:22:03 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-25 19:22:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-25 19:22:03 --> Config Class Initialized
INFO - 2020-02-25 19:22:03 --> Hooks Class Initialized
ERROR - 2020-02-25 19:22:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 19:22:03 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-25 19:22:03 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:03 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:03 --> Final output sent to browser
DEBUG - 2020-02-25 19:22:03 --> Total execution time: 1.0140
INFO - 2020-02-25 19:22:03 --> URI Class Initialized
INFO - 2020-02-25 19:22:03 --> Router Class Initialized
INFO - 2020-02-25 19:22:03 --> Output Class Initialized
INFO - 2020-02-25 19:22:03 --> Security Class Initialized
DEBUG - 2020-02-25 19:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:03 --> Input Class Initialized
INFO - 2020-02-25 19:22:03 --> Language Class Initialized
ERROR - 2020-02-25 19:22:03 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 19:22:04 --> Config Class Initialized
INFO - 2020-02-25 19:22:04 --> Hooks Class Initialized
DEBUG - 2020-02-25 19:22:04 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:04 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:04 --> URI Class Initialized
INFO - 2020-02-25 19:22:04 --> Router Class Initialized
INFO - 2020-02-25 19:22:04 --> Output Class Initialized
INFO - 2020-02-25 19:22:04 --> Security Class Initialized
DEBUG - 2020-02-25 19:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:04 --> Input Class Initialized
INFO - 2020-02-25 19:22:04 --> Language Class Initialized
ERROR - 2020-02-25 19:22:04 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 19:22:04 --> Config Class Initialized
INFO - 2020-02-25 19:22:04 --> Hooks Class Initialized
DEBUG - 2020-02-25 19:22:04 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:04 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:04 --> URI Class Initialized
INFO - 2020-02-25 19:22:04 --> Router Class Initialized
INFO - 2020-02-25 19:22:04 --> Config Class Initialized
INFO - 2020-02-25 19:22:04 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:04 --> Output Class Initialized
INFO - 2020-02-25 19:22:04 --> Security Class Initialized
DEBUG - 2020-02-25 19:22:04 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:04 --> Utf8 Class Initialized
DEBUG - 2020-02-25 19:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:04 --> Input Class Initialized
INFO - 2020-02-25 19:22:04 --> URI Class Initialized
INFO - 2020-02-25 19:22:04 --> Language Class Initialized
DEBUG - 2020-02-25 19:22:04 --> No URI present. Default controller set.
INFO - 2020-02-25 19:22:04 --> Router Class Initialized
ERROR - 2020-02-25 19:22:04 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-25 19:22:04 --> Output Class Initialized
INFO - 2020-02-25 19:22:04 --> Config Class Initialized
INFO - 2020-02-25 19:22:04 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:04 --> Security Class Initialized
DEBUG - 2020-02-25 19:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 19:22:04 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:05 --> Input Class Initialized
INFO - 2020-02-25 19:22:05 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:05 --> Language Class Initialized
INFO - 2020-02-25 19:22:05 --> URI Class Initialized
INFO - 2020-02-25 19:22:05 --> Router Class Initialized
INFO - 2020-02-25 19:22:05 --> Loader Class Initialized
INFO - 2020-02-25 19:22:05 --> Helper loaded: url_helper
INFO - 2020-02-25 19:22:05 --> Output Class Initialized
INFO - 2020-02-25 19:22:05 --> Helper loaded: string_helper
INFO - 2020-02-25 19:22:05 --> Security Class Initialized
DEBUG - 2020-02-25 19:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:05 --> Database Driver Class Initialized
INFO - 2020-02-25 19:22:05 --> Input Class Initialized
DEBUG - 2020-02-25 19:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 19:22:05 --> Language Class Initialized
INFO - 2020-02-25 19:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 19:22:05 --> Controller Class Initialized
ERROR - 2020-02-25 19:22:05 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-25 19:22:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 19:22:05 --> Config Class Initialized
INFO - 2020-02-25 19:22:05 --> Pagination Class Initialized
INFO - 2020-02-25 19:22:05 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:05 --> Model "M_show" initialized
DEBUG - 2020-02-25 19:22:05 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:05 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:05 --> Helper loaded: form_helper
INFO - 2020-02-25 19:22:05 --> Form Validation Class Initialized
INFO - 2020-02-25 19:22:05 --> URI Class Initialized
INFO - 2020-02-25 19:22:05 --> Router Class Initialized
INFO - 2020-02-25 19:22:05 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-25 19:22:05 --> Final output sent to browser
INFO - 2020-02-25 19:22:05 --> Output Class Initialized
DEBUG - 2020-02-25 19:22:05 --> Total execution time: 0.9476
INFO - 2020-02-25 19:22:05 --> Security Class Initialized
DEBUG - 2020-02-25 19:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:05 --> Input Class Initialized
INFO - 2020-02-25 19:22:05 --> Language Class Initialized
ERROR - 2020-02-25 19:22:05 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-25 19:22:08 --> Config Class Initialized
INFO - 2020-02-25 19:22:08 --> Hooks Class Initialized
DEBUG - 2020-02-25 19:22:08 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:08 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:08 --> URI Class Initialized
INFO - 2020-02-25 19:22:08 --> Router Class Initialized
INFO - 2020-02-25 19:22:08 --> Output Class Initialized
INFO - 2020-02-25 19:22:08 --> Security Class Initialized
DEBUG - 2020-02-25 19:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:08 --> Input Class Initialized
INFO - 2020-02-25 19:22:08 --> Language Class Initialized
INFO - 2020-02-25 19:22:08 --> Loader Class Initialized
INFO - 2020-02-25 19:22:08 --> Helper loaded: url_helper
INFO - 2020-02-25 19:22:08 --> Helper loaded: string_helper
INFO - 2020-02-25 19:22:08 --> Database Driver Class Initialized
DEBUG - 2020-02-25 19:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 19:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 19:22:09 --> Controller Class Initialized
INFO - 2020-02-25 19:22:09 --> Model "M_tiket" initialized
INFO - 2020-02-25 19:22:09 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 19:22:09 --> Model "M_pesan" initialized
INFO - 2020-02-25 19:22:09 --> Helper loaded: form_helper
INFO - 2020-02-25 19:22:09 --> Form Validation Class Initialized
INFO - 2020-02-25 19:22:09 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 19:22:09 --> Final output sent to browser
INFO - 2020-02-25 19:22:09 --> Config Class Initialized
INFO - 2020-02-25 19:22:09 --> Config Class Initialized
INFO - 2020-02-25 19:22:09 --> Config Class Initialized
INFO - 2020-02-25 19:22:09 --> Config Class Initialized
INFO - 2020-02-25 19:22:09 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:09 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:09 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:09 --> Hooks Class Initialized
DEBUG - 2020-02-25 19:22:09 --> Total execution time: 0.9314
INFO - 2020-02-25 19:22:09 --> Config Class Initialized
INFO - 2020-02-25 19:22:09 --> Hooks Class Initialized
DEBUG - 2020-02-25 19:22:09 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 19:22:09 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 19:22:09 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 19:22:09 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:09 --> Config Class Initialized
INFO - 2020-02-25 19:22:09 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:09 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:09 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:09 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:09 --> Utf8 Class Initialized
DEBUG - 2020-02-25 19:22:09 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:09 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:09 --> URI Class Initialized
INFO - 2020-02-25 19:22:09 --> URI Class Initialized
INFO - 2020-02-25 19:22:09 --> URI Class Initialized
INFO - 2020-02-25 19:22:09 --> URI Class Initialized
DEBUG - 2020-02-25 19:22:09 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:09 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:09 --> URI Class Initialized
INFO - 2020-02-25 19:22:09 --> Router Class Initialized
INFO - 2020-02-25 19:22:09 --> Router Class Initialized
INFO - 2020-02-25 19:22:09 --> Router Class Initialized
INFO - 2020-02-25 19:22:09 --> Router Class Initialized
INFO - 2020-02-25 19:22:09 --> Output Class Initialized
INFO - 2020-02-25 19:22:09 --> Output Class Initialized
INFO - 2020-02-25 19:22:09 --> Router Class Initialized
INFO - 2020-02-25 19:22:09 --> Output Class Initialized
INFO - 2020-02-25 19:22:09 --> URI Class Initialized
INFO - 2020-02-25 19:22:09 --> Output Class Initialized
INFO - 2020-02-25 19:22:09 --> Security Class Initialized
INFO - 2020-02-25 19:22:09 --> Security Class Initialized
INFO - 2020-02-25 19:22:09 --> Security Class Initialized
INFO - 2020-02-25 19:22:09 --> Router Class Initialized
INFO - 2020-02-25 19:22:09 --> Security Class Initialized
INFO - 2020-02-25 19:22:09 --> Output Class Initialized
DEBUG - 2020-02-25 19:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 19:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:09 --> Output Class Initialized
INFO - 2020-02-25 19:22:09 --> Security Class Initialized
DEBUG - 2020-02-25 19:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 19:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:09 --> Input Class Initialized
INFO - 2020-02-25 19:22:09 --> Input Class Initialized
INFO - 2020-02-25 19:22:09 --> Input Class Initialized
INFO - 2020-02-25 19:22:09 --> Input Class Initialized
DEBUG - 2020-02-25 19:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:09 --> Security Class Initialized
INFO - 2020-02-25 19:22:09 --> Input Class Initialized
INFO - 2020-02-25 19:22:09 --> Language Class Initialized
INFO - 2020-02-25 19:22:09 --> Language Class Initialized
DEBUG - 2020-02-25 19:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:09 --> Language Class Initialized
INFO - 2020-02-25 19:22:09 --> Language Class Initialized
INFO - 2020-02-25 19:22:09 --> Input Class Initialized
ERROR - 2020-02-25 19:22:09 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-25 19:22:09 --> Language Class Initialized
ERROR - 2020-02-25 19:22:09 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-25 19:22:09 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-25 19:22:09 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-25 19:22:09 --> Language Class Initialized
INFO - 2020-02-25 19:22:09 --> Loader Class Initialized
INFO - 2020-02-25 19:22:09 --> Config Class Initialized
INFO - 2020-02-25 19:22:09 --> Config Class Initialized
INFO - 2020-02-25 19:22:09 --> Config Class Initialized
INFO - 2020-02-25 19:22:09 --> Config Class Initialized
INFO - 2020-02-25 19:22:09 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:09 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:09 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:09 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:09 --> Helper loaded: url_helper
INFO - 2020-02-25 19:22:09 --> Loader Class Initialized
INFO - 2020-02-25 19:22:09 --> Helper loaded: url_helper
DEBUG - 2020-02-25 19:22:09 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 19:22:09 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 19:22:09 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:09 --> Helper loaded: string_helper
DEBUG - 2020-02-25 19:22:09 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:09 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:09 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:09 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:09 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:09 --> Helper loaded: string_helper
INFO - 2020-02-25 19:22:09 --> Database Driver Class Initialized
INFO - 2020-02-25 19:22:10 --> URI Class Initialized
INFO - 2020-02-25 19:22:10 --> URI Class Initialized
INFO - 2020-02-25 19:22:10 --> URI Class Initialized
INFO - 2020-02-25 19:22:10 --> URI Class Initialized
DEBUG - 2020-02-25 19:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 19:22:10 --> Database Driver Class Initialized
INFO - 2020-02-25 19:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 19:22:10 --> Router Class Initialized
INFO - 2020-02-25 19:22:10 --> Router Class Initialized
INFO - 2020-02-25 19:22:10 --> Router Class Initialized
INFO - 2020-02-25 19:22:10 --> Router Class Initialized
DEBUG - 2020-02-25 19:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 19:22:10 --> Controller Class Initialized
INFO - 2020-02-25 19:22:10 --> Output Class Initialized
INFO - 2020-02-25 19:22:10 --> Output Class Initialized
INFO - 2020-02-25 19:22:10 --> Output Class Initialized
INFO - 2020-02-25 19:22:10 --> Output Class Initialized
INFO - 2020-02-25 19:22:10 --> Model "M_tiket" initialized
INFO - 2020-02-25 19:22:10 --> Security Class Initialized
INFO - 2020-02-25 19:22:10 --> Security Class Initialized
INFO - 2020-02-25 19:22:10 --> Security Class Initialized
INFO - 2020-02-25 19:22:10 --> Security Class Initialized
INFO - 2020-02-25 19:22:10 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-25 19:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 19:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 19:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 19:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:10 --> Input Class Initialized
INFO - 2020-02-25 19:22:10 --> Input Class Initialized
INFO - 2020-02-25 19:22:10 --> Input Class Initialized
INFO - 2020-02-25 19:22:10 --> Input Class Initialized
INFO - 2020-02-25 19:22:10 --> Model "M_pesan" initialized
INFO - 2020-02-25 19:22:10 --> Language Class Initialized
INFO - 2020-02-25 19:22:10 --> Language Class Initialized
INFO - 2020-02-25 19:22:10 --> Language Class Initialized
INFO - 2020-02-25 19:22:10 --> Language Class Initialized
INFO - 2020-02-25 19:22:10 --> Helper loaded: form_helper
INFO - 2020-02-25 19:22:10 --> Form Validation Class Initialized
ERROR - 2020-02-25 19:22:10 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-25 19:22:10 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-25 19:22:10 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-25 19:22:10 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-25 19:22:10 --> Config Class Initialized
INFO - 2020-02-25 19:22:10 --> Config Class Initialized
ERROR - 2020-02-25 19:22:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-25 19:22:10 --> Config Class Initialized
INFO - 2020-02-25 19:22:10 --> Config Class Initialized
INFO - 2020-02-25 19:22:10 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:10 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:10 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:10 --> Hooks Class Initialized
ERROR - 2020-02-25 19:22:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 19:22:10 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-25 19:22:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 19:22:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 19:22:10 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 19:22:10 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:10 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:10 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:10 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:10 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:10 --> Final output sent to browser
DEBUG - 2020-02-25 19:22:10 --> Total execution time: 1.0722
INFO - 2020-02-25 19:22:10 --> URI Class Initialized
INFO - 2020-02-25 19:22:10 --> URI Class Initialized
INFO - 2020-02-25 19:22:10 --> URI Class Initialized
INFO - 2020-02-25 19:22:10 --> URI Class Initialized
INFO - 2020-02-25 19:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 19:22:10 --> Router Class Initialized
INFO - 2020-02-25 19:22:10 --> Router Class Initialized
INFO - 2020-02-25 19:22:10 --> Router Class Initialized
INFO - 2020-02-25 19:22:10 --> Router Class Initialized
INFO - 2020-02-25 19:22:10 --> Controller Class Initialized
INFO - 2020-02-25 19:22:10 --> Output Class Initialized
INFO - 2020-02-25 19:22:10 --> Output Class Initialized
INFO - 2020-02-25 19:22:10 --> Output Class Initialized
INFO - 2020-02-25 19:22:10 --> Output Class Initialized
INFO - 2020-02-25 19:22:10 --> Model "M_tiket" initialized
INFO - 2020-02-25 19:22:10 --> Security Class Initialized
INFO - 2020-02-25 19:22:10 --> Security Class Initialized
INFO - 2020-02-25 19:22:10 --> Security Class Initialized
INFO - 2020-02-25 19:22:10 --> Security Class Initialized
INFO - 2020-02-25 19:22:10 --> Model "M_pengunjung" initialized
DEBUG - 2020-02-25 19:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 19:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 19:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 19:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:10 --> Input Class Initialized
INFO - 2020-02-25 19:22:10 --> Input Class Initialized
INFO - 2020-02-25 19:22:10 --> Input Class Initialized
INFO - 2020-02-25 19:22:10 --> Input Class Initialized
INFO - 2020-02-25 19:22:10 --> Model "M_pesan" initialized
INFO - 2020-02-25 19:22:10 --> Language Class Initialized
INFO - 2020-02-25 19:22:10 --> Language Class Initialized
INFO - 2020-02-25 19:22:10 --> Language Class Initialized
INFO - 2020-02-25 19:22:10 --> Language Class Initialized
INFO - 2020-02-25 19:22:10 --> Helper loaded: form_helper
INFO - 2020-02-25 19:22:10 --> Form Validation Class Initialized
ERROR - 2020-02-25 19:22:10 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-25 19:22:10 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-25 19:22:10 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-25 19:22:10 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-25 19:22:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-25 19:22:10 --> Config Class Initialized
INFO - 2020-02-25 19:22:10 --> Hooks Class Initialized
ERROR - 2020-02-25 19:22:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 19:22:10 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-25 19:22:10 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:10 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:10 --> Final output sent to browser
DEBUG - 2020-02-25 19:22:10 --> Total execution time: 1.4764
INFO - 2020-02-25 19:22:10 --> URI Class Initialized
INFO - 2020-02-25 19:22:11 --> Router Class Initialized
INFO - 2020-02-25 19:22:11 --> Output Class Initialized
INFO - 2020-02-25 19:22:11 --> Security Class Initialized
DEBUG - 2020-02-25 19:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:11 --> Input Class Initialized
INFO - 2020-02-25 19:22:11 --> Language Class Initialized
ERROR - 2020-02-25 19:22:11 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-25 19:22:11 --> Config Class Initialized
INFO - 2020-02-25 19:22:11 --> Hooks Class Initialized
DEBUG - 2020-02-25 19:22:11 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:11 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:11 --> URI Class Initialized
INFO - 2020-02-25 19:22:11 --> Router Class Initialized
INFO - 2020-02-25 19:22:11 --> Output Class Initialized
INFO - 2020-02-25 19:22:11 --> Security Class Initialized
DEBUG - 2020-02-25 19:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:11 --> Input Class Initialized
INFO - 2020-02-25 19:22:11 --> Language Class Initialized
ERROR - 2020-02-25 19:22:11 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-25 19:22:11 --> Config Class Initialized
INFO - 2020-02-25 19:22:11 --> Hooks Class Initialized
DEBUG - 2020-02-25 19:22:11 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:11 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:11 --> URI Class Initialized
INFO - 2020-02-25 19:22:11 --> Router Class Initialized
INFO - 2020-02-25 19:22:12 --> Output Class Initialized
INFO - 2020-02-25 19:22:12 --> Security Class Initialized
DEBUG - 2020-02-25 19:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:12 --> Input Class Initialized
INFO - 2020-02-25 19:22:12 --> Language Class Initialized
ERROR - 2020-02-25 19:22:12 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-25 19:22:12 --> Config Class Initialized
INFO - 2020-02-25 19:22:12 --> Hooks Class Initialized
DEBUG - 2020-02-25 19:22:12 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:12 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:12 --> URI Class Initialized
INFO - 2020-02-25 19:22:12 --> Config Class Initialized
INFO - 2020-02-25 19:22:12 --> Router Class Initialized
INFO - 2020-02-25 19:22:12 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:12 --> Output Class Initialized
INFO - 2020-02-25 19:22:12 --> Security Class Initialized
DEBUG - 2020-02-25 19:22:12 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:12 --> Utf8 Class Initialized
DEBUG - 2020-02-25 19:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:12 --> Input Class Initialized
INFO - 2020-02-25 19:22:12 --> URI Class Initialized
INFO - 2020-02-25 19:22:12 --> Language Class Initialized
DEBUG - 2020-02-25 19:22:12 --> No URI present. Default controller set.
INFO - 2020-02-25 19:22:12 --> Router Class Initialized
ERROR - 2020-02-25 19:22:12 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 19:22:12 --> Output Class Initialized
INFO - 2020-02-25 19:22:12 --> Config Class Initialized
INFO - 2020-02-25 19:22:12 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:12 --> Security Class Initialized
DEBUG - 2020-02-25 19:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 19:22:12 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:12 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:12 --> Input Class Initialized
INFO - 2020-02-25 19:22:13 --> Language Class Initialized
INFO - 2020-02-25 19:22:13 --> URI Class Initialized
INFO - 2020-02-25 19:22:13 --> Router Class Initialized
INFO - 2020-02-25 19:22:13 --> Loader Class Initialized
INFO - 2020-02-25 19:22:13 --> Helper loaded: url_helper
INFO - 2020-02-25 19:22:13 --> Output Class Initialized
INFO - 2020-02-25 19:22:13 --> Helper loaded: string_helper
INFO - 2020-02-25 19:22:13 --> Security Class Initialized
DEBUG - 2020-02-25 19:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:13 --> Database Driver Class Initialized
INFO - 2020-02-25 19:22:13 --> Input Class Initialized
DEBUG - 2020-02-25 19:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 19:22:13 --> Language Class Initialized
INFO - 2020-02-25 19:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 19:22:13 --> Controller Class Initialized
ERROR - 2020-02-25 19:22:13 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 19:22:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 19:22:13 --> Config Class Initialized
INFO - 2020-02-25 19:22:13 --> Pagination Class Initialized
INFO - 2020-02-25 19:22:13 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:13 --> Model "M_show" initialized
DEBUG - 2020-02-25 19:22:13 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:13 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:13 --> Helper loaded: form_helper
INFO - 2020-02-25 19:22:13 --> Form Validation Class Initialized
INFO - 2020-02-25 19:22:13 --> URI Class Initialized
INFO - 2020-02-25 19:22:13 --> Router Class Initialized
INFO - 2020-02-25 19:22:13 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-25 19:22:13 --> Final output sent to browser
INFO - 2020-02-25 19:22:13 --> Output Class Initialized
DEBUG - 2020-02-25 19:22:13 --> Total execution time: 0.9756
INFO - 2020-02-25 19:22:13 --> Security Class Initialized
DEBUG - 2020-02-25 19:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:13 --> Input Class Initialized
INFO - 2020-02-25 19:22:13 --> Language Class Initialized
ERROR - 2020-02-25 19:22:13 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-25 19:22:15 --> Config Class Initialized
INFO - 2020-02-25 19:22:15 --> Hooks Class Initialized
DEBUG - 2020-02-25 19:22:15 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:16 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:16 --> URI Class Initialized
INFO - 2020-02-25 19:22:16 --> Router Class Initialized
INFO - 2020-02-25 19:22:16 --> Output Class Initialized
INFO - 2020-02-25 19:22:16 --> Security Class Initialized
DEBUG - 2020-02-25 19:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:16 --> Input Class Initialized
INFO - 2020-02-25 19:22:16 --> Language Class Initialized
INFO - 2020-02-25 19:22:16 --> Loader Class Initialized
INFO - 2020-02-25 19:22:16 --> Helper loaded: url_helper
INFO - 2020-02-25 19:22:16 --> Helper loaded: string_helper
INFO - 2020-02-25 19:22:16 --> Database Driver Class Initialized
DEBUG - 2020-02-25 19:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 19:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 19:22:16 --> Controller Class Initialized
INFO - 2020-02-25 19:22:16 --> Model "M_tiket" initialized
INFO - 2020-02-25 19:22:16 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 19:22:16 --> Model "M_pesan" initialized
INFO - 2020-02-25 19:22:16 --> Helper loaded: form_helper
INFO - 2020-02-25 19:22:16 --> Form Validation Class Initialized
INFO - 2020-02-25 19:22:16 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 19:22:16 --> Final output sent to browser
INFO - 2020-02-25 19:22:17 --> Config Class Initialized
INFO - 2020-02-25 19:22:17 --> Config Class Initialized
INFO - 2020-02-25 19:22:17 --> Config Class Initialized
INFO - 2020-02-25 19:22:17 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:17 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:17 --> Hooks Class Initialized
DEBUG - 2020-02-25 19:22:17 --> Total execution time: 1.1067
INFO - 2020-02-25 19:22:17 --> Config Class Initialized
DEBUG - 2020-02-25 19:22:17 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:17 --> Config Class Initialized
INFO - 2020-02-25 19:22:17 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:17 --> Hooks Class Initialized
DEBUG - 2020-02-25 19:22:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 19:22:17 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:17 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:17 --> Config Class Initialized
INFO - 2020-02-25 19:22:17 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:17 --> URI Class Initialized
INFO - 2020-02-25 19:22:17 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:17 --> Utf8 Class Initialized
DEBUG - 2020-02-25 19:22:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 19:22:17 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:17 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:17 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:17 --> URI Class Initialized
INFO - 2020-02-25 19:22:17 --> URI Class Initialized
INFO - 2020-02-25 19:22:17 --> Router Class Initialized
DEBUG - 2020-02-25 19:22:17 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:17 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:17 --> URI Class Initialized
INFO - 2020-02-25 19:22:17 --> Output Class Initialized
INFO - 2020-02-25 19:22:17 --> Router Class Initialized
INFO - 2020-02-25 19:22:17 --> URI Class Initialized
INFO - 2020-02-25 19:22:17 --> Router Class Initialized
INFO - 2020-02-25 19:22:17 --> URI Class Initialized
INFO - 2020-02-25 19:22:17 --> Security Class Initialized
INFO - 2020-02-25 19:22:17 --> Router Class Initialized
INFO - 2020-02-25 19:22:17 --> Output Class Initialized
INFO - 2020-02-25 19:22:17 --> Output Class Initialized
INFO - 2020-02-25 19:22:17 --> Router Class Initialized
DEBUG - 2020-02-25 19:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:17 --> Output Class Initialized
INFO - 2020-02-25 19:22:17 --> Security Class Initialized
INFO - 2020-02-25 19:22:17 --> Security Class Initialized
INFO - 2020-02-25 19:22:17 --> Output Class Initialized
INFO - 2020-02-25 19:22:17 --> Router Class Initialized
INFO - 2020-02-25 19:22:17 --> Input Class Initialized
INFO - 2020-02-25 19:22:17 --> Security Class Initialized
INFO - 2020-02-25 19:22:17 --> Security Class Initialized
DEBUG - 2020-02-25 19:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 19:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:17 --> Output Class Initialized
INFO - 2020-02-25 19:22:17 --> Input Class Initialized
INFO - 2020-02-25 19:22:17 --> Language Class Initialized
INFO - 2020-02-25 19:22:17 --> Input Class Initialized
DEBUG - 2020-02-25 19:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 19:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:17 --> Security Class Initialized
INFO - 2020-02-25 19:22:17 --> Input Class Initialized
INFO - 2020-02-25 19:22:17 --> Input Class Initialized
INFO - 2020-02-25 19:22:17 --> Language Class Initialized
ERROR - 2020-02-25 19:22:17 --> 404 Page Not Found: Bower_components/jquery
DEBUG - 2020-02-25 19:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:17 --> Language Class Initialized
INFO - 2020-02-25 19:22:17 --> Input Class Initialized
INFO - 2020-02-25 19:22:17 --> Language Class Initialized
INFO - 2020-02-25 19:22:17 --> Language Class Initialized
ERROR - 2020-02-25 19:22:17 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-25 19:22:17 --> Loader Class Initialized
INFO - 2020-02-25 19:22:17 --> Config Class Initialized
INFO - 2020-02-25 19:22:17 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:17 --> Language Class Initialized
INFO - 2020-02-25 19:22:17 --> Helper loaded: url_helper
ERROR - 2020-02-25 19:22:17 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-25 19:22:17 --> Loader Class Initialized
INFO - 2020-02-25 19:22:17 --> Config Class Initialized
INFO - 2020-02-25 19:22:17 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:17 --> Helper loaded: string_helper
INFO - 2020-02-25 19:22:17 --> Helper loaded: url_helper
DEBUG - 2020-02-25 19:22:17 --> UTF-8 Support Enabled
ERROR - 2020-02-25 19:22:17 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-25 19:22:17 --> Config Class Initialized
INFO - 2020-02-25 19:22:17 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:17 --> Helper loaded: string_helper
INFO - 2020-02-25 19:22:17 --> Utf8 Class Initialized
DEBUG - 2020-02-25 19:22:17 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:17 --> Database Driver Class Initialized
INFO - 2020-02-25 19:22:17 --> Config Class Initialized
INFO - 2020-02-25 19:22:17 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:17 --> URI Class Initialized
INFO - 2020-02-25 19:22:17 --> Utf8 Class Initialized
DEBUG - 2020-02-25 19:22:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 19:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 19:22:17 --> Database Driver Class Initialized
INFO - 2020-02-25 19:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 19:22:17 --> URI Class Initialized
INFO - 2020-02-25 19:22:17 --> Router Class Initialized
INFO - 2020-02-25 19:22:17 --> Utf8 Class Initialized
DEBUG - 2020-02-25 19:22:17 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 19:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 19:22:17 --> Controller Class Initialized
INFO - 2020-02-25 19:22:17 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:17 --> Router Class Initialized
INFO - 2020-02-25 19:22:17 --> URI Class Initialized
INFO - 2020-02-25 19:22:17 --> Output Class Initialized
INFO - 2020-02-25 19:22:17 --> URI Class Initialized
INFO - 2020-02-25 19:22:17 --> Router Class Initialized
INFO - 2020-02-25 19:22:17 --> Output Class Initialized
INFO - 2020-02-25 19:22:17 --> Model "M_tiket" initialized
INFO - 2020-02-25 19:22:17 --> Security Class Initialized
DEBUG - 2020-02-25 19:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:17 --> Security Class Initialized
INFO - 2020-02-25 19:22:17 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 19:22:17 --> Output Class Initialized
INFO - 2020-02-25 19:22:17 --> Router Class Initialized
INFO - 2020-02-25 19:22:17 --> Input Class Initialized
INFO - 2020-02-25 19:22:17 --> Model "M_pesan" initialized
DEBUG - 2020-02-25 19:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:17 --> Security Class Initialized
INFO - 2020-02-25 19:22:17 --> Output Class Initialized
INFO - 2020-02-25 19:22:17 --> Input Class Initialized
DEBUG - 2020-02-25 19:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:17 --> Security Class Initialized
INFO - 2020-02-25 19:22:17 --> Language Class Initialized
INFO - 2020-02-25 19:22:17 --> Helper loaded: form_helper
INFO - 2020-02-25 19:22:17 --> Form Validation Class Initialized
INFO - 2020-02-25 19:22:17 --> Input Class Initialized
INFO - 2020-02-25 19:22:17 --> Language Class Initialized
ERROR - 2020-02-25 19:22:17 --> 404 Page Not Found: Bower_components/bootstrap
DEBUG - 2020-02-25 19:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:17 --> Input Class Initialized
INFO - 2020-02-25 19:22:17 --> Language Class Initialized
ERROR - 2020-02-25 19:22:17 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-25 19:22:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-25 19:22:17 --> Config Class Initialized
INFO - 2020-02-25 19:22:17 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:17 --> Language Class Initialized
ERROR - 2020-02-25 19:22:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-25 19:22:17 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 19:22:17 --> Config Class Initialized
INFO - 2020-02-25 19:22:18 --> Hooks Class Initialized
ERROR - 2020-02-25 19:22:18 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 19:22:18 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
DEBUG - 2020-02-25 19:22:18 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:18 --> Config Class Initialized
INFO - 2020-02-25 19:22:18 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:18 --> Hooks Class Initialized
INFO - 2020-02-25 19:22:18 --> Final output sent to browser
DEBUG - 2020-02-25 19:22:18 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:18 --> Config Class Initialized
INFO - 2020-02-25 19:22:18 --> Hooks Class Initialized
DEBUG - 2020-02-25 19:22:18 --> Total execution time: 1.0962
INFO - 2020-02-25 19:22:18 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:18 --> URI Class Initialized
DEBUG - 2020-02-25 19:22:18 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:18 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 19:22:18 --> URI Class Initialized
DEBUG - 2020-02-25 19:22:18 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:18 --> Router Class Initialized
INFO - 2020-02-25 19:22:18 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:18 --> Controller Class Initialized
INFO - 2020-02-25 19:22:18 --> URI Class Initialized
INFO - 2020-02-25 19:22:18 --> Router Class Initialized
INFO - 2020-02-25 19:22:18 --> Output Class Initialized
INFO - 2020-02-25 19:22:18 --> URI Class Initialized
INFO - 2020-02-25 19:22:18 --> Security Class Initialized
INFO - 2020-02-25 19:22:18 --> Router Class Initialized
INFO - 2020-02-25 19:22:18 --> Model "M_tiket" initialized
INFO - 2020-02-25 19:22:18 --> Output Class Initialized
INFO - 2020-02-25 19:22:18 --> Security Class Initialized
INFO - 2020-02-25 19:22:18 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 19:22:18 --> Router Class Initialized
DEBUG - 2020-02-25 19:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:18 --> Output Class Initialized
INFO - 2020-02-25 19:22:18 --> Model "M_pesan" initialized
INFO - 2020-02-25 19:22:18 --> Input Class Initialized
INFO - 2020-02-25 19:22:18 --> Security Class Initialized
DEBUG - 2020-02-25 19:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:18 --> Output Class Initialized
INFO - 2020-02-25 19:22:18 --> Input Class Initialized
DEBUG - 2020-02-25 19:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:18 --> Language Class Initialized
INFO - 2020-02-25 19:22:18 --> Security Class Initialized
INFO - 2020-02-25 19:22:18 --> Helper loaded: form_helper
INFO - 2020-02-25 19:22:18 --> Input Class Initialized
INFO - 2020-02-25 19:22:18 --> Form Validation Class Initialized
INFO - 2020-02-25 19:22:18 --> Language Class Initialized
ERROR - 2020-02-25 19:22:18 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
DEBUG - 2020-02-25 19:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:18 --> Input Class Initialized
INFO - 2020-02-25 19:22:18 --> Language Class Initialized
ERROR - 2020-02-25 19:22:18 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-25 19:22:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 19:22:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 19:22:18 --> Language Class Initialized
ERROR - 2020-02-25 19:22:18 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-25 19:22:18 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-25 19:22:18 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-25 19:22:18 --> Final output sent to browser
INFO - 2020-02-25 19:22:18 --> Config Class Initialized
INFO - 2020-02-25 19:22:18 --> Hooks Class Initialized
DEBUG - 2020-02-25 19:22:18 --> Total execution time: 1.6095
DEBUG - 2020-02-25 19:22:18 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:18 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:18 --> URI Class Initialized
INFO - 2020-02-25 19:22:18 --> Router Class Initialized
INFO - 2020-02-25 19:22:18 --> Output Class Initialized
INFO - 2020-02-25 19:22:18 --> Security Class Initialized
DEBUG - 2020-02-25 19:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:18 --> Input Class Initialized
INFO - 2020-02-25 19:22:19 --> Language Class Initialized
ERROR - 2020-02-25 19:22:19 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-25 19:22:19 --> Config Class Initialized
INFO - 2020-02-25 19:22:19 --> Hooks Class Initialized
DEBUG - 2020-02-25 19:22:19 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:19 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:19 --> URI Class Initialized
INFO - 2020-02-25 19:22:19 --> Router Class Initialized
INFO - 2020-02-25 19:22:19 --> Output Class Initialized
INFO - 2020-02-25 19:22:19 --> Security Class Initialized
DEBUG - 2020-02-25 19:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:19 --> Input Class Initialized
INFO - 2020-02-25 19:22:19 --> Language Class Initialized
ERROR - 2020-02-25 19:22:19 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-25 19:22:19 --> Config Class Initialized
INFO - 2020-02-25 19:22:19 --> Hooks Class Initialized
DEBUG - 2020-02-25 19:22:19 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:22:19 --> Utf8 Class Initialized
INFO - 2020-02-25 19:22:19 --> URI Class Initialized
INFO - 2020-02-25 19:22:19 --> Router Class Initialized
INFO - 2020-02-25 19:22:19 --> Output Class Initialized
INFO - 2020-02-25 19:22:19 --> Security Class Initialized
DEBUG - 2020-02-25 19:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:22:19 --> Input Class Initialized
INFO - 2020-02-25 19:22:19 --> Language Class Initialized
ERROR - 2020-02-25 19:22:20 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-25 19:23:00 --> Config Class Initialized
INFO - 2020-02-25 19:23:00 --> Hooks Class Initialized
DEBUG - 2020-02-25 19:23:00 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:23:00 --> Utf8 Class Initialized
INFO - 2020-02-25 19:23:00 --> URI Class Initialized
DEBUG - 2020-02-25 19:23:00 --> No URI present. Default controller set.
INFO - 2020-02-25 19:23:00 --> Router Class Initialized
INFO - 2020-02-25 19:23:00 --> Output Class Initialized
INFO - 2020-02-25 19:23:00 --> Security Class Initialized
DEBUG - 2020-02-25 19:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:23:00 --> Input Class Initialized
INFO - 2020-02-25 19:23:00 --> Language Class Initialized
INFO - 2020-02-25 19:23:00 --> Loader Class Initialized
INFO - 2020-02-25 19:23:00 --> Helper loaded: url_helper
INFO - 2020-02-25 19:23:00 --> Helper loaded: string_helper
INFO - 2020-02-25 19:23:00 --> Database Driver Class Initialized
DEBUG - 2020-02-25 19:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 19:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 19:23:00 --> Controller Class Initialized
INFO - 2020-02-25 19:23:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-02-25 19:23:00 --> Pagination Class Initialized
INFO - 2020-02-25 19:23:00 --> Model "M_show" initialized
INFO - 2020-02-25 19:23:00 --> Helper loaded: form_helper
INFO - 2020-02-25 19:23:00 --> Form Validation Class Initialized
INFO - 2020-02-25 19:23:01 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\show/lihat_show.php
INFO - 2020-02-25 19:23:01 --> Final output sent to browser
DEBUG - 2020-02-25 19:23:01 --> Total execution time: 1.0557
INFO - 2020-02-25 19:23:05 --> Config Class Initialized
INFO - 2020-02-25 19:23:05 --> Hooks Class Initialized
DEBUG - 2020-02-25 19:23:05 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:23:05 --> Utf8 Class Initialized
INFO - 2020-02-25 19:23:05 --> URI Class Initialized
INFO - 2020-02-25 19:23:05 --> Router Class Initialized
INFO - 2020-02-25 19:23:05 --> Output Class Initialized
INFO - 2020-02-25 19:23:05 --> Security Class Initialized
DEBUG - 2020-02-25 19:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:23:05 --> Input Class Initialized
INFO - 2020-02-25 19:23:05 --> Language Class Initialized
INFO - 2020-02-25 19:23:05 --> Loader Class Initialized
INFO - 2020-02-25 19:23:05 --> Helper loaded: url_helper
INFO - 2020-02-25 19:23:05 --> Helper loaded: string_helper
INFO - 2020-02-25 19:23:05 --> Database Driver Class Initialized
DEBUG - 2020-02-25 19:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 19:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 19:23:05 --> Controller Class Initialized
INFO - 2020-02-25 19:23:05 --> Model "M_tiket" initialized
INFO - 2020-02-25 19:23:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 19:23:05 --> Model "M_pesan" initialized
INFO - 2020-02-25 19:23:06 --> Helper loaded: form_helper
INFO - 2020-02-25 19:23:06 --> Form Validation Class Initialized
INFO - 2020-02-25 19:23:06 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 19:23:06 --> Final output sent to browser
INFO - 2020-02-25 19:23:06 --> Config Class Initialized
INFO - 2020-02-25 19:23:06 --> Config Class Initialized
INFO - 2020-02-25 19:23:06 --> Config Class Initialized
INFO - 2020-02-25 19:23:06 --> Config Class Initialized
INFO - 2020-02-25 19:23:06 --> Config Class Initialized
INFO - 2020-02-25 19:23:06 --> Hooks Class Initialized
INFO - 2020-02-25 19:23:06 --> Hooks Class Initialized
INFO - 2020-02-25 19:23:06 --> Hooks Class Initialized
DEBUG - 2020-02-25 19:23:06 --> Total execution time: 1.0543
INFO - 2020-02-25 19:23:06 --> Hooks Class Initialized
INFO - 2020-02-25 19:23:06 --> Hooks Class Initialized
DEBUG - 2020-02-25 19:23:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 19:23:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 19:23:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 19:23:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 19:23:06 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:23:06 --> Config Class Initialized
INFO - 2020-02-25 19:23:06 --> Utf8 Class Initialized
INFO - 2020-02-25 19:23:06 --> Utf8 Class Initialized
INFO - 2020-02-25 19:23:06 --> Hooks Class Initialized
INFO - 2020-02-25 19:23:06 --> Utf8 Class Initialized
INFO - 2020-02-25 19:23:06 --> Utf8 Class Initialized
INFO - 2020-02-25 19:23:06 --> Utf8 Class Initialized
INFO - 2020-02-25 19:23:06 --> URI Class Initialized
INFO - 2020-02-25 19:23:06 --> URI Class Initialized
INFO - 2020-02-25 19:23:06 --> URI Class Initialized
INFO - 2020-02-25 19:23:06 --> URI Class Initialized
DEBUG - 2020-02-25 19:23:06 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:23:06 --> URI Class Initialized
INFO - 2020-02-25 19:23:06 --> Utf8 Class Initialized
INFO - 2020-02-25 19:23:06 --> Router Class Initialized
INFO - 2020-02-25 19:23:06 --> Router Class Initialized
INFO - 2020-02-25 19:23:06 --> Router Class Initialized
INFO - 2020-02-25 19:23:06 --> Router Class Initialized
INFO - 2020-02-25 19:23:06 --> Router Class Initialized
INFO - 2020-02-25 19:23:06 --> Output Class Initialized
INFO - 2020-02-25 19:23:06 --> Output Class Initialized
INFO - 2020-02-25 19:23:06 --> Output Class Initialized
INFO - 2020-02-25 19:23:06 --> Output Class Initialized
INFO - 2020-02-25 19:23:06 --> URI Class Initialized
INFO - 2020-02-25 19:23:06 --> Output Class Initialized
INFO - 2020-02-25 19:23:06 --> Security Class Initialized
INFO - 2020-02-25 19:23:06 --> Security Class Initialized
INFO - 2020-02-25 19:23:06 --> Router Class Initialized
INFO - 2020-02-25 19:23:06 --> Security Class Initialized
INFO - 2020-02-25 19:23:06 --> Security Class Initialized
INFO - 2020-02-25 19:23:06 --> Security Class Initialized
DEBUG - 2020-02-25 19:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 19:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 19:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:23:06 --> Output Class Initialized
DEBUG - 2020-02-25 19:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 19:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:23:06 --> Input Class Initialized
INFO - 2020-02-25 19:23:06 --> Input Class Initialized
INFO - 2020-02-25 19:23:06 --> Input Class Initialized
INFO - 2020-02-25 19:23:06 --> Input Class Initialized
INFO - 2020-02-25 19:23:06 --> Input Class Initialized
INFO - 2020-02-25 19:23:06 --> Security Class Initialized
INFO - 2020-02-25 19:23:06 --> Language Class Initialized
INFO - 2020-02-25 19:23:06 --> Language Class Initialized
INFO - 2020-02-25 19:23:06 --> Language Class Initialized
DEBUG - 2020-02-25 19:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:23:06 --> Language Class Initialized
INFO - 2020-02-25 19:23:06 --> Language Class Initialized
ERROR - 2020-02-25 19:23:06 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-25 19:23:06 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-25 19:23:06 --> Input Class Initialized
INFO - 2020-02-25 19:23:06 --> Loader Class Initialized
ERROR - 2020-02-25 19:23:06 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-25 19:23:06 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-25 19:23:06 --> Language Class Initialized
INFO - 2020-02-25 19:23:06 --> Helper loaded: url_helper
INFO - 2020-02-25 19:23:06 --> Config Class Initialized
INFO - 2020-02-25 19:23:06 --> Config Class Initialized
INFO - 2020-02-25 19:23:06 --> Config Class Initialized
INFO - 2020-02-25 19:23:06 --> Config Class Initialized
INFO - 2020-02-25 19:23:06 --> Hooks Class Initialized
INFO - 2020-02-25 19:23:06 --> Hooks Class Initialized
INFO - 2020-02-25 19:23:06 --> Hooks Class Initialized
INFO - 2020-02-25 19:23:06 --> Hooks Class Initialized
INFO - 2020-02-25 19:23:06 --> Helper loaded: string_helper
INFO - 2020-02-25 19:23:06 --> Loader Class Initialized
INFO - 2020-02-25 19:23:06 --> Helper loaded: url_helper
DEBUG - 2020-02-25 19:23:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 19:23:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 19:23:06 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 19:23:06 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:23:06 --> Database Driver Class Initialized
INFO - 2020-02-25 19:23:06 --> Utf8 Class Initialized
INFO - 2020-02-25 19:23:06 --> Utf8 Class Initialized
INFO - 2020-02-25 19:23:06 --> Utf8 Class Initialized
INFO - 2020-02-25 19:23:06 --> Utf8 Class Initialized
INFO - 2020-02-25 19:23:06 --> Helper loaded: string_helper
DEBUG - 2020-02-25 19:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 19:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 19:23:06 --> URI Class Initialized
INFO - 2020-02-25 19:23:06 --> URI Class Initialized
INFO - 2020-02-25 19:23:06 --> URI Class Initialized
INFO - 2020-02-25 19:23:06 --> URI Class Initialized
INFO - 2020-02-25 19:23:06 --> Database Driver Class Initialized
INFO - 2020-02-25 19:23:06 --> Controller Class Initialized
INFO - 2020-02-25 19:23:06 --> Router Class Initialized
INFO - 2020-02-25 19:23:06 --> Router Class Initialized
INFO - 2020-02-25 19:23:06 --> Router Class Initialized
INFO - 2020-02-25 19:23:06 --> Router Class Initialized
DEBUG - 2020-02-25 19:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 19:23:06 --> Output Class Initialized
INFO - 2020-02-25 19:23:06 --> Output Class Initialized
INFO - 2020-02-25 19:23:06 --> Output Class Initialized
INFO - 2020-02-25 19:23:06 --> Model "M_tiket" initialized
INFO - 2020-02-25 19:23:06 --> Output Class Initialized
INFO - 2020-02-25 19:23:07 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 19:23:07 --> Security Class Initialized
INFO - 2020-02-25 19:23:07 --> Security Class Initialized
INFO - 2020-02-25 19:23:07 --> Security Class Initialized
INFO - 2020-02-25 19:23:07 --> Security Class Initialized
DEBUG - 2020-02-25 19:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 19:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:23:07 --> Model "M_pesan" initialized
DEBUG - 2020-02-25 19:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 19:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:23:07 --> Input Class Initialized
INFO - 2020-02-25 19:23:07 --> Input Class Initialized
INFO - 2020-02-25 19:23:07 --> Input Class Initialized
INFO - 2020-02-25 19:23:07 --> Input Class Initialized
INFO - 2020-02-25 19:23:07 --> Helper loaded: form_helper
INFO - 2020-02-25 19:23:07 --> Form Validation Class Initialized
INFO - 2020-02-25 19:23:07 --> Language Class Initialized
INFO - 2020-02-25 19:23:07 --> Language Class Initialized
INFO - 2020-02-25 19:23:07 --> Language Class Initialized
INFO - 2020-02-25 19:23:07 --> Language Class Initialized
ERROR - 2020-02-25 19:23:07 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-25 19:23:07 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-25 19:23:07 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-25 19:23:07 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-25 19:23:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 19:23:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 19:23:07 --> Config Class Initialized
INFO - 2020-02-25 19:23:07 --> Config Class Initialized
INFO - 2020-02-25 19:23:07 --> Config Class Initialized
INFO - 2020-02-25 19:23:07 --> Config Class Initialized
INFO - 2020-02-25 19:23:07 --> Hooks Class Initialized
INFO - 2020-02-25 19:23:07 --> Hooks Class Initialized
INFO - 2020-02-25 19:23:07 --> Hooks Class Initialized
INFO - 2020-02-25 19:23:07 --> Hooks Class Initialized
INFO - 2020-02-25 19:23:07 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 19:23:07 --> Final output sent to browser
DEBUG - 2020-02-25 19:23:07 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 19:23:07 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 19:23:07 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 19:23:07 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:23:07 --> Utf8 Class Initialized
INFO - 2020-02-25 19:23:07 --> Utf8 Class Initialized
INFO - 2020-02-25 19:23:07 --> Utf8 Class Initialized
DEBUG - 2020-02-25 19:23:07 --> Total execution time: 1.1096
INFO - 2020-02-25 19:23:07 --> Utf8 Class Initialized
INFO - 2020-02-25 19:23:07 --> URI Class Initialized
INFO - 2020-02-25 19:23:07 --> URI Class Initialized
INFO - 2020-02-25 19:23:07 --> URI Class Initialized
INFO - 2020-02-25 19:23:07 --> URI Class Initialized
INFO - 2020-02-25 19:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 19:23:07 --> Controller Class Initialized
INFO - 2020-02-25 19:23:07 --> Router Class Initialized
INFO - 2020-02-25 19:23:07 --> Router Class Initialized
INFO - 2020-02-25 19:23:07 --> Router Class Initialized
INFO - 2020-02-25 19:23:07 --> Router Class Initialized
INFO - 2020-02-25 19:23:07 --> Output Class Initialized
INFO - 2020-02-25 19:23:07 --> Output Class Initialized
INFO - 2020-02-25 19:23:07 --> Output Class Initialized
INFO - 2020-02-25 19:23:07 --> Model "M_tiket" initialized
INFO - 2020-02-25 19:23:07 --> Output Class Initialized
INFO - 2020-02-25 19:23:07 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 19:23:07 --> Security Class Initialized
INFO - 2020-02-25 19:23:07 --> Security Class Initialized
INFO - 2020-02-25 19:23:07 --> Security Class Initialized
INFO - 2020-02-25 19:23:07 --> Security Class Initialized
INFO - 2020-02-25 19:23:07 --> Model "M_pesan" initialized
DEBUG - 2020-02-25 19:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 19:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 19:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 19:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:23:07 --> Input Class Initialized
INFO - 2020-02-25 19:23:07 --> Input Class Initialized
INFO - 2020-02-25 19:23:07 --> Input Class Initialized
INFO - 2020-02-25 19:23:07 --> Input Class Initialized
INFO - 2020-02-25 19:23:07 --> Helper loaded: form_helper
INFO - 2020-02-25 19:23:07 --> Form Validation Class Initialized
INFO - 2020-02-25 19:23:07 --> Language Class Initialized
INFO - 2020-02-25 19:23:07 --> Language Class Initialized
INFO - 2020-02-25 19:23:07 --> Language Class Initialized
INFO - 2020-02-25 19:23:07 --> Language Class Initialized
ERROR - 2020-02-25 19:23:07 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-25 19:23:07 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
ERROR - 2020-02-25 19:23:07 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-25 19:23:07 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-25 19:23:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 19:23:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 19:23:07 --> Config Class Initialized
INFO - 2020-02-25 19:23:07 --> Hooks Class Initialized
INFO - 2020-02-25 19:23:07 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 19:23:07 --> Final output sent to browser
DEBUG - 2020-02-25 19:23:07 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 19:23:07 --> Total execution time: 1.5157
INFO - 2020-02-25 19:23:07 --> Utf8 Class Initialized
INFO - 2020-02-25 19:23:07 --> URI Class Initialized
INFO - 2020-02-25 19:23:07 --> Router Class Initialized
INFO - 2020-02-25 19:23:08 --> Output Class Initialized
INFO - 2020-02-25 19:23:08 --> Security Class Initialized
DEBUG - 2020-02-25 19:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:23:08 --> Input Class Initialized
INFO - 2020-02-25 19:23:08 --> Language Class Initialized
ERROR - 2020-02-25 19:23:08 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-25 19:23:08 --> Config Class Initialized
INFO - 2020-02-25 19:23:09 --> Hooks Class Initialized
DEBUG - 2020-02-25 19:23:09 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:23:09 --> Utf8 Class Initialized
INFO - 2020-02-25 19:23:09 --> URI Class Initialized
INFO - 2020-02-25 19:23:09 --> Router Class Initialized
INFO - 2020-02-25 19:23:09 --> Output Class Initialized
INFO - 2020-02-25 19:23:09 --> Security Class Initialized
DEBUG - 2020-02-25 19:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:23:09 --> Input Class Initialized
INFO - 2020-02-25 19:23:09 --> Language Class Initialized
ERROR - 2020-02-25 19:23:09 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-25 19:23:09 --> Config Class Initialized
INFO - 2020-02-25 19:23:09 --> Hooks Class Initialized
DEBUG - 2020-02-25 19:23:09 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:23:09 --> Utf8 Class Initialized
INFO - 2020-02-25 19:23:09 --> URI Class Initialized
INFO - 2020-02-25 19:23:09 --> Router Class Initialized
INFO - 2020-02-25 19:23:09 --> Output Class Initialized
INFO - 2020-02-25 19:23:09 --> Security Class Initialized
DEBUG - 2020-02-25 19:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:23:09 --> Input Class Initialized
INFO - 2020-02-25 19:23:09 --> Language Class Initialized
ERROR - 2020-02-25 19:23:09 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 19:23:10 --> Config Class Initialized
INFO - 2020-02-25 19:23:10 --> Hooks Class Initialized
DEBUG - 2020-02-25 19:23:10 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:23:10 --> Utf8 Class Initialized
INFO - 2020-02-25 19:23:10 --> URI Class Initialized
INFO - 2020-02-25 19:23:10 --> Router Class Initialized
INFO - 2020-02-25 19:23:10 --> Output Class Initialized
INFO - 2020-02-25 19:23:10 --> Security Class Initialized
DEBUG - 2020-02-25 19:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:23:10 --> Input Class Initialized
INFO - 2020-02-25 19:23:10 --> Language Class Initialized
ERROR - 2020-02-25 19:23:10 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-25 19:23:10 --> Config Class Initialized
INFO - 2020-02-25 19:23:10 --> Hooks Class Initialized
DEBUG - 2020-02-25 19:23:10 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:23:10 --> Utf8 Class Initialized
INFO - 2020-02-25 19:23:10 --> URI Class Initialized
INFO - 2020-02-25 19:23:10 --> Router Class Initialized
INFO - 2020-02-25 19:23:10 --> Output Class Initialized
INFO - 2020-02-25 19:23:10 --> Security Class Initialized
DEBUG - 2020-02-25 19:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:23:10 --> Input Class Initialized
INFO - 2020-02-25 19:23:10 --> Language Class Initialized
ERROR - 2020-02-25 19:23:10 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-25 19:23:11 --> Config Class Initialized
INFO - 2020-02-25 19:23:11 --> Hooks Class Initialized
DEBUG - 2020-02-25 19:23:11 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:23:11 --> Utf8 Class Initialized
INFO - 2020-02-25 19:23:11 --> URI Class Initialized
INFO - 2020-02-25 19:23:11 --> Router Class Initialized
INFO - 2020-02-25 19:23:11 --> Output Class Initialized
INFO - 2020-02-25 19:23:11 --> Security Class Initialized
DEBUG - 2020-02-25 19:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:23:11 --> Input Class Initialized
INFO - 2020-02-25 19:23:11 --> Language Class Initialized
ERROR - 2020-02-25 19:23:11 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-25 19:23:11 --> Config Class Initialized
INFO - 2020-02-25 19:23:11 --> Hooks Class Initialized
DEBUG - 2020-02-25 19:23:11 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:23:11 --> Utf8 Class Initialized
INFO - 2020-02-25 19:23:11 --> URI Class Initialized
INFO - 2020-02-25 19:23:11 --> Router Class Initialized
INFO - 2020-02-25 19:23:11 --> Output Class Initialized
INFO - 2020-02-25 19:23:11 --> Security Class Initialized
DEBUG - 2020-02-25 19:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:23:12 --> Input Class Initialized
INFO - 2020-02-25 19:23:12 --> Language Class Initialized
ERROR - 2020-02-25 19:23:12 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-25 19:23:12 --> Config Class Initialized
INFO - 2020-02-25 19:23:12 --> Hooks Class Initialized
DEBUG - 2020-02-25 19:23:12 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:23:12 --> Utf8 Class Initialized
INFO - 2020-02-25 19:23:12 --> URI Class Initialized
INFO - 2020-02-25 19:23:12 --> Router Class Initialized
INFO - 2020-02-25 19:23:12 --> Output Class Initialized
INFO - 2020-02-25 19:23:12 --> Security Class Initialized
DEBUG - 2020-02-25 19:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:23:12 --> Input Class Initialized
INFO - 2020-02-25 19:23:12 --> Language Class Initialized
ERROR - 2020-02-25 19:23:12 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-25 19:23:39 --> Config Class Initialized
INFO - 2020-02-25 19:23:39 --> Hooks Class Initialized
DEBUG - 2020-02-25 19:23:39 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:23:39 --> Utf8 Class Initialized
INFO - 2020-02-25 19:23:39 --> URI Class Initialized
INFO - 2020-02-25 19:23:39 --> Router Class Initialized
INFO - 2020-02-25 19:23:39 --> Output Class Initialized
INFO - 2020-02-25 19:23:39 --> Security Class Initialized
DEBUG - 2020-02-25 19:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:23:39 --> Input Class Initialized
INFO - 2020-02-25 19:23:39 --> Language Class Initialized
INFO - 2020-02-25 19:23:39 --> Loader Class Initialized
INFO - 2020-02-25 19:23:39 --> Helper loaded: url_helper
INFO - 2020-02-25 19:23:39 --> Helper loaded: string_helper
INFO - 2020-02-25 19:23:40 --> Database Driver Class Initialized
DEBUG - 2020-02-25 19:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 19:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 19:23:40 --> Controller Class Initialized
INFO - 2020-02-25 19:23:40 --> Model "M_tiket" initialized
INFO - 2020-02-25 19:23:40 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 19:23:40 --> Model "M_pesan" initialized
INFO - 2020-02-25 19:23:40 --> Helper loaded: form_helper
INFO - 2020-02-25 19:23:40 --> Form Validation Class Initialized
INFO - 2020-02-25 19:23:48 --> Config Class Initialized
INFO - 2020-02-25 19:23:48 --> Hooks Class Initialized
DEBUG - 2020-02-25 19:23:48 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:23:48 --> Utf8 Class Initialized
INFO - 2020-02-25 19:23:48 --> URI Class Initialized
INFO - 2020-02-25 19:23:48 --> Router Class Initialized
INFO - 2020-02-25 19:23:48 --> Output Class Initialized
INFO - 2020-02-25 19:23:48 --> Security Class Initialized
DEBUG - 2020-02-25 19:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:23:48 --> Input Class Initialized
INFO - 2020-02-25 19:23:49 --> Language Class Initialized
INFO - 2020-02-25 19:23:49 --> Loader Class Initialized
INFO - 2020-02-25 19:23:49 --> Helper loaded: url_helper
INFO - 2020-02-25 19:23:49 --> Helper loaded: string_helper
INFO - 2020-02-25 19:23:49 --> Database Driver Class Initialized
DEBUG - 2020-02-25 19:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 19:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 19:23:49 --> Controller Class Initialized
INFO - 2020-02-25 19:23:49 --> Model "M_tiket" initialized
INFO - 2020-02-25 19:23:49 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 19:23:49 --> Model "M_pesan" initialized
INFO - 2020-02-25 19:23:49 --> Helper loaded: form_helper
INFO - 2020-02-25 19:23:49 --> Form Validation Class Initialized
ERROR - 2020-02-25 19:23:49 --> Severity: error --> Exception: Too few arguments to function Tiket::upload_bukti(), 0 passed in C:\xampp\htdocs\roadshow-2\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\roadshow-2\application\controllers\Tiket.php 28
INFO - 2020-02-25 19:24:32 --> Config Class Initialized
INFO - 2020-02-25 19:24:32 --> Hooks Class Initialized
DEBUG - 2020-02-25 19:24:32 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:24:32 --> Utf8 Class Initialized
INFO - 2020-02-25 19:24:32 --> URI Class Initialized
INFO - 2020-02-25 19:24:32 --> Router Class Initialized
INFO - 2020-02-25 19:24:32 --> Output Class Initialized
INFO - 2020-02-25 19:24:32 --> Security Class Initialized
DEBUG - 2020-02-25 19:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:24:32 --> Input Class Initialized
INFO - 2020-02-25 19:24:32 --> Language Class Initialized
INFO - 2020-02-25 19:24:32 --> Loader Class Initialized
INFO - 2020-02-25 19:24:32 --> Helper loaded: url_helper
INFO - 2020-02-25 19:24:32 --> Helper loaded: string_helper
INFO - 2020-02-25 19:24:32 --> Database Driver Class Initialized
DEBUG - 2020-02-25 19:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 19:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 19:24:32 --> Controller Class Initialized
INFO - 2020-02-25 19:24:32 --> Model "M_tiket" initialized
INFO - 2020-02-25 19:24:32 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 19:24:32 --> Model "M_pesan" initialized
INFO - 2020-02-25 19:24:32 --> Helper loaded: form_helper
INFO - 2020-02-25 19:24:32 --> Form Validation Class Initialized
INFO - 2020-02-25 19:24:32 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 19:24:32 --> Final output sent to browser
DEBUG - 2020-02-25 19:24:33 --> Total execution time: 0.9519
INFO - 2020-02-25 19:24:33 --> Config Class Initialized
INFO - 2020-02-25 19:24:33 --> Config Class Initialized
INFO - 2020-02-25 19:24:33 --> Config Class Initialized
INFO - 2020-02-25 19:24:33 --> Config Class Initialized
INFO - 2020-02-25 19:24:33 --> Hooks Class Initialized
INFO - 2020-02-25 19:24:33 --> Hooks Class Initialized
INFO - 2020-02-25 19:24:33 --> Hooks Class Initialized
INFO - 2020-02-25 19:24:33 --> Hooks Class Initialized
DEBUG - 2020-02-25 19:24:33 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 19:24:33 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 19:24:33 --> UTF-8 Support Enabled
DEBUG - 2020-02-25 19:24:33 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:24:33 --> Utf8 Class Initialized
INFO - 2020-02-25 19:24:33 --> Utf8 Class Initialized
INFO - 2020-02-25 19:24:33 --> Utf8 Class Initialized
INFO - 2020-02-25 19:24:33 --> Utf8 Class Initialized
INFO - 2020-02-25 19:24:33 --> URI Class Initialized
INFO - 2020-02-25 19:24:33 --> URI Class Initialized
INFO - 2020-02-25 19:24:33 --> URI Class Initialized
INFO - 2020-02-25 19:24:33 --> URI Class Initialized
INFO - 2020-02-25 19:24:33 --> Router Class Initialized
INFO - 2020-02-25 19:24:33 --> Router Class Initialized
INFO - 2020-02-25 19:24:33 --> Router Class Initialized
INFO - 2020-02-25 19:24:33 --> Router Class Initialized
INFO - 2020-02-25 19:24:33 --> Output Class Initialized
INFO - 2020-02-25 19:24:33 --> Output Class Initialized
INFO - 2020-02-25 19:24:33 --> Output Class Initialized
INFO - 2020-02-25 19:24:33 --> Output Class Initialized
INFO - 2020-02-25 19:24:33 --> Security Class Initialized
INFO - 2020-02-25 19:24:33 --> Security Class Initialized
INFO - 2020-02-25 19:24:33 --> Security Class Initialized
INFO - 2020-02-25 19:24:33 --> Security Class Initialized
DEBUG - 2020-02-25 19:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 19:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 19:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-25 19:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:24:33 --> Input Class Initialized
INFO - 2020-02-25 19:24:33 --> Input Class Initialized
INFO - 2020-02-25 19:24:33 --> Input Class Initialized
INFO - 2020-02-25 19:24:33 --> Input Class Initialized
INFO - 2020-02-25 19:24:33 --> Language Class Initialized
INFO - 2020-02-25 19:24:33 --> Language Class Initialized
INFO - 2020-02-25 19:24:33 --> Language Class Initialized
INFO - 2020-02-25 19:24:33 --> Language Class Initialized
ERROR - 2020-02-25 19:24:33 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-25 19:24:33 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-25 19:24:33 --> Loader Class Initialized
INFO - 2020-02-25 19:24:33 --> Loader Class Initialized
INFO - 2020-02-25 19:24:33 --> Helper loaded: url_helper
INFO - 2020-02-25 19:24:33 --> Helper loaded: url_helper
INFO - 2020-02-25 19:24:33 --> Helper loaded: string_helper
INFO - 2020-02-25 19:24:33 --> Helper loaded: string_helper
INFO - 2020-02-25 19:24:33 --> Database Driver Class Initialized
INFO - 2020-02-25 19:24:33 --> Database Driver Class Initialized
DEBUG - 2020-02-25 19:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-25 19:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 19:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 19:24:33 --> Controller Class Initialized
INFO - 2020-02-25 19:24:33 --> Model "M_tiket" initialized
INFO - 2020-02-25 19:24:33 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 19:24:33 --> Model "M_pesan" initialized
INFO - 2020-02-25 19:24:34 --> Helper loaded: form_helper
INFO - 2020-02-25 19:24:34 --> Form Validation Class Initialized
ERROR - 2020-02-25 19:24:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 19:24:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 19:24:34 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 19:24:34 --> Final output sent to browser
DEBUG - 2020-02-25 19:24:34 --> Total execution time: 1.0691
INFO - 2020-02-25 19:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 19:24:34 --> Controller Class Initialized
INFO - 2020-02-25 19:24:34 --> Model "M_tiket" initialized
INFO - 2020-02-25 19:24:34 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 19:24:34 --> Model "M_pesan" initialized
INFO - 2020-02-25 19:24:34 --> Helper loaded: form_helper
INFO - 2020-02-25 19:24:34 --> Form Validation Class Initialized
ERROR - 2020-02-25 19:24:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-25 19:24:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow-2\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-25 19:24:34 --> File loaded: C:\xampp\htdocs\roadshow-2\application\views\tiket/lihat_jenis.php
INFO - 2020-02-25 19:24:34 --> Final output sent to browser
DEBUG - 2020-02-25 19:24:34 --> Total execution time: 1.5115
INFO - 2020-02-25 19:24:37 --> Config Class Initialized
INFO - 2020-02-25 19:24:37 --> Hooks Class Initialized
DEBUG - 2020-02-25 19:24:37 --> UTF-8 Support Enabled
INFO - 2020-02-25 19:24:37 --> Utf8 Class Initialized
INFO - 2020-02-25 19:24:37 --> URI Class Initialized
INFO - 2020-02-25 19:24:37 --> Router Class Initialized
INFO - 2020-02-25 19:24:37 --> Output Class Initialized
INFO - 2020-02-25 19:24:37 --> Security Class Initialized
DEBUG - 2020-02-25 19:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-25 19:24:37 --> Input Class Initialized
INFO - 2020-02-25 19:24:37 --> Language Class Initialized
INFO - 2020-02-25 19:24:37 --> Loader Class Initialized
INFO - 2020-02-25 19:24:37 --> Helper loaded: url_helper
INFO - 2020-02-25 19:24:37 --> Helper loaded: string_helper
INFO - 2020-02-25 19:24:37 --> Database Driver Class Initialized
DEBUG - 2020-02-25 19:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-25 19:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-25 19:24:38 --> Controller Class Initialized
INFO - 2020-02-25 19:24:38 --> Model "M_tiket" initialized
INFO - 2020-02-25 19:24:38 --> Model "M_pengunjung" initialized
INFO - 2020-02-25 19:24:38 --> Model "M_pesan" initialized
INFO - 2020-02-25 19:24:38 --> Helper loaded: form_helper
INFO - 2020-02-25 19:24:38 --> Form Validation Class Initialized
