<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-11 10:42:45 --> Config Class Initialized
INFO - 2020-02-11 10:42:45 --> Hooks Class Initialized
DEBUG - 2020-02-11 10:42:46 --> UTF-8 Support Enabled
INFO - 2020-02-11 10:42:46 --> Utf8 Class Initialized
INFO - 2020-02-11 10:42:46 --> URI Class Initialized
INFO - 2020-02-11 10:42:46 --> Router Class Initialized
INFO - 2020-02-11 10:42:46 --> Output Class Initialized
INFO - 2020-02-11 10:42:46 --> Security Class Initialized
DEBUG - 2020-02-11 10:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 10:42:46 --> Input Class Initialized
INFO - 2020-02-11 10:42:46 --> Language Class Initialized
INFO - 2020-02-11 10:42:46 --> Loader Class Initialized
INFO - 2020-02-11 10:42:46 --> Helper loaded: url_helper
INFO - 2020-02-11 10:42:47 --> Database Driver Class Initialized
DEBUG - 2020-02-11 10:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 10:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 10:42:47 --> Controller Class Initialized
INFO - 2020-02-11 10:42:47 --> Model "M_tiket" initialized
INFO - 2020-02-11 10:42:47 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 10:42:47 --> Model "M_pesan" initialized
INFO - 2020-02-11 10:42:47 --> Helper loaded: form_helper
INFO - 2020-02-11 10:42:47 --> Form Validation Class Initialized
INFO - 2020-02-11 10:42:47 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-11 10:42:47 --> Final output sent to browser
DEBUG - 2020-02-11 10:42:47 --> Total execution time: 2.2370
INFO - 2020-02-11 10:42:53 --> Config Class Initialized
INFO - 2020-02-11 10:42:53 --> Hooks Class Initialized
DEBUG - 2020-02-11 10:42:53 --> UTF-8 Support Enabled
INFO - 2020-02-11 10:42:53 --> Utf8 Class Initialized
INFO - 2020-02-11 10:42:53 --> URI Class Initialized
INFO - 2020-02-11 10:42:53 --> Router Class Initialized
INFO - 2020-02-11 10:42:53 --> Output Class Initialized
INFO - 2020-02-11 10:42:53 --> Security Class Initialized
DEBUG - 2020-02-11 10:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 10:42:54 --> Input Class Initialized
INFO - 2020-02-11 10:42:54 --> Language Class Initialized
INFO - 2020-02-11 10:42:54 --> Loader Class Initialized
INFO - 2020-02-11 10:42:54 --> Helper loaded: url_helper
INFO - 2020-02-11 10:42:54 --> Database Driver Class Initialized
DEBUG - 2020-02-11 10:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 10:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 10:42:54 --> Controller Class Initialized
INFO - 2020-02-11 10:42:54 --> Model "M_tiket" initialized
INFO - 2020-02-11 10:42:54 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 10:42:54 --> Model "M_pesan" initialized
INFO - 2020-02-11 10:42:54 --> Helper loaded: form_helper
INFO - 2020-02-11 10:42:54 --> Form Validation Class Initialized
ERROR - 2020-02-11 10:42:54 --> Severity: error --> Exception: Too few arguments to function Tiket::add_all(), 0 passed in C:\xampp\htdocs\roadshow\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 27
INFO - 2020-02-11 10:43:58 --> Config Class Initialized
INFO - 2020-02-11 10:43:58 --> Hooks Class Initialized
DEBUG - 2020-02-11 10:43:58 --> UTF-8 Support Enabled
INFO - 2020-02-11 10:43:58 --> Utf8 Class Initialized
INFO - 2020-02-11 10:43:58 --> URI Class Initialized
INFO - 2020-02-11 10:43:58 --> Router Class Initialized
INFO - 2020-02-11 10:43:58 --> Output Class Initialized
INFO - 2020-02-11 10:43:58 --> Security Class Initialized
DEBUG - 2020-02-11 10:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 10:43:58 --> Input Class Initialized
INFO - 2020-02-11 10:43:58 --> Language Class Initialized
INFO - 2020-02-11 10:43:58 --> Loader Class Initialized
INFO - 2020-02-11 10:43:58 --> Helper loaded: url_helper
INFO - 2020-02-11 10:43:58 --> Database Driver Class Initialized
DEBUG - 2020-02-11 10:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 10:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 10:43:58 --> Controller Class Initialized
INFO - 2020-02-11 10:43:58 --> Model "M_tiket" initialized
INFO - 2020-02-11 10:43:58 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 10:43:58 --> Model "M_pesan" initialized
INFO - 2020-02-11 10:43:58 --> Helper loaded: form_helper
INFO - 2020-02-11 10:43:58 --> Form Validation Class Initialized
ERROR - 2020-02-11 10:43:58 --> Severity: error --> Exception: Too few arguments to function Tiket::add_all(), 0 passed in C:\xampp\htdocs\roadshow\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 27
INFO - 2020-02-11 10:44:20 --> Config Class Initialized
INFO - 2020-02-11 10:44:20 --> Hooks Class Initialized
DEBUG - 2020-02-11 10:44:20 --> UTF-8 Support Enabled
INFO - 2020-02-11 10:44:20 --> Utf8 Class Initialized
INFO - 2020-02-11 10:44:20 --> URI Class Initialized
INFO - 2020-02-11 10:44:20 --> Router Class Initialized
INFO - 2020-02-11 10:44:20 --> Output Class Initialized
INFO - 2020-02-11 10:44:20 --> Security Class Initialized
DEBUG - 2020-02-11 10:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 10:44:20 --> Input Class Initialized
INFO - 2020-02-11 10:44:20 --> Language Class Initialized
INFO - 2020-02-11 10:44:20 --> Loader Class Initialized
INFO - 2020-02-11 10:44:20 --> Helper loaded: url_helper
INFO - 2020-02-11 10:44:20 --> Database Driver Class Initialized
DEBUG - 2020-02-11 10:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 10:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 10:44:20 --> Controller Class Initialized
INFO - 2020-02-11 10:44:20 --> Model "M_tiket" initialized
INFO - 2020-02-11 10:44:20 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 10:44:20 --> Model "M_pesan" initialized
INFO - 2020-02-11 10:44:20 --> Helper loaded: form_helper
INFO - 2020-02-11 10:44:20 --> Form Validation Class Initialized
ERROR - 2020-02-11 10:44:20 --> Severity: error --> Exception: Too few arguments to function Tiket::add_all(), 0 passed in C:\xampp\htdocs\roadshow\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 27
INFO - 2020-02-11 10:45:39 --> Config Class Initialized
INFO - 2020-02-11 10:45:39 --> Hooks Class Initialized
DEBUG - 2020-02-11 10:45:39 --> UTF-8 Support Enabled
INFO - 2020-02-11 10:45:39 --> Utf8 Class Initialized
INFO - 2020-02-11 10:45:39 --> URI Class Initialized
INFO - 2020-02-11 10:45:39 --> Router Class Initialized
INFO - 2020-02-11 10:45:39 --> Output Class Initialized
INFO - 2020-02-11 10:45:39 --> Security Class Initialized
DEBUG - 2020-02-11 10:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 10:45:39 --> Input Class Initialized
INFO - 2020-02-11 10:45:39 --> Language Class Initialized
INFO - 2020-02-11 10:45:39 --> Loader Class Initialized
INFO - 2020-02-11 10:45:39 --> Helper loaded: url_helper
INFO - 2020-02-11 10:45:39 --> Database Driver Class Initialized
DEBUG - 2020-02-11 10:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 10:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 10:45:39 --> Controller Class Initialized
INFO - 2020-02-11 10:45:39 --> Model "M_tiket" initialized
INFO - 2020-02-11 10:45:39 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 10:45:39 --> Model "M_pesan" initialized
INFO - 2020-02-11 10:45:39 --> Helper loaded: form_helper
INFO - 2020-02-11 10:45:39 --> Form Validation Class Initialized
ERROR - 2020-02-11 10:45:39 --> Severity: error --> Exception: Too few arguments to function Tiket::add_all(), 0 passed in C:\xampp\htdocs\roadshow\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 27
INFO - 2020-02-11 10:46:16 --> Config Class Initialized
INFO - 2020-02-11 10:46:16 --> Hooks Class Initialized
DEBUG - 2020-02-11 10:46:16 --> UTF-8 Support Enabled
INFO - 2020-02-11 10:46:16 --> Utf8 Class Initialized
INFO - 2020-02-11 10:46:16 --> URI Class Initialized
INFO - 2020-02-11 10:46:16 --> Router Class Initialized
INFO - 2020-02-11 10:46:16 --> Output Class Initialized
INFO - 2020-02-11 10:46:16 --> Security Class Initialized
DEBUG - 2020-02-11 10:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 10:46:16 --> Input Class Initialized
INFO - 2020-02-11 10:46:16 --> Language Class Initialized
INFO - 2020-02-11 10:46:16 --> Loader Class Initialized
INFO - 2020-02-11 10:46:16 --> Helper loaded: url_helper
INFO - 2020-02-11 10:46:16 --> Database Driver Class Initialized
DEBUG - 2020-02-11 10:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 10:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 10:46:17 --> Controller Class Initialized
INFO - 2020-02-11 10:46:17 --> Model "M_tiket" initialized
INFO - 2020-02-11 10:46:17 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 10:46:17 --> Model "M_pesan" initialized
INFO - 2020-02-11 10:46:17 --> Helper loaded: form_helper
INFO - 2020-02-11 10:46:17 --> Form Validation Class Initialized
INFO - 2020-02-11 10:46:17 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-11 10:46:17 --> Final output sent to browser
DEBUG - 2020-02-11 10:46:17 --> Total execution time: 0.8439
INFO - 2020-02-11 10:46:17 --> Config Class Initialized
INFO - 2020-02-11 10:46:17 --> Hooks Class Initialized
INFO - 2020-02-11 10:46:17 --> Config Class Initialized
INFO - 2020-02-11 10:46:17 --> Hooks Class Initialized
DEBUG - 2020-02-11 10:46:17 --> UTF-8 Support Enabled
INFO - 2020-02-11 10:46:17 --> Utf8 Class Initialized
DEBUG - 2020-02-11 10:46:17 --> UTF-8 Support Enabled
INFO - 2020-02-11 10:46:17 --> Utf8 Class Initialized
INFO - 2020-02-11 10:46:17 --> URI Class Initialized
INFO - 2020-02-11 10:46:17 --> URI Class Initialized
INFO - 2020-02-11 10:46:17 --> Router Class Initialized
INFO - 2020-02-11 10:46:17 --> Router Class Initialized
INFO - 2020-02-11 10:46:17 --> Output Class Initialized
INFO - 2020-02-11 10:46:17 --> Security Class Initialized
INFO - 2020-02-11 10:46:17 --> Output Class Initialized
INFO - 2020-02-11 10:46:17 --> Security Class Initialized
DEBUG - 2020-02-11 10:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 10:46:17 --> Input Class Initialized
DEBUG - 2020-02-11 10:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 10:46:17 --> Input Class Initialized
INFO - 2020-02-11 10:46:17 --> Language Class Initialized
INFO - 2020-02-11 10:46:17 --> Language Class Initialized
INFO - 2020-02-11 10:46:17 --> Loader Class Initialized
INFO - 2020-02-11 10:46:17 --> Helper loaded: url_helper
INFO - 2020-02-11 10:46:17 --> Loader Class Initialized
INFO - 2020-02-11 10:46:17 --> Helper loaded: url_helper
INFO - 2020-02-11 10:46:17 --> Database Driver Class Initialized
DEBUG - 2020-02-11 10:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 10:46:17 --> Database Driver Class Initialized
INFO - 2020-02-11 10:46:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-11 10:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 10:46:17 --> Controller Class Initialized
INFO - 2020-02-11 10:46:17 --> Model "M_tiket" initialized
INFO - 2020-02-11 10:46:17 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 10:46:17 --> Model "M_pesan" initialized
INFO - 2020-02-11 10:46:17 --> Helper loaded: form_helper
INFO - 2020-02-11 10:46:17 --> Form Validation Class Initialized
ERROR - 2020-02-11 10:46:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-11 10:46:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-11 10:46:18 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-11 10:46:18 --> Final output sent to browser
DEBUG - 2020-02-11 10:46:18 --> Total execution time: 0.6742
INFO - 2020-02-11 10:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 10:46:18 --> Controller Class Initialized
INFO - 2020-02-11 10:46:18 --> Model "M_tiket" initialized
INFO - 2020-02-11 10:46:18 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 10:46:18 --> Model "M_pesan" initialized
INFO - 2020-02-11 10:46:18 --> Helper loaded: form_helper
INFO - 2020-02-11 10:46:18 --> Form Validation Class Initialized
ERROR - 2020-02-11 10:46:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-11 10:46:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-11 10:46:18 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-11 10:46:18 --> Final output sent to browser
DEBUG - 2020-02-11 10:46:18 --> Total execution time: 0.9342
INFO - 2020-02-11 10:46:19 --> Config Class Initialized
INFO - 2020-02-11 10:46:19 --> Hooks Class Initialized
DEBUG - 2020-02-11 10:46:20 --> UTF-8 Support Enabled
INFO - 2020-02-11 10:46:20 --> Utf8 Class Initialized
INFO - 2020-02-11 10:46:20 --> URI Class Initialized
INFO - 2020-02-11 10:46:20 --> Router Class Initialized
INFO - 2020-02-11 10:46:20 --> Output Class Initialized
INFO - 2020-02-11 10:46:20 --> Security Class Initialized
DEBUG - 2020-02-11 10:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 10:46:20 --> Input Class Initialized
INFO - 2020-02-11 10:46:20 --> Language Class Initialized
INFO - 2020-02-11 10:46:20 --> Loader Class Initialized
INFO - 2020-02-11 10:46:20 --> Helper loaded: url_helper
INFO - 2020-02-11 10:46:20 --> Database Driver Class Initialized
DEBUG - 2020-02-11 10:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 10:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 10:46:20 --> Controller Class Initialized
INFO - 2020-02-11 10:46:20 --> Model "M_tiket" initialized
INFO - 2020-02-11 10:46:20 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 10:46:20 --> Model "M_pesan" initialized
INFO - 2020-02-11 10:46:20 --> Helper loaded: form_helper
INFO - 2020-02-11 10:46:20 --> Form Validation Class Initialized
ERROR - 2020-02-11 10:46:20 --> Severity: error --> Exception: Too few arguments to function Tiket::add_all(), 0 passed in C:\xampp\htdocs\roadshow\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 27
INFO - 2020-02-11 10:46:58 --> Config Class Initialized
INFO - 2020-02-11 10:46:58 --> Hooks Class Initialized
DEBUG - 2020-02-11 10:46:58 --> UTF-8 Support Enabled
INFO - 2020-02-11 10:46:58 --> Utf8 Class Initialized
INFO - 2020-02-11 10:46:58 --> URI Class Initialized
INFO - 2020-02-11 10:46:58 --> Router Class Initialized
INFO - 2020-02-11 10:46:58 --> Output Class Initialized
INFO - 2020-02-11 10:46:58 --> Security Class Initialized
DEBUG - 2020-02-11 10:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 10:46:58 --> Input Class Initialized
INFO - 2020-02-11 10:46:58 --> Language Class Initialized
INFO - 2020-02-11 10:46:58 --> Loader Class Initialized
INFO - 2020-02-11 10:46:58 --> Helper loaded: url_helper
INFO - 2020-02-11 10:46:58 --> Database Driver Class Initialized
DEBUG - 2020-02-11 10:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 10:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 10:46:58 --> Controller Class Initialized
INFO - 2020-02-11 10:46:58 --> Model "M_tiket" initialized
INFO - 2020-02-11 10:46:58 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 10:46:58 --> Model "M_pesan" initialized
INFO - 2020-02-11 10:46:58 --> Helper loaded: form_helper
INFO - 2020-02-11 10:46:58 --> Form Validation Class Initialized
ERROR - 2020-02-11 10:46:58 --> Severity: error --> Exception: Too few arguments to function Tiket::add_all(), 0 passed in C:\xampp\htdocs\roadshow\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 27
INFO - 2020-02-11 10:54:00 --> Config Class Initialized
INFO - 2020-02-11 10:54:00 --> Hooks Class Initialized
DEBUG - 2020-02-11 10:54:00 --> UTF-8 Support Enabled
INFO - 2020-02-11 10:54:00 --> Utf8 Class Initialized
INFO - 2020-02-11 10:54:00 --> URI Class Initialized
INFO - 2020-02-11 10:54:00 --> Router Class Initialized
INFO - 2020-02-11 10:54:00 --> Output Class Initialized
INFO - 2020-02-11 10:54:00 --> Security Class Initialized
DEBUG - 2020-02-11 10:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 10:54:00 --> Input Class Initialized
INFO - 2020-02-11 10:54:00 --> Language Class Initialized
INFO - 2020-02-11 10:54:00 --> Loader Class Initialized
INFO - 2020-02-11 10:54:00 --> Helper loaded: url_helper
INFO - 2020-02-11 10:54:00 --> Database Driver Class Initialized
DEBUG - 2020-02-11 10:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 10:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 10:54:00 --> Controller Class Initialized
INFO - 2020-02-11 10:54:00 --> Model "M_tiket" initialized
INFO - 2020-02-11 10:54:00 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 10:54:00 --> Model "M_pesan" initialized
INFO - 2020-02-11 10:54:00 --> Helper loaded: form_helper
INFO - 2020-02-11 10:54:00 --> Form Validation Class Initialized
ERROR - 2020-02-11 10:54:00 --> Severity: error --> Exception: Too few arguments to function Tiket::add_all(), 0 passed in C:\xampp\htdocs\roadshow\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 27
INFO - 2020-02-11 10:55:29 --> Config Class Initialized
INFO - 2020-02-11 10:55:29 --> Hooks Class Initialized
DEBUG - 2020-02-11 10:55:29 --> UTF-8 Support Enabled
INFO - 2020-02-11 10:55:29 --> Utf8 Class Initialized
INFO - 2020-02-11 10:55:29 --> URI Class Initialized
INFO - 2020-02-11 10:55:29 --> Router Class Initialized
INFO - 2020-02-11 10:55:29 --> Output Class Initialized
INFO - 2020-02-11 10:55:29 --> Security Class Initialized
DEBUG - 2020-02-11 10:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 10:55:29 --> Input Class Initialized
INFO - 2020-02-11 10:55:29 --> Language Class Initialized
INFO - 2020-02-11 10:55:29 --> Loader Class Initialized
INFO - 2020-02-11 10:55:29 --> Helper loaded: url_helper
INFO - 2020-02-11 10:55:29 --> Database Driver Class Initialized
DEBUG - 2020-02-11 10:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 10:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 10:55:29 --> Controller Class Initialized
INFO - 2020-02-11 10:55:29 --> Model "M_tiket" initialized
INFO - 2020-02-11 10:55:29 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 10:55:29 --> Model "M_pesan" initialized
INFO - 2020-02-11 10:55:29 --> Helper loaded: form_helper
INFO - 2020-02-11 10:55:30 --> Form Validation Class Initialized
ERROR - 2020-02-11 10:55:30 --> Severity: error --> Exception: Too few arguments to function Tiket::add_all(), 0 passed in C:\xampp\htdocs\roadshow\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 27
INFO - 2020-02-11 10:56:15 --> Config Class Initialized
INFO - 2020-02-11 10:56:15 --> Hooks Class Initialized
DEBUG - 2020-02-11 10:56:15 --> UTF-8 Support Enabled
INFO - 2020-02-11 10:56:16 --> Utf8 Class Initialized
INFO - 2020-02-11 10:56:16 --> URI Class Initialized
INFO - 2020-02-11 10:56:16 --> Router Class Initialized
INFO - 2020-02-11 10:56:16 --> Output Class Initialized
INFO - 2020-02-11 10:56:16 --> Security Class Initialized
DEBUG - 2020-02-11 10:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 10:56:16 --> Input Class Initialized
INFO - 2020-02-11 10:56:16 --> Language Class Initialized
INFO - 2020-02-11 10:56:16 --> Loader Class Initialized
INFO - 2020-02-11 10:56:16 --> Helper loaded: url_helper
INFO - 2020-02-11 10:56:16 --> Database Driver Class Initialized
DEBUG - 2020-02-11 10:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 10:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 10:56:16 --> Controller Class Initialized
INFO - 2020-02-11 10:56:16 --> Model "M_tiket" initialized
INFO - 2020-02-11 10:56:16 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 10:56:16 --> Model "M_pesan" initialized
INFO - 2020-02-11 10:56:16 --> Helper loaded: form_helper
INFO - 2020-02-11 10:56:16 --> Form Validation Class Initialized
ERROR - 2020-02-11 10:56:16 --> Severity: error --> Exception: Too few arguments to function Tiket::add_all(), 0 passed in C:\xampp\htdocs\roadshow\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\roadshow\application\controllers\Tiket.php 27
INFO - 2020-02-11 11:06:04 --> Config Class Initialized
INFO - 2020-02-11 11:06:04 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:06:04 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:06:04 --> Utf8 Class Initialized
INFO - 2020-02-11 11:06:05 --> URI Class Initialized
INFO - 2020-02-11 11:06:05 --> Router Class Initialized
INFO - 2020-02-11 11:06:05 --> Output Class Initialized
INFO - 2020-02-11 11:06:05 --> Security Class Initialized
DEBUG - 2020-02-11 11:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:06:05 --> Input Class Initialized
INFO - 2020-02-11 11:06:05 --> Language Class Initialized
INFO - 2020-02-11 11:06:05 --> Loader Class Initialized
INFO - 2020-02-11 11:06:05 --> Helper loaded: url_helper
INFO - 2020-02-11 11:06:05 --> Database Driver Class Initialized
DEBUG - 2020-02-11 11:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 11:06:05 --> Controller Class Initialized
INFO - 2020-02-11 11:06:05 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:06:05 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:06:05 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:06:05 --> Helper loaded: form_helper
INFO - 2020-02-11 11:06:05 --> Form Validation Class Initialized
ERROR - 2020-02-11 11:06:06 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$nama_bank C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
INFO - 2020-02-11 11:06:06 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-11 11:06:06 --> Final output sent to browser
DEBUG - 2020-02-11 11:06:06 --> Total execution time: 1.3267
INFO - 2020-02-11 11:10:16 --> Config Class Initialized
INFO - 2020-02-11 11:10:16 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:10:16 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:10:16 --> Utf8 Class Initialized
INFO - 2020-02-11 11:10:16 --> URI Class Initialized
INFO - 2020-02-11 11:10:16 --> Router Class Initialized
INFO - 2020-02-11 11:10:16 --> Output Class Initialized
INFO - 2020-02-11 11:10:16 --> Security Class Initialized
DEBUG - 2020-02-11 11:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:10:16 --> Input Class Initialized
INFO - 2020-02-11 11:10:16 --> Language Class Initialized
INFO - 2020-02-11 11:10:16 --> Loader Class Initialized
INFO - 2020-02-11 11:10:16 --> Helper loaded: url_helper
INFO - 2020-02-11 11:10:16 --> Database Driver Class Initialized
DEBUG - 2020-02-11 11:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 11:10:16 --> Controller Class Initialized
INFO - 2020-02-11 11:10:16 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:10:16 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:10:16 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:10:16 --> Helper loaded: form_helper
INFO - 2020-02-11 11:10:16 --> Form Validation Class Initialized
ERROR - 2020-02-11 11:10:17 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$nama_bank C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
INFO - 2020-02-11 11:10:17 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-11 11:10:17 --> Final output sent to browser
DEBUG - 2020-02-11 11:10:17 --> Total execution time: 0.8868
INFO - 2020-02-11 11:14:46 --> Config Class Initialized
INFO - 2020-02-11 11:14:46 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:14:46 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:14:46 --> Utf8 Class Initialized
INFO - 2020-02-11 11:14:46 --> URI Class Initialized
INFO - 2020-02-11 11:14:46 --> Router Class Initialized
INFO - 2020-02-11 11:14:46 --> Output Class Initialized
INFO - 2020-02-11 11:14:46 --> Security Class Initialized
DEBUG - 2020-02-11 11:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:14:46 --> Input Class Initialized
INFO - 2020-02-11 11:14:46 --> Language Class Initialized
INFO - 2020-02-11 11:14:46 --> Loader Class Initialized
INFO - 2020-02-11 11:14:46 --> Helper loaded: url_helper
INFO - 2020-02-11 11:14:47 --> Database Driver Class Initialized
DEBUG - 2020-02-11 11:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 11:14:47 --> Controller Class Initialized
INFO - 2020-02-11 11:14:47 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:14:47 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:14:47 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:14:47 --> Helper loaded: form_helper
INFO - 2020-02-11 11:14:47 --> Form Validation Class Initialized
ERROR - 2020-02-11 11:14:47 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$atasnama C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
INFO - 2020-02-11 11:14:47 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-11 11:14:47 --> Final output sent to browser
DEBUG - 2020-02-11 11:14:47 --> Total execution time: 0.5723
INFO - 2020-02-11 11:14:59 --> Config Class Initialized
INFO - 2020-02-11 11:14:59 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:14:59 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:14:59 --> Utf8 Class Initialized
INFO - 2020-02-11 11:14:59 --> URI Class Initialized
INFO - 2020-02-11 11:14:59 --> Router Class Initialized
INFO - 2020-02-11 11:14:59 --> Output Class Initialized
INFO - 2020-02-11 11:14:59 --> Security Class Initialized
DEBUG - 2020-02-11 11:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:14:59 --> Input Class Initialized
INFO - 2020-02-11 11:14:59 --> Language Class Initialized
INFO - 2020-02-11 11:14:59 --> Loader Class Initialized
INFO - 2020-02-11 11:14:59 --> Helper loaded: url_helper
INFO - 2020-02-11 11:14:59 --> Database Driver Class Initialized
DEBUG - 2020-02-11 11:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 11:14:59 --> Controller Class Initialized
INFO - 2020-02-11 11:14:59 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:14:59 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:14:59 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:14:59 --> Helper loaded: form_helper
INFO - 2020-02-11 11:14:59 --> Form Validation Class Initialized
ERROR - 2020-02-11 11:14:59 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$atas_nama C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
INFO - 2020-02-11 11:14:59 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-11 11:14:59 --> Final output sent to browser
DEBUG - 2020-02-11 11:14:59 --> Total execution time: 0.5791
INFO - 2020-02-11 11:15:17 --> Config Class Initialized
INFO - 2020-02-11 11:15:17 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:15:17 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:15:17 --> Utf8 Class Initialized
INFO - 2020-02-11 11:15:17 --> URI Class Initialized
INFO - 2020-02-11 11:15:17 --> Router Class Initialized
INFO - 2020-02-11 11:15:17 --> Output Class Initialized
INFO - 2020-02-11 11:15:17 --> Security Class Initialized
DEBUG - 2020-02-11 11:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:15:17 --> Input Class Initialized
INFO - 2020-02-11 11:15:17 --> Language Class Initialized
INFO - 2020-02-11 11:15:17 --> Loader Class Initialized
INFO - 2020-02-11 11:15:17 --> Helper loaded: url_helper
INFO - 2020-02-11 11:15:18 --> Database Driver Class Initialized
DEBUG - 2020-02-11 11:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 11:15:18 --> Controller Class Initialized
INFO - 2020-02-11 11:15:18 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:15:18 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:15:18 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:15:18 --> Helper loaded: form_helper
INFO - 2020-02-11 11:15:18 --> Form Validation Class Initialized
ERROR - 2020-02-11 11:15:18 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
INFO - 2020-02-11 11:15:18 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-11 11:15:18 --> Final output sent to browser
DEBUG - 2020-02-11 11:15:18 --> Total execution time: 0.5320
INFO - 2020-02-11 11:16:36 --> Config Class Initialized
INFO - 2020-02-11 11:16:36 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:16:36 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:16:36 --> Utf8 Class Initialized
INFO - 2020-02-11 11:16:36 --> URI Class Initialized
INFO - 2020-02-11 11:16:36 --> Router Class Initialized
INFO - 2020-02-11 11:16:36 --> Output Class Initialized
INFO - 2020-02-11 11:16:36 --> Security Class Initialized
DEBUG - 2020-02-11 11:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:16:36 --> Input Class Initialized
INFO - 2020-02-11 11:16:36 --> Language Class Initialized
INFO - 2020-02-11 11:16:36 --> Loader Class Initialized
INFO - 2020-02-11 11:16:36 --> Helper loaded: url_helper
INFO - 2020-02-11 11:16:36 --> Database Driver Class Initialized
DEBUG - 2020-02-11 11:16:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 11:16:36 --> Controller Class Initialized
INFO - 2020-02-11 11:16:36 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:16:36 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:16:36 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:16:36 --> Helper loaded: form_helper
INFO - 2020-02-11 11:16:36 --> Form Validation Class Initialized
ERROR - 2020-02-11 11:16:37 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
INFO - 2020-02-11 11:16:37 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-11 11:16:37 --> Final output sent to browser
DEBUG - 2020-02-11 11:16:37 --> Total execution time: 0.4930
INFO - 2020-02-11 11:16:49 --> Config Class Initialized
INFO - 2020-02-11 11:16:49 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:16:49 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:16:49 --> Utf8 Class Initialized
INFO - 2020-02-11 11:16:50 --> URI Class Initialized
INFO - 2020-02-11 11:16:50 --> Router Class Initialized
INFO - 2020-02-11 11:16:50 --> Output Class Initialized
INFO - 2020-02-11 11:16:50 --> Security Class Initialized
DEBUG - 2020-02-11 11:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:16:50 --> Input Class Initialized
INFO - 2020-02-11 11:16:50 --> Language Class Initialized
INFO - 2020-02-11 11:16:50 --> Loader Class Initialized
INFO - 2020-02-11 11:16:50 --> Helper loaded: url_helper
INFO - 2020-02-11 11:16:50 --> Database Driver Class Initialized
DEBUG - 2020-02-11 11:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 11:16:50 --> Controller Class Initialized
INFO - 2020-02-11 11:16:50 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:16:50 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:16:50 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:16:50 --> Helper loaded: form_helper
INFO - 2020-02-11 11:16:50 --> Form Validation Class Initialized
ERROR - 2020-02-11 11:16:50 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$atas_nama C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 4
INFO - 2020-02-11 11:16:50 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-11 11:16:50 --> Final output sent to browser
DEBUG - 2020-02-11 11:16:50 --> Total execution time: 0.5502
INFO - 2020-02-11 11:19:09 --> Config Class Initialized
INFO - 2020-02-11 11:19:09 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:19:09 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:19:09 --> Utf8 Class Initialized
INFO - 2020-02-11 11:19:09 --> URI Class Initialized
INFO - 2020-02-11 11:19:09 --> Router Class Initialized
INFO - 2020-02-11 11:19:09 --> Output Class Initialized
INFO - 2020-02-11 11:19:09 --> Security Class Initialized
DEBUG - 2020-02-11 11:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:19:09 --> Input Class Initialized
INFO - 2020-02-11 11:19:09 --> Language Class Initialized
INFO - 2020-02-11 11:19:09 --> Loader Class Initialized
INFO - 2020-02-11 11:19:09 --> Helper loaded: url_helper
INFO - 2020-02-11 11:19:09 --> Database Driver Class Initialized
DEBUG - 2020-02-11 11:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 11:19:09 --> Controller Class Initialized
INFO - 2020-02-11 11:19:09 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:19:09 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:19:09 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:19:09 --> Helper loaded: form_helper
INFO - 2020-02-11 11:19:09 --> Form Validation Class Initialized
INFO - 2020-02-11 11:19:09 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-11 11:19:09 --> Final output sent to browser
DEBUG - 2020-02-11 11:19:09 --> Total execution time: 0.5091
INFO - 2020-02-11 11:20:08 --> Config Class Initialized
INFO - 2020-02-11 11:20:08 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:20:08 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:20:08 --> Utf8 Class Initialized
INFO - 2020-02-11 11:20:08 --> URI Class Initialized
INFO - 2020-02-11 11:20:08 --> Router Class Initialized
INFO - 2020-02-11 11:20:08 --> Output Class Initialized
INFO - 2020-02-11 11:20:08 --> Security Class Initialized
DEBUG - 2020-02-11 11:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:20:08 --> Input Class Initialized
INFO - 2020-02-11 11:20:08 --> Language Class Initialized
INFO - 2020-02-11 11:20:08 --> Loader Class Initialized
INFO - 2020-02-11 11:20:08 --> Helper loaded: url_helper
INFO - 2020-02-11 11:20:08 --> Database Driver Class Initialized
DEBUG - 2020-02-11 11:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 11:20:08 --> Controller Class Initialized
INFO - 2020-02-11 11:20:08 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:20:08 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:20:08 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:20:08 --> Helper loaded: form_helper
INFO - 2020-02-11 11:20:08 --> Form Validation Class Initialized
INFO - 2020-02-11 11:20:08 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-11 11:20:08 --> Final output sent to browser
DEBUG - 2020-02-11 11:20:08 --> Total execution time: 0.3650
INFO - 2020-02-11 11:20:08 --> Config Class Initialized
INFO - 2020-02-11 11:20:08 --> Config Class Initialized
INFO - 2020-02-11 11:20:08 --> Hooks Class Initialized
INFO - 2020-02-11 11:20:08 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:20:08 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 11:20:08 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:20:08 --> Utf8 Class Initialized
INFO - 2020-02-11 11:20:08 --> Utf8 Class Initialized
INFO - 2020-02-11 11:20:08 --> URI Class Initialized
INFO - 2020-02-11 11:20:08 --> URI Class Initialized
INFO - 2020-02-11 11:20:08 --> Router Class Initialized
INFO - 2020-02-11 11:20:08 --> Router Class Initialized
INFO - 2020-02-11 11:20:08 --> Output Class Initialized
INFO - 2020-02-11 11:20:08 --> Output Class Initialized
INFO - 2020-02-11 11:20:08 --> Security Class Initialized
INFO - 2020-02-11 11:20:08 --> Security Class Initialized
DEBUG - 2020-02-11 11:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 11:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:20:08 --> Input Class Initialized
INFO - 2020-02-11 11:20:08 --> Input Class Initialized
INFO - 2020-02-11 11:20:08 --> Language Class Initialized
INFO - 2020-02-11 11:20:08 --> Language Class Initialized
INFO - 2020-02-11 11:20:08 --> Loader Class Initialized
INFO - 2020-02-11 11:20:08 --> Loader Class Initialized
INFO - 2020-02-11 11:20:08 --> Helper loaded: url_helper
INFO - 2020-02-11 11:20:08 --> Helper loaded: url_helper
INFO - 2020-02-11 11:20:08 --> Database Driver Class Initialized
INFO - 2020-02-11 11:20:08 --> Database Driver Class Initialized
DEBUG - 2020-02-11 11:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-11 11:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 11:20:09 --> Controller Class Initialized
INFO - 2020-02-11 11:20:09 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:20:09 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:20:09 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:20:09 --> Helper loaded: form_helper
INFO - 2020-02-11 11:20:09 --> Form Validation Class Initialized
ERROR - 2020-02-11 11:20:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-11 11:20:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-11 11:20:09 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-11 11:20:09 --> Final output sent to browser
DEBUG - 2020-02-11 11:20:09 --> Total execution time: 0.4978
INFO - 2020-02-11 11:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 11:20:09 --> Controller Class Initialized
INFO - 2020-02-11 11:20:09 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:20:09 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:20:09 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:20:09 --> Helper loaded: form_helper
INFO - 2020-02-11 11:20:09 --> Form Validation Class Initialized
ERROR - 2020-02-11 11:20:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-11 11:20:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-11 11:20:09 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-11 11:20:09 --> Final output sent to browser
DEBUG - 2020-02-11 11:20:09 --> Total execution time: 0.6727
INFO - 2020-02-11 11:20:14 --> Config Class Initialized
INFO - 2020-02-11 11:20:14 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:20:14 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:20:14 --> Utf8 Class Initialized
INFO - 2020-02-11 11:20:14 --> URI Class Initialized
INFO - 2020-02-11 11:20:14 --> Router Class Initialized
INFO - 2020-02-11 11:20:14 --> Output Class Initialized
INFO - 2020-02-11 11:20:14 --> Security Class Initialized
DEBUG - 2020-02-11 11:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:20:14 --> Input Class Initialized
INFO - 2020-02-11 11:20:14 --> Language Class Initialized
INFO - 2020-02-11 11:20:14 --> Loader Class Initialized
INFO - 2020-02-11 11:20:14 --> Helper loaded: url_helper
INFO - 2020-02-11 11:20:14 --> Database Driver Class Initialized
DEBUG - 2020-02-11 11:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 11:20:14 --> Controller Class Initialized
INFO - 2020-02-11 11:20:14 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:20:14 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:20:14 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:20:14 --> Helper loaded: form_helper
INFO - 2020-02-11 11:20:14 --> Form Validation Class Initialized
INFO - 2020-02-11 11:20:14 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-11 11:20:14 --> Final output sent to browser
DEBUG - 2020-02-11 11:20:14 --> Total execution time: 0.3514
INFO - 2020-02-11 11:20:17 --> Config Class Initialized
INFO - 2020-02-11 11:20:17 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:20:17 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:20:17 --> Utf8 Class Initialized
INFO - 2020-02-11 11:20:17 --> URI Class Initialized
INFO - 2020-02-11 11:20:17 --> Router Class Initialized
INFO - 2020-02-11 11:20:17 --> Output Class Initialized
INFO - 2020-02-11 11:20:17 --> Security Class Initialized
DEBUG - 2020-02-11 11:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:20:17 --> Input Class Initialized
INFO - 2020-02-11 11:20:17 --> Language Class Initialized
INFO - 2020-02-11 11:20:17 --> Loader Class Initialized
INFO - 2020-02-11 11:20:17 --> Helper loaded: url_helper
INFO - 2020-02-11 11:20:17 --> Database Driver Class Initialized
DEBUG - 2020-02-11 11:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 11:20:17 --> Controller Class Initialized
INFO - 2020-02-11 11:20:17 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:20:17 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:20:17 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:20:17 --> Helper loaded: form_helper
INFO - 2020-02-11 11:20:17 --> Form Validation Class Initialized
INFO - 2020-02-11 11:20:17 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-11 11:20:17 --> Final output sent to browser
DEBUG - 2020-02-11 11:20:17 --> Total execution time: 0.3644
INFO - 2020-02-11 11:20:17 --> Config Class Initialized
INFO - 2020-02-11 11:20:17 --> Hooks Class Initialized
INFO - 2020-02-11 11:20:17 --> Config Class Initialized
INFO - 2020-02-11 11:20:17 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:20:17 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:20:17 --> Utf8 Class Initialized
DEBUG - 2020-02-11 11:20:17 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:20:17 --> Utf8 Class Initialized
INFO - 2020-02-11 11:20:17 --> URI Class Initialized
INFO - 2020-02-11 11:20:17 --> URI Class Initialized
INFO - 2020-02-11 11:20:17 --> Router Class Initialized
INFO - 2020-02-11 11:20:17 --> Router Class Initialized
INFO - 2020-02-11 11:20:18 --> Output Class Initialized
INFO - 2020-02-11 11:20:18 --> Security Class Initialized
INFO - 2020-02-11 11:20:18 --> Output Class Initialized
INFO - 2020-02-11 11:20:18 --> Security Class Initialized
DEBUG - 2020-02-11 11:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:20:18 --> Input Class Initialized
DEBUG - 2020-02-11 11:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:20:18 --> Input Class Initialized
INFO - 2020-02-11 11:20:18 --> Language Class Initialized
INFO - 2020-02-11 11:20:18 --> Language Class Initialized
INFO - 2020-02-11 11:20:18 --> Loader Class Initialized
INFO - 2020-02-11 11:20:18 --> Helper loaded: url_helper
INFO - 2020-02-11 11:20:18 --> Loader Class Initialized
INFO - 2020-02-11 11:20:18 --> Helper loaded: url_helper
INFO - 2020-02-11 11:20:18 --> Database Driver Class Initialized
DEBUG - 2020-02-11 11:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:20:18 --> Database Driver Class Initialized
INFO - 2020-02-11 11:20:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-11 11:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:20:18 --> Controller Class Initialized
INFO - 2020-02-11 11:20:18 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:20:18 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:20:18 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:20:18 --> Helper loaded: form_helper
INFO - 2020-02-11 11:20:18 --> Form Validation Class Initialized
ERROR - 2020-02-11 11:20:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-11 11:20:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-11 11:20:18 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-11 11:20:18 --> Final output sent to browser
DEBUG - 2020-02-11 11:20:18 --> Total execution time: 0.5238
INFO - 2020-02-11 11:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 11:20:18 --> Controller Class Initialized
INFO - 2020-02-11 11:20:18 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:20:18 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:20:18 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:20:18 --> Helper loaded: form_helper
INFO - 2020-02-11 11:20:18 --> Form Validation Class Initialized
ERROR - 2020-02-11 11:20:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-11 11:20:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-11 11:20:18 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-11 11:20:18 --> Final output sent to browser
DEBUG - 2020-02-11 11:20:18 --> Total execution time: 0.6975
INFO - 2020-02-11 11:20:22 --> Config Class Initialized
INFO - 2020-02-11 11:20:22 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:20:22 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:20:22 --> Utf8 Class Initialized
INFO - 2020-02-11 11:20:22 --> URI Class Initialized
INFO - 2020-02-11 11:20:22 --> Router Class Initialized
INFO - 2020-02-11 11:20:22 --> Output Class Initialized
INFO - 2020-02-11 11:20:22 --> Security Class Initialized
DEBUG - 2020-02-11 11:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:20:22 --> Input Class Initialized
INFO - 2020-02-11 11:20:22 --> Language Class Initialized
INFO - 2020-02-11 11:20:22 --> Loader Class Initialized
INFO - 2020-02-11 11:20:22 --> Helper loaded: url_helper
INFO - 2020-02-11 11:20:22 --> Database Driver Class Initialized
DEBUG - 2020-02-11 11:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 11:20:22 --> Controller Class Initialized
INFO - 2020-02-11 11:20:22 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:20:22 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:20:22 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:20:22 --> Helper loaded: form_helper
INFO - 2020-02-11 11:20:22 --> Form Validation Class Initialized
INFO - 2020-02-11 11:20:22 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-11 11:20:22 --> Final output sent to browser
DEBUG - 2020-02-11 11:20:22 --> Total execution time: 0.3676
INFO - 2020-02-11 11:20:59 --> Config Class Initialized
INFO - 2020-02-11 11:20:59 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:20:59 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:20:59 --> Utf8 Class Initialized
INFO - 2020-02-11 11:20:59 --> URI Class Initialized
INFO - 2020-02-11 11:20:59 --> Router Class Initialized
INFO - 2020-02-11 11:20:59 --> Output Class Initialized
INFO - 2020-02-11 11:20:59 --> Security Class Initialized
DEBUG - 2020-02-11 11:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:20:59 --> Input Class Initialized
INFO - 2020-02-11 11:20:59 --> Language Class Initialized
INFO - 2020-02-11 11:20:59 --> Loader Class Initialized
INFO - 2020-02-11 11:20:59 --> Helper loaded: url_helper
INFO - 2020-02-11 11:20:59 --> Database Driver Class Initialized
DEBUG - 2020-02-11 11:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 11:20:59 --> Controller Class Initialized
INFO - 2020-02-11 11:20:59 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:20:59 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:20:59 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:20:59 --> Helper loaded: form_helper
INFO - 2020-02-11 11:20:59 --> Form Validation Class Initialized
INFO - 2020-02-11 11:20:59 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-11 11:20:59 --> Final output sent to browser
DEBUG - 2020-02-11 11:20:59 --> Total execution time: 0.4263
INFO - 2020-02-11 11:21:07 --> Config Class Initialized
INFO - 2020-02-11 11:21:07 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:21:07 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:21:07 --> Utf8 Class Initialized
INFO - 2020-02-11 11:21:07 --> URI Class Initialized
INFO - 2020-02-11 11:21:08 --> Router Class Initialized
INFO - 2020-02-11 11:21:08 --> Output Class Initialized
INFO - 2020-02-11 11:21:08 --> Security Class Initialized
DEBUG - 2020-02-11 11:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:21:08 --> Input Class Initialized
INFO - 2020-02-11 11:21:08 --> Language Class Initialized
INFO - 2020-02-11 11:21:08 --> Loader Class Initialized
INFO - 2020-02-11 11:21:08 --> Helper loaded: url_helper
INFO - 2020-02-11 11:21:08 --> Database Driver Class Initialized
DEBUG - 2020-02-11 11:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 11:21:08 --> Controller Class Initialized
INFO - 2020-02-11 11:21:08 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:21:08 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:21:08 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:21:08 --> Helper loaded: form_helper
INFO - 2020-02-11 11:21:08 --> Form Validation Class Initialized
INFO - 2020-02-11 11:21:08 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-11 11:21:08 --> Final output sent to browser
DEBUG - 2020-02-11 11:21:08 --> Total execution time: 0.3782
INFO - 2020-02-11 11:22:16 --> Config Class Initialized
INFO - 2020-02-11 11:22:16 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:22:16 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:22:16 --> Utf8 Class Initialized
INFO - 2020-02-11 11:22:16 --> URI Class Initialized
INFO - 2020-02-11 11:22:16 --> Router Class Initialized
INFO - 2020-02-11 11:22:16 --> Output Class Initialized
INFO - 2020-02-11 11:22:16 --> Security Class Initialized
DEBUG - 2020-02-11 11:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:22:16 --> Input Class Initialized
INFO - 2020-02-11 11:22:16 --> Language Class Initialized
INFO - 2020-02-11 11:22:16 --> Loader Class Initialized
INFO - 2020-02-11 11:22:16 --> Helper loaded: url_helper
INFO - 2020-02-11 11:22:16 --> Database Driver Class Initialized
DEBUG - 2020-02-11 11:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 11:22:16 --> Controller Class Initialized
INFO - 2020-02-11 11:22:16 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:22:16 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:22:16 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:22:16 --> Helper loaded: form_helper
INFO - 2020-02-11 11:22:16 --> Form Validation Class Initialized
INFO - 2020-02-11 11:22:16 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-11 11:22:16 --> Final output sent to browser
DEBUG - 2020-02-11 11:22:16 --> Total execution time: 0.3715
INFO - 2020-02-11 11:22:33 --> Config Class Initialized
INFO - 2020-02-11 11:22:33 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:22:33 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:22:33 --> Utf8 Class Initialized
INFO - 2020-02-11 11:22:33 --> URI Class Initialized
INFO - 2020-02-11 11:22:33 --> Router Class Initialized
INFO - 2020-02-11 11:22:33 --> Output Class Initialized
INFO - 2020-02-11 11:22:33 --> Security Class Initialized
DEBUG - 2020-02-11 11:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:22:33 --> Input Class Initialized
INFO - 2020-02-11 11:22:33 --> Language Class Initialized
INFO - 2020-02-11 11:22:33 --> Loader Class Initialized
INFO - 2020-02-11 11:22:33 --> Helper loaded: url_helper
INFO - 2020-02-11 11:22:33 --> Database Driver Class Initialized
DEBUG - 2020-02-11 11:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 11:22:33 --> Controller Class Initialized
INFO - 2020-02-11 11:22:33 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:22:33 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:22:33 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:22:33 --> Helper loaded: form_helper
INFO - 2020-02-11 11:22:33 --> Form Validation Class Initialized
INFO - 2020-02-11 11:22:33 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-11 11:22:33 --> Final output sent to browser
DEBUG - 2020-02-11 11:22:33 --> Total execution time: 0.3723
INFO - 2020-02-11 11:22:34 --> Config Class Initialized
INFO - 2020-02-11 11:22:34 --> Config Class Initialized
INFO - 2020-02-11 11:22:34 --> Hooks Class Initialized
INFO - 2020-02-11 11:22:34 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:22:34 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 11:22:34 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:22:34 --> Utf8 Class Initialized
INFO - 2020-02-11 11:22:34 --> Utf8 Class Initialized
INFO - 2020-02-11 11:22:34 --> URI Class Initialized
INFO - 2020-02-11 11:22:34 --> URI Class Initialized
INFO - 2020-02-11 11:22:34 --> Router Class Initialized
INFO - 2020-02-11 11:22:34 --> Router Class Initialized
INFO - 2020-02-11 11:22:34 --> Output Class Initialized
INFO - 2020-02-11 11:22:34 --> Output Class Initialized
INFO - 2020-02-11 11:22:34 --> Security Class Initialized
INFO - 2020-02-11 11:22:34 --> Security Class Initialized
DEBUG - 2020-02-11 11:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 11:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:22:34 --> Input Class Initialized
INFO - 2020-02-11 11:22:34 --> Input Class Initialized
INFO - 2020-02-11 11:22:34 --> Language Class Initialized
INFO - 2020-02-11 11:22:34 --> Language Class Initialized
INFO - 2020-02-11 11:22:34 --> Loader Class Initialized
INFO - 2020-02-11 11:22:34 --> Loader Class Initialized
INFO - 2020-02-11 11:22:34 --> Helper loaded: url_helper
INFO - 2020-02-11 11:22:34 --> Helper loaded: url_helper
INFO - 2020-02-11 11:22:34 --> Database Driver Class Initialized
INFO - 2020-02-11 11:22:34 --> Database Driver Class Initialized
DEBUG - 2020-02-11 11:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-11 11:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 11:22:34 --> Controller Class Initialized
INFO - 2020-02-11 11:22:34 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:22:34 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:22:34 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:22:34 --> Helper loaded: form_helper
INFO - 2020-02-11 11:22:34 --> Form Validation Class Initialized
ERROR - 2020-02-11 11:22:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-11 11:22:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-11 11:22:34 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-11 11:22:34 --> Final output sent to browser
DEBUG - 2020-02-11 11:22:34 --> Total execution time: 0.4831
INFO - 2020-02-11 11:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 11:22:34 --> Controller Class Initialized
INFO - 2020-02-11 11:22:34 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:22:34 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:22:34 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:22:34 --> Helper loaded: form_helper
INFO - 2020-02-11 11:22:34 --> Form Validation Class Initialized
ERROR - 2020-02-11 11:22:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-11 11:22:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-11 11:22:34 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-11 11:22:34 --> Final output sent to browser
DEBUG - 2020-02-11 11:22:34 --> Total execution time: 0.7067
INFO - 2020-02-11 11:28:28 --> Config Class Initialized
INFO - 2020-02-11 11:28:28 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:28:28 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:28:28 --> Utf8 Class Initialized
INFO - 2020-02-11 11:28:28 --> URI Class Initialized
INFO - 2020-02-11 11:28:28 --> Router Class Initialized
INFO - 2020-02-11 11:28:28 --> Output Class Initialized
INFO - 2020-02-11 11:28:28 --> Security Class Initialized
DEBUG - 2020-02-11 11:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:28:28 --> Input Class Initialized
INFO - 2020-02-11 11:28:28 --> Language Class Initialized
INFO - 2020-02-11 11:28:28 --> Loader Class Initialized
INFO - 2020-02-11 11:28:28 --> Helper loaded: url_helper
INFO - 2020-02-11 11:28:28 --> Database Driver Class Initialized
DEBUG - 2020-02-11 11:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 11:28:28 --> Controller Class Initialized
INFO - 2020-02-11 11:28:28 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:28:28 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:28:28 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:28:28 --> Helper loaded: form_helper
INFO - 2020-02-11 11:28:28 --> Form Validation Class Initialized
ERROR - 2020-02-11 11:28:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 2
INFO - 2020-02-11 11:28:28 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-11 11:28:28 --> Final output sent to browser
DEBUG - 2020-02-11 11:28:28 --> Total execution time: 0.3870
INFO - 2020-02-11 11:31:03 --> Config Class Initialized
INFO - 2020-02-11 11:31:03 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:31:03 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:31:03 --> Utf8 Class Initialized
INFO - 2020-02-11 11:31:03 --> URI Class Initialized
INFO - 2020-02-11 11:31:03 --> Router Class Initialized
INFO - 2020-02-11 11:31:03 --> Output Class Initialized
INFO - 2020-02-11 11:31:03 --> Security Class Initialized
DEBUG - 2020-02-11 11:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:31:03 --> Input Class Initialized
INFO - 2020-02-11 11:31:03 --> Language Class Initialized
INFO - 2020-02-11 11:31:03 --> Loader Class Initialized
INFO - 2020-02-11 11:31:03 --> Helper loaded: url_helper
INFO - 2020-02-11 11:31:03 --> Database Driver Class Initialized
DEBUG - 2020-02-11 11:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 11:31:03 --> Controller Class Initialized
INFO - 2020-02-11 11:31:03 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:31:03 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:31:03 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:31:03 --> Helper loaded: form_helper
INFO - 2020-02-11 11:31:03 --> Form Validation Class Initialized
ERROR - 2020-02-11 11:31:03 --> Severity: error --> Exception: Call to a member function result() on array C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 2
INFO - 2020-02-11 11:31:40 --> Config Class Initialized
INFO - 2020-02-11 11:31:40 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:31:40 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:31:40 --> Utf8 Class Initialized
INFO - 2020-02-11 11:31:40 --> URI Class Initialized
INFO - 2020-02-11 11:31:40 --> Router Class Initialized
INFO - 2020-02-11 11:31:40 --> Output Class Initialized
INFO - 2020-02-11 11:31:40 --> Security Class Initialized
DEBUG - 2020-02-11 11:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:31:40 --> Input Class Initialized
INFO - 2020-02-11 11:31:40 --> Language Class Initialized
INFO - 2020-02-11 11:31:41 --> Loader Class Initialized
INFO - 2020-02-11 11:31:41 --> Helper loaded: url_helper
INFO - 2020-02-11 11:31:41 --> Database Driver Class Initialized
DEBUG - 2020-02-11 11:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 11:31:41 --> Controller Class Initialized
INFO - 2020-02-11 11:31:41 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:31:41 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:31:41 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:31:41 --> Helper loaded: form_helper
INFO - 2020-02-11 11:31:41 --> Form Validation Class Initialized
ERROR - 2020-02-11 11:31:41 --> Severity: error --> Exception: Call to a member function result() on array C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 2
INFO - 2020-02-11 11:34:22 --> Config Class Initialized
INFO - 2020-02-11 11:34:22 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:34:22 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:34:22 --> Utf8 Class Initialized
INFO - 2020-02-11 11:34:22 --> URI Class Initialized
INFO - 2020-02-11 11:34:22 --> Router Class Initialized
INFO - 2020-02-11 11:34:22 --> Output Class Initialized
INFO - 2020-02-11 11:34:22 --> Security Class Initialized
DEBUG - 2020-02-11 11:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:34:22 --> Input Class Initialized
INFO - 2020-02-11 11:34:22 --> Language Class Initialized
INFO - 2020-02-11 11:34:23 --> Loader Class Initialized
INFO - 2020-02-11 11:34:23 --> Helper loaded: url_helper
INFO - 2020-02-11 11:34:23 --> Database Driver Class Initialized
DEBUG - 2020-02-11 11:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 11:34:23 --> Controller Class Initialized
INFO - 2020-02-11 11:34:23 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:34:23 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:34:23 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:34:23 --> Helper loaded: form_helper
INFO - 2020-02-11 11:34:23 --> Form Validation Class Initialized
ERROR - 2020-02-11 11:34:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 2
INFO - 2020-02-11 11:34:23 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-11 11:34:23 --> Final output sent to browser
DEBUG - 2020-02-11 11:34:23 --> Total execution time: 0.4117
INFO - 2020-02-11 11:35:14 --> Config Class Initialized
INFO - 2020-02-11 11:35:14 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:35:14 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:35:14 --> Utf8 Class Initialized
INFO - 2020-02-11 11:35:14 --> URI Class Initialized
INFO - 2020-02-11 11:35:14 --> Router Class Initialized
INFO - 2020-02-11 11:35:14 --> Output Class Initialized
INFO - 2020-02-11 11:35:14 --> Security Class Initialized
DEBUG - 2020-02-11 11:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:35:14 --> Input Class Initialized
INFO - 2020-02-11 11:35:14 --> Language Class Initialized
INFO - 2020-02-11 11:35:14 --> Loader Class Initialized
INFO - 2020-02-11 11:35:14 --> Helper loaded: url_helper
INFO - 2020-02-11 11:35:14 --> Database Driver Class Initialized
DEBUG - 2020-02-11 11:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 11:35:14 --> Controller Class Initialized
INFO - 2020-02-11 11:35:14 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:35:14 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:35:14 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:35:14 --> Helper loaded: form_helper
INFO - 2020-02-11 11:35:14 --> Form Validation Class Initialized
ERROR - 2020-02-11 11:35:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\Pemesanan\konfirm_bayar.php 2
INFO - 2020-02-11 11:35:14 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-11 11:35:14 --> Final output sent to browser
DEBUG - 2020-02-11 11:35:14 --> Total execution time: 0.3916
INFO - 2020-02-11 11:36:21 --> Config Class Initialized
INFO - 2020-02-11 11:36:21 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:36:21 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:36:21 --> Utf8 Class Initialized
INFO - 2020-02-11 11:36:21 --> URI Class Initialized
INFO - 2020-02-11 11:36:21 --> Router Class Initialized
INFO - 2020-02-11 11:36:21 --> Output Class Initialized
INFO - 2020-02-11 11:36:21 --> Security Class Initialized
DEBUG - 2020-02-11 11:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:36:21 --> Input Class Initialized
INFO - 2020-02-11 11:36:21 --> Language Class Initialized
INFO - 2020-02-11 11:36:21 --> Loader Class Initialized
INFO - 2020-02-11 11:36:21 --> Helper loaded: url_helper
INFO - 2020-02-11 11:36:21 --> Database Driver Class Initialized
DEBUG - 2020-02-11 11:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 11:36:22 --> Controller Class Initialized
INFO - 2020-02-11 11:36:22 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:36:22 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:36:22 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:36:22 --> Helper loaded: form_helper
INFO - 2020-02-11 11:36:22 --> Form Validation Class Initialized
INFO - 2020-02-11 11:36:22 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-11 11:36:22 --> Final output sent to browser
DEBUG - 2020-02-11 11:36:22 --> Total execution time: 0.4308
INFO - 2020-02-11 11:37:12 --> Config Class Initialized
INFO - 2020-02-11 11:37:12 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:37:12 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:37:12 --> Utf8 Class Initialized
INFO - 2020-02-11 11:37:12 --> URI Class Initialized
INFO - 2020-02-11 11:37:12 --> Router Class Initialized
INFO - 2020-02-11 11:37:12 --> Output Class Initialized
INFO - 2020-02-11 11:37:12 --> Security Class Initialized
DEBUG - 2020-02-11 11:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:37:12 --> Input Class Initialized
INFO - 2020-02-11 11:37:12 --> Language Class Initialized
INFO - 2020-02-11 11:37:12 --> Loader Class Initialized
INFO - 2020-02-11 11:37:12 --> Helper loaded: url_helper
INFO - 2020-02-11 11:37:12 --> Database Driver Class Initialized
DEBUG - 2020-02-11 11:37:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 11:37:12 --> Controller Class Initialized
INFO - 2020-02-11 11:37:12 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:37:12 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:37:12 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:37:12 --> Helper loaded: form_helper
INFO - 2020-02-11 11:37:12 --> Form Validation Class Initialized
INFO - 2020-02-11 11:37:12 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-11 11:37:12 --> Final output sent to browser
DEBUG - 2020-02-11 11:37:12 --> Total execution time: 0.3681
INFO - 2020-02-11 11:37:48 --> Config Class Initialized
INFO - 2020-02-11 11:37:48 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:37:48 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:37:48 --> Utf8 Class Initialized
INFO - 2020-02-11 11:37:48 --> URI Class Initialized
INFO - 2020-02-11 11:37:48 --> Router Class Initialized
INFO - 2020-02-11 11:37:48 --> Output Class Initialized
INFO - 2020-02-11 11:37:49 --> Security Class Initialized
DEBUG - 2020-02-11 11:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:37:49 --> Input Class Initialized
INFO - 2020-02-11 11:37:49 --> Language Class Initialized
INFO - 2020-02-11 11:37:49 --> Loader Class Initialized
INFO - 2020-02-11 11:37:49 --> Helper loaded: url_helper
INFO - 2020-02-11 11:37:49 --> Database Driver Class Initialized
DEBUG - 2020-02-11 11:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 11:37:49 --> Controller Class Initialized
INFO - 2020-02-11 11:37:49 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:37:49 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:37:49 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:37:49 --> Helper loaded: form_helper
INFO - 2020-02-11 11:37:49 --> Form Validation Class Initialized
INFO - 2020-02-11 11:37:49 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-11 11:37:49 --> Final output sent to browser
DEBUG - 2020-02-11 11:37:49 --> Total execution time: 0.3697
INFO - 2020-02-11 11:38:20 --> Config Class Initialized
INFO - 2020-02-11 11:38:20 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:38:20 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:38:20 --> Utf8 Class Initialized
INFO - 2020-02-11 11:38:20 --> URI Class Initialized
INFO - 2020-02-11 11:38:20 --> Router Class Initialized
INFO - 2020-02-11 11:38:20 --> Output Class Initialized
INFO - 2020-02-11 11:38:20 --> Security Class Initialized
DEBUG - 2020-02-11 11:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:38:20 --> Input Class Initialized
INFO - 2020-02-11 11:38:20 --> Language Class Initialized
INFO - 2020-02-11 11:38:20 --> Loader Class Initialized
INFO - 2020-02-11 11:38:20 --> Helper loaded: url_helper
INFO - 2020-02-11 11:38:20 --> Database Driver Class Initialized
DEBUG - 2020-02-11 11:38:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 11:38:20 --> Controller Class Initialized
INFO - 2020-02-11 11:38:20 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:38:20 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:38:20 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:38:20 --> Helper loaded: form_helper
INFO - 2020-02-11 11:38:20 --> Form Validation Class Initialized
INFO - 2020-02-11 11:38:20 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-11 11:38:20 --> Final output sent to browser
DEBUG - 2020-02-11 11:38:20 --> Total execution time: 0.3982
INFO - 2020-02-11 11:38:20 --> Config Class Initialized
INFO - 2020-02-11 11:38:20 --> Hooks Class Initialized
INFO - 2020-02-11 11:38:20 --> Config Class Initialized
INFO - 2020-02-11 11:38:20 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:38:20 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:38:20 --> Utf8 Class Initialized
DEBUG - 2020-02-11 11:38:20 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:38:20 --> Utf8 Class Initialized
INFO - 2020-02-11 11:38:20 --> URI Class Initialized
INFO - 2020-02-11 11:38:20 --> Router Class Initialized
INFO - 2020-02-11 11:38:20 --> URI Class Initialized
INFO - 2020-02-11 11:38:20 --> Router Class Initialized
INFO - 2020-02-11 11:38:20 --> Output Class Initialized
INFO - 2020-02-11 11:38:20 --> Security Class Initialized
INFO - 2020-02-11 11:38:20 --> Output Class Initialized
INFO - 2020-02-11 11:38:20 --> Security Class Initialized
DEBUG - 2020-02-11 11:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:38:20 --> Input Class Initialized
DEBUG - 2020-02-11 11:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:38:20 --> Input Class Initialized
INFO - 2020-02-11 11:38:20 --> Language Class Initialized
INFO - 2020-02-11 11:38:20 --> Language Class Initialized
INFO - 2020-02-11 11:38:20 --> Loader Class Initialized
INFO - 2020-02-11 11:38:20 --> Helper loaded: url_helper
INFO - 2020-02-11 11:38:20 --> Loader Class Initialized
INFO - 2020-02-11 11:38:20 --> Helper loaded: url_helper
INFO - 2020-02-11 11:38:20 --> Database Driver Class Initialized
DEBUG - 2020-02-11 11:38:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:38:20 --> Database Driver Class Initialized
INFO - 2020-02-11 11:38:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-11 11:38:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:38:20 --> Controller Class Initialized
INFO - 2020-02-11 11:38:20 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:38:20 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:38:20 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:38:20 --> Helper loaded: form_helper
INFO - 2020-02-11 11:38:20 --> Form Validation Class Initialized
ERROR - 2020-02-11 11:38:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-11 11:38:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-11 11:38:21 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-11 11:38:21 --> Final output sent to browser
DEBUG - 2020-02-11 11:38:21 --> Total execution time: 0.5257
INFO - 2020-02-11 11:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 11:38:21 --> Controller Class Initialized
INFO - 2020-02-11 11:38:21 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:38:21 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:38:21 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:38:21 --> Helper loaded: form_helper
INFO - 2020-02-11 11:38:21 --> Form Validation Class Initialized
ERROR - 2020-02-11 11:38:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-11 11:38:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-11 11:38:21 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-11 11:38:21 --> Final output sent to browser
DEBUG - 2020-02-11 11:38:21 --> Total execution time: 0.6608
INFO - 2020-02-11 11:38:24 --> Config Class Initialized
INFO - 2020-02-11 11:38:24 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:38:24 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:38:24 --> Utf8 Class Initialized
INFO - 2020-02-11 11:38:24 --> URI Class Initialized
INFO - 2020-02-11 11:38:24 --> Router Class Initialized
INFO - 2020-02-11 11:38:24 --> Output Class Initialized
INFO - 2020-02-11 11:38:24 --> Security Class Initialized
DEBUG - 2020-02-11 11:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:38:25 --> Input Class Initialized
INFO - 2020-02-11 11:38:25 --> Language Class Initialized
INFO - 2020-02-11 11:38:25 --> Loader Class Initialized
INFO - 2020-02-11 11:38:25 --> Helper loaded: url_helper
INFO - 2020-02-11 11:38:25 --> Database Driver Class Initialized
DEBUG - 2020-02-11 11:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 11:38:25 --> Controller Class Initialized
INFO - 2020-02-11 11:38:25 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:38:25 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:38:25 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:38:25 --> Helper loaded: form_helper
INFO - 2020-02-11 11:38:25 --> Form Validation Class Initialized
INFO - 2020-02-11 11:38:25 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-11 11:38:25 --> Final output sent to browser
DEBUG - 2020-02-11 11:38:25 --> Total execution time: 0.4072
INFO - 2020-02-11 11:46:36 --> Config Class Initialized
INFO - 2020-02-11 11:46:37 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:46:37 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:46:37 --> Utf8 Class Initialized
INFO - 2020-02-11 11:46:37 --> URI Class Initialized
INFO - 2020-02-11 11:46:37 --> Router Class Initialized
INFO - 2020-02-11 11:46:37 --> Output Class Initialized
INFO - 2020-02-11 11:46:37 --> Security Class Initialized
DEBUG - 2020-02-11 11:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:46:37 --> Input Class Initialized
INFO - 2020-02-11 11:46:37 --> Language Class Initialized
INFO - 2020-02-11 11:46:37 --> Loader Class Initialized
INFO - 2020-02-11 11:46:37 --> Helper loaded: url_helper
INFO - 2020-02-11 11:46:37 --> Database Driver Class Initialized
DEBUG - 2020-02-11 11:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 11:46:37 --> Controller Class Initialized
INFO - 2020-02-11 11:46:37 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:46:37 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:46:37 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:46:37 --> Helper loaded: form_helper
INFO - 2020-02-11 11:46:37 --> Form Validation Class Initialized
INFO - 2020-02-11 11:46:37 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-11 11:46:37 --> Final output sent to browser
DEBUG - 2020-02-11 11:46:37 --> Total execution time: 0.5248
INFO - 2020-02-11 11:46:37 --> Config Class Initialized
INFO - 2020-02-11 11:46:37 --> Config Class Initialized
INFO - 2020-02-11 11:46:37 --> Hooks Class Initialized
INFO - 2020-02-11 11:46:37 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:46:37 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:46:37 --> Utf8 Class Initialized
DEBUG - 2020-02-11 11:46:37 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:46:37 --> Utf8 Class Initialized
INFO - 2020-02-11 11:46:37 --> URI Class Initialized
INFO - 2020-02-11 11:46:37 --> URI Class Initialized
INFO - 2020-02-11 11:46:37 --> Router Class Initialized
INFO - 2020-02-11 11:46:37 --> Router Class Initialized
INFO - 2020-02-11 11:46:37 --> Output Class Initialized
INFO - 2020-02-11 11:46:37 --> Security Class Initialized
INFO - 2020-02-11 11:46:37 --> Output Class Initialized
DEBUG - 2020-02-11 11:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:46:37 --> Security Class Initialized
INFO - 2020-02-11 11:46:37 --> Input Class Initialized
DEBUG - 2020-02-11 11:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:46:37 --> Language Class Initialized
INFO - 2020-02-11 11:46:37 --> Input Class Initialized
INFO - 2020-02-11 11:46:37 --> Loader Class Initialized
INFO - 2020-02-11 11:46:37 --> Language Class Initialized
INFO - 2020-02-11 11:46:37 --> Helper loaded: url_helper
INFO - 2020-02-11 11:46:37 --> Loader Class Initialized
INFO - 2020-02-11 11:46:38 --> Database Driver Class Initialized
INFO - 2020-02-11 11:46:38 --> Helper loaded: url_helper
DEBUG - 2020-02-11 11:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 11:46:38 --> Database Driver Class Initialized
INFO - 2020-02-11 11:46:38 --> Controller Class Initialized
DEBUG - 2020-02-11 11:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:46:38 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:46:38 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:46:38 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:46:38 --> Helper loaded: form_helper
INFO - 2020-02-11 11:46:38 --> Form Validation Class Initialized
ERROR - 2020-02-11 11:46:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-11 11:46:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-11 11:46:38 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-11 11:46:38 --> Final output sent to browser
DEBUG - 2020-02-11 11:46:38 --> Total execution time: 0.5724
INFO - 2020-02-11 11:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 11:46:38 --> Controller Class Initialized
INFO - 2020-02-11 11:46:38 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:46:38 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:46:38 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:46:38 --> Helper loaded: form_helper
INFO - 2020-02-11 11:46:38 --> Form Validation Class Initialized
ERROR - 2020-02-11 11:46:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-11 11:46:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-11 11:46:38 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-11 11:46:38 --> Final output sent to browser
DEBUG - 2020-02-11 11:46:38 --> Total execution time: 0.7044
INFO - 2020-02-11 11:48:11 --> Config Class Initialized
INFO - 2020-02-11 11:48:11 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:48:11 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:48:11 --> Utf8 Class Initialized
INFO - 2020-02-11 11:48:11 --> URI Class Initialized
INFO - 2020-02-11 11:48:11 --> Router Class Initialized
INFO - 2020-02-11 11:48:11 --> Output Class Initialized
INFO - 2020-02-11 11:48:11 --> Security Class Initialized
DEBUG - 2020-02-11 11:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:48:11 --> Input Class Initialized
INFO - 2020-02-11 11:48:11 --> Language Class Initialized
INFO - 2020-02-11 11:48:11 --> Loader Class Initialized
INFO - 2020-02-11 11:48:11 --> Helper loaded: url_helper
INFO - 2020-02-11 11:48:11 --> Database Driver Class Initialized
DEBUG - 2020-02-11 11:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 11:48:11 --> Controller Class Initialized
INFO - 2020-02-11 11:48:11 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:48:11 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:48:11 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:48:11 --> Helper loaded: form_helper
INFO - 2020-02-11 11:48:11 --> Form Validation Class Initialized
INFO - 2020-02-11 11:48:11 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-11 11:48:11 --> Final output sent to browser
DEBUG - 2020-02-11 11:48:11 --> Total execution time: 0.4540
INFO - 2020-02-11 11:48:11 --> Config Class Initialized
INFO - 2020-02-11 11:48:11 --> Config Class Initialized
INFO - 2020-02-11 11:48:11 --> Config Class Initialized
INFO - 2020-02-11 11:48:11 --> Hooks Class Initialized
INFO - 2020-02-11 11:48:11 --> Hooks Class Initialized
INFO - 2020-02-11 11:48:11 --> Hooks Class Initialized
INFO - 2020-02-11 11:48:11 --> Config Class Initialized
INFO - 2020-02-11 11:48:11 --> Config Class Initialized
INFO - 2020-02-11 11:48:11 --> Config Class Initialized
INFO - 2020-02-11 11:48:11 --> Hooks Class Initialized
INFO - 2020-02-11 11:48:11 --> Hooks Class Initialized
INFO - 2020-02-11 11:48:11 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:48:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 11:48:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 11:48:11 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:48:11 --> Utf8 Class Initialized
DEBUG - 2020-02-11 11:48:12 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:48:12 --> Utf8 Class Initialized
INFO - 2020-02-11 11:48:12 --> Utf8 Class Initialized
INFO - 2020-02-11 11:48:12 --> URI Class Initialized
INFO - 2020-02-11 11:48:12 --> Utf8 Class Initialized
DEBUG - 2020-02-11 11:48:12 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 11:48:12 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:48:12 --> Utf8 Class Initialized
INFO - 2020-02-11 11:48:12 --> Utf8 Class Initialized
INFO - 2020-02-11 11:48:12 --> URI Class Initialized
INFO - 2020-02-11 11:48:12 --> URI Class Initialized
INFO - 2020-02-11 11:48:12 --> Router Class Initialized
INFO - 2020-02-11 11:48:12 --> URI Class Initialized
INFO - 2020-02-11 11:48:12 --> Router Class Initialized
INFO - 2020-02-11 11:48:12 --> Router Class Initialized
INFO - 2020-02-11 11:48:12 --> Router Class Initialized
INFO - 2020-02-11 11:48:12 --> Output Class Initialized
INFO - 2020-02-11 11:48:12 --> URI Class Initialized
INFO - 2020-02-11 11:48:12 --> URI Class Initialized
INFO - 2020-02-11 11:48:12 --> Router Class Initialized
INFO - 2020-02-11 11:48:12 --> Router Class Initialized
INFO - 2020-02-11 11:48:12 --> Security Class Initialized
INFO - 2020-02-11 11:48:12 --> Output Class Initialized
INFO - 2020-02-11 11:48:12 --> Output Class Initialized
INFO - 2020-02-11 11:48:12 --> Output Class Initialized
DEBUG - 2020-02-11 11:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:48:12 --> Output Class Initialized
INFO - 2020-02-11 11:48:12 --> Security Class Initialized
INFO - 2020-02-11 11:48:12 --> Security Class Initialized
INFO - 2020-02-11 11:48:12 --> Security Class Initialized
INFO - 2020-02-11 11:48:12 --> Output Class Initialized
INFO - 2020-02-11 11:48:12 --> Input Class Initialized
DEBUG - 2020-02-11 11:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 11:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 11:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:48:12 --> Security Class Initialized
INFO - 2020-02-11 11:48:12 --> Security Class Initialized
INFO - 2020-02-11 11:48:12 --> Input Class Initialized
INFO - 2020-02-11 11:48:12 --> Input Class Initialized
INFO - 2020-02-11 11:48:12 --> Input Class Initialized
INFO - 2020-02-11 11:48:12 --> Language Class Initialized
DEBUG - 2020-02-11 11:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 11:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:48:12 --> Input Class Initialized
INFO - 2020-02-11 11:48:12 --> Language Class Initialized
INFO - 2020-02-11 11:48:12 --> Language Class Initialized
INFO - 2020-02-11 11:48:12 --> Language Class Initialized
INFO - 2020-02-11 11:48:12 --> Input Class Initialized
ERROR - 2020-02-11 11:48:12 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-11 11:48:12 --> Language Class Initialized
ERROR - 2020-02-11 11:48:12 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-11 11:48:12 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-11 11:48:12 --> Language Class Initialized
INFO - 2020-02-11 11:48:12 --> Loader Class Initialized
ERROR - 2020-02-11 11:48:12 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-11 11:48:12 --> Helper loaded: url_helper
INFO - 2020-02-11 11:48:12 --> Loader Class Initialized
INFO - 2020-02-11 11:48:12 --> Helper loaded: url_helper
INFO - 2020-02-11 11:48:12 --> Database Driver Class Initialized
INFO - 2020-02-11 11:48:12 --> Config Class Initialized
INFO - 2020-02-11 11:48:12 --> Config Class Initialized
INFO - 2020-02-11 11:48:12 --> Hooks Class Initialized
INFO - 2020-02-11 11:48:12 --> Hooks Class Initialized
INFO - 2020-02-11 11:48:12 --> Config Class Initialized
INFO - 2020-02-11 11:48:12 --> Config Class Initialized
DEBUG - 2020-02-11 11:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:48:12 --> Database Driver Class Initialized
INFO - 2020-02-11 11:48:12 --> Hooks Class Initialized
INFO - 2020-02-11 11:48:12 --> Hooks Class Initialized
INFO - 2020-02-11 11:48:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-11 11:48:12 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 11:48:12 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 11:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 11:48:12 --> Controller Class Initialized
INFO - 2020-02-11 11:48:12 --> Utf8 Class Initialized
INFO - 2020-02-11 11:48:12 --> Utf8 Class Initialized
DEBUG - 2020-02-11 11:48:12 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 11:48:12 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:48:12 --> Utf8 Class Initialized
INFO - 2020-02-11 11:48:12 --> Utf8 Class Initialized
INFO - 2020-02-11 11:48:12 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:48:12 --> URI Class Initialized
INFO - 2020-02-11 11:48:12 --> URI Class Initialized
INFO - 2020-02-11 11:48:12 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:48:12 --> URI Class Initialized
INFO - 2020-02-11 11:48:12 --> URI Class Initialized
INFO - 2020-02-11 11:48:12 --> Router Class Initialized
INFO - 2020-02-11 11:48:12 --> Router Class Initialized
INFO - 2020-02-11 11:48:12 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:48:12 --> Router Class Initialized
INFO - 2020-02-11 11:48:12 --> Output Class Initialized
INFO - 2020-02-11 11:48:12 --> Output Class Initialized
INFO - 2020-02-11 11:48:12 --> Router Class Initialized
INFO - 2020-02-11 11:48:12 --> Security Class Initialized
INFO - 2020-02-11 11:48:12 --> Output Class Initialized
INFO - 2020-02-11 11:48:12 --> Output Class Initialized
INFO - 2020-02-11 11:48:12 --> Helper loaded: form_helper
INFO - 2020-02-11 11:48:12 --> Security Class Initialized
INFO - 2020-02-11 11:48:12 --> Form Validation Class Initialized
DEBUG - 2020-02-11 11:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:48:12 --> Security Class Initialized
INFO - 2020-02-11 11:48:12 --> Security Class Initialized
DEBUG - 2020-02-11 11:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:48:12 --> Input Class Initialized
INFO - 2020-02-11 11:48:12 --> Input Class Initialized
DEBUG - 2020-02-11 11:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 11:48:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-11 11:48:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-11 11:48:12 --> Input Class Initialized
INFO - 2020-02-11 11:48:12 --> Language Class Initialized
INFO - 2020-02-11 11:48:12 --> Input Class Initialized
INFO - 2020-02-11 11:48:12 --> Language Class Initialized
ERROR - 2020-02-11 11:48:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-11 11:48:12 --> Language Class Initialized
INFO - 2020-02-11 11:48:12 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-11 11:48:12 --> Language Class Initialized
ERROR - 2020-02-11 11:48:12 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-11 11:48:12 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-11 11:48:12 --> Final output sent to browser
ERROR - 2020-02-11 11:48:12 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-11 11:48:12 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-11 11:48:12 --> Config Class Initialized
INFO - 2020-02-11 11:48:12 --> Config Class Initialized
DEBUG - 2020-02-11 11:48:12 --> Total execution time: 0.5175
INFO - 2020-02-11 11:48:12 --> Hooks Class Initialized
INFO - 2020-02-11 11:48:12 --> Hooks Class Initialized
INFO - 2020-02-11 11:48:12 --> Config Class Initialized
INFO - 2020-02-11 11:48:12 --> Config Class Initialized
INFO - 2020-02-11 11:48:12 --> Hooks Class Initialized
INFO - 2020-02-11 11:48:12 --> Hooks Class Initialized
INFO - 2020-02-11 11:48:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-11 11:48:12 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 11:48:12 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:48:12 --> Controller Class Initialized
INFO - 2020-02-11 11:48:12 --> Utf8 Class Initialized
INFO - 2020-02-11 11:48:12 --> Utf8 Class Initialized
DEBUG - 2020-02-11 11:48:12 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 11:48:12 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:48:12 --> Utf8 Class Initialized
INFO - 2020-02-11 11:48:12 --> Utf8 Class Initialized
INFO - 2020-02-11 11:48:12 --> URI Class Initialized
INFO - 2020-02-11 11:48:12 --> URI Class Initialized
INFO - 2020-02-11 11:48:12 --> Model "M_tiket" initialized
INFO - 2020-02-11 11:48:12 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 11:48:12 --> URI Class Initialized
INFO - 2020-02-11 11:48:12 --> URI Class Initialized
INFO - 2020-02-11 11:48:12 --> Router Class Initialized
INFO - 2020-02-11 11:48:12 --> Router Class Initialized
INFO - 2020-02-11 11:48:12 --> Model "M_pesan" initialized
INFO - 2020-02-11 11:48:12 --> Router Class Initialized
INFO - 2020-02-11 11:48:12 --> Output Class Initialized
INFO - 2020-02-11 11:48:12 --> Output Class Initialized
INFO - 2020-02-11 11:48:12 --> Router Class Initialized
INFO - 2020-02-11 11:48:12 --> Output Class Initialized
INFO - 2020-02-11 11:48:12 --> Security Class Initialized
INFO - 2020-02-11 11:48:12 --> Output Class Initialized
INFO - 2020-02-11 11:48:12 --> Security Class Initialized
INFO - 2020-02-11 11:48:12 --> Helper loaded: form_helper
INFO - 2020-02-11 11:48:12 --> Form Validation Class Initialized
DEBUG - 2020-02-11 11:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:48:12 --> Security Class Initialized
DEBUG - 2020-02-11 11:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:48:12 --> Security Class Initialized
INFO - 2020-02-11 11:48:12 --> Input Class Initialized
INFO - 2020-02-11 11:48:12 --> Input Class Initialized
DEBUG - 2020-02-11 11:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 11:48:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-11 11:48:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-11 11:48:12 --> Input Class Initialized
INFO - 2020-02-11 11:48:12 --> Input Class Initialized
INFO - 2020-02-11 11:48:12 --> Language Class Initialized
ERROR - 2020-02-11 11:48:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-11 11:48:12 --> Language Class Initialized
INFO - 2020-02-11 11:48:12 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-11 11:48:12 --> Language Class Initialized
INFO - 2020-02-11 11:48:12 --> Language Class Initialized
ERROR - 2020-02-11 11:48:12 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-11 11:48:12 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-11 11:48:12 --> Final output sent to browser
ERROR - 2020-02-11 11:48:12 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-11 11:48:12 --> 404 Page Not Found: Bower_components/jquery-i18next
DEBUG - 2020-02-11 11:48:12 --> Total execution time: 0.7302
INFO - 2020-02-11 11:48:12 --> Config Class Initialized
INFO - 2020-02-11 11:48:12 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:48:12 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:48:12 --> Utf8 Class Initialized
INFO - 2020-02-11 11:48:12 --> URI Class Initialized
INFO - 2020-02-11 11:48:12 --> Router Class Initialized
INFO - 2020-02-11 11:48:12 --> Output Class Initialized
INFO - 2020-02-11 11:48:12 --> Security Class Initialized
DEBUG - 2020-02-11 11:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:48:12 --> Input Class Initialized
INFO - 2020-02-11 11:48:12 --> Language Class Initialized
ERROR - 2020-02-11 11:48:12 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-11 11:48:12 --> Config Class Initialized
INFO - 2020-02-11 11:48:12 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:48:12 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:48:12 --> Utf8 Class Initialized
INFO - 2020-02-11 11:48:12 --> URI Class Initialized
INFO - 2020-02-11 11:48:12 --> Router Class Initialized
INFO - 2020-02-11 11:48:13 --> Output Class Initialized
INFO - 2020-02-11 11:48:13 --> Security Class Initialized
DEBUG - 2020-02-11 11:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:48:13 --> Input Class Initialized
INFO - 2020-02-11 11:48:13 --> Language Class Initialized
ERROR - 2020-02-11 11:48:13 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-11 11:48:13 --> Config Class Initialized
INFO - 2020-02-11 11:48:13 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:48:13 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:48:13 --> Utf8 Class Initialized
INFO - 2020-02-11 11:48:13 --> URI Class Initialized
INFO - 2020-02-11 11:48:13 --> Router Class Initialized
INFO - 2020-02-11 11:48:13 --> Output Class Initialized
INFO - 2020-02-11 11:48:13 --> Security Class Initialized
DEBUG - 2020-02-11 11:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:48:13 --> Input Class Initialized
INFO - 2020-02-11 11:48:13 --> Language Class Initialized
ERROR - 2020-02-11 11:48:13 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-11 11:48:13 --> Config Class Initialized
INFO - 2020-02-11 11:48:13 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:48:13 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:48:13 --> Utf8 Class Initialized
INFO - 2020-02-11 11:48:13 --> URI Class Initialized
INFO - 2020-02-11 11:48:13 --> Router Class Initialized
INFO - 2020-02-11 11:48:13 --> Output Class Initialized
INFO - 2020-02-11 11:48:13 --> Security Class Initialized
DEBUG - 2020-02-11 11:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:48:13 --> Input Class Initialized
INFO - 2020-02-11 11:48:13 --> Language Class Initialized
ERROR - 2020-02-11 11:48:13 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-11 11:48:13 --> Config Class Initialized
INFO - 2020-02-11 11:48:13 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:48:13 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:48:13 --> Utf8 Class Initialized
INFO - 2020-02-11 11:48:13 --> URI Class Initialized
INFO - 2020-02-11 11:48:13 --> Router Class Initialized
INFO - 2020-02-11 11:48:13 --> Output Class Initialized
INFO - 2020-02-11 11:48:13 --> Security Class Initialized
DEBUG - 2020-02-11 11:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:48:13 --> Input Class Initialized
INFO - 2020-02-11 11:48:13 --> Language Class Initialized
ERROR - 2020-02-11 11:48:13 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-11 11:48:13 --> Config Class Initialized
INFO - 2020-02-11 11:48:13 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:48:13 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:48:13 --> Utf8 Class Initialized
INFO - 2020-02-11 11:48:13 --> URI Class Initialized
INFO - 2020-02-11 11:48:13 --> Router Class Initialized
INFO - 2020-02-11 11:48:13 --> Output Class Initialized
INFO - 2020-02-11 11:48:13 --> Security Class Initialized
DEBUG - 2020-02-11 11:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:48:13 --> Input Class Initialized
INFO - 2020-02-11 11:48:13 --> Language Class Initialized
ERROR - 2020-02-11 11:48:13 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-11 11:48:13 --> Config Class Initialized
INFO - 2020-02-11 11:48:14 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:48:14 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:48:14 --> Utf8 Class Initialized
INFO - 2020-02-11 11:48:14 --> URI Class Initialized
INFO - 2020-02-11 11:48:14 --> Router Class Initialized
INFO - 2020-02-11 11:48:14 --> Output Class Initialized
INFO - 2020-02-11 11:48:14 --> Security Class Initialized
DEBUG - 2020-02-11 11:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:48:14 --> Input Class Initialized
INFO - 2020-02-11 11:48:14 --> Language Class Initialized
ERROR - 2020-02-11 11:48:14 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-11 11:48:14 --> Config Class Initialized
INFO - 2020-02-11 11:48:14 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:48:14 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:48:14 --> Utf8 Class Initialized
INFO - 2020-02-11 11:48:14 --> URI Class Initialized
INFO - 2020-02-11 11:48:14 --> Router Class Initialized
INFO - 2020-02-11 11:48:14 --> Output Class Initialized
INFO - 2020-02-11 11:48:14 --> Security Class Initialized
DEBUG - 2020-02-11 11:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:48:14 --> Input Class Initialized
INFO - 2020-02-11 11:48:14 --> Language Class Initialized
ERROR - 2020-02-11 11:48:14 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-11 11:48:14 --> Config Class Initialized
INFO - 2020-02-11 11:48:14 --> Hooks Class Initialized
DEBUG - 2020-02-11 11:48:14 --> UTF-8 Support Enabled
INFO - 2020-02-11 11:48:14 --> Utf8 Class Initialized
INFO - 2020-02-11 11:48:14 --> URI Class Initialized
INFO - 2020-02-11 11:48:14 --> Router Class Initialized
INFO - 2020-02-11 11:48:14 --> Output Class Initialized
INFO - 2020-02-11 11:48:14 --> Security Class Initialized
DEBUG - 2020-02-11 11:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 11:48:14 --> Input Class Initialized
INFO - 2020-02-11 11:48:14 --> Language Class Initialized
ERROR - 2020-02-11 11:48:14 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-11 14:12:18 --> Config Class Initialized
INFO - 2020-02-11 14:12:18 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:12:19 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:12:19 --> Utf8 Class Initialized
INFO - 2020-02-11 14:12:19 --> URI Class Initialized
INFO - 2020-02-11 14:12:19 --> Router Class Initialized
INFO - 2020-02-11 14:12:19 --> Output Class Initialized
INFO - 2020-02-11 14:12:19 --> Security Class Initialized
DEBUG - 2020-02-11 14:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:12:19 --> Input Class Initialized
INFO - 2020-02-11 14:12:19 --> Language Class Initialized
INFO - 2020-02-11 14:12:19 --> Loader Class Initialized
INFO - 2020-02-11 14:12:19 --> Helper loaded: url_helper
INFO - 2020-02-11 14:12:19 --> Database Driver Class Initialized
DEBUG - 2020-02-11 14:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 14:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 14:12:20 --> Controller Class Initialized
INFO - 2020-02-11 14:12:20 --> Model "M_tiket" initialized
INFO - 2020-02-11 14:12:20 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 14:12:20 --> Model "M_pesan" initialized
INFO - 2020-02-11 14:12:20 --> Helper loaded: form_helper
INFO - 2020-02-11 14:12:20 --> Form Validation Class Initialized
INFO - 2020-02-11 14:12:21 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-11 14:12:21 --> Final output sent to browser
DEBUG - 2020-02-11 14:12:21 --> Total execution time: 2.8902
INFO - 2020-02-11 14:12:21 --> Config Class Initialized
INFO - 2020-02-11 14:12:21 --> Config Class Initialized
INFO - 2020-02-11 14:12:21 --> Hooks Class Initialized
INFO - 2020-02-11 14:12:21 --> Config Class Initialized
INFO - 2020-02-11 14:12:21 --> Config Class Initialized
INFO - 2020-02-11 14:12:21 --> Config Class Initialized
INFO - 2020-02-11 14:12:21 --> Hooks Class Initialized
INFO - 2020-02-11 14:12:21 --> Hooks Class Initialized
INFO - 2020-02-11 14:12:21 --> Hooks Class Initialized
INFO - 2020-02-11 14:12:21 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:12:21 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:12:21 --> Config Class Initialized
INFO - 2020-02-11 14:12:21 --> Hooks Class Initialized
INFO - 2020-02-11 14:12:21 --> Utf8 Class Initialized
DEBUG - 2020-02-11 14:12:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:12:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:12:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:12:21 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:12:21 --> Utf8 Class Initialized
INFO - 2020-02-11 14:12:21 --> Utf8 Class Initialized
INFO - 2020-02-11 14:12:21 --> Utf8 Class Initialized
INFO - 2020-02-11 14:12:21 --> Utf8 Class Initialized
INFO - 2020-02-11 14:12:21 --> URI Class Initialized
DEBUG - 2020-02-11 14:12:21 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:12:21 --> URI Class Initialized
INFO - 2020-02-11 14:12:21 --> URI Class Initialized
INFO - 2020-02-11 14:12:21 --> URI Class Initialized
INFO - 2020-02-11 14:12:21 --> Router Class Initialized
INFO - 2020-02-11 14:12:21 --> Utf8 Class Initialized
INFO - 2020-02-11 14:12:21 --> URI Class Initialized
INFO - 2020-02-11 14:12:21 --> URI Class Initialized
INFO - 2020-02-11 14:12:21 --> Router Class Initialized
INFO - 2020-02-11 14:12:21 --> Output Class Initialized
INFO - 2020-02-11 14:12:21 --> Router Class Initialized
INFO - 2020-02-11 14:12:21 --> Router Class Initialized
INFO - 2020-02-11 14:12:21 --> Router Class Initialized
INFO - 2020-02-11 14:12:21 --> Output Class Initialized
INFO - 2020-02-11 14:12:21 --> Router Class Initialized
INFO - 2020-02-11 14:12:21 --> Security Class Initialized
INFO - 2020-02-11 14:12:21 --> Output Class Initialized
INFO - 2020-02-11 14:12:21 --> Output Class Initialized
INFO - 2020-02-11 14:12:21 --> Output Class Initialized
DEBUG - 2020-02-11 14:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:12:21 --> Security Class Initialized
INFO - 2020-02-11 14:12:21 --> Security Class Initialized
INFO - 2020-02-11 14:12:21 --> Output Class Initialized
INFO - 2020-02-11 14:12:21 --> Security Class Initialized
INFO - 2020-02-11 14:12:21 --> Security Class Initialized
INFO - 2020-02-11 14:12:21 --> Input Class Initialized
DEBUG - 2020-02-11 14:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 14:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:12:21 --> Security Class Initialized
DEBUG - 2020-02-11 14:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 14:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:12:21 --> Input Class Initialized
INFO - 2020-02-11 14:12:21 --> Input Class Initialized
INFO - 2020-02-11 14:12:21 --> Input Class Initialized
INFO - 2020-02-11 14:12:21 --> Input Class Initialized
INFO - 2020-02-11 14:12:21 --> Language Class Initialized
DEBUG - 2020-02-11 14:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:12:21 --> Input Class Initialized
INFO - 2020-02-11 14:12:21 --> Language Class Initialized
INFO - 2020-02-11 14:12:21 --> Language Class Initialized
INFO - 2020-02-11 14:12:21 --> Language Class Initialized
INFO - 2020-02-11 14:12:21 --> Language Class Initialized
ERROR - 2020-02-11 14:12:21 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-11 14:12:21 --> Language Class Initialized
ERROR - 2020-02-11 14:12:21 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-11 14:12:21 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-11 14:12:21 --> Loader Class Initialized
INFO - 2020-02-11 14:12:21 --> Loader Class Initialized
ERROR - 2020-02-11 14:12:21 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-11 14:12:21 --> Helper loaded: url_helper
INFO - 2020-02-11 14:12:21 --> Helper loaded: url_helper
INFO - 2020-02-11 14:12:21 --> Config Class Initialized
INFO - 2020-02-11 14:12:21 --> Config Class Initialized
INFO - 2020-02-11 14:12:21 --> Config Class Initialized
INFO - 2020-02-11 14:12:21 --> Database Driver Class Initialized
INFO - 2020-02-11 14:12:21 --> Database Driver Class Initialized
INFO - 2020-02-11 14:12:21 --> Hooks Class Initialized
INFO - 2020-02-11 14:12:21 --> Hooks Class Initialized
INFO - 2020-02-11 14:12:21 --> Hooks Class Initialized
INFO - 2020-02-11 14:12:21 --> Config Class Initialized
DEBUG - 2020-02-11 14:12:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-11 14:12:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 14:12:21 --> Hooks Class Initialized
INFO - 2020-02-11 14:12:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-11 14:12:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:12:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:12:21 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:12:21 --> Controller Class Initialized
INFO - 2020-02-11 14:12:21 --> Utf8 Class Initialized
INFO - 2020-02-11 14:12:21 --> Utf8 Class Initialized
INFO - 2020-02-11 14:12:21 --> Utf8 Class Initialized
DEBUG - 2020-02-11 14:12:21 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:12:21 --> Utf8 Class Initialized
INFO - 2020-02-11 14:12:21 --> URI Class Initialized
INFO - 2020-02-11 14:12:21 --> Model "M_tiket" initialized
INFO - 2020-02-11 14:12:21 --> URI Class Initialized
INFO - 2020-02-11 14:12:21 --> URI Class Initialized
INFO - 2020-02-11 14:12:21 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 14:12:21 --> Router Class Initialized
INFO - 2020-02-11 14:12:21 --> Router Class Initialized
INFO - 2020-02-11 14:12:21 --> Router Class Initialized
INFO - 2020-02-11 14:12:21 --> URI Class Initialized
INFO - 2020-02-11 14:12:21 --> Model "M_pesan" initialized
INFO - 2020-02-11 14:12:21 --> Router Class Initialized
INFO - 2020-02-11 14:12:21 --> Output Class Initialized
INFO - 2020-02-11 14:12:21 --> Output Class Initialized
INFO - 2020-02-11 14:12:21 --> Output Class Initialized
INFO - 2020-02-11 14:12:21 --> Security Class Initialized
INFO - 2020-02-11 14:12:21 --> Security Class Initialized
INFO - 2020-02-11 14:12:21 --> Security Class Initialized
INFO - 2020-02-11 14:12:21 --> Output Class Initialized
INFO - 2020-02-11 14:12:21 --> Helper loaded: form_helper
INFO - 2020-02-11 14:12:21 --> Form Validation Class Initialized
DEBUG - 2020-02-11 14:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 14:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 14:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:12:21 --> Security Class Initialized
INFO - 2020-02-11 14:12:21 --> Input Class Initialized
INFO - 2020-02-11 14:12:21 --> Input Class Initialized
INFO - 2020-02-11 14:12:21 --> Input Class Initialized
DEBUG - 2020-02-11 14:12:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-11 14:12:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-11 14:12:21 --> Input Class Initialized
INFO - 2020-02-11 14:12:21 --> Language Class Initialized
INFO - 2020-02-11 14:12:21 --> Language Class Initialized
INFO - 2020-02-11 14:12:21 --> Language Class Initialized
INFO - 2020-02-11 14:12:21 --> Language Class Initialized
ERROR - 2020-02-11 14:12:21 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-11 14:12:21 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-11 14:12:21 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-11 14:12:21 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-11 14:12:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-11 14:12:22 --> Config Class Initialized
INFO - 2020-02-11 14:12:22 --> Config Class Initialized
INFO - 2020-02-11 14:12:22 --> Config Class Initialized
INFO - 2020-02-11 14:12:22 --> Hooks Class Initialized
INFO - 2020-02-11 14:12:22 --> Hooks Class Initialized
INFO - 2020-02-11 14:12:22 --> Hooks Class Initialized
INFO - 2020-02-11 14:12:22 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-11 14:12:22 --> Config Class Initialized
INFO - 2020-02-11 14:12:22 --> Hooks Class Initialized
INFO - 2020-02-11 14:12:22 --> Final output sent to browser
DEBUG - 2020-02-11 14:12:22 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:12:22 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:12:22 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:12:22 --> Total execution time: 0.7410
INFO - 2020-02-11 14:12:22 --> Utf8 Class Initialized
INFO - 2020-02-11 14:12:22 --> Utf8 Class Initialized
INFO - 2020-02-11 14:12:22 --> Utf8 Class Initialized
DEBUG - 2020-02-11 14:12:22 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 14:12:22 --> URI Class Initialized
INFO - 2020-02-11 14:12:22 --> URI Class Initialized
INFO - 2020-02-11 14:12:22 --> URI Class Initialized
INFO - 2020-02-11 14:12:22 --> Utf8 Class Initialized
INFO - 2020-02-11 14:12:22 --> Controller Class Initialized
INFO - 2020-02-11 14:12:22 --> Router Class Initialized
INFO - 2020-02-11 14:12:22 --> Router Class Initialized
INFO - 2020-02-11 14:12:22 --> URI Class Initialized
INFO - 2020-02-11 14:12:22 --> Router Class Initialized
INFO - 2020-02-11 14:12:22 --> Model "M_tiket" initialized
INFO - 2020-02-11 14:12:22 --> Output Class Initialized
INFO - 2020-02-11 14:12:22 --> Output Class Initialized
INFO - 2020-02-11 14:12:22 --> Output Class Initialized
INFO - 2020-02-11 14:12:22 --> Router Class Initialized
INFO - 2020-02-11 14:12:22 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 14:12:22 --> Security Class Initialized
INFO - 2020-02-11 14:12:22 --> Security Class Initialized
INFO - 2020-02-11 14:12:22 --> Output Class Initialized
INFO - 2020-02-11 14:12:22 --> Security Class Initialized
INFO - 2020-02-11 14:12:22 --> Model "M_pesan" initialized
DEBUG - 2020-02-11 14:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:12:22 --> Security Class Initialized
DEBUG - 2020-02-11 14:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 14:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:12:22 --> Input Class Initialized
INFO - 2020-02-11 14:12:22 --> Input Class Initialized
INFO - 2020-02-11 14:12:22 --> Input Class Initialized
DEBUG - 2020-02-11 14:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:12:22 --> Helper loaded: form_helper
INFO - 2020-02-11 14:12:22 --> Input Class Initialized
INFO - 2020-02-11 14:12:22 --> Form Validation Class Initialized
INFO - 2020-02-11 14:12:22 --> Language Class Initialized
INFO - 2020-02-11 14:12:22 --> Language Class Initialized
INFO - 2020-02-11 14:12:22 --> Language Class Initialized
INFO - 2020-02-11 14:12:22 --> Language Class Initialized
ERROR - 2020-02-11 14:12:22 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-11 14:12:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-11 14:12:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-11 14:12:22 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-11 14:12:22 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-11 14:12:22 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-11 14:12:22 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-11 14:12:22 --> Config Class Initialized
INFO - 2020-02-11 14:12:22 --> Final output sent to browser
INFO - 2020-02-11 14:12:22 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:12:22 --> Total execution time: 1.0665
DEBUG - 2020-02-11 14:12:22 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:12:22 --> Utf8 Class Initialized
INFO - 2020-02-11 14:12:22 --> URI Class Initialized
INFO - 2020-02-11 14:12:22 --> Router Class Initialized
INFO - 2020-02-11 14:12:22 --> Output Class Initialized
INFO - 2020-02-11 14:12:22 --> Security Class Initialized
DEBUG - 2020-02-11 14:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:12:22 --> Input Class Initialized
INFO - 2020-02-11 14:12:22 --> Language Class Initialized
ERROR - 2020-02-11 14:12:22 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-11 14:12:22 --> Config Class Initialized
INFO - 2020-02-11 14:12:22 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:12:22 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:12:22 --> Utf8 Class Initialized
INFO - 2020-02-11 14:12:22 --> URI Class Initialized
INFO - 2020-02-11 14:12:22 --> Router Class Initialized
INFO - 2020-02-11 14:12:22 --> Output Class Initialized
INFO - 2020-02-11 14:12:22 --> Security Class Initialized
DEBUG - 2020-02-11 14:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:12:22 --> Input Class Initialized
INFO - 2020-02-11 14:12:22 --> Language Class Initialized
ERROR - 2020-02-11 14:12:22 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-11 14:12:22 --> Config Class Initialized
INFO - 2020-02-11 14:12:22 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:12:23 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:12:23 --> Utf8 Class Initialized
INFO - 2020-02-11 14:12:23 --> URI Class Initialized
INFO - 2020-02-11 14:12:23 --> Router Class Initialized
INFO - 2020-02-11 14:12:23 --> Output Class Initialized
INFO - 2020-02-11 14:12:23 --> Security Class Initialized
DEBUG - 2020-02-11 14:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:12:23 --> Input Class Initialized
INFO - 2020-02-11 14:12:23 --> Language Class Initialized
ERROR - 2020-02-11 14:12:23 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-11 14:12:23 --> Config Class Initialized
INFO - 2020-02-11 14:12:23 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:12:23 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:12:23 --> Utf8 Class Initialized
INFO - 2020-02-11 14:12:23 --> URI Class Initialized
INFO - 2020-02-11 14:12:23 --> Router Class Initialized
INFO - 2020-02-11 14:12:23 --> Output Class Initialized
INFO - 2020-02-11 14:12:23 --> Security Class Initialized
DEBUG - 2020-02-11 14:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:12:23 --> Input Class Initialized
INFO - 2020-02-11 14:12:23 --> Language Class Initialized
ERROR - 2020-02-11 14:12:23 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-11 14:12:23 --> Config Class Initialized
INFO - 2020-02-11 14:12:23 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:12:23 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:12:23 --> Utf8 Class Initialized
INFO - 2020-02-11 14:12:23 --> URI Class Initialized
INFO - 2020-02-11 14:12:23 --> Router Class Initialized
INFO - 2020-02-11 14:12:23 --> Output Class Initialized
INFO - 2020-02-11 14:12:23 --> Security Class Initialized
DEBUG - 2020-02-11 14:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:12:23 --> Input Class Initialized
INFO - 2020-02-11 14:12:23 --> Language Class Initialized
ERROR - 2020-02-11 14:12:23 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-11 14:12:23 --> Config Class Initialized
INFO - 2020-02-11 14:12:23 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:12:23 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:12:23 --> Utf8 Class Initialized
INFO - 2020-02-11 14:12:23 --> URI Class Initialized
INFO - 2020-02-11 14:12:23 --> Router Class Initialized
INFO - 2020-02-11 14:12:23 --> Output Class Initialized
INFO - 2020-02-11 14:12:24 --> Security Class Initialized
DEBUG - 2020-02-11 14:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:12:24 --> Input Class Initialized
INFO - 2020-02-11 14:12:24 --> Language Class Initialized
ERROR - 2020-02-11 14:12:24 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-11 14:12:46 --> Config Class Initialized
INFO - 2020-02-11 14:12:46 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:12:46 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:12:46 --> Utf8 Class Initialized
INFO - 2020-02-11 14:12:46 --> URI Class Initialized
INFO - 2020-02-11 14:12:46 --> Router Class Initialized
INFO - 2020-02-11 14:12:46 --> Output Class Initialized
INFO - 2020-02-11 14:12:46 --> Security Class Initialized
DEBUG - 2020-02-11 14:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:12:46 --> Input Class Initialized
INFO - 2020-02-11 14:12:46 --> Language Class Initialized
INFO - 2020-02-11 14:12:46 --> Loader Class Initialized
INFO - 2020-02-11 14:12:46 --> Helper loaded: url_helper
INFO - 2020-02-11 14:12:46 --> Database Driver Class Initialized
DEBUG - 2020-02-11 14:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 14:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 14:12:47 --> Controller Class Initialized
INFO - 2020-02-11 14:12:47 --> Model "M_tiket" initialized
INFO - 2020-02-11 14:12:47 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 14:12:47 --> Model "M_pesan" initialized
INFO - 2020-02-11 14:12:47 --> Helper loaded: form_helper
INFO - 2020-02-11 14:12:47 --> Form Validation Class Initialized
INFO - 2020-02-11 14:12:47 --> File loaded: C:\xampp\htdocs\roadshow\application\views\pemesanan/konfirm_bayar.php
INFO - 2020-02-11 14:12:47 --> Final output sent to browser
DEBUG - 2020-02-11 14:12:47 --> Total execution time: 0.6529
INFO - 2020-02-11 14:12:51 --> Config Class Initialized
INFO - 2020-02-11 14:12:51 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:12:51 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:12:51 --> Utf8 Class Initialized
INFO - 2020-02-11 14:12:51 --> URI Class Initialized
INFO - 2020-02-11 14:12:51 --> Router Class Initialized
INFO - 2020-02-11 14:12:51 --> Output Class Initialized
INFO - 2020-02-11 14:12:51 --> Security Class Initialized
DEBUG - 2020-02-11 14:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:12:51 --> Input Class Initialized
INFO - 2020-02-11 14:12:51 --> Language Class Initialized
INFO - 2020-02-11 14:12:51 --> Loader Class Initialized
INFO - 2020-02-11 14:12:51 --> Helper loaded: url_helper
INFO - 2020-02-11 14:12:52 --> Database Driver Class Initialized
DEBUG - 2020-02-11 14:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 14:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 14:12:52 --> Controller Class Initialized
INFO - 2020-02-11 14:12:52 --> Model "M_tiket" initialized
INFO - 2020-02-11 14:12:52 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 14:12:52 --> Model "M_pesan" initialized
INFO - 2020-02-11 14:12:52 --> Helper loaded: form_helper
INFO - 2020-02-11 14:12:52 --> Form Validation Class Initialized
INFO - 2020-02-11 14:12:52 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-11 14:12:52 --> Final output sent to browser
DEBUG - 2020-02-11 14:12:52 --> Total execution time: 0.9337
INFO - 2020-02-11 14:12:52 --> Config Class Initialized
INFO - 2020-02-11 14:12:52 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:12:52 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:12:52 --> Utf8 Class Initialized
INFO - 2020-02-11 14:12:52 --> URI Class Initialized
INFO - 2020-02-11 14:12:52 --> Router Class Initialized
INFO - 2020-02-11 14:12:52 --> Output Class Initialized
INFO - 2020-02-11 14:12:52 --> Security Class Initialized
DEBUG - 2020-02-11 14:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:12:52 --> Input Class Initialized
INFO - 2020-02-11 14:12:52 --> Language Class Initialized
ERROR - 2020-02-11 14:12:52 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-11 14:13:02 --> Config Class Initialized
INFO - 2020-02-11 14:13:02 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:13:02 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:13:02 --> Utf8 Class Initialized
INFO - 2020-02-11 14:13:02 --> URI Class Initialized
INFO - 2020-02-11 14:13:02 --> Router Class Initialized
INFO - 2020-02-11 14:13:03 --> Output Class Initialized
INFO - 2020-02-11 14:13:03 --> Security Class Initialized
DEBUG - 2020-02-11 14:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:13:03 --> Input Class Initialized
INFO - 2020-02-11 14:13:03 --> Language Class Initialized
INFO - 2020-02-11 14:13:03 --> Loader Class Initialized
INFO - 2020-02-11 14:13:03 --> Helper loaded: url_helper
INFO - 2020-02-11 14:13:03 --> Database Driver Class Initialized
DEBUG - 2020-02-11 14:13:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 14:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 14:13:03 --> Controller Class Initialized
INFO - 2020-02-11 14:13:03 --> Model "M_tiket" initialized
INFO - 2020-02-11 14:13:03 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 14:13:03 --> Model "M_pesan" initialized
INFO - 2020-02-11 14:13:03 --> Helper loaded: form_helper
INFO - 2020-02-11 14:13:03 --> Form Validation Class Initialized
INFO - 2020-02-11 14:13:03 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-11 14:13:03 --> Final output sent to browser
DEBUG - 2020-02-11 14:13:03 --> Total execution time: 0.8550
INFO - 2020-02-11 14:13:03 --> Config Class Initialized
INFO - 2020-02-11 14:13:03 --> Config Class Initialized
INFO - 2020-02-11 14:13:03 --> Config Class Initialized
INFO - 2020-02-11 14:13:03 --> Config Class Initialized
INFO - 2020-02-11 14:13:03 --> Hooks Class Initialized
INFO - 2020-02-11 14:13:03 --> Hooks Class Initialized
INFO - 2020-02-11 14:13:03 --> Hooks Class Initialized
INFO - 2020-02-11 14:13:03 --> Hooks Class Initialized
INFO - 2020-02-11 14:13:03 --> Config Class Initialized
INFO - 2020-02-11 14:13:03 --> Config Class Initialized
INFO - 2020-02-11 14:13:03 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:13:03 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:13:03 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:13:03 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:13:03 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:13:03 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:13:03 --> Utf8 Class Initialized
INFO - 2020-02-11 14:13:03 --> Utf8 Class Initialized
INFO - 2020-02-11 14:13:03 --> Utf8 Class Initialized
INFO - 2020-02-11 14:13:03 --> Utf8 Class Initialized
DEBUG - 2020-02-11 14:13:03 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:13:03 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:13:03 --> Utf8 Class Initialized
INFO - 2020-02-11 14:13:03 --> Utf8 Class Initialized
INFO - 2020-02-11 14:13:03 --> URI Class Initialized
INFO - 2020-02-11 14:13:03 --> URI Class Initialized
INFO - 2020-02-11 14:13:03 --> URI Class Initialized
INFO - 2020-02-11 14:13:03 --> URI Class Initialized
INFO - 2020-02-11 14:13:03 --> URI Class Initialized
INFO - 2020-02-11 14:13:03 --> URI Class Initialized
INFO - 2020-02-11 14:13:03 --> Router Class Initialized
INFO - 2020-02-11 14:13:03 --> Router Class Initialized
INFO - 2020-02-11 14:13:03 --> Router Class Initialized
INFO - 2020-02-11 14:13:03 --> Router Class Initialized
INFO - 2020-02-11 14:13:03 --> Router Class Initialized
INFO - 2020-02-11 14:13:03 --> Router Class Initialized
INFO - 2020-02-11 14:13:03 --> Output Class Initialized
INFO - 2020-02-11 14:13:03 --> Output Class Initialized
INFO - 2020-02-11 14:13:03 --> Output Class Initialized
INFO - 2020-02-11 14:13:03 --> Output Class Initialized
INFO - 2020-02-11 14:13:03 --> Security Class Initialized
INFO - 2020-02-11 14:13:03 --> Security Class Initialized
INFO - 2020-02-11 14:13:03 --> Output Class Initialized
INFO - 2020-02-11 14:13:03 --> Security Class Initialized
INFO - 2020-02-11 14:13:03 --> Security Class Initialized
INFO - 2020-02-11 14:13:03 --> Output Class Initialized
DEBUG - 2020-02-11 14:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 14:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 14:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:13:03 --> Security Class Initialized
DEBUG - 2020-02-11 14:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:13:03 --> Security Class Initialized
INFO - 2020-02-11 14:13:03 --> Input Class Initialized
INFO - 2020-02-11 14:13:03 --> Input Class Initialized
INFO - 2020-02-11 14:13:03 --> Input Class Initialized
INFO - 2020-02-11 14:13:03 --> Input Class Initialized
DEBUG - 2020-02-11 14:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 14:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:13:03 --> Input Class Initialized
INFO - 2020-02-11 14:13:03 --> Input Class Initialized
INFO - 2020-02-11 14:13:03 --> Language Class Initialized
INFO - 2020-02-11 14:13:03 --> Language Class Initialized
INFO - 2020-02-11 14:13:03 --> Language Class Initialized
INFO - 2020-02-11 14:13:03 --> Language Class Initialized
INFO - 2020-02-11 14:13:03 --> Language Class Initialized
INFO - 2020-02-11 14:13:03 --> Language Class Initialized
ERROR - 2020-02-11 14:13:03 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-11 14:13:03 --> Loader Class Initialized
INFO - 2020-02-11 14:13:03 --> Loader Class Initialized
ERROR - 2020-02-11 14:13:03 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-11 14:13:03 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-11 14:13:03 --> Helper loaded: url_helper
ERROR - 2020-02-11 14:13:03 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-11 14:13:03 --> Helper loaded: url_helper
INFO - 2020-02-11 14:13:04 --> Config Class Initialized
INFO - 2020-02-11 14:13:04 --> Config Class Initialized
INFO - 2020-02-11 14:13:04 --> Hooks Class Initialized
INFO - 2020-02-11 14:13:04 --> Hooks Class Initialized
INFO - 2020-02-11 14:13:04 --> Database Driver Class Initialized
INFO - 2020-02-11 14:13:04 --> Database Driver Class Initialized
INFO - 2020-02-11 14:13:04 --> Config Class Initialized
INFO - 2020-02-11 14:13:04 --> Config Class Initialized
INFO - 2020-02-11 14:13:04 --> Hooks Class Initialized
INFO - 2020-02-11 14:13:04 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:13:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:13:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-11 14:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 14:13:04 --> Utf8 Class Initialized
INFO - 2020-02-11 14:13:04 --> Utf8 Class Initialized
INFO - 2020-02-11 14:13:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-11 14:13:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:13:04 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:13:04 --> Controller Class Initialized
INFO - 2020-02-11 14:13:04 --> Utf8 Class Initialized
INFO - 2020-02-11 14:13:04 --> Utf8 Class Initialized
INFO - 2020-02-11 14:13:04 --> URI Class Initialized
INFO - 2020-02-11 14:13:04 --> URI Class Initialized
INFO - 2020-02-11 14:13:04 --> URI Class Initialized
INFO - 2020-02-11 14:13:04 --> URI Class Initialized
INFO - 2020-02-11 14:13:04 --> Router Class Initialized
INFO - 2020-02-11 14:13:04 --> Router Class Initialized
INFO - 2020-02-11 14:13:04 --> Model "M_tiket" initialized
INFO - 2020-02-11 14:13:04 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 14:13:04 --> Router Class Initialized
INFO - 2020-02-11 14:13:04 --> Output Class Initialized
INFO - 2020-02-11 14:13:04 --> Output Class Initialized
INFO - 2020-02-11 14:13:04 --> Router Class Initialized
INFO - 2020-02-11 14:13:04 --> Model "M_pesan" initialized
INFO - 2020-02-11 14:13:04 --> Security Class Initialized
INFO - 2020-02-11 14:13:04 --> Security Class Initialized
INFO - 2020-02-11 14:13:04 --> Output Class Initialized
INFO - 2020-02-11 14:13:04 --> Output Class Initialized
DEBUG - 2020-02-11 14:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:13:04 --> Security Class Initialized
DEBUG - 2020-02-11 14:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:13:04 --> Security Class Initialized
INFO - 2020-02-11 14:13:04 --> Helper loaded: form_helper
INFO - 2020-02-11 14:13:04 --> Input Class Initialized
INFO - 2020-02-11 14:13:04 --> Form Validation Class Initialized
INFO - 2020-02-11 14:13:04 --> Input Class Initialized
DEBUG - 2020-02-11 14:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 14:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:13:04 --> Input Class Initialized
INFO - 2020-02-11 14:13:04 --> Input Class Initialized
INFO - 2020-02-11 14:13:04 --> Language Class Initialized
INFO - 2020-02-11 14:13:04 --> Language Class Initialized
ERROR - 2020-02-11 14:13:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-11 14:13:04 --> Language Class Initialized
ERROR - 2020-02-11 14:13:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-11 14:13:04 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-11 14:13:04 --> Language Class Initialized
ERROR - 2020-02-11 14:13:04 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-11 14:13:04 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-11 14:13:04 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-11 14:13:04 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-11 14:13:04 --> Config Class Initialized
INFO - 2020-02-11 14:13:04 --> Config Class Initialized
INFO - 2020-02-11 14:13:04 --> Hooks Class Initialized
INFO - 2020-02-11 14:13:04 --> Hooks Class Initialized
INFO - 2020-02-11 14:13:04 --> Final output sent to browser
INFO - 2020-02-11 14:13:04 --> Config Class Initialized
INFO - 2020-02-11 14:13:04 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:13:04 --> Total execution time: 0.7198
DEBUG - 2020-02-11 14:13:04 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:13:04 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:13:04 --> Utf8 Class Initialized
INFO - 2020-02-11 14:13:04 --> Utf8 Class Initialized
INFO - 2020-02-11 14:13:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-11 14:13:04 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:13:04 --> Utf8 Class Initialized
INFO - 2020-02-11 14:13:04 --> Controller Class Initialized
INFO - 2020-02-11 14:13:04 --> URI Class Initialized
INFO - 2020-02-11 14:13:04 --> URI Class Initialized
INFO - 2020-02-11 14:13:04 --> URI Class Initialized
INFO - 2020-02-11 14:13:04 --> Model "M_tiket" initialized
INFO - 2020-02-11 14:13:04 --> Router Class Initialized
INFO - 2020-02-11 14:13:04 --> Router Class Initialized
INFO - 2020-02-11 14:13:04 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 14:13:04 --> Router Class Initialized
INFO - 2020-02-11 14:13:04 --> Output Class Initialized
INFO - 2020-02-11 14:13:04 --> Output Class Initialized
INFO - 2020-02-11 14:13:04 --> Model "M_pesan" initialized
INFO - 2020-02-11 14:13:04 --> Security Class Initialized
INFO - 2020-02-11 14:13:04 --> Output Class Initialized
INFO - 2020-02-11 14:13:04 --> Security Class Initialized
DEBUG - 2020-02-11 14:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 14:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:13:04 --> Security Class Initialized
INFO - 2020-02-11 14:13:04 --> Helper loaded: form_helper
INFO - 2020-02-11 14:13:04 --> Input Class Initialized
INFO - 2020-02-11 14:13:04 --> Form Validation Class Initialized
INFO - 2020-02-11 14:13:04 --> Input Class Initialized
DEBUG - 2020-02-11 14:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:13:04 --> Input Class Initialized
INFO - 2020-02-11 14:13:04 --> Language Class Initialized
INFO - 2020-02-11 14:13:04 --> Language Class Initialized
ERROR - 2020-02-11 14:13:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-11 14:13:04 --> Language Class Initialized
ERROR - 2020-02-11 14:13:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-11 14:13:04 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-11 14:13:04 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-11 14:13:04 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-11 14:13:04 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-11 14:13:04 --> Config Class Initialized
INFO - 2020-02-11 14:13:04 --> Hooks Class Initialized
INFO - 2020-02-11 14:13:04 --> Final output sent to browser
DEBUG - 2020-02-11 14:13:04 --> Total execution time: 1.0017
DEBUG - 2020-02-11 14:13:04 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:13:04 --> Utf8 Class Initialized
INFO - 2020-02-11 14:13:04 --> URI Class Initialized
INFO - 2020-02-11 14:13:04 --> Router Class Initialized
INFO - 2020-02-11 14:13:04 --> Output Class Initialized
INFO - 2020-02-11 14:13:04 --> Security Class Initialized
DEBUG - 2020-02-11 14:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:13:04 --> Input Class Initialized
INFO - 2020-02-11 14:13:04 --> Language Class Initialized
ERROR - 2020-02-11 14:13:04 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-11 14:13:04 --> Config Class Initialized
INFO - 2020-02-11 14:13:04 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:13:05 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:13:05 --> Utf8 Class Initialized
INFO - 2020-02-11 14:13:05 --> URI Class Initialized
INFO - 2020-02-11 14:13:05 --> Router Class Initialized
INFO - 2020-02-11 14:13:05 --> Output Class Initialized
INFO - 2020-02-11 14:13:05 --> Security Class Initialized
DEBUG - 2020-02-11 14:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:13:05 --> Input Class Initialized
INFO - 2020-02-11 14:13:05 --> Language Class Initialized
ERROR - 2020-02-11 14:13:05 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-11 14:13:34 --> Config Class Initialized
INFO - 2020-02-11 14:13:34 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:13:34 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:13:34 --> Utf8 Class Initialized
INFO - 2020-02-11 14:13:34 --> URI Class Initialized
INFO - 2020-02-11 14:13:34 --> Router Class Initialized
INFO - 2020-02-11 14:13:34 --> Output Class Initialized
INFO - 2020-02-11 14:13:34 --> Security Class Initialized
DEBUG - 2020-02-11 14:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:13:34 --> Input Class Initialized
INFO - 2020-02-11 14:13:34 --> Language Class Initialized
INFO - 2020-02-11 14:13:34 --> Loader Class Initialized
INFO - 2020-02-11 14:13:34 --> Helper loaded: url_helper
INFO - 2020-02-11 14:13:34 --> Database Driver Class Initialized
DEBUG - 2020-02-11 14:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 14:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 14:13:34 --> Controller Class Initialized
INFO - 2020-02-11 14:13:34 --> Model "M_tiket" initialized
INFO - 2020-02-11 14:13:34 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 14:13:34 --> Model "M_pesan" initialized
INFO - 2020-02-11 14:13:34 --> Helper loaded: form_helper
INFO - 2020-02-11 14:13:34 --> Form Validation Class Initialized
INFO - 2020-02-11 14:13:34 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-11 14:13:34 --> Final output sent to browser
DEBUG - 2020-02-11 14:13:35 --> Total execution time: 0.9504
INFO - 2020-02-11 14:13:35 --> Config Class Initialized
INFO - 2020-02-11 14:13:35 --> Config Class Initialized
INFO - 2020-02-11 14:13:35 --> Config Class Initialized
INFO - 2020-02-11 14:13:35 --> Config Class Initialized
INFO - 2020-02-11 14:13:35 --> Hooks Class Initialized
INFO - 2020-02-11 14:13:35 --> Hooks Class Initialized
INFO - 2020-02-11 14:13:35 --> Hooks Class Initialized
INFO - 2020-02-11 14:13:35 --> Config Class Initialized
INFO - 2020-02-11 14:13:35 --> Hooks Class Initialized
INFO - 2020-02-11 14:13:35 --> Config Class Initialized
INFO - 2020-02-11 14:13:35 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:13:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:13:35 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:13:35 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:13:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:13:35 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:13:35 --> Utf8 Class Initialized
INFO - 2020-02-11 14:13:35 --> Utf8 Class Initialized
INFO - 2020-02-11 14:13:35 --> Utf8 Class Initialized
INFO - 2020-02-11 14:13:35 --> Utf8 Class Initialized
DEBUG - 2020-02-11 14:13:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:13:35 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:13:35 --> Utf8 Class Initialized
INFO - 2020-02-11 14:13:35 --> Utf8 Class Initialized
INFO - 2020-02-11 14:13:35 --> URI Class Initialized
INFO - 2020-02-11 14:13:35 --> URI Class Initialized
INFO - 2020-02-11 14:13:35 --> URI Class Initialized
INFO - 2020-02-11 14:13:35 --> URI Class Initialized
INFO - 2020-02-11 14:13:35 --> URI Class Initialized
INFO - 2020-02-11 14:13:35 --> Router Class Initialized
INFO - 2020-02-11 14:13:35 --> Router Class Initialized
INFO - 2020-02-11 14:13:35 --> Router Class Initialized
INFO - 2020-02-11 14:13:35 --> URI Class Initialized
INFO - 2020-02-11 14:13:35 --> Router Class Initialized
INFO - 2020-02-11 14:13:35 --> Router Class Initialized
INFO - 2020-02-11 14:13:35 --> Output Class Initialized
INFO - 2020-02-11 14:13:35 --> Output Class Initialized
INFO - 2020-02-11 14:13:35 --> Output Class Initialized
INFO - 2020-02-11 14:13:35 --> Router Class Initialized
INFO - 2020-02-11 14:13:35 --> Output Class Initialized
INFO - 2020-02-11 14:13:35 --> Security Class Initialized
INFO - 2020-02-11 14:13:35 --> Security Class Initialized
INFO - 2020-02-11 14:13:35 --> Output Class Initialized
INFO - 2020-02-11 14:13:35 --> Output Class Initialized
INFO - 2020-02-11 14:13:35 --> Security Class Initialized
INFO - 2020-02-11 14:13:35 --> Security Class Initialized
DEBUG - 2020-02-11 14:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:13:35 --> Security Class Initialized
DEBUG - 2020-02-11 14:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 14:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 14:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:13:35 --> Security Class Initialized
INFO - 2020-02-11 14:13:35 --> Input Class Initialized
INFO - 2020-02-11 14:13:35 --> Input Class Initialized
INFO - 2020-02-11 14:13:35 --> Input Class Initialized
INFO - 2020-02-11 14:13:35 --> Input Class Initialized
DEBUG - 2020-02-11 14:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 14:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:13:35 --> Language Class Initialized
INFO - 2020-02-11 14:13:35 --> Language Class Initialized
INFO - 2020-02-11 14:13:35 --> Language Class Initialized
INFO - 2020-02-11 14:13:35 --> Input Class Initialized
INFO - 2020-02-11 14:13:35 --> Input Class Initialized
INFO - 2020-02-11 14:13:35 --> Language Class Initialized
ERROR - 2020-02-11 14:13:35 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-11 14:13:35 --> 404 Page Not Found: Bower_components/jquery-slimscroll
ERROR - 2020-02-11 14:13:35 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-11 14:13:35 --> Language Class Initialized
INFO - 2020-02-11 14:13:35 --> Language Class Initialized
ERROR - 2020-02-11 14:13:35 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-11 14:13:35 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-11 14:13:35 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-11 14:13:35 --> Config Class Initialized
INFO - 2020-02-11 14:13:35 --> Config Class Initialized
INFO - 2020-02-11 14:13:35 --> Config Class Initialized
INFO - 2020-02-11 14:13:35 --> Config Class Initialized
INFO - 2020-02-11 14:13:35 --> Hooks Class Initialized
INFO - 2020-02-11 14:13:35 --> Hooks Class Initialized
INFO - 2020-02-11 14:13:35 --> Hooks Class Initialized
INFO - 2020-02-11 14:13:35 --> Hooks Class Initialized
INFO - 2020-02-11 14:13:35 --> Config Class Initialized
INFO - 2020-02-11 14:13:35 --> Config Class Initialized
INFO - 2020-02-11 14:13:35 --> Hooks Class Initialized
INFO - 2020-02-11 14:13:35 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:13:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:13:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:13:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:13:35 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:13:35 --> Utf8 Class Initialized
INFO - 2020-02-11 14:13:35 --> Utf8 Class Initialized
INFO - 2020-02-11 14:13:35 --> Utf8 Class Initialized
INFO - 2020-02-11 14:13:35 --> Utf8 Class Initialized
DEBUG - 2020-02-11 14:13:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:13:35 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:13:35 --> Utf8 Class Initialized
INFO - 2020-02-11 14:13:35 --> URI Class Initialized
INFO - 2020-02-11 14:13:35 --> URI Class Initialized
INFO - 2020-02-11 14:13:35 --> URI Class Initialized
INFO - 2020-02-11 14:13:35 --> URI Class Initialized
INFO - 2020-02-11 14:13:35 --> Utf8 Class Initialized
INFO - 2020-02-11 14:13:35 --> URI Class Initialized
INFO - 2020-02-11 14:13:35 --> URI Class Initialized
INFO - 2020-02-11 14:13:35 --> Router Class Initialized
INFO - 2020-02-11 14:13:35 --> Router Class Initialized
INFO - 2020-02-11 14:13:35 --> Router Class Initialized
INFO - 2020-02-11 14:13:35 --> Router Class Initialized
INFO - 2020-02-11 14:13:35 --> Router Class Initialized
INFO - 2020-02-11 14:13:35 --> Output Class Initialized
INFO - 2020-02-11 14:13:35 --> Output Class Initialized
INFO - 2020-02-11 14:13:35 --> Router Class Initialized
INFO - 2020-02-11 14:13:35 --> Output Class Initialized
INFO - 2020-02-11 14:13:35 --> Output Class Initialized
INFO - 2020-02-11 14:13:35 --> Security Class Initialized
INFO - 2020-02-11 14:13:35 --> Security Class Initialized
INFO - 2020-02-11 14:13:35 --> Output Class Initialized
INFO - 2020-02-11 14:13:35 --> Output Class Initialized
INFO - 2020-02-11 14:13:35 --> Security Class Initialized
INFO - 2020-02-11 14:13:35 --> Security Class Initialized
INFO - 2020-02-11 14:13:35 --> Security Class Initialized
DEBUG - 2020-02-11 14:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 14:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 14:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:13:35 --> Security Class Initialized
DEBUG - 2020-02-11 14:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:13:35 --> Input Class Initialized
INFO - 2020-02-11 14:13:35 --> Input Class Initialized
INFO - 2020-02-11 14:13:35 --> Input Class Initialized
INFO - 2020-02-11 14:13:35 --> Input Class Initialized
DEBUG - 2020-02-11 14:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 14:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:13:35 --> Input Class Initialized
INFO - 2020-02-11 14:13:35 --> Input Class Initialized
INFO - 2020-02-11 14:13:35 --> Language Class Initialized
INFO - 2020-02-11 14:13:35 --> Language Class Initialized
INFO - 2020-02-11 14:13:35 --> Language Class Initialized
INFO - 2020-02-11 14:13:35 --> Language Class Initialized
INFO - 2020-02-11 14:13:35 --> Language Class Initialized
INFO - 2020-02-11 14:13:35 --> Language Class Initialized
ERROR - 2020-02-11 14:13:35 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-11 14:13:35 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-11 14:13:35 --> Loader Class Initialized
INFO - 2020-02-11 14:13:35 --> Loader Class Initialized
INFO - 2020-02-11 14:13:35 --> Helper loaded: url_helper
INFO - 2020-02-11 14:13:35 --> Helper loaded: url_helper
ERROR - 2020-02-11 14:13:35 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-11 14:13:35 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-11 14:13:35 --> Config Class Initialized
INFO - 2020-02-11 14:13:35 --> Config Class Initialized
INFO - 2020-02-11 14:13:35 --> Hooks Class Initialized
INFO - 2020-02-11 14:13:35 --> Hooks Class Initialized
INFO - 2020-02-11 14:13:35 --> Database Driver Class Initialized
INFO - 2020-02-11 14:13:35 --> Database Driver Class Initialized
DEBUG - 2020-02-11 14:13:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-11 14:13:35 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 14:13:35 --> Utf8 Class Initialized
INFO - 2020-02-11 14:13:35 --> Utf8 Class Initialized
INFO - 2020-02-11 14:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 14:13:35 --> Controller Class Initialized
INFO - 2020-02-11 14:13:35 --> URI Class Initialized
INFO - 2020-02-11 14:13:35 --> URI Class Initialized
INFO - 2020-02-11 14:13:35 --> Model "M_tiket" initialized
INFO - 2020-02-11 14:13:35 --> Router Class Initialized
INFO - 2020-02-11 14:13:35 --> Router Class Initialized
INFO - 2020-02-11 14:13:35 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 14:13:35 --> Output Class Initialized
INFO - 2020-02-11 14:13:35 --> Output Class Initialized
INFO - 2020-02-11 14:13:35 --> Model "M_pesan" initialized
INFO - 2020-02-11 14:13:35 --> Security Class Initialized
INFO - 2020-02-11 14:13:35 --> Security Class Initialized
DEBUG - 2020-02-11 14:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 14:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:13:35 --> Helper loaded: form_helper
INFO - 2020-02-11 14:13:35 --> Input Class Initialized
INFO - 2020-02-11 14:13:35 --> Form Validation Class Initialized
INFO - 2020-02-11 14:13:35 --> Input Class Initialized
INFO - 2020-02-11 14:13:36 --> Language Class Initialized
INFO - 2020-02-11 14:13:36 --> Language Class Initialized
ERROR - 2020-02-11 14:13:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-11 14:13:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-11 14:13:36 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-11 14:13:36 --> 404 Page Not Found: Bower_components/tether
INFO - 2020-02-11 14:13:36 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-11 14:13:36 --> Config Class Initialized
INFO - 2020-02-11 14:13:36 --> Hooks Class Initialized
INFO - 2020-02-11 14:13:36 --> Final output sent to browser
DEBUG - 2020-02-11 14:13:36 --> Total execution time: 0.6735
DEBUG - 2020-02-11 14:13:36 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:13:36 --> Utf8 Class Initialized
INFO - 2020-02-11 14:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 14:13:36 --> Controller Class Initialized
INFO - 2020-02-11 14:13:36 --> URI Class Initialized
INFO - 2020-02-11 14:13:36 --> Model "M_tiket" initialized
INFO - 2020-02-11 14:13:36 --> Router Class Initialized
INFO - 2020-02-11 14:13:36 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 14:13:36 --> Output Class Initialized
INFO - 2020-02-11 14:13:36 --> Model "M_pesan" initialized
INFO - 2020-02-11 14:13:36 --> Security Class Initialized
DEBUG - 2020-02-11 14:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:13:36 --> Helper loaded: form_helper
INFO - 2020-02-11 14:13:36 --> Form Validation Class Initialized
INFO - 2020-02-11 14:13:36 --> Input Class Initialized
INFO - 2020-02-11 14:13:36 --> Language Class Initialized
ERROR - 2020-02-11 14:13:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-11 14:13:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-11 14:13:36 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-11 14:13:36 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-11 14:13:36 --> Config Class Initialized
INFO - 2020-02-11 14:13:36 --> Hooks Class Initialized
INFO - 2020-02-11 14:13:36 --> Final output sent to browser
DEBUG - 2020-02-11 14:13:36 --> Total execution time: 0.9638
DEBUG - 2020-02-11 14:13:36 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:13:36 --> Utf8 Class Initialized
INFO - 2020-02-11 14:13:36 --> URI Class Initialized
INFO - 2020-02-11 14:13:36 --> Router Class Initialized
INFO - 2020-02-11 14:13:36 --> Output Class Initialized
INFO - 2020-02-11 14:13:36 --> Security Class Initialized
DEBUG - 2020-02-11 14:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:13:36 --> Input Class Initialized
INFO - 2020-02-11 14:13:36 --> Language Class Initialized
ERROR - 2020-02-11 14:13:36 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-11 14:13:36 --> Config Class Initialized
INFO - 2020-02-11 14:13:36 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:13:36 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:13:36 --> Utf8 Class Initialized
INFO - 2020-02-11 14:13:36 --> URI Class Initialized
INFO - 2020-02-11 14:13:36 --> Router Class Initialized
INFO - 2020-02-11 14:13:36 --> Output Class Initialized
INFO - 2020-02-11 14:13:36 --> Security Class Initialized
DEBUG - 2020-02-11 14:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:13:36 --> Input Class Initialized
INFO - 2020-02-11 14:13:36 --> Language Class Initialized
ERROR - 2020-02-11 14:13:36 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-11 14:13:36 --> Config Class Initialized
INFO - 2020-02-11 14:13:36 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:13:37 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:13:37 --> Utf8 Class Initialized
INFO - 2020-02-11 14:13:37 --> URI Class Initialized
INFO - 2020-02-11 14:13:37 --> Router Class Initialized
INFO - 2020-02-11 14:13:37 --> Output Class Initialized
INFO - 2020-02-11 14:13:37 --> Security Class Initialized
DEBUG - 2020-02-11 14:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:13:37 --> Input Class Initialized
INFO - 2020-02-11 14:13:37 --> Language Class Initialized
ERROR - 2020-02-11 14:13:37 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-11 14:13:37 --> Config Class Initialized
INFO - 2020-02-11 14:13:37 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:13:37 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:13:37 --> Utf8 Class Initialized
INFO - 2020-02-11 14:13:37 --> URI Class Initialized
INFO - 2020-02-11 14:13:37 --> Router Class Initialized
INFO - 2020-02-11 14:13:37 --> Output Class Initialized
INFO - 2020-02-11 14:13:37 --> Security Class Initialized
DEBUG - 2020-02-11 14:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:13:37 --> Input Class Initialized
INFO - 2020-02-11 14:13:37 --> Language Class Initialized
ERROR - 2020-02-11 14:13:37 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-11 14:13:37 --> Config Class Initialized
INFO - 2020-02-11 14:13:37 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:13:37 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:13:37 --> Utf8 Class Initialized
INFO - 2020-02-11 14:13:37 --> URI Class Initialized
INFO - 2020-02-11 14:13:37 --> Router Class Initialized
INFO - 2020-02-11 14:13:37 --> Output Class Initialized
INFO - 2020-02-11 14:13:37 --> Security Class Initialized
DEBUG - 2020-02-11 14:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:13:37 --> Input Class Initialized
INFO - 2020-02-11 14:13:37 --> Language Class Initialized
ERROR - 2020-02-11 14:13:37 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-11 14:13:37 --> Config Class Initialized
INFO - 2020-02-11 14:13:37 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:13:37 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:13:37 --> Utf8 Class Initialized
INFO - 2020-02-11 14:13:37 --> URI Class Initialized
INFO - 2020-02-11 14:13:37 --> Router Class Initialized
INFO - 2020-02-11 14:13:37 --> Output Class Initialized
INFO - 2020-02-11 14:13:37 --> Security Class Initialized
DEBUG - 2020-02-11 14:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:13:38 --> Input Class Initialized
INFO - 2020-02-11 14:13:38 --> Language Class Initialized
ERROR - 2020-02-11 14:13:38 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-11 14:13:38 --> Config Class Initialized
INFO - 2020-02-11 14:13:38 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:13:38 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:13:38 --> Utf8 Class Initialized
INFO - 2020-02-11 14:13:38 --> URI Class Initialized
INFO - 2020-02-11 14:13:38 --> Router Class Initialized
INFO - 2020-02-11 14:13:38 --> Output Class Initialized
INFO - 2020-02-11 14:13:38 --> Security Class Initialized
DEBUG - 2020-02-11 14:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:13:38 --> Input Class Initialized
INFO - 2020-02-11 14:13:38 --> Language Class Initialized
ERROR - 2020-02-11 14:13:38 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-11 14:17:09 --> Config Class Initialized
INFO - 2020-02-11 14:17:09 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:17:09 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:17:09 --> Utf8 Class Initialized
INFO - 2020-02-11 14:17:09 --> URI Class Initialized
INFO - 2020-02-11 14:17:10 --> Router Class Initialized
INFO - 2020-02-11 14:17:10 --> Output Class Initialized
INFO - 2020-02-11 14:17:10 --> Security Class Initialized
DEBUG - 2020-02-11 14:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:17:10 --> Input Class Initialized
INFO - 2020-02-11 14:17:10 --> Language Class Initialized
INFO - 2020-02-11 14:17:10 --> Loader Class Initialized
INFO - 2020-02-11 14:17:10 --> Helper loaded: url_helper
INFO - 2020-02-11 14:17:10 --> Database Driver Class Initialized
DEBUG - 2020-02-11 14:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 14:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 14:17:10 --> Controller Class Initialized
INFO - 2020-02-11 14:17:10 --> Model "M_tiket" initialized
INFO - 2020-02-11 14:17:10 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 14:17:10 --> Model "M_pesan" initialized
INFO - 2020-02-11 14:17:10 --> Helper loaded: form_helper
INFO - 2020-02-11 14:17:10 --> Form Validation Class Initialized
INFO - 2020-02-11 14:17:11 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-11 14:17:11 --> Final output sent to browser
DEBUG - 2020-02-11 14:17:11 --> Total execution time: 1.8222
INFO - 2020-02-11 14:17:11 --> Config Class Initialized
INFO - 2020-02-11 14:17:11 --> Config Class Initialized
INFO - 2020-02-11 14:17:11 --> Config Class Initialized
INFO - 2020-02-11 14:17:11 --> Config Class Initialized
INFO - 2020-02-11 14:17:11 --> Config Class Initialized
INFO - 2020-02-11 14:17:11 --> Config Class Initialized
INFO - 2020-02-11 14:17:11 --> Hooks Class Initialized
INFO - 2020-02-11 14:17:11 --> Hooks Class Initialized
INFO - 2020-02-11 14:17:11 --> Hooks Class Initialized
INFO - 2020-02-11 14:17:11 --> Hooks Class Initialized
INFO - 2020-02-11 14:17:11 --> Hooks Class Initialized
INFO - 2020-02-11 14:17:11 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:17:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:17:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:17:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:17:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:17:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:17:11 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:17:11 --> Utf8 Class Initialized
INFO - 2020-02-11 14:17:11 --> Utf8 Class Initialized
INFO - 2020-02-11 14:17:11 --> Utf8 Class Initialized
INFO - 2020-02-11 14:17:11 --> Utf8 Class Initialized
INFO - 2020-02-11 14:17:11 --> Utf8 Class Initialized
INFO - 2020-02-11 14:17:11 --> Utf8 Class Initialized
INFO - 2020-02-11 14:17:11 --> URI Class Initialized
INFO - 2020-02-11 14:17:11 --> URI Class Initialized
INFO - 2020-02-11 14:17:11 --> URI Class Initialized
INFO - 2020-02-11 14:17:11 --> URI Class Initialized
INFO - 2020-02-11 14:17:11 --> URI Class Initialized
INFO - 2020-02-11 14:17:11 --> URI Class Initialized
INFO - 2020-02-11 14:17:11 --> Router Class Initialized
INFO - 2020-02-11 14:17:11 --> Router Class Initialized
INFO - 2020-02-11 14:17:11 --> Router Class Initialized
INFO - 2020-02-11 14:17:11 --> Router Class Initialized
INFO - 2020-02-11 14:17:11 --> Router Class Initialized
INFO - 2020-02-11 14:17:11 --> Router Class Initialized
INFO - 2020-02-11 14:17:11 --> Output Class Initialized
INFO - 2020-02-11 14:17:11 --> Output Class Initialized
INFO - 2020-02-11 14:17:11 --> Output Class Initialized
INFO - 2020-02-11 14:17:11 --> Output Class Initialized
INFO - 2020-02-11 14:17:11 --> Output Class Initialized
INFO - 2020-02-11 14:17:11 --> Output Class Initialized
INFO - 2020-02-11 14:17:11 --> Security Class Initialized
INFO - 2020-02-11 14:17:11 --> Security Class Initialized
INFO - 2020-02-11 14:17:11 --> Security Class Initialized
INFO - 2020-02-11 14:17:11 --> Security Class Initialized
INFO - 2020-02-11 14:17:11 --> Security Class Initialized
INFO - 2020-02-11 14:17:11 --> Security Class Initialized
DEBUG - 2020-02-11 14:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 14:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 14:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 14:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 14:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 14:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:17:11 --> Input Class Initialized
INFO - 2020-02-11 14:17:11 --> Input Class Initialized
INFO - 2020-02-11 14:17:11 --> Input Class Initialized
INFO - 2020-02-11 14:17:11 --> Input Class Initialized
INFO - 2020-02-11 14:17:11 --> Input Class Initialized
INFO - 2020-02-11 14:17:11 --> Input Class Initialized
INFO - 2020-02-11 14:17:11 --> Language Class Initialized
INFO - 2020-02-11 14:17:11 --> Language Class Initialized
INFO - 2020-02-11 14:17:11 --> Language Class Initialized
INFO - 2020-02-11 14:17:11 --> Language Class Initialized
INFO - 2020-02-11 14:17:11 --> Language Class Initialized
INFO - 2020-02-11 14:17:11 --> Language Class Initialized
ERROR - 2020-02-11 14:17:11 --> 404 Page Not Found: Bower_components/jquery
ERROR - 2020-02-11 14:17:11 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-11 14:17:11 --> 404 Page Not Found: Bower_components/jquery-ui
ERROR - 2020-02-11 14:17:11 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-11 14:17:11 --> Loader Class Initialized
INFO - 2020-02-11 14:17:11 --> Loader Class Initialized
INFO - 2020-02-11 14:17:11 --> Helper loaded: url_helper
INFO - 2020-02-11 14:17:11 --> Helper loaded: url_helper
INFO - 2020-02-11 14:17:11 --> Config Class Initialized
INFO - 2020-02-11 14:17:11 --> Config Class Initialized
INFO - 2020-02-11 14:17:11 --> Config Class Initialized
INFO - 2020-02-11 14:17:11 --> Config Class Initialized
INFO - 2020-02-11 14:17:11 --> Hooks Class Initialized
INFO - 2020-02-11 14:17:11 --> Hooks Class Initialized
INFO - 2020-02-11 14:17:11 --> Hooks Class Initialized
INFO - 2020-02-11 14:17:11 --> Hooks Class Initialized
INFO - 2020-02-11 14:17:11 --> Database Driver Class Initialized
INFO - 2020-02-11 14:17:11 --> Database Driver Class Initialized
DEBUG - 2020-02-11 14:17:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:17:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:17:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-11 14:17:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 14:17:11 --> Utf8 Class Initialized
INFO - 2020-02-11 14:17:11 --> Utf8 Class Initialized
INFO - 2020-02-11 14:17:11 --> Utf8 Class Initialized
INFO - 2020-02-11 14:17:11 --> Utf8 Class Initialized
INFO - 2020-02-11 14:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 14:17:11 --> Controller Class Initialized
INFO - 2020-02-11 14:17:11 --> URI Class Initialized
INFO - 2020-02-11 14:17:11 --> URI Class Initialized
INFO - 2020-02-11 14:17:11 --> URI Class Initialized
INFO - 2020-02-11 14:17:11 --> URI Class Initialized
INFO - 2020-02-11 14:17:11 --> Model "M_tiket" initialized
INFO - 2020-02-11 14:17:11 --> Router Class Initialized
INFO - 2020-02-11 14:17:11 --> Router Class Initialized
INFO - 2020-02-11 14:17:11 --> Router Class Initialized
INFO - 2020-02-11 14:17:11 --> Router Class Initialized
INFO - 2020-02-11 14:17:11 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 14:17:11 --> Output Class Initialized
INFO - 2020-02-11 14:17:11 --> Output Class Initialized
INFO - 2020-02-11 14:17:11 --> Output Class Initialized
INFO - 2020-02-11 14:17:11 --> Output Class Initialized
INFO - 2020-02-11 14:17:11 --> Model "M_pesan" initialized
INFO - 2020-02-11 14:17:11 --> Security Class Initialized
INFO - 2020-02-11 14:17:11 --> Security Class Initialized
INFO - 2020-02-11 14:17:11 --> Security Class Initialized
INFO - 2020-02-11 14:17:11 --> Security Class Initialized
DEBUG - 2020-02-11 14:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 14:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 14:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:17:11 --> Helper loaded: form_helper
DEBUG - 2020-02-11 14:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:17:12 --> Input Class Initialized
INFO - 2020-02-11 14:17:12 --> Input Class Initialized
INFO - 2020-02-11 14:17:12 --> Form Validation Class Initialized
INFO - 2020-02-11 14:17:12 --> Input Class Initialized
INFO - 2020-02-11 14:17:12 --> Input Class Initialized
INFO - 2020-02-11 14:17:12 --> Language Class Initialized
INFO - 2020-02-11 14:17:12 --> Language Class Initialized
INFO - 2020-02-11 14:17:12 --> Language Class Initialized
INFO - 2020-02-11 14:17:12 --> Language Class Initialized
ERROR - 2020-02-11 14:17:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-11 14:17:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-11 14:17:12 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-11 14:17:12 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-11 14:17:12 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-11 14:17:12 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-11 14:17:12 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-11 14:17:12 --> Config Class Initialized
INFO - 2020-02-11 14:17:12 --> Config Class Initialized
INFO - 2020-02-11 14:17:12 --> Config Class Initialized
INFO - 2020-02-11 14:17:12 --> Config Class Initialized
INFO - 2020-02-11 14:17:12 --> Hooks Class Initialized
INFO - 2020-02-11 14:17:12 --> Hooks Class Initialized
INFO - 2020-02-11 14:17:12 --> Hooks Class Initialized
INFO - 2020-02-11 14:17:12 --> Hooks Class Initialized
INFO - 2020-02-11 14:17:12 --> Final output sent to browser
DEBUG - 2020-02-11 14:17:12 --> Total execution time: 1.0404
DEBUG - 2020-02-11 14:17:12 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:17:12 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:17:12 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:17:12 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:17:12 --> Utf8 Class Initialized
INFO - 2020-02-11 14:17:12 --> Utf8 Class Initialized
INFO - 2020-02-11 14:17:12 --> Utf8 Class Initialized
INFO - 2020-02-11 14:17:12 --> Utf8 Class Initialized
INFO - 2020-02-11 14:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 14:17:12 --> Controller Class Initialized
INFO - 2020-02-11 14:17:12 --> URI Class Initialized
INFO - 2020-02-11 14:17:12 --> URI Class Initialized
INFO - 2020-02-11 14:17:12 --> URI Class Initialized
INFO - 2020-02-11 14:17:12 --> URI Class Initialized
INFO - 2020-02-11 14:17:12 --> Model "M_tiket" initialized
INFO - 2020-02-11 14:17:12 --> Router Class Initialized
INFO - 2020-02-11 14:17:12 --> Router Class Initialized
INFO - 2020-02-11 14:17:12 --> Router Class Initialized
INFO - 2020-02-11 14:17:12 --> Router Class Initialized
INFO - 2020-02-11 14:17:12 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 14:17:12 --> Output Class Initialized
INFO - 2020-02-11 14:17:12 --> Output Class Initialized
INFO - 2020-02-11 14:17:12 --> Output Class Initialized
INFO - 2020-02-11 14:17:12 --> Output Class Initialized
INFO - 2020-02-11 14:17:12 --> Model "M_pesan" initialized
INFO - 2020-02-11 14:17:12 --> Security Class Initialized
INFO - 2020-02-11 14:17:12 --> Security Class Initialized
INFO - 2020-02-11 14:17:12 --> Security Class Initialized
INFO - 2020-02-11 14:17:12 --> Security Class Initialized
DEBUG - 2020-02-11 14:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 14:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 14:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 14:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:17:12 --> Helper loaded: form_helper
INFO - 2020-02-11 14:17:12 --> Form Validation Class Initialized
INFO - 2020-02-11 14:17:12 --> Input Class Initialized
INFO - 2020-02-11 14:17:12 --> Input Class Initialized
INFO - 2020-02-11 14:17:12 --> Input Class Initialized
INFO - 2020-02-11 14:17:12 --> Input Class Initialized
INFO - 2020-02-11 14:17:12 --> Language Class Initialized
INFO - 2020-02-11 14:17:12 --> Language Class Initialized
INFO - 2020-02-11 14:17:12 --> Language Class Initialized
INFO - 2020-02-11 14:17:12 --> Language Class Initialized
ERROR - 2020-02-11 14:17:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
ERROR - 2020-02-11 14:17:12 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-11 14:17:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-11 14:17:12 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
ERROR - 2020-02-11 14:17:12 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-11 14:17:12 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-11 14:17:12 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-11 14:17:12 --> Config Class Initialized
INFO - 2020-02-11 14:17:12 --> Hooks Class Initialized
INFO - 2020-02-11 14:17:12 --> Final output sent to browser
DEBUG - 2020-02-11 14:17:12 --> Total execution time: 1.3785
DEBUG - 2020-02-11 14:17:12 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:17:12 --> Utf8 Class Initialized
INFO - 2020-02-11 14:17:12 --> URI Class Initialized
INFO - 2020-02-11 14:17:12 --> Router Class Initialized
INFO - 2020-02-11 14:17:12 --> Output Class Initialized
INFO - 2020-02-11 14:17:12 --> Security Class Initialized
DEBUG - 2020-02-11 14:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:17:12 --> Input Class Initialized
INFO - 2020-02-11 14:17:12 --> Language Class Initialized
ERROR - 2020-02-11 14:17:12 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-11 14:17:12 --> Config Class Initialized
INFO - 2020-02-11 14:17:12 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:17:12 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:17:12 --> Utf8 Class Initialized
INFO - 2020-02-11 14:17:13 --> URI Class Initialized
INFO - 2020-02-11 14:17:13 --> Router Class Initialized
INFO - 2020-02-11 14:17:13 --> Output Class Initialized
INFO - 2020-02-11 14:17:13 --> Security Class Initialized
DEBUG - 2020-02-11 14:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:17:13 --> Input Class Initialized
INFO - 2020-02-11 14:17:13 --> Language Class Initialized
ERROR - 2020-02-11 14:17:13 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-11 14:17:13 --> Config Class Initialized
INFO - 2020-02-11 14:17:13 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:17:13 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:17:13 --> Utf8 Class Initialized
INFO - 2020-02-11 14:17:13 --> URI Class Initialized
INFO - 2020-02-11 14:17:13 --> Router Class Initialized
INFO - 2020-02-11 14:17:13 --> Output Class Initialized
INFO - 2020-02-11 14:17:13 --> Security Class Initialized
DEBUG - 2020-02-11 14:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:17:13 --> Input Class Initialized
INFO - 2020-02-11 14:17:13 --> Language Class Initialized
ERROR - 2020-02-11 14:17:13 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-11 14:17:13 --> Config Class Initialized
INFO - 2020-02-11 14:17:13 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:17:13 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:17:13 --> Utf8 Class Initialized
INFO - 2020-02-11 14:17:13 --> URI Class Initialized
INFO - 2020-02-11 14:17:13 --> Router Class Initialized
INFO - 2020-02-11 14:17:13 --> Output Class Initialized
INFO - 2020-02-11 14:17:13 --> Security Class Initialized
DEBUG - 2020-02-11 14:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:17:13 --> Input Class Initialized
INFO - 2020-02-11 14:17:13 --> Language Class Initialized
ERROR - 2020-02-11 14:17:13 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-11 14:17:13 --> Config Class Initialized
INFO - 2020-02-11 14:17:13 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:17:13 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:17:13 --> Utf8 Class Initialized
INFO - 2020-02-11 14:17:13 --> URI Class Initialized
INFO - 2020-02-11 14:17:13 --> Router Class Initialized
INFO - 2020-02-11 14:17:13 --> Output Class Initialized
INFO - 2020-02-11 14:17:14 --> Security Class Initialized
DEBUG - 2020-02-11 14:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:17:14 --> Input Class Initialized
INFO - 2020-02-11 14:17:14 --> Language Class Initialized
ERROR - 2020-02-11 14:17:14 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-11 14:17:14 --> Config Class Initialized
INFO - 2020-02-11 14:17:14 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:17:14 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:17:14 --> Utf8 Class Initialized
INFO - 2020-02-11 14:17:14 --> URI Class Initialized
INFO - 2020-02-11 14:17:14 --> Router Class Initialized
INFO - 2020-02-11 14:17:14 --> Output Class Initialized
INFO - 2020-02-11 14:17:14 --> Security Class Initialized
DEBUG - 2020-02-11 14:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:17:14 --> Input Class Initialized
INFO - 2020-02-11 14:17:14 --> Language Class Initialized
ERROR - 2020-02-11 14:17:14 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-11 14:17:14 --> Config Class Initialized
INFO - 2020-02-11 14:17:14 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:17:14 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:17:14 --> Utf8 Class Initialized
INFO - 2020-02-11 14:17:14 --> URI Class Initialized
INFO - 2020-02-11 14:17:14 --> Router Class Initialized
INFO - 2020-02-11 14:17:14 --> Output Class Initialized
INFO - 2020-02-11 14:17:14 --> Security Class Initialized
DEBUG - 2020-02-11 14:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:17:14 --> Input Class Initialized
INFO - 2020-02-11 14:17:14 --> Language Class Initialized
ERROR - 2020-02-11 14:17:14 --> 404 Page Not Found: Bower_components/jquery-i18next
INFO - 2020-02-11 14:18:12 --> Config Class Initialized
INFO - 2020-02-11 14:18:12 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:18:12 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:18:12 --> Utf8 Class Initialized
INFO - 2020-02-11 14:18:12 --> URI Class Initialized
INFO - 2020-02-11 14:18:12 --> Router Class Initialized
INFO - 2020-02-11 14:18:13 --> Output Class Initialized
INFO - 2020-02-11 14:18:13 --> Security Class Initialized
DEBUG - 2020-02-11 14:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:18:13 --> Input Class Initialized
INFO - 2020-02-11 14:18:13 --> Language Class Initialized
INFO - 2020-02-11 14:18:13 --> Loader Class Initialized
INFO - 2020-02-11 14:18:13 --> Helper loaded: url_helper
INFO - 2020-02-11 14:18:13 --> Database Driver Class Initialized
DEBUG - 2020-02-11 14:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 14:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 14:18:13 --> Controller Class Initialized
INFO - 2020-02-11 14:18:13 --> Model "M_tiket" initialized
INFO - 2020-02-11 14:18:13 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 14:18:13 --> Model "M_pesan" initialized
INFO - 2020-02-11 14:18:13 --> Helper loaded: form_helper
INFO - 2020-02-11 14:18:13 --> Form Validation Class Initialized
INFO - 2020-02-11 14:18:13 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
INFO - 2020-02-11 14:18:13 --> Final output sent to browser
DEBUG - 2020-02-11 14:18:13 --> Total execution time: 0.8017
INFO - 2020-02-11 14:18:13 --> Config Class Initialized
INFO - 2020-02-11 14:18:13 --> Config Class Initialized
INFO - 2020-02-11 14:18:13 --> Config Class Initialized
INFO - 2020-02-11 14:18:13 --> Hooks Class Initialized
INFO - 2020-02-11 14:18:13 --> Hooks Class Initialized
INFO - 2020-02-11 14:18:13 --> Hooks Class Initialized
INFO - 2020-02-11 14:18:13 --> Config Class Initialized
INFO - 2020-02-11 14:18:13 --> Config Class Initialized
INFO - 2020-02-11 14:18:13 --> Config Class Initialized
INFO - 2020-02-11 14:18:13 --> Hooks Class Initialized
INFO - 2020-02-11 14:18:13 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:18:13 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:18:13 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:18:13 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:18:13 --> Hooks Class Initialized
INFO - 2020-02-11 14:18:13 --> Utf8 Class Initialized
INFO - 2020-02-11 14:18:13 --> Utf8 Class Initialized
INFO - 2020-02-11 14:18:13 --> Utf8 Class Initialized
DEBUG - 2020-02-11 14:18:13 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:18:13 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:18:13 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:18:13 --> Utf8 Class Initialized
INFO - 2020-02-11 14:18:13 --> Utf8 Class Initialized
INFO - 2020-02-11 14:18:13 --> Utf8 Class Initialized
INFO - 2020-02-11 14:18:13 --> URI Class Initialized
INFO - 2020-02-11 14:18:13 --> URI Class Initialized
INFO - 2020-02-11 14:18:13 --> URI Class Initialized
INFO - 2020-02-11 14:18:13 --> Router Class Initialized
INFO - 2020-02-11 14:18:13 --> Router Class Initialized
INFO - 2020-02-11 14:18:13 --> URI Class Initialized
INFO - 2020-02-11 14:18:13 --> URI Class Initialized
INFO - 2020-02-11 14:18:13 --> URI Class Initialized
INFO - 2020-02-11 14:18:13 --> Router Class Initialized
INFO - 2020-02-11 14:18:13 --> Router Class Initialized
INFO - 2020-02-11 14:18:13 --> Output Class Initialized
INFO - 2020-02-11 14:18:13 --> Router Class Initialized
INFO - 2020-02-11 14:18:13 --> Output Class Initialized
INFO - 2020-02-11 14:18:13 --> Output Class Initialized
INFO - 2020-02-11 14:18:13 --> Router Class Initialized
INFO - 2020-02-11 14:18:13 --> Security Class Initialized
INFO - 2020-02-11 14:18:13 --> Security Class Initialized
INFO - 2020-02-11 14:18:13 --> Output Class Initialized
INFO - 2020-02-11 14:18:13 --> Security Class Initialized
INFO - 2020-02-11 14:18:13 --> Output Class Initialized
INFO - 2020-02-11 14:18:13 --> Output Class Initialized
DEBUG - 2020-02-11 14:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:18:13 --> Security Class Initialized
INFO - 2020-02-11 14:18:13 --> Security Class Initialized
DEBUG - 2020-02-11 14:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:18:13 --> Security Class Initialized
DEBUG - 2020-02-11 14:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:18:13 --> Input Class Initialized
INFO - 2020-02-11 14:18:13 --> Input Class Initialized
INFO - 2020-02-11 14:18:13 --> Input Class Initialized
DEBUG - 2020-02-11 14:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 14:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 14:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:18:13 --> Input Class Initialized
INFO - 2020-02-11 14:18:13 --> Input Class Initialized
INFO - 2020-02-11 14:18:13 --> Input Class Initialized
INFO - 2020-02-11 14:18:13 --> Language Class Initialized
INFO - 2020-02-11 14:18:13 --> Language Class Initialized
INFO - 2020-02-11 14:18:13 --> Language Class Initialized
INFO - 2020-02-11 14:18:13 --> Language Class Initialized
ERROR - 2020-02-11 14:18:13 --> 404 Page Not Found: Bower_components/jquery
INFO - 2020-02-11 14:18:13 --> Language Class Initialized
INFO - 2020-02-11 14:18:13 --> Language Class Initialized
INFO - 2020-02-11 14:18:13 --> Loader Class Initialized
INFO - 2020-02-11 14:18:13 --> Loader Class Initialized
ERROR - 2020-02-11 14:18:13 --> 404 Page Not Found: Bower_components/bootstrap
INFO - 2020-02-11 14:18:13 --> Helper loaded: url_helper
ERROR - 2020-02-11 14:18:13 --> 404 Page Not Found: Bower_components/tether
ERROR - 2020-02-11 14:18:13 --> 404 Page Not Found: Bower_components/jquery-ui
INFO - 2020-02-11 14:18:13 --> Helper loaded: url_helper
INFO - 2020-02-11 14:18:13 --> Config Class Initialized
INFO - 2020-02-11 14:18:13 --> Hooks Class Initialized
INFO - 2020-02-11 14:18:13 --> Database Driver Class Initialized
INFO - 2020-02-11 14:18:13 --> Config Class Initialized
INFO - 2020-02-11 14:18:13 --> Config Class Initialized
INFO - 2020-02-11 14:18:14 --> Config Class Initialized
INFO - 2020-02-11 14:18:14 --> Database Driver Class Initialized
INFO - 2020-02-11 14:18:14 --> Hooks Class Initialized
INFO - 2020-02-11 14:18:14 --> Hooks Class Initialized
INFO - 2020-02-11 14:18:14 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:18:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-02-11 14:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 14:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 14:18:14 --> Utf8 Class Initialized
DEBUG - 2020-02-11 14:18:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:18:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:18:14 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:18:14 --> Utf8 Class Initialized
INFO - 2020-02-11 14:18:14 --> Utf8 Class Initialized
INFO - 2020-02-11 14:18:14 --> Controller Class Initialized
INFO - 2020-02-11 14:18:14 --> Utf8 Class Initialized
INFO - 2020-02-11 14:18:14 --> URI Class Initialized
INFO - 2020-02-11 14:18:14 --> URI Class Initialized
INFO - 2020-02-11 14:18:14 --> URI Class Initialized
INFO - 2020-02-11 14:18:14 --> URI Class Initialized
INFO - 2020-02-11 14:18:14 --> Model "M_tiket" initialized
INFO - 2020-02-11 14:18:14 --> Router Class Initialized
INFO - 2020-02-11 14:18:14 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 14:18:14 --> Router Class Initialized
INFO - 2020-02-11 14:18:14 --> Output Class Initialized
INFO - 2020-02-11 14:18:14 --> Router Class Initialized
INFO - 2020-02-11 14:18:14 --> Router Class Initialized
INFO - 2020-02-11 14:18:14 --> Model "M_pesan" initialized
INFO - 2020-02-11 14:18:14 --> Security Class Initialized
INFO - 2020-02-11 14:18:14 --> Output Class Initialized
INFO - 2020-02-11 14:18:14 --> Output Class Initialized
INFO - 2020-02-11 14:18:14 --> Output Class Initialized
DEBUG - 2020-02-11 14:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:18:14 --> Security Class Initialized
INFO - 2020-02-11 14:18:14 --> Security Class Initialized
INFO - 2020-02-11 14:18:14 --> Security Class Initialized
INFO - 2020-02-11 14:18:14 --> Helper loaded: form_helper
INFO - 2020-02-11 14:18:14 --> Input Class Initialized
INFO - 2020-02-11 14:18:14 --> Form Validation Class Initialized
DEBUG - 2020-02-11 14:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 14:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 14:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:18:14 --> Input Class Initialized
INFO - 2020-02-11 14:18:14 --> Input Class Initialized
INFO - 2020-02-11 14:18:14 --> Input Class Initialized
INFO - 2020-02-11 14:18:14 --> Language Class Initialized
ERROR - 2020-02-11 14:18:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-11 14:18:14 --> Language Class Initialized
INFO - 2020-02-11 14:18:14 --> Language Class Initialized
ERROR - 2020-02-11 14:18:14 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-11 14:18:14 --> Language Class Initialized
ERROR - 2020-02-11 14:18:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
INFO - 2020-02-11 14:18:14 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-11 14:18:14 --> 404 Page Not Found: Bower_components/modernizr
ERROR - 2020-02-11 14:18:14 --> 404 Page Not Found: Bower_components/i18next
ERROR - 2020-02-11 14:18:14 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-11 14:18:14 --> Config Class Initialized
INFO - 2020-02-11 14:18:14 --> Hooks Class Initialized
INFO - 2020-02-11 14:18:14 --> Final output sent to browser
INFO - 2020-02-11 14:18:14 --> Config Class Initialized
INFO - 2020-02-11 14:18:14 --> Config Class Initialized
INFO - 2020-02-11 14:18:14 --> Config Class Initialized
INFO - 2020-02-11 14:18:14 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:18:14 --> Total execution time: 0.7920
INFO - 2020-02-11 14:18:14 --> Hooks Class Initialized
INFO - 2020-02-11 14:18:14 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:18:14 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:18:14 --> Utf8 Class Initialized
INFO - 2020-02-11 14:18:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-11 14:18:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:18:14 --> UTF-8 Support Enabled
DEBUG - 2020-02-11 14:18:14 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:18:14 --> Controller Class Initialized
INFO - 2020-02-11 14:18:14 --> Utf8 Class Initialized
INFO - 2020-02-11 14:18:14 --> Utf8 Class Initialized
INFO - 2020-02-11 14:18:14 --> Utf8 Class Initialized
INFO - 2020-02-11 14:18:14 --> URI Class Initialized
INFO - 2020-02-11 14:18:14 --> URI Class Initialized
INFO - 2020-02-11 14:18:14 --> URI Class Initialized
INFO - 2020-02-11 14:18:14 --> Model "M_tiket" initialized
INFO - 2020-02-11 14:18:14 --> URI Class Initialized
INFO - 2020-02-11 14:18:14 --> Router Class Initialized
INFO - 2020-02-11 14:18:14 --> Output Class Initialized
INFO - 2020-02-11 14:18:14 --> Router Class Initialized
INFO - 2020-02-11 14:18:14 --> Model "M_pengunjung" initialized
INFO - 2020-02-11 14:18:14 --> Router Class Initialized
INFO - 2020-02-11 14:18:14 --> Router Class Initialized
INFO - 2020-02-11 14:18:14 --> Model "M_pesan" initialized
INFO - 2020-02-11 14:18:14 --> Output Class Initialized
INFO - 2020-02-11 14:18:14 --> Output Class Initialized
INFO - 2020-02-11 14:18:14 --> Output Class Initialized
INFO - 2020-02-11 14:18:14 --> Security Class Initialized
DEBUG - 2020-02-11 14:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:18:14 --> Security Class Initialized
INFO - 2020-02-11 14:18:14 --> Security Class Initialized
INFO - 2020-02-11 14:18:14 --> Security Class Initialized
INFO - 2020-02-11 14:18:14 --> Helper loaded: form_helper
INFO - 2020-02-11 14:18:14 --> Form Validation Class Initialized
INFO - 2020-02-11 14:18:14 --> Input Class Initialized
DEBUG - 2020-02-11 14:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 14:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-02-11 14:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:18:14 --> Input Class Initialized
INFO - 2020-02-11 14:18:14 --> Input Class Initialized
INFO - 2020-02-11 14:18:14 --> Input Class Initialized
INFO - 2020-02-11 14:18:14 --> Language Class Initialized
ERROR - 2020-02-11 14:18:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 57
INFO - 2020-02-11 14:18:14 --> Language Class Initialized
INFO - 2020-02-11 14:18:14 --> Language Class Initialized
ERROR - 2020-02-11 14:18:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\roadshow\application\views\tiket\lihat_jenis.php 58
ERROR - 2020-02-11 14:18:14 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-11 14:18:14 --> Language Class Initialized
INFO - 2020-02-11 14:18:14 --> File loaded: C:\xampp\htdocs\roadshow\application\views\tiket/lihat_jenis.php
ERROR - 2020-02-11 14:18:14 --> 404 Page Not Found: Bower_components/jquery-i18next
ERROR - 2020-02-11 14:18:14 --> 404 Page Not Found: Bower_components/bootstrap
ERROR - 2020-02-11 14:18:14 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-11 14:18:14 --> Final output sent to browser
INFO - 2020-02-11 14:18:14 --> Config Class Initialized
INFO - 2020-02-11 14:18:14 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:18:14 --> Total execution time: 1.1379
DEBUG - 2020-02-11 14:18:14 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:18:14 --> Utf8 Class Initialized
INFO - 2020-02-11 14:18:14 --> URI Class Initialized
INFO - 2020-02-11 14:18:14 --> Router Class Initialized
INFO - 2020-02-11 14:18:14 --> Output Class Initialized
INFO - 2020-02-11 14:18:14 --> Security Class Initialized
DEBUG - 2020-02-11 14:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:18:14 --> Input Class Initialized
INFO - 2020-02-11 14:18:14 --> Language Class Initialized
ERROR - 2020-02-11 14:18:14 --> 404 Page Not Found: Bower_components/jquery-slimscroll
INFO - 2020-02-11 14:18:15 --> Config Class Initialized
INFO - 2020-02-11 14:18:15 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:18:15 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:18:15 --> Utf8 Class Initialized
INFO - 2020-02-11 14:18:15 --> URI Class Initialized
INFO - 2020-02-11 14:18:15 --> Router Class Initialized
INFO - 2020-02-11 14:18:15 --> Output Class Initialized
INFO - 2020-02-11 14:18:15 --> Security Class Initialized
DEBUG - 2020-02-11 14:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:18:15 --> Input Class Initialized
INFO - 2020-02-11 14:18:15 --> Language Class Initialized
ERROR - 2020-02-11 14:18:15 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-11 14:18:15 --> Config Class Initialized
INFO - 2020-02-11 14:18:15 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:18:15 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:18:15 --> Utf8 Class Initialized
INFO - 2020-02-11 14:18:15 --> URI Class Initialized
INFO - 2020-02-11 14:18:15 --> Router Class Initialized
INFO - 2020-02-11 14:18:15 --> Output Class Initialized
INFO - 2020-02-11 14:18:15 --> Security Class Initialized
DEBUG - 2020-02-11 14:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:18:15 --> Input Class Initialized
INFO - 2020-02-11 14:18:15 --> Language Class Initialized
ERROR - 2020-02-11 14:18:15 --> 404 Page Not Found: Bower_components/modernizr
INFO - 2020-02-11 14:18:15 --> Config Class Initialized
INFO - 2020-02-11 14:18:15 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:18:15 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:18:15 --> Utf8 Class Initialized
INFO - 2020-02-11 14:18:15 --> URI Class Initialized
INFO - 2020-02-11 14:18:15 --> Router Class Initialized
INFO - 2020-02-11 14:18:15 --> Output Class Initialized
INFO - 2020-02-11 14:18:15 --> Security Class Initialized
DEBUG - 2020-02-11 14:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:18:15 --> Input Class Initialized
INFO - 2020-02-11 14:18:15 --> Language Class Initialized
ERROR - 2020-02-11 14:18:15 --> 404 Page Not Found: Bower_components/i18next
INFO - 2020-02-11 14:18:15 --> Config Class Initialized
INFO - 2020-02-11 14:18:15 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:18:16 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:18:16 --> Utf8 Class Initialized
INFO - 2020-02-11 14:18:16 --> URI Class Initialized
INFO - 2020-02-11 14:18:16 --> Router Class Initialized
INFO - 2020-02-11 14:18:16 --> Output Class Initialized
INFO - 2020-02-11 14:18:16 --> Security Class Initialized
DEBUG - 2020-02-11 14:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:18:16 --> Input Class Initialized
INFO - 2020-02-11 14:18:16 --> Language Class Initialized
ERROR - 2020-02-11 14:18:16 --> 404 Page Not Found: Bower_components/i18next-xhr-backend
INFO - 2020-02-11 14:18:16 --> Config Class Initialized
INFO - 2020-02-11 14:18:16 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:18:16 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:18:16 --> Utf8 Class Initialized
INFO - 2020-02-11 14:18:16 --> URI Class Initialized
INFO - 2020-02-11 14:18:16 --> Router Class Initialized
INFO - 2020-02-11 14:18:16 --> Output Class Initialized
INFO - 2020-02-11 14:18:16 --> Security Class Initialized
DEBUG - 2020-02-11 14:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:18:16 --> Input Class Initialized
INFO - 2020-02-11 14:18:16 --> Language Class Initialized
ERROR - 2020-02-11 14:18:16 --> 404 Page Not Found: Bower_components/i18next-browser-languagedetector
INFO - 2020-02-11 14:18:16 --> Config Class Initialized
INFO - 2020-02-11 14:18:16 --> Hooks Class Initialized
DEBUG - 2020-02-11 14:18:16 --> UTF-8 Support Enabled
INFO - 2020-02-11 14:18:16 --> Utf8 Class Initialized
INFO - 2020-02-11 14:18:16 --> URI Class Initialized
INFO - 2020-02-11 14:18:16 --> Router Class Initialized
INFO - 2020-02-11 14:18:16 --> Output Class Initialized
INFO - 2020-02-11 14:18:16 --> Security Class Initialized
DEBUG - 2020-02-11 14:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 14:18:16 --> Input Class Initialized
INFO - 2020-02-11 14:18:16 --> Language Class Initialized
ERROR - 2020-02-11 14:18:16 --> 404 Page Not Found: Bower_components/jquery-i18next
