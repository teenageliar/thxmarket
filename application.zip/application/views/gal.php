<div class="localP6">
                     <div class="col-lg-12 centered" style="margin: auto;">
                        <br /><br />
                        <div class="gallery">
                            <div class="col-lg-3">
                                <img src="<?php echo base_url()?>asset/image/kontent/gallery/f59e1851-a4bf-4759-9eb5-93652413e9aa.jpg" onclick="lightbox(0)" style="width:auto;" class="abaout3 img img-responsive"  />
                            </div>
                            <div class="col-lg-3">
                                <img src="<?php echo base_url()?>asset/image/kontent/gallery/e9893055-13d4-4459-8a41-062b1cd0d173.jpg" onclick="lightbox(1)" style="width:auto;" class="abaout3 img img-responsive" />
                            </div>
                            <div class="col-lg-3">
                                <img src="<?php echo base_url()?>asset/image/kontent/gallery/c68413f0-fa58-4ad4-a72e-e3881b3306d1.jpg" onclick="lightbox(2)" style="width:auto;" class="abaout3 img img-responsive" />
                            </div>
                            <div class="col-lg-3">
                                <img src="<?php echo base_url()?>asset/image/kontent/gallery/ba9c8d04-4970-4bdc-8bf0-0ce7e842f585.jpg" onclick="lightbox(3)" style="width:auto;" class="abaout3 img img-responsive" />
                            </div>
                                 <div class="col-lg-3">
                                <img src="<?php echo base_url()?>asset/image/kontent/gallery/aed1b70a-6d74-49de-8fd3-600b944f11ae.jpg" onclick="lightbox(4)" style="width:auto;" class="abaout3 img img-responsive"  />
                            </div>
                            <div class="col-lg-3">
                                <img src="<?php echo base_url()?>asset/image/kontent/gallery/a6e9c4cc-0b64-4a4f-b1da-5a25576eb318.jpg" onclick="lightbox(5)" style="width:auto;" class="abaout3 img img-responsive" />
                            </div>
                            <div class="col-lg-3">
                                <img src="<?php echo base_url()?>asset/image/kontent/gallery/9fb50341-9fdf-4bc8-9a0e-0d5b9538f4f8.jpg" onclick="lightbox(6)" style="width:auto;" class="abaout3 img img-responsive"  />
                            </div>
                            <div class="col-lg-3">
                                <img src="<?php echo base_url()?>asset/image/kontent/gallery/9db856c0-6c0b-4fb9-8b31-42ef1f5834b5.jpg" onclick="lightbox(7)" style="width:auto;" class="abaout3 img img-responsive" />
                            </div>
                        </div>
                        </div>
            </div>

       <div style="display:none;">
        <div id="ninja-slider">
            <div class="slider-inner">
                <ul>
                    <li>
                        <a class="ns-img" href="<?php echo base_url()?>asset/image/kontent/gallery/f59e1851-a4bf-4759-9eb5-93652413e9aa.jpg"></a>
                        <div class="caption">
                            <h3>Musikologi 2019</h3>
                        </div>
                    </li>
                    <li>
                        <a class="ns-img" href="<?php echo base_url()?>asset/image/kontent/gallery/e9893055-13d4-4459-8a41-062b1cd0d173.jpg"></a>
                        <div class="caption">
                            <h3>Musikologi 2019</h3>
                        </div>
                    </li>
                    <li>
                        <a class="ns-img" href="<?php echo base_url()?>asset/image/kontent/gallery/c68413f0-fa58-4ad4-a72e-e3881b3306d1.jpg"></a>
                        <div class="caption">
                            <h3>Musikologi 2019</h3>
                        </div>
                    </li>
                    <li>
                        <a class="ns-img" href="<?php echo base_url()?>asset/image/kontent/gallery/ba9c8d04-4970-4bdc-8bf0-0ce7e842f585.jpg"></a>
                        <div class="caption">
                            <h3>Musikologi 2019</h3>
                        </div>
                    </li>
                    <li>
                        <a class="ns-img" href="<?php echo base_url()?>asset/image/kontent/gallery/aed1b70a-6d74-49de-8fd3-600b944f11ae.jpg"></a>
                        <div class="caption">
                            <h3>Musikologi 2019</h3>
                        </div>
                    </li>
                    <li>
                        <a class="ns-img" href="<?php echo base_url()?>asset/image/kontent/gallery/a6e9c4cc-0b64-4a4f-b1da-5a25576eb318.jpg"></a>
                        <div class="caption">
                            <h3>Musikologi 2019</h3>
                        </div>
                    </li>
                    <li>
                        <a class="ns-img" href="<?php echo base_url()?>asset/image/kontent/gallery/9fb50341-9fdf-4bc8-9a0e-0d5b9538f4f8.jpg"></a>
                        <div class="caption">
                            <h3>Musikologi 2019</h3>
                        </div>
                    </li>
                    <li>
                        <a class="ns-img" href="<?php echo base_url()?>asset/image/kontent/gallery/9db856c0-6c0b-4fb9-8b31-42ef1f5834b5.jpg"></a>
                        <div class="caption">
                            <h3>Musikologi 2019</h3>
                        </div>
                    </li>
                    </ul>
                <div id="fsBtn" class="fs-icon" title="Expand/Close"></div>
            </div>
        </div>
    </div>
         